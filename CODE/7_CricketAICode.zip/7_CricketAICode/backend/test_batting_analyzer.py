from app.biomechanics.batting.analyzer import BattingAnalyzer

analyzer = BattingAnalyzer()

report = analyzer.analyze(
    "analysis/test_video/landmarks/landmarks.json"
)

print(report[:5])
