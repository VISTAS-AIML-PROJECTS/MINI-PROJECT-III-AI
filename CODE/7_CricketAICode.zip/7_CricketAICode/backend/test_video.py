from pathlib import Path
from app.ai.video_processor import load_video

uploads = Path("uploads")

video_files = list(uploads.glob("*.mp4"))

if not video_files:
    raise FileNotFoundError("No MP4 files found in uploads folder.")

video = load_video(str(video_files[0]))

print("Video loaded successfully!")
print(video)
