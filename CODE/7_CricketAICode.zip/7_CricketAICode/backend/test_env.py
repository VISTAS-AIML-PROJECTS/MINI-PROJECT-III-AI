from dotenv import load_dotenv
import os

load_dotenv()

print("MONGO_URI:", os.getenv("MONGO_URI"))
print("DB:", os.getenv("MONGO_DB_NAME"))
