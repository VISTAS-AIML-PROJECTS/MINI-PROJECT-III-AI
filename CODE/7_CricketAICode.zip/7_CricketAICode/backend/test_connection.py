from pymongo import MongoClient

uri = "mongodb+srv://wahidcricketer12_db_user:Abwah2502.@cluster0.gygnv2c.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

try:
    client = MongoClient(uri, serverSelectionTimeoutMS=10000)
    print(client.admin.command("ping"))
    print("Connected successfully!")
except Exception as e:
    print(type(e).__name__)
    print(e)
