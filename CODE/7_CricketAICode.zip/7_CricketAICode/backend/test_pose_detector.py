from app.vision.pose_detector import PoseDetector

detector = PoseDetector()

result = detector.process_frames(
    frames_dir="analysis/test_video/frames",
    output_json="analysis/test_video/landmarks/landmarks.json",
)

print(result)
