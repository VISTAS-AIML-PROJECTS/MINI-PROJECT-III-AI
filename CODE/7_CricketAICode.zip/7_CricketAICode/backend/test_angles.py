from app.biomechanics.common.angles import AngleCalculator

A = (1, 0)
B = (0, 0)
C = (0, 1)

angle = AngleCalculator.calculate_angle(A, B, C)

print(angle)
