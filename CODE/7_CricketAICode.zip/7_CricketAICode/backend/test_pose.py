from pathlib import Path

from app.ai.pose_detector import detect_landmarks

uploads = Path("uploads")

video = list(uploads.glob("*.mp4"))[0]

frames = detect_landmarks(str(video))

print(f"Frames with pose detected: {len(frames)}")

if frames:
    print(f"Frame Index: {frames[0].frame_index}")
    print(f"Landmarks: {len(frames[0].landmarks)}")
