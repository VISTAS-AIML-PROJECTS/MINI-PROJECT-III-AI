from app.analysis.analyzer import CricketAnalyzer

pipeline = CricketAnalyzer()

result = pipeline.analyze_video(
    video_path="uploads/019469e4-571d-4496-80ee-24d43199dd60_WhatsApp Video 2026-07-19 at 11.38.20 PM.mp4",
    output_dir="analysis/test_pipeline",
)

print(result["frame_extraction"])
print(result["pose_detection"])
print(result["batting_analysis"][:3])
