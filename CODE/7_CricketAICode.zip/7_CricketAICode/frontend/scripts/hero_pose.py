"""
Temporal post-processing for per-frame MediaPipe pose detections.

Input : raw[F, L, 3]  (x, y, visibility), NaN where nothing was detected.
Output: clean[F, L, 3] (NaN = no trustworthy landmark) + per-frame status.

Rules
- Detection happens independently per frame (caller's job).
- Low-confidence landmarks are dropped, never guessed.
- Implausible frames (wrong size / shape) are rejected outright.
- Left/right swaps are corrected against the previous pose.
- One-frame spikes are removed; fast but smooth motion is kept.
- Short gaps are interpolated between valid frames; short leading /
  trailing gaps hold the nearest valid pose. Longer gaps stay empty.
- Smoothing is zero-phase (centred), so the overlay never lags the player.

Everything is pure numpy so it can be unit-tested without MediaPipe.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

NAMES = [
    "nose",
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]
IDX = {n: i for i, n in enumerate(NAMES)}
LR_PAIRS = [(IDX[f"left_{p}"], IDX[f"right_{p}"]) for p in ("shoulder", "elbow", "wrist", "hip", "knee", "ankle")]
BONES = [
    ("left_shoulder", "left_elbow"), ("left_elbow", "left_wrist"),
    ("right_shoulder", "right_elbow"), ("right_elbow", "right_wrist"),
    ("left_hip", "left_knee"), ("left_knee", "left_ankle"),
    ("right_hip", "right_knee"), ("right_knee", "right_ankle"),
]

DETECTED, INTERPOLATED, HELD, MISSING = "detected", "interpolated", "held", "missing"


@dataclass
class PoseOptions:
    min_visibility: float = 0.5        # per-landmark confidence floor
    min_core_visibility: float = 0.6   # mean over shoulders + hips, per frame
    min_body_height: float = 0.3       # fraction of frame height
    torso_tolerance: float = 0.35      # reject frame if torso differs >35% from median
    bone_tolerance: float = 1.8        # drop distal joint if bone > 1.8x its median
    spike_factor: float = 0.35         # spike = deviation > 0.35 x torso from neighbours' line
    max_gap: int = 6                   # interpolate gaps up to this many frames (0.25 s @ 24 fps)
    max_hold: int = 3                  # hold at sequence edges up to this many frames
    smooth_sigma: float = 1.0          # Gaussian sigma in frames (0 = off)


@dataclass
class PoseStats:
    frames: int = 0
    detected: int = 0
    rejected_frames: int = 0
    dropped_landmarks: int = 0
    swaps_fixed: int = 0
    spikes_removed: int = 0
    bones_rejected: int = 0
    interpolated_points: int = 0
    held_points: int = 0
    frames_status: dict = field(default_factory=dict)


def _valid(a: np.ndarray) -> np.ndarray:
    return ~np.isnan(a[..., 0])


def _mean_valid(points: np.ndarray) -> np.ndarray | None:
    ok = ~np.isnan(points[:, 0])
    return points[ok, :2].mean(axis=0) if ok.any() else None


def _torso(frame: np.ndarray) -> float:
    sh = _mean_valid(frame[[IDX["left_shoulder"], IDX["right_shoulder"]]])
    hp = _mean_valid(frame[[IDX["left_hip"], IDX["right_hip"]]])
    return float(np.linalg.norm(sh - hp)) if sh is not None and hp is not None else np.nan


def process_pose(raw: np.ndarray, opt: PoseOptions | None = None) -> tuple[np.ndarray, list[str], PoseStats]:
    opt = opt or PoseOptions()
    a = raw.astype(np.float64).copy()
    F, L, _ = a.shape
    st = PoseStats(frames=F)
    st.detected = int(_valid(a).any(axis=1).sum())
    core = [IDX["left_shoulder"], IDX["right_shoulder"], IDX["left_hip"], IDX["right_hip"]]

    # 1. Frame-level plausibility (before per-landmark dropping).
    for t in range(F):
        if not _valid(a[t]).any():
            continue
        ys = a[t, _valid(a[t]), 1]
        core_v = a[t, core, 2]
        core_vis = core_v[~np.isnan(core_v)].mean() if (~np.isnan(core_v)).any() else 0.0
        if ys.max() - ys.min() < opt.min_body_height or not (core_vis >= opt.min_core_visibility):
            a[t] = np.nan
            st.rejected_frames += 1

    # 2. Per-landmark confidence: drop, never guess.
    low = _valid(a) & (a[..., 2] < opt.min_visibility)
    st.dropped_landmarks = int(low.sum())
    a[low] = np.nan

    # 3. Torso-size consistency (catches a different "person" or a bad fit).
    torsos = np.array([_torso(a[t]) for t in range(F)])
    med_torso = float(np.nanmedian(torsos)) if np.isfinite(torsos).any() else np.nan
    if np.isfinite(med_torso):
        bad = np.isfinite(torsos) & (np.abs(torsos - med_torso) > opt.torso_tolerance * med_torso)
        st.rejected_frames += int(bad.sum())
        a[bad] = np.nan
    scale = med_torso if np.isfinite(med_torso) else 0.2

    # 4. Left/right swap correction against the last good pose.
    prev = None
    for t in range(F):
        cur = a[t]
        if _valid(cur).sum() < 4:
            continue
        if prev is not None:
            sw = cur.copy()
            for l, r in LR_PAIRS:
                sw[[l, r]] = cur[[r, l]]
            both = _valid(cur) & _valid(prev)
            both_sw = _valid(sw) & _valid(prev)
            if both.sum() >= 4 and both_sw.sum() >= 4:
                d_keep = np.nanmean(np.linalg.norm(cur[both, :2] - prev[both, :2], axis=1))
                d_swap = np.nanmean(np.linalg.norm(sw[both_sw, :2] - prev[both_sw, :2], axis=1))
                if d_swap < 0.5 * d_keep:
                    a[t] = sw
                    st.swaps_fixed += 1
        prev = a[t]

    # 5. Bone-length sanity: drop the distal joint of an over-long bone.
    for p, c in BONES:
        i, j = IDX[p], IDX[c]
        lens = np.linalg.norm(a[:, i, :2] - a[:, j, :2], axis=1)
        if np.isfinite(lens).sum() < 3:
            continue
        med = np.nanmedian(lens)
        bad = np.isfinite(lens) & (lens > opt.bone_tolerance * med)
        st.bones_rejected += int(bad.sum())
        a[bad, j] = np.nan

    # 6. Spike removal: a point far off the line between its neighbours,
    #    when the neighbours themselves agree (so fast motion survives).
    for l in range(L):
        for t in range(1, F - 1):
            p, n, c = a[t - 1, l, :2], a[t + 1, l, :2], a[t, l, :2]
            if np.isnan(p).any() or np.isnan(n).any() or np.isnan(c).any():
                continue
            dev = np.linalg.norm(c - (p + n) / 2)
            if dev > opt.spike_factor * scale and dev > np.linalg.norm(n - p):
                a[t, l] = np.nan
                st.spikes_removed += 1

    # 7. Gap filling per landmark.
    status = np.full((F, L), MISSING, dtype=object)
    status[_valid(a)] = DETECTED
    for l in range(L):
        ok = np.flatnonzero(_valid(a[:, l]))
        if ok.size == 0:
            continue
        for k in range(ok.size - 1):  # interior gaps
            t0, t1 = ok[k], ok[k + 1]
            gap = t1 - t0 - 1
            if 0 < gap <= opt.max_gap:
                for t in range(t0 + 1, t1):
                    w = (t - t0) / (t1 - t0)
                    a[t, l, :2] = (1 - w) * a[t0, l, :2] + w * a[t1, l, :2]
                    a[t, l, 2] = min(a[t0, l, 2], a[t1, l, 2])
                    status[t, l] = INTERPOLATED
                    st.interpolated_points += 1
        # Hold = keep the PREVIOUS valid position for a few frames after a
        # landmark is lost (any gap too long to interpolate, or the end).
        for k in range(ok.size):
            t0 = ok[k]
            t_next = ok[k + 1] if k + 1 < ok.size else F
            if t_next - t0 - 1 > opt.max_gap or k + 1 == ok.size:
                for t in range(t0 + 1, min(t_next, t0 + 1 + opt.max_hold)):
                    a[t, l] = a[t0, l]; status[t, l] = HELD; st.held_points += 1
        # Back-fill only at the very start of the sequence (nothing earlier
        # to hold); mid-sequence first appearances are never back-filled.
        if ok[0] <= opt.max_hold:
            for t in range(0, ok[0]):
                a[t, l] = a[ok[0], l]; status[t, l] = HELD; st.held_points += 1

    # 8. Zero-phase Gaussian smoothing within contiguous valid runs.
    if opt.smooth_sigma > 0:
        r = max(1, int(round(2 * opt.smooth_sigma)))
        k = np.exp(-0.5 * (np.arange(-r, r + 1) / opt.smooth_sigma) ** 2)
        for l in range(L):
            v = _valid(a[:, l])
            t = 0
            while t < F:
                if not v[t]:
                    t += 1
                    continue
                s = t
                while t < F and v[t]:
                    t += 1
                seg = a[s:t, l, :2].copy()
                for i in range(seg.shape[0]):
                    lo, hi = max(0, i - r), min(seg.shape[0], i + r + 1)
                    w = k[(lo - i + r):(hi - i + r)]
                    a[s + i, l, :2] = (seg[lo:hi] * w[:, None]).sum(axis=0) / w.sum()

    # Frame-level status: the "worst" landmark source in the frame.
    frame_status = []
    for t in range(F):
        s = set(status[t])
        if s == {MISSING}:
            frame_status.append(MISSING)
        elif DETECTED in s and not (s & {INTERPOLATED, HELD}):
            frame_status.append(DETECTED)
        elif HELD in s:
            frame_status.append(HELD)
        else:
            frame_status.append(INTERPOLATED if INTERPOLATED in s else DETECTED)
    for s in (DETECTED, INTERPOLATED, HELD, MISSING):
        st.frames_status[s] = frame_status.count(s)
    return a, frame_status, st


def to_json_frames(a: np.ndarray) -> list:
    """frames[i] = null | [[x, y, v] | null, …] (null landmark = not trusted)."""
    out = []
    for t in range(a.shape[0]):
        if not _valid(a[t]).any():
            out.append(None)
            continue
        out.append([None if np.isnan(p[0]) else [round(float(p[0]), 4), round(float(p[1]), 4), round(float(p[2]), 3)] for p in a[t]])
    return out
