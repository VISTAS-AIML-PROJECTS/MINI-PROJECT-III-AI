"""
Remove drawn-in website text (the black headline) that segmentation kept
next to the player in frames taken from the reference video.

The text is near-black, but so is the helmet's shading, so colour alone
can't separate them. Position can: the player's legitimate near-black parts
sit at known body points (helmet at the head, gloves at the wrists, shoes at
the ankles). Near-black pixels far from all of those are text and are made
transparent; dark pixels enclosed by the player (e.g. bat stickers) are
restored.

Uses the per-frame landmarks in pose.json built from these same frames.

  python frontend/scripts/remove_baked_text.py --frames <framed rgba dir> \
      --pose <pose.json> --out <dir>
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
import numpy as np

ANCHORS = {  # landmark -> radius as a fraction of body height
    "nose": 0.22,  # whole helmet, including its top
    "left_wrist": 0.09, "right_wrist": 0.09,
    "left_ankle": 0.08, "right_ankle": 0.08,
}
# Legs are protected along their length (dark pad edges / straps).
LIMBS = [("left_hip", "left_knee"), ("left_knee", "left_ankle"),
         ("right_hip", "right_knee"), ("right_knee", "right_ankle")]
LIMB_HALF_WIDTH = 0.08


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--frames", required=True, type=Path)
    ap.add_argument("--pose", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--dark", type=int, default=45, help="V threshold for near-black text pixels")
    args = ap.parse_args()

    pose = json.loads(args.pose.read_text(encoding="utf-8"))
    names = pose["landmarks"]
    frames = sorted(args.frames.glob("frame_*.png"))
    if len(frames) != len(pose["frames"]):
        raise SystemExit("pose.json does not match the frame count")
    args.out.mkdir(parents=True, exist_ok=True)

    removed_total = 0
    for t, f in enumerate(frames):
        rgba = cv2.imread(str(f), cv2.IMREAD_UNCHANGED)
        h, w = rgba.shape[:2]
        alpha = rgba[:, :, 3]
        lm = pose["frames"][t]
        if lm is None:
            cv2.imwrite(str(args.out / f.name), rgba)
            continue
        pts = {n: p for n, p in zip(names, lm) if p}
        ys = [p[1] for p in pts.values()]
        body_h = max(0.2, max(ys) - min(ys)) * h

        allowed = np.zeros((h, w), np.uint8)
        for n, r in ANCHORS.items():
            if n in pts:
                cv2.circle(allowed, (int(pts[n][0] * w), int(pts[n][1] * h)), int(r * body_h), 1, -1)
        for a, b in LIMBS:
            if a in pts and b in pts:
                pa = (int(pts[a][0] * w), int(pts[a][1] * h))
                pb = (int(pts[b][0] * w), int(pts[b][1] * h))
                cv2.line(allowed, pa, pb, 1, thickness=max(1, int(2 * LIMB_HALF_WIDTH * body_h)))

        hsv = cv2.cvtColor(rgba[:, :, :3], cv2.COLOR_BGR2HSV)
        dark = (alpha > 0) & (hsv[..., 2] < args.dark)
        text = (dark & (allowed == 0)).astype(np.uint8)
        # Include each glyph's anti-aliased edge.
        text = cv2.dilate(text, np.ones((3, 3), np.uint8), iterations=2) & (alpha > 0) & (hsv[..., 1] < 255) & (allowed == 0)
        text = text.astype(np.uint8)

        # Restore enclosed dark areas (stickers inside the bat, logos on kit).
        n, lab, st, _ = cv2.connectedComponentsWithStats(text)
        keep_alpha = (alpha > 0) & (text == 0)
        for i in range(1, n):
            comp = lab == i
            ring = (cv2.dilate(comp.astype(np.uint8), np.ones((7, 7), np.uint8)) > 0) & ~comp
            if ring.any() and keep_alpha[ring].mean() > 0.85:
                text[comp] = 0

        removed = int(text.sum())
        removed_total += removed
        alpha = alpha.copy()
        alpha[text > 0] = 0

        # Drop specks left floating after the cut.
        n, lab, st, _ = cv2.connectedComponentsWithStats((alpha > 24).astype(np.uint8))
        if n > 2:
            main_i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
            near_main = cv2.dilate((lab == main_i).astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
            for i in range(1, n):
                if i != main_i and st[i, cv2.CC_STAT_AREA] < 1500 and not (near_main & (lab == i)).any():
                    alpha[lab == i] = 0

        rgba[:, :, 3] = alpha
        cv2.imwrite(str(args.out / f.name), rgba)
    print(f"{len(frames)} frames, text pixels removed: {removed_total}")


if __name__ == "__main__":
    main()
