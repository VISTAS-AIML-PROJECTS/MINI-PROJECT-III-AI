"""
Build the homepage hero assets from the CLEAN player render.

    clean render (video or PNG sequence, ideally with alpha)
        -> public/animations/cricket-hero/frames/frame_000001.webp …
        -> public/animations/cricket-hero/pose.json   (MediaPipe landmarks)
        -> public/animations/cricket-hero/manifest.json

Pose detection uses the project's existing backend detector
(backend/app/vision/pose_detector.py -> MediaPipe Pose) so the website's
connector lines start from real, detected body positions.

Run with the backend virtualenv (it has mediapipe + opencv):

    backend/venv/Scripts/python.exe frontend/scripts/build_hero_assets.py \
        --input path/to/clean_render.mov  [--out frontend/public/animations/cricket-hero]

Only feed this the clean render (player, bat, ball, shadow). Do not use
the reference video that has website UI drawn into it.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend"))

import cv2  # noqa: E402
import numpy as np  # noqa: E402

from app.vision.pose_detector import PoseDetector  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
from hero_pose import BONES as LIMB_BONES, IDX, NAMES, PoseOptions, process_pose, to_json_frames  # noqa: E402

QA_BONES = [("left_shoulder", "right_shoulder"), ("left_shoulder", "left_hip"), ("right_shoulder", "right_hip"),
            ("left_hip", "right_hip"), ("nose", "left_shoulder"), ("nose", "right_shoulder"), *LIMB_BONES]

# MediaPipe Pose landmark ids we expose to the website.
LANDMARKS = {
    "nose": 0,
    "left_shoulder": 11, "right_shoulder": 12,
    "left_elbow": 13, "right_elbow": 14,
    "left_wrist": 15, "right_wrist": 16,
    "left_hip": 23, "right_hip": 24,
    "left_knee": 25, "right_knee": 26,
    "left_ankle": 27, "right_ankle": 28,
}
# Background used only for detection when frames have transparency.
DETECTION_BG = (236, 243, 247)  # BGR of #f7f3ec


def source_fps(src: Path) -> float | None:
    if src.is_dir():
        return None
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=r_frame_rate",
                          "-of", "csv=p=0", str(src)], capture_output=True, text=True).stdout.strip()
    try:
        num, den = out.split("/")
        return float(num) / float(den)
    except ValueError:
        return None


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def extract_frames(src: Path, work: Path, fps: float | None) -> list[Path]:
    """Decode the source into lossless RGBA PNGs (keeps alpha if present)."""
    work.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        files = sorted(p for p in src.iterdir() if p.suffix.lower() in {".png", ".webp", ".tif", ".tiff"})
        for i, f in enumerate(files, 1):
            shutil.copy(f, work / f"frame_{i:06d}{f.suffix.lower()}")
    else:
        vf = ["-vf", f"fps={fps}"] if fps else []
        run(["ffmpeg", "-v", "error", "-y", "-i", str(src), *vf, "-pix_fmt", "rgba",
             str(work / "frame_%06d.png")])
    return sorted(work.iterdir())


def to_webp(frames: list[Path], out_dir: Path, quality: int) -> tuple[int, int, bool]:
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("frame_*.webp"):
        old.unlink()
    has_alpha = False
    w = h = 0
    for i, f in enumerate(frames, 1):
        img = cv2.imread(str(f), cv2.IMREAD_UNCHANGED)
        h, w = img.shape[:2]
        if img.ndim == 3 and img.shape[2] == 4 and img[:, :, 3].min() < 255:
            has_alpha = True
        run(["ffmpeg", "-v", "error", "-y", "-i", str(f), "-c:v", "libwebp",
             "-quality", str(quality), "-compression_level", "6",
             *(["-pix_fmt", "yuva420p"] if has_alpha else []),
             str(out_dir / f"frame_{i:06d}.webp")])
    return w, h, has_alpha


def detect_raw(frames: list[Path]) -> np.ndarray:
    """Independent detection on every frame -> raw[F, L, 3], NaN = nothing found."""
    detector = PoseDetector()  # project's detector + MediaPipe settings
    raw = np.full((len(frames), len(LANDMARKS), 3), np.nan)
    for t, f in enumerate(frames):
        img = composite(cv2.imread(str(f), cv2.IMREAD_UNCHANGED))
        result = detector.pose.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        if result.pose_landmarks:
            lm = result.pose_landmarks.landmark
            raw[t] = [[lm[i].x, lm[i].y, lm[i].visibility] for i in LANDMARKS.values()]
    return raw


def composite(img: np.ndarray) -> np.ndarray:
    """Flatten transparent frames onto the page cream (detection / QA only)."""
    if img.ndim == 3 and img.shape[2] == 4:
        alpha = img[:, :, 3:4].astype(np.float32) / 255.0
        bg = np.full_like(img[:, :, :3], DETECTION_BG, dtype=np.uint8)
        return (img[:, :, :3] * alpha + bg * (1 - alpha)).astype(np.uint8)
    return img


# QA colours (BGR): detected = pitch green, interpolated = amber, held = grey.
QA_COLOR = {"detected": (62, 90, 27), "interpolated": (31, 114, 163), "held": (150, 150, 150)}


def write_qa_video(frames: list[Path], clean: np.ndarray, status: list[str], out: Path, fps: float) -> None:
    """Final (post-processed) skeleton + bat path drawn over every frame."""
    out.parent.mkdir(parents=True, exist_ok=True)
    first = composite(cv2.imread(str(frames[0]), cv2.IMREAD_UNCHANGED))
    h, w = first.shape[:2]
    vw = cv2.VideoWriter(str(out), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    trail = []
    lw, rw = IDX["left_wrist"], IDX["right_wrist"]
    for t, f in enumerate(frames):
        img = composite(cv2.imread(str(f), cv2.IMREAD_UNCHANGED)).copy()
        pts = clean[t]

        def P(i):
            return (int(pts[i, 0] * w), int(pts[i, 1] * h))

        def ok(i):
            return not np.isnan(pts[i, 0])

        color = QA_COLOR.get(status[t], (0, 0, 255))
        for a, b in QA_BONES:
            if ok(IDX[a]) and ok(IDX[b]):
                cv2.line(img, P(IDX[a]), P(IDX[b]), color, 3, cv2.LINE_AA)
        for i in range(len(pts)):
            if ok(i):
                cv2.circle(img, P(i), 6, (255, 255, 255), -1, cv2.LINE_AA)
                cv2.circle(img, P(i), 6, color, 2, cv2.LINE_AA)
        trail.append(((P(lw)[0] + P(rw)[0]) // 2, (P(lw)[1] + P(rw)[1]) // 2) if ok(lw) and ok(rw) else None)
        for p0, p1 in zip(trail, trail[1:]):
            if p0 and p1:  # bat path, broken at gaps
                cv2.line(img, p0, p1, (43, 138, 192), 3, cv2.LINE_AA)
        cv2.putText(img, f"{t + 1:03d} {status[t]}", (16, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (20, 20, 20), 2, cv2.LINE_AA)
        vw.write(img)
    vw.release()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", required=True, type=Path, help="clean render: video file or folder of PNG frames")
    ap.add_argument("--out", type=Path, default=ROOT / "frontend/public/animations/cricket-hero")
    ap.add_argument("--fps", type=float, default=None, help="resample video to this fps (default: source fps)")
    ap.add_argument("--quality", type=int, default=82, help="WebP quality (default 82)")
    ap.add_argument("--smoothing", type=float, default=1.0,
                    help="zero-lag Gaussian smoothing sigma in frames (default 1.0, 0 = off)")
    ap.add_argument("--min-body-height", type=float, default=0.3,
                    help="discard detections shorter than this fraction of frame height (default 0.3)")
    ap.add_argument("--min-visibility", type=float, default=0.5,
                    help="drop landmarks below this MediaPipe visibility (default 0.5)")
    ap.add_argument("--max-gap", type=int, default=6, help="interpolate gaps up to N frames (default 6)")
    ap.add_argument("--max-hold", type=int, default=3, help="hold pose up to N frames at the ends (default 3)")
    ap.add_argument("--qa", type=Path, default=None,
                    help="also write a QA video with the final skeleton drawn on every frame")
    args = ap.parse_args()
    opts = PoseOptions(
        min_visibility=args.min_visibility, min_body_height=args.min_body_height,
        max_gap=args.max_gap, max_hold=args.max_hold, smooth_sigma=args.smoothing,
    )

    with tempfile.TemporaryDirectory() as tmp:
        frames = extract_frames(args.input, Path(tmp) / "src", args.fps)
        if not frames:
            sys.exit("No frames found in input.")
        print(f"{len(frames)} frames decoded")
        width, height, alpha = to_webp(frames, args.out / "frames", args.quality)
        print(f"WebP frames written ({width}x{height}, alpha={alpha})")
        raw = detect_raw(frames)
        clean, status, stats = process_pose(raw, opts)
        if args.qa:
            fps = args.fps or source_fps(args.input) or 24
            write_qa_video(frames, clean, status, args.qa, fps)
            print(f"QA video -> {args.qa}")

    pose = to_json_frames(clean)
    detected = sum(x != "missing" for x in status)
    (args.out / "pose.json").write_text(json.dumps({
        "landmarks": NAMES,
        "format": "frames[i] = null | [[x, y, visibility] | null per landmark]; normalised 0-1 to the frame; "
                  "null landmark = not trusted (never drawn)",
        "status": status,
        "frames": pose,
    }, separators=(",", ":")), encoding="utf-8")
    print(
        f"pose: raw detections {stats.detected}/{stats.frames}, rejected frames {stats.rejected_frames}, "
        f"low-confidence landmarks dropped {stats.dropped_landmarks}, swaps fixed {stats.swaps_fixed}, "
        f"spikes removed {stats.spikes_removed}, bone rejects {stats.bones_rejected}"
    )
    print(f"pose: per-frame status {stats.frames_status} "
          f"(interpolated points {stats.interpolated_points}, held points {stats.held_points})")

    manifest = {
        "frameCount": len(pose),
        "width": width,
        "height": height,
        "alpha": alpha,
        "framePattern": "frames/frame_{n}.webp",
        "pose": "pose.json",
        "poseFrames": detected,
        "poseStatus": stats.frames_status,
        "source": args.input.name,
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"manifest -> {args.out / 'manifest.json'}")


if __name__ == "__main__":
    main()
