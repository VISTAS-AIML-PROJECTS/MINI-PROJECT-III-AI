"""
Extract the batsman from the reference hero video frames (which have the
website UI drawn in) into transparent RGBA frames.

  reference frame
    -> person mask (rembg u2net_human_seg)          body, no UI text
    + general mask (rembg isnet-general-use) parts that touch the body
                                                     brings back the bat
    - overlay colours (purple / mint-green lines)   drawn-on graphics
        on the body  -> repainted (inpaint), kept opaque
        off the body -> made transparent
    -> RGBA PNG per frame

Run with the throwaway segmentation env (rembg + opencv), e.g.
  %LOCALAPPDATA%\\cai-seg\\Scripts\\python.exe frontend/scripts/extract_player.py \\
      --src frontend/assets-src/reference-video-ui-frames/png --out <dir>

Then feed <dir> to build_hero_assets.py like any clean render.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
from rembg import new_session, remove


def alpha_of(session, rgb: np.ndarray) -> np.ndarray:
    return np.array(remove(rgb, session=session, only_mask=True))


def overlay_colour_mask(bgr: np.ndarray, body: np.ndarray) -> np.ndarray:
    """Purple / mint-green UI strokes (colours not present on the kit).
    Strong strokes anywhere; faint (pale lavender / mint) strokes only on the
    white kit, where they show as ghost lines."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0].astype(int), hsv[..., 1].astype(int), hsv[..., 2].astype(int)
    purple_h = (h >= 120) & (h <= 162)
    green_h = (h >= 50) & (h <= 92)
    strong = (purple_h & (s >= 60) & (v >= 90)) | (green_h & (s >= 80) & (v >= 110))
    faint = (body > 0) & (v >= 150) & ((purple_h & (s >= 18)) | (green_h & (s >= 28)))
    m = (strong | faint).astype(np.uint8) * 255
    m = cv2.dilate(m, np.ones((3, 3), np.uint8), iterations=2)
    # Joint markers are rings: fill small closed outlines so the white dot
    # inside is repainted too.
    contours, _ = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    for c in contours:
        if cv2.contourArea(c) < 900:
            cv2.drawContours(m, [c], -1, 255, thickness=cv2.FILLED)
    return m


def static_ui_mask(files: list[Path], share: float = 0.6) -> np.ndarray:
    """Pixels that are dark & colourless in the same place in most frames:
    the website text drawn into the video (it never moves; the player does)."""
    count = None
    for f in files:
        hsv = cv2.cvtColor(cv2.imread(str(f)), cv2.COLOR_BGR2HSV)
        dark = (hsv[..., 2] < 110) & (hsv[..., 1] < 80)
        count = dark.astype(np.uint16) if count is None else count + dark
    static = (count >= share * len(files)).astype(np.uint8)
    return cv2.dilate(static, np.ones((3, 3), np.uint8), iterations=2) > 0


def extract(bgr: np.ndarray, human, general, static_ui: np.ndarray | None = None) -> np.ndarray:
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    a_human = alpha_of(human, rgb)
    # general=None: person model only (clean renders where it keeps the bat).
    a_general = alpha_of(general, rgb) if general is not None else np.zeros_like(a_human)

    body = (a_human > 127).astype(np.uint8)
    near = cv2.dilate(body, np.ones((9, 9), np.uint8), iterations=2)
    # Keep general-mask components that touch the body (bat, gloves, dust).
    n, labels = cv2.connectedComponents((a_general > 127).astype(np.uint8))
    keep = np.zeros_like(body)
    touching = np.unique(labels[(near > 0) & (labels > 0)])
    for lab in touching:
        keep[labels == lab] = 1
    # Extra (non-person) parts: drop thin line-like pieces, near-white flat
    # areas (floor disc, label boxes) and lavender-tinted label boxes. The
    # bat's wood always carries some warmth, so it survives even when pale.
    # Pixels hugging the body are kept so pad/shirt edges survive.
    extra = ((keep > 0) & (a_human <= 127)).astype(np.uint8)
    extra = cv2.morphologyEx(extra, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0].astype(int), hsv[..., 1].astype(int), hsv[..., 2].astype(int)
    flat_white = (s < 16) & (v > 170)          # floor disc, label boxes, grey "01"
    lavender = (h >= 115) & (h <= 165) & (s >= 6) & (v > 195)
    dark_text = (v < 95) & (s < 70)            # black headline letters
    hug = cv2.dilate(body, np.ones((3, 3), np.uint8), iterations=3) > 0
    drop = (flat_white | lavender | dark_text) & ~hug
    kept = (extra > 0) & ~drop
    # Re-fill small holes the dark rule punched INSIDE kept parts (bat
    # stickers); open areas next to the bat (headline letters) stay removed.
    holes = ((extra > 0) & drop).astype(np.uint8)
    n_h, lab_h, st_h, _ = cv2.connectedComponentsWithStats(holes)
    ring = np.ones((5, 5), np.uint8)
    for i in range(1, n_h):
        if st_h[i, cv2.CC_STAT_AREA] > 600:
            continue
        comp = lab_h == i
        border = (cv2.dilate(comp.astype(np.uint8), ring) > 0) & ~comp
        if border.any() and kept[border].mean() > 0.9:  # enclosed by bat
            kept |= comp
    extra = kept
    alpha = np.maximum(a_human, (a_general * extra).astype(np.uint8))

    # Drawn overlay strokes: repaint where they cross the body, drop elsewhere.
    strokes = overlay_colour_mask(bgr, body)
    core = cv2.erode(body, np.ones((5, 5), np.uint8), iterations=1)
    on_body = (strokes > 0) & (core > 0)
    off_body = (strokes > 0) & (core == 0)
    clean = cv2.inpaint(bgr, on_body.astype(np.uint8) * 255, 5, cv2.INPAINT_TELEA)
    alpha[off_body] = 0

    # Static website text: drop where it is still showing (dark) this frame;
    # when the bat/body passes in front of it, those pixels aren't dark.
    if static_ui is not None:
        hsv_now = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        dark_now = (hsv_now[..., 2] < 140) & (hsv_now[..., 1] < 80)
        alpha[static_ui & dark_now] = 0

    # Remove specks left after cutting strokes away; keep the main figure.
    n, labels, stats, _ = cv2.connectedComponentsWithStats((alpha > 40).astype(np.uint8))
    if n > 1:
        main = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        big = stats[:, cv2.CC_STAT_AREA] > 0.004 * alpha.size
        allowed = np.isin(labels, [i for i in range(1, n) if i == main or (big[i] and touching_main(labels, i, main))])
        alpha[~allowed] = 0

    alpha = drop_floor_strips(alpha, body)
    clean, alpha = tighten_matte(clean, alpha)
    return np.dstack([clean, alpha])


def drop_floor_strips(alpha: np.ndarray, body: np.ndarray) -> np.ndarray:
    """Remove floor seams / ground strips kept next to the feet: anything in
    the bottom band of the body that spreads sideways beyond the feet."""
    ys, xs = np.nonzero(body)
    if ys.size == 0:
        return alpha
    bottom = ys.max()
    height = bottom - ys.min() + 1
    band_top = int(bottom - 0.06 * height)
    feet_cols = np.zeros(alpha.shape[1], bool)
    feet_cols[np.unique(xs[ys >= band_top])] = True
    near_feet = cv2.dilate(feet_cols.astype(np.uint8)[None, :], np.ones((1, 41), np.uint8))[0] > 0
    out = alpha.copy()
    out[band_top:, ~near_feet] = 0
    return out


def tighten_matte(bgr: np.ndarray, alpha: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Firm up soft edges (drops background haze) and remove colour spill
    from the studio backdrop by recolouring edge pixels from the interior."""
    a = alpha.astype(np.float32) / 255.0
    a = np.clip((a - 0.25) / 0.6, 0, 1)
    a8 = (a * 255).astype(np.uint8)
    interior = (a8 > 242).astype(np.uint8)
    edge = ((a8 > 0) & (interior == 0)).astype(np.uint8)
    if edge.any() and interior.any():
        # Recolour edges from nearby interior colour (inpaint over edge+outside).
        fill_mask = (interior == 0).astype(np.uint8) * 255
        recolored = cv2.inpaint(bgr, fill_mask, 3, cv2.INPAINT_TELEA)
        e = edge.astype(bool)
        bgr = bgr.copy()
        bgr[e] = (0.35 * bgr[e] + 0.65 * recolored[e]).astype(np.uint8)
    return bgr, a8


def touching_main(labels: np.ndarray, i: int, main: int) -> bool:
    a = cv2.dilate((labels == main).astype(np.uint8), np.ones((15, 15), np.uint8))
    return bool(((labels == i) & (a > 0)).any())


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--only", type=int, nargs="*", help="process only these 1-based frame numbers")
    ap.add_argument("--human-only", action="store_true", help="person model only (no general-model additions)")
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    human = new_session("u2net_human_seg")
    general = None if args.human_only else new_session("isnet-general-use")
    files = sorted(args.src.glob("frame_*.png"))
    static_ui = static_ui_mask(files)  # always from the full clip
    print(f"static UI pixels: {int(static_ui.sum())}", flush=True)
    for i, f in enumerate(files, 1):
        if args.only and i not in args.only:
            continue
        rgba = extract(cv2.imread(str(f)), human, general, static_ui)
        cv2.imwrite(str(args.out / f.name), rgba)
        if i % 16 == 0 or args.only:
            print(f"{i}/{len(files)}", flush=True)


if __name__ == "__main__":
    main()
