"""Self-contained checks for hero_pose.process_pose (run: python test_hero_pose.py)."""

import numpy as np

from hero_pose import IDX, NAMES, HELD, INTERPOLATED, MISSING, PoseOptions, process_pose

F, L = 96, len(NAMES)


def synthetic():
    """A batter-sized skeleton drifting right, wrists sweeping a fast arc."""
    base = {
        "nose": (0.50, 0.12), "left_shoulder": (0.45, 0.25), "right_shoulder": (0.55, 0.25),
        "left_elbow": (0.42, 0.37), "right_elbow": (0.58, 0.37), "left_wrist": (0.42, 0.48),
        "right_wrist": (0.58, 0.48), "left_hip": (0.46, 0.52), "right_hip": (0.54, 0.52),
        "left_knee": (0.45, 0.70), "right_knee": (0.55, 0.70), "left_ankle": (0.44, 0.88),
        "right_ankle": (0.56, 0.88),
    }
    a = np.zeros((F, L, 3))
    for t in range(F):
        drift = 0.001 * t
        ang = np.pi * t / F * 1.6  # fast swing: wrists travel a big arc
        for n, (x, y) in base.items():
            a[t, IDX[n]] = (x + drift, y, 0.95)
        for w in ("left_wrist", "right_wrist"):
            a[t, IDX[w], 0] = 0.5 + drift + 0.22 * np.cos(ang)
            a[t, IDX[w], 1] = 0.40 - 0.18 * np.sin(ang)
        # keep elbows between shoulders and wrists so bones stay plausible
        for side in ("left", "right"):
            s, w = a[t, IDX[f"{side}_shoulder"], :2], a[t, IDX[f"{side}_wrist"], :2]
            a[t, IDX[f"{side}_elbow"], :2] = (s + w) / 2
    return a


def err(a, b, l, t):
    return float(np.linalg.norm(a[t, l, :2] - b[t, l, :2]))


def check(name, cond, detail=""):
    print(("PASS " if cond else "FAIL ") + name + (f" - {detail}" if detail else ""))
    return cond


def main():
    ok = True
    truth = synthetic()
    rw = IDX["right_wrist"]

    clean, status, st = process_pose(truth.copy())
    worst = max(err(clean, truth, l, t) for t in range(2, F - 2) for l in range(L))
    ok &= check("clean fast motion survives, zero-lag smoothing", worst < 0.006 and st.spikes_removed == 0,
                f"max error {worst:.4f}, spikes removed {st.spikes_removed}")

    a = truth.copy(); a[40:43] = np.nan
    c, s, st = process_pose(a)
    ok &= check("3-frame dropout interpolated", s[41] == INTERPOLATED and err(c, truth, rw, 41) < 0.03,
                f"status {s[41]}, wrist error {err(c, truth, rw, 41):.4f}")

    a = truth.copy(); a[50:62] = np.nan
    c, s, st = process_pose(a)
    ok &= check("12-frame gap left empty (no invention)", s[55] == MISSING and np.isnan(c[55]).all())

    a = truth.copy(); a[30, rw, :2] += (0.25, 0.2)
    c, s, st = process_pose(a)
    ok &= check("one-frame wrist spike removed (spike or bone-length rule)",
                st.spikes_removed + st.bones_rejected >= 1 and err(c, truth, rw, 30) < 0.03,
                f"spikes {st.spikes_removed}, bone rejects {st.bones_rejected}, error {err(c, truth, rw, 30):.4f}")

    a = truth.copy(); a[35, IDX["nose"], :2] += (0.12, 0.0)
    c, s, st = process_pose(a)
    ok &= check("one-frame head spike removed by spike rule", st.spikes_removed >= 1 and err(c, truth, IDX["nose"], 35) < 0.02,
                f"spikes {st.spikes_removed}, error {err(c, truth, IDX['nose'], 35):.4f}")

    a = truth.copy(); a[20:, IDX["left_ankle"], 2] = 0.2  # ankle occluded for the rest
    c, s, st = process_pose(a)
    ok &= check("low-confidence landmark dropped, not guessed",
                np.isnan(c[40, IDX["left_ankle"]]).all() and not np.isnan(c[40, IDX["nose"]]).any())

    a = truth.copy(); a[10, :, :2] = a[10, :, :2] * 0.15 + 0.05  # tiny "person" elsewhere
    c, s, st = process_pose(a)
    ok &= check("tiny false detection rejected then bridged", st.rejected_frames >= 1 and err(c, truth, IDX["nose"], 10) < 0.02,
                f"rejected {st.rejected_frames}")

    a = truth.copy()
    for side_l, side_r in [("left_wrist", "right_wrist"), ("left_elbow", "right_elbow"), ("left_knee", "right_knee"),
                           ("left_ankle", "right_ankle"), ("left_hip", "right_hip"), ("left_shoulder", "right_shoulder")]:
        a[60, [IDX[side_l], IDX[side_r]]] = a[60, [IDX[side_r], IDX[side_l]]]
    c, s, st = process_pose(a)
    ok &= check("left/right swap corrected", st.swaps_fixed >= 1 and err(c, truth, rw, 60) < 0.02,
                f"swaps {st.swaps_fixed}")

    a = truth.copy(); a[:2] = np.nan
    c, s, st = process_pose(a)
    ok &= check("short leading gap held", s[0] == HELD and s[1] == HELD)

    a = truth.copy(); a[:30, IDX["left_ankle"]] = np.nan  # ankle first seen at frame 30
    c, s, st = process_pose(a)
    ok &= check("mid-sequence first appearance is not back-filled", np.isnan(c[28, IDX["left_ankle"]]).all())

    a = truth.copy(); a[50:62, rw] = np.nan  # wrist lost for 12 frames
    c, s, st = process_pose(a)
    held_ok = not np.isnan(c[51, rw]).any() and np.isnan(c[56, rw]).all()
    ok &= check("lost landmark: previous position held briefly, then dropped", held_ok)

    a = truth.copy(); a[:, :, 2] = 0.3
    c, s, st = process_pose(a, PoseOptions())
    ok &= check("all low confidence -> nothing drawn", all(x == MISSING for x in s))

    print("\nALL PASSED" if ok else "\nSOME CHECKS FAILED")
    return ok


if __name__ == "__main__":
    raise SystemExit(0 if main() else 1)
