"""
Frame the extracted player for the homepage hero stage.

Crops every RGBA frame to ONE shared box (the union of the player across the
whole clip, so he never jumps between frames), with side/top margins and a
bottom band so the feet land on the hero's ground line (drawn 11% above the
stage bottom; the canvas anchors frames to the bottom).

  python frontend/scripts/frame_player.py --src <rgba dir> --out <dir>
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np

GROUND_LINE = 0.11  # HeroBackdrop ground line: bottom-[11%] of the stage


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--margin", type=float, default=0.06, help="side/top margin as a fraction of player height")
    ap.add_argument("--alpha-threshold", type=int, default=24)
    args = ap.parse_args()

    files = sorted(args.src.glob("frame_*.png"))
    x0 = y0 = 10**9
    x1 = y1 = -1
    for f in files:
        a = cv2.imread(str(f), cv2.IMREAD_UNCHANGED)[:, :, 3]
        ys, xs = np.nonzero(a > args.alpha_threshold)
        if xs.size:
            x0, x1 = min(x0, xs.min()), max(x1, xs.max())
            y0, y1 = min(y0, ys.min()), max(y1, ys.max())
    if x1 < 0:
        raise SystemExit("No player pixels found.")

    h = y1 - y0 + 1
    m = int(round(args.margin * h))
    # Bottom band so feet (y1) sit at (1 - GROUND_LINE) of the output height.
    content_h = h + m
    out_h = int(round(content_h / (1 - GROUND_LINE)))
    bottom_pad = out_h - content_h
    print(f"player union box x[{x0},{x1}] y[{y0},{y1}] -> output {x1 - x0 + 1 + 2 * m}x{out_h}")

    args.out.mkdir(parents=True, exist_ok=True)
    for f in files:
        img = cv2.imread(str(f), cv2.IMREAD_UNCHANGED)
        H, W = img.shape[:2]
        # Pad the source so the crop box can extend past its edges.
        P = m + bottom_pad
        src = cv2.copyMakeBorder(img, P, P, P, P, cv2.BORDER_CONSTANT, value=(0, 0, 0, 0))
        crop = src[y0 - m + P: y1 + 1 + bottom_pad + P, x0 - m + P: x1 + 1 + m + P]
        cv2.imwrite(str(args.out / f.name), crop)
    print(f"{len(files)} frames -> {args.out}")


if __name__ == "__main__":
    main()
