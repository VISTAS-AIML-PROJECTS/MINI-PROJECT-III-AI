export const DURATION = {
  fast: 0.2,
  base: 0.3,
  slow: 0.45,
};

export const EASE = {
  standard: [0.4, 0, 0.2, 1],
};
