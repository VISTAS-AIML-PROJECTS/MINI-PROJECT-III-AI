import { useCallback, useId, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Search, ArrowRight } from "lucide-react";

import { getSkills } from "../services/skillsApi";
import { useResource } from "../lib/useResource";
import { titleCase } from "../lib/scoring";

import { PageHeader } from "../ui/Layout";
import { Tabs, TabPanel } from "../ui/Tabs";
import { Input, Segmented } from "../ui/Field";
import { Badge } from "../ui/Data";
import { PageLoading, ErrorState, EmptyState } from "../ui/States";

const CATEGORY_ORDER = ["batting", "bowling", "fielding"];
const LEVELS = ["all", "beginner", "intermediate", "advanced"];

export default function Skills() {
  const [params, setParams] = useSearchParams();
  const loader = useCallback(() => getSkills(), []);
  const { data, error, loading, reload } = useResource(loader, []);
  const [level, setLevel] = useState("all");
  const [query, setQuery] = useState("");
  const baseId = useId();
  const searchId = useId();

  const skills = useMemo(() => data || [], [data]);
  const categories = useMemo(() => {
    const present = [...new Set(skills.map((s) => s.category))];
    return [...CATEGORY_ORDER.filter((c) => present.includes(c)), ...present.filter((c) => !CATEGORY_ORDER.includes(c))];
  }, [skills]);

  const requested = params.get("category");
  const category = categories.includes(requested) ? requested : categories[0] || "batting";

  if (loading) return <PageLoading label="Loading skill library" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;

  const q = query.trim().toLowerCase();
  const shown = skills
    .filter((s) => s.category === category)
    .filter((s) => level === "all" || s.difficulty === level)
    .filter((s) => !q || s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q));

  return (
    <>
      <PageHeader
        eyebrow="Skills"
        title="Skill library"
        lede="Technique guides for every stroke, delivery and fielding skill, with coaching points, common faults and drills."
      />

      {skills.length === 0 ? (
        <EmptyState title="The skill library is empty" body="No skills have been added to the library yet." />
      ) : (
        <>
          <Tabs
            label="Skill category"
            baseId={baseId}
            value={category}
            onChange={(c) => setParams({ category: c }, { replace: true })}
            tabs={categories.map((c) => ({ value: c, label: titleCase(c), count: skills.filter((s) => s.category === c).length }))}
          />

          <TabPanel baseId={baseId} value={category} className="mt-6">
            <div className="mb-6 grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)] md:items-end">
              <div>
                <label htmlFor={searchId} className="t-label mb-1.5 block !text-ink-2">Search {category}</label>
                <div className="relative">
                  <Search size={16} aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-3" />
                  <Input id={searchId} type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. drive, yorker, catching" className="pl-9" />
                </div>
              </div>
              <Segmented
                legend="Level"
                name="level"
                value={level}
                onChange={setLevel}
                options={LEVELS.map((l) => ({ value: l, label: titleCase(l) }))}
              />
            </div>

            <p className="t-data mb-3 text-ink-3" aria-live="polite">
              {shown.length} skill{shown.length === 1 ? "" : "s"}
            </p>

            {shown.length === 0 ? (
              <EmptyState title="No skills match" body="Try a different level or search term." />
            ) : (
              <ul className="grid gap-px overflow-hidden rounded-md border border-line bg-line md:grid-cols-2">
                {shown.map((s) => (
                  <li key={s.skill_id} className="group relative flex flex-col bg-surface p-5 hover:bg-paper md:[&:nth-child(odd):last-child]:col-span-2">
                    <div className="flex items-start justify-between gap-3">
                      <h2 className="t-section text-xl">
                        <Link to={`/skills/${s.skill_id}`} className="after:absolute after:inset-0 after:content-['']">
                          {s.name}
                        </Link>
                      </h2>
                      <Badge>{s.difficulty}</Badge>
                    </div>
                    <p className="mt-2 line-clamp-2 flex-1 text-sm text-ink-2">{s.description}</p>
                    <div className="t-data mt-4 flex items-center gap-4 text-xs text-ink-3">
                      <span>{s.video_count} lesson{s.video_count === 1 ? "" : "s"}</span>
                      <span>{s.drill_count} drill{s.drill_count === 1 ? "" : "s"}</span>
                      <ArrowRight size={14} aria-hidden="true" className="ml-auto text-ink-4 group-hover:text-ink" />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </TabPanel>
        </>
      )}
    </>
  );
}
