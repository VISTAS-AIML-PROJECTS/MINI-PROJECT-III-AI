import { useEffect, useState } from "react";
import { History as HistoryIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";

import { getHistory } from "../services/historyService";
import HistoryCard from "../components/history/HistoryCard";
import SectionTitle from "../components/common/SectionTitle";
import Loader from "../components/common/Loader";
import EmptyState from "../components/common/EmptyState";

export default function History() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadHistory();
  }, []);

  async function loadHistory() {
    try {
      const data = await getHistory();
      setHistory(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <Loader label="Loading analysis history..." />;
  }

  return (
    <div className="space-y-8">
      <SectionTitle
        size="hero"
        eyebrow="Your Journey"
        title="Analysis History"
        subtitle="Review every AI analysis you've completed."
      />

      {history.length === 0 ? (
        <EmptyState
          icon={HistoryIcon}
          title="No analyses yet"
          description="Upload your first cricket video to see it appear here."
          actionLabel="Upload a Video"
          onAction={() => navigate("/upload")}
        />
      ) : (
        <div className="space-y-6">
          {history.map((analysis) => (
            <HistoryCard key={analysis.id} analysis={analysis} />
          ))}
        </div>
      )}
    </div>
  );
}
