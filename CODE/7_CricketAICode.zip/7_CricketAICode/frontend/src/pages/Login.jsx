import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { useAuth } from "../hooks/useAuth";
import { AuthFrame } from "../components/shell/Public";
import Button from "../ui/Button";
import { Field, Input, PasswordInput } from "../ui/Field";
import { InlineAlert } from "../ui/States";
import { detailText } from "../lib/errors";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    document.title = "Sign in · CricketAI";
  }, []);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function handleSubmit(e) {
    e.preventDefault();
    const next = {};
    if (!form.email.trim()) next.email = "Enter your email address.";
    else if (!EMAIL.test(form.email.trim())) next.email = "Enter a valid email address.";
    if (!form.password) next.password = "Enter your password.";
    setErrors(next);
    setSubmitError("");
    if (Object.keys(next).length) return;

    setLoading(true);
    const result = await login({ email: form.email.trim(), password: form.password });
    setLoading(false);
    if (result.success) navigate("/dashboard", { replace: true });
    else setSubmitError(detailText(result.message, "Incorrect email or password."));
  }

  return (
    <AuthFrame
      title="Sign in"
      lede="Pick up where your last session left off."
      footer={
        <>
          New to CricketAI?{" "}
          <Link to="/register" className="font-medium text-ink underline decoration-line-2 underline-offset-4 hover:decoration-ink">
            Create an account
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        {submitError && <InlineAlert>{submitError}</InlineAlert>}
        <Field label="Email" error={errors.email}>
          {(p) => <Input {...p} type="email" autoComplete="email" value={form.email} onChange={set("email")} />}
        </Field>
        <Field label="Password" error={errors.password}>
          {(p) => <PasswordInput {...p} autoComplete="current-password" value={form.password} onChange={set("password")} />}
        </Field>
        <Button type="submit" size="lg" loading={loading} className="w-full">
          {loading ? "Signing in…" : "Sign in"}
        </Button>
      </form>
    </AuthFrame>
  );
}
