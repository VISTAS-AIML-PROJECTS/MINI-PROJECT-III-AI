import { useCallback } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, MessagesSquare, Upload } from "lucide-react";

import { getSkill, MEDIA_BASE_URL } from "../services/skillsApi";
import { useResource } from "../lib/useResource";
import { titleCase } from "../lib/scoring";

import Button from "../ui/Button";
import { SectionHeader } from "../ui/Layout";
import { Badge } from "../ui/Data";
import { PageLoading, ErrorState, EmptyState } from "../ui/States";
import DrillList from "../components/practice/DrillList";
import LessonVideo from "../components/practice/LessonVideo";

export default function SkillDetail() {
  const { skillId } = useParams();
  const loader = useCallback(() => getSkill(skillId), [skillId]);
  const { data: skill, error, loading, reload } = useResource(loader, [skillId]);

  if (loading) return <PageLoading label="Loading skill" />;
  if (error) {
    return error.status === 404 ? (
      <EmptyState title="Skill not found" action={<Button to="/skills" variant="secondary">Back to library</Button>} />
    ) : (
      <ErrorState error={error} onRetry={reload} />
    );
  }

  const analysable = ["batting", "bowling"].includes(skill.category);
  let section = 0;
  const idx = () => String(++section).padStart(2, "0");

  return (
    <article>
      <Link to={`/skills?category=${skill.category}`} className="mb-4 inline-flex min-h-9 items-center gap-1.5 text-sm text-ink-2 hover:text-ink">
        <ArrowLeft size={15} aria-hidden="true" /> {titleCase(skill.category)} skills
      </Link>

      <header className="mb-8 border-b border-line pb-6">
        <div className="mb-3 flex items-center gap-2">
          <p className="t-label">{skill.category}</p>
          <Badge>{skill.difficulty}</Badge>
        </div>
        <h1 className="t-page">{skill.name}</h1>
        <p className="mt-4 max-w-3xl text-lg text-ink-2">{skill.description}</p>
        {skill.when_to_play && (
          <p className="mt-3 max-w-3xl text-ink-2">
            <span className="font-semibold text-ink">When to use it. </span>
            {skill.when_to_play}
          </p>
        )}
        <div className="mt-6 flex flex-wrap gap-2">
          {analysable && (
            <Button to={`/upload?skill=${skill.skill_id}&type=${skill.category}`} icon={Upload}>
              Record and analyse an attempt
            </Button>
          )}
          <Button to="/coach" variant="secondary" icon={MessagesSquare}>Ask your coach</Button>
        </div>
      </header>

      <div className="grid gap-10 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)] lg:gap-12">
        <div className="min-w-0">
          {skill.key_points.length > 0 && (
            <section aria-labelledby="points-h" className="mb-10">
              <SectionHeader id="points-h" index={idx()} title="Key coaching points" />
              <ol className="divide-y divide-line border-y border-line">
                {skill.key_points.map((p, i) => (
                  <li key={i} className="flex gap-4 py-3">
                    <span className="t-data pt-0.5 text-pitch">{String(i + 1).padStart(2, "0")}</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ol>
            </section>
          )}

          {skill.common_mistakes.length > 0 && (
            <section aria-labelledby="faults-h" className="mb-10">
              <SectionHeader id="faults-h" index={idx()} title="Common faults & corrections" />
              <div className="space-y-4">
                {skill.common_mistakes.map((m, i) => (
                  <div key={i} className="rounded-md border border-line bg-surface">
                    <h3 className="border-b border-line px-4 py-3 font-semibold">
                      <span className="mr-2 inline-block h-2 w-2 bg-leather align-middle" aria-hidden="true" />
                      {m.mistake}
                    </h3>
                    <dl className="grid gap-4 px-4 py-3 sm:grid-cols-2">
                      <div>
                        <dt className="t-label">Why it happens</dt>
                        <dd className="mt-1 text-sm text-ink-2">{m.why_it_happens}</dd>
                      </div>
                      <div>
                        <dt className="t-label !text-pitch">Correction</dt>
                        <dd className="mt-1 text-sm">{m.how_to_correct}</dd>
                      </div>
                    </dl>
                    {m.drill && (
                      <p className="border-t border-line px-4 py-2.5 text-sm text-ink-2">
                        <span className="t-label mr-2">Drill</span>
                        {m.drill}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}

          {skill.drills.length > 0 && (
            <section aria-labelledby="drills-h" className="mb-10">
              <SectionHeader id="drills-h" index={idx()} title="Drills" />
              <DrillList drills={skill.drills} />
            </section>
          )}
        </div>

        <aside className="space-y-8">
          <section aria-labelledby="lessons-h">
            <h2 id="lessons-h" className="t-section mb-4">Video lessons</h2>
            {skill.videos.length === 0 ? (
              <p className="rounded-md border border-dashed border-line-2 px-4 py-6 text-sm text-ink-3">No video lessons for this skill yet.</p>
            ) : (
              <ul className="space-y-5">
                {skill.videos.map((v) => (
                  <li key={v.path}>
                    <LessonVideo src={`${MEDIA_BASE_URL}/media/${v.path}`} title={v.title} type={v.type} duration={v.duration} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          {skill.related_metrics?.length > 0 && (
            <section aria-labelledby="metrics-h" className="rule-top pt-6">
              <h2 id="metrics-h" className="t-label mb-3">Measured in analysis</h2>
              <ul className="flex flex-wrap gap-2">
                {skill.related_metrics.map((m) => (
                  <li key={m} className="t-data rounded-xs border border-line bg-surface px-2 py-1 text-xs text-ink-2">
                    {m}
                  </li>
                ))}
              </ul>
            </section>
          )}
        </aside>
      </div>
    </article>
  );
}
