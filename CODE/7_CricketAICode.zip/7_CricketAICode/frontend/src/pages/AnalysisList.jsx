import { useCallback, useId, useState } from "react";
import { Upload, ScanLine } from "lucide-react";

import { getHistory } from "../services/historyService";
import { useResource } from "../lib/useResource";
import Button from "../ui/Button";
import { PageHeader } from "../ui/Layout";
import { Tabs, TabPanel } from "../ui/Tabs";
import { PageLoading, ErrorState, EmptyState } from "../ui/States";
import SessionTable from "../components/performance/SessionTable";

export default function AnalysisList() {
  const loader = useCallback(() => getHistory(), []);
  const { data, error, loading, reload } = useResource(loader, []);
  const [filter, setFilter] = useState("all");
  const baseId = useId();

  if (loading) return <PageLoading label="Loading sessions" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;

  const sessions = data || [];
  const count = (t) => sessions.filter((s) => s.analysis_type === t).length;
  const shown = filter === "all" ? sessions : sessions.filter((s) => s.analysis_type === filter);

  return (
    <>
      <PageHeader
        eyebrow="Analysis"
        title="Sessions"
        lede="Every video you've analysed. Open a session for its full technique report."
        actions={<Button to="/upload" icon={Upload}>New analysis</Button>}
      />

      {sessions.length === 0 ? (
        <EmptyState
          icon={ScanLine}
          title="No sessions analysed yet"
          body="Upload a batting or bowling clip to get your first technique report."
          action={<Button to="/upload" icon={Upload}>Analyse a video</Button>}
        />
      ) : (
        <>
          <Tabs
            label="Filter sessions by discipline"
            baseId={baseId}
            value={filter}
            onChange={setFilter}
            tabs={[
              { value: "all", label: "All", count: sessions.length },
              { value: "batting", label: "Batting", count: count("batting") },
              { value: "bowling", label: "Bowling", count: count("bowling") },
            ]}
          />
          <TabPanel baseId={baseId} value={filter} className="mt-6">
            {shown.length ? (
              <SessionTable sessions={shown} caption={`${filter === "all" ? "All" : filter} sessions`} />
            ) : (
              <EmptyState title={`No ${filter} sessions yet`} action={<Button to="/upload" variant="secondary">Analyse a {filter} clip</Button>} />
            )}
          </TabPanel>
        </>
      )}
    </>
  );
}
