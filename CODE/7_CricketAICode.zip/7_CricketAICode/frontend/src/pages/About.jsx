import { useEffect } from "react";
import Button from "../ui/Button";
import { PublicHeader, PublicFooter } from "../components/shell/Public";

const STAGES = [
  {
    title: "Pose tracking",
    body: "Your clip is processed frame by frame with MediaPipe pose estimation and OpenCV, producing body landmarks for every frame.",
  },
  {
    title: "Biomechanics evaluation",
    body: "Rule-based evaluators built from coaching standards measure joint angles, alignment, balance, sequencing and weight transfer, and score each one 0–100.",
  },
  {
    title: "Technique report",
    body: "Scores are combined into an overall technique score with strengths, areas to improve, a coaching note and corrective drills.",
  },
  {
    title: "AI coach",
    body: "Questions go to a language model (Qwen3-4B) running locally through Ollama. It answers using your report plus passages retrieved and re-ranked from cricket coaching manuals, biomechanics texts and the MCC Laws.",
  },
];

export default function About() {
  useEffect(() => {
    document.title = "How it works · CricketAI";
  }, []);

  return (
    <div className="flex min-h-dvh flex-col">
      <PublicHeader />
      <main id="content" className="mx-auto w-full max-w-[1240px] flex-1 px-4 py-14 sm:px-6 lg:px-10 lg:py-20">
        <header className="max-w-3xl border-b border-line pb-10">
          <p className="t-label">How it works</p>
          <h1 className="t-page mt-3 text-[clamp(2.5rem,1.8rem+3vw,4.5rem)]">From a phone clip to a coaching plan</h1>
          <p className="mt-6 text-lg text-ink-2">
            CricketAI turns ordinary training footage into the kind of technique breakdown usually reserved for
            academy video sessions, for batting and bowling.
          </p>
        </header>

        <ol className="mt-4 divide-y divide-line">
          {STAGES.map((s, i) => (
            <li key={s.title} className="grid gap-3 py-8 md:grid-cols-[6rem_minmax(0,4fr)_minmax(0,8fr)]">
              <span className="t-data text-pitch">0{i + 1}</span>
              <h2 className="t-section">{s.title}</h2>
              <p className="max-w-2xl text-ink-2">{s.body}</p>
            </li>
          ))}
        </ol>

        <section aria-labelledby="who-h" className="mt-10 grid gap-8 border-t border-ink pt-10 md:grid-cols-3">
          <h2 id="who-h" className="t-section md:col-span-3">Who it's for</h2>
          {[
            ["Players", "Club, college and aspiring players who want specific, measurable feedback between sessions."],
            ["Coaches", "A consistent, frame-level view of each player's action to support what you see in the nets."],
            ["Academies", "A shared record of technique and progress across a squad, session after session."],
          ].map(([t, d]) => (
            <div key={t}>
              <h3 className="t-sub text-base">{t}</h3>
              <p className="mt-2 text-sm text-ink-2">{d}</p>
            </div>
          ))}
        </section>

        <div className="mt-14">
          <Button to="/register" size="lg">Create an account</Button>
        </div>
      </main>
      <PublicFooter />
    </div>
  );
}
