import { useEffect } from "react";

import { isLoggedIn } from "../services/authService";
import LandingNav from "../components/landing/LandingNav";
import HeroSection from "../components/landing/HeroSection";
import {
  FeatureStrip,
  HowItWorks,
  AnalysisSection,
  CoachSection,
  PracticeSection,
  ProgressSection,
  FinalCta,
  LandingFooter,
} from "../components/landing/LandingSections";

export default function Home() {
  const authed = isLoggedIn();

  useEffect(() => {
    document.title = "CricketAI · Your AI cricket coach";
  }, []);

  return (
    <div id="top" className="min-h-dvh bg-paper">
      <a href="#content" className="skip-link visually-hidden">Skip to content</a>
      <LandingNav authed={authed} />
      <main id="content" tabIndex={-1} className="focus:outline-none">
        <HeroSection authed={authed} />
        <FeatureStrip />
        <HowItWorks />
        <AnalysisSection />
        <CoachSection />
        <PracticeSection />
        <ProgressSection />
        <FinalCta authed={authed} />
      </main>
      <LandingFooter />
    </div>
  );
}
