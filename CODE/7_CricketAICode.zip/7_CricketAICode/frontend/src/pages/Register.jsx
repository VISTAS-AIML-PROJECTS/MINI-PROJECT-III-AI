import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { useAuth } from "../hooks/useAuth";
import { PLAYING_ROLES, SKILL_LEVELS } from "../utils/constants";
import { AuthFrame } from "../components/shell/Public";
import Button from "../ui/Button";
import { Field, Input, PasswordInput, Select } from "../ui/Field";
import { InlineAlert } from "../ui/States";
import { detailText } from "../lib/errors";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState("");
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    playingRole: PLAYING_ROLES[0],
    skillLevel: SKILL_LEVELS[0],
  });

  useEffect(() => {
    document.title = "Create account · CricketAI";
  }, []);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function handleSubmit(e) {
    e.preventDefault();
    const next = {};
    if (!form.name.trim()) next.name = "Enter your full name.";
    if (!form.email.trim()) next.email = "Enter your email address.";
    else if (!EMAIL.test(form.email.trim())) next.email = "Enter a valid email address.";
    if (!form.password) next.password = "Create a password.";
    if (form.password && form.password !== form.confirmPassword) next.confirmPassword = "Passwords don't match.";
    setErrors(next);
    setSubmitError("");
    if (Object.keys(next).length) return;

    setLoading(true);
    const result = await register({
      name: form.name.trim(),
      email: form.email.trim().toLowerCase(),
      password: form.password,
      playingRole: form.playingRole,
      skillLevel: form.skillLevel,
    });
    setLoading(false);

    if (!result.success) {
      setSubmitError(detailText(result.message, "Registration failed. Check your details and try again."));
      return;
    }
    if (!localStorage.getItem("token")) {
      setSubmitError("Your account was created, but sign-in failed. Sign in to continue.");
      return;
    }
    navigate("/dashboard", { replace: true });
  }

  return (
    <AuthFrame
      title="Create account"
      lede="Set up your player profile. You can change these details later."
      footer={
        <>
          Already have an account?{" "}
          <Link to="/login" className="font-medium text-ink underline decoration-line-2 underline-offset-4 hover:decoration-ink">
            Sign in
          </Link>
        </>
      }
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-5">
        {submitError && <InlineAlert>{submitError}</InlineAlert>}
        <Field label="Full name" required error={errors.name}>
          {(p) => <Input {...p} autoComplete="name" value={form.name} onChange={set("name")} />}
        </Field>
        <Field label="Email" required error={errors.email}>
          {(p) => <Input {...p} type="email" autoComplete="email" value={form.email} onChange={set("email")} />}
        </Field>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Password" required error={errors.password}>
            {(p) => <PasswordInput {...p} autoComplete="new-password" value={form.password} onChange={set("password")} />}
          </Field>
          <Field label="Confirm password" required error={errors.confirmPassword}>
            {(p) => <PasswordInput {...p} autoComplete="new-password" value={form.confirmPassword} onChange={set("confirmPassword")} />}
          </Field>
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Playing role">
            {(p) => <Select {...p} value={form.playingRole} onChange={set("playingRole")} options={PLAYING_ROLES} />}
          </Field>
          <Field label="Level">
            {(p) => <Select {...p} value={form.skillLevel} onChange={set("skillLevel")} options={SKILL_LEVELS} />}
          </Field>
        </div>
        <Button type="submit" size="lg" loading={loading} className="w-full">
          {loading ? "Creating account…" : "Create account"}
        </Button>
      </form>
    </AuthFrame>
  );
}
