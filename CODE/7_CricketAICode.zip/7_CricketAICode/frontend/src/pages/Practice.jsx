import { useCallback, useEffect, useId, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Upload, ListChecks } from "lucide-react";

import { getHistory, getAnalysis } from "../services/historyService";
import { getPlan, setPlanItemDone } from "../services/practiceService";
import { getSkills, getSkill } from "../services/skillsApi";
import { useResource } from "../lib/useResource";
import { describeError } from "../lib/errors";
import { sortedMetrics, analysisLabel, titleCase } from "../lib/scoring";
import { formatDate } from "../lib/format";

import Button from "../ui/Button";
import { PageHeader, SectionHeader } from "../ui/Layout";
import { Meter } from "../ui/Data";
import { Tabs, TabPanel } from "../ui/Tabs";
import { useToast } from "../ui/Overlay";
import { ErrorState, EmptyState, PageLoading, SkeletonRows } from "../ui/States";
import DrillList from "../components/practice/DrillList";

async function loadFocus() {
  const history = await getHistory();
  const latest = history.find((a) => a.status === "completed");
  if (!latest) return { latest: null, report: null };
  return { latest, report: await getAnalysis(latest.id) };
}

const PERIODS = [
  { value: "daily", label: "Today" },
  { value: "weekly", label: "This week" },
  { value: "monthly", label: "This month" },
];

function TrainingPlan() {
  const notify = useToast();
  const baseId = useId();
  const [period, setPeriod] = useState("daily");
  const loader = useCallback(() => getPlan(period), [period]);
  const { data, error, loading, reload } = useResource(loader, [period]);
  const [items, setItems] = useState([]);

  useEffect(() => setItems(data || []), [data]);

  async function toggle(item) {
    const next = !item.done;
    setItems((list) => list.map((i) => (i.id === item.id ? { ...i, done: next } : i)));
    try {
      await setPlanItemDone(period, item.id, next);
    } catch (err) {
      setItems((list) => list.map((i) => (i.id === item.id ? { ...i, done: !next } : i)));
      notify(describeError(err, "Couldn't save that change.").message, "error");
    }
  }

  const done = items.filter((i) => i.done).length;

  return (
    <>
      <Tabs label="Plan period" baseId={baseId} value={period} onChange={setPeriod} tabs={PERIODS} />
      <TabPanel baseId={baseId} value={period} className="mt-5">
        {loading ? (
          <SkeletonRows rows={2} />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} title="Couldn't load the plan" />
        ) : items.length === 0 ? (
          <p className="text-sm text-ink-3">No plan items for this period.</p>
        ) : (
          <>
            <div className="mb-3 flex items-center gap-3">
              <Meter value={(done / items.length) * 100} tone="pitch" label="Plan completion" className="max-w-48" />
              <span className="t-data text-ink-2">{done}/{items.length} done</span>
            </div>
            <ul className="divide-y divide-line border-y border-line">
              {items.map((item) => (
                <li key={item.id}>
                  <label className="flex min-h-12 items-center gap-3 py-2">
                    <input
                      type="checkbox"
                      checked={item.done}
                      onChange={() => toggle(item)}
                      className="h-6 w-6 shrink-0 accent-[var(--color-pitch)]"
                    />
                    <span className={item.done ? "text-ink-3 line-through decoration-ink-4" : ""}>{item.label}</span>
                  </label>
                </li>
              ))}
            </ul>
          </>
        )}
      </TabPanel>
    </>
  );
}

function LibraryDrills({ category }) {
  const loader = useCallback(async () => {
    const list = await getSkills(category);
    const withDrills = list.filter((s) => s.drill_count > 0);
    return Promise.all(withDrills.map((s) => getSkill(s.skill_id)));
  }, [category]);
  const { data, error, loading, reload } = useResource(loader, [category]);
  const [showAll, setShowAll] = useState(false);

  if (loading) return <SkeletonRows rows={3} />;
  if (error) return <ErrorState error={error} onRetry={reload} title="Couldn't load drills" />;
  if (!data?.length) return <p className="text-sm text-ink-3">No structured drills in the library for {category} yet.</p>;

  const shown = showAll ? data : data.slice(0, 3);
  return (
    <div className="space-y-8">
      {shown.map((skill) => (
        <div key={skill.skill_id}>
          <div className="mb-2 flex items-baseline justify-between gap-3">
            <h3 className="t-sub text-base">{skill.name}</h3>
            <Link to={`/skills/${skill.skill_id}`} className="inline-flex min-h-9 items-center gap-1 text-sm text-ink-2 hover:text-ink hover:underline">
              Technique guide <ArrowRight size={13} aria-hidden="true" />
            </Link>
          </div>
          <DrillList drills={skill.drills} />
        </div>
      ))}
      {data.length > 3 && (
        <Button variant="secondary" onClick={() => setShowAll((v) => !v)} aria-expanded={showAll}>
          {showAll ? "Show fewer skills" : `Show drills for all ${data.length} ${category} skills`}
        </Button>
      )}
    </div>
  );
}

export default function Practice() {
  const loader = useCallback(loadFocus, []);
  const { data, error, loading, reload } = useResource(loader, []);

  if (loading) return <PageLoading label="Loading practice" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;

  const { latest, report } = data;
  const focus = sortedMetrics(report?.metrics).filter((m) => m.value < 75).slice(0, 5);
  const drills = report?.recommended_drills || [];
  const category = latest?.analysis_type === "bowling" ? "bowling" : "batting";

  return (
    <>
      <PageHeader
        eyebrow="Practice"
        title="Training focus"
        lede="What to work on, why, and how, based on your latest analysed session."
      />

      {!latest ? (
        <EmptyState
          icon={ListChecks}
          title="Analyse a session to get a training focus"
          body="Practice priorities come from your latest technique report. You can still use the training plan below."
          action={<Button to="/upload" icon={Upload}>Analyse a video</Button>}
          className="mb-10"
        />
      ) : (
        <div className="grid gap-10 lg:grid-cols-2">
          <section aria-labelledby="why-h">
            <SectionHeader
              id="why-h"
              index="01"
              title="What to train, and why"
              description={`Lowest-scoring areas · ${analysisLabel(latest)}, ${formatDate(latest.created_at)}`}
            />
            {focus.length ? (
              <ul className="space-y-4">
                {focus.map((m) => (
                  <li key={m.name}>
                    <div className="mb-1.5 flex items-baseline justify-between gap-3">
                      <span className="font-medium">{m.name}</span>
                      <span className="t-figure text-xl">{m.value}</span>
                    </div>
                    <Meter value={m.value} label={`${m.name} score`} showTicks />
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-ink-3">Every measure scored 75 or above. Keep your current routine and re-test.</p>
            )}
            <Link to={`/analysis/${latest.id}`} className="mt-5 inline-flex min-h-9 items-center gap-1.5 text-sm font-medium hover:underline">
              Open the report <ArrowRight size={14} aria-hidden="true" />
            </Link>
          </section>

          <section aria-labelledby="drills-h">
            <SectionHeader id="drills-h" index="02" title="Corrective drills" description="Prescribed in your report for these areas" />
            {drills.length ? (
              <ol className="divide-y divide-line border-y border-line">
                {drills.map((d, i) => (
                  <li key={d} className="flex gap-4 py-3">
                    <span className="t-data pt-0.5 text-pitch">{String(i + 1).padStart(2, "0")}</span>
                    <span>{d}</span>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="text-sm text-ink-3">No drills were prescribed in this report.</p>
            )}
          </section>
        </div>
      )}

      <section aria-labelledby="plan-h" className="rule-top mt-10 pt-8">
        <SectionHeader id="plan-h" index={latest ? "03" : "01"} title="Training plan" description="Tick items off as you complete them. Progress is saved to your account." />
        <div className="max-w-2xl">
          <TrainingPlan />
        </div>
      </section>

      <section aria-labelledby="lib-h" className="rule-top mt-10 pt-8">
        <SectionHeader
          id="lib-h"
          index={latest ? "04" : "02"}
          title={`How to perform them · ${titleCase(category)} drills`}
          description="Structured drills from the skill library, with sets, reps and duration."
        />
        <LibraryDrills category={category} />
      </section>
    </>
  );
}
