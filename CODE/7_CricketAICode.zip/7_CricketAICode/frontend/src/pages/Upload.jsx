import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useDropzone } from "react-dropzone";
import { FileVideo, X, Check } from "lucide-react";

import { uploadVideo } from "../services/videoService";
import { rememberVideo } from "../lib/sessionVideos";
import { describeError } from "../lib/errors";
import Button from "../ui/Button";
import { PageHeader, Panel } from "../ui/Layout";
import { Segmented } from "../ui/Field";
import { IndeterminateBar, InlineAlert } from "../ui/States";
import { Meter } from "../ui/Data";

const MAX_MB = 200;

function formatBytes(bytes) {
  return bytes > 1024 * 1024 ? `${(bytes / (1024 * 1024)).toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`;
}

function useObjectUrl(file) {
  const url = useMemo(() => (file ? URL.createObjectURL(file) : null), [file]);
  useEffect(() => () => url && URL.revokeObjectURL(url), [url]);
  return url;
}

function Step({ n, title, children, done }) {
  return (
    <li className="grid grid-cols-[2rem_1fr] gap-x-3 border-t border-line pt-5">
      <span className={`t-data flex h-6 w-6 items-center justify-center rounded-xs text-xs ${done ? "bg-pitch text-white" : "border border-line-2 text-ink-2"}`}>
        {done ? <Check size={13} aria-hidden="true" /> : n}
      </span>
      <div className="min-w-0">
        <h2 className="t-sub mb-3">{title}</h2>
        {children}
      </div>
    </li>
  );
}

export default function Upload() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const skill = params.get("skill");
  const presetType = params.get("type");

  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState("");
  const [analysisType, setAnalysisType] = useState(presetType === "bowling" ? "bowling" : "batting");
  const [side, setSide] = useState("right");
  const [bowlingArm, setBowlingArm] = useState("right");
  const [bowlingStyle, setBowlingStyle] = useState("fast");

  // idle | uploading | analysing | error
  const [phase, setPhase] = useState("idle");
  const [progress, setProgress] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [error, setError] = useState("");
  const statusRef = useRef(null);

  const previewUrl = useObjectUrl(file);
  const busy = phase === "uploading" || phase === "analysing";

  useEffect(() => {
    if (phase !== "analysing") return;
    const start = Date.now();
    const t = setInterval(() => setElapsed(Math.round((Date.now() - start) / 1000)), 1000);
    return () => clearInterval(t);
  }, [phase]);

  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({
    multiple: false,
    noClick: true,
    disabled: busy,
    maxSize: MAX_MB * 1024 * 1024,
    accept: { "video/mp4": [".mp4"], "video/quicktime": [".mov"] },
    onDropAccepted: (files) => {
      setFile(files[0]);
      setFileError("");
      setError("");
    },
    onDropRejected: (rejections) => {
      const code = rejections[0]?.errors[0]?.code;
      setFileError(
        code === "file-too-large"
          ? `That file is larger than ${MAX_MB} MB. Trim the clip and try again.`
          : "Use an MP4 or MOV video file."
      );
    },
  });

  async function handleSubmit(e) {
    e.preventDefault();
    if (!file) {
      setFileError("Choose a video to analyse.");
      return;
    }
    setError("");
    setProgress(0);
    setPhase("uploading");
    statusRef.current?.focus();

    try {
      const result = await uploadVideo(
        file,
        analysisType,
        side,
        (p) => {
          setProgress(p);
          // The upload is done at 100%; the server then runs the analysis
          // before responding.
          if (p >= 100) setPhase("analysing");
        },
        bowlingArm,
        bowlingStyle
      );
      rememberVideo(result.analysis_id, file);
      localStorage.setItem("analysis_id", result.analysis_id);
      navigate(`/analysis/${result.analysis_id}`, { state: { fresh: true } });
    } catch (err) {
      setPhase("error");
      setError(describeError(err, "The analysis failed. Check the clip and try again.").message);
    }
  }

  return (
    <>
      <PageHeader
        eyebrow="Analysis · New session"
        title="Analyse a session"
        lede="Upload one batting stroke or bowling delivery. The video is scored joint-by-joint and you get a full technique report."
      />

      {skill && (
        <div className="mb-6">
          <InlineAlert tone="neutral">
            Practising <span className="font-semibold capitalize">{skill.replace(/_/g, " ")}</span>. Record an attempt and analyse it here.
          </InlineAlert>
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid gap-10 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        <ol className="space-y-6">
          <Step n="1" title="Discipline" done={busy}>
            <Segmented
              legend="Discipline"
              name="analysis_type"
              value={analysisType}
              onChange={setAnalysisType}
              options={[
                { value: "batting", label: "Batting" },
                { value: "bowling", label: "Bowling" },
              ]}
            />
          </Step>

          <Step n="2" title={analysisType === "batting" ? "Batter" : "Bowler"} done={busy}>
            {analysisType === "batting" ? (
              <Segmented
                legend="Batting side"
                name="side"
                value={side}
                onChange={setSide}
                options={[
                  { value: "right", label: "Right-handed" },
                  { value: "left", label: "Left-handed" },
                ]}
              />
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                <Segmented
                  legend="Bowling arm"
                  name="bowling_arm"
                  value={bowlingArm}
                  onChange={setBowlingArm}
                  options={[
                    { value: "right", label: "Right arm" },
                    { value: "left", label: "Left arm" },
                  ]}
                />
                <Segmented
                  legend="Bowling style"
                  name="bowling_style"
                  value={bowlingStyle}
                  onChange={setBowlingStyle}
                  options={[
                    { value: "fast", label: "Pace" },
                    { value: "spin", label: "Spin" },
                  ]}
                />
              </div>
            )}
          </Step>

          <Step n="3" title="Video" done={busy}>
            {!file ? (
              <div
                {...getRootProps()}
                className={`flex flex-col items-start gap-3 rounded-md border border-dashed px-5 py-8 transition-colors sm:items-center sm:text-center ${
                  isDragActive ? "border-pitch bg-pitch-tint" : fileError ? "border-leather bg-surface" : "border-line-2 bg-surface"
                }`}
              >
                <input {...getInputProps()} aria-label="Video file" />
                <FileVideo size={24} aria-hidden="true" className="text-ink-3" />
                <p className="font-medium">{isDragActive ? "Drop the video to add it" : "Drag a video here"}</p>
                <p className="text-sm text-ink-3">MP4 or MOV · up to {MAX_MB} MB</p>
                <Button variant="secondary" onClick={open}>Choose file</Button>
              </div>
            ) : (
              <div className="overflow-hidden rounded-md border border-line bg-surface">
                <video src={previewUrl} controls playsInline preload="metadata" className="aspect-video w-full bg-night object-contain" />
                <div className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{file.name}</p>
                    <p className="t-data text-ink-3">{formatBytes(file.size)}</p>
                  </div>
                  {!busy && (
                    <Button variant="ghost" size="sm" icon={X} onClick={() => setFile(null)}>
                      Remove
                    </Button>
                  )}
                </div>
              </div>
            )}
            {fileError && <p role="alert" className="mt-2 text-sm font-medium text-leather">{fileError}</p>}
          </Step>

          <li className="border-t border-line pt-5">
            <div ref={statusRef} tabIndex={-1} className="focus:outline-none">
              {phase === "uploading" && (
                <div role="status" className="mb-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Uploading video</span>
                    <span className="t-data">{progress}%</span>
                  </div>
                  <Meter value={progress} tone="neutral" label="Upload progress" />
                </div>
              )}
              {phase === "analysing" && (
                <div role="status" className="mb-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">Analysing technique on the server</span>
                    <span className="t-data text-ink-3">{elapsed}s</span>
                  </div>
                  <IndeterminateBar label="Analysing technique" />
                  <p className="text-sm text-ink-3">Tracking pose frame by frame and scoring each joint. Keep this page open.</p>
                </div>
              )}
              {phase === "error" && <div className="mb-4"><InlineAlert>{error}</InlineAlert></div>}
            </div>
            <Button type="submit" size="lg" loading={busy} className="w-full sm:w-auto">
              {busy ? (phase === "uploading" ? "Uploading…" : "Analysing…") : phase === "error" ? "Try again" : "Analyse session"}
            </Button>
          </li>
        </ol>

        <aside aria-labelledby="filming-h" className="lg:pt-5">
          <Panel>
            <h2 id="filming-h" className="t-section">Filming checklist</h2>
            <p className="mt-1 text-sm text-ink-3">Pose tracking is only as good as the footage.</p>
            <ul className="mt-4 space-y-3 text-sm">
              {[
                "Whole body in frame for the entire action, head to feet.",
                "Camera fixed in one position: tripod or a steady rest.",
                "Good, even light. Avoid filming into the sun.",
                "One stroke or one delivery per clip.",
                "Wear clothing that contrasts with the background.",
              ].map((t) => (
                <li key={t} className="flex gap-3">
                  <Check size={16} aria-hidden="true" className="mt-0.5 shrink-0 text-pitch" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </aside>
      </form>
    </>
  );
}
