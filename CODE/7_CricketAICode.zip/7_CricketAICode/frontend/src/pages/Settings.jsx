import { useNavigate } from "react-router-dom";
import { LogOut, Pencil } from "lucide-react";

import { getSavedUser, logout } from "../services/authService";
import Button from "../ui/Button";
import { PageHeader, SectionHeader, DataRow } from "../ui/Layout";

export default function Settings() {
  const navigate = useNavigate();
  const user = getSavedUser();

  return (
    <>
      <PageHeader eyebrow="Settings" title="Settings" />

      <div className="max-w-2xl space-y-10">
        <section aria-labelledby="acct-h">
          <SectionHeader id="acct-h" title="Account" action={<Button to="/profile" variant="ghost" size="sm" icon={Pencil}>Edit in profile</Button>} />
          <dl className="rounded-md border border-line bg-surface px-5">
            <DataRow label="Name">{user?.name || "—"}</DataRow>
            <DataRow label="Email"><span className="t-data">{user?.email || "—"}</span></DataRow>
            <DataRow label="Playing role">{user?.playingRole || "Not set"}</DataRow>
            <DataRow label="Level">{user?.skillLevel || "Not set"}</DataRow>
          </dl>
        </section>

        <section aria-labelledby="engine-h" className="rule-top pt-8">
          <SectionHeader id="engine-h" title="How analysis works" />
          <dl className="rounded-md border border-line bg-surface px-5">
            <DataRow label="Technique analysis">Pose tracking + biomechanics scoring on your CricketAI server</DataRow>
            <DataRow label="AI coach">Local language model with coaching-manual retrieval</DataRow>
            <DataRow label="Uploaded video">Processed on the server; not played back in the app</DataRow>
          </dl>
        </section>

        <section aria-labelledby="session-h" className="rule-top pt-8">
          <SectionHeader id="session-h" title="Session" />
          <Button
            variant="danger"
            icon={LogOut}
            onClick={() => {
              logout();
              navigate("/login", { replace: true });
            }}
          >
            Sign out
          </Button>
        </section>
      </div>
    </>
  );
}
