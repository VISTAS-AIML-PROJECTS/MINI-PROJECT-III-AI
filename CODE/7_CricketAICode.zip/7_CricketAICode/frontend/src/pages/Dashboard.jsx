import { useCallback, useState } from "react";
import { ArrowRight, Upload, MessagesSquare, ListChecks, RefreshCw, AlertTriangle } from "lucide-react";

import { getDashboardOverview } from "../services/dashboardService";
import { getHistory, getAnalysis } from "../services/historyService";
import { getChatHistory } from "../services/chatService";
import { getPlan } from "../services/practiceService";
import { getSavedUser } from "../services/authService";
import { useResource } from "../lib/useResource";
import { bandFor, groupMetrics, sortedMetrics, analysisLabel, round } from "../lib/scoring";
import { formatDateTime, relativeDay } from "../lib/format";

import Button from "../ui/Button";
import { PageHeader, SectionHeader } from "../ui/Layout";
import { Meter, BandBadge } from "../ui/Data";
import { PageLoading, ErrorState } from "../ui/States";
import PipelineStrip from "../components/dashboard/PipelineStrip";
import BodyMap from "../components/dashboard/BodyMap";
import SessionVideo from "../components/analysis/SessionVideo";
import SessionTable from "../components/performance/SessionTable";
import ScoreTrend, { trendPoints, isScored } from "../components/performance/ScoreTrend";

const FIGURE_TONE = { pitch: "text-ink", amber: "text-amber", leather: "text-leather" };

// Everything the dashboard shows comes from these calls; anything that
// fails or doesn't exist renders as an explicit empty/unknown state.
async function loadDashboard() {
  const [overview, history] = await Promise.all([getDashboardOverview(), getHistory()]);
  const latest = history[0] || null;
  const latestDone = history.find((a) => a.status === "completed") || null;
  const focusSession = latest?.status === "completed" ? latest : null;

  const [report, chat, plan] = await Promise.all([
    focusSession ? getAnalysis(focusSession.id).catch(() => null) : null,
    focusSession ? getChatHistory(focusSession.id).catch(() => null) : null,
    getPlan("daily").catch(() => null),
  ]);
  return { overview, history, latest, latestDone, report, chat, plan };
}

/** Pipeline stages for the latest upload, from real data only. */
function pipelineSteps({ latest, report, chat, plan }) {
  const failed = latest.status === "failed";
  const processing = latest.status === "processing";
  const done = latest.status === "completed";
  const conf = round(latest.confidence);
  const score = round(report?.score ?? latest.technique_score);
  const measures = Object.keys(report?.metrics || {}).length;
  const messages = chat?.messages?.length || 0;
  const drills = report?.recommended_drills?.length || 0;
  const planDone = plan ? plan.filter((i) => i.done).length : null;

  return [
    {
      key: "upload",
      label: "Upload",
      state: "done",
      value: formatDateTime(latest.created_at),
      detail: analysisLabel(latest),
    },
    {
      key: "processing",
      label: "Video processing",
      state: failed ? "failed" : processing ? "active" : "done",
      value: failed ? "Failed" : processing ? "In progress" : "Processed",
      detail: failed ? "The clip couldn't be processed" : processing ? "Refresh to check again" : null,
    },
    {
      key: "pose",
      label: "Pose detection",
      state: !done ? "pending" : conf > 0 ? (conf < 50 ? "warn" : "done") : "warn",
      value: !done ? "Waiting" : conf > 0 ? `${conf}% tracking confidence` : "Body not detected",
      detail: done && conf > 0 && conf < 50 ? "Low confidence: scores are less certain" : null,
      href: done ? "#session" : undefined,
    },
    {
      key: "technique",
      label: "Technique analysis",
      state: !done ? "pending" : score != null ? "done" : "warn",
      value: !done ? "Waiting" : score != null ? `Score ${score} / 100` : "No score",
      detail: done && measures ? `${measures} measures scored` : null,
      href: done ? "#session" : undefined,
    },
    {
      key: "feedback",
      label: "AI feedback",
      state: !done ? "pending" : report?.coaching_feedback ? "done" : "pending",
      value: !done ? "Waiting" : report?.coaching_feedback ? "Coaching note ready" : "No note",
      detail: done ? (messages ? `${messages} messages with your coach` : "Not discussed with coach yet") : null,
      href: done ? "#coach" : undefined,
    },
    {
      key: "practice",
      label: "Practice",
      state: !done ? "pending" : drills ? "done" : "pending",
      value: !done ? "Waiting" : drills ? `${drills} drills recommended` : "No drills",
      detail: done && plan ? `Today's plan: ${planDone}/${plan.length} done` : null,
      href: done ? "#practice" : undefined,
    },
  ];
}

/** Drills in the report that mention the focus measure, else the first ones. */
function drillsFor(focus, drills = []) {
  if (!focus) return { matched: false, list: drills.slice(0, 3) };
  const words = focus.name.toLowerCase().split(/[^a-z]+/).filter((w) => w.length > 3);
  const matched = drills.filter((d) => words.some((w) => d.toLowerCase().includes(w)));
  return { matched: matched.length > 0, list: (matched.length ? matched : drills).slice(0, 3) };
}

function plainExcerpt(markdown = "", max = 220) {
  const text = markdown.replace(/[#*_`>|-]+/g, " ").replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max).trimEnd()}…` : text;
}

/* ------------------------------------------------------------------ */

function NoAnalysisYet() {
  const steps = [
    { key: "upload", label: "Upload", state: "pending", value: "Upload a batting or bowling clip" },
    { key: "processing", label: "Video processing", state: "pending", value: "Frames extracted on the server" },
    { key: "pose", label: "Pose detection", state: "pending", value: "Body landmarks tracked each frame" },
    { key: "technique", label: "Technique analysis", state: "pending", value: "Each measure scored 0–100" },
    { key: "feedback", label: "AI feedback", state: "pending", value: "Coaching note + AI coach" },
    { key: "practice", label: "Practice", state: "pending", value: "Drills for your weakest areas" },
  ];
  return (
    <section aria-labelledby="pipe-h">
      <h2 id="pipe-h" className="t-label mb-3">How your first analysis will run</h2>
      <PipelineStrip steps={steps} />
      <div className="mt-8 flex flex-col items-start gap-4 rounded-md border border-dashed border-line-2 bg-surface p-8 sm:items-center sm:text-center">
        <Upload size={24} aria-hidden="true" className="text-ink-3" />
        <h2 className="t-section">No analysis yet</h2>
        <p className="max-w-md text-sm text-ink-2">
          Everything on this dashboard comes from your own videos. Upload one stroke or delivery to start the pipeline.
        </p>
        <Button to="/upload" size="lg" icon={Upload}>Upload your first video</Button>
      </div>
    </section>
  );
}

function SessionPanel({ session, report }) {
  const [segment, setSegment] = useState(null);
  const groups = groupMetrics(report.metrics);
  const shown = (segment ? groups.filter((g) => g.key === segment) : groups).flatMap((g) =>
    g.items.map((m) => ({ ...m, group: g.label }))
  );
  const score = round(report.score);
  const band = bandFor(score);
  const conf = round(report.confidence);

  return (
    <section id="session" aria-labelledby="session-h" className="scroll-mt-20 overflow-hidden rounded-md border border-line bg-surface">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-3">
        <div className="min-w-0">
          <p className="t-label">Latest analysis · {relativeDay(session.created_at)}</p>
          <h2 id="session-h" className="t-section mt-1">{analysisLabel(session)}</h2>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button to={`/analysis/${session.id}`} variant="secondary" size="sm" iconRight={ArrowRight}>Full report</Button>
        </div>
      </header>

      <div className="grid lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        {/* Source of truth: the video */}
        <div className="border-line p-4 sm:p-5 lg:border-r">
          <SessionVideo analysisId={session.id} />
          <dl className="mt-4 grid grid-cols-3 gap-4">
            <div>
              <dt className="t-label">Technique</dt>
              <dd className={`t-figure mt-1 text-[3.25rem] ${FIGURE_TONE[band?.tone] || "text-ink"}`}>{score ?? "—"}</dd>
              <dd className="mt-1"><BandBadge score={score} /></dd>
            </div>
            <div className="col-span-2">
              <dt className="t-label">Pose tracking confidence</dt>
              <dd className="mt-2 flex items-center gap-3">
                <Meter value={conf} tone="neutral" label="Pose tracking confidence" className="flex-1" />
                <span className="t-data font-medium">{conf != null ? `${conf}%` : "—"}</span>
              </dd>
              <dd className="mt-2 text-xs text-ink-3">
                {report.summary || "No summary for this session."}
              </dd>
            </div>
          </dl>
        </div>

        {/* Pose → measures, linked by body segment */}
        <div className="flex min-h-0 flex-col border-t border-line p-4 sm:p-5 lg:border-t-0">
          {groups.length ? (
            <>
              <BodyMap groups={groups} selected={segment} onSelect={setSegment} />
              <div className="mt-4 border-t border-line pt-3">
                <p className="t-label mb-1">
                  {segment ? groups.find((g) => g.key === segment)?.label : "All measures"} · lowest first
                </p>
                <ul
                  tabIndex={0}
                  aria-label="Technique measures"
                  className="max-h-72 overflow-y-auto pr-1 focus-visible:outline-offset-2"
                >
                  {shown.map((m) => (
                    <li key={m.name} className="border-b border-line py-2 last:border-b-0">
                      <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
                        <span>{m.name}</span>
                        <span className="t-data font-medium">{m.value}</span>
                      </div>
                      <Meter value={m.value} label={`${m.name} score`} showTicks />
                    </li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <p className="text-sm text-ink-3">The engine didn't return per-measure scores for this session.</p>
          )}
        </div>
      </div>
    </section>
  );
}

function CoachPanel({ session, report, chat, focus }) {
  const messages = chat?.messages || [];
  const lastAnswer = [...messages].reverse().find((m) => m.role === "assistant");
  const question = focus ? `How do I improve my ${focus.name.toLowerCase()}?` : "What should I fix first in this session?";
  return (
    <section id="coach" aria-labelledby="coach-h" className="scroll-mt-20 flex flex-col p-5 sm:p-6">
      <SectionHeader id="coach-h" title="AI coach" description="On this session" />
      {report.coaching_feedback ? (
        <p className="t-coach">{report.coaching_feedback}</p>
      ) : (
        <p className="text-sm text-ink-3">No coaching note was generated for this session.</p>
      )}
      <div className="mt-5 border-t border-line pt-4">
        {lastAnswer ? (
          <>
            <p className="t-label mb-1.5">Last answer · {messages.length} messages</p>
            <p className="text-sm text-ink-2">{plainExcerpt(lastAnswer.content)}</p>
          </>
        ) : (
          <p className="text-sm text-ink-3">You haven't asked your coach about this session yet.</p>
        )}
      </div>
      <div className="mt-auto pt-5">
        <Button
          to={`/coach?analysis=${session.id}&q=${encodeURIComponent(question)}`}
          icon={MessagesSquare}
          className="w-full justify-start sm:w-auto"
        >
          {lastAnswer ? "Continue with coach" : `Ask: “${question}”`}
        </Button>
      </div>
    </section>
  );
}

function PracticePanel({ report, focus, plan }) {
  const { matched, list } = drillsFor(focus, report.recommended_drills);
  const planDone = plan ? plan.filter((i) => i.done).length : 0;
  return (
    <section id="practice" aria-labelledby="practice-h" className="scroll-mt-20 flex flex-col border-t border-line p-5 sm:p-6 lg:border-l lg:border-t-0">
      <SectionHeader id="practice-h" title="Practice" description="From this session's weakest area" />
      {focus ? (
        <div className="mb-4">
          <div className="mb-1.5 flex items-baseline justify-between gap-3">
            <p className="font-medium">
              <span className="t-label mr-2 !text-leather">Focus</span>
              {focus.name}
            </p>
            <span className="t-figure text-2xl">{focus.value}</span>
          </div>
          <Meter value={focus.value} label={`${focus.name} score`} showTicks />
        </div>
      ) : (
        <p className="mb-4 text-sm text-ink-3">No measure scored below the strong band.</p>
      )}

      {list.length ? (
        <>
          <p className="t-label mb-1">{matched ? `Drills for ${focus.name.toLowerCase()}` : "Recommended drills"}</p>
          <ol className="divide-y divide-line border-y border-line">
            {list.map((d, i) => (
              <li key={d} className="flex gap-3 py-2.5 text-sm">
                <span className="t-data pt-0.5 text-pitch">{String(i + 1).padStart(2, "0")}</span>
                <span>{d}</span>
              </li>
            ))}
          </ol>
        </>
      ) : (
        <p className="text-sm text-ink-3">No drills were recommended for this session.</p>
      )}

      <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-5">
        {plan && plan.length > 0 && (
          <p className="t-data text-ink-3">Today's plan {planDone}/{plan.length}</p>
        )}
        <Button to="/practice" variant="secondary" icon={ListChecks}>Open practice</Button>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */

export default function Dashboard() {
  const user = getSavedUser();
  const loader = useCallback(loadDashboard, []);
  const { data, error, loading, reload } = useResource(loader, []);

  if (loading) return <PageLoading label="Loading dashboard" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;

  const { overview, history, latest, latestDone, report, chat, plan } = data;
  const header = (
    <PageHeader
      eyebrow="Player dashboard"
      title={user?.name || "Dashboard"}
      lede={[user?.playingRole, user?.skillLevel].filter(Boolean).join(" · ") || undefined}
      actions={<Button to="/upload" icon={Upload} className="max-lg:hidden">New analysis</Button>}
    />
  );

  if (!latest) {
    return (
      <>
        {header}
        <NoAnalysisYet />
      </>
    );
  }

  const focus = report ? sortedMetrics(report.metrics).find((m) => m.value < 75) || null : null;
  const scored = history.filter(isScored);
  const trend = trendPoints(history).slice(-12);

  return (
    <>
      {header}

      <section aria-labelledby="pipe-h">
        <div className="mb-3 flex items-baseline justify-between gap-3">
          <h2 id="pipe-h" className="t-label">Latest upload · analysis pipeline</h2>
          {latest.status === "processing" && (
            <Button variant="ghost" size="sm" icon={RefreshCw} onClick={reload}>Refresh</Button>
          )}
        </div>
        <PipelineStrip steps={pipelineSteps({ latest, report, chat, plan })} />
      </section>

      <div className="mt-6">
        {latest.status === "completed" && report ? (
          <>
            <SessionPanel session={latest} report={report} />
            <div className="mt-6 grid overflow-hidden rounded-md border border-line bg-surface lg:grid-cols-2">
              <CoachPanel session={latest} report={report} chat={chat} focus={focus} />
              <PracticePanel report={report} focus={focus} plan={plan} />
            </div>
          </>
        ) : (
          <div role="status" className="flex flex-col items-start gap-3 rounded-md border border-line bg-surface p-6">
            <div className="flex items-center gap-2">
              {latest.status === "failed" ? (
                <AlertTriangle size={18} aria-hidden="true" className="text-leather" />
              ) : (
                <RefreshCw size={18} aria-hidden="true" className="text-amber" />
              )}
              <h2 className="t-sub text-base">
                {latest.status === "failed"
                  ? "Your latest upload couldn't be analysed"
                  : latest.status === "processing"
                    ? "Your latest upload is still being analysed"
                    : "Couldn't load your latest report"}
              </h2>
            </div>
            <p className="text-sm text-ink-2">
              {latest.status === "failed"
                ? "Re-record with the whole body in frame and a steady camera, then upload again."
                : "Results appear here as soon as the analysis finishes."}
            </p>
            <div className="flex flex-wrap gap-2">
              {latest.status === "failed" && <Button to="/upload" icon={Upload}>Upload again</Button>}
              {latestDone && (
                <Button to={`/analysis/${latestDone.id}`} variant="secondary" iconRight={ArrowRight}>
                  Last completed analysis
                </Button>
              )}
            </div>
          </div>
        )}
      </div>

      <section aria-labelledby="history-h" className="rule-top mt-10 pt-8">
        <SectionHeader
          id="history-h"
          title="History"
          description={`${history.length} upload${history.length === 1 ? "" : "s"} · ${scored.length} scored`}
          action={history.length > 1 && <Button to="/analysis" variant="ghost" size="sm" iconRight={ArrowRight}>All sessions</Button>}
        />

        {scored.length >= 2 ? (
          <div className="grid gap-6 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
            <div className="rounded-md border border-line bg-surface p-5">
              <ScoreTrend points={trend} height={200} title="Technique score by session" />
            </div>
            <dl className="grid grid-cols-2 content-start gap-px overflow-hidden rounded-md border border-line bg-line">
              {[
                ["Average", round(overview.average_score)],
                ["Best", round(overview.best_score)],
                ["Completed", overview.total_analyses],
                ["Day streak", overview.practice_streak_days],
              ].map(([label, value]) => (
                <div key={label} className="bg-surface px-4 py-3">
                  <dt className="t-label">{label}</dt>
                  <dd className="t-figure mt-1.5 text-[2rem]">{value ?? "—"}</dd>
                </div>
              ))}
            </dl>
          </div>
        ) : (
          <p className="rounded-md border border-dashed border-line-2 px-4 py-4 text-sm text-ink-2">
            {scored.length === 1
              ? "This is your only scored analysis so far. Upload another session to start tracking progress."
              : "No scored analyses yet. Trends appear after two scored sessions."}
          </p>
        )}

        {history.length > 1 && (
          <div className="mt-6">
            <SessionTable sessions={history.slice(0, 5)} caption="Recent uploads" compact />
          </div>
        )}
      </section>

    </>
  );
}
