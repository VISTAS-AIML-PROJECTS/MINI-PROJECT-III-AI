import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import { ArrowRight, MessagesSquare, Send, Trash2, Upload } from "lucide-react";

import { askCoach, getChatHistory, clearChat } from "../services/chatService";
import { getHistory, getAnalysis } from "../services/historyService";
import { useResource } from "../lib/useResource";
import { describeError } from "../lib/errors";
import { analysisLabel, bandFor, round, sortedMetrics } from "../lib/scoring";
import { formatDate, toDate } from "../lib/format";

import Button from "../ui/Button";
import { Select } from "../ui/Field";
import { BandBadge, Meter } from "../ui/Data";
import { Dialog, useToast } from "../ui/Overlay";
import { PageLoading, ErrorState, EmptyState, Spinner } from "../ui/States";

const FIGURE_TONE = { pitch: "text-ink", amber: "text-amber", leather: "text-leather" };

function timeOf(value) {
  const d = toDate(value);
  return d ? d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) : "";
}

function ContextRail({ sessions, activeId, onSelect, report, reportLoading }) {
  const selectId = useId();
  const issues = sortedMetrics(report?.metrics).filter((m) => m.value < 75).slice(0, 3);
  const score = round(report?.score);
  const band = bandFor(score);
  // Small screens: context collapses to one line so the conversation
  // stays near the top; the full card is always open on desktop.
  const [expanded, setExpanded] = useState(false);
  const cardId = useId();

  return (
    <aside aria-label="Analysis context" className="space-y-4 lg:sticky lg:top-6 lg:self-start lg:space-y-5">
      <div>
        <label htmlFor={selectId} className="t-label mb-1.5 block !text-ink-2">Coaching on</label>
        <Select
          id={selectId}
          value={activeId || ""}
          onChange={(e) => onSelect(e.target.value)}
          options={sessions.map((s) => ({
            value: s.id,
            label: `${formatDate(s.created_at)} · ${analysisLabel(s)} · ${round(s.technique_score) ?? "—"}`,
          }))}
        />
      </div>

      {report && !reportLoading && (
        <div className="flex items-center justify-between gap-3 border-y border-line py-2 lg:hidden">
          <p className="min-w-0 text-sm">
            <span className={`t-figure mr-2 text-2xl ${FIGURE_TONE[band?.tone] || "text-ink"}`}>{score ?? "—"}</span>
            {issues[0] ? (
              <span className="text-ink-2">Top issue: <span className="font-medium text-ink">{issues[0].name}</span></span>
            ) : (
              <BandBadge score={score} />
            )}
          </p>
          <button
            type="button"
            aria-expanded={expanded}
            aria-controls={cardId}
            onClick={() => setExpanded((v) => !v)}
            className="inline-flex min-h-10 shrink-0 items-center text-sm font-medium underline decoration-line-2 underline-offset-4"
          >
            {expanded ? "Hide context" : "Show context"}
          </button>
        </div>
      )}

      <div id={cardId} className={`${expanded ? "" : "hidden"} rounded-md border border-line bg-surface lg:block`}>
        {reportLoading || !report ? (
          <div className="space-y-3 p-5" aria-hidden="true">
            <div className="skeleton h-3 w-24" />
            <div className="skeleton h-14 w-28" />
            <div className="skeleton h-20" />
          </div>
        ) : (
          <>
            <div className="flex items-end justify-between gap-3 p-5">
              <div>
                <p className="t-label">Technique score</p>
                <p className={`t-figure mt-1.5 text-6xl ${FIGURE_TONE[band?.tone] || "text-ink"}`}>{score ?? "—"}</p>
              </div>
              <BandBadge score={score} />
            </div>

            <div className="border-t border-line p-5">
              <h2 className="t-label mb-3">Technique issues</h2>
              {issues.length ? (
                <ul className="space-y-3">
                  {issues.map((m) => (
                    <li key={m.name}>
                      <div className="mb-1 flex justify-between gap-2 text-sm">
                        <span>{m.name}</span>
                        <span className="t-data">{m.value}</span>
                      </div>
                      <Meter value={m.value} label={`${m.name} score`} />
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-ink-3">No measure scored under 75.</p>
              )}
            </div>

            {report.coaching_feedback && (
              <div className="border-t border-line p-5">
                <h2 className="t-label mb-2">Coach recommendation</h2>
                <p className="text-sm leading-relaxed">{report.coaching_feedback}</p>
              </div>
            )}

            <div className="border-t border-line px-5 py-3">
              <Link to={`/analysis/${activeId}`} className="inline-flex min-h-9 items-center gap-1.5 text-sm font-medium hover:underline">
                Open full report <ArrowRight size={14} aria-hidden="true" />
              </Link>
            </div>
          </>
        )}
      </div>
    </aside>
  );
}

function Message({ m }) {
  if (m.role === "user") {
    return (
      <li className="flex justify-end">
        <div className="max-w-[85%] rounded-md bg-sunken px-4 py-3">
          <p className="t-label mb-1">You{m.created_at ? ` · ${timeOf(m.created_at)}` : ""}</p>
          <p className="whitespace-pre-wrap">{m.content}</p>
        </div>
      </li>
    );
  }
  return (
    <li className="border-l-[3px] border-pitch pl-4">
      <p className="t-label mb-1.5 !text-pitch">Coach{m.created_at ? ` · ${timeOf(m.created_at)}` : ""}</p>
      {m.error ? (
        <p className="text-leather">{m.content}</p>
      ) : (
        <div className="prose-coach">
          <ReactMarkdown>{m.content}</ReactMarkdown>
        </div>
      )}
    </li>
  );
}

function Composer({ onSend, disabled, initial = "" }) {
  // Pre-filled (not sent) when arriving with ?q= from the dashboard.
  const [text, setText] = useState(initial);
  const formRef = useRef(null);
  const id = useId();

  function submit(e) {
    e.preventDefault();
    const q = text.trim();
    if (!q || disabled) return;
    onSend(q);
    setText("");
  }

  return (
    <form ref={formRef} onSubmit={submit} className="flex items-end gap-2 rounded-md border border-control bg-surface p-2 focus-within:border-pitch">
      <label htmlFor={id} className="visually-hidden">Question for your coach</label>
      <textarea
        id={id}
        rows={2}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            // IME-safe: don't submit while composing characters.
            if (e.nativeEvent.isComposing || e.keyCode === 229) return;
            formRef.current?.requestSubmit();
          }
        }}
        placeholder="Ask about your technique…"
        maxLength={2000}
        className="max-h-40 min-h-11 flex-1 resize-none bg-transparent px-2 py-2 text-[15px] placeholder:text-ink-4 focus-visible:outline-none"
      />
      <Button type="submit" disabled={disabled || !text.trim()} icon={Send} aria-label="Send question">
        <span className="hidden sm:inline">Send</span>
      </Button>
    </form>
  );
}

export default function Coach() {
  const [params, setParams] = useSearchParams();
  const notify = useToast();
  const loader = useCallback(() => getHistory(), []);
  const { data: history, error, loading, reload } = useResource(loader, []);

  const sessions = useMemo(
    () => (history || []).filter((s) => s.status === "completed"),
    [history]
  );

  const requested = params.get("analysis");
  const stored = localStorage.getItem("analysis_id");
  const activeId = useMemo(() => {
    const ids = sessions.map((s) => s.id);
    if (requested && ids.includes(requested)) return requested;
    if (stored && ids.includes(stored)) return stored;
    return ids[0] || null;
  }, [sessions, requested, stored]);

  const [report, setReport] = useState(null);
  const [reportLoading, setReportLoading] = useState(false);
  const [messages, setMessages] = useState([]);
  const [threadLoading, setThreadLoading] = useState(false);
  const [pending, setPending] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [confirmClear, setConfirmClear] = useState(false);
  const endRef = useRef(null);

  // Load the selected report and its saved conversation.
  useEffect(() => {
    if (!activeId) return;
    let cancelled = false;
    localStorage.setItem("analysis_id", activeId);
    setReportLoading(true);
    setThreadLoading(true);
    setMessages([]);
    getAnalysis(activeId)
      .then((r) => !cancelled && setReport(r))
      .catch(() => !cancelled && setReport(null))
      .finally(() => !cancelled && setReportLoading(false));
    getChatHistory(activeId)
      .then((h) => !cancelled && setMessages(h.messages || []))
      .catch(() => !cancelled && setMessages([]))
      .finally(() => !cancelled && setThreadLoading(false));
    return () => {
      cancelled = true;
    };
  }, [activeId]);

  useEffect(() => {
    if (!pending) return;
    const start = Date.now();
    const t = setInterval(() => setElapsed(Math.round((Date.now() - start) / 1000)), 1000);
    return () => clearInterval(t);
  }, [pending]);

  // Follow the conversation only once the player has asked something in
  // this visit, so opening the page doesn't jump past the context.
  const followRef = useRef(false);
  useEffect(() => {
    if (!followRef.current) return;
    const reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    endRef.current?.scrollIntoView({ block: "end", behavior: reduce ? "auto" : "smooth" });
  }, [messages.length, pending]);

  function select(id) {
    setParams({ analysis: id }, { replace: true }); // drops any ?q= prefill
  }

  async function send(question) {
    const now = new Date().toISOString();
    followRef.current = true;
    setMessages((m) => [...m, { role: "user", content: question, created_at: now }]);
    setPending(true);
    setElapsed(0);
    try {
      const res = await askCoach(activeId, question);
      setMessages((m) => [...m, { role: "assistant", content: res.answer, created_at: new Date().toISOString() }]);
    } catch (err) {
      const { message } = describeError(err, "The coach couldn't answer. Check that Ollama is running and try again.");
      setMessages((m) => [...m, { role: "assistant", content: message, error: true }]);
    } finally {
      setPending(false);
    }
  }

  async function doClear() {
    setConfirmClear(false);
    try {
      await clearChat(activeId);
      setMessages([]);
      notify("Conversation cleared", "success");
    } catch (err) {
      notify(describeError(err, "Couldn't clear the conversation.").message, "error");
    }
  }

  if (loading) return <PageLoading label="Loading coach" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;

  if (!sessions.length) {
    return (
      <>
        <header className="mb-8 border-b border-line pb-6">
          <p className="t-label mb-2">AI Coach</p>
          <h1 className="t-page">Coaching session</h1>
        </header>
        <EmptyState
          icon={MessagesSquare}
          title="Your coach needs a session to review"
          body="The coach answers questions about a specific analysis. Analyse a batting or bowling clip first."
          action={<Button to="/upload" icon={Upload}>Analyse a video</Button>}
        />
      </>
    );
  }

  const weakest = sortedMetrics(report?.metrics).slice(0, 2);
  const suggestions = [
    "What should I fix first in this session?",
    ...weakest.map((m) => `How do I improve my ${m.name.toLowerCase()}?`),
    "Give me a practice routine for my weakest areas.",
  ];

  return (
    <>
      <header className="mb-6 flex flex-col gap-4 border-b border-line pb-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="t-label mb-2">AI Coach</p>
          <h1 className="t-page">Coaching session</h1>
          <p className="mt-3 max-w-2xl text-ink-2">Your coach has read the selected report and draws on cricket coaching manuals to answer.</p>
        </div>
        {messages.length > 0 && (
          <Button variant="ghost" className="self-start md:self-auto" icon={Trash2} onClick={() => setConfirmClear(true)} disabled={pending}>
            Clear conversation
          </Button>
        )}
      </header>

      <div className="grid gap-8 lg:grid-cols-[minmax(0,4fr)_minmax(0,8fr)] lg:gap-10">
        <ContextRail sessions={sessions} activeId={activeId} onSelect={select} report={report} reportLoading={reportLoading} />

        <section aria-label="Conversation" className="flex min-w-0 flex-col">
          {threadLoading ? (
            <div className="flex items-center gap-2 py-6 text-sm text-ink-3"><Spinner /> Loading conversation…</div>
          ) : messages.length === 0 && !pending ? (
            <div className="rounded-md border border-dashed border-line-2 p-6">
              <h2 className="t-sub text-base">Start with a question about this session</h2>
              <p className="mt-1 text-sm text-ink-3">Or pick one of these, drawn from your report:</p>
              <ul className="mt-4 flex flex-col gap-2">
                {suggestions.map((s) => (
                  <li key={s}>
                    <button
                      type="button"
                      onClick={() => send(s)}
                      disabled={!report}
                      className="flex min-h-11 w-full items-center justify-between gap-3 rounded-sm border border-line bg-surface px-3 text-left text-sm hover:border-ink-3 disabled:opacity-50"
                    >
                      {s}
                      <ArrowRight size={14} aria-hidden="true" className="shrink-0 text-ink-3" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div role="log" aria-live="polite" aria-label="Coaching conversation">
            <ol className="space-y-6 pb-4">
              {messages.map((m, i) => (
                <Message key={i} m={m} />
              ))}
              {pending && (
                <li className="border-l-[3px] border-line-2 pl-4" aria-live="off">
                  <p className="t-label mb-1.5">Coach</p>
                  <div className="flex items-center gap-2 text-sm text-ink-2">
                    <Spinner />
                    Reviewing your report and the coaching references… <span className="t-data text-ink-3">{elapsed}s</span>
                  </div>
                  <p className="mt-1 text-xs text-ink-3">The coach model runs locally; answers can take a minute or two.</p>
                </li>
              )}
            </ol>
            </div>
          )}
          <div ref={endRef} />

          <div className="sticky bottom-[calc(3.5rem+env(safe-area-inset-bottom))] mt-4 bg-paper pb-3 pt-2 lg:bottom-0">
            <Composer onSend={send} disabled={pending || !activeId} initial={params.get("q") || ""} />
            <p className="mt-1.5 text-xs text-ink-3">Enter to send · Shift + Enter for a new line</p>
          </div>
        </section>
      </div>

      <Dialog
        open={confirmClear}
        onClose={() => setConfirmClear(false)}
        title="Clear conversation?"
        labelledBy="clear-title"
        actions={
          <>
            <Button variant="secondary" onClick={() => setConfirmClear(false)}>Cancel</Button>
            <Button variant="danger" icon={Trash2} onClick={doClear}>Clear</Button>
          </>
        }
      >
        <p className="text-sm text-ink-2">This deletes the saved conversation for this session. The analysis report isn't affected.</p>
      </Dialog>
    </>
  );
}
