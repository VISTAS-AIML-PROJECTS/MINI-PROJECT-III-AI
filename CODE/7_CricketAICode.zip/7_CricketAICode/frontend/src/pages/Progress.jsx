import { useCallback, useId, useMemo, useState } from "react";
import { TrendingUp, Upload } from "lucide-react";

import { getHistory, getAnalysis } from "../services/historyService";
import { useResource } from "../lib/useResource";
import { formatDate } from "../lib/format";
import { titleCase } from "../lib/scoring";

import Button from "../ui/Button";
import { PageHeader, SectionHeader, Panel } from "../ui/Layout";
import { Delta } from "../ui/Data";
import { Tabs, TabPanel } from "../ui/Tabs";
import { PageLoading, ErrorState, EmptyState, SkeletonRows } from "../ui/States";
import ScoreTrend, { trendPoints } from "../components/performance/ScoreTrend";
import SessionTable from "../components/performance/SessionTable";

function MetricDevelopment({ points }) {
  const first = points[0];
  const last = points[points.length - 1];
  const loader = useCallback(
    () => Promise.all([getAnalysis(first.id), getAnalysis(last.id)]),
    [first.id, last.id]
  );
  const { data, error, loading, reload } = useResource(loader, [first.id, last.id]);

  if (loading) return <SkeletonRows rows={4} />;
  if (error) return <ErrorState error={error} onRetry={reload} title="Couldn't load metric history" />;

  const [a, b] = data;
  const rows = Object.keys(b.metrics || {})
    .filter((k) => k in (a.metrics || {}))
    .map((k) => ({ name: k, first: Math.round(a.metrics[k]), latest: Math.round(b.metrics[k]) }))
    .map((r) => ({ ...r, change: r.latest - r.first }))
    .sort((x, y) => y.change - x.change);

  if (!rows.length) return <p className="text-sm text-ink-3">These sessions don't share comparable measures.</p>;

  return (
    <div className="overflow-x-auto rounded-md border border-line bg-surface">
      <table className="w-full min-w-[28rem] border-collapse text-left">
        <caption className="visually-hidden">
          Metric scores in your first session ({formatDate(first.date)}) compared with your latest ({formatDate(last.date)})
        </caption>
        <thead className="bg-paper">
          <tr className="border-b border-line">
            <th scope="col" className="t-label px-4 py-2.5">Measure</th>
            <th scope="col" className="t-label px-4 py-2.5 text-right">First · {formatDate(first.date, { year: false })}</th>
            <th scope="col" className="t-label px-4 py-2.5 text-right">Latest · {formatDate(last.date, { year: false })}</th>
            <th scope="col" className="t-label px-4 py-2.5 text-right">Change</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.name} className="border-b border-line last:border-b-0">
              <th scope="row" className="px-4 py-2.5 font-normal">{r.name}</th>
              <td className="t-data px-4 py-2.5 text-right text-ink-3">{r.first}</td>
              <td className="t-data px-4 py-2.5 text-right font-medium">{r.latest}</td>
              <td className="px-4 py-2.5 text-right"><Delta value={r.change} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Progress() {
  const loader = useCallback(() => getHistory(), []);
  const { data, error, loading, reload } = useResource(loader, []);
  const baseId = useId();

  const history = useMemo(() => data || [], [data]);
  const types = useMemo(
    () => ["batting", "bowling"].filter((t) => trendPoints(history, t).length > 0),
    [history]
  );
  const [type, setType] = useState(null);
  const active = type && types.includes(type) ? type : types[0];

  if (loading) return <PageLoading label="Loading progress" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;

  if (!types.length) {
    return (
      <>
        <PageHeader eyebrow="Progress" title="Progress" />
        <EmptyState
          icon={TrendingUp}
          title="No scored sessions yet"
          body="Progress tracks your technique score and each measure across sessions. Analyse a clip to begin."
          action={<Button to="/upload" icon={Upload}>Analyse a video</Button>}
        />
      </>
    );
  }

  const points = trendPoints(history, active);
  const scores = points.map((p) => p.score);
  const avg = Math.round(scores.reduce((s, v) => s + v, 0) / scores.length);
  const best = Math.max(...scores);
  const change = scores.length > 1 ? scores[scores.length - 1] - scores[0] : null;
  const sessions = history.filter((h) => h.analysis_type === active);
  const untracked = sessions.filter(
    (h) => h.status === "completed" && typeof h.technique_score === "number" && !((h.confidence ?? 0) > 0)
  ).length;

  return (
    <>
      <PageHeader
        eyebrow="Progress"
        title="Progress"
        lede="How your technique has moved across every analysed session."
      />

      <Tabs
        label="Discipline"
        baseId={baseId}
        value={active}
        onChange={setType}
        tabs={types.map((t) => ({ value: t, label: titleCase(t), count: trendPoints(history, t).length }))}
      />

      <TabPanel baseId={baseId} value={active} className="mt-6">
        <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-md border border-line bg-line md:grid-cols-4">
          {[
            ["Scored sessions", scores.length],
            ["Average", avg],
            ["Best", best],
            ["First → latest", change],
          ].map(([label, value]) => (
            <div key={label} className="bg-surface px-5 py-4">
              <dt className="t-label">{label}</dt>
              <dd
                className={`t-figure mt-2 text-[2.5rem] ${
                  label === "First → latest" && value ? (value > 0 ? "text-pitch" : "text-leather") : ""
                }`}
              >
                {label === "First → latest" ? (value == null ? "—" : value > 0 ? `+${value}` : value === 0 ? "±0" : `−${Math.abs(value)}`) : value}
              </dd>
            </div>
          ))}
        </dl>

        <Panel className="mt-6">
          <SectionHeader title={`${titleCase(active)} score by session`} description="Oldest to newest. Hover a point for the date." />
          <ScoreTrend points={points} height={280} title={`${titleCase(active)} technique score by session`} />
          {untracked > 0 && (
            <p className="mt-3 border-t border-line pt-3 text-xs text-ink-3">
              {untracked} session{untracked === 1 ? "" : "s"} with 0% tracking confidence {untracked === 1 ? "is" : "are"} left out:
              the body wasn't detected, so {untracked === 1 ? "its score isn't" : "their scores aren't"} a real assessment.
            </p>
          )}
        </Panel>

        <section aria-labelledby="dev-h" className="rule-top mt-10 pt-8">
          <SectionHeader id="dev-h" title="Metric development" description="Each measure in your first session against your latest, biggest gains first." />
          {points.length < 2 ? (
            <p className="text-sm text-ink-3">Metric development appears after your second analysed session in this discipline.</p>
          ) : (
            <MetricDevelopment key={active} points={points} />
          )}
        </section>

        <section aria-labelledby="log-h" className="rule-top mt-10 pt-8">
          <SectionHeader id="log-h" title="Session log" />
          <SessionTable sessions={sessions} caption={`${titleCase(active)} sessions`} />
        </section>
      </TabPanel>
    </>
  );
}
