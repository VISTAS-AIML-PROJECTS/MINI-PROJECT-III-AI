import { useCallback, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import { ArrowRight, MessagesSquare, Upload, CheckCircle2, AlertTriangle, RefreshCw } from "lucide-react";

import { getAnalysis, getHistory } from "../services/historyService";
import { useResource } from "../lib/useResource";
import { bandFor, groupMetrics, sortedMetrics, analysisLabel, round, titleCase } from "../lib/scoring";
import { formatDateTime } from "../lib/format";

import Button from "../ui/Button";
import { SectionHeader } from "../ui/Layout";
import { Badge, BandBadge, Meter } from "../ui/Data";
import { PageLoading, ErrorState, EmptyState, InlineAlert } from "../ui/States";
import SessionVideo from "../components/analysis/SessionVideo";

const SECTIONS = [
  { id: "summary", label: "Summary" },
  { id: "biomechanics", label: "Biomechanics" },
  { id: "observations", label: "Observations" },
  { id: "coaching", label: "Coaching" },
  { id: "drills", label: "Drills" },
];

const FIGURE_TONE = { pitch: "text-ink", amber: "text-amber", leather: "text-leather" };

async function loadReport(id) {
  const [report, history] = await Promise.all([getAnalysis(id), getHistory().catch(() => [])]);
  return { report, meta: history.find((h) => h.id === id) || null };
}

function ExpandableList({ items, limit = 6, icon: Icon, iconClass, empty }) {
  const [all, setAll] = useState(false);
  if (!items?.length) return <p className="text-sm text-ink-3">{empty}</p>;
  const shown = all ? items : items.slice(0, limit);
  return (
    <>
      <ul className="space-y-2.5">
        {shown.map((item, i) => (
          <li key={`${item}-${i}`} className="flex gap-2.5 text-[15px]">
            <Icon size={16} aria-hidden="true" className={`mt-1 shrink-0 ${iconClass}`} />
            <span>{item}</span>
          </li>
        ))}
      </ul>
      {items.length > limit && (
        <button
          type="button"
          onClick={() => setAll((v) => !v)}
          aria-expanded={all}
          className="mt-2 inline-flex min-h-9 items-center text-sm font-medium text-ink underline decoration-line-2 underline-offset-4 hover:decoration-ink"
        >
          {all ? "Show fewer" : `Show all ${items.length}`}
        </button>
      )}
    </>
  );
}

function Verdict({ report, meta }) {
  const score = round(report.score);
  const band = bandFor(score);
  const confidence = round(report.confidence);
  return (
    <div className="rounded-md border border-line bg-surface p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="t-label">Technique score</p>
          <p className={`t-figure mt-2 text-[5.5rem] ${FIGURE_TONE[band?.tone] || "text-ink"}`}>{score ?? "—"}</p>
        </div>
        <div className="pt-1 text-right">
          <BandBadge score={score} />
          <p className="t-data mt-3 text-ink-3">out of 100</p>
        </div>
      </div>
      <div className="mt-5 border-t border-line pt-4">
        <div className="mb-1.5 flex items-baseline justify-between text-sm">
          <span className="text-ink-2">Tracking confidence</span>
          <span className="t-data font-medium">{confidence != null ? `${confidence}%` : "—"}</span>
        </div>
        <Meter value={confidence} tone="neutral" label="Tracking confidence" />
        <p className="mt-2 text-xs text-ink-3">How reliably the body was tracked in this clip. Low confidence means the scores are less certain.</p>
      </div>
      {meta && (
        <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-4 text-sm">
          <div>
            <dt className="t-label">Recorded</dt>
            <dd className="t-data mt-1">{formatDateTime(meta.created_at)}</dd>
          </div>
          <div>
            <dt className="t-label">Discipline</dt>
            <dd className="mt-1">{analysisLabel(meta)}</dd>
          </div>
        </dl>
      )}
    </div>
  );
}

function Scorecard({ metrics }) {
  const groups = groupMetrics(metrics);
  if (!groups.length) {
    return <p className="text-sm text-ink-3">No per-joint breakdown was produced for this session.</p>;
  }
  return (
    <div className="space-y-7">
      <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-ink-3" aria-hidden="true">
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-3 bg-pitch" />75+ strong</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-3 bg-amber-bar" />50–74 developing</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-3 bg-leather" />under 50 priority</span>
      </div>
      {groups.map((g) => (
        <div key={g.key}>
          <h3 className="t-label mb-2 !text-ink-2">{g.label}</h3>
          <table className="w-full border-collapse">
            <caption className="visually-hidden">{g.label} scores, lowest first</caption>
            <thead className="visually-hidden">
              <tr><th scope="col">Measure</th><th scope="col">Score</th><th scope="col">Band</th></tr>
            </thead>
            <tbody>
              {g.items.map((m) => {
                const band = bandFor(m.value);
                return (
                  <tr key={m.name} className="border-t border-line">
                    <th scope="row" className="w-[44%] py-2.5 pr-3 text-left text-[15px] font-normal">
                      {m.name}
                    </th>
                    <td className="py-2.5">
                      <div className="flex items-center gap-3">
                        <Meter value={m.value} label={`${m.name} score`} height="h-2" showTicks className="flex-1" />
                        <span className="t-figure w-9 text-right text-xl">{m.value}</span>
                      </div>
                    </td>
                    <td className="hidden w-24 py-2.5 pl-3 text-right sm:table-cell">
                      {band?.key === "priority" && <Badge tone="leather">Priority</Badge>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}

export default function Analysis() {
  const { id } = useParams();
  const location = useLocation();
  const loader = useCallback(() => loadReport(id), [id]);
  const { data, error, loading, reload } = useResource(loader, [id]);

  if (loading) return <PageLoading label="Loading report" />;
  if (error) {
    return error.status === 404 ? (
      <EmptyState title="Report not found" body="This analysis doesn't exist or belongs to another account." action={<Button to="/analysis" variant="secondary">All sessions</Button>} />
    ) : (
      <ErrorState error={error} onRetry={reload} />
    );
  }

  const { report, meta } = data;
  const title = `${titleCase(report.type || meta?.analysis_type || "Technique")} report`;

  if (report.status !== "completed") {
    const failed = report.status === "failed";
    return (
      <>
        <header className="mb-8 border-b border-line pb-6">
          <p className="t-label mb-2">Analysis</p>
          <h1 className="t-page">{title}</h1>
        </header>
        <EmptyState
          icon={failed ? AlertTriangle : RefreshCw}
          title={failed ? "This analysis didn't complete" : "Still analysing"}
          body={failed ? "The server couldn't process this clip. Re-record following the filming checklist and try again." : "The server is still processing this clip. Refresh in a moment."}
          action={failed ? <Button to="/upload" icon={Upload}>Analyse again</Button> : <Button onClick={reload} variant="secondary" icon={RefreshCw}>Refresh</Button>}
        />
      </>
    );
  }

  const critical = sortedMetrics(report.metrics).filter((m) => m.value < 50);
  const drills = report.recommended_drills || [];

  return (
    <article className="reveal">
      <header className="mb-6 flex flex-col gap-4 border-b border-line pb-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="t-label mb-2">Analysis report{meta ? ` · ${formatDateTime(meta.created_at)}` : ""}</p>
          <h1 className="t-page">{title}</h1>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button to={`/coach?analysis=${id}`} icon={MessagesSquare}>Discuss with coach</Button>
          <Button to="/upload" variant="secondary" icon={Upload}>New analysis</Button>
        </div>
      </header>

      {location.state?.fresh && (
        <div className="mb-6"><InlineAlert tone="pitch">Analysis complete. Here's your report.</InlineAlert></div>
      )}

      <div className="grid gap-8 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-12">
        {/* Footage + verdict: sticky beside the report on desktop */}
        <div className="space-y-4 lg:sticky lg:top-6 lg:self-start">
          <SessionVideo analysisId={id} />
          <Verdict report={report} meta={meta} />
        </div>

        <div className="min-w-0">
          <nav aria-label="Report sections" className="sticky top-14 z-20 -mx-4 mb-6 overflow-x-auto border-b border-line bg-paper px-4 lg:top-0 lg:mx-0 lg:px-0">
            <ul className="flex gap-5">
              {SECTIONS.map((s, i) => (
                <li key={s.id}>
                  <a href={`#${s.id}`} className="flex min-h-11 items-center gap-1.5 whitespace-nowrap text-sm text-ink-3 hover:text-ink">
                    <span className="t-data text-xs text-pitch">0{i + 1}</span>
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <section aria-labelledby="summary" className="scroll-mt-28">
            <SectionHeader id="summary" index="01" title="Summary" />
            <p className="text-lg leading-relaxed text-ink">{report.summary || "No summary was produced for this session."}</p>
          </section>

          <section aria-labelledby="biomechanics" className="rule-top mt-10 scroll-mt-28 pt-8">
            <SectionHeader id="biomechanics" index="02" title="Biomechanics" description="Each measured part of the action, scored 0–100 and grouped by body segment. Lowest first." />
            <Scorecard metrics={report.metrics} />
          </section>

          <section aria-labelledby="observations" className="rule-top mt-10 scroll-mt-28 pt-8">
            <SectionHeader id="observations" index="03" title="Observations" />
            {critical.length > 0 && (
              <div className="mb-8 border-l-[3px] border-leather bg-leather-tint px-4 py-3">
                <h3 className="t-label !text-leather">Critical issues · scored under 50</h3>
                <ul className="mt-2 flex flex-wrap gap-x-5 gap-y-1">
                  {critical.map((m) => (
                    <li key={m.name} className="text-[15px] font-medium">
                      {m.name} <span className="t-data text-leather">{m.value}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <div className="grid gap-8 md:grid-cols-2">
              <div>
                <h3 className="t-sub mb-3 flex items-center gap-2"><span className="h-2 w-2 bg-pitch" aria-hidden="true" />Strengths</h3>
                <ExpandableList items={report.strengths} icon={CheckCircle2} iconClass="text-pitch" empty="No strengths recorded." />
              </div>
              <div>
                <h3 className="t-sub mb-3 flex items-center gap-2"><span className="h-2 w-2 bg-leather" aria-hidden="true" />Areas to improve</h3>
                <ExpandableList items={report.weaknesses} icon={AlertTriangle} iconClass="text-leather" empty="No areas to improve recorded." />
              </div>
            </div>
          </section>

          <section aria-labelledby="coaching" className="rule-top mt-10 scroll-mt-28 pt-8">
            <SectionHeader id="coaching" index="04" title="Coaching note" />
            {report.coaching_feedback ? <p className="t-coach">{report.coaching_feedback}</p> : <p className="text-sm text-ink-3">No coaching note for this session.</p>}
          </section>

          <section aria-labelledby="drills" className="rule-top mt-10 scroll-mt-28 pt-8">
            <SectionHeader id="drills" index="05" title="Corrections & drills" description="Recommended for the areas above." />
            {drills.length ? (
              <ol className="divide-y divide-line border-y border-line">
                {drills.map((d, i) => (
                  <li key={d} className="flex gap-4 py-3">
                    <span className="t-data pt-0.5 text-pitch">{String(i + 1).padStart(2, "0")}</span>
                    <span>{d}</span>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="text-sm text-ink-3">No drills were recommended for this session.</p>
            )}
            <div className="mt-6 flex flex-wrap gap-2">
              <Button to="/practice" variant="secondary" iconRight={ArrowRight}>Practice plan</Button>
              <Button to={`/skills?category=${report.type || ""}`} variant="ghost" iconRight={ArrowRight}>Drill demonstrations in Skills</Button>
            </div>
          </section>

          <aside className="mt-12 rounded-md bg-night p-6 text-night-ink" data-surface="night">
            <p className="t-label !text-night-ink-3">Next</p>
            <p className="t-section mt-2">Talk this report through with your coach</p>
            <p className="mt-2 max-w-lg text-sm text-night-ink-3">The AI coach reads this report and draws on coaching manuals to answer questions about your technique.</p>
            <Button to={`/coach?analysis=${id}`} variant="inverse" className="mt-4" icon={MessagesSquare}>Open AI coach</Button>
          </aside>
        </div>
      </div>
    </article>
  );
}
