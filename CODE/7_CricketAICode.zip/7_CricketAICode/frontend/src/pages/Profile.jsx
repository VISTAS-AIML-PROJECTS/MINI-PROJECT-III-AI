import { useCallback, useState } from "react";
import { ArrowRight, Pencil, Upload } from "lucide-react";

import { getCurrentUser } from "../services/authService";
import { getDashboardOverview } from "../services/dashboardService";
import { getHistory } from "../services/historyService";
import { updateProfile } from "../services/profileService";
import { PLAYING_ROLES, SKILL_LEVELS } from "../utils/constants";
import { useResource } from "../lib/useResource";
import { describeError } from "../lib/errors";
import { initials } from "../lib/format";
import { round } from "../lib/scoring";

import Button from "../ui/Button";
import { SectionHeader } from "../ui/Layout";
import { Field, Input, Select } from "../ui/Field";
import { Dialog, useToast } from "../ui/Overlay";
import { PageLoading, ErrorState, EmptyState, InlineAlert } from "../ui/States";
import SessionTable from "../components/performance/SessionTable";

async function loadProfile() {
  const me = await getCurrentUser();
  if (!me.success) {
    const err = new Error(me.message);
    err.response = { status: 0, data: { detail: me.message } };
    throw err;
  }
  const [overview, history] = await Promise.all([getDashboardOverview(), getHistory()]);
  return { user: me.data, overview, history };
}

function EditProfile({ open, user, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: user.name || "",
    playingRole: user.playingRole || PLAYING_ROLES[0],
    skillLevel: user.skillLevel || SKILL_LEVELS[0],
  });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function save(e) {
    e.preventDefault();
    if (!form.name.trim()) {
      setError("Enter your name.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const updated = await updateProfile({ ...form, name: form.name.trim() });
      onSaved(updated);
    } catch (err) {
      setError(describeError(err, "Couldn't save your profile.").message);
    } finally {
      setSaving(false);
    }
  }

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <Dialog open={open} onClose={onClose} title="Edit profile" labelledBy="edit-profile-title">
      <form onSubmit={save} className="space-y-4" noValidate>
        <Field label="Full name" required error={error && !form.name.trim() ? error : undefined}>
          {(p) => <Input {...p} value={form.name} onChange={set("name")} autoComplete="name" />}
        </Field>
        <Field label="Playing role">
          {(p) => <Select {...p} value={form.playingRole} onChange={set("playingRole")} options={PLAYING_ROLES} />}
        </Field>
        <Field label="Level">
          {(p) => <Select {...p} value={form.skillLevel} onChange={set("skillLevel")} options={SKILL_LEVELS} />}
        </Field>
        {error && form.name.trim() && <InlineAlert>{error}</InlineAlert>}
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" loading={saving}>Save changes</Button>
        </div>
      </form>
    </Dialog>
  );
}

export default function Profile() {
  const notify = useToast();
  const loader = useCallback(loadProfile, []);
  const { data, error, loading, reload } = useResource(loader, []);
  const [editing, setEditing] = useState(false);
  const [userOverride, setUserOverride] = useState(null);

  if (loading) return <PageLoading label="Loading profile" />;
  if (error) return <ErrorState error={error} onRetry={reload} />;

  const { overview, history } = data;
  const user = userOverride || data.user;
  const disciplines = ["batting", "bowling"]
    .map((t) => ({ t, n: history.filter((h) => h.analysis_type === t && h.status === "completed").length }))
    .filter((d) => d.n > 0);

  return (
    <>
      <header className="mb-10 grid gap-6 border-b border-line pb-8 md:grid-cols-[auto_1fr_auto] md:items-end">
        <div
          aria-hidden="true"
          className="flex h-24 w-24 items-center justify-center rounded-sm bg-night font-display text-4xl font-semibold text-night-ink"
        >
          {initials(user.name)}
        </div>
        <div className="min-w-0">
          <p className="t-label mb-2">Player profile</p>
          <h1 className="t-page">{user.name}</h1>
          <dl className="mt-4 flex flex-wrap gap-x-8 gap-y-2 text-sm">
            <div><dt className="t-label">Role</dt><dd className="mt-0.5 font-medium">{user.playingRole || "Not set"}</dd></div>
            <div><dt className="t-label">Level</dt><dd className="mt-0.5 font-medium">{user.skillLevel || "Not set"}</dd></div>
            <div className="min-w-0"><dt className="t-label">Email</dt><dd className="t-data mt-0.5 truncate">{user.email}</dd></div>
          </dl>
        </div>
        <Button variant="secondary" icon={Pencil} onClick={() => setEditing(true)}>Edit profile</Button>
      </header>

      <section aria-labelledby="record-h">
        <SectionHeader id="record-h" title="Performance record" />
        <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-md border border-line bg-line md:grid-cols-5">
          {[
            ["Latest score", round(overview.skill_score)],
            ["Best score", round(overview.best_score)],
            ["Average", round(overview.average_score)],
            ["Sessions", overview.total_analyses],
            ["Day streak", overview.practice_streak_days],
          ].map(([label, value]) => (
            <div key={label} className="bg-surface px-5 py-4">
              <dt className="t-label">{label}</dt>
              <dd className="t-figure mt-2 text-[2.5rem]">{overview.total_analyses ? value ?? "—" : "—"}</dd>
            </div>
          ))}
        </dl>
        {disciplines.length > 0 && (
          <p className="mt-3 text-sm text-ink-3">
            {disciplines.map((d) => `${d.n} ${d.t} session${d.n === 1 ? "" : "s"}`).join(" · ")}
          </p>
        )}
      </section>

      <section aria-labelledby="hist-h" className="rule-top mt-10 pt-8">
        <SectionHeader
          id="hist-h"
          title="Analysis history"
          action={history.length > 5 && <Button to="/analysis" variant="ghost" size="sm" iconRight={ArrowRight}>All {history.length}</Button>}
        />
        {history.length ? (
          <SessionTable sessions={history.slice(0, 5)} caption="Recent analysis sessions" />
        ) : (
          <EmptyState title="No analyses yet" action={<Button to="/upload" icon={Upload}>Analyse a video</Button>} />
        )}
        {history.length > 0 && (
          <Button to="/progress" variant="secondary" className="mt-5" iconRight={ArrowRight}>View progress trends</Button>
        )}
      </section>

      {editing && (
        <EditProfile
          open={editing}
          user={user}
          onClose={() => setEditing(false)}
          onSaved={(u) => {
            setUserOverride(u);
            setEditing(false);
            notify("Profile updated", "success");
          }}
        />
      )}
    </>
  );
}
