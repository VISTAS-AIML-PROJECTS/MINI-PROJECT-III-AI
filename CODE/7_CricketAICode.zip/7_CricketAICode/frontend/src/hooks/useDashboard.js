import { useEffect, useState } from "react";
import {
  getDashboardOverview,
  getWeeklyProgress,
} from "../services/dashboardService";

export function useDashboard() {
  const [overview, setOverview] = useState(null);
  const [weeklyProgress, setWeeklyProgress] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const [overviewData, weeklyData] = await Promise.all([
          getDashboardOverview(),
          getWeeklyProgress(),
        ]);

        setOverview(overviewData);
        setWeeklyProgress(weeklyData);
      } catch (err) {
        console.error("Dashboard load failed:", err);
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, []);

  return {
    overview,
    weeklyProgress,
    loading,
  };
}
