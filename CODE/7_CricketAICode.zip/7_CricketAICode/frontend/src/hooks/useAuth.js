import * as authService from "../services/authService";

export function useAuth() {
  return {
    register: authService.register,
    login: authService.login,
    logout: authService.logout,
  };
}
