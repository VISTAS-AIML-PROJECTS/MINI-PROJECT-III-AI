import api from "./axios";

export const uploadVideo = async (file) => {
    const formData = new FormData();

    formData.append("video", file);

    const response = await api.post(
        "/analysis/upload",
        formData
    );

    return response.data;
};

export const getAnalysis = async (id) => {
    const response = await api.get(
        `/analysis/${id}`
    );

    return response.data;
};

export const getHistory = async () => {
    const response = await api.get(
        "/analysis/history"
    );

    return response.data;
};
