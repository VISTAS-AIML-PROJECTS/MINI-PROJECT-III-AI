import { useId, useRef } from "react";

/**
 * Accessible tabs (WAI-ARIA tabs pattern with automatic activation).
 * Controlled: pass `value` and `onChange`. Render the active panel with
 * <TabPanel> using the ids from `tabIds(baseId, value)`.
 */
export function Tabs({ label, tabs, value, onChange, baseId: baseProp, className = "" }) {
  const auto = useId();
  const baseId = baseProp || auto;
  const refs = useRef({});

  function onKeyDown(e) {
    const index = tabs.findIndex((t) => t.value === value);
    let next = null;
    if (e.key === "ArrowRight") next = (index + 1) % tabs.length;
    if (e.key === "ArrowLeft") next = (index - 1 + tabs.length) % tabs.length;
    if (e.key === "Home") next = 0;
    if (e.key === "End") next = tabs.length - 1;
    if (next === null) return;
    e.preventDefault();
    onChange(tabs[next].value);
    refs.current[tabs[next].value]?.focus();
  }

  return (
    <div
      role="tablist"
      aria-label={label}
      onKeyDown={onKeyDown}
      className={`flex gap-6 overflow-x-auto border-b border-line ${className}`}
    >
      {tabs.map((t) => {
        const selected = t.value === value;
        return (
          <button
            key={t.value}
            ref={(el) => (refs.current[t.value] = el)}
            role="tab"
            type="button"
            id={`${baseId}-tab-${t.value}`}
            aria-selected={selected}
            aria-controls={`${baseId}-panel`}
            tabIndex={selected ? 0 : -1}
            onClick={() => onChange(t.value)}
            className={`touch-target -mb-px flex min-h-11 shrink-0 items-center gap-2 border-b-2 text-sm font-medium transition-colors ${
              selected
                ? "border-ink text-ink"
                : "border-transparent text-ink-3 hover:text-ink"
            }`}
          >
            {t.label}
            {typeof t.count === "number" && (
              <span className="t-data text-xs text-ink-3">{t.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

export function TabPanel({ baseId, value, children, className = "" }) {
  return (
    <div
      role="tabpanel"
      id={`${baseId}-panel`}
      aria-labelledby={`${baseId}-tab-${value}`}
      tabIndex={0}
      className={`focus-visible:outline-offset-4 ${className}`}
    >
      {children}
    </div>
  );
}
