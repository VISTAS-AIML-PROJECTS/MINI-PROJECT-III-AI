import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { X, CheckCircle2, AlertTriangle, Info } from "lucide-react";

/* ------------------------------------------------------------------ */
/* Dialog — native <dialog> opened with showModal() (inert background,  */
/* Esc / platform close requests, focus handled by the browser).        */
/* ------------------------------------------------------------------ */

export function Dialog({ open, onClose, title, children, actions, variant = "dlg", labelledBy }) {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (open && !el.open) el.showModal();
    if (!open && el.open) el.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      className={variant}
      aria-labelledby={labelledBy || "dialog-title"}
      onClose={onClose}
      onClick={(e) => {
        // Light dismiss on backdrop click (progressive: closedby="any").
        if (e.target === ref.current) onClose?.();
      }}
      closedby="any"
    >
      <div className="p-5 sm:p-6">
        {title && (
          <div className="mb-3 flex items-start justify-between gap-4">
            <h2 id={labelledBy || "dialog-title"} className="t-section">
              {title}
            </h2>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="-mr-2 -mt-1 flex min-h-10 min-w-10 items-center justify-center rounded-sm text-ink-3 hover:bg-sunken hover:text-ink"
            >
              <X size={18} aria-hidden="true" />
            </button>
          </div>
        )}
        {children}
        {actions && <div className="mt-6 flex flex-wrap justify-end gap-2">{actions}</div>}
      </div>
    </dialog>
  );
}

/* ------------------------------------------------------------------ */
/* Toasts — popover="manual" so they persist and stack; announced via  */
/* a single polite live region.                                        */
/* ------------------------------------------------------------------ */

const ToastContext = createContext(() => {});
const supportsPopover =
  typeof HTMLElement !== "undefined" && "popover" in HTMLElement.prototype;

const TONES = {
  success: { border: "border-l-pitch", icon: CheckCircle2, color: "text-pitch" },
  error: { border: "border-l-leather", icon: AlertTriangle, color: "text-leather" },
  info: { border: "border-l-ink-3", icon: Info, color: "text-ink-2" },
};

function ToastItem({ toast, index, onDismiss }) {
  const ref = useRef(null);
  const tone = TONES[toast.tone] || TONES.info;
  const Icon = tone.icon;

  useEffect(() => {
    const el = ref.current;
    if (supportsPopover && el && !el.matches(":popover-open")) el.showPopover();
    const timer = setTimeout(() => onDismiss(toast.id), toast.duration ?? 5000);
    return () => clearTimeout(timer);
  }, [toast, onDismiss]);

  return (
    <div
      ref={ref}
      popover={supportsPopover ? "manual" : undefined}
      data-open={supportsPopover ? undefined : ""}
      className={`toast ${tone.border}`}
      style={{ bottom: `calc(1rem + ${index} * 4.75rem)` }}
    >
      <div className="flex items-start gap-3">
        <Icon size={18} className={`mt-0.5 shrink-0 ${tone.color}`} aria-hidden="true" />
        <p className="flex-1 text-sm font-medium">{toast.message}</p>
        <button
          type="button"
          onClick={() => onDismiss(toast.id)}
          aria-label="Dismiss notification"
          className="-m-1.5 flex min-h-8 min-w-8 items-center justify-center rounded-sm text-ink-3 hover:bg-sunken hover:text-ink"
        >
          <X size={15} aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [announcement, setAnnouncement] = useState("");

  const dismiss = useCallback((id) => {
    setToasts((list) => list.filter((t) => t.id !== id));
  }, []);

  const notify = useCallback((message, tone = "info", duration) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((list) => [...list.slice(-2), { id, message, tone, duration }]);
    setAnnouncement(message);
  }, []);

  return (
    <ToastContext.Provider value={notify}>
      {children}
      <div aria-live="polite" role="status" className="visually-hidden">
        {announcement}
      </div>
      {toasts.map((t, i) => (
        <ToastItem key={t.id} toast={t} index={toasts.length - 1 - i} onDismiss={dismiss} />
      ))}
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
}
