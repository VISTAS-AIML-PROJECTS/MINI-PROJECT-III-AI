import { bandFor } from "../lib/scoring";

const TONE_TEXT = {
  pitch: "text-pitch",
  amber: "text-amber",
  leather: "text-leather",
  neutral: "text-ink-2",
};

const TONE_BADGE = {
  pitch: "border-pitch/30 bg-pitch-tint text-pitch-strong",
  amber: "border-amber/30 bg-amber-tint text-amber",
  leather: "border-leather/30 bg-leather-tint text-leather",
  neutral: "border-line-2 bg-paper text-ink-2",
  ink: "border-ink bg-ink text-white",
};

const TONE_BAR = {
  pitch: "bg-pitch",
  amber: "bg-amber-bar",
  leather: "bg-leather",
  neutral: "bg-ink-3",
};

/** Status badge — square-cornered tag, not a pill. */
export function Badge({ tone = "neutral", children, className = "" }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-xs border px-1.5 py-0.5 text-[11px] font-semibold uppercase tracking-[0.06em] ${TONE_BADGE[tone]} ${className}`}
    >
      {children}
    </span>
  );
}

/** Band badge derived from a 0–100 score. */
export function BandBadge({ score }) {
  const band = bandFor(score);
  if (!band) return null;
  return <Badge tone={band.tone}>{band.label}</Badge>;
}

/**
 * Metric display: label, large figure, optional unit and supporting line.
 * size: "xl" (hero score), "lg" (headline stats), "md" (inline stats).
 */
export function Metric({ label, value, unit, size = "lg", tone, sub, className = "" }) {
  const figure = { xl: "text-[5.5rem] sm:text-[7rem]", lg: "text-5xl", md: "text-[2rem]" }[size];
  return (
    <div className={className}>
      <p className="t-label">{label}</p>
      <p className={`mt-2 flex items-baseline gap-1 ${tone ? TONE_TEXT[tone] : "text-ink"}`}>
        <span className={`t-figure ${figure}`}>{value ?? "—"}</span>
        {unit && value != null && <span className="t-data text-sm text-ink-3">{unit}</span>}
      </p>
      {sub && <div className="mt-2 text-[13px] text-ink-3">{sub}</div>}
    </div>
  );
}

/**
 * Horizontal meter for a 0–100 value. Colour comes from the score band
 * unless `tone` is set. Includes an accessible meter role.
 */
export function Meter({ value, label, tone, height = "h-1.5", className = "", showTicks = false }) {
  const v = Math.max(0, Math.min(100, Number(value) || 0));
  const t = tone || bandFor(v)?.tone || "neutral";
  return (
    <div
      role="meter"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(v)}
      aria-label={label}
      className={`relative w-full overflow-hidden rounded-xs bg-sunken ${height} ${className}`}
    >
      <div
        className={`h-full ${TONE_BAR[t]} transition-[width] duration-500 ease-[var(--ease-standard)]`}
        style={{ width: `${v}%` }}
      />
      {showTicks && (
        <>
          <span aria-hidden="true" className="absolute inset-y-0 left-1/2 w-px bg-paper" />
          <span aria-hidden="true" className="absolute inset-y-0 left-3/4 w-px bg-paper" />
        </>
      )}
    </div>
  );
}

/** Delta indicator, e.g. +6 since previous session. */
export function Delta({ value, suffix = "" }) {
  if (typeof value !== "number") return null;
  const tone = value > 0 ? "text-pitch" : value < 0 ? "text-leather" : "text-ink-3";
  const sign = value > 0 ? "+" : value < 0 ? "−" : "±";
  return (
    <span className={`t-data font-medium ${tone}`}>
      {sign}
      {Math.abs(value)}
      {suffix}
    </span>
  );
}
