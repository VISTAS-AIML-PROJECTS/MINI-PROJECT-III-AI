import { AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";

export function Spinner({ size = 16, className = "" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      className={`spin ${className}`}
    >
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

/** Indeterminate progress bar for work of unknown duration. */
export function IndeterminateBar({ label }) {
  return (
    <div
      role="progressbar"
      aria-label={label}
      className="relative h-1 w-full overflow-hidden rounded-xs bg-sunken"
    >
      <div className="indeterminate absolute inset-y-0 w-2/5 bg-pitch" />
    </div>
  );
}

/** Page-level loading placeholder shaped like content (not a spinner wall). */
export function PageLoading({ label = "Loading" }) {
  return (
    <div role="status" aria-live="polite" className="space-y-6">
      <span className="visually-hidden">{label}…</span>
      <div className="skeleton h-3 w-28" />
      <div className="skeleton h-10 w-72 max-w-full" />
      <div className="grid gap-4 md:grid-cols-3">
        <div className="skeleton h-32" />
        <div className="skeleton h-32" />
        <div className="skeleton h-32" />
      </div>
      <div className="skeleton h-56" />
    </div>
  );
}

export function SkeletonRows({ rows = 4 }) {
  return (
    <div aria-hidden="true" className="space-y-3">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="skeleton h-12" />
      ))}
    </div>
  );
}

/**
 * Empty state: says what's missing and the one action that fixes it.
 */
export function EmptyState({ title, body, action, icon: Icon, className = "" }) {
  return (
    <div className={`flex flex-col items-start gap-3 rounded-md border border-dashed border-line-2 px-6 py-10 sm:items-center sm:text-center ${className}`}>
      {Icon && <Icon size={22} className="text-ink-3" aria-hidden="true" />}
      <h2 className="t-sub text-base">{title}</h2>
      {body && <p className="max-w-md text-sm text-ink-3">{body}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

/**
 * Error state with retry. `error` is the object from describeError().
 */
export function ErrorState({ error, onRetry, title = "Couldn't load this page" }) {
  return (
    <div role="alert" className="flex flex-col items-start gap-3 rounded-md border border-leather/30 bg-leather-tint px-5 py-5">
      <div className="flex items-center gap-2 text-leather">
        <AlertTriangle size={18} aria-hidden="true" />
        <h2 className="t-sub">{error?.expired ? "Session expired" : title}</h2>
      </div>
      <p className="text-sm text-ink-2">{error?.message}</p>
      <div className="flex gap-2">
        {error?.expired ? (
          <Link
            to="/login"
            className="inline-flex min-h-9 items-center rounded-sm border border-ink bg-ink px-3 text-sm font-medium text-white"
          >
            Sign in
          </Link>
        ) : (
          onRetry && (
            <button
              type="button"
              onClick={onRetry}
              className="inline-flex min-h-9 items-center rounded-sm border border-line-2 bg-surface px-3 text-sm font-medium text-ink hover:border-ink-3"
            >
              Try again
            </button>
          )
        )}
      </div>
    </div>
  );
}

/** Inline alert for form-level messages. */
export function InlineAlert({ tone = "leather", children }) {
  const styles = {
    leather: "border-leather/30 bg-leather-tint text-leather",
    pitch: "border-pitch/30 bg-pitch-tint text-pitch-strong",
    neutral: "border-line-2 bg-paper text-ink-2",
  }[tone];
  return (
    <div role={tone === "leather" ? "alert" : "status"} className={`rounded-sm border px-3 py-2.5 text-sm font-medium ${styles}`}>
      {children}
    </div>
  );
}
