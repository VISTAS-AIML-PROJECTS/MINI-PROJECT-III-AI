// Page structure primitives: page header, section header, panel.

/** Top of every app page: eyebrow, title, optional lede and actions. */
export function PageHeader({ eyebrow, title, lede, actions, children }) {
  return (
    <header className="mb-8 flex flex-col gap-5 border-b border-line pb-6 md:flex-row md:items-end md:justify-between">
      <div className="min-w-0">
        {eyebrow && <p className="t-label mb-2">{eyebrow}</p>}
        <h1 className="t-page">{title}</h1>
        {lede && <p className="mt-3 max-w-2xl text-ink-2">{lede}</p>}
        {children}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap gap-2">{actions}</div>}
    </header>
  );
}

/** Numbered/labelled section heading used inside pages and reports. */
export function SectionHeader({ index, title, id, description, action, as: Tag = "h2" }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div className="min-w-0">
        <Tag id={id} className="t-section flex items-baseline gap-3">
          {index && <span className="t-data text-sm font-medium text-pitch">{index}</span>}
          <span>{title}</span>
        </Tag>
        {description && <p className="mt-1 text-sm text-ink-3">{description}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

/**
 * Panel: a bordered surface. Use only to group related information —
 * report sections sit directly on the page separated by rules instead.
 */
export function Panel({ as: Tag = "div", className = "", padded = true, children, ...rest }) {
  return (
    <Tag
      className={`rounded-md border border-line bg-surface ${padded ? "p-5 sm:p-6" : ""} ${className}`}
      {...rest}
    >
      {children}
    </Tag>
  );
}

/** Definition-list row for key/value technical data. */
export function DataRow({ label, children }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-line py-2.5 last:border-b-0">
      <dt className="text-sm text-ink-3">{label}</dt>
      <dd className="text-right text-sm font-medium text-ink">{children}</dd>
    </div>
  );
}
