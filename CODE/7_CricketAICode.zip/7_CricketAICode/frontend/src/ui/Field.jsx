import { forwardRef, useId, useState } from "react";
import { Eye, EyeOff } from "lucide-react";

const CONTROL =
  "w-full rounded-sm border bg-surface px-3 text-[15px] text-ink placeholder:text-ink-4 " +
  "transition-colors hover:border-ink-3 focus-visible:border-pitch disabled:bg-sunken disabled:text-ink-3";

function describedBy(hintId, errorId, hint, error) {
  return [hint && hintId, error && errorId].filter(Boolean).join(" ") || undefined;
}

/**
 * Label + control + hint + error, wired with for/id and aria-describedby.
 * Pass `children` as a render function receiving the control props to
 * build custom controls.
 */
export function Field({ label, hint, error, id: idProp, required, children, className = "" }) {
  const autoId = useId();
  const id = idProp || autoId;
  const hintId = `${id}-hint`;
  const errorId = `${id}-error`;
  const controlProps = {
    id,
    required,
    "aria-invalid": error ? true : undefined,
    "aria-describedby": describedBy(hintId, errorId, hint, error),
  };

  return (
    <div className={className}>
      <label htmlFor={id} className="t-label mb-1.5 block !text-ink-2">
        {label}
        {required && <span className="text-leather" aria-hidden="true"> *</span>}
      </label>
      {hint && (
        <p id={hintId} className="mb-1.5 text-[13px] text-ink-3">
          {hint}
        </p>
      )}
      {children(controlProps)}
      {error && (
        <p id={errorId} className="mt-1.5 text-[13px] font-medium text-leather">
          {error}
        </p>
      )}
    </div>
  );
}

export const Input = forwardRef(function Input({ invalid, className = "", ...rest }, ref) {
  return (
    <input
      ref={ref}
      className={`${CONTROL} min-h-11 ${rest["aria-invalid"] || invalid ? "border-leather" : "border-control"} ${className}`}
      {...rest}
    />
  );
});

export function PasswordInput(props) {
  const [visible, setVisible] = useState(false);
  return (
    <div className="relative">
      <Input {...props} type={visible ? "text" : "password"} className="pr-12" />
      <button
        type="button"
        onClick={() => setVisible((v) => !v)}
        aria-label={visible ? "Hide password" : "Show password"}
        aria-pressed={visible}
        className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-ink-3 hover:text-ink"
      >
        {visible ? <EyeOff size={17} aria-hidden="true" /> : <Eye size={17} aria-hidden="true" />}
      </button>
    </div>
  );
}

export const Select = forwardRef(function Select({ options = [], className = "", ...rest }, ref) {
  return (
    <select
      ref={ref}
      className={`${CONTROL} min-h-11 appearance-none border-control bg-[length:16px] bg-[right_0.75rem_center] bg-no-repeat pr-10 ${className}`}
      style={{
        backgroundImage:
          "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%235c626b' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")",
      }}
      {...rest}
    >
      {options.map((o) => {
        const value = typeof o === "string" ? o : o.value;
        const label = typeof o === "string" ? o : o.label;
        return (
          <option key={value} value={value}>
            {label}
          </option>
        );
      })}
    </select>
  );
});

export const Textarea = forwardRef(function Textarea({ className = "", ...rest }, ref) {
  return (
    <textarea
      ref={ref}
      className={`${CONTROL} border-control py-2.5 leading-normal ${className}`}
      {...rest}
    />
  );
});

/**
 * Segmented choice built on native radio inputs (arrow keys work natively).
 */
export function Segmented({ legend, name, value, onChange, options, className = "" }) {
  return (
    <fieldset className={className}>
      <legend className="t-label mb-1.5 !text-ink-2">{legend}</legend>
      <div className="grid auto-cols-fr grid-flow-col rounded-sm border border-control bg-surface p-0.5">
        {options.map((o) => {
          const checked = value === o.value;
          return (
            <label
              key={o.value}
              className={`touch-target relative flex min-h-10 items-center justify-center gap-2 rounded-xs px-3 text-sm font-medium transition-colors has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-1 has-[:focus-visible]:outline-pitch ${
                checked ? "bg-ink text-white" : "text-ink-2 hover:bg-sunken"
              }`}
            >
              <input
                type="radio"
                name={name}
                value={o.value}
                checked={checked}
                onChange={() => onChange(o.value)}
                className="sr-only"
              />
              {o.label}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}
