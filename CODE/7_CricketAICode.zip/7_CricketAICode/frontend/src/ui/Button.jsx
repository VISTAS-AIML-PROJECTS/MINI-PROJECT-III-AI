import { forwardRef } from "react";
import { Link } from "react-router-dom";
import { Spinner } from "./States";

const BASE =
  "touch-target inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm border font-medium " +
  "transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-50 aria-disabled:opacity-50";

const VARIANTS = {
  primary:
    "border-pitch bg-pitch text-white hover:border-pitch-strong hover:bg-pitch-strong",
  secondary:
    "border-line-2 bg-surface text-ink hover:border-ink-3 hover:bg-paper",
  ghost:
    "border-transparent bg-transparent text-ink-2 hover:bg-sunken hover:text-ink",
  danger:
    "border-leather bg-surface text-leather hover:bg-leather-tint",
  inverse:
    "border-night-ink bg-night-ink text-night hover:bg-white",
};

const SIZES = {
  sm: "min-h-8 px-3 text-[13px]",
  md: "min-h-10 px-4 text-sm",
  lg: "min-h-12 px-5 text-[15px]",
};

const ICON_SIZE = { sm: 14, md: 16, lg: 18 };

/**
 * Product button. Renders a router <Link> when `to` is given.
 * Variants: primary (one per view), secondary, ghost, danger, inverse.
 */
const Button = forwardRef(function Button(
  {
    variant = "primary",
    size = "md",
    to,
    icon: Icon,
    iconRight: IconRight,
    loading = false,
    className = "",
    children,
    type = "button",
    disabled,
    ...rest
  },
  ref
) {
  const cls = `${BASE} ${VARIANTS[variant]} ${SIZES[size]} ${className}`;
  const iconSize = ICON_SIZE[size];
  const content = (
    <>
      {loading ? (
        <Spinner size={iconSize} />
      ) : (
        Icon && <Icon size={iconSize} aria-hidden="true" strokeWidth={2} />
      )}
      {children}
      {IconRight && !loading && (
        <IconRight size={iconSize} aria-hidden="true" strokeWidth={2} />
      )}
    </>
  );

  if (to) {
    return (
      <Link ref={ref} to={to} className={cls} {...rest}>
        {content}
      </Link>
    );
  }

  return (
    <button
      ref={ref}
      type={type}
      className={cls}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...rest}
    >
      {content}
    </button>
  );
});

export default Button;

/** Square icon-only button; `label` is required for screen readers. */
export function IconButton({ icon: Icon, label, className = "", size = 18, ...rest }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className={`touch-target inline-flex min-h-10 min-w-10 items-center justify-center rounded-sm text-ink-2 transition-colors hover:bg-sunken hover:text-ink ${className}`}
      {...rest}
    >
      <Icon size={size} aria-hidden="true" />
    </button>
  );
}
