import api from "./api";

/**
 * Ask CricketAI Coach
 *
 * @param {string} analysisId
 * @param {string} message
 * @returns {Promise<Object>}
 */
export async function askCoach(analysisId, message) {
  try {
    const response = await api.post("/chat", {
      analysis_id: analysisId,
      message: message,
    });

    return response.data;
  } catch (error) {
    console.error("Chat API Error:", error);

    if (error.response) {
      console.error("Status:", error.response.status);
      console.error("Response:", error.response.data);
    }

    throw error;
  }
}

/**
 * Get chat history
 */
export async function getChatHistory(analysisId) {
  try {
    const response = await api.get(`/chat/${analysisId}`);
    return response.data;
  } catch (error) {
    console.error("History Error:", error);

    if (error.response) {
      console.error("Status:", error.response.status);
      console.error("Response:", error.response.data);
    }

    throw error;
  }
}

/**
 * Clear chat history
 */
export async function clearChat(analysisId) {
  try {
    await api.delete(`/chat/${analysisId}`);
  } catch (error) {
    console.error("Clear Chat Error:", error);

    if (error.response) {
      console.error("Status:", error.response.status);
      console.error("Response:", error.response.data);
    }

    throw error;
  }
}
