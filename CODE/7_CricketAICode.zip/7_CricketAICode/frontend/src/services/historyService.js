import api from "./api";

export async function getHistory() {
  const response = await api.get("/video/history");
  return response.data;
}

export async function getAnalysis(id) {
  const response = await api.get(`/video/${id}`);
  return response.data;
}
