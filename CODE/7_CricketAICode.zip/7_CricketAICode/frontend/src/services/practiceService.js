import api from "./api";

// Existing endpoints: GET /api/practice/{period}, PATCH /api/practice/{period}/{item_id}
export async function getPlan(period) {
  const response = await api.get(`/practice/${period}`);
  return response.data;
}

export async function setPlanItemDone(period, itemId, done) {
  const response = await api.patch(`/practice/${period}/${itemId}`, { done });
  return response.data;
}
