import api from "./api";

export async function uploadVideo(
  file,
  analysisType,
  battingSide,
  onProgress,
  bowlingArm,
  bowlingStyle
) {
  const formData = new FormData();

  formData.append("file", file);
  formData.append("analysis_type", analysisType);

  if (battingSide) {
    formData.append("side", battingSide);
  }

  if (analysisType === "bowling") {
    formData.append("bowling_arm", bowlingArm);
    formData.append("bowling_style", bowlingStyle);
  }

  const response = await api.post(
    "/video/upload",
    formData,
    {
      headers: {
        "Content-Type": "multipart/form-data",
      },

      onUploadProgress: (event) => {
        if (event.total) {
          const percent = Math.round(
            (event.loaded * 100) / event.total
          );

          onProgress(percent);
        }
      },
    }
  );

  return response.data;
}
