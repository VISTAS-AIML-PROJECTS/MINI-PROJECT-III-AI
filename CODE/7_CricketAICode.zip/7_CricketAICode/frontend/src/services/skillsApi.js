import api from "./api";

// The backend serves skill lesson videos as static files at /media.
// Relative (empty) so it goes through the same Vite proxy / reverse
// proxy as /api, instead of hardcoding localhost:8000.
export const MEDIA_BASE_URL = "";

export async function getSkills(category) {
  const response = await api.get("/skills", {
    params: category ? { category } : {},
  });
  return response.data;
}

export async function getSkill(skillId) {
  const response = await api.get(`/skills/${skillId}`);
  return response.data;
}

