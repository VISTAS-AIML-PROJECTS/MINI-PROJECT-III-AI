import api from "./api";

// --------------------
// Register
// --------------------
export async function register(data) {
  try {
    const response = await api.post("/auth/register", data);

    // Save JWT token
    localStorage.setItem("token", response.data.token);

    // Save logged-in user
    localStorage.setItem(
      "user",
      JSON.stringify(response.data.user)
    );

    return {
      success: true,
      ...response.data,
    };
  } catch (err) {
    return {
      success: false,
      message:
        err.response?.data?.detail ||
        "Registration failed",
    };
  }
}

// --------------------
// Login
// --------------------
export async function login(data) {
  try {
    const response = await api.post("/auth/login", data);

    // Save JWT token
    localStorage.setItem("token", response.data.token);

    // Save logged-in user
    localStorage.setItem(
      "user",
      JSON.stringify(response.data.user)
    );

    return {
      success: true,
      ...response.data,
    };
  } catch (err) {
    return {
      success: false,
      message:
        err.response?.data?.detail ||
        "Login failed",
    };
  }
}

// --------------------
// Logout
// --------------------
export function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
}

// --------------------
// Fetch Current User
// --------------------
export async function getCurrentUser() {
  try {
    const response = await api.get("/auth/me");

    localStorage.setItem(
      "user",
      JSON.stringify(response.data)
    );

    return {
      success: true,
      data: response.data,
    };
  } catch (err) {
    return {
      success: false,
      message:
        err.response?.data?.detail ||
        "Failed to fetch user profile",
    };
  }
}

// --------------------
// Local Storage Helpers
// --------------------
export function getSavedUser() {
  const user = localStorage.getItem("user");
  return user ? JSON.parse(user) : null;
}

export function saveUser(user) {
  localStorage.setItem(
    "user",
    JSON.stringify(user)
  );
}

export function isLoggedIn() {
  return !!localStorage.getItem("token");
}
