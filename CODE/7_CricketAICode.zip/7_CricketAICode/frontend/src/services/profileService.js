import api from "./api";
import { saveUser } from "./authService";

// Existing endpoint: PATCH /api/auth/profile → UserOut
export async function updateProfile(changes) {
  const response = await api.patch("/auth/profile", changes);
  saveUser(response.data);
  return response.data;
}
