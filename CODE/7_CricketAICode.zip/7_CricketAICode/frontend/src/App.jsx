import { BrowserRouter, Navigate, Outlet, Route, Routes } from "react-router-dom";

import ProtectedRoute from "./components/auth/ProtectedRoute";
import AppShell from "./components/shell/AppShell";

import Home from "./pages/Home";
import About from "./pages/About";
import Login from "./pages/Login";
import Register from "./pages/Register";

import Dashboard from "./pages/Dashboard";
import AnalysisList from "./pages/AnalysisList";
import Upload from "./pages/Upload";
import Analysis from "./pages/Analysis";
import Coach from "./pages/Coach";
import Practice from "./pages/Practice";
import Skills from "./pages/Skills";
import SkillDetail from "./pages/SkillDetail";
import Progress from "./pages/Progress";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";

function ProtectedShell() {
  return (
    <ProtectedRoute>
      <AppShell>
        <Outlet />
      </AppShell>
    </ProtectedRoute>
  );
}

export default function App() {
  return (
    // basename follows Vite's `base` so routes work under /CricketAI/.
    <BrowserRouter basename={import.meta.env.BASE_URL.replace(/\/$/, "")}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route element={<ProtectedShell />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/analysis" element={<AnalysisList />} />
          <Route path="/analysis/:id" element={<Analysis />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="/coach" element={<Coach />} />
          <Route path="/practice" element={<Practice />} />
          <Route path="/skills" element={<Skills />} />
          <Route path="/skills/:skillId" element={<SkillDetail />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />

          {/* Previous URLs */}
          <Route path="/history" element={<Navigate to="/analysis" replace />} />
          <Route path="/planner" element={<Navigate to="/practice" replace />} />
          <Route path="/leaderboard" element={<Navigate to="/progress" replace />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
