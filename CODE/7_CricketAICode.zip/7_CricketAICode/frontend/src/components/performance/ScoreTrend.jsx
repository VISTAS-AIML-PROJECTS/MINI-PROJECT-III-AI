import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { formatDate } from "../../lib/format";

const INK3 = "#5c626b";
const LINE = "#dfddd5";
const PITCH = "#1d6a42";

function TrendTooltip({ active, payload }) {
  if (!active || !payload?.length) return null;
  const p = payload[0].payload;
  return (
    <div className="rounded-sm border border-line bg-surface px-3 py-2 text-sm shadow-sm">
      <p className="t-data text-ink-3">{formatDate(p.date)}</p>
      <p className="font-medium capitalize">
        {p.type} · <span className="t-figure text-lg">{p.score}</span>
      </p>
    </div>
  );
}

/**
 * Technique score over sessions (chronological). Only completed sessions
 * with a score are plotted; each point is one real analysis.
 * Includes a visually-hidden data table as the text alternative.
 */
export default function ScoreTrend({ points, height = 220, compact = false, title = "Technique score by session" }) {
  const data = points.map((p, i) => ({ ...p, n: i + 1 }));
  const avg = data.length
    ? Math.round(data.reduce((s, p) => s + p.score, 0) / data.length)
    : null;

  return (
    <figure>
      <div style={{ height }} aria-hidden="true">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={data}
            accessibilityLayer={false}
            margin={{ top: 8, right: 8, bottom: 0, left: compact ? -28 : -12 }}
          >
            <CartesianGrid stroke={LINE} vertical={false} />
            <XAxis
              dataKey="n"
              tick={{ fill: INK3, fontSize: 11, fontFamily: "IBM Plex Mono" }}
              tickLine={false}
              axisLine={{ stroke: LINE }}
              hide={compact}
            />
            <YAxis
              domain={[0, 100]}
              ticks={[0, 50, 75, 100]}
              tick={{ fill: INK3, fontSize: 11, fontFamily: "IBM Plex Mono" }}
              tickLine={false}
              axisLine={false}
              width={40}
            />
            <ReferenceLine y={75} stroke={PITCH} strokeDasharray="3 4" strokeOpacity={0.5} />
            <Tooltip content={<TrendTooltip />} cursor={{ stroke: LINE }} />
            <Line
              type="linear"
              dataKey="score"
              stroke="#14161a"
              strokeWidth={2}
              dot={{ r: 3, fill: "#14161a", strokeWidth: 0 }}
              activeDot={{ r: 5, fill: PITCH, strokeWidth: 0 }}
              isAnimationActive={!window.matchMedia?.("(prefers-reduced-motion: reduce)").matches}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <figcaption className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-3">
        <span>{title}. {data.length} session{data.length === 1 ? "" : "s"}{avg != null ? `, average ${avg}` : ""}.</span>
        <span className="inline-flex items-center gap-1.5">
          <span aria-hidden="true" className="inline-block w-4 border-t border-dashed border-pitch" />
          75 = strong band
        </span>
      </figcaption>
      <table className="visually-hidden">
        <caption>{title}</caption>
        <thead>
          <tr><th scope="col">Session</th><th scope="col">Date</th><th scope="col">Type</th><th scope="col">Score</th></tr>
        </thead>
        <tbody>
          {data.map((p) => (
            <tr key={p.n}><td>{p.n}</td><td>{formatDate(p.date)}</td><td>{p.type}</td><td>{p.score}</td></tr>
          ))}
        </tbody>
      </table>
    </figure>
  );
}

/** A completed session where the body was actually tracked. Sessions with
 *  0% tracking confidence carry a placeholder score of 0, not a real
 *  assessment, so trends leave them out (and say so). */
export function isScored(a) {
  return a.status === "completed" && typeof a.technique_score === "number" && (a.confidence ?? 0) > 0;
}

/** Build chronological trend points from the history API response. */
export function trendPoints(history = [], type) {
  return history
    .filter(isScored)
    .filter((a) => !type || a.analysis_type === type)
    .map((a) => ({ id: a.id, date: a.created_at, score: Math.round(a.technique_score), type: a.analysis_type || "analysis" }))
    .reverse();
}
