import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

import { BandBadge, Badge } from "../../ui/Data";
import { formatDate } from "../../lib/format";
import { analysisLabel, round } from "../../lib/scoring";

const STATUS = {
  processing: { tone: "amber", label: "Processing" },
  failed: { tone: "leather", label: "Failed" },
};

/**
 * Sessions list. A real <table> on wide screens; stacked rows on narrow
 * screens (same DOM, so screen readers always get a table).
 */
export default function SessionTable({ sessions, caption = "Analysis sessions", compact = false }) {
  return (
    <div className="overflow-hidden rounded-md border border-line bg-surface">
      <table className="w-full border-collapse text-left">
        <caption className="visually-hidden">{caption}</caption>
        <thead className="hidden bg-paper sm:table-header-group">
          <tr className="border-b border-line">
            <th scope="col" className="t-label px-4 py-2.5 font-semibold">Date</th>
            <th scope="col" className="t-label px-4 py-2.5 font-semibold">Session</th>
            {!compact && <th scope="col" className="t-label px-4 py-2.5 font-semibold">Confidence</th>}
            <th scope="col" className="t-label px-4 py-2.5 text-right font-semibold">Score</th>
            <th scope="col" className="px-2 py-2.5"><span className="visually-hidden">Open</span></th>
          </tr>
        </thead>
        <tbody>
          {sessions.map((s) => {
            const score = round(s.technique_score ?? s.score);
            const status = STATUS[s.status];
            return (
              <tr
                key={s.id}
                className="group relative grid grid-cols-[1fr_auto] items-center gap-x-4 border-b border-line px-4 py-3 last:border-b-0 hover:bg-paper sm:table-row sm:p-0"
              >
                <td className="t-data text-ink-3 sm:px-4 sm:py-3 sm:whitespace-nowrap">
                  {formatDate(s.created_at)}
                </td>
                <td className="col-start-1 font-medium text-ink sm:px-4 sm:py-3">
                  <Link
                    to={`/analysis/${s.id}`}
                    className="inline-flex min-h-6 items-center after:absolute after:inset-0 after:content-[''] focus-visible:outline-offset-[-2px]"
                  >
                    {analysisLabel(s)}
                  </Link>
                </td>
                {!compact && (
                  <td className="t-data hidden text-ink-2 sm:table-cell sm:px-4 sm:py-3">
                    {s.confidence != null ? `${round(s.confidence)}%` : "—"}
                  </td>
                )}
                <td className="col-start-2 row-span-2 row-start-1 text-right sm:px-4 sm:py-3">
                  {status ? (
                    <Badge tone={status.tone}>{status.label}</Badge>
                  ) : (
                    <span className="inline-flex items-center gap-3">
                      <span className="hidden sm:inline"><BandBadge score={score} /></span>
                      <span className="t-figure w-10 text-[1.75rem]">{score ?? "—"}</span>
                    </span>
                  )}
                </td>
                <td className="hidden pr-3 text-ink-4 sm:table-cell">
                  <ChevronRight size={16} aria-hidden="true" className="group-hover:text-ink" />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
