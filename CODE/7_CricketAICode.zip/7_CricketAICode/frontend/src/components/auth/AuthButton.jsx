export default function AuthButton({
  children,
  loading,
}) {
  return (
    <button
      type="submit"
      disabled={loading}
      className="
        w-full
        rounded-xl
        bg-yellow-400
        py-3
        font-semibold
        text-slate-900
        transition
        duration-200
        hover:bg-yellow-300
        disabled:opacity-50
      "
    >
      {loading ? "Please wait..." : children}
    </button>
  );
}
