import AuthBrandPanel from "./AuthBrandPanel";
import Container from "../common/Container";

export default function AuthLayout({
  title,
  subtitle,
  children,
}) {
  return (
    <div className="min-h-screen bg-surface-sidebar">

      <Container className="grid min-h-screen lg:grid-cols-2 gap-16">

        <AuthBrandPanel />

        <div className="flex items-center justify-center">

          <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-[#111827] p-10 shadow-2xl">

            <h2 className="text-4xl font-bold text-white">
              {title}
            </h2>

            <p className="mt-2 text-slate-400">
              {subtitle}
            </p>

            <div className="mt-8">
              {children}
            </div>

          </div>

        </div>

      </Container>

    </div>
  );
}
