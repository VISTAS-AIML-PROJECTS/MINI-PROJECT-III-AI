export default function AuthSelect({
  label,
  name,
  value,
  onChange,
  options,
}) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-slate-300">
        {label}
      </label>

      <select
        name={name}
        value={value}
        onChange={onChange}
        className="
          w-full
          rounded-xl
          border
          border-slate-700
          bg-[#0F172A]
          px-4
          py-3
          text-white
          outline-none
          transition
          duration-200
          focus:border-yellow-400
          focus:ring-2
          focus:ring-yellow-400/20
        "
      >
        {options.map((option) => (
          <option key={option}>{option}</option>
        ))}
      </select>
    </div>
  );
}
