import {
  Brain,
  Trophy,
  BarChart3,
  CalendarDays,
} from "lucide-react";

export default function AuthBrandPanel() {
  const features = [
    {
      icon: Brain,
      text: "AI Cricket Coach",
    },
    {
      icon: Trophy,
      text: "Video Technique Analysis",
    },
    {
      icon: BarChart3,
      text: "Performance Dashboard",
    },
    {
      icon: CalendarDays,
      text: "Practice Planner",
    },
  ];

  return (
    <div className="hidden lg:flex flex-col justify-center bg-surface-sidebar">

      <p className="text-yellow-400 tracking-[0.35em] uppercase text-sm font-semibold">
        JOIN CRICKETAI
      </p>

      <h1 className="mt-6 text-6xl font-bold leading-tight text-white">
        Train Smarter
        <br />
        With AI Coaching
      </h1>

      <p className="mt-8 text-lg leading-8 text-slate-400 max-w-md">
        Create your account and start receiving AI-powered cricket
        coaching, personalized practice plans and performance tracking.
      </p>

      <div className="mt-12 space-y-7">

        {features.map(({ icon: Icon, text }) => (
          <div
            key={text}
            className="flex items-center gap-4 text-white"
          >
            <Icon className="w-6 h-6 text-yellow-400" />
            <span className="text-xl">{text}</span>
          </div>
        ))}

      </div>

    </div>
  );
}
