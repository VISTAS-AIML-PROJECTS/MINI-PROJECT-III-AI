export default function AuthInput({
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
}) {
  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-slate-300">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="
          w-full
          rounded-xl
          border
          border-slate-700
          bg-[#0F172A]
          px-4
          py-3
          text-white
          placeholder:text-slate-500
          outline-none
          transition
          duration-200
          focus:border-yellow-400
          focus:ring-2
          focus:ring-yellow-400/20
        "
      />
    </div>
  );
}
