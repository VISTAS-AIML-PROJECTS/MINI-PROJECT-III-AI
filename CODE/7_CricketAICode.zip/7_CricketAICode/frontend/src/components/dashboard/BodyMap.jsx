import { bandFor } from "../../lib/scoring";

// Fill/stroke per band; segments without measures stay neutral.
const TONE = {
  pitch: "fill-pitch-tint stroke-pitch",
  amber: "fill-amber-tint stroke-amber",
  leather: "fill-leather-tint stroke-leather",
  none: "fill-sunken stroke-line-2",
};

function toneOf(group) {
  if (!group?.items.length) return "none";
  return bandFor(group.items[0].value)?.tone || "none"; // items sorted lowest first
}

/**
 * Body-segment map of the pose measures. Each segment is coloured by its
 * lowest-scoring measure. The figure is decorative-free: the segment
 * buttons beside it carry the same information and act as filters.
 */
export default function BodyMap({ groups, selected, onSelect }) {
  const by = Object.fromEntries(groups.map((g) => [g.key, g]));
  const cls = (key) =>
    `${TONE[toneOf(by[key])]} transition-opacity duration-200 ${
      selected && selected !== key ? "opacity-25" : "opacity-100"
    }`;

  const buttons = groups.filter((g) => g.key !== "other" || g.items.length);

  return (
    <div className="flex items-start gap-4">
      <svg viewBox="0 0 120 200" className="h-40 w-24 shrink-0" aria-hidden="true" strokeWidth="2">
        <circle cx="60" cy="20" r="13" className={cls("head")} />
        <rect x="43" y="40" width="34" height="62" rx="7" className={cls("rotation")} />
        <rect x="24" y="42" width="14" height="58" rx="7" transform="rotate(8 31 42)" className={cls("upper")} />
        <rect x="82" y="42" width="14" height="58" rx="7" transform="rotate(-8 89 42)" className={cls("upper")} />
        <rect x="44" y="106" width="14" height="80" rx="7" className={cls("lower")} />
        <rect x="62" y="106" width="14" height="80" rx="7" className={cls("lower")} />
      </svg>

      <div className="min-w-0 flex-1">
        <p className="t-label mb-2" id="segments-label">Pose segments</p>
        <div role="group" aria-labelledby="segments-label" className="flex flex-col gap-1">
          <button
            type="button"
            aria-pressed={!selected}
            onClick={() => onSelect(null)}
            className={`flex min-h-8 items-center justify-between rounded-xs px-2 text-left text-sm ${
              !selected ? "bg-ink text-white" : "text-ink-2 hover:bg-sunken"
            }`}
          >
            All measures
            <span className="t-data text-xs">{groups.reduce((n, g) => n + g.items.length, 0)}</span>
          </button>
          {buttons.map((g) => {
            const low = g.items[0]?.value;
            const tone = toneOf(g);
            return (
              <button
                key={g.key}
                type="button"
                aria-pressed={selected === g.key}
                onClick={() => onSelect(selected === g.key ? null : g.key)}
                className={`flex min-h-8 items-center justify-between gap-2 rounded-xs px-2 text-left text-sm ${
                  selected === g.key ? "bg-ink text-white" : "text-ink-2 hover:bg-sunken"
                }`}
              >
                <span className="flex min-w-0 items-center gap-2">
                  <span
                    aria-hidden="true"
                    className={`h-2 w-2 shrink-0 ${tone === "pitch" ? "bg-pitch" : tone === "amber" ? "bg-amber-bar" : tone === "leather" ? "bg-leather" : "bg-line-2"}`}
                  />
                  <span className="truncate">{g.label}</span>
                </span>
                <span className="t-data shrink-0 text-xs">
                  {low != null ? <>low {low}</> : "—"}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
