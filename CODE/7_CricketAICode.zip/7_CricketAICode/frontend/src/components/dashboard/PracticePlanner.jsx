import { motion } from "framer-motion";
import {
  CalendarDays,
  Clock3,
  CheckCircle2,
  PlayCircle,
} from "lucide-react";
import Badge from "../common/Badge";

const sessions = [
  {
    title: "Warm-up & Mobility",
    duration: "15 min",
    completed: true,
  },
  {
    title: "Bowling Accuracy Drill",
    duration: "30 min",
    completed: false,
  },
  {
    title: "Batting Footwork",
    duration: "25 min",
    completed: false,
  },
  {
    title: "Strength & Core",
    duration: "20 min",
    completed: false,
  },
];

export default function PracticePlanner() {
  const completed = sessions.filter((s) => s.completed).length;
  const progress = (completed / sessions.length) * 100;

  return (
    <motion.section
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="rounded-3xl border border-white/10 bg-surface-sidebar p-6"
    >
      {/* Header */}

      <div className="flex items-start justify-between">

        <div className="flex items-center gap-3">

          <div className="rounded-xl bg-gold-500/10 p-3">
            <CalendarDays
              size={20}
              className="text-gold-400"
            />
          </div>

          <div>

            <div className="flex items-center gap-2">
              <h2 className="text-xl font-semibold text-white">
                Practice Planner
              </h2>
              <Badge tone="neutral">Preview</Badge>
            </div>

            <p className="mt-1 text-sm text-slate-400">
              A sample of what personalized training plans will look like
            </p>

          </div>

        </div>

        <PlayCircle
          size={20}
          className="text-pitch-400"
        />

      </div>

      {/* Progress */}

      <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-4">

        <div className="mb-3 flex items-center justify-between">

          <span className="text-sm text-slate-400">
            Daily Progress
          </span>

          <span className="text-sm font-semibold text-white">
            {completed}/{sessions.length} Completed
          </span>

        </div>

        <div className="h-2 overflow-hidden rounded-full bg-white/10">

          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1 }}
            className="h-full rounded-full bg-gradient-to-r from-gold-500 to-leather-300"
          />

        </div>

      </div>

      {/* Session List */}

      <div className="mt-6">

        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-400">
          Training Sessions
        </h3>

        <div className="space-y-3">

          {sessions.map((session) => (

            <motion.div
              whileHover={{ x: 4 }}
              key={session.title}
              className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-gold-500/20"
            >

              <div className="flex items-center gap-3">

                {session.completed ? (

                  <div className="rounded-lg bg-pitch-500/10 p-2">

                    <CheckCircle2
                      size={16}
                      className="text-pitch-400"
                    />

                  </div>

                ) : (

                  <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-600">
                    <div className="h-2.5 w-2.5 rounded-full bg-slate-500" />
                  </div>

                )}

                <div>

                  <h3 className="text-sm font-semibold text-white">
                    {session.title}
                  </h3>

                  <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">

                    <Clock3 size={13} />

                    {session.duration}

                  </div>

                </div>

              </div>

            </motion.div>

          ))}

        </div>

      </div>

      {/* CTA */}

      <button
        disabled
        title="Coming soon"
        className="mt-7 flex w-full cursor-not-allowed items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 py-3.5 text-sm font-semibold text-slate-400"
      >
        <PlayCircle size={18} />

        Start Today's Practice — Coming Soon

      </button>

    </motion.section>
  );
}

