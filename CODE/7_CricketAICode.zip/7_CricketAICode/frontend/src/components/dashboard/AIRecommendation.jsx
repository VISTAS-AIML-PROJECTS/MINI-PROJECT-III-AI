import { motion } from "framer-motion";
import {
  Brain,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Target,
  AlertTriangle,
} from "lucide-react";

export default function AIRecommendation({ analysis }) {
  if (!analysis) {
    return (
      <motion.section
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="rounded-3xl border border-leather-500/20 bg-surface-sidebar p-6"
      >
        <div className="flex h-80 items-center justify-center text-slate-400">
          Upload a video to receive AI coaching insights.
        </div>
      </motion.section>
    );
  }

  const recommendations =
    analysis.recommended_drills?.length > 0
      ? analysis.recommended_drills
      : ["No recommendations available."];

  const strengths =
    analysis.strengths?.length > 0
      ? analysis.strengths
      : ["No strengths identified yet."];

  const weaknesses =
    analysis.weaknesses?.length > 0
      ? analysis.weaknesses
      : ["No weaknesses identified yet."];

  return (
    <motion.section
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="rounded-3xl border border-white/10 bg-surface-sidebar p-6"
    >
      {/* Header */}

      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-gold-500/10 p-3">
            <Brain
              size={20}
              className="text-gold-400"
            />
          </div>

          <div>
            <h2 className="text-xl font-semibold text-white">
              AI Coach
            </h2>

            <p className="mt-1 text-sm text-slate-400">
              Personalized coaching insights
            </p>
          </div>
        </div>

        <Sparkles
          size={18}
          className="text-gold-400"
        />
      </div>

      {/* AI Summary */}

      <div className="mt-6 rounded-2xl border border-gold-500/20 bg-gold-500/5 p-5">
        <div className="mb-3 flex items-center gap-2">
          <Brain
            size={16}
            className="text-gold-400"
          />

          <span className="text-sm font-medium text-gold-400">
            AI Summary
          </span>
        </div>

        <p className="text-sm leading-7 text-slate-300">
          {analysis.summary ||
            "No AI summary available."}
        </p>
      </div>

      {/* Coaching Feedback */}

      <div className="mt-6 rounded-2xl border border-gold-500/20 bg-gold-500/5 p-5">
        <div className="mb-3 flex items-center gap-2">
          <Target
            size={16}
            className="text-gold-400"
          />

          <span className="text-sm font-medium text-gold-400">
            Coach Feedback
          </span>
        </div>

        <p className="text-sm leading-7 text-slate-300">
          {analysis.coaching_feedback ||
            "No coaching feedback available."}
        </p>
      </div>

      {/* Strengths */}

      <div className="mt-7">
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-pitch-400">
          Strengths
        </h3>

        <div className="space-y-3">
          {strengths.map((item, index) => (
            <div
              key={index}
              className="flex items-start gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3"
            >
              <div className="mt-0.5 rounded-lg bg-pitch-500/10 p-2">
                <CheckCircle2
                  size={15}
                  className="text-pitch-400"
                />
              </div>

              <p className="text-sm text-slate-300">
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Weaknesses */}

      <div className="mt-7">
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-leather-400">
          Weaknesses
        </h3>

        <div className="space-y-3">
          {weaknesses.map((item, index) => (
            <div
              key={index}
              className="flex items-start gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3"
            >
              <div className="mt-0.5 rounded-lg bg-leather-500/10 p-2">
                <AlertTriangle
                  size={15}
                  className="text-leather-400"
                />
              </div>

              <p className="text-sm text-slate-300">
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Drills */}

      <div className="mt-7">
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-400">
          Recommended Drills
        </h3>

        <div className="space-y-3">
          {recommendations.map((item, index) => (
            <div
              key={index}
              className="flex items-start gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3 transition hover:border-gold-500/20"
            >
              <div className="mt-0.5 rounded-lg bg-gold-500/10 p-2">
                <CheckCircle2
                  size={15}
                  className="text-gold-400"
                />
              </div>

              <p className="text-sm leading-6 text-slate-300">
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Today's Focus */}

      <div className="mt-7 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gold-500/10 p-2">
              <Target
                size={18}
                className="text-gold-400"
              />
            </div>

            <div>
              <p className="text-xs uppercase tracking-wide text-slate-500">
                Today's Focus
              </p>

              <h3 className="mt-1 font-semibold text-white">
                {recommendations[0]}
              </h3>
            </div>
          </div>

          <button className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-gold-600 to-leather-400 px-4 py-2 text-sm font-medium text-white transition hover:scale-105">
            Start

            <ArrowRight size={15} />
          </button>
        </div>
      </div>
    </motion.section>
  );
}

