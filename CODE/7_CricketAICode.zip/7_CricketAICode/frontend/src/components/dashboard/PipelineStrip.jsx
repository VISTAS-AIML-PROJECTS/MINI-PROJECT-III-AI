import { Check, X, AlertTriangle } from "lucide-react";
import { Spinner } from "../../ui/States";

/*
  The analysis pipeline for one upload:
  Upload → Processing → Pose detection → Technique → AI feedback → Practice.
  Each step's state and value come from API data for that upload.

  state: "done" | "active" | "failed" | "warn" | "pending"
*/

const MARK = {
  done: "border-pitch bg-pitch text-white",
  active: "border-amber bg-amber-tint text-amber",
  failed: "border-leather bg-leather text-white",
  warn: "border-amber bg-amber-tint text-amber",
  pending: "border-line-2 bg-surface text-ink-3",
};

const STATE_TEXT = {
  done: "complete",
  active: "in progress",
  failed: "failed",
  warn: "needs attention",
  pending: "not started",
};

function Mark({ state, n }) {
  return (
    <span
      aria-hidden="true"
      className={`t-data relative z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-xs border text-xs ${MARK[state]}`}
    >
      {state === "done" ? (
        <Check size={14} strokeWidth={2.5} />
      ) : state === "failed" ? (
        <X size={14} strokeWidth={2.5} />
      ) : state === "warn" ? (
        <AlertTriangle size={13} />
      ) : state === "active" ? (
        <Spinner size={13} />
      ) : (
        n
      )}
    </span>
  );
}

export default function PipelineStrip({ steps }) {
  return (
    <ol
      aria-label="Analysis pipeline for your latest upload"
      className="grid grid-cols-2 gap-px overflow-hidden rounded-md border border-line bg-line sm:grid-cols-3 xl:grid-cols-6"
    >
      {steps.map((s, i) => {
        const Tag = s.href ? "a" : "div";
        return (
          <li key={s.key} className="bg-surface">
            <Tag
              {...(s.href ? { href: s.href } : {})}
              className={`group relative flex h-full flex-col gap-2 px-4 py-3.5 ${s.href ? "hover:bg-paper" : ""}`}
            >
              {/* Connector to the next stage (desktop row only). */}
              {i < steps.length - 1 && (
                <span
                  aria-hidden="true"
                  className={`absolute left-[2.75rem] right-0 top-[1.75rem] hidden h-px xl:block ${
                    s.state === "done" ? "bg-pitch" : "bg-line-2"
                  }`}
                />
              )}
              <div className="flex items-center gap-2">
                <Mark state={s.state} n={i + 1} />
              </div>
              <p className="t-label !text-ink-2">
                {s.label}
                <span className="visually-hidden">: {STATE_TEXT[s.state]}.</span>
              </p>
              <p className={`text-sm font-medium leading-snug ${s.state === "pending" ? "text-ink-3" : "text-ink"}`}>
                {s.value}
              </p>
              {s.detail && <p className="text-xs leading-snug text-ink-3">{s.detail}</p>}
            </Tag>
          </li>
        );
      })}
    </ol>
  );
}
