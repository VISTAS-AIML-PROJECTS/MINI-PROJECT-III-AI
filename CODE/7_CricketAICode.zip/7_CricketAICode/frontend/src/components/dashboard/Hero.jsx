import { motion } from "framer-motion";
import {
  ArrowRight,
  History,
  Sparkles,
  TrendingUp,
  Target,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Hero({ user, overview }) {
  const playerName = user?.name || "Player";

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="relative overflow-hidden rounded-3xl border border-white/10 bg-surface-sidebar p-8"
    >
      {/* Background Glow */}
      <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-gold-500/10 blur-[100px]" />

      <div className="relative z-10 flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
        {/* Left Section */}
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold-500/20 bg-gold-500/10 px-3 py-1.5 text-xs font-medium text-gold-300">
            <Sparkles size={14} />
            AI Cricket Coach
          </div>

          <h1 className="mt-5 text-3xl font-bold tracking-tight text-white">
            Welcome back,
            <br />
            {playerName} 👋
          </h1>

          <p className="mt-4 max-w-xl text-sm leading-7 text-slate-400">
            Continue improving your cricket skills with AI-powered analysis,
            personalized coaching and performance tracking.
          </p>

          {/* Quick Stats */}

          <div className="mt-8 flex flex-wrap gap-4">
            <div className="rounded-xl border border-white/10 bg-white/5 px-5 py-3">
              <p className="text-xs uppercase text-slate-400">
                Technique
              </p>

              <p className="mt-1 text-xl font-bold text-gold-400">
                {overview?.skill_score ?? 0}%
              </p>
            </div>

            <div className="rounded-xl border border-white/10 bg-white/5 px-5 py-3">
              <p className="text-xs uppercase text-slate-400">
                Analyses
              </p>

              <p className="mt-1 text-xl font-bold text-white">
                {overview?.total_analyses ?? 0}
              </p>
            </div>

            <div className="rounded-xl border border-white/10 bg-white/5 px-5 py-3">
              <p className="text-xs uppercase text-slate-400">
                Confidence
              </p>

              <p className="mt-1 text-xl font-bold text-pitch-400">
                {overview?.average_confidence ?? 0}%
              </p>
            </div>
          </div>
        </div>

        {/* Right Section */}

        <div className="flex flex-col gap-4">
          <Link
            to="/upload"
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-gold-600 to-leather-400 px-6 py-3 text-sm font-semibold text-white transition hover:scale-105"
          >
            Upload New Video
            <ArrowRight size={18} />
          </Link>

          <Link
            to="/history"
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-6 py-3 text-sm font-medium text-slate-300 transition hover:bg-white/10 hover:text-white"
          >
            <History size={18} />
            View History
          </Link>

          <div className="mt-2 rounded-xl border border-gold-500/20 bg-gold-500/5 p-4">
            <div className="flex items-center gap-3">
              <Target
                size={18}
                className="text-gold-400"
              />

              <div>
                <p className="text-xs uppercase text-slate-400">
                  Best Score
                </p>

                <p className="font-semibold text-white">
                  {overview?.best_score ?? 0}%
                </p>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-3">
              <TrendingUp
                size={18}
                className="text-pitch-400"
              />

              <div>
                <p className="text-xs uppercase text-slate-400">
                  Improvement
                </p>

                <p className="font-semibold text-pitch-400">
                  {overview?.skill_score_delta >= 0 ? "+" : ""}
                  {overview?.skill_score_delta ?? 0}%
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.section>
  );
}
