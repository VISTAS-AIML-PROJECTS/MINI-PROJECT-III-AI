import { TrendingUp, TrendingDown } from "lucide-react";
import Card from "../common/Card";
import ProgressBar from "../common/ProgressBar";

const TONES = {
  gold: { bg: "bg-gold-500/10", text: "text-gold-400", border: "border-gold-500/20" },
  pitch: { bg: "bg-pitch-500/10", text: "text-pitch-400", border: "border-pitch-500/20" },
  leather: { bg: "bg-leather-500/10", text: "text-leather-400", border: "border-leather-500/20" },
  neutral: { bg: "bg-white/5", text: "text-slate-300", border: "border-white/10" },
};

export default function StatsCard({
  title,
  value,
  change,
  icon,
  tone = "gold",
  percent,
}) {
  const theme = TONES[tone] || TONES.gold;
  const positive = typeof change === "string" && change.startsWith("+");

  return (
    <Card
      tier="primary"
      className="group transition-colors hover:border-gold-500/20"
    >
      <div className="flex items-start justify-between">
        <div
          className={`flex h-11 w-11 items-center justify-center rounded-xl border ${theme.border} ${theme.bg} ${theme.text}`}
        >
          {icon}
        </div>

        <div
          className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${
            positive
              ? "bg-pitch-500/10 text-pitch-400"
              : "bg-white/5 text-slate-400"
          }`}
        >
          {positive ? <TrendingUp size={12} /> : null}
          {change}
        </div>
      </div>

      <div className="mt-6">
        <p className="text-sm font-medium text-slate-400">{title}</p>
        <h2 className="mt-2 text-3xl font-bold tracking-tight tabular-nums text-white">
          {value}
        </h2>
      </div>

      {typeof percent === "number" && (
        <ProgressBar value={percent} tone={tone === "neutral" ? "gold" : tone} className="mt-5" />
      )}
    </Card>
  );
}
