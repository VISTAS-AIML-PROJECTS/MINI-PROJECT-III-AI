import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import {
  ArrowRight,
  Calendar,
  TrendingUp,
  CheckCircle2,
  Target,
  Sparkles,
} from "lucide-react";

export default function RecentAnalysis({ analysis }) {
  const navigate = useNavigate();

  if (!analysis) {
    return (
      <motion.section
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="rounded-3xl border border-white/10 bg-surface-sidebar p-6"
      >
        <div className="flex h-72 items-center justify-center text-slate-400">
          No analysis uploaded yet.
        </div>
      </motion.section>
    );
  }

  const formattedDate = new Date(
    analysis.created_at
  ).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

  return (
    <motion.section
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="rounded-3xl border border-white/10 bg-surface-sidebar p-6"
    >
      {/* Header */}

      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-gold-500/10 p-2">
            <Sparkles
              size={18}
              className="text-gold-400"
            />
          </div>

          <div>
            <h2 className="text-xl font-semibold text-white">
              Latest Analysis
            </h2>

            <p className="mt-1 text-sm text-slate-400">
              {analysis.analysis_type} Session
            </p>
          </div>
        </div>

        <button
          onClick={() => navigate(`/analysis/${analysis.id}`)}
          className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300 transition hover:bg-white/10 hover:text-white"
        >
          View

          <ArrowRight size={15} />
        </button>
      </div>

      {/* Metrics */}

      <div className="mt-6 grid gap-3">
        <InfoCard
          icon={<Target size={16} />}
          label="Technique Score"
          value={`${analysis.score}%`}
        />

        <InfoCard
          icon={<TrendingUp size={16} />}
          label="AI Confidence"
          value={`${analysis.confidence}%`}
        />

        <InfoCard
          icon={<Calendar size={16} />}
          label="Analysis Date"
          value={formattedDate}
        />
      </div>

      {/* Progress */}

      <div className="mt-7">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm text-slate-400">
            Overall Performance
          </span>

          <span className="text-sm font-semibold text-gold-400">
            {analysis.score}%
          </span>
        </div>

        <div className="h-2 overflow-hidden rounded-full bg-white/10">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${analysis.score}%` }}
            transition={{ duration: 1 }}
            className="h-full rounded-full bg-gradient-to-r from-gold-500 to-leather-300"
          />
        </div>
      </div>

      {/* Summary */}

      <div className="mt-8 rounded-2xl border border-gold-500/20 bg-gold-500/5 p-4">
        <h3 className="mb-2 text-sm font-semibold text-gold-400">
          Latest Result
        </h3>

        <p className="text-sm text-slate-300">
          Your latest{" "}
          <span className="font-semibold text-white">
            {analysis.analysis_type.toLowerCase()}
          </span>{" "}
          analysis achieved a technique score of{" "}
          <span className="font-semibold text-gold-400">
            {analysis.score}%
          </span>{" "}
          with an AI confidence of{" "}
          <span className="font-semibold text-gold-400">
            {analysis.confidence}%
          </span>.
        </p>
      </div>

      {/* Status */}

      <div className="mt-7">
        <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-400">
          Analysis Status
        </h3>

        <div className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.03] p-3">
          <div className="rounded-lg bg-pitch-500/10 p-2">
            <CheckCircle2
              size={16}
              className="text-pitch-400"
            />
          </div>

          <span className="text-sm text-slate-300">
            Analysis completed successfully.
          </span>
        </div>
      </div>
    </motion.section>
  );
}

function InfoCard({ icon, label, value }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="rounded-lg bg-gold-500/10 p-2 text-gold-400">
          {icon}
        </div>

        <div>
          <p className="text-xs uppercase tracking-wide text-slate-500">
            {label}
          </p>

          <h3 className="mt-1 text-sm font-semibold text-white">
            {value}
          </h3>
        </div>
      </div>
    </div>
  );
}

