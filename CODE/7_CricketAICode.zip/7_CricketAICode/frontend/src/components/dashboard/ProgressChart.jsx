import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";

export default function ProgressChart({ data = [] }) {
  return (
    <div className="rounded-2xl border border-slate-700 bg-slate-900 p-6 shadow-xl">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">
            Weekly Progress
          </h2>

          <p className="mt-1 text-sm text-slate-400">
            Average technique score from your recent analyses
          </p>
        </div>
      </div>

      {/* Chart */}
      <div className="h-80">
        {data.length === 0 ? (
          <div className="flex h-full items-center justify-center text-slate-400">
            No analysis data available yet.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 15,
                right: 20,
                left: 0,
                bottom: 5,
              }}
            >
              <CartesianGrid
                stroke="#334155"
                strokeDasharray="4 4"
              />

              <XAxis
                dataKey="day"
                tick={{ fill: "#CBD5E1", fontSize: 12 }}
                axisLine={{ stroke: "#475569" }}
                tickLine={{ stroke: "#475569" }}
              />

              <YAxis
                domain={[0, 100]}
                tick={{ fill: "#CBD5E1", fontSize: 12 }}
                axisLine={{ stroke: "#475569" }}
                tickLine={{ stroke: "#475569" }}
              />

              <Tooltip
                cursor={{ stroke: "#FBBF24", strokeWidth: 1 }}
                contentStyle={{
                  backgroundColor: "#111827",
                  border: "1px solid #374151",
                  borderRadius: "12px",
                }}
                labelStyle={{
                  color: "#F8FAFC",
                  fontWeight: "bold",
                }}
                itemStyle={{
                  color: "#FBBF24",
                }}
              />

              <Line
                type="monotone"
                dataKey="score"
                stroke="#FBBF24"
                strokeWidth={3}
                dot={{
                  r: 5,
                  fill: "#FBBF24",
                  strokeWidth: 2,
                  stroke: "#0F172A",
                }}
                activeDot={{
                  r: 7,
                  fill: "#FBBF24",
                }}
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
