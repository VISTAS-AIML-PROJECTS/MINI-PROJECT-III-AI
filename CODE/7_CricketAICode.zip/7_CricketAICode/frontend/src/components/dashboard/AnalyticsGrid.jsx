import { Target, Sparkles, Video, Flame } from "lucide-react";
import StatsCard from "./StatsCard";

export default function AnalyticsGrid({ overview }) {
  if (!overview) {
    return (
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-32 animate-pulse rounded-2xl bg-white/5" />
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Technique Score",
      value: `${overview.skill_score}%`,
      change:
        overview.skill_score_delta >= 0
          ? `+${overview.skill_score_delta}%`
          : `${overview.skill_score_delta}%`,
      icon: <Target size={20} />,
      tone: "gold",
      percent: overview.skill_score,
    },
    {
      title: "AI Confidence",
      value: `${overview.average_confidence}%`,
      change: "Average",
      icon: <Sparkles size={20} />,
      tone: "pitch",
      percent: overview.average_confidence,
    },
    {
      title: "Videos Uploaded",
      value: overview.total_analyses,
      change: "Analyses",
      icon: <Video size={20} />,
      tone: "neutral",
    },
    {
      title: "Practice Streak",
      value: `${overview.practice_streak_days} Days`,
      change: "Current",
      icon: <Flame size={20} />,
      tone: "leather",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => (
        <StatsCard key={card.title} {...card} />
      ))}
    </div>
  );
}
