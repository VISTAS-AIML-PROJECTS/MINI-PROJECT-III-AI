import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Upload,
  History,
  CalendarDays,
  Bot,
  TrendingUp,
  Trophy,
  User,
  Settings,
  Menu,
  X,
  ChevronRight,
  BookOpen,
} from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";
import Logo from "../common/Logo";
import Badge from "../common/Badge";

const LIVE_ITEMS = [
  { title: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { title: "Upload Analysis", icon: Upload, path: "/upload" },
  { title: "History", icon: History, path: "/history" },
  { title: "AI Coach", icon: Bot, path: "/coach" },
  { title: "Skill Library", icon: BookOpen, path: "/skills" },
  { title: "Profile", icon: User, path: "/profile" },
];

const COMING_SOON_ITEMS = [
  { title: "Practice Plan", icon: CalendarDays, path: "/planner" },
  { title: "Progress", icon: TrendingUp, path: "/progress" },
  { title: "Leaderboard", icon: Trophy, path: "/leaderboard" },
  { title: "Settings", icon: Settings, path: "/settings" },
];

function NavItem({ item }) {
  const Icon = item.icon;

  return (
    <NavLink key={item.title} to={item.path}>
      {({ isActive }) => (
        <motion.div
          whileHover={{ x: 3 }}
          whileTap={{ scale: 0.98 }}
          className={`group flex items-center justify-between rounded-xl px-3 py-2.5 transition-all duration-200 ${
            isActive
              ? "bg-gradient-to-r from-gold-600/90 to-gold-500/90 text-white shadow-md shadow-gold-500/20"
              : "text-slate-400 hover:bg-white/5 hover:text-white"
          }`}
        >
          <div className="flex items-center gap-3">
            <Icon size={18} />
            <span className="text-[15px] font-medium">{item.title}</span>
          </div>

          <ChevronRight
            size={14}
            className={`transition-all ${
              isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100"
            }`}
          />
        </motion.div>
      )}
    </NavLink>
  );
}

export default function Sidebar() {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Mobile Menu */}
      <button
        onClick={() => setOpen(true)}
        className="fixed left-5 top-5 z-50 rounded-xl border border-white/10 bg-surface-sidebar p-3 text-white lg:hidden"
      >
        <Menu size={20} />
      </button>

      {open && (
        <div
          onClick={() => setOpen(false)}
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden"
        />
      )}

      <motion.aside
        initial={{ x: -60, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.35 }}
        drag={open ? "x" : false}
        dragConstraints={{ left: -300, right: 0 }}
        dragElastic={0.05}
        onDragEnd={(_, info) => {
          if (info.offset.x < -80) setOpen(false);
        }}
        className={`
          fixed lg:relative z-50
          h-screen w-[280px]
          bg-surface-abyss
          border-r border-white/10
          flex flex-col
          transition-all duration-300
          ${open ? "left-0" : "-left-[300px]"}
          lg:left-0
        `}
      >
        {/* Close Button */}
        <button
          onClick={() => setOpen(false)}
          className="absolute right-5 top-5 text-slate-400 lg:hidden"
        >
          <X size={20} />
        </button>

        {/* Brand */}
        <div className="border-b border-white/10 px-6 py-6">
          <Logo />
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto px-4 py-6">
          <p className="mb-4 px-3 text-[11px] font-semibold uppercase tracking-[0.25em] text-slate-500">
            Navigation
          </p>

          <nav className="space-y-1.5">
            {LIVE_ITEMS.map((item) => (
              <NavItem key={item.title} item={item} />
            ))}
          </nav>

          <p className="mb-3 mt-7 flex items-center gap-2 px-3 text-[11px] font-semibold uppercase tracking-[0.25em] text-slate-600">
            Coming Soon
          </p>

          <nav className="space-y-1.5 opacity-60">
            {COMING_SOON_ITEMS.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.title}
                  to={item.path}
                  className="flex items-center justify-between rounded-xl px-3 py-2.5 text-slate-500 transition-colors hover:bg-white/5 hover:text-slate-300"
                >
                  <div className="flex items-center gap-3">
                    <Icon size={18} />
                    <span className="text-[15px] font-medium">{item.title}</span>
                  </div>

                  <Badge tone="neutral">Soon</Badge>
                </NavLink>
              );
            })}
          </nav>
        </div>
      </motion.aside>
    </>
  );
}
