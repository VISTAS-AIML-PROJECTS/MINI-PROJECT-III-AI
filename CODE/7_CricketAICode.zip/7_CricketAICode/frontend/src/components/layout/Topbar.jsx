import { ChevronDown, LogOut, User as UserIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { getSavedUser, logout } from "../../services/authService";
import { getRouteMeta } from "../../utils/routeMeta";
import { DURATION } from "../../theme/motion";

export default function Topbar() {
  const [user, setUser] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  const location = useLocation();
  const navigate = useNavigate();
  const { title, subtitle } = getRouteMeta(location.pathname);

  useEffect(() => {
    setUser(getSavedUser());
  }, []);

  useEffect(() => {
    function handleClickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const initials = user?.name
    ? user.name
        .split(" ")
        .map((word) => word[0])
        .join("")
        .toUpperCase()
    : "U";

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-surface-abyss/80 backdrop-blur-xl">
      <div className="flex h-auto min-h-20 flex-wrap items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <div className="ml-12 lg:ml-0">
          <h1 className="font-display text-2xl font-bold text-white md:text-3xl">
            {title}
          </h1>

          {subtitle && (
            <p className="text-sm text-slate-400">{subtitle}</p>
          )}
        </div>

        <div className="flex items-center gap-3" ref={menuRef}>
          <div className="relative">
            <motion.button
              whileHover={{ scale: 1.03 }}
              onClick={() => setMenuOpen((v) => !v)}
              className="flex cursor-pointer items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-3 py-2 sm:px-4"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-gold-600 to-leather-400 text-sm font-bold text-white">
                {initials}
              </div>

              <div className="hidden text-left lg:block">
                <h3 className="text-sm font-semibold text-white">
                  {user?.name || "Player"}
                </h3>

                <p className="text-xs text-slate-400">
                  {user?.role || "Cricket Player"}
                </p>
              </div>

              <ChevronDown
                className={`text-slate-400 transition-transform ${menuOpen ? "rotate-180" : ""}`}
                size={18}
              />
            </motion.button>

            <AnimatePresence>
              {menuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: DURATION.fast }}
                  className="absolute right-0 top-full mt-2 w-48 overflow-hidden rounded-xl border border-white/10 bg-surface-sidebar shadow-xl"
                >
                  <Link
                    to="/profile"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-4 py-3 text-sm text-slate-300 hover:bg-white/5 hover:text-white"
                  >
                    <UserIcon size={16} />
                    Profile
                  </Link>

                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center gap-2 px-4 py-3 text-left text-sm text-leather-300 hover:bg-white/5"
                  >
                    <LogOut size={16} />
                    Log out
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </header>
  );
}
