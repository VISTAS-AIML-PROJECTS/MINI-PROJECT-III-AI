import { Link } from "react-router-dom";

/** CricketAI wordmark: three stumps + condensed name. */
export default function Wordmark({ to = "/dashboard", tone = "night", className = "" }) {
  const night = tone === "night";
  const text = night ? "text-night-ink" : "text-ink";
  const accent = night ? "text-pitch-bright" : "text-pitch";
  return (
    <Link to={to} className={`inline-flex min-h-10 items-center gap-2.5 ${text} ${className}`} aria-label="CricketAI home">
      <svg width="18" height="20" viewBox="0 0 18 20" aria-hidden="true">
        <rect x="1" y="4" width="3" height="16" fill="currentColor" />
        <rect x="7.5" y="4" width="3" height="16" fill="currentColor" />
        <rect x="14" y="4" width="3" height="16" fill="currentColor" />
        <rect x="1" y="0.5" width="16" height="2" className={night ? "fill-pitch-bright" : "fill-pitch"} />
      </svg>
      <span className="font-display text-[1.375rem] font-semibold uppercase leading-none tracking-[0.04em]">
        Cricket<span className={accent}>AI</span>
      </span>
    </Link>
  );
}
