import {
  LayoutDashboard,
  ScanLine,
  MessagesSquare,
  ListChecks,
  BookOpen,
  TrendingUp,
  UserRound,
} from "lucide-react";

// Primary navigation. `match` lists the path prefixes that belong to the
// section so nested/related routes keep the section highlighted.
export const NAV = [
  { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard, match: ["/dashboard"] },
  { label: "Analysis", to: "/analysis", icon: ScanLine, match: ["/analysis", "/upload", "/history"] },
  { label: "AI Coach", to: "/coach", icon: MessagesSquare, match: ["/coach"] },
  { label: "Practice", to: "/practice", icon: ListChecks, match: ["/practice", "/planner"] },
  { label: "Skills", to: "/skills", icon: BookOpen, match: ["/skills"] },
  { label: "Progress", to: "/progress", icon: TrendingUp, match: ["/progress"] },
  { label: "Profile", to: "/profile", icon: UserRound, match: ["/profile", "/settings"] },
];

// Mobile bottom bar: the four most frequent destinations + "More".
export const MOBILE_PRIMARY = ["/dashboard", "/analysis", "/coach", "/practice"];

export function isActive(item, pathname) {
  return item.match.some((p) => pathname === p || pathname.startsWith(`${p}/`));
}

const TITLES = [
  ["/dashboard", "Dashboard"],
  ["/upload", "New analysis"],
  ["/analysis/", "Analysis report"],
  ["/analysis", "Analysis"],
  ["/history", "Analysis"],
  ["/coach", "AI Coach"],
  ["/practice", "Practice"],
  ["/planner", "Practice"],
  ["/skills/", "Skill"],
  ["/skills", "Skill library"],
  ["/progress", "Progress"],
  ["/profile", "Profile"],
  ["/settings", "Settings"],
];

export function documentTitle(pathname) {
  const hit = TITLES.find(([p]) => pathname.startsWith(p));
  return hit ? `${hit[1]} · CricketAI` : "CricketAI";
}
