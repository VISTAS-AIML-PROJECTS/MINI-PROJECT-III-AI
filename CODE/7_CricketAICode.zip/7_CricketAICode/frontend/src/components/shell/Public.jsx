import { Link, NavLink } from "react-router-dom";
import Wordmark from "./Wordmark";
import { isLoggedIn } from "../../services/authService";

export function PublicHeader() {
  const authed = isLoggedIn();
  return (
    <header data-surface="night" className="bg-night text-night-ink">
      <div className="mx-auto flex h-16 max-w-[1240px] items-center justify-between gap-4 px-4 sm:px-6 lg:px-10">
        <Wordmark to="/" />
        <nav aria-label="Main" className="flex items-center gap-1 sm:gap-2">
          <NavLink
            to="/about"
            className={({ isActive }) =>
              `hidden min-h-10 items-center rounded-sm px-3 text-sm sm:inline-flex ${isActive ? "text-white" : "text-night-ink-3 hover:text-night-ink"}`
            }
          >
            How it works
          </NavLink>
          {authed ? (
            <Link to="/dashboard" className="inline-flex min-h-10 items-center rounded-sm bg-pitch px-4 text-sm font-medium text-white hover:bg-pitch-strong">
              Open dashboard
            </Link>
          ) : (
            <>
              <Link to="/login" className="inline-flex min-h-10 items-center rounded-sm px-3 text-sm text-night-ink-3 hover:text-night-ink">
                Sign in
              </Link>
              <Link to="/register" className="inline-flex min-h-10 items-center rounded-sm bg-pitch px-4 text-sm font-medium text-white hover:bg-pitch-strong">
                Create account
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}

export function PublicFooter() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex max-w-[1240px] flex-col gap-3 px-4 py-8 text-sm text-ink-3 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-10">
        <Wordmark to="/" tone="paper" />
        <nav aria-label="Footer" className="flex gap-5">
          <Link to="/about" className="inline-flex min-h-10 items-center hover:text-ink">How it works</Link>
          <Link to="/login" className="inline-flex min-h-10 items-center hover:text-ink">Sign in</Link>
          <Link to="/register" className="inline-flex min-h-10 items-center hover:text-ink">Create account</Link>
        </nav>
      </div>
    </footer>
  );
}

/** Two-column frame for sign-in / registration. */
export function AuthFrame({ title, lede, children, footer }) {
  return (
    <div className="grid min-h-dvh lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
      <aside data-surface="night" className="hidden flex-col justify-between bg-night p-10 text-night-ink lg:flex">
        <Wordmark to="/" />
        <div>
          <p className="t-label !text-night-ink-3">Cricket performance analysis</p>
          <p className="t-page mt-4 max-w-md text-[3.25rem]">Every joint. Every frame. A plan to fix it.</p>
          <ul className="mt-10 space-y-4 border-t border-night-line pt-8 text-sm text-night-ink-3">
            <li className="flex gap-4"><span className="t-data text-pitch-bright">01</span>Pose-tracked technique scores for batting and bowling</li>
            <li className="flex gap-4"><span className="t-data text-pitch-bright">02</span>Biomechanics broken down by body segment</li>
            <li className="flex gap-4"><span className="t-data text-pitch-bright">03</span>An AI coach that knows your report</li>
            <li className="flex gap-4"><span className="t-data text-pitch-bright">04</span>Drills, training plan and progress tracking</li>
          </ul>
        </div>
        <p className="text-xs text-night-ink-3">For players, coaches and academies.</p>
      </aside>

      <main id="content" className="flex flex-col">
        <div data-surface="night" className="bg-night px-4 py-4 lg:hidden">
          <Wordmark to="/" />
        </div>
        <div className="flex flex-1 items-center justify-center px-4 py-10 sm:px-8">
          <div className="w-full max-w-md page-enter">
            <h1 className="t-page">{title}</h1>
            {lede && <p className="mt-3 text-ink-2">{lede}</p>}
            <div className="mt-8">{children}</div>
            {footer && <div className="mt-8 border-t border-line pt-6 text-sm text-ink-2">{footer}</div>}
          </div>
        </div>
      </main>
    </div>
  );
}
