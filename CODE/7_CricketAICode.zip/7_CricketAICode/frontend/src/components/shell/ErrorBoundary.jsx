import { Component } from "react";

/** Keeps a render error in one page from blanking the whole app. */
export default class ErrorBoundary extends Component {
  state = { error: null };

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    console.error("Render error:", error, info?.componentStack);
  }

  componentDidUpdate(prev) {
    if (prev.resetKey !== this.props.resetKey && this.state.error) {
      this.setState({ error: null });
    }
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div role="alert" className="mx-auto max-w-xl rounded-md border border-leather/30 bg-leather-tint p-6">
        <h1 className="t-section text-leather">This screen hit a problem</h1>
        <p className="mt-2 text-sm text-ink-2">
          Something unexpected went wrong while showing this page. Your data is safe.
        </p>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="mt-4 inline-flex min-h-10 items-center rounded-sm border border-ink bg-ink px-4 text-sm font-medium text-white"
        >
          Reload page
        </button>
      </div>
    );
  }
}
