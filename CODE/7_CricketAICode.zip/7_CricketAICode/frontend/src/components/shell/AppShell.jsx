import { useEffect, useRef, useState } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { Plus, MoreHorizontal, LogOut, Settings } from "lucide-react";

import Wordmark from "./Wordmark";
import ErrorBoundary from "./ErrorBoundary";
import { NAV, MOBILE_PRIMARY, isActive, documentTitle } from "./nav";
import { getSavedUser, logout } from "../../services/authService";
import { initials } from "../../lib/format";
import { Dialog } from "../../ui/Overlay";

function useSignOut() {
  const navigate = useNavigate();
  return () => {
    logout();
    navigate("/login", { replace: true });
  };
}

function SideNav({ pathname, user }) {
  const signOut = useSignOut();
  return (
    <aside
      data-surface="night"
      className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col bg-night text-night-ink lg:flex"
    >
      <div className="px-5 pb-6 pt-6">
        <Wordmark />
      </div>

      <div className="px-4">
        <Link
          to="/upload"
          className="flex min-h-10 items-center justify-center gap-2 rounded-sm bg-pitch px-3 text-sm font-medium text-white transition-colors hover:bg-pitch-strong"
        >
          <Plus size={16} aria-hidden="true" />
          New analysis
        </Link>
      </div>

      <nav aria-label="Primary" className="mt-6 flex-1 overflow-y-auto px-2">
        <ul className="space-y-0.5">
          {NAV.map((item) => {
            const active = isActive(item, pathname);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  aria-current={active ? "page" : undefined}
                  className={`relative flex min-h-10 items-center gap-3 rounded-sm px-3 text-sm transition-colors ${
                    active
                      ? "bg-night-2 font-medium text-white"
                      : "text-night-ink-3 hover:bg-night-2 hover:text-night-ink"
                  }`}
                >
                  {active && (
                    <span aria-hidden="true" className="absolute inset-y-2 left-0 w-0.5 bg-pitch" />
                  )}
                  <Icon size={17} aria-hidden="true" strokeWidth={active ? 2.2 : 1.8} />
                  {item.label}
                </NavLink>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="border-t border-night-line px-4 py-4">
        <div className="flex items-center gap-3">
          <span
            aria-hidden="true"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-sm bg-night-2 font-display text-sm font-semibold"
          >
            {initials(user?.name)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{user?.name || "Player"}</p>
            <p className="truncate text-xs text-night-ink-3">
              {[user?.playingRole, user?.skillLevel].filter(Boolean).join(" · ") || "Player"}
            </p>
          </div>
        </div>
        <div className="mt-3 flex gap-1">
          <NavLink
            to="/settings"
            className="flex min-h-9 flex-1 items-center justify-center gap-1.5 rounded-sm text-xs text-night-ink-3 hover:bg-night-2 hover:text-night-ink"
          >
            <Settings size={14} aria-hidden="true" /> Settings
          </NavLink>
          <button
            type="button"
            onClick={signOut}
            className="flex min-h-9 flex-1 items-center justify-center gap-1.5 rounded-sm text-xs text-night-ink-3 hover:bg-night-2 hover:text-night-ink"
          >
            <LogOut size={14} aria-hidden="true" /> Sign out
          </button>
        </div>
      </div>
    </aside>
  );
}

function MobileTopBar() {
  return (
    <header
      data-surface="night"
      className="sticky top-0 z-30 flex h-14 items-center justify-between bg-night px-4 lg:hidden"
    >
      <Wordmark />
      <Link
        to="/upload"
        className="flex min-h-10 items-center gap-1.5 rounded-sm bg-pitch px-3 text-sm font-medium text-white"
      >
        <Plus size={16} aria-hidden="true" />
        Analyse
      </Link>
    </header>
  );
}

function MobileTabBar({ pathname, user }) {
  const [moreOpen, setMoreOpen] = useState(false);
  const signOut = useSignOut();
  const primary = NAV.filter((n) => MOBILE_PRIMARY.includes(n.to));
  const secondary = NAV.filter((n) => !MOBILE_PRIMARY.includes(n.to));
  const moreActive = secondary.some((n) => isActive(n, pathname));

  useEffect(() => setMoreOpen(false), [pathname]);

  return (
    <>
      <nav
        aria-label="Primary"
        className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden"
      >
        <ul className="grid grid-cols-5">
          {primary.map((item) => {
            const active = isActive(item, pathname);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  aria-current={active ? "page" : undefined}
                  className={`relative flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] font-medium ${
                    active ? "text-ink" : "text-ink-3"
                  }`}
                >
                  {active && <span aria-hidden="true" className="absolute inset-x-5 top-0 h-0.5 bg-pitch" />}
                  <Icon size={20} aria-hidden="true" strokeWidth={active ? 2.2 : 1.8} />
                  {item.label}
                </NavLink>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              aria-haspopup="dialog"
              aria-expanded={moreOpen}
              className={`relative flex min-h-14 w-full flex-col items-center justify-center gap-1 text-[11px] font-medium ${
                moreActive ? "text-ink" : "text-ink-3"
              }`}
            >
              {moreActive && <span aria-hidden="true" className="absolute inset-x-5 top-0 h-0.5 bg-pitch" />}
              <MoreHorizontal size={20} aria-hidden="true" />
              More
            </button>
          </li>
        </ul>
      </nav>

      <Dialog
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        variant="sheet"
        title="More"
        labelledBy="more-sheet-title"
      >
        <p className="-mt-1 mb-3 text-sm text-ink-3">
          Signed in as <span className="font-medium text-ink">{user?.name || "Player"}</span>
        </p>
        <ul className="divide-y divide-line border-y border-line">
          {[...secondary, { label: "Settings", to: "/settings", icon: Settings, match: ["/settings"] }].map((item) => {
            const Icon = item.icon;
            const active = isActive(item, pathname);
            return (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  aria-current={active ? "page" : undefined}
                  className={`flex min-h-12 items-center gap-3 text-[15px] ${active ? "font-medium text-ink" : "text-ink-2"}`}
                >
                  <Icon size={18} aria-hidden="true" />
                  {item.label}
                </NavLink>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={signOut}
              className="flex min-h-12 w-full items-center gap-3 text-[15px] text-leather"
            >
              <LogOut size={18} aria-hidden="true" />
              Sign out
            </button>
          </li>
        </ul>
      </Dialog>
    </>
  );
}

export default function AppShell({ children }) {
  const { pathname } = useLocation();
  const mainRef = useRef(null);
  // Compare against the previous path (not a "first render" flag, which
  // StrictMode's double effect run would consume).
  const prevPath = useRef(pathname);
  const user = getSavedUser();

  useEffect(() => {
    document.title = documentTitle(pathname);
    if (prevPath.current === pathname) return;
    prevPath.current = pathname;
    // Move focus to the new page so screen-reader users hear it.
    mainRef.current?.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="flex min-h-dvh">
      <a href="#content" className="skip-link visually-hidden">
        Skip to content
      </a>
      <SideNav pathname={pathname} user={user} />
      <div className="flex min-w-0 flex-1 flex-col">
        <MobileTopBar />
        <main
          id="content"
          ref={mainRef}
          tabIndex={-1}
          className="flex-1 focus:outline-none"
        >
          <div key={pathname} className="page-enter mx-auto w-full max-w-[1240px] px-4 pb-28 pt-6 sm:px-6 lg:px-10 lg:pb-16 lg:pt-10">
            <ErrorBoundary resetKey={pathname}>{children}</ErrorBoundary>
          </div>
        </main>
        <MobileTabBar pathname={pathname} user={user} />
      </div>
    </div>
  );
}
