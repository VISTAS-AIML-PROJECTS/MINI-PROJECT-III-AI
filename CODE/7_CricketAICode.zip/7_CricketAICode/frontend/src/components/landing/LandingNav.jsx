import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Menu } from "lucide-react";

import Wordmark from "../shell/Wordmark";
import { Dialog } from "../../ui/Overlay";

// Section anchors on the homepage (each is a real section below).
export const LANDING_LINKS = [
  { label: "Home", href: "#top" },
  { label: "AI Coach", href: "#coach" },
  { label: "Practice Planner", href: "#practice" },
  { label: "Technique Analysis", href: "#analysis" },
  { label: "Progress", href: "#progress" },
];

function useActiveSection() {
  const [active, setActive] = useState("#top");
  useEffect(() => {
    const ids = LANDING_LINKS.map((l) => l.href.slice(1));
    const els = ids.map((id) => document.getElementById(id)).filter(Boolean);
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(`#${visible.target.id}`);
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: [0, 0.25, 0.5] }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
  return active;
}

export default function LandingNav({ authed }) {
  const active = useActiveSection();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const primary = authed
    ? { to: "/dashboard", label: "Open dashboard" }
    : { to: "/register", label: "Get Started" };

  return (
    <header
      className={`sticky top-0 z-40 transition-[background-color,border-color] duration-200 ${
        scrolled ? "border-b border-line bg-paper/90 backdrop-blur-md" : "border-b border-transparent bg-paper"
      }`}
    >
      <div className="mx-auto flex h-[4.5rem] max-w-[1320px] items-center justify-between gap-4 px-5 sm:px-8 lg:px-12">
        <Wordmark to="/" tone="paper" />

        <nav aria-label="Main" className="hidden lg:block">
          <ul className="flex items-center gap-1">
            {LANDING_LINKS.map((l) => {
              const current = active === l.href;
              return (
                <li key={l.href}>
                  <a
                    href={l.href}
                    aria-current={current ? "location" : undefined}
                    className={`relative inline-flex min-h-10 items-center px-3.5 text-sm transition-colors ${
                      current ? "font-medium text-ink" : "text-ink-2 hover:text-ink"
                    }`}
                  >
                    {l.label}
                    {current && <span aria-hidden="true" className="absolute inset-x-3.5 bottom-1 h-0.5 rounded-full bg-gold" />}
                  </a>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          {!authed && (
            <Link to="/login" className="hidden min-h-10 items-center rounded-md border border-line-2 bg-surface px-4 text-sm font-medium text-ink hover:border-ink-3 sm:inline-flex">
              Sign in
            </Link>
          )}
          <Link
            to={primary.to}
            className="inline-flex min-h-10 items-center gap-2 rounded-md bg-pitch px-4 text-sm font-medium text-white shadow-sm transition-colors hover:bg-pitch-strong sm:px-5"
          >
            {primary.label}
            <ArrowRight size={16} aria-hidden="true" />
          </Link>
          <button
            type="button"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
            aria-haspopup="dialog"
            aria-expanded={open}
            className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-md text-ink hover:bg-sunken lg:hidden"
          >
            <Menu size={20} aria-hidden="true" />
          </button>
        </div>
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} variant="sheet" title="Menu" labelledBy="landing-menu-title">
        <nav aria-label="Main">
          <ul className="divide-y divide-line border-y border-line">
            {LANDING_LINKS.map((l) => (
              <li key={l.href}>
                <a href={l.href} onClick={() => setOpen(false)} className="flex min-h-12 items-center text-[15px] text-ink">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        {!authed && (
          <Link to="/login" className="mt-4 flex min-h-12 items-center justify-center rounded-md border border-line-2 text-[15px] font-medium">
            Sign in
          </Link>
        )}
      </Dialog>
    </header>
  );
}
