// Loads the hero assets produced by frontend/scripts/build_hero_assets.py
// from the CLEAN player render:
//   animations/cricket-hero/manifest.json  (frame count, size, pattern)
//   animations/cricket-hero/pose.json      (MediaPipe landmarks per frame)
// Until that render exists there is no manifest and the hero runs without
// the player sequence (status "missing").

const BASE = `${import.meta.env.BASE_URL}animations/cricket-hero/`;

export const LANDMARK_NAMES = [
  "nose",
  "left_shoulder", "right_shoulder",
  "left_elbow", "right_elbow",
  "left_wrist", "right_wrist",
  "left_hip", "right_hip",
  "left_knee", "right_knee",
  "left_ankle", "right_ankle",
];

export const BONES = [
  ["left_shoulder", "right_shoulder"],
  ["left_shoulder", "left_elbow"], ["left_elbow", "left_wrist"],
  ["right_shoulder", "right_elbow"], ["right_elbow", "right_wrist"],
  ["left_shoulder", "left_hip"], ["right_shoulder", "right_hip"],
  ["left_hip", "right_hip"],
  ["left_hip", "left_knee"], ["left_knee", "left_ankle"],
  ["right_hip", "right_knee"], ["right_knee", "right_ankle"],
];

export function frameSrc(manifest, index) {
  const n = String(index + 1).padStart(6, "0");
  return BASE + manifest.framePattern.replace("{n}", n);
}

/** { status: "ready", manifest, pose } | { status: "missing" } */
export async function loadHeroAssets() {
  try {
    const res = await fetch(`${BASE}manifest.json`, { cache: "no-cache" });
    if (!res.ok || !res.headers.get("content-type")?.includes("json")) return { status: "missing" };
    const manifest = await res.json();
    let pose = null;
    if (manifest.pose) {
      const p = await fetch(BASE + manifest.pose).then((r) => (r.ok ? r.json() : null)).catch(() => null);
      if (p?.frames) pose = decodePose(p);
    }
    return { status: "ready", manifest, pose };
  } catch {
    return { status: "missing" };
  }
}

// pose.json: frames[i] = null | [[x, y, v] | null per landmark]. The build
// script has already validated, gap-filled and smoothed the data; a null
// landmark is untrusted and is simply left out (never drawn or guessed).
function decodePose(p) {
  const names = p.landmarks || LANDMARK_NAMES;
  return p.frames.map((frame) => {
    if (!frame) return null;
    const out = {};
    names.forEach((name, i) => {
      const lm = frame[i];
      if (lm) out[name] = { x: lm[0], y: lm[1], v: lm[2] };
    });
    return Object.keys(out).length ? out : null;
  });
}

/** Pose for a frame. No borrowing from other frames: gaps the build step
 *  couldn't fill responsibly stay empty, so the overlay never detaches. */
export function poseAt(pose, index) {
  return pose?.[index] || null;
}

/** Midpoint of two landmarks, only when both are trusted. */
export function midpoint(p, a, b) {
  const A = p?.[a];
  const B = p?.[b];
  return A && B ? { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2, v: Math.min(A.v, B.v) } : null;
}

/**
 * Where a frame sits inside a stage of size w×h: contain-fit, anchored to
 * the bottom so the player's feet stay on the page's ground line.
 */
export function frameBox(manifest, w, h) {
  const scale = Math.min(w / manifest.width, h / manifest.height);
  const fw = manifest.width * scale;
  const fh = manifest.height * scale;
  return { x: (w - fw) / 2, y: h - fh, w: fw, h: fh };
}
