import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  ArrowRight, Video, ScanLine, ListChecks, TrendingUp, Upload, MessageSquareText,
  CheckCircle2, BookOpen, Check,
} from "lucide-react";

import Button from "../../ui/Button";
import Wordmark from "../shell/Wordmark";
import { getSkills, getSkill } from "../../services/skillsApi";
import { prescription } from "../practice/DrillList";

gsap.registerPlugin(ScrollTrigger);

/** Fade/lift section content in as it enters (skipped for reduced motion). */
export function useReveal() {
  const ref = useRef(null);
  useEffect(() => {
    const mm = gsap.matchMedia();
    mm.add("(prefers-reduced-motion: no-preference)", () => {
      gsap.from(ref.current.querySelectorAll("[data-reveal]"), {
        autoAlpha: 0, y: 18, duration: 0.6, ease: "power2.out", stagger: 0.08,
        scrollTrigger: { trigger: ref.current, start: "top 78%", once: true },
      });
    });
    return () => mm.revert();
  }, []);
  return ref;
}

function Eyebrow({ children, tone = "ink" }) {
  return (
    <p className={`text-[11px] font-semibold uppercase tracking-[0.26em] ${tone === "night" ? "text-pitch-bright" : "text-gold-ink"}`}>
      {children}
    </p>
  );
}

const Container = ({ className = "", children }) => (
  <div className={`mx-auto max-w-[1320px] px-5 sm:px-8 lg:px-12 ${className}`}>{children}</div>
);

/* ---------------- Feature strip ---------------- */

const FEATURES = [
  { icon: Video, title: "Video Upload & Analysis", body: "Upload a batting or bowling clip from your phone." },
  { icon: ScanLine, title: "AI Technique Analysis", body: "Pose tracking scores each part of your action 0–100." },
  { icon: ListChecks, title: "Personalized Practice Plan", body: "Drills chosen for your weakest measures." },
  { icon: TrendingUp, title: "Track Your Progress", body: "Every measure, session after session." },
];

export function FeatureStrip() {
  const ref = useReveal();
  return (
    <section id="features" ref={ref} aria-label="Capabilities" className="border-y border-line bg-surface">
      <Container>
        <ul className="grid divide-line sm:grid-cols-2 sm:divide-x lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <li key={f.title} data-reveal className={`flex gap-4 py-6 sm:px-6 ${i === 0 ? "sm:pl-0" : ""} ${i % 2 === 1 ? "" : ""} border-line max-sm:border-b max-sm:last:border-b-0`}>
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-gold-tint text-gold-ink">
                <f.icon size={20} aria-hidden="true" />
              </span>
              <div>
                <h2 className="text-[15px] font-semibold text-ink">{f.title}</h2>
                <p className="mt-1 text-sm text-ink-3">{f.body}</p>
              </div>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}

/* ---------------- How it works ---------------- */

function MiniSkeleton() {
  return (
    <svg viewBox="0 0 80 100" className="h-full w-full" aria-hidden="true">
      <g className="stroke-pitch" strokeWidth="1.5" fill="none">
        <path d="M40 22 L40 52 M28 28 L52 28 M28 28 L22 44 L30 56 M52 28 L60 42 L54 54 M34 52 L46 52 M34 52 L30 72 L28 92 M46 52 L52 72 L56 92" />
      </g>
      <circle cx="40" cy="14" r="6" className="fill-surface stroke-pitch" strokeWidth="1.5" />
      {[[28, 28], [52, 28], [22, 44], [60, 42], [30, 56], [54, 54], [34, 52], [46, 52], [30, 72], [52, 72], [28, 92], [56, 92]].map(([x, y]) => (
        <circle key={`${x}${y}`} cx={x} cy={y} r="2.4" className="fill-surface stroke-gold" strokeWidth="1.2" />
      ))}
    </svg>
  );
}

const STEPS = [
  {
    title: "Upload video",
    body: "Record one stroke or delivery on your phone and upload it.",
    visual: (
      <div className="flex h-full flex-col justify-center gap-2 px-4">
        <div className="flex items-center gap-2 rounded-sm border border-line bg-surface px-3 py-2 text-xs">
          <Upload size={14} aria-hidden="true" className="text-pitch" /> <span className="truncate">cover-drive.mp4</span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-sunken"><div className="h-full w-3/4 rounded-full bg-pitch" /></div>
      </div>
    ),
  },
  { title: "AI analysis", body: "Pose tracking follows 13 landmarks through every frame.", visual: <div className="mx-auto h-full w-24 py-3"><MiniSkeleton /></div> },
  {
    title: "Get feedback",
    body: "Each measure scored, strengths and priorities flagged.",
    visual: (
      <div className="flex h-full flex-col justify-center gap-2.5 px-4">
        {[["Balance", 82, "bg-pitch"], ["Front elbow", 61, "bg-amber-bar"], ["Head position", 90, "bg-pitch"]].map(([l, v, c]) => (
          <div key={l} className="grid grid-cols-[1fr_3.5rem] items-center gap-2 text-[11px] text-ink-2">
            {l}
            <span className="h-1.5 overflow-hidden rounded-full bg-sunken"><span className={`block h-full rounded-full ${c}`} style={{ width: `${v}%` }} /></span>
          </div>
        ))}
      </div>
    ),
  },
  {
    title: "Practice & improve",
    body: "Follow the drills for your weakest areas and re-test.",
    visual: (
      <ul className="flex h-full flex-col justify-center gap-2 px-4 text-[11px] text-ink-2">
        {["Front-elbow drill", "Shadow batting, 3 sets", "Re-test next session"].map((d, i) => (
          <li key={d} className="flex items-center gap-2">
            <span className={`flex h-4 w-4 items-center justify-center rounded-xs border ${i === 0 ? "border-pitch bg-pitch text-white" : "border-line-2"}`}>
              {i === 0 && <Check size={10} aria-hidden="true" />}
            </span>
            {d}
          </li>
        ))}
      </ul>
    ),
  },
];

export function HowItWorks() {
  const ref = useReveal();
  return (
    <section id="how" ref={ref} aria-labelledby="how-h" className="scroll-mt-24 py-20 lg:py-28">
      <Container className="grid gap-12 lg:grid-cols-[minmax(0,4fr)_minmax(0,8fr)]">
        <div data-reveal>
          <Eyebrow>How it works</Eyebrow>
          <h2 id="how-h" className="t-page mt-4 text-[clamp(2.25rem,1.6rem+2.2vw,3.5rem)]">From video to better performance</h2>
          <p className="mt-5 max-w-md text-lg text-ink-2">Upload your video and get analysis of every movement, with practice built around what it finds.</p>
          <Button to="/register" className="mt-8 !rounded-md" iconRight={ArrowRight}>Analyse your first clip</Button>
        </div>
        <ol className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {STEPS.map((s, i) => (
            <li key={s.title} data-reveal className="relative flex flex-col rounded-md border border-line bg-surface p-4">
              <span className="absolute -left-2 -top-2 flex h-8 w-8 items-center justify-center rounded-full bg-pitch font-display text-sm font-bold text-white">{i + 1}</span>
              <div className="h-28 rounded-sm bg-paper">{s.visual}</div>
              <h3 className="mt-4 text-[15px] font-semibold">{s.title}</h3>
              <p className="mt-1 text-sm text-ink-3">{s.body}</p>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}

/* ---------------- Technique analysis ---------------- */

const MEASURES = {
  Batting: ["Batting stance", "Base width", "Balance", "Head stability", "Head lateral lean", "Backlift", "Hand path straightness", "Front elbow", "Front knee", "Back knee", "Front foot direction", "Shoulder alignment", "Hip rotation", "X-factor sequencing", "Weight transfer"],
  Bowling: ["Bowling arm height", "Front knee brace", "Trunk lean", "Shoulder-hip rotation", "Head stability", "Balance"],
};

export function AnalysisSection() {
  const ref = useReveal();
  const specimen = [
    ["Head & balance", [["Head stability", 94], ["Balance", 88]]],
    ["Arms, hands & bat", [["Front elbow", 71], ["Backlift", 46]]],
    ["Base, legs & feet", [["Front knee", 63], ["Weight transfer", 80]]],
  ];
  const tone = (v) => (v >= 75 ? "bg-pitch" : v >= 50 ? "bg-amber-bar" : "bg-leather");
  return (
    <section id="analysis" ref={ref} aria-labelledby="analysis-h" className="scroll-mt-24 border-t border-line bg-surface py-20 lg:py-28">
      <Container className="grid items-start gap-14 lg:grid-cols-2">
        <div data-reveal>
          <Eyebrow>AI technique analysis</Eyebrow>
          <h2 id="analysis-h" className="t-page mt-4 text-[clamp(2.25rem,1.6rem+2.2vw,3.5rem)]">Every joint, scored and explained</h2>
          <p className="mt-5 max-w-lg text-lg text-ink-2">
            Body landmarks are tracked frame by frame, then rule-based biomechanics evaluators score each part of the action 0–100 and group
            it by body segment, so you see exactly what to fix first.
          </p>
          <div className="mt-10 grid gap-8 sm:grid-cols-2">
            {Object.entries(MEASURES).map(([d, list]) => (
              <div key={d}>
                <h3 className="border-b border-ink pb-2 text-sm font-semibold uppercase tracking-[0.12em]">{d} · {list.length} measures</h3>
                <ul className="mt-2 columns-1 text-sm text-ink-2">
                  {list.map((m) => <li key={m} className="py-1">{m}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <figure data-reveal className="rounded-lg border border-line bg-paper p-5 sm:p-7 lg:sticky lg:top-28">
          <div className="flex items-center justify-between gap-3">
            <p className="font-display text-sm font-extrabold uppercase tracking-[0.04em]">Biomechanics scorecard</p>
            <span className="rounded-full border border-line-2 px-2 py-0.5 text-[10.5px] text-ink-3">Example</span>
          </div>
          <div className="mt-5 space-y-5">
            {specimen.map(([group, items]) => (
              <div key={group}>
                <p className="t-label mb-2">{group}</p>
                {items.map(([n, v]) => (
                  <div key={n} className="grid grid-cols-[8.5rem_1fr_2rem] items-center gap-3 border-t border-line py-2 text-sm">
                    <span>{n}</span>
                    <span className="h-2 overflow-hidden rounded-full bg-sunken"><span className={`block h-full rounded-full ${tone(v)}`} style={{ width: `${v}%` }} /></span>
                    <span className="t-figure text-right text-lg">{v}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <figcaption className="mt-5 text-xs text-ink-3">Illustrative scorecard. Real reports cover every measure listed alongside.</figcaption>
        </figure>
      </Container>
    </section>
  );
}

/* ---------------- AI coach ---------------- */

export function CoachSection() {
  const ref = useReveal();
  return (
    <section id="coach" ref={ref} aria-labelledby="coach-h" data-surface="night" className="scroll-mt-24 bg-night py-20 text-night-ink lg:py-28">
      <Container className="grid items-center gap-14 lg:grid-cols-2">
        <div data-reveal>
          <Eyebrow tone="night">AI coach</Eyebrow>
          <h2 id="coach-h" className="t-page mt-4 text-[clamp(2.25rem,1.6rem+2.2vw,3.5rem)] text-white">A coach that has read your report</h2>
          <p className="mt-5 max-w-lg text-lg text-night-ink-3">
            Ask about any analysis. Answers draw on your scores plus coaching manuals, biomechanics texts and the MCC Laws, retrieved and
            ranked for your question.
          </p>
          <ul className="mt-8 space-y-3 text-night-ink">
            {["Knows the measures in the session you pick", "Explains why a fault happens and how to correct it", "Suggests drills for your weakest areas"].map((t) => (
              <li key={t} className="flex gap-3"><CheckCircle2 size={18} aria-hidden="true" className="mt-0.5 shrink-0 text-pitch-bright" />{t}</li>
            ))}
          </ul>
        </div>

        <figure data-reveal className="rounded-lg border border-night-line bg-night-2 p-5 sm:p-7">
          <div className="flex items-center justify-between">
            <p className="flex items-center gap-2 text-sm font-medium"><MessageSquareText size={16} aria-hidden="true" className="text-pitch-bright" />Coaching session</p>
            <span className="rounded-full border border-night-line px-2 py-0.5 text-[10.5px] text-night-ink-3">Example conversation</span>
          </div>
          <div className="mt-6 space-y-5">
            <p className="ml-auto max-w-[85%] rounded-md bg-night px-4 py-3 text-sm">My front elbow scored 61. How do I fix it?</p>
            <div className="border-l-2 border-pitch-bright pl-4 text-sm leading-relaxed text-night-ink">
              <p className="t-label mb-2 !text-pitch-bright">Coach</p>
              <p>Your elbow is dropping before contact, so the bat face opens. Lead the downswing with the top hand and keep the elbow pointing down the pitch.</p>
              <p className="mt-3">Try 3 sets of 10 slow-motion shadow drives against a mirror, pausing at impact.</p>
            </div>
          </div>
          <figcaption className="mt-6 text-xs text-night-ink-3">Illustrative exchange. Real answers are generated from your own report.</figcaption>
        </figure>
      </Container>
    </section>
  );
}

/* ---------------- Personalized practice (real skill-library drills) ---------------- */

export function PracticeSection() {
  const ref = useReveal();
  const [skill, setSkill] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const list = await getSkills("batting");
        const pick = list.find((s) => s.drill_count > 1) || list.find((s) => s.drill_count > 0);
        if (!pick) throw new Error("no drills");
        const full = await getSkill(pick.skill_id);
        if (!cancelled) setSkill(full);
      } catch {
        if (!cancelled) setFailed(true);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return (
    <section id="practice" ref={ref} aria-labelledby="practice-h" className="scroll-mt-24 py-20 lg:py-28">
      <Container className="grid items-start gap-14 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <div data-reveal>
          <Eyebrow>Personalized practice</Eyebrow>
          <h2 id="practice-h" className="t-page mt-4 text-[clamp(2.25rem,1.6rem+2.2vw,3.5rem)]">Practice what your video says</h2>
          <p className="mt-5 max-w-md text-lg text-ink-2">
            Your lowest-scoring measures become your training focus, with corrective drills, sets and reps from a library of batting,
            bowling and fielding skills.
          </p>
          <Button to="/register" variant="secondary" className="mt-8 !rounded-md" icon={BookOpen}>Explore the skill library</Button>
        </div>

        <div data-reveal className="rounded-lg border border-line bg-surface p-5 sm:p-7" aria-live="polite">
          {skill ? (
            <>
              <p className="t-label">From the skill library</p>
              <h3 className="mt-2 font-display text-2xl font-extrabold tracking-tight">{skill.name}</h3>
              <p className="mt-1 text-sm text-ink-3">{skill.description}</p>
              <ul className="mt-5 divide-y divide-line border-y border-line">
                {skill.drills.slice(0, 3).map((d) => (
                  <li key={d.name} className="grid gap-1 py-3 sm:grid-cols-[1fr_auto] sm:gap-6">
                    <div>
                      <p className="font-medium">{d.name}</p>
                      <p className="text-sm text-ink-2">{d.description}</p>
                    </div>
                    {prescription(d) && <p className="t-data whitespace-nowrap text-gold-ink">{prescription(d)}</p>}
                  </li>
                ))}
              </ul>
            </>
          ) : failed ? (
            <p className="text-sm text-ink-3">Drills load from the CricketAI skill library once the service is available.</p>
          ) : (
            <div className="space-y-3" aria-hidden="true">
              <div className="skeleton h-3 w-32" /><div className="skeleton h-7 w-48" /><div className="skeleton h-16" /><div className="skeleton h-16" />
            </div>
          )}
        </div>
      </Container>
    </section>
  );
}

/* ---------------- Progress ---------------- */

export function ProgressSection() {
  const ref = useReveal();
  const pts = [52, 55, 54, 59, 63, 62, 67, 71];
  const path = pts.map((v, i) => `${i === 0 ? "M" : "L"}${(i / (pts.length - 1)) * 300},${120 - v * 1.1}`).join(" ");
  return (
    <section id="progress" ref={ref} aria-labelledby="progress-h" className="scroll-mt-24 border-t border-line bg-surface py-20 lg:py-28">
      <Container className="grid items-center gap-14 lg:grid-cols-2">
        <figure data-reveal className="order-2 rounded-lg border border-line bg-paper p-5 sm:p-7 lg:order-1">
          <div className="flex items-center justify-between">
            <p className="font-display text-sm font-extrabold uppercase tracking-[0.04em]">Technique score by session</p>
            <span className="rounded-full border border-line-2 px-2 py-0.5 text-[10.5px] text-ink-3">Example progress</span>
          </div>
          <svg viewBox="0 -4 300 130" className="mt-5 h-48 w-full" role="img" aria-label="Example: technique score rising from 52 to 71 over eight sessions">
            {[0, 50, 75, 100].map((v) => (
              <line key={v} x1="0" x2="300" y1={120 - v * 1.1} y2={120 - v * 1.1} className="stroke-line" strokeWidth="1" strokeDasharray={v === 75 ? "3 4" : undefined} />
            ))}
            <path d={path} fill="none" className="stroke-pitch" strokeWidth="2.5" strokeLinejoin="round" />
            {pts.map((v, i) => <circle key={i} cx={(i / (pts.length - 1)) * 300} cy={120 - v * 1.1} r="3.5" className={i === pts.length - 1 ? "fill-gold" : "fill-pitch"} />)}
          </svg>
          <figcaption className="mt-3 text-xs text-ink-3">Illustrative trend. Your progress page plots your own sessions.</figcaption>
        </figure>
        <div data-reveal className="order-1 lg:order-2">
          <Eyebrow>Progress</Eyebrow>
          <h2 id="progress-h" className="t-page mt-4 text-[clamp(2.25rem,1.6rem+2.2vw,3.5rem)]">See the change, measure by measure</h2>
          <p className="mt-5 max-w-lg text-lg text-ink-2">Every analysis adds a data point. Compare your first session with your latest for each measure and keep your practice streak going.</p>
        </div>
      </Container>
    </section>
  );
}

/* ---------------- Final CTA + footer ---------------- */

export function FinalCta({ authed }) {
  return (
    <section aria-labelledby="cta-h" className="py-20 lg:py-24">
      <Container>
        <div data-surface="night" className="relative overflow-hidden rounded-lg bg-night px-6 py-14 text-center text-night-ink sm:px-12">
          <div aria-hidden="true" className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
          <h2 id="cta-h" className="t-hero mx-auto max-w-3xl text-[clamp(2rem,1.4rem+2.6vw,3.75rem)] text-white">Your next session starts with one clip</h2>
          <p className="mx-auto mt-5 max-w-lg text-night-ink-3">Upload a stroke or a delivery and get your first technique report in minutes.</p>
          <Link
            to={authed ? "/upload" : "/register"}
            className="mt-8 inline-flex min-h-12 items-center gap-2 rounded-md bg-night-ink px-6 font-medium text-night hover:bg-white"
          >
            Start Training <ArrowRight size={18} aria-hidden="true" />
          </Link>
        </div>
      </Container>
    </section>
  );
}

export function LandingFooter() {
  return (
    <footer className="border-t border-line">
      <Container className="flex flex-col gap-4 py-8 text-sm text-ink-3 sm:flex-row sm:items-center sm:justify-between">
        <Wordmark to="/" tone="paper" />
        <nav aria-label="Footer" className="flex flex-wrap gap-x-5">
          <Link to="/about" className="inline-flex min-h-10 items-center hover:text-ink">How it works</Link>
          <Link to="/login" className="inline-flex min-h-10 items-center hover:text-ink">Sign in</Link>
          <Link to="/register" className="inline-flex min-h-10 items-center hover:text-ink">Create account</Link>
        </nav>
      </Container>
    </footer>
  );
}
