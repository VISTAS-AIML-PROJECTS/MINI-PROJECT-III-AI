import { forwardRef, useCallback, useEffect, useId, useImperativeHandle, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ScrollToPlugin } from "gsap/ScrollToPlugin";
import { ArrowRight, PlayCircle, Scale, Ruler, ScanFace, BarChart3 } from "lucide-react";

import Button from "../../ui/Button";
import FrameCanvas from "./FrameCanvas";
import { BONES, frameBox, loadHeroAssets, midpoint, poseAt } from "./heroAssets";

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

/* Illustrative values for the public homepage only (labelled "Example"). */
const EXAMPLE = [
  { key: "balance", label: "Balance", value: "92%", bar: 92, tone: "pitch", icon: Scale },
  { key: "bat", label: "Bat Angle", value: "87°", bar: 70, tone: "gold", icon: Ruler },
  { key: "head", label: "Head Position", value: "Optimal", bar: 90, tone: "pitch", icon: ScanFace },
];

// Callout chips: position in the stage (fractions) and the body point
// they connect to. Points come from the processed pose each frame; a
// connector is drawn only when its body point is trusted in that frame.
const CALLOUTS = [
  { key: "head", at: { x: 0.6, y: 0.06 }, from: (p) => p.nose || null },
  { key: "bat", at: { x: 0.74, y: 0.38 }, from: (p) => midpoint(p, "left_wrist", "right_wrist") },
  { key: "balance", at: { x: 0.74, y: 0.66 }, from: (p) => midpoint(p, "left_hip", "right_hip") },
];

/* ------------------------------------------------------------------ */
/* Live computer-vision overlay (SVG), driven by real MediaPipe data   */
/* ------------------------------------------------------------------ */

/** Bat path: hand midpoints from the swing start to now, split into
 *  segments wherever a frame lacks both trusted wrists (no bridging). */
function batPath(pose, from, to, pt) {
  const segments = [];
  let current = [];
  for (let i = from; i <= to; i++) {
    const m = midpoint(pose[i], "left_wrist", "right_wrist");
    if (m) {
      current.push(pt(m));
    } else if (current.length) {
      segments.push(current);
      current = [];
    }
  }
  if (current.length) segments.push(current);
  return segments.filter((seg) => seg.length > 1);
}

const PoseOverlay = forwardRef(function PoseOverlay({ manifest, pose, size }, ref) {
  const [frame, setFrame] = useState(0);
  const [swingFrom, setSwingFrom] = useState(null);
  useImperativeHandle(ref, () => ({ setFrame, setSwingFrom }), []);

  if (!manifest || !pose || !size.w) return null;
  const box = frameBox(manifest, size.w, size.h);
  const pt = (l) => ({ x: box.x + l.x * box.w, y: box.y + l.y * box.h });
  const p = poseAt(pose, frame);
  if (!p) return null; // no trusted pose this frame: draw nothing

  const trail = swingFrom != null ? batPath(pose, swingFrom, frame, pt) : [];

  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox={`0 0 ${size.w} ${size.h}`} aria-hidden="true">
      <g data-anim="trail">
        {trail.map((seg, i) => (
          <polyline
            key={i}
            points={seg.map((t) => `${t.x},${t.y}`).join(" ")}
            fill="none"
            className="stroke-gold"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity="0.9"
          />
        ))}
      </g>
      <g data-anim="skeleton">
        {BONES.filter(([a, b]) => p[a] && p[b]).map(([a, b]) => {
          const A = pt(p[a]);
          const B = pt(p[b]);
          return <line key={a + b} x1={A.x} y1={A.y} x2={B.x} y2={B.y} className="stroke-white" strokeWidth="1.5" opacity="0.85" />;
        })}
        {Object.entries(p).map(([name, l]) => {
          const P = pt(l);
          return <circle key={name} cx={P.x} cy={P.y} r={name === "nose" ? 4 : 3.2} className="fill-white stroke-pitch" strokeWidth="1.5" />;
        })}
      </g>
      <g data-anim="connectors">
        {CALLOUTS.map((c) => {
          const source = c.from(p);
          if (!source) return null;
          const from = pt(source);
          const to = { x: c.at.x * size.w, y: c.at.y * size.h + 24 };
          const elbowX = from.x + (to.x - from.x) * 0.55;
          return (
            <g key={c.key}>
              <path
                d={`M${from.x},${from.y} L${elbowX},${to.y} L${to.x},${to.y}`}
                fill="none"
                className="stroke-pitch"
                strokeWidth="1"
                strokeDasharray="3 3"
                opacity="0.7"
              />
              <circle cx={from.x} cy={from.y} r="5.5" fill="none" className="stroke-gold" strokeWidth="1.5" />
            </g>
          );
        })}
      </g>
    </svg>
  );
});

function Callout({ item, at }) {
  const Icon = item.icon;
  return (
    <div
      data-anim="chip"
      className="absolute flex items-center gap-2.5 rounded-sm border border-line bg-surface/90 px-3 py-2 shadow-float backdrop-blur-[2px]"
      style={{ left: `${at.x * 100}%`, top: `${at.y * 100}%` }}
    >
      <Icon size={18} aria-hidden="true" className={item.tone === "gold" ? "text-gold-ink" : "text-pitch"} />
      <div>
        <p className="text-[11px] font-medium leading-tight text-ink-2">{item.label}</p>
        <p className={`font-display text-lg font-extrabold leading-tight ${item.tone === "gold" ? "text-gold-ink" : "text-pitch"}`}>
          {item.value}
        </p>
      </div>
    </div>
  );
}

export function TechniquePanel({ className = "" }) {
  const titleId = useId();
  return (
    <aside
      data-anim="panel"
      aria-labelledby={titleId}
      className={`rounded-md border border-line bg-surface/92 p-4 shadow-float backdrop-blur-[3px] ${className}`}
    >
      <div className="flex items-center justify-between gap-3">
        <h2 id={titleId} className="flex items-center gap-2 font-display text-[13px] font-extrabold uppercase tracking-[0.04em]">
          <BarChart3 size={16} aria-hidden="true" className="text-gold-ink" />
          AI Technique Analysis
        </h2>
        <span className="rounded-full border border-line-2 px-2 py-0.5 text-[10.5px] font-medium text-ink-3">Example analysis</span>
      </div>
      <dl className="mt-3 divide-y divide-line">
        {EXAMPLE.map((m) => (
          <div key={m.key} className="grid grid-cols-[1.25rem_6.5rem_1fr_auto] items-center gap-2.5 py-2">
            <m.icon size={15} aria-hidden="true" className="text-ink-2" />
            <dt className="text-sm text-ink">{m.label}</dt>
            <span aria-hidden="true" className="h-1.5 overflow-hidden rounded-full bg-sunken">
              <span className={`block h-full rounded-full ${m.tone === "gold" ? "bg-gold" : "bg-pitch"}`} style={{ width: `${m.bar}%` }} />
            </span>
            <dd className={`text-right text-sm font-semibold ${m.tone === "gold" ? "text-gold-ink" : "text-pitch"}`}>{m.value}</dd>
          </div>
        ))}
      </dl>
      <p className="mt-2 text-[11px] leading-snug text-ink-3">Illustrative values. Your own report scores every measure from your video.</p>
    </aside>
  );
}

/* Background: grid, ground line, large "01", side words. Secondary only. */
function HeroBackdrop() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.55]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--color-line) 1px, transparent 1px), linear-gradient(to bottom, var(--color-line) 1px, transparent 1px)",
          backgroundSize: "88px 88px",
          maskImage: "radial-gradient(ellipse 75% 70% at 65% 45%, black 20%, transparent 75%)",
        }}
      />
      <span className="absolute -right-[1vw] bottom-[14%] font-display text-[clamp(10rem,24vw,22rem)] font-black leading-none tracking-[-0.06em] text-ink/[0.045]">
        01
      </span>
      <div className="absolute bottom-[11%] left-0 right-0 h-px bg-gradient-to-r from-transparent via-line-2 to-transparent" />
      <ul className="absolute right-6 top-1/2 hidden -translate-y-1/2 space-y-3 text-[10px] font-semibold uppercase tracking-[0.32em] text-ink-4 xl:block">
        <li>Analyze</li><li>Improve</li><li>Practice</li><li>Excel</li>
      </ul>
    </div>
  );
}

function RenderPending() {
  // Development-only marker: production simply omits the player until the
  // clean render is integrated (no old frames are ever used).
  if (!import.meta.env.DEV) return null;
  return (
    <div className="absolute inset-x-[12%] bottom-[11%] top-[6%] flex items-end justify-center rounded-lg border border-dashed border-line-2">
      <p className="mb-6 rounded-sm bg-surface/90 px-3 py-2 text-center text-xs text-ink-3">
        Player render pending — run <code className="t-data">scripts/build_hero_assets.py</code> on the clean render
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */

export default function HeroSection({ authed }) {
  const sectionRef = useRef(null);
  const pinRef = useRef(null);
  const stageRef = useRef(null);
  const canvasRef = useRef(null);
  const overlayRef = useRef(null);
  const [assets, setAssets] = useState({ status: "loading" });
  const [size, setSize] = useState({ w: 0, h: 0 });

  useEffect(() => {
    loadHeroAssets().then(setAssets);
  }, []);

  useEffect(() => {
    const el = stageRef.current;
    const ro = new ResizeObserver(([e]) => setSize({ w: e.contentRect.width, h: e.contentRect.height }));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const manifest = assets.status === "ready" ? assets.manifest : null;
  const pose = assets.status === "ready" ? assets.pose : null;

  const showFrame = useCallback(
    (f) => {
      canvasRef.current?.setFrame(f);
      overlayRef.current?.setFrame(Math.round(f));
    },
    []
  );

  // Scroll choreography (GSAP + ScrollTrigger), per breakpoint.
  useEffect(() => {
    if (assets.status === "loading") return undefined;
    const frames = manifest?.frameCount || 0;
    const swingStart = Math.round(frames * 0.4);
    const mm = gsap.matchMedia();

    mm.add(
      {
        wide: "(min-width: 1024px) and (prefers-reduced-motion: no-preference)",
        mid: "(min-width: 768px) and (max-width: 1023px) and (prefers-reduced-motion: no-preference)",
        narrow: "(max-width: 767px) and (prefers-reduced-motion: no-preference)",
        reduced: "(prefers-reduced-motion: reduce)",
      },
      (ctx) => {
        const { reduced, narrow } = ctx.conditions;
        const q = gsap.utils.selector(sectionRef);

        if (reduced) {
          // Finished composition, no motion.
          if (frames) showFrame(Math.round(frames * 0.6));
          overlayRef.current?.setSwingFrom(swingStart);
          return undefined;
        }

        const state = { f: 0 };
        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: narrow
            ? { trigger: stageRef.current, start: "top 85%", end: "bottom 15%", scrub: 0.4 }
            : {
                trigger: pinRef.current,
                // Pin below the sticky 4.5rem nav so nothing slides under it.
                start: "top 72px",
                end: () => `+=${window.innerHeight * (ctx.conditions.wide ? 2.6 : 1.8)}`,
                pin: true,
                scrub: 0.5,
                invalidateOnRefresh: true,
              },
        });

        // 0% setup → frames run 5%–85%: motion, bat/ball.
        if (frames) {
          tl.to(state, {
            f: frames - 1,
            duration: 0.8,
            onUpdate: () => {
              showFrame(state.f);
              overlayRef.current?.setSwingFrom(state.f >= swingStart ? swingStart : null);
            },
          }, 0.05);
        }
        // 20%: pose detection appears.
        tl.fromTo(q('[data-anim="skeleton"], [data-anim="status"]'), { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.08 }, 0.16);
        // 60%: bat path.
        tl.fromTo(q('[data-anim="trail"]'), { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.06 }, 0.56);
        // 80%: technique analysis becomes prominent.
        // Wide/tablet only: on phones the panel sits in the page flow and
        // stays fully visible (readable without scrolling the stage).
        if (!narrow) tl.fromTo(q('[data-anim="panel"]'), { autoAlpha: 0.35, y: 14 }, { autoAlpha: 1, y: 0, duration: 0.1 }, 0.7);
        tl.fromTo(q('[data-anim="chip"]'), { autoAlpha: 0, y: 8 }, { autoAlpha: 1, y: 0, duration: 0.06, stagger: 0.03 }, 0.72);
        tl.fromTo(q('[data-anim="connectors"]'), { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.06 }, 0.74);
        // 100%: hand over to the next section.
        if (!narrow) tl.to(q('[data-anim="copy"]'), { autoAlpha: 0.2, y: -24, duration: 0.1 }, 0.9);

        return () => tl.kill();
      }
    );

    return () => mm.revert();
  }, [assets.status, manifest, showFrame]);

  function watchDemo() {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const st = ScrollTrigger.getAll().find((t) => t.pin === pinRef.current);
    const target = st ? st.end : document.getElementById("features")?.offsetTop ?? 0;
    if (reduce) window.scrollTo(0, target);
    else gsap.to(window, { scrollTo: target, duration: 7, ease: "power1.inOut" });
  }

  return (
    <section ref={sectionRef} aria-labelledby="hero-title" className="relative">
      <div ref={pinRef} className="relative min-h-[640px] overflow-hidden bg-paper md:h-[calc(100svh-4.5rem)] md:min-h-[600px]">
        <HeroBackdrop />

        <div className="relative mx-auto grid h-full max-w-[1320px] px-5 sm:px-8 md:grid-cols-[minmax(0,11fr)_minmax(0,13fr)] md:gap-4 lg:px-12">
          {/* Copy */}
          <div data-anim="copy" className="relative z-10 flex flex-col justify-center pb-6 pt-10 md:py-10">
            <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-2 sm:tracking-[0.28em]">
              Play smarter <span aria-hidden="true">•</span> Practice better <span aria-hidden="true">•</span> Improve faster
            </p>
            <h1 id="hero-title" className="t-hero mt-6 text-[clamp(2.75rem,0.9rem+5.2vw,5.75rem)] text-ink">
              Your
              <br />
              <span className="whitespace-nowrap text-pitch">AI Cricket</span>
              <br />
              Coach
            </h1>
            <p className="mt-6 max-w-md text-[clamp(1.05rem,0.9rem+0.5vw,1.375rem)] leading-snug text-ink-2">
              Train smarter. Analyze every movement.
              <br className="hidden sm:inline" /> Improve every shot.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button to={authed ? "/upload" : "/register"} size="lg" iconRight={ArrowRight} className="!rounded-md px-6">
                Start Training
              </Button>
              <Button variant="secondary" size="lg" icon={PlayCircle} onClick={watchDemo} className="!rounded-md px-5">
                Watch Demo
              </Button>
            </div>
          </div>

          {/* Stage: player + live analysis */}
          <div ref={stageRef} className="relative h-[min(78vw,560px)] md:h-full" role="img" aria-label="Batter playing a shot while pose tracking measures balance, bat angle and head position">
            {manifest ? <FrameCanvas ref={canvasRef} manifest={manifest} /> : assets.status === "missing" && <RenderPending />}
            <PoseOverlay ref={overlayRef} manifest={manifest} pose={pose} size={size} />

            <p data-anim="status" className="absolute left-0 top-[4%] hidden items-center gap-2 rounded-full border border-line bg-surface/85 px-3 py-1 text-[11px] font-medium text-ink-2 md:inline-flex">
              <span className="h-1.5 w-1.5 rounded-full bg-pitch" />
              Pose tracking · 13 landmarks
            </p>

            <div className="hidden md:block">
              {CALLOUTS.map((c) => (
                <Callout key={c.key} item={EXAMPLE.find((e) => e.key === c.key)} at={c.at} />
              ))}
            </div>
          </div>
        </div>

        <TechniquePanel className="absolute right-5 top-6 z-20 hidden w-[340px] lg:right-12 lg:block xl:w-[380px]" />
      </div>

      {/* Narrow screens: the panel sits in the flow under the player. */}
      <div className="px-5 pb-6 sm:px-8 lg:hidden">
        <TechniquePanel />
      </div>
    </section>
  );
}
