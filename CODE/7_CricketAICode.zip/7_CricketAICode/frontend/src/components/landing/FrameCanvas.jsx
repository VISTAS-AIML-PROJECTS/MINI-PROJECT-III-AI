import { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from "react";
import { frameSrc, frameBox } from "./heroAssets";

const CONCURRENCY = 6;

/**
 * Transparent canvas that draws one frame of the player sequence.
 * Frame 1 renders as soon as it decodes; the rest preload in order.
 * Control it imperatively: ref.current.setFrame(index).
 */
const FrameCanvas = forwardRef(function FrameCanvas({ manifest, onProgress, className = "" }, ref) {
  const canvasRef = useRef(null);
  const frames = useRef([]);
  const current = useRef(0);
  const raf = useRef(0);
  const [ready, setReady] = useState(false);

  const nearest = useCallback((i) => {
    const f = frames.current;
    for (let k = i; k >= 0; k--) if (f[k]) return f[k];
    for (let k = i + 1; k < f.length; k++) if (f[k]) return f[k];
    return null;
  }, []);

  const draw = useCallback(() => {
    raf.current = 0;
    const canvas = canvasRef.current;
    const img = nearest(current.current);
    if (!canvas || !img) return;
    const ctx = canvas.getContext("2d");
    const box = frameBox(manifest, canvas.width, canvas.height);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, box.x, box.y, box.w, box.h);
  }, [manifest, nearest]);

  const schedule = useCallback(() => {
    if (!raf.current) raf.current = requestAnimationFrame(draw);
  }, [draw]);

  useImperativeHandle(ref, () => ({
    setFrame(i) {
      const next = Math.max(0, Math.min(manifest.frameCount - 1, Math.round(i)));
      if (next !== current.current) {
        current.current = next;
        schedule();
      }
    },
  }), [manifest, schedule]);

  // Backing store = CSS size × DPR (max 2).
  useEffect(() => {
    const canvas = canvasRef.current;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const r = canvas.getBoundingClientRect();
      canvas.width = Math.max(1, Math.round(r.width * dpr));
      canvas.height = Math.max(1, Math.round(r.height * dpr));
      draw();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    resize();
    return () => ro.disconnect();
  }, [draw]);

  useEffect(() => {
    let cancelled = false;
    let loaded = 0;
    frames.current = new Array(manifest.frameCount).fill(null);
    const load = (i) =>
      new Promise((resolve) => {
        const img = new Image();
        img.decoding = "async";
        img.src = frameSrc(manifest, i);
        img.decode().then(
          () => {
            if (!cancelled) {
              frames.current[i] = img;
              if (i <= current.current) schedule();
            }
          },
          () => {}
        ).finally(() => {
          if (!cancelled) onProgress?.(++loaded / manifest.frameCount);
          resolve();
        });
      });

    (async () => {
      await load(0);
      if (cancelled) return;
      setReady(true);
      schedule();
      let next = 1;
      const worker = async () => {
        while (!cancelled && next < manifest.frameCount) await load(next++);
      };
      await Promise.all(Array.from({ length: CONCURRENCY }, worker));
    })();

    return () => {
      cancelled = true;
      cancelAnimationFrame(raf.current);
      raf.current = 0;
    };
  }, [manifest, onProgress, schedule]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={`absolute inset-0 h-full w-full transition-opacity duration-500 ${ready ? "opacity-100" : "opacity-0"} ${className}`}
    />
  );
});

export default FrameCanvas;
