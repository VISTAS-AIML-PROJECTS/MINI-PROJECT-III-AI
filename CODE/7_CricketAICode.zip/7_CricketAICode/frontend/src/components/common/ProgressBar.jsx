import { motion } from "framer-motion";
import { DURATION } from "../../theme/motion";

const TONES = {
  gold: "from-gold-500 to-gold-400",
  pitch: "from-pitch-500 to-pitch-400",
  leather: "from-leather-500 to-leather-400",
};

export default function ProgressBar({ value = 0, tone = "gold", className = "" }) {
  const clamped = Math.max(0, Math.min(100, value));

  return (
    <div className={`h-1.5 overflow-hidden rounded-full bg-white/10 ${className}`}>
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${clamped}%` }}
        transition={{ duration: DURATION.slow }}
        className={`h-full rounded-full bg-gradient-to-r ${TONES[tone]}`}
      />
    </div>
  );
}
