import { Link } from "react-router-dom";
import { useState } from "react";
import { Menu, X, ChevronRight } from "lucide-react";
import Container from "./Container";
import Logo from "./Logo";

export default function Nav() {
  const [open, setOpen] = useState(false);
  const navItems = ["Features", "How It Works", "Why CricketAI", "FAQ"];

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-surface-abyss/90 backdrop-blur-xl">
      <Container className="flex h-20 items-center justify-between">
        <Logo />
        <nav className="hidden md:flex items-center gap-10">
          {navItems.map((item) => (
            
            <a
              key={item}
              href={"/#" + item.toLowerCase().split(" ").join("-")}
              className="text-slate-400 transition hover:text-white"
            >
              {item}
            </a>
          ))}
        </nav>
        <div className="hidden md:flex items-center gap-4">
          <Link to="/login" className="rounded-xl border border-white/10 px-5 py-2 text-white hover:bg-white/5">
            Login
          </Link>
          <Link
            to="/register"
            className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-gold-600 to-leather-400 px-6 py-3 font-semibold text-white shadow-lg shadow-gold-500/20 transition hover:opacity-90"
          >
            Get Started
            <ChevronRight size={16} />
          </Link>
        </div>
        <button onClick={() => setOpen(!open)} className="text-white md:hidden">
          {open ? <X size={28} /> : <Menu size={28} />}
        </button>
      </Container>
      {open && (
        <div className="border-t border-white/10 bg-surface-abyss md:hidden">
          <Container className="space-y-5 py-5">
            {navItems.map((item) => (
              <a key={item} href={"/#" + item.toLowerCase().split(" ").join("-")} className="block text-white">
                {item}
              </a>
            ))}
            <Link to="/login" className="block text-white">Login</Link>
            <Link to="/register" className="block font-semibold text-gold-400">Get Started</Link>
          </Container>
        </div>
      )}
    </header>
  );
}
