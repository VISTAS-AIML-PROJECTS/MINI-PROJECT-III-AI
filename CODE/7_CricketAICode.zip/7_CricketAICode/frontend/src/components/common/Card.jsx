import { motion } from "framer-motion";
import { DURATION } from "../../theme/motion";

const TIERS = {
  hero: "rounded-3xl border border-gold-500/20 bg-gradient-to-br from-surface-sidebar to-surface-abyss p-8 shadow-[var(--shadow-glow)]",
  primary: "rounded-2xl border border-white/10 bg-surface-sidebar p-6",
  standard: "rounded-2xl border border-white/10 bg-surface-sidebar/70 p-5",
  compact: "rounded-xl border border-white/10 bg-white/5 p-4",
};

const HOVER = {
  hero: { y: -4 },
  primary: { y: -3 },
  standard: { y: -2 },
  compact: {},
};

export default function Card({
  children,
  tier = "primary",
  className = "",
  ...props
}) {
  return (
    <motion.div
      whileHover={HOVER[tier]}
      transition={{ duration: DURATION.fast }}
      className={`${TIERS[tier]} ${className}`}
      {...props}
    >
      {children}
    </motion.div>
  );
}
