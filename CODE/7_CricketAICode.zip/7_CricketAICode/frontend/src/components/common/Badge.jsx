const TONES = {
  gold: "border-gold-500/25 bg-gold-500/10 text-gold-300",
  pitch: "border-pitch-500/25 bg-pitch-500/10 text-pitch-400",
  leather: "border-leather-500/25 bg-leather-500/10 text-leather-300",
  neutral: "border-white/10 bg-white/5 text-slate-300",
};

export default function Badge({
  children,
  tone = "neutral",
  icon: Icon,
  className = "",
}) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold ${TONES[tone]} ${className}`}
    >
      {Icon && <Icon size={12} />}
      {children}
    </span>
  );
}
