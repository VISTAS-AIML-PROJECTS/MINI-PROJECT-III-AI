import { Link } from "react-router-dom";
import Container from "./Container";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-surface-abyss py-16">
      <Container>
        <div className="grid gap-12 md:grid-cols-4">
          <div>
            <Logo />
            <p className="mt-4 leading-7 text-slate-400">
              AI-powered cricket coaching for players who want to improve their skills anytime and anywhere.
            </p>
          </div>
          <div>
            <h3 className="mb-5 text-lg font-semibold text-white">Product</h3>
            <ul className="space-y-3 text-slate-400">
              <li>
                <a href="/#features" className="hover:text-white">Features</a>
              </li>
              <li>
                <a href="/#how-it-works" className="hover:text-white">How It Works</a>
              </li>
              <li>
                <a href="/#demo" className="hover:text-white">Demo</a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-5 text-lg font-semibold text-white">Company</h3>
            <ul className="space-y-3 text-slate-400">
              <li>
                <Link to="/about" className="hover:text-white">About</Link>
              </li>
              <li>
                <a href="/#why-cricketai" className="hover:text-white">Why CricketAI</a>
              </li>
              <li>
                <a href="/#faq" className="hover:text-white">FAQ</a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-5 text-lg font-semibold text-white">Contact</h3>
            <p className="text-slate-400">Abdul Wahid</p>
            <a
              href="mailto:wahid05250@gmail.com"
              className="mt-2 block text-slate-400 hover:text-white"
            >
              wahid05250@gmail.com
            </a>
          </div>
        </div>
        <div className="mt-12 border-t border-white/10 pt-6 text-center text-slate-500">
          © {new Date().getFullYear()} CricketAI. All rights reserved.
        </div>
      </Container>
    </footer>
  );
}

