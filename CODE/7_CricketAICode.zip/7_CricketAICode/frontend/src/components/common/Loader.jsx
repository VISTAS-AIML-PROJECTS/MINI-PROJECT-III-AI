export default function Loader({ label = "Loading...", className = "" }) {
  return (
    <div className={`flex min-h-[40vh] flex-col items-center justify-center gap-4 ${className}`}>
      <div className="h-12 w-12 animate-spin rounded-full border-4 border-gold-500 border-t-transparent" />
      {label && <p className="text-sm text-slate-400">{label}</p>}
    </div>
  );
}
