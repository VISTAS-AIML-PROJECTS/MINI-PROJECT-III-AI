import { motion } from "framer-motion";

const VARIANTS = {
  primary:
    "bg-gradient-to-r from-gold-600 to-gold-400 text-surface-abyss shadow-lg shadow-gold-500/25 hover:shadow-gold-500/40",
  secondary:
    "border border-white/10 bg-white/5 text-slate-200 hover:bg-white/10 hover:text-white",
  ghost:
    "text-slate-300 hover:bg-white/5 hover:text-white",
  danger:
    "bg-gradient-to-r from-leather-600 to-leather-400 text-white shadow-lg shadow-leather-500/25 hover:shadow-leather-500/40",
};

const SIZES = {
  sm: "px-4 py-2 text-sm gap-1.5",
  md: "px-5 py-3 text-sm gap-2",
  lg: "px-6 py-4 text-base gap-2",
};

export default function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft: IconLeft,
  iconRight: IconRight,
  className = "",
  disabled = false,
  ...props
}) {
  return (
    <motion.button
      whileHover={disabled ? undefined : { scale: 1.03 }}
      whileTap={disabled ? undefined : { scale: 0.97 }}
      disabled={disabled}
      className={`inline-flex items-center justify-center rounded-xl font-semibold transition disabled:cursor-not-allowed disabled:opacity-60 ${VARIANTS[variant]} ${SIZES[size]} ${className}`}
      {...props}
    >
      {IconLeft && <IconLeft size={size === "lg" ? 20 : 18} />}
      {children}
      {IconRight && <IconRight size={size === "lg" ? 20 : 18} />}
    </motion.button>
  );
}
