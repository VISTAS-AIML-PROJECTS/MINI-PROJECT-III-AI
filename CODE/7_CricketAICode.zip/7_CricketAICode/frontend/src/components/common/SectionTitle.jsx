const TITLE_SIZE = {
  section: "text-2xl md:text-3xl",
  hero: "text-4xl md:text-5xl",
};

export default function SectionTitle({
  eyebrow,
  title,
  subtitle,
  size = "section",
  className = "",
}) {
  return (
    <div className={className}>
      {eyebrow && (
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.25em] text-gold-400">
          {eyebrow}
        </p>
      )}

      <h1 className={`font-display font-bold text-white ${TITLE_SIZE[size]}`}>
        {title}
      </h1>

      {subtitle && (
        <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-400 md:text-base">
          {subtitle}
        </p>
      )}
    </div>
  );
}
