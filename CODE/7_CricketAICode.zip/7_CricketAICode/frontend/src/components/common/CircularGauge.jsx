import { motion } from "framer-motion";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { DURATION } from "../../theme/motion";

const COLORS = {
  gold: "#d4a017",
  pitch: "#4c9a5b",
  leather: "#a6303c",
};

export default function CircularGauge({
  value,
  label,
  tone = "gold",
  size = 176,
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: DURATION.slow }}
      className="flex flex-col items-center"
    >
      <div style={{ height: size, width: size }}>
        <CircularProgressbar
          value={value}
          text={`${value}`}
          styles={buildStyles({
            pathColor: COLORS[tone],
            textColor: "#ffffff",
            trailColor: "#263244",
            strokeLinecap: "round",
            textSize: "20px",
          })}
        />
      </div>

      {label && (
        <h3 className="mt-6 text-center text-xl font-semibold text-white">
          {label}
        </h3>
      )}
    </motion.div>
  );
}
