/**
 * Custom cricket iconography — hand-drawn SVGs grounded in the actual
 * sport (ball seam, stumps, bat willow) rather than generic tech icons,
 * so the product reads as "cricket platform" rather than "SaaS template".
 */

export function CricketBallIcon({ size = 24, className = "" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
    >
      <circle cx="12" cy="12" r="9" fill="currentColor" opacity="0.15" />
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.4" />
      {/* seam */}
      <path
        d="M4.5 7.5C7 9.5 8.6 12 8.6 12s-1.6 2.5-4.1 4.5"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M19.5 7.5C17 9.5 15.4 12 15.4 12s1.6 2.5 4.1 4.5"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        fill="none"
      />
      {/* stitch ticks along the seam */}
      {[6.2, 7.6, 9, 10.4].map((y, i) => (
        <line
          key={`l${i}`}
          x1={6.8 - i * 0.35}
          y1={y}
          x2={7.9 - i * 0.35}
          y2={y + 0.6}
          stroke="currentColor"
          strokeWidth="0.9"
        />
      ))}
      {[13.6, 15, 16.4, 17.8].map((y, i) => (
        <line
          key={`r${i}`}
          x1={17.2 + i * 0.35}
          y1={y}
          x2={16.1 + i * 0.35}
          y2={y - 0.6}
          stroke="currentColor"
          strokeWidth="0.9"
        />
      ))}
    </svg>
  );
}

export function StumpsIcon({ size = 24, className = "" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
    >
      {/* crease */}
      <line x1="2.5" y1="20.5" x2="21.5" y2="20.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      {/* three stumps */}
      <rect x="6.3" y="5" width="1.8" height="15.2" rx="0.9" fill="currentColor" />
      <rect x="11.1" y="4" width="1.8" height="16.2" rx="0.9" fill="currentColor" />
      <rect x="15.9" y="5" width="1.8" height="15.2" rx="0.9" fill="currentColor" />
      {/* bails */}
      <rect x="6.9" y="3.4" width="4.9" height="1.3" rx="0.6" fill="currentColor" opacity="0.85" />
      <rect x="11.7" y="2.6" width="4.9" height="1.3" rx="0.6" fill="currentColor" opacity="0.85" />
    </svg>
  );
}

export function CricketBatIcon({ size = 24, className = "" }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
    >
      {/* blade (willow) */}
      <path
        d="M13.5 3.2c1.6 0 2.9 1.4 2.9 3.6 0 3.6-1.7 7-3.9 9.9l-2.4 3.1-2.2-1.7 2.2-3.3c2-3 3-6 3-8.4 0-1.6-.5-2.6-1.1-3.1.4-.05.9-.1 1.5-.1Z"
        fill="currentColor"
        opacity="0.18"
      />
      <path
        d="M13.5 3.2c1.6 0 2.9 1.4 2.9 3.6 0 3.6-1.7 7-3.9 9.9l-2.4 3.1"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
        fill="none"
      />
      {/* handle grip */}
      <path
        d="M7 15.3l2.2 1.7"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
      />
      <line x1="6.1" y1="14.6" x2="3.3" y2="19.3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <line x1="7.4" y1="15.6" x2="4.6" y2="20.3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" opacity="0.6" />
    </svg>
  );
}

/**
 * A repeating cricket-ball seam-stitch texture, meant to be used as a
 * low-opacity <pattern> fill behind hero/section content — a subject-
 * specific alternative to a generic gradient blob.
 *
 * Usage:
 *   <svg className="absolute inset-0 h-full w-full">
 *     <SeamStitchDefs id="seam" />
 *     <rect width="100%" height="100%" fill="url(#seam)" />
 *   </svg>
 */
export function SeamStitchDefs({ id = "seam-stitch" }) {
  return (
    <defs>
      <pattern id={id} width="46" height="46" patternUnits="userSpaceOnUse" patternTransform="rotate(18)">
        <path
          d="M0 23 C 11 15, 23 15, 46 23"
          stroke="currentColor"
          strokeWidth="1"
          fill="none"
        />
        {[6, 14, 22, 30, 38].map((x, i) => (
          <line
            key={i}
            x1={x}
            y1={20 - Math.abs(i - 2) * 1.5}
            x2={x + 2.4}
            y2={24 - Math.abs(i - 2) * 1.5}
            stroke="currentColor"
            strokeWidth="0.8"
          />
        ))}
      </pattern>
    </defs>
  );
}

