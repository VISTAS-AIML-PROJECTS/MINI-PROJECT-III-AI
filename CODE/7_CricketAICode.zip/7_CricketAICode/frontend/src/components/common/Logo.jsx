import { Link } from "react-router-dom";

export default function Logo({ to = "/", size = "md" }) {
  const isSmall = size === "sm";

  return (
    <Link to={to} className="flex items-center gap-3">
      <div
        className={`flex items-center justify-center rounded-xl bg-gradient-to-br from-gold-600 to-leather-400 shadow-lg shadow-gold-500/20 ${
          isSmall ? "h-9 w-9 text-base" : "h-11 w-11 text-lg"
        }`}
      >
        🏏
      </div>
      <span className={`font-bold text-white ${isSmall ? "text-lg" : "text-2xl"}`}>
        CricketAI
      </span>
    </Link>
  );
}
