import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from "recharts";
import Card from "../common/Card";
import ProgressBar from "../common/ProgressBar";

function humanize(key) {
  return key
    .replace(/^avg_/, "")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function toneFor(score) {
  if (score >= 75) return "pitch";
  if (score >= 50) return "gold";
  return "leather";
}

export default function MetricsGrid({ metrics }) {
  const entries = Object.entries(metrics || {});

  if (entries.length === 0) {
    return (
      <Card tier="standard" className="text-center text-sm text-slate-400">
        No per-metric breakdown is available for this analysis.
      </Card>
    );
  }

  const radarData = entries.map(([key, value]) => ({
    metric: humanize(key),
    score: value,
  }));

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <Card tier="primary" className="lg:col-span-2">
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData} outerRadius="75%">
              <PolarGrid stroke="rgba(255,255,255,0.1)" />
              <PolarAngleAxis
                dataKey="metric"
                tick={{ fill: "#94a3b8", fontSize: 11 }}
              />
              <PolarRadiusAxis
                domain={[0, 100]}
                tick={false}
                axisLine={false}
              />
              <Radar
                dataKey="score"
                stroke="#d4a017"
                fill="#d4a017"
                fillOpacity={0.25}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:col-span-3">
        {entries.map(([key, value]) => (
          <Card key={key} tier="compact">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-300">
                {humanize(key)}
              </span>
              <span className="text-sm font-bold tabular-nums text-white">
                {value}
              </span>
            </div>

            <ProgressBar value={value} tone={toneFor(value)} className="mt-3" />
          </Card>
        ))}
      </div>
    </div>
  );
}
