import { CheckCircle2, AlertTriangle } from "lucide-react";
import Card from "../common/Card";

const VARIANTS = {
  strength: {
    border: "border-pitch-500/25",
    heading: "text-pitch-400",
    icon: CheckCircle2,
    bullet: "text-pitch-400",
  },
  weakness: {
    border: "border-leather-500/25",
    heading: "text-leather-400",
    icon: AlertTriangle,
    bullet: "text-leather-400",
  },
};

export default function StrengthWeakness({ title, items, kind }) {
  const variant = VARIANTS[kind] || VARIANTS.strength;
  const Icon = variant.icon;

  return (
    <Card tier="primary" className={`!${variant.border}`}>
      <h2 className={`flex items-center gap-2 text-xl font-bold ${variant.heading}`}>
        <Icon size={20} />
        {title}
      </h2>

      <ul className="mt-6 space-y-3">
        {items.length === 0 && (
          <li className="text-sm text-slate-500">Nothing to report yet.</li>
        )}

        {items.map((item, index) => (
          <li key={index} className="flex gap-2 text-sm text-slate-300">
            <span className={variant.bullet}>•</span>
            {item}
          </li>
        ))}
      </ul>
    </Card>
  );
}
