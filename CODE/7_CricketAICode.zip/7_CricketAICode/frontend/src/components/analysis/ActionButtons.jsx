import { useNavigate } from "react-router-dom";
import { Upload, LayoutDashboard } from "lucide-react";
import Button from "../common/Button";

export default function ActionButtons() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-wrap gap-4">
      <Button iconLeft={Upload} onClick={() => navigate("/upload")}>
        Analyze Another Video
      </Button>

      <Button
        variant="secondary"
        iconLeft={LayoutDashboard}
        onClick={() => navigate("/dashboard")}
      >
        Back to Dashboard
      </Button>
    </div>
  );
}
