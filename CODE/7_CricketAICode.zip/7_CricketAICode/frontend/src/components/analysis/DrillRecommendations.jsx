import { CricketBatIcon } from "../common/CricketIcons";
import Card from "../common/Card";

export default function DrillRecommendations({ drills }) {
  if (!drills || drills.length === 0) return null;

  return (
    <Card tier="primary">
      <h2 className="text-xl font-bold text-white">Recommended Drills</h2>

      <ul className="mt-6 space-y-3">
        {drills.map((drill, index) => (
          <li key={index} className="flex items-center gap-3 text-sm text-gold-300">
            <CricketBatIcon size={18} className="shrink-0 text-gold-400" />
            {drill}
          </li>
        ))}
      </ul>
    </Card>
  );
}
