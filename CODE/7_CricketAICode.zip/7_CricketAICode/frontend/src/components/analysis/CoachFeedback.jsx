import { Sparkles } from "lucide-react";
import Card from "../common/Card";

export default function CoachFeedback({ feedback }) {
  if (!feedback) return null;

  return (
    <Card tier="hero">
      <h2 className="flex items-center gap-2 text-xl font-bold text-gold-300">
        <Sparkles size={20} />
        AI Coach Feedback
      </h2>

      <p className="mt-5 leading-8 text-slate-200">{feedback}</p>
    </Card>
  );
}
