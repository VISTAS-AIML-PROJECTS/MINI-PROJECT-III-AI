import { useRef, useState } from "react";
import { FileVideo, StepBack, StepForward } from "lucide-react";

import { rememberVideo, videoFor } from "../../lib/sessionVideos";
import Button from "../../ui/Button";

const RATES = [0.25, 0.5, 1];
const FRAME = 1 / 30;

/**
 * Footage panel for a report. Plays the clip uploaded in this browser
 * session, or a clip the player loads from their device for side-by-side
 * review. The API does not serve analysed videos back, so nothing is
 * fetched from the server.
 */
export default function SessionVideo({ analysisId }) {
  const [src, setSrc] = useState(() => videoFor(analysisId));
  const [rate, setRate] = useState(1);
  const videoRef = useRef(null);
  const inputRef = useRef(null);

  function loadLocal(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    rememberVideo(analysisId, file);
    setSrc(videoFor(analysisId));
  }

  function step(delta) {
    const v = videoRef.current;
    if (!v) return;
    v.pause();
    v.currentTime = Math.max(0, Math.min(v.duration || 0, v.currentTime + delta));
  }

  function changeRate(r) {
    setRate(r);
    if (videoRef.current) videoRef.current.playbackRate = r;
  }

  if (!src) {
    return (
      <div className="flex aspect-video flex-col items-center justify-center gap-3 rounded-md border border-dashed border-line-2 bg-sunken px-6 text-center">
        <FileVideo size={24} aria-hidden="true" className="text-ink-3" />
        <p className="max-w-xs text-sm text-ink-2">
          Footage isn't kept for playback. Load the clip from this device to review it next to the report.
        </p>
        {/* Opened by the button below; hidden so it isn't a second tab stop. */}
        <input ref={inputRef} type="file" accept="video/*" onChange={loadLocal} hidden aria-label="Load clip from device" />
        <Button variant="secondary" size="sm" onClick={() => inputRef.current?.click()}>
          Load clip from device
        </Button>
        <p className="text-xs text-ink-3">It stays on your device and isn't uploaded.</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-md border border-line bg-night">
      <video
        ref={videoRef}
        src={src}
        controls
        playsInline
        preload="metadata"
        className="aspect-video w-full object-contain"
        aria-label="Session footage"
      />
      <div data-surface="night" className="flex flex-wrap items-center justify-between gap-2 border-t border-night-line px-2 py-1.5 text-night-ink">
        <div className="flex items-center">
          <button type="button" onClick={() => step(-FRAME)} aria-label="Previous frame" className="flex min-h-9 min-w-9 items-center justify-center rounded-sm hover:bg-night-2">
            <StepBack size={16} aria-hidden="true" />
          </button>
          <button type="button" onClick={() => step(FRAME)} aria-label="Next frame" className="flex min-h-9 min-w-9 items-center justify-center rounded-sm hover:bg-night-2">
            <StepForward size={16} aria-hidden="true" />
          </button>
          <span className="t-data ml-1 text-xs text-night-ink-3">Frame step</span>
        </div>
        <div role="group" aria-label="Playback speed" className="flex">
          {RATES.map((r) => (
            <button
              key={r}
              type="button"
              aria-pressed={rate === r}
              onClick={() => changeRate(r)}
              className={`t-data min-h-9 min-w-11 rounded-sm px-2 text-xs ${rate === r ? "bg-night-ink text-night" : "text-night-ink-3 hover:bg-night-2 hover:text-night-ink"}`}
            >
              {r}×
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
