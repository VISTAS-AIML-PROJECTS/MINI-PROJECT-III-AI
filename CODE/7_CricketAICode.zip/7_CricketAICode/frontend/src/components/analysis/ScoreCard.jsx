import Card from "../common/Card";
import Badge from "../common/Badge";
import CircularGauge from "../common/CircularGauge";

function getLevel(score) {
  if (score >= 90) return { label: "Elite", tone: "pitch" };
  if (score >= 75) return { label: "Advanced", tone: "gold" };
  if (score >= 60) return { label: "Intermediate", tone: "gold" };
  return { label: "Beginner", tone: "leather" };
}

export default function ScoreCard({ score = 0, confidence = 0 }) {
  const level = getLevel(score);

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <Card tier="hero">
        <CircularGauge value={score} label="Technique Score" tone="gold" />

        <div className="mt-6 flex justify-center">
          <Badge tone={level.tone}>{level.label} Level</Badge>
        </div>
      </Card>

      <Card tier="hero" className="!border-pitch-500/20">
        <CircularGauge value={confidence} label="AI Confidence" tone="pitch" />

        <p className="mt-6 text-center text-sm text-slate-400">
          Confidence indicates how certain the AI is about this analysis
          based on the extracted pose and motion data.
        </p>
      </Card>
    </div>
  );
}
