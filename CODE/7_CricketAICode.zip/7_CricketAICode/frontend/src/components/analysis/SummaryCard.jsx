import Card from "../common/Card";

export default function SummaryCard({ summary }) {
  return (
    <Card tier="primary">
      <h2 className="mb-4 text-xl font-bold text-white">AI Summary</h2>
      <p className="text-lg leading-8 text-slate-300">
        {summary || "No summary available."}
      </p>
    </Card>
  );
}
