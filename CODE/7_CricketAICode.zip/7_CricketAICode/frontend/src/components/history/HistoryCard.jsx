import { useNavigate } from "react-router-dom";
import { Calendar, Trophy, Brain, ChevronRight } from "lucide-react";
import Card from "../common/Card";
import Button from "../common/Button";

function formatDate(value) {
  if (!value) return "Unknown date";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Unknown date";

  return date.toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export default function HistoryCard({ analysis }) {
  const navigate = useNavigate();

  const score = analysis.score ?? analysis.technique_score ?? 0;
  const strengths = analysis.strengths || [];
  const weaknesses = analysis.weaknesses || [];
  const type = analysis.analysis_type || analysis.type || "batting";

  return (
    <Card tier="primary" className="hover:border-gold-400/40">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold capitalize text-white sm:text-2xl">
            {type} Analysis
          </h2>

          {(analysis.bowling_arm || analysis.bowling_style) && (
            <p className="mt-1 text-sm capitalize text-slate-400">
              {[analysis.bowling_style, analysis.bowling_arm && `${analysis.bowling_arm}-arm`]
                .filter(Boolean)
                .join(" · ")}
            </p>
          )}

          <span className="mt-3 flex items-center gap-2 text-slate-400">
            <Calendar size={16} />
            {formatDate(analysis.created_at)}
          </span>
        </div>

        <div className="text-right">
          <div className="text-4xl font-bold tabular-nums text-gold-400 sm:text-5xl">
            {score}
          </div>
          <div className="text-sm text-slate-400">Score</div>
        </div>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <div>
          <div className="flex items-center gap-2 font-semibold text-pitch-400">
            <Trophy size={18} />
            Strengths
          </div>

          <ul className="mt-3 space-y-2 text-sm text-slate-300">
            {strengths.length === 0 && <li className="text-slate-500">—</li>}
            {strengths.slice(0, 3).map((item, index) => (
              <li key={index}>✓ {item}</li>
            ))}
          </ul>
        </div>

        <div>
          <div className="flex items-center gap-2 font-semibold text-leather-400">
            <Brain size={18} />
            Weaknesses
          </div>

          <ul className="mt-3 space-y-2 text-sm text-slate-300">
            {weaknesses.length === 0 && <li className="text-slate-500">—</li>}
            {weaknesses.slice(0, 3).map((item, index) => (
              <li key={index}>• {item}</li>
            ))}
          </ul>
        </div>
      </div>

      <Button
        size="sm"
        iconRight={ChevronRight}
        onClick={() => navigate(`/analysis/${analysis.id}`)}
        className="mt-8"
      >
        View Report
      </Button>
    </Card>
  );
}
