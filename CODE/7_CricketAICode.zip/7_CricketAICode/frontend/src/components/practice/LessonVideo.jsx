import { useState } from "react";
import { VideoOff } from "lucide-react";

function formatDuration(seconds) {
  if (!seconds) return null;
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
}

/** Skill lesson video with an explicit state for missing media files. */
export default function LessonVideo({ src, title, type, duration }) {
  const [failed, setFailed] = useState(false);
  const meta = [type === "drill" ? "Drill" : "Lesson", formatDuration(duration)].filter(Boolean).join(" · ");

  return (
    <figure>
      {failed ? (
        <div className="flex aspect-video flex-col items-center justify-center gap-2 rounded-md border border-dashed border-line-2 bg-sunken px-4 text-center">
          <VideoOff size={20} aria-hidden="true" className="text-ink-3" />
          <p className="text-sm text-ink-2">This video isn't available on the server yet.</p>
        </div>
      ) : (
        <video
          src={src}
          controls
          playsInline
          preload="metadata"
          onError={() => setFailed(true)}
          className="aspect-video w-full rounded-md border border-line bg-night object-contain"
          aria-label={title}
        />
      )}
      <figcaption className="mt-2 flex items-baseline justify-between gap-3">
        <span className="text-sm font-medium">{title}</span>
        <span className="t-data text-xs text-ink-3">{meta}</span>
      </figcaption>
    </figure>
  );
}
