import { Badge } from "../../ui/Data";

/** Prescription line built only from fields the skill library provides. */
export function prescription(d) {
  const parts = [];
  if (d.sets && d.repetitions) parts.push(`${d.sets} sets × ${d.repetitions} reps`);
  else if (d.repetitions) parts.push(`${d.repetitions} reps`);
  else if (d.sets) parts.push(`${d.sets} sets`);
  if (d.duration_minutes) parts.push(`${d.duration_minutes} min`);
  return parts.join(" · ");
}

/** Structured drills (SkillDrill[]) as a dense, scannable list. */
export default function DrillList({ drills }) {
  return (
    <ul className="divide-y divide-line border-y border-line">
      {drills.map((d) => {
        const rx = prescription(d);
        return (
          <li key={d.name} className="grid gap-x-6 gap-y-1 py-4 sm:grid-cols-[minmax(0,1fr)_auto]">
            <div className="min-w-0">
              <p className="font-medium">{d.name}</p>
              <p className="mt-1 text-sm text-ink-2">{d.description}</p>
            </div>
            <div className="flex items-start gap-3 sm:flex-col sm:items-end">
              {rx && <span className="t-data whitespace-nowrap font-medium text-ink">{rx}</span>}
              {d.difficulty && <Badge>{d.difficulty}</Badge>}
            </div>
          </li>
        );
      })}
    </ul>
  );
}
