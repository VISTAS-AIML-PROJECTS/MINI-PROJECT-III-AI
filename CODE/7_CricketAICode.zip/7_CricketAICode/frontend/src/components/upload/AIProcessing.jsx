import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Brain,
  ScanLine,
  Activity,
  FileText,
  CheckCircle2,
} from "lucide-react";

const steps = [
  {
    icon: Activity,
    title: "Analyzing Your Video",
    description: "This usually takes a few moments...",
  },
  {
    icon: ScanLine,
    title: "Analyzing Your Video",
    description: "Extracting body movement and pose data...",
  },
  {
    icon: Brain,
    title: "Analyzing Your Video",
    description: "Evaluating your technique...",
  },
  {
    icon: FileText,
    title: "Almost Done",
    description: "Preparing your personalized coaching report...",
  },
];

export default function AIProcessing({
  onComplete,
}) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (step >= steps.length) {
      onComplete?.();
      return;
    }

    const timer = setTimeout(() => {
      setStep((s) => s + 1);
    }, 1500);

    return () => clearTimeout(timer);
  }, [step, onComplete]);

  if (step >= steps.length) {
    return (
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="rounded-3xl border border-pitch-500/20 bg-surface-sidebar p-12 text-center"
      >
        <CheckCircle2
          className="mx-auto text-pitch-400"
          size={70}
        />

        <h2 className="mt-6 text-3xl font-bold text-white">
          Analysis Complete
        </h2>

        <p className="mt-3 text-slate-400">
          Opening your AI report...
        </p>
      </motion.div>
    );
  }

  const current = steps[step];
  const Icon = current.icon;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="rounded-3xl border border-white/10 bg-surface-sidebar p-12"
    >
      <div className="flex flex-col items-center">
        <motion.div
          animate={{
            rotate: 360,
          }}
          transition={{
            repeat: Infinity,
            duration: 3,
            ease: "linear",
          }}
          className="rounded-full bg-gold-500/10 p-6"
        >
          <Icon
            size={50}
            className="text-gold-400"
          />
        </motion.div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{
              opacity: 0,
              y: 20,
            }}
            animate={{
              opacity: 1,
              y: 0,
            }}
            exit={{
              opacity: 0,
              y: -20,
            }}
            className="mt-8 text-center"
          >
            <h2 className="text-3xl font-bold text-white">
              {current.title}
            </h2>

            <p className="mt-4 text-slate-400">
              {current.description}
            </p>
          </motion.div>
        </AnimatePresence>

        <div className="mt-10 h-3 w-full overflow-hidden rounded-full bg-white/10">
          <motion.div
            initial={{
              width: 0,
            }}
            animate={{
              width: `${((step + 1) / steps.length) * 100}%`,
            }}
            className="h-full rounded-full bg-gradient-to-r from-gold-500 to-leather-300"
          />
        </div>

        <p className="mt-4 text-sm text-gold-400">
          Analyzing...
        </p>
      </div>
    </motion.div>
  );
}

