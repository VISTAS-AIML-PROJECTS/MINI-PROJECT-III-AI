import SegmentedControl from "./SegmentedControl";

const SIDE_OPTIONS = [
  { key: "right", label: "Right-Handed", emoji: "🫱" },
  { key: "left", label: "Left-Handed", emoji: "🫲" },
];

export default function BattingOptionsSelector({ side, onSideChange }) {
  return (
    <div className="mt-6">
      <SegmentedControl
        label="Batting Side"
        layoutId="battingSideIndicator"
        options={SIDE_OPTIONS}
        value={side}
        onChange={onSideChange}
      />
    </div>
  );
}
