import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { UploadCloud, Loader2 } from "lucide-react";

import UploadPreview from "./UploadPreview";
import UploadProgress from "./UploadProgress";
import AnalysisTypeSelector from "./AnalysisTypeSelector";
import BattingOptionsSelector from "./BattingOptionsSelector";
import BowlingOptionsSelector from "./BowlingOptionsSelector";
import AIProcessing from "./AIProcessing";

import { uploadVideo } from "../../services/videoService";

export default function UploadZone() {
  const navigate = useNavigate();

  const [selectedFile, setSelectedFile] = useState(null);
  const [analysisType, setAnalysisType] = useState("batting");
  const [battingSide, setBattingSide] = useState("right");
  const [bowlingArm, setBowlingArm] = useState("right");
  const [bowlingStyle, setBowlingStyle] = useState("fast");

  const [progress, setProgress] = useState(0);
  const [uploading, setUploading] = useState(false);

  const [error, setError] = useState("");

  const [showProcessing, setShowProcessing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);

  const onDrop = useCallback((acceptedFiles) => {
    if (acceptedFiles.length > 0) {
      setSelectedFile(acceptedFiles[0]);
      setError("");
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } =
    useDropzone({
      onDrop,
      multiple: false,
      accept: {
        "video/mp4": [".mp4"],
        "video/quicktime": [".mov"],
      },
    });

  async function handleUpload() {
    if (!selectedFile) {
      setError("Please select a cricket video.");
      return;
    }

    try {
      setUploading(true);
      setProgress(0);
      setError("");

      const result = await uploadVideo(
        selectedFile,
        analysisType,
        battingSide,
        setProgress,
        bowlingArm,
        bowlingStyle
      );

      setAnalysisResult(result);

      setUploading(false);

      setShowProcessing(true);
    } catch (err) {
      console.error(err);

      setUploading(false);

      setError(
        err.response?.data?.detail ||
          "Video upload failed. Please try again."
      );
    }
  }

  if (showProcessing && analysisResult) {
  return (
    <AIProcessing
      onComplete={() => {
        localStorage.setItem(
          "analysis_id",
          analysisResult.analysis_id
        );

        navigate(`/analysis/${analysisResult.analysis_id}`);
      }}
    />
  );
}

  return (
    <div>
      {/* Upload Area */}

      <motion.div
        {...getRootProps()}
        animate={{
          borderColor: isDragActive
            ? "rgba(212,160,23,0.6)"
            : "rgba(255,255,255,0.15)",

          boxShadow: isDragActive
            ? "0 0 40px rgba(212,160,23,0.25)"
            : "0 0 0 rgba(0,0,0,0)",
        }}
        className="cursor-pointer rounded-3xl border-2 border-dashed bg-white/5 p-16 backdrop-blur-xl transition-colors"
      >
        <input {...getInputProps()} />

        <div className="flex flex-col items-center text-center">
          <motion.div
            animate={{
              y: isDragActive ? -6 : 0,
            }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 15,
            }}
            className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-to-br from-gold-600 to-leather-400 shadow-lg shadow-gold-500/30"
          >
            <UploadCloud
              size={36}
              className="text-white"
            />
          </motion.div>

          <h2 className="mt-6 text-2xl font-bold text-white md:text-3xl">
            {isDragActive
              ? "Drop your cricket video here"
              : "Drag & Drop Cricket Video"}
          </h2>

          <p className="mt-3 text-slate-400">
            Supported formats: MP4, MOV • Max Size: 200MB
          </p>
        </div>
      </motion.div>

      {/* Preview */}

      <UploadPreview file={selectedFile} />

      {/* Analysis Type */}

      <AnalysisTypeSelector
        value={analysisType}
        onChange={setAnalysisType}
      />

      {analysisType === "batting" && (
        <BattingOptionsSelector
          side={battingSide}
          onSideChange={setBattingSide}
        />
      )}

      {analysisType === "bowling" && (
        <BowlingOptionsSelector
          arm={bowlingArm}
          onArmChange={setBowlingArm}
          style={bowlingStyle}
          onStyleChange={setBowlingStyle}
        />
      )}

      {/* Upload Progress */}

      {uploading && (
        <UploadProgress
          progress={progress}
        />
      )}

      {/* Error */}

      {error && (
        <motion.div
          initial={{
            opacity: 0,
          }}
          animate={{
            opacity: 1,
          }}
          className="mt-6 rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-red-300"
        >
          {error}
        </motion.div>
      )}

      {/* Upload Button */}

      <motion.button
        whileHover={{
          scale: uploading ? 1 : 1.02,
        }}
        whileTap={{
          scale: uploading ? 1 : 0.98,
        }}
        disabled={uploading}
        onClick={handleUpload}
        className="mt-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-gold-600 via-leather-400 to-gold-400 py-4 text-lg font-bold text-white shadow-xl shadow-gold-500/30 transition disabled:cursor-not-allowed disabled:opacity-60"
      >
        {uploading ? (
          <>
            <Loader2
              size={20}
              className="animate-spin"
            />

            Uploading Video...
          </>
        ) : (
          "Analyze with CricketAI"
        )}
      </motion.button>
    </div>
  );
}
