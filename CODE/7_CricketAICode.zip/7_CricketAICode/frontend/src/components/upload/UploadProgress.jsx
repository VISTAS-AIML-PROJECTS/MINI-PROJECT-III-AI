import { motion } from "framer-motion";

export default function UploadProgress({ progress }) {
  return (
    <div className="mt-8">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-sm font-medium text-slate-300">Uploading &amp; Analyzing</span>
        <span className="text-sm font-semibold text-gold-400">{progress}%</span>
      </div>
      <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/10">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-gold-500 to-leather-300 shadow-[0_0_12px_rgba(212,160,23,0.6)]"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
