import { motion, AnimatePresence } from "framer-motion";
import { FileVideo } from "lucide-react";

export default function UploadPreview({ file }) {
  return (
    <AnimatePresence>
      {file && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="mt-8 flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-5 backdrop-blur-xl"
        >
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-gold-600 to-leather-400">
            <FileVideo size={22} className="text-white" />
          </div>
          <div className="min-w-0">
            <h3 className="truncate font-semibold text-white">{file.name}</h3>
            <p className="mt-0.5 text-sm text-slate-400">
              {(file.size / (1024 * 1024)).toFixed(2)} MB
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

