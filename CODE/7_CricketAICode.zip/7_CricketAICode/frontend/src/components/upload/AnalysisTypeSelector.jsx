import { motion } from "framer-motion";

export default function AnalysisTypeSelector({ value, onChange }) {
  const options = [
    { key: "batting", label: "Batting", emoji: "🏏" },
    { key: "bowling", label: "Bowling", emoji: "🎯" },
  ];

  return (
    <div className="mt-8">
      <label className="mb-3 block text-sm font-medium text-slate-300">Analysis Type</label>
      <div className="relative flex gap-2 rounded-2xl border border-white/10 bg-white/5 p-1.5">
        {options.map((opt) => (
          <button
            key={opt.key}
            type="button"
            onClick={() => onChange(opt.key)}
            className={`relative z-10 flex flex-1 items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold transition-colors ${
              value === opt.key ? "text-surface-abyss" : "text-slate-400"
            }`}
          >
            {value === opt.key && (
              <motion.div
                layoutId="analysisTypeIndicator"
                className="absolute inset-0 -z-10 rounded-xl bg-gradient-to-r from-gold-500 to-leather-300 shadow-lg shadow-gold-500/30"
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              />
            )}
            <span>{opt.emoji}</span>
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}

