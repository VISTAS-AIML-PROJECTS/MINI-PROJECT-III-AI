import SegmentedControl from "./SegmentedControl";

const ARM_OPTIONS = [
  { key: "right", label: "Right Arm", emoji: "🫱" },
  { key: "left", label: "Left Arm", emoji: "🫲" },
];

const STYLE_OPTIONS = [
  { key: "fast", label: "Fast", emoji: "💨" },
  { key: "spin", label: "Spin", emoji: "🌀" },
];

export default function BowlingOptionsSelector({
  arm,
  onArmChange,
  style,
  onStyleChange,
}) {
  return (
    <div className="mt-6 grid gap-6 sm:grid-cols-2">
      <SegmentedControl
        label="Bowling Arm"
        layoutId="bowlingArmIndicator"
        options={ARM_OPTIONS}
        value={arm}
        onChange={onArmChange}
      />

      <SegmentedControl
        label="Bowling Style"
        layoutId="bowlingStyleIndicator"
        options={STYLE_OPTIONS}
        value={style}
        onChange={onStyleChange}
      />
    </div>
  );
}
