import React from 'react';
import { Target, Repeat, Timer } from 'lucide-react';

export default function DrillCard({ drill, index }) {
    return (
        <div className="bg-gray-800 p-5 rounded-xl border border-gray-700 border-l-4 border-l-green-500">
            <h4 className="text-xl font-bold text-white mb-1">Drill {index + 1}: {drill.name}</h4>
            {drill.description && <p className="text-gray-400 text-sm mb-4">{drill.description}</p>}
            
            <div className="grid grid-cols-2 gap-3 text-sm text-gray-300">
                {drill.sets && drill.repetitions && (
                    <div className="flex items-center gap-2">
                        <Repeat className="w-4 h-4 text-green-400" />
                        <span>{drill.sets} sets × {drill.repetitions} reps</span>
                    </div>
                )}
                {drill.duration_estimated && (
                    <div className="flex items-center gap-2">
                        <Timer className="w-4 h-4 text-green-400" />
                        <span>{drill.duration_estimated} mins</span>
                    </div>
                )}
                {drill.difficulty && (
                    <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-green-400" />
                        <span className="capitalize">{drill.difficulty}</span>
                    </div>
                )}
            </div>
        </div>
    );
}
