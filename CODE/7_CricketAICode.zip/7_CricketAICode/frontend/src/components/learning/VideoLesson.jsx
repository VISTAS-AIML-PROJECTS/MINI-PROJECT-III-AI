import { useRef, useState, useEffect } from "react";
import {
  Play,
  Pause,
  Maximize,
  Volume2,
  VolumeX,
} from "lucide-react";

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60)
    .toString()
    .padStart(2, "0");
  return `${m}:${s}`;
}

/**
 * Reusable instructional video player.
 *
 * Props:
 *   title       - lesson title
 *   description - short explanation shown under the player
 *   src         - video URL (from skill.videos[i].path, served via /media)
 */
export default function VideoLesson({ title, description, src }) {
  const videoRef = useRef(null);
  const containerRef = useRef(null);

  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [current, setCurrent] = useState(0);
  const [speed, setSpeed] = useState(1);
  const [muted, setMuted] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onLoaded = () => setDuration(video.duration || 0);
    const onTimeUpdate = () => {
      setCurrent(video.currentTime);
      setProgress(
        video.duration ? (video.currentTime / video.duration) * 100 : 0
      );
    };
    const onEnded = () => setPlaying(false);

    video.addEventListener("loadedmetadata", onLoaded);
    video.addEventListener("timeupdate", onTimeUpdate);
    video.addEventListener("ended", onEnded);

    return () => {
      video.removeEventListener("loadedmetadata", onLoaded);
      video.removeEventListener("timeupdate", onTimeUpdate);
      video.removeEventListener("ended", onEnded);
    };
  }, []);

  function togglePlay() {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play();
      setPlaying(true);
    } else {
      video.pause();
      setPlaying(false);
    }
  }

  function handleSeek(e) {
    const video = videoRef.current;
    if (!video || !duration) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    video.currentTime = ratio * duration;
  }

  function changeSpeed(rate) {
    const video = videoRef.current;
    if (!video) return;

    video.playbackRate = rate;
    setSpeed(rate);
    setShowSpeedMenu(false);
  }

  function toggleMute() {
    const video = videoRef.current;
    if (!video) return;

    video.muted = !video.muted;
    setMuted(video.muted);
  }

  function toggleFullscreen() {
    const container = containerRef.current;
    if (!container) return;

    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      container.requestFullscreen?.();
    }
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-white/5">
      <div ref={containerRef} className="relative bg-black">
        <video
          ref={videoRef}
          src={src}
          className="aspect-video w-full"
          onClick={togglePlay}
        />

        {/* Controls bar */}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-3">

          {/* Progress bar */}
          <div
            onClick={handleSeek}
            className="mb-2 h-1.5 w-full cursor-pointer rounded-full bg-white/20"
          >
            <div
              className="h-full rounded-full bg-cyan-400"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <button onClick={togglePlay} aria-label="Play/Pause">
                {playing ? <Pause size={18} /> : <Play size={18} />}
              </button>

              <button onClick={toggleMute} aria-label="Mute">
                {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </button>

              <span className="text-xs text-slate-300">
                {formatTime(current)} / {formatTime(duration)}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <button
                  onClick={() => setShowSpeedMenu((v) => !v)}
                  className="text-xs font-semibold text-slate-300 hover:text-white"
                >
                  {speed}x
                </button>

                {showSpeedMenu && (
                  <div className="absolute bottom-7 right-0 rounded-lg border border-white/10 bg-surface-sidebar p-1 shadow-xl">
                    {SPEEDS.map((s) => (
                      <button
                        key={s}
                        onClick={() => changeSpeed(s)}
                        className={`block w-16 rounded px-2 py-1 text-left text-xs ${
                          s === speed
                            ? "bg-cyan-500/20 text-cyan-300"
                            : "text-slate-300 hover:bg-white/5"
                        }`}
                      >
                        {s}x
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <button onClick={toggleFullscreen} aria-label="Fullscreen">
                <Maximize size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <p className="font-semibold text-white">{title}</p>
        {description && (
          <p className="mt-1 text-sm text-slate-400">{description}</p>
        )}
      </div>
    </div>
  );
}

