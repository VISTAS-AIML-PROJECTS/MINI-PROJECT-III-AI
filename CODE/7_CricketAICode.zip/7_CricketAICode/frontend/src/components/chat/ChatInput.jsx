import { useState } from "react";
import { Send } from "lucide-react";
import Button from "../common/Button";

function ChatInput({ onSend, loading }) {
  const [question, setQuestion] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!question.trim()) return;

    onSend(question);

    setQuestion("");
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-3">
      <textarea
        rows={2}
        placeholder="Ask CricketAI anything..."
        value={question}
        disabled={loading}
        onChange={(e) => setQuestion(e.target.value)}
        className="flex-1 resize-none rounded-xl border border-white/10 bg-surface-sidebar p-4 text-white outline-none focus:ring-2 focus:ring-gold-500"
      />

      <Button type="submit" disabled={loading} iconRight={Send}>
        Send
      </Button>
    </form>
  );
}

export default ChatInput;
