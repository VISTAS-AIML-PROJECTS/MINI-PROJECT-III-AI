function TypingIndicator() {
  return (
    <div className="flex justify-start mb-6">
      <div className="rounded-2xl bg-slate-800 px-5 py-3 text-slate-300">
        CricketAI is thinking...
      </div>
    </div>
  );
}

export default TypingIndicator;
