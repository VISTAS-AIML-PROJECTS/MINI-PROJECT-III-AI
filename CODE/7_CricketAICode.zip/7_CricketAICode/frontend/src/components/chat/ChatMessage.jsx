import ReactMarkdown from "react-markdown";
import ConfidenceBadge from "./ConfidenceBadge";
import SourceCard from "./SourceCard";

function ChatMessage({ message }) {
  const isUser = message.role === "user";

  return (
    <div
      className={`flex ${
        isUser ? "justify-end" : "justify-start"
      } mb-6`}
    >
      <div
        className={`max-w-4xl rounded-2xl p-4 ${
          isUser
            ? "bg-gold-600 text-white"
            : "bg-surface-sidebar text-slate-100"
        }`}
      >
        {/* ============================
            User Message
        ============================ */}
        {isUser ? (
          <p>{message.content}</p>
        ) : (
          <>
            {/* AI Answer */}
            <div className="prose prose-invert max-w-none">
              <ReactMarkdown>
                {message.content}
              </ReactMarkdown>
            </div>

            {/* Confidence Badge */}
            {typeof message.confidence === "number" && (
              <div className="mt-4">
                <ConfidenceBadge
                  confidence={message.confidence}
                />
              </div>
            )}

            {/* Sources */}
            {message.sources?.length > 0 && (
              <div className="mt-4">
                <p className="mb-2 text-sm font-semibold text-slate-400">
                  📚 Sources
                </p>

                <div className="flex flex-wrap gap-2">
                  {message.sources.map((source, index) => (
                    <SourceCard
                      key={index}
                      source={source}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default ChatMessage;

