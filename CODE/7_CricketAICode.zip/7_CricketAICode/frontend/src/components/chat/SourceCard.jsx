function SourceCard({ source }) {
  return (
    <span className="inline-flex items-center rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-sm text-slate-200">
      📚 {source}
    </span>
  );
}

export default SourceCard;
