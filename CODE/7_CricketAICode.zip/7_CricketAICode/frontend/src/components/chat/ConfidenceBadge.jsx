import Badge from "../common/Badge";

function ConfidenceBadge({ confidence }) {
  const percentage = Math.round(confidence * 100);

  return (
    <Badge tone="pitch" className="mt-4">
      Confidence: {percentage}%
    </Badge>
  );
}

export default ConfidenceBadge;
