import { SCORE_THRESHOLDS } from "./constants";

export function formatDate(dateInput) {
  const date = new Date(dateInput);
  if (isNaN(date)) return "";
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

// Maps a 0-100 skill score to a readable tier label.
export function getScoreTier(score) {
  if (score >= SCORE_THRESHOLDS.STRONG) return "Elite";
  if (score >= SCORE_THRESHOLDS.DEVELOPING) return "Strong";
  if (score >= SCORE_THRESHOLDS.NEEDS_WORK) return "Developing";
  return "Needs Work";
}

// Maps a score to a semantic color key ("gold" | "positive" | "leather")
// so components can pull the right color from theme tokens.
export function getScoreColorKey(score) {
  if (score >= SCORE_THRESHOLDS.STRONG) return "gold";
  if (score >= SCORE_THRESHOLDS.DEVELOPING) return "positive";
  if (score >= SCORE_THRESHOLDS.NEEDS_WORK) return "muted";
  return "leather";
}

export function getInitials(name = "") {
  const parts = name.trim().split(/\s+/);
  const initials = parts.slice(0, 2).map((p) => p.charAt(0).toUpperCase());
  return initials.join("") || "?";
}

// Simple class name joiner — skips falsy values, no dependency needed.
export function classNames(...args) {
  return args.filter(Boolean).join(" ");
}

// Given an array of { date, score } sorted oldest-to-newest, returns the
// change between the first and last entry, e.g. for a "+8 pts" summary.
export function calculateChange(series = []) {
  if (series.length < 2) return 0;
  return series[series.length - 1].score - series[0].score;
}

export function truncate(text = "", maxLength = 80) {
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength).trimEnd()}…`;
}

// Basic debounce, e.g. for a search input.
export function debounce(fn, delayMs = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delayMs);
  };
}

