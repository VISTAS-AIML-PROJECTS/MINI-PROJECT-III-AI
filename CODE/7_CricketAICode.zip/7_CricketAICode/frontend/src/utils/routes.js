// Central source of truth for paths — components and <Route> definitions
// should reference these instead of hardcoding strings, so a path only
// ever needs to change in one place.
export const ROUTES = {
  HOME: "/",
  ABOUT: "/about",

  AI_COACH: "/ai-coach",
  VIDEO_UPLOAD: "/video-upload",

  DASHBOARD: "/dashboard",
  PRACTICE_PLANNER: "/practice-planner",
  HISTORY: "/history",

  PROFILE: "/profile",
  SETTINGS: "/settings",

  LOGIN: "/login",
  REGISTER: "/register",

  NOT_FOUND: "*",
};

// Pages that don't require an authenticated user.
export const PUBLIC_ROUTES = [ROUTES.HOME, ROUTES.ABOUT, ROUTES.LOGIN, ROUTES.REGISTER];

// Pages that should redirect to /login if there's no user — pair with a
// ProtectedRoute wrapper that checks useAuth().isAuthenticated.
export const PROTECTED_ROUTES = [
  ROUTES.AI_COACH,
  ROUTES.VIDEO_UPLOAD,
  ROUTES.DASHBOARD,
  ROUTES.PRACTICE_PLANNER,
  ROUTES.HISTORY,
  ROUTES.PROFILE,
  ROUTES.SETTINGS,
];

// Matches the Sidebar's nav items — kept here so Sidebar, Topbar, and any
// breadcrumb/redirect logic all stay in sync with the same list.
export const DASHBOARD_NAV = [
  { label: "Dashboard", path: ROUTES.DASHBOARD },
  { label: "AI Coach", path: ROUTES.AI_COACH },
  { label: "Video Upload", path: ROUTES.VIDEO_UPLOAD },
  { label: "Practice Planner", path: ROUTES.PRACTICE_PLANNER },
  { label: "History", path: ROUTES.HISTORY },
  { label: "Profile", path: ROUTES.PROFILE },
];

