export const PLAYING_ROLES = [
  "Batsman",
  "Bowler",
  "All-Rounder",
  "Wicket Keeper",
];

export const SKILL_LEVELS = [
  "Beginner",
  "Intermediate",
  "Advanced",
];
