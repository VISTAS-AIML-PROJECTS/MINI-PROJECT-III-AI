// Page title/subtitle shown in the Topbar, keyed by route pathname prefix.
// Checked longest-prefix-first so nested routes (e.g. /skills/:id) resolve
// correctly without needing an entry per dynamic id.
const ROUTE_META = [
  { prefix: "/dashboard", title: "Dashboard", subtitle: "Your performance at a glance" },
  { prefix: "/upload", title: "Upload Analysis", subtitle: "Get AI-powered feedback on your technique" },
  { prefix: "/analysis", title: "Analysis Report", subtitle: "Your technique, broken down" },
  { prefix: "/skills", title: "Skill Library", subtitle: "Master cricket shots and techniques" },
  { prefix: "/history", title: "History", subtitle: "Every analysis you've run" },
  { prefix: "/coach", title: "AI Coach", subtitle: "Ask questions about your analysis" },
  { prefix: "/profile", title: "Profile", subtitle: "Your account and stats" },
  { prefix: "/planner", title: "Practice Plan", subtitle: "Coming soon" },
  { prefix: "/progress", title: "Progress", subtitle: "Coming soon" },
  { prefix: "/leaderboard", title: "Leaderboard", subtitle: "Coming soon" },
  { prefix: "/settings", title: "Settings", subtitle: "Coming soon" },
];

export function getRouteMeta(pathname) {
  const match = ROUTE_META.find((entry) => pathname.startsWith(entry.prefix));
  return match || { title: "CricketAI", subtitle: "" };
}
