import {
  PLAYING_ROLES,
  SKILL_LEVELS,
  ACCEPTED_VIDEO_TYPES,
  MAX_VIDEO_SIZE_MB,
} from "./constants";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function isValidEmail(email) {
  return EMAIL_REGEX.test(String(email || "").trim());
}

// At least 8 characters, one letter, one number.
export function isValidPassword(password) {
  return /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(password || "");
}

export function validateLoginForm({ email, password }) {
  const errors = {};

  if (!email?.trim()) errors.email = "Email is required.";
  else if (!isValidEmail(email)) errors.email = "Enter a valid email address.";

  if (!password) errors.password = "Password is required.";

  return { valid: Object.keys(errors).length === 0, errors };
}

export function validateRegisterForm({
  name,
  email,
  password,
  confirmPassword,
  playingRole,
  skillLevel,
}) {
  const errors = {};

  if (!name?.trim()) errors.name = "Name is required.";

  if (!email?.trim()) errors.email = "Email is required.";
  else if (!isValidEmail(email)) errors.email = "Enter a valid email address.";

  if (!password) errors.password = "Password is required.";
  else if (!isValidPassword(password))
    errors.password = "Password must be at least 8 characters and include a number.";

  if (confirmPassword !== password) errors.confirmPassword = "Passwords do not match.";

  if (playingRole && !PLAYING_ROLES.includes(playingRole))
    errors.playingRole = "Select a valid playing role.";

  if (skillLevel && !SKILL_LEVELS.includes(skillLevel))
    errors.skillLevel = "Select a valid skill level.";

  return { valid: Object.keys(errors).length === 0, errors };
}

// file: a browser File object from an <input type="file"> or drop event.
export function validateVideoFile(file) {
  if (!file) return { valid: false, error: "No file selected." };

  if (!ACCEPTED_VIDEO_TYPES.includes(file.type)) {
    return { valid: false, error: "Unsupported format. Upload an MP4 or MOV file." };
  }

  const sizeMb = file.size / (1024 * 1024);
  if (sizeMb > MAX_VIDEO_SIZE_MB) {
    return { valid: false, error: `File is too large. Max size is ${MAX_VIDEO_SIZE_MB}MB.` };
  }

  return { valid: true, error: null };
}

