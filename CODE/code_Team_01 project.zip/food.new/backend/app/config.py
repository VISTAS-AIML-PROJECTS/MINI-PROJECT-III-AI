import logging
import os
from pathlib import Path

from pydantic import AliasChoices, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

log = logging.getLogger(__name__)

# Placeholder secrets that ship in docs/examples. A deployed backend must
# never sign tokens with one of these — anyone could forge an admin JWT.
WEAK_JWT_SECRETS = {
    '', 'change-me-in-production', 'replace-this-with-a-long-random-secret',
    'secret', 'changeme', 'jwt-secret',
}
MIN_JWT_SECRET_LENGTH = 32
LOCAL_MONGODB_URL = 'mongodb://localhost:27017'


class Settings(BaseSettings):
    app_name: str = "Smart Food Expiry Detection and Reminder System"
    # "production" enables strict config validation. Render (RENDER) and
    # Vercel (VERCEL) are also always treated as production — see
    # is_production below.
    environment: str = Field('development', validation_alias=AliasChoices('APP_ENV', 'ENVIRONMENT'))
    # Connection URI only — never commit a real one. The older env names
    # (MONGODB_URI / MONGODB_DB / JWT_SECRET / ACCESS_TOKEN_MINUTES) are
    # still accepted so existing deployments keep working.
    mongodb_url: str = Field(LOCAL_MONGODB_URL, validation_alias=AliasChoices('MONGODB_URL', 'MONGODB_URI'))
    # Database name only (e.g. food_expiry) — not a URL.
    mongodb_database: str = Field('food_expiry', validation_alias=AliasChoices('MONGODB_DATABASE', 'MONGODB_DB'))
    mongodb_timeout_ms: int = 5000
    jwt_secret_key: str = Field('change-me-in-production', validation_alias=AliasChoices('JWT_SECRET_KEY', 'JWT_SECRET'))
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = Field(60 * 24, validation_alias=AliasChoices('ACCESS_TOKEN_EXPIRE_MINUTES', 'ACCESS_TOKEN_MINUTES'))
    upload_dir: str = "./uploads"
    max_upload_mb: int = 8
    ocr_confidence_threshold: float = 0.75
    classification_high_threshold: float = 0.85
    classification_medium_threshold: float = 0.60
    reminder_days_default: int = 3
    default_timezone: str = "Asia/Kolkata"
    reminder_scheduler_enabled: bool = True
    model_name: str = "imagenet"
    model_version: str = "demo-1"
    # Banana ripeness classifier (V1, MobileNetV3Small). Loaded read-only and
    # only served if the file matches the evaluated checkpoint's SHA-256.
    # Needs tensorflow (requirements-banana.txt); without it the endpoint
    # returns 503 and everything else keeps working.
    banana_model_path: str = str(Path(__file__).resolve().parents[2] / 'ml' / 'banana' / 'checkpoints' / 'best.keras')
    banana_model_sha256: str = 'f33362eb93d147465f52c5edd02912afa8d9f5deccd2a66e96c8fac8f0e530fa'
    banana_min_confidence: float = 0.60
    banana_preload: bool = True
    cors_origins: str = "http://localhost:5173"
    # Leave smtp_host empty to disable real email sending — reminders still
    # get created and shown in the in-app bell either way; only the actual
    # email delivery is skipped. For Gmail: smtp_host=smtp.gmail.com,
    # smtp_port=587, smtp_user=your address, smtp_password=a 16-character
    # App Password (Google Account -> Security -> 2-Step Verification ->
    # App Passwords — a normal Gmail password will NOT work here).
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @model_validator(mode='after')
    def _serverless_upload_dir(self):
        # Vercel's filesystem is read-only except /tmp.
        if os.environ.get('VERCEL') and not os.path.isabs(self.upload_dir):
            self.upload_dir = '/tmp/uploads'
        return self

    @property
    def is_production(self) -> bool:
        return (self.environment.lower() in ('production', 'prod')
                or bool(os.environ.get('RENDER')) or bool(os.environ.get('VERCEL')))


def validate_settings(s: Settings) -> None:
    """Fail fast on insecure or malformed configuration. Error messages
    name the offending variable but never echo its value, since values
    here (MongoDB URL, JWT secret) are credentials."""
    errors = []
    name = s.mongodb_database
    if not name or '://' in name or any(c in name for c in '/\\. "$'):
        errors.append('MONGODB_DATABASE must be a plain database name (e.g. food_expiry), not a connection URL.')
    lowered = s.mongodb_url.lower()
    if 'tlsallowinvalidcertificates=true' in lowered or 'tlsinsecure=true' in lowered:
        errors.append('MONGODB_URL must not disable TLS certificate verification.')
    weak_secret = s.jwt_secret_key in WEAK_JWT_SECRETS or len(s.jwt_secret_key) < MIN_JWT_SECRET_LENGTH
    if s.is_production:
        if weak_secret:
            errors.append(f'JWT_SECRET_KEY is missing, a known placeholder, or shorter than {MIN_JWT_SECRET_LENGTH} characters.')
        if s.mongodb_url == LOCAL_MONGODB_URL:
            errors.append('MONGODB_URL is not set.')
    elif weak_secret:
        log.warning('JWT_SECRET_KEY is weak/default — acceptable for local development only.')
    if errors:
        raise RuntimeError('Invalid configuration:\n  - ' + '\n  - '.join(errors))


settings = Settings()
