from datetime import date, datetime
from pydantic import BaseModel, EmailStr, Field, ConfigDict, field_validator, model_validator
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

def _valid_timezone(v:str)->str:
    try: ZoneInfo(v)
    except (ZoneInfoNotFoundError, ValueError): raise ValueError(f'Unknown timezone: {v}')
    return v

class RegisterIn(BaseModel):
    name:str=Field(min_length=1,max_length=120); email:EmailStr; password:str=Field(min_length=8,max_length=128); timezone:str='Asia/Kolkata'
    @field_validator('timezone')
    @classmethod
    def _tz(cls,v:str)->str: return _valid_timezone(v)
class LoginIn(BaseModel): email:EmailStr; password:str
class UserOut(BaseModel): model_config=ConfigDict(from_attributes=True); id:int; name:str; email:EmailStr; timezone:str; is_admin:bool; is_active:bool=True
class TokenOut(BaseModel): access_token:str; token_type:str='bearer'; user:UserOut
class FoodIn(BaseModel):
    name:str; category:str; scientific_name:str|None=None; aliases:list[str]=[]; image_model_label:str|None=None; default_shelf_life_days:int|None=None; default_storage_condition:str='room_temperature'
    @field_validator('aliases',mode='before')
    @classmethod
    def _split_aliases(cls,v):
        # The DB stores aliases as a comma-joined string (see Food.aliases),
        # but this field is a list[str]. Pydantic v2 does not auto-split a
        # str into a list, so normalize here for both directions: reading
        # from the ORM (str -> list) and accepting client input (list stays
        # a list; an empty string becomes []).
        if isinstance(v,str):
            return [a.strip() for a in v.split(',') if a.strip()]
        return v
class FoodOut(FoodIn): model_config=ConfigDict(from_attributes=True); id:int
class RuleIn(BaseModel):
    food_id:int; shelf_life_days:int=Field(ge=0); storage_condition:str='room_temperature'; source:str='USER_CUSTOM'; notes:str|None=None
    # Optional upper bound, for rules expressed as a range ("3–4 weeks").
    # shelf_life_days stays the lower/conservative value used for dates.
    shelf_life_days_max:int|None=Field(None,ge=0)
    @model_validator(mode='after')
    def _max_not_below_min(self):
        if self.shelf_life_days_max is not None and self.shelf_life_days_max<self.shelf_life_days:
            raise ValueError('shelf_life_days_max must be >= shelf_life_days')
        return self
class RuleOut(RuleIn): model_config=ConfigDict(from_attributes=True); id:int; user_id:int|None; confidence:float|None
class ShelfLifeOption(BaseModel):
    storage_condition:str; shelf_life_days:int; shelf_life_days_max:int|None=None; label:str; source:str|None=None; notes:str|None=None
class FoodBrief(BaseModel): id:int; name:str; category:str|None=None
class ShelfLifeRecommendationOut(BaseModel):
    food:FoodBrief; storage_condition:str|None; recommendation:ShelfLifeOption|None; options:list[ShelfLifeOption]
    reference_date:date; expected_expiry_date:date|None; message:str|None=None
class InventoryIn(BaseModel): product_name:str; food_id:int|None=None; category:str|None=None; purchase_date:date|None=None; opened_date:date|None=None; printed_expiry_date:date|None=None; estimated_expiry_date:date|None=None; final_expiry_date:date; expiry_type:str; storage_condition:str='room_temperature'; quantity:float=1; unit:str='item'; confidence:float|None=None; detection_method:str; notes:str|None=None; image_url:str|None=None
class InventoryOut(InventoryIn): model_config=ConfigDict(from_attributes=True); id:int; consumed:bool; created_at:datetime
class SettingsIn(BaseModel):
    default_reminder_days:int=Field(ge=0,le=365); notifications_enabled:bool=True; email_notifications:bool=False; push_notifications:bool=True; timezone:str='Asia/Kolkata'
    @field_validator('timezone')
    @classmethod
    def _tz(cls,v:str)->str: return _valid_timezone(v)
class SettingsOut(SettingsIn): model_config=ConfigDict(from_attributes=True); id:int; user_id:int
class Prediction(BaseModel): label:str; confidence:float
class OCRResult(BaseModel): text:str; expiry_date:date|None; confidence:float; label:str|None=None; ambiguous:bool=False
class ExpiryResult(BaseModel): date:date|None; type:str; shelf_life_days:int|None=None; source:str|None=None
class AnalyzeResponse(BaseModel): success:bool; scan_id:int; image_url:str|None; food:Prediction|None; food_source:str|None=None; predictions:list[Prediction]=[]; ocr:OCRResult; expiry:ExpiryResult|None; requires_confirmation:bool; confirmation_reason:str|None=None; processing_time:float; expiry_status:str|None=None; days_until_expiry:int|None=None
class ScanOut(BaseModel):
    model_config=ConfigDict(from_attributes=True)
    id:int; image_url:str|None; raw_ocr_text:str; detected_product:str|None; detected_expiry_date:date|None; ocr_confidence:float; classification_confidence:float; final_result:str; processing_time:float; created_at:datetime
class NotificationOut(BaseModel):
    id:int; inventory_id:int; notification_type:str; scheduled_for:datetime; sent_at:datetime|None; status:str; created_at:datetime
    product_name:str|None=None; final_expiry_date:date|None=None
class QuickFoodIn(BaseModel):
    name:str=Field(min_length=1,max_length=120)
    category:str=Field('Uncategorized',max_length=60)
    shelf_life_days:int=Field(ge=0,le=3650)
    storage_condition:str=Field('room_temperature',pattern=r'^[a-z_]{1,40}$')
    @field_validator('name','category')
    @classmethod
    def _collapse_whitespace(cls,v:str)->str:
        return ' '.join(v.split())
