import logging
import os
import threading
from contextlib import asynccontextmanager
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from apscheduler.schedulers.background import BackgroundScheduler
from .config import settings, validate_settings
from . import database
from .routes.api import router

log = logging.getLogger(__name__)
# uvicorn only configures its own loggers; show the app's INFO lines (e.g.
# each banana model prediction) without the scheduler's per-minute chatter.
if not logging.getLogger().handlers:
    logging.basicConfig(level=logging.INFO, format='%(levelname)s:     %(name)s - %(message)s')
logging.getLogger('apscheduler').setLevel(logging.WARNING)

# Refuse to boot with an insecure production config (weak JWT secret,
# missing MONGODB_URL, URL in MONGODB_DATABASE, TLS verification off).
validate_settings(settings)

os.makedirs(settings.upload_dir,exist_ok=True)

# Serverless instances (Vercel) freeze between requests, so a background
# thread can't be relied on there — Vercel Cron hits /api/cron/reminders
# instead (see vercel.json), and GET /api/notifications sweeps on read.
IS_SERVERLESS=bool(os.environ.get('VERCEL'))

# Background reminder scheduler: every 60s, deliver any due PENDING
# notifications (see services/reminder_service.py::send_due). PyMongo is
# thread-safe, so calling it from APScheduler's background thread is safe.
scheduler=BackgroundScheduler(timezone='UTC')

def sweep():
    from .services.reminder_service import send_due
    try:
        send_due(database.get_db())
    except Exception:
        log.exception('reminder sweep failed')

def _preload_banana():
    from .services.banana_service import BananaModelUnavailable, classifier
    try:
        classifier.ensure_loaded()
    except BananaModelUnavailable as exc:
        log.warning('Banana classifier not available: %s', exc)

@asynccontextmanager
async def lifespan(app:FastAPI):
    try:
        database.init_indexes()
    except Exception as exc:
        # Keep serving so /health can report the outage; never log the URL.
        log.error('MongoDB unavailable at startup (%s); indexes not ensured.', type(exc).__name__)
    if settings.reminder_scheduler_enabled and not IS_SERVERLESS:
        scheduler.add_job(sweep,'interval',seconds=60,id='reminder_sweep',replace_existing=True,coalesce=True,max_instances=1)
        scheduler.start()
    if settings.banana_preload and not IS_SERVERLESS:
        # Load TensorFlow + the banana model in the background so the first
        # banana scan is fast; failures are reported by the endpoint/health.
        threading.Thread(target=_preload_banana,daemon=True,name='banana-preload').start()
    yield
    if scheduler.running: scheduler.shutdown(wait=False)

app=FastAPI(title=settings.app_name,version='1.0.0',lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in settings.cors_origins.split(',')],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.mount('/uploads',StaticFiles(directory=settings.upload_dir),name='uploads')
app.include_router(router)

@app.exception_handler(Exception)
async def unhandled_error(request:Request,exc:Exception):
    # Same {"detail": ...} shape as every HTTPException; the traceback goes
    # to the server log only, never to the client.
    log.exception('Unhandled error on %s %s', request.method, request.url.path)
    return JSONResponse(status_code=500,content={'detail':'Internal server error'})

@app.get('/api/cron/reminders')
def cron_reminders(authorization:str|None=Header(default=None)):
    secret=os.environ.get('CRON_SECRET')
    if not secret or authorization!=f'Bearer {secret}': raise HTTPException(401,'Unauthorized')
    from .services.reminder_service import send_due
    return {'sent':send_due(database.get_db())}

@app.get('/health')
def health():
    from .services.ocr_service import USE_TESSEROCR
    db_ok=database.ping()
    body={'status':'ok' if db_ok else 'degraded','database':'ok' if db_ok else 'unavailable',
          'ocr_adapter':'tesserocr' if USE_TESSEROCR else 'tesseract','food_recognition_adapter':settings.model_name}
    return JSONResponse(status_code=200 if db_ok else 503,content=body)
