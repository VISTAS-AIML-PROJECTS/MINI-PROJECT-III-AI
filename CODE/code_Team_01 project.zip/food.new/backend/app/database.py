from datetime import date, datetime, time as dtime
from pymongo import MongoClient, ReturnDocument
from pymongo.errors import OperationFailure
from .config import settings

# One client for the whole process (it pools connections internally).
# tz_aware=True makes every datetime read back as timezone-aware UTC, so
# API responses carry an explicit offset instead of being misread by the
# browser as local time. TLS verification stays at the driver default.
client = MongoClient(
    settings.mongodb_url,
    serverSelectionTimeoutMS=settings.mongodb_timeout_ms,
    connectTimeoutMS=settings.mongodb_timeout_ms,
    tz_aware=True,
    appname='smartfood-backend',
)
db = client[settings.mongodb_database]

def ping() -> bool:
    """True if MongoDB answers within the server-selection timeout."""
    try:
        client.admin.command('ping')
        return True
    except Exception:
        return False

def get_db():
    """PyMongo's client is thread-safe and pools connections internally,
    so — unlike SQLAlchemy's Session — there's no per-request object to
    create or tear down. This just hands back the same db handle every
    time; kept as a function (rather than importing `db` directly
    everywhere) so route signatures didn't need to change."""
    return db

def next_id(name: str) -> int:
    """Atomically issues the next integer id for a given collection name,
    via a dedicated `counters` collection. Mongo's native _id is an
    ObjectId, but the frontend (and every Pydantic schema here) expects
    plain integer ids — this keeps that contract intact without touching
    the frontend at all. Every document below stores its id in a normal
    `id` field; Mongo's own `_id` is left as its auto-generated default
    and never referenced by application code."""
    doc = db.counters.find_one_and_update(
        {"_id": name}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER
    )
    return doc["seq"]

def d2dt(d):
    """date -> datetime at midnight, for Mongo storage (BSON has no bare
    date type — only datetime). Passes datetime/None through unchanged."""
    if d is None or isinstance(d, datetime):
        return d
    if isinstance(d, date):
        return datetime.combine(d, dtime.min)
    return d

def dt2d(dt):
    """The inverse of d2dt — datetime -> date, for reading date-only
    fields back out. Passes date/None through unchanged."""
    if dt is None or isinstance(dt, date) and not isinstance(dt, datetime):
        return dt
    if isinstance(dt, datetime):
        return dt.date()
    return dt

def init_indexes():
    """Mongo only indexes _id (an ObjectId we never use) by default.
    Without indexing our own app-level `id` field, every current_user()
    call and every /foods/{fid}-style lookup would be a full collection
    scan. Also enforces the uniqueness the original SQLAlchemy models
    declared (User.email, Food.name) at the database level, not just in
    application pre-checks. Safe to call on every startup — create_index
    is a no-op if the index already exists with the same options."""
    db.users.create_index("id", unique=True)
    db.users.create_index("email", unique=True)
    db.foods.create_index("id", unique=True)
    # Food names are unique per owner: the global catalog (owner_id=None)
    # plus each user's private quick-added foods. Replaces the original
    # globally-unique "name" index, which would stop two users privately
    # adding the same food.
    _drop_index_if_exists(db.foods, "name_1")
    db.foods.create_index([("name", 1), ("owner_id", 1)], unique=True)
    db.shelf_life_rules.create_index("id", unique=True)
    db.shelf_life_rules.create_index([("food_id", 1), ("user_id", 1), ("storage_condition", 1)])
    db.inventory.create_index("id", unique=True)
    db.inventory.create_index("user_id")
    db.scans.create_index("id", unique=True)
    db.scans.create_index("user_id")
    db.notifications.create_index("id", unique=True)
    db.notifications.create_index([("status", 1), ("scheduled_for", 1)])
    db.notifications.create_index([("user_id", 1), ("scheduled_for", -1)])
    db.notifications.create_index("inventory_id")
    # At most one PENDING notification of each type per inventory item —
    # enforced by the database so concurrent reschedules can't duplicate.
    db.notifications.create_index(
        [("inventory_id", 1), ("notification_type", 1)], unique=True,
        partialFilterExpression={"status": "PENDING"}, name="one_pending_per_item_type",
    )
    db.user_settings.create_index("id", unique=True)
    db.user_settings.create_index("user_id", unique=True)


def _drop_index_if_exists(collection, name):
    try:
        if name in collection.index_information():
            collection.drop_index(name)
    except OperationFailure:
        pass
