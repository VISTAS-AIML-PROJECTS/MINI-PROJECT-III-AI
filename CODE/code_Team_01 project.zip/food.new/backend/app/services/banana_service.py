"""Banana ripeness classification with the V1 MobileNetV3Small checkpoint.

The checkpoint is opened read-only and only used if its SHA-256 matches the
evaluated V1 model. Preprocessing reproduces training exactly (see
ml/banana/data.py::load_image): RGB -> 224x224 bilinear resize (stretched)
-> float32 in [0, 255]; MobileNetV3's own normalisation is inside the model.
EXIF orientation is applied first (phone photos are often stored sideways).

The predicted class is a ripeness/condition label only — never a shelf life.
"""
import hashlib
import logging
import threading
from pathlib import Path

import numpy as np
from PIL import Image

from ..config import settings

log = logging.getLogger(__name__)

# Output order of the V1 model = sorted training folder names.
CLASSES = ['overripe', 'ripe', 'rotten', 'unripe']
IMG_SIZE = 224
UNCERTAIN_MESSAGE = 'Banana condition is uncertain. Please capture one banana clearly.'


class BananaModelUnavailable(RuntimeError):
    pass


class BananaClassifier:
    def __init__(self, path: str, expected_sha256: str):
        self.path = Path(path)
        self.expected_sha256 = expected_sha256.lower()
        self._model = None
        self._tf = None
        self._lock = threading.Lock()
        self.error: str | None = None

    def _load(self):
        if not self.path.is_file():
            raise BananaModelUnavailable(f'Banana model not found at {self.path}')
        digest = hashlib.sha256(self.path.read_bytes()).hexdigest()
        if digest != self.expected_sha256:
            raise BananaModelUnavailable('Banana model file does not match the evaluated V1 checkpoint (SHA-256 mismatch)')
        try:
            import keras
            import tensorflow as tf
        except ImportError as exc:
            raise BananaModelUnavailable('TensorFlow is not installed (pip install -r requirements-banana.txt)') from exc
        model = keras.models.load_model(self.path, compile=False)  # read-only: never saved back
        if model.output_shape[-1] != len(CLASSES):
            raise BananaModelUnavailable(f'Unexpected model output size {model.output_shape[-1]}')
        self._tf, self._model = tf, model
        log.info('Banana model loaded from %s (sha256 %s…)', self.path, digest[:12])

    def ensure_loaded(self):
        if self._model is not None:
            return
        with self._lock:
            if self._model is None:
                try:
                    self._load(); self.error = None
                except BananaModelUnavailable as exc:
                    self.error = str(exc)
                    raise

    def preprocess(self, image: Image.Image) -> np.ndarray:
        """`image` must already be EXIF-oriented. Same ops as training."""
        tf = self._tf
        x = tf.image.resize(tf.convert_to_tensor(np.asarray(image.convert('RGB'), dtype=np.uint8)),
                            (IMG_SIZE, IMG_SIZE), method='bilinear')
        return tf.cast(x, tf.float32).numpy()

    def classify(self, image: Image.Image) -> dict:
        self.ensure_loaded()
        probs = self._model(self.preprocess(image)[None], training=False).numpy()[0].astype(float)
        order = np.argsort(probs)[::-1]
        top = CLASSES[order[0]]; conf = float(probs[order[0]])
        uncertain = conf < settings.banana_min_confidence
        log.info('Banana prediction: %s %.4f | %s', top, conf,
                 ', '.join(f'{CLASSES[i]}={probs[i]:.4f}' for i in order))
        return {
            'food': 'banana',
            'predicted_class': top,
            'confidence': round(conf, 4),
            'top3': [{'class': CLASSES[i], 'confidence': round(float(probs[i]), 4)} for i in order[:3]],
            'probabilities': {c: round(float(probs[i]), 4) for i, c in enumerate(CLASSES)},
            'uncertain': uncertain,
            'message': UNCERTAIN_MESSAGE if uncertain else None,
            'model': {'name': 'banana_mobilenetv3small_v1', 'sha256': self.expected_sha256[:16]},
        }


classifier = BananaClassifier(settings.banana_model_path, settings.banana_model_sha256)
