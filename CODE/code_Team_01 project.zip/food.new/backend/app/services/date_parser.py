import re
from datetime import date, timedelta
from calendar import monthrange

PASS_SEPARATOR = '\n\n<<<OCR_PASS_BOUNDARY>>>\n\n'

# Strong expiry/use-by labels. These should beat ordinary dates.
LABELS = re.compile(
    r'\b('
    r'EXP(?:IRY)?(?:\.?\s*DATE)?|EXPIRES|EXPIRATION|'
    r'USE\s*BY|USE\s*BEFORE|CONSUME\s*BY|'
    r'BEST\s*BEFORE(?:\s*END)?|BBE|'
    r'VALID\s*UNTIL|VALID\s*UP\s*TO'
    r')\b', re.I
)

# Dates next to these labels are NOT expiry dates.
NON_EXP = re.compile(
    r'\b('
    r'MFD|MFG|MANUFACTURED(?:\s*ON)?|'
    r'PACKED(?:\s*ON)?|PKD|PKG|DATE\s*OF\s*PACKING|'
    r'DOM|BATCH(?:\s*NO\.?)?|LOT(?:\s*NO\.?)?|'
    r'MACHINE(?:\s*CODE)?'
    r')\b', re.I
)

# Normal printed date formats.
PATTERNS = [
    (r'\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b', 'dmy'),
    (r'\b(\d{4})[/-](\d{1,2})[/-](\d{1,2})\b', 'ymd'),
    (r'\b(\d{1,2})[.](\d{1,2})[.](\d{2,4})\b', 'dmydot'),
    (r'\b(\d{1,2})[/-](\d{1,2})[/-](\d{2})\b', 'dmy2'),
    (r'\b(\d{2})(\d{2})(\d{2})\b', 'dmy6'),
    (r'\b(\d{1,2})[/-](\d{2})\b', 'my'),
    (r'\b(\d{1,2})[/-](\d{4})\b', 'my4'),
]

def _date(*args):
    *vals, kind = args
    a, b, c = (vals + [None, None, None])[:3]
    try:
        if kind == 'dmy':
            y = int(c)
            y += 2000 if y < 100 else 0
            return date(y, int(b), int(a))
        if kind == 'ymd':
            return date(int(a), int(b), int(c))
        if kind == 'dmydot':
            y = int(c)
            y += 2000 if y < 100 else 0
            return date(y, int(b), int(a))
        if kind in ('dmy2', 'dmy6'):
            y = int(c)
            y += 2000 if y < 100 else 0
            return date(y, int(b), int(a))
        if kind in ('my', 'my4'):
            y = int(b)
            y += 2000 if y < 100 else 0
            return date(y, int(a), monthrange(y, int(a))[1])
    except (ValueError, TypeError):
        return None


def _clean_ocr_text(value: str) -> str:
    """Normalize common OCR mistakes without changing ordinary text."""
    value = value.replace('—', '-').replace('–', '-').replace('|', ' ')
    value = re.sub(r'[ \t]+', ' ', value)
    return value.strip()


def _parse_compact_date(token: str):
    """
    Handle dates that Tesseract commonly returns without separators.

    Examples:
        080826  -> 08/08/26
        0401127 -> 04/01/27
        080826  -> 08/08/26

    Seven digits are intentionally handled as DDMMYYY only when the
    first two digits form a valid day and the next two form a valid month.
    """
    digits = re.sub(r'\D', '', token)
    if len(digits) == 6:
        return _date(digits[:2], digits[2:4], digits[4:], 'dmy6')
    if len(digits) == 7:
        # Most likely OCR loss of the separator in DD/MM/YY.
        d = _date(digits[:2], digits[2:4], digits[5:], 'dmy2')
        if d:
            return d
        # Also allow DD/MM/YYYY if OCR produced 7 digits.
        return _date(digits[:1], digits[1:3], digits[3:], 'dmy')
    if len(digits) == 8:
        # YYYYMMDD
        d = _date(digits[:4], digits[4:6], digits[6:], 'ymd')
        if d:
            return d
        # DDMMYYYY
        return _date(digits[:2], digits[2:4], digits[4:], 'dmy')
    return None


def _date_candidates_from_text(text: str):
    """Return (date, start, end, raw) candidates from ordinary OCR text."""
    candidates = []

    for pat, kind in PATTERNS:
        for m in re.finditer(pat, text):
            d = _date(*m.groups(), kind)
            if d:
                candidates.append((d, m.start(), m.end(), m.group(0)))

    # Compact OCR dates such as 080826 / 0401127.
    for m in re.finditer(r'(?<!\d)\d{6,8}(?!\d)', text):
        d = _parse_compact_date(m.group(0))
        if d:
            candidates.append((d, m.start(), m.end(), m.group(0)))

    # Drop matches lying inside a longer match: in "12/10/2026" the
    # month/year pattern also sees "10/2026", which would otherwise
    # compete with the real date and make it look ambiguous.
    return [
        c for c in candidates
        if not any(o is not c and o[1] <= c[1] and c[2] <= o[2] and (o[2] - o[1]) > (c[2] - c[1])
                   for o in candidates)
    ]


def _nearest_label_kind(text: str, start: int, end: int, max_gap: int = 35):
    """'expiry', 'non_expiry' or None for the label governing the date at
    text[start:end]. The closest label *before* the date wins (labels
    precede their dates on packaging); a following label is only used
    when nothing precedes. So in "PKD 08/08/26 USE BY 04/01/27" each date
    is tied to its own label instead of to both."""
    labels = [(m, 'expiry') for m in LABELS.finditer(text)] +              [(m, 'non_expiry') for m in NON_EXP.finditer(text)]
    before = [(start - m.end(), kind) for m, kind in labels if m.end() <= start and start - m.end() <= max_gap]
    if before:
        return min(before)[1]
    after = [(m.start() - end, kind) for m, kind in labels if m.start() >= end and m.start() - end <= max_gap]
    if after:
        return min(after)[1]
    return None


def _score_date(d, today, expiry_nearby=False, non_exp_nearby=False,
                compact=False):
    score = 0.55

    if expiry_nearby:
        score += 0.40
    if non_exp_nearby:
        score -= 0.60
    if compact:
        score -= 0.05

    # Reasonable product-date range.
    if d < date(today.year - 2, 1, 1) or d > date(today.year + 10, 12, 31):
        score -= 0.20

    return max(0.0, min(0.99, score))


def _line_label_and_date_score(line_text: str, today: date):
    """
    Score dates in a single OCR line. Strongly prefers:
        USE BY 04/01/27
    and rejects:
        PKD 08/08/26
    """
    line = _clean_ocr_text(line_text)
    candidates = _date_candidates_from_text(line)

    if not candidates:
        return []

    results = []
    for d, start, end, raw in candidates:
        kind = _nearest_label_kind(line, start, end)
        expiry_nearby = kind == 'expiry'
        non_exp_nearby = kind == 'non_expiry'
        compact = raw.isdigit() and len(raw) >= 6 and '/' not in raw and '-' not in raw
        score = _score_date(
            d, today,
            expiry_nearby=expiry_nearby,
            non_exp_nearby=non_exp_nearby,
            compact=compact
        )
        label = 'printed_label' if expiry_nearby else 'date_only'
        if non_exp_nearby:
            label = 'non_expiry'
        results.append((d, score, label, raw, line))

    return results


def parse_expiry(text: str, today: date | None = None, ocr_lines=None):
    """
    Parse expiry information.

    If ocr_lines is supplied, it should be a list of OCR line dictionaries:
        {'text': 'USE BY 04/01/27', 'left': ..., 'top': ...}

    Spatial information lets us associate a label with the date even when
    Tesseract separates them into different OCR words.
    """
    today = today or date.today()
    text = text or ''

    candidates = []

    # First pass: individual OCR lines.
    lines = ocr_lines or []
    for idx, item in enumerate(lines):
        line_text = _clean_ocr_text(item.get('text', '') if isinstance(item, dict) else str(item))
        for d, score, label, raw, source_line in _line_label_and_date_score(line_text, today):
            candidates.append({
                'date': d,
                'score': score,
                'label': label,
                'raw': raw,
                'line': source_line,
                'line_index': idx,
                'top': item.get('top', 0) if isinstance(item, dict) else 0,
                'left': item.get('left', 0) if isinstance(item, dict) else 0,
            })

    # Second pass: neighboring OCR lines. This handles:
    #   USE BY
    #   04/01/27
    if lines:
        for i, item in enumerate(lines):
            label_text = _clean_ocr_text(item.get('text', ''))
            if not LABELS.search(label_text):
                continue

            for j in (i - 1, i + 1):
                if j < 0 or j >= len(lines):
                    continue

                date_text = _clean_ocr_text(lines[j].get('text', ''))
                for d, _, _, raw in _date_candidates_from_text(date_text):
                    candidates.append({
                        'date': d,
                        'score': 0.90,
                        'label': 'printed_label',
                        'raw': raw,
                        'line': f'{label_text} {date_text}',
                        'line_index': j,
                        'top': lines[j].get('top', 0),
                        'left': lines[j].get('left', 0),
                    })

    # Final fallback: plain OCR text.
    if not candidates:
        for d, start, end, raw in _date_candidates_from_text(text):
            prev_boundary = text.rfind(PASS_SEPARATOR, 0, start)
            next_boundary = text.find(PASS_SEPARATOR, end)
            pass_start = 0 if prev_boundary == -1 else prev_boundary + len(PASS_SEPARATOR)
            pass_end = len(text) if next_boundary == -1 else next_boundary

            window_start = max(pass_start, start - 50)
            window_end = min(pass_end, end + 50)
            window = text[window_start:window_end]
            date_pos = start - window_start

            kind = _nearest_label_kind(window, date_pos, date_pos + len(raw))
            expiry_nearby = kind == 'expiry'
            non_exp_nearby = kind == 'non_expiry'

            if non_exp_nearby:
                continue

            compact = raw.isdigit() and len(raw) >= 6
            score = _score_date(d, today, expiry_nearby, False, compact)
            candidates.append({
                'date': d,
                'score': score,
                'label': 'printed_label' if expiry_nearby else 'date_only',
                'raw': raw,
                'line': window,
                'line_index': -1,
                'top': 0,
                'left': 0,
            })

    if not candidates:
        return None, 0.0, None, False, None

    # Same date can be discovered multiple times by OCR passes.
    candidates.sort(key=lambda x: x['score'], reverse=True)

    best = candidates[0]
    best_date = best['date']

    # Ambiguous only when similarly-scored dates are close in confidence.
    top_score = best['score']
    competing = [
        c for c in candidates[1:]
        if c['date'] != best_date and c['score'] >= top_score - 0.12
    ]

    return (
        best_date,
        best['score'],
        best['label'],
        bool(competing),
        best
    )


def extract_date_fields(text: str, ocr_lines=None, today: date | None = None):
    """
    Extract both packing/manufacturing date and expiry date.

    Expiry selection prioritizes explicit expiry labels such as:
    USE BY, EXP, EXPIRY, BEST BEFORE, SELL BY, CONSUME BY.

    Packing/manufacturing dates such as PKD, MFD, MFG, LOT and BATCH
    are kept separate and must not make an expiry date ambiguous.
    """
    today = today or date.today()
    lines = ocr_lines or []

    expiry_candidates = []
    packing_candidates = []

    # ---------------------------------------------------------------
    # 1. Analyze each OCR line using the line-aware date classifier.
    # ---------------------------------------------------------------
    for idx, item in enumerate(lines):
        line_text = _clean_ocr_text(
            str(item.get('text', ''))
        )

        if not line_text:
            continue

        for d, score, label, raw, source_line in _line_label_and_date_score(
            line_text,
            today
        ):
            candidate = {
                'date': d,
                'score': score,
                'label': label,
                'raw': raw,
                'line': source_line,
                'index': idx,
                'top': item.get('top', 0),
                'left': item.get('left', 0),
            }

            # The existing helper uses "printed_label" for dates that
            # were identified as expiry-labelled dates.
            if label == 'printed_label':
                expiry_candidates.append(candidate)
            elif NON_EXP.search(source_line):
                packing_candidates.append(candidate)

    # ---------------------------------------------------------------
    # 2. Also use the general parser.
    #
    # This is important because OCR can split:
    #
    #     USE BY
    #     04/01/27
    #
    # across two separate OCR lines.
    # ---------------------------------------------------------------
    parsed_date, parsed_score, parsed_label, parsed_ambiguous, parsed_best = (
        parse_expiry(
            text,
            today=today,
            ocr_lines=lines
        )
    )

    # A manufacturing/packing date is never an expiry candidate, even as
    # the parser's only (zero-scored) result.
    if parsed_best and parsed_best.get('label') != 'non_expiry':
        # Don't blindly add a duplicate. The same date may already have
        # been discovered by the line-aware pass.
        already_present = any(
            c['date'] == parsed_best['date']
            for c in expiry_candidates
        )

        if not already_present:
            expiry_candidates.append({
                'date': parsed_best['date'],
                'score': parsed_best['score'],
                'label': parsed_best.get('label'),
                'raw': parsed_best.get('raw'),
                'line': parsed_best.get('line', ''),
                'index': parsed_best.get('line_index', -1),
                'top': 0,
                'left': 0,
            })

    # ---------------------------------------------------------------
    # 3. Deduplicate dates.
    #
    # OCR may produce:
    #
    #     04701127
    #     04901127
    #     4901127
    #
    # but several of those can resolve to the same actual date.
    # They should NOT create ambiguity.
    # ---------------------------------------------------------------
    best_by_date = {}
    support = {}      # date -> how many OCR passes/lines read it
    raws = {}         # date -> every raw string it was read from

    for c in expiry_candidates:
        d = c['date']
        support[d] = support.get(d, 0) + 1
        raws.setdefault(d, set()).add(re.sub(r'\s+', '', str(c.get('raw') or '')))

        if d not in best_by_date:
            best_by_date[d] = c
            continue

        existing = best_by_date[d]

        if c['score'] > existing['score']:
            best_by_date[d] = c
        elif (
            c['score'] == existing['score']
            and c.get('label')
            and not existing.get('label')
        ):
            best_by_date[d] = c

    # A date read ONLY as the tail of another reading is an OCR fragment, not
    # a second date: Tesseract often splits digits ("1 5/08/2026"), which
    # makes "5/08/2026" parse as 5 August next to the real 15 August.
    all_raws = {r for rs in raws.values() for r in rs if r}
    fragments = {
        d for d, rs in raws.items()
        if rs and all(any(o != r and o.endswith(r) for o in all_raws - rs) for r in rs)
    }
    for d in fragments:
        best_by_date.pop(d, None)

    # Equal scores: prefer the date most OCR passes agree on.
    expiry_candidates = sorted(
        best_by_date.values(),
        key=lambda x: (x['score'], support.get(x['date'], 0)),
        reverse=True
    )

    # ---------------------------------------------------------------
    # 4. Select the strongest expiry candidate.
    # ---------------------------------------------------------------
    best_exp = expiry_candidates[0] if expiry_candidates else None

    # ---------------------------------------------------------------
    # 5. Determine genuine ambiguity.
    #
    # A packing date such as:
    #
    #     PKD 08/08/26
    #
    # must NOT compete with:
    #
    #     USE BY 04/01/27
    #
    # Repeated OCR interpretations of 04/01/27 have already been
    # deduplicated above.
    # ---------------------------------------------------------------
    ambiguous = False

    if best_exp:
        for candidate in expiry_candidates[1:]:
            if candidate['date'] == best_exp['date']:
                continue

            line_text = str(candidate.get('line', ''))

            # Never allow packing/manufacturing/lot dates to create
            # expiry ambiguity.
            if NON_EXP.search(line_text):
                continue

            candidate_label = str(
                candidate.get('label') or ''
            ).upper()

            if any(
                marker in candidate_label
                for marker in (
                    'PKD',
                    'PKG',
                    'PACKED',
                    'MFD',
                    'MFG',
                    'MANUFACTURED',
                    'LOT',
                    'BATCH',
                    'DOM',
                )
            ):
                continue

            # Only a genuinely competing expiry-labelled candidate
            # counts as ambiguous.
            if (
                candidate.get('label')
                and candidate['score'] >= best_exp['score'] - 0.10
            ):
                ambiguous = True
                break

    # If parse_expiry found a genuine ambiguity that survives the same
    # filtering, preserve it.
    if parsed_best and parsed_ambiguous and best_exp:
        # Only preserve parser ambiguity if the parser's competing
        # evidence is actually a different expiry date. The main
        # candidate aggregation above is authoritative.
        ambiguous = ambiguous or False

    # ---------------------------------------------------------------
    # 6. Packing date.
    # ---------------------------------------------------------------
    packing_candidates.sort(
        key=lambda x: x['score'],
        reverse=True
    )

    packing_date = (
        packing_candidates[0]['date']
        if packing_candidates
        else None
    )

    # ---------------------------------------------------------------
    # 6b. Relative shelf life: "BEST BEFORE 6 MONTHS (FROM MFD)".
    # Only used when no explicit expiry date was printed, and only when
    # the packing/manufacturing date it is relative to was found.
    # ---------------------------------------------------------------
    if not best_exp and packing_date:
        all_text = ' '.join([text or ''] + [str(i.get('text', '')) for i in lines])
        relative = _relative_shelf_life(all_text)
        if relative:
            amount, unit = relative
            best_exp = {
                'date': _add_duration(packing_date, amount, unit),
                'score': RELATIVE_EXPIRY_SCORE,
                'label': 'relative_to_packing',
            }

    # ---------------------------------------------------------------
    # 7. Final result consumed by OCRService.
    # ---------------------------------------------------------------
    return {
        'expiry_date': best_exp['date'] if best_exp else None,
        'expiry_confidence': best_exp['score'] if best_exp else 0.0,
        'expiry_label': best_exp.get('label') if best_exp else None,
        'packing_date': packing_date,
        'best_candidate': best_exp,
        'ambiguous': ambiguous if best_exp else False,
    }


# "BEST BEFORE 6 MONTHS", "USE WITHIN 30 DAYS FROM PACKAGING", ...
RELATIVE = re.compile(
    r'\b(?:BEST\s*BEFORE|USE\s*(?:BY|WITHIN|BEFORE)|CONSUME\s*(?:BY|WITHIN)|EXPIRES?\s*IN|SHELF\s*LIFE)'
    r'\s*(?:WITHIN\s*)?:?\s*(\d{1,3})\s*(DAYS?|WEEKS?|MONTHS?|YEARS?)\b', re.I
)
# Above the default OCR threshold (0.75): it's a printed statement, but
# one step weaker than an explicit printed date (0.95).
RELATIVE_EXPIRY_SCORE = 0.85


def _relative_shelf_life(text: str):
    m = RELATIVE.search(_clean_ocr_text(text or ''))
    if not m or int(m.group(1)) <= 0:
        return None
    return int(m.group(1)), m.group(2).upper().rstrip('S')


def _add_duration(start: date, amount: int, unit: str) -> date:
    if unit == 'DAY':
        return start + timedelta(days=amount)
    if unit == 'WEEK':
        return start + timedelta(weeks=amount)
    months = amount * 12 if unit == 'YEAR' else amount
    y, m = divmod(start.month - 1 + months, 12)
    y, m = start.year + y, m + 1
    return date(y, m, min(start.day, monthrange(y, m)[1]))
