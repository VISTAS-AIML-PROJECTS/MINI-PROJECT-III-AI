from datetime import datetime, timedelta, timezone
from jose import ExpiredSignatureError, JWTError, jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status
from ..config import settings

# The single password-hashing / JWT implementation for the backend.
pwd = CryptContext(schemes=['bcrypt'], deprecated='auto')


def hash_password(p: str) -> str:
    return pwd.hash(p)


def verify_password(p: str, h: str) -> bool:
    try:
        return pwd.verify(p, h)
    except (ValueError, TypeError):
        return False


def create_token(uid: int) -> str:
    now = datetime.now(timezone.utc)
    claims = {'sub': str(uid), 'iat': now, 'exp': now + timedelta(minutes=settings.access_token_expire_minutes)}
    return jwt.encode(claims, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def _unauthorized(detail: str) -> HTTPException:
    return HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail,
                         headers={'WWW-Authenticate': 'Bearer'})


def decode_token(t: str) -> int:
    try:
        payload = jwt.decode(t, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm])
        return int(payload['sub'])
    except ExpiredSignatureError:
        raise _unauthorized('Token has expired')
    except (JWTError, KeyError, ValueError, TypeError):
        raise _unauthorized('Invalid token')
