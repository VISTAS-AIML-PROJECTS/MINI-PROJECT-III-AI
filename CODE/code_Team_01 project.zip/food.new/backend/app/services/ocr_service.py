from collections import defaultdict
from pathlib import Path
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
import pytesseract
from pytesseract import Output
import os
import re
import shutil
import threading

_WINDOWS_TESSERACT = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
if os.path.exists(_WINDOWS_TESSERACT):
    pytesseract.pytesseract.tesseract_cmd = _WINDOWS_TESSERACT

# Serverless hosts (Vercel) can't apt-install the tesseract binary, so
# when it's missing we fall back to tesserocr, whose manylinux wheels
# bundle libtesseract. Its language model ships in backend/tessdata.
USE_TESSEROCR = shutil.which(pytesseract.pytesseract.tesseract_cmd) is None
TESSDATA_DIR = str(Path(__file__).resolve().parents[2] / 'tessdata')
_tess_api = None
_tess_lock = threading.Lock()


def _tesserocr_image_to_data(image, config):
    """Same output shape as pytesseract.image_to_data(..., Output.DICT)
    for the keys this service reads."""
    global _tess_api
    from tesserocr import PyTessBaseAPI, OEM, RIL, iterate_level

    psm = int(re.search(r'--psm\s+(\d+)', config).group(1))
    data = {k: [] for k in ('text', 'conf', 'block_num', 'par_num', 'line_num', 'left', 'top', 'width', 'height')}

    with _tess_lock:
        if _tess_api is None:
            _tess_api = PyTessBaseAPI(path=TESSDATA_DIR, lang='eng', oem=OEM.DEFAULT)
        api = _tess_api
        api.SetPageSegMode(psm)
        api.SetImage(image)
        api.Recognize()
        it = api.GetIterator()
        if it is None:
            return data

        block = par = line = 0
        for r in iterate_level(it, RIL.WORD):
            if r.IsAtBeginningOf(RIL.BLOCK):
                block += 1; par = 0; line = 0
            if r.IsAtBeginningOf(RIL.PARA):
                par += 1; line = 0
            if r.IsAtBeginningOf(RIL.TEXTLINE):
                line += 1
            box = r.BoundingBox(RIL.WORD)
            if box is None:
                continue
            x1, y1, x2, y2 = box
            data['text'].append(r.GetUTF8Text(RIL.WORD) or '')
            data['conf'].append(r.Confidence(RIL.WORD))
            data['block_num'].append(block)
            data['par_num'].append(par)
            data['line_num'].append(line)
            data['left'].append(x1)
            data['top'].append(y1)
            data['width'].append(x2 - x1)
            data['height'].append(y2 - y1)
    return data

from .date_parser import (
    parse_expiry,
    extract_date_fields,
    PASS_SEPARATOR,
)


class OCRService:
    """
    OCR pipeline for packaged-food expiry detection.

    Important:
    1. Run normal OCR over the image.
    2. Find expiry-label words such as USE / BY.
    3. Crop the area immediately around the label.
    4. Upscale that crop heavily.
    5. Run focused OCR on the crop.
    6. Associate the focused date with the expiry label.

    This solves cases where full-image OCR sees the date but loses the
    relationship between "USE BY" and "04/01/27".
    """

    EXPIRY_WORDS = {
        'EXP', 'EXP.', 'EXPIRY', 'EXPIRY.', 'EXPIRES', 'EXPIRATION',
        'USE', 'BY', 'BEFORE', 'CONSUME', 'BEST', 'VALID'
    }

    def _variants(self, image):
        img = image.convert('RGB')
        img.thumbnail((2200, 2200))
        gray = ImageOps.grayscale(img)

        yield gray
        yield ImageEnhance.Contrast(gray).enhance(2.5)

        sharp = ImageEnhance.Sharpness(gray).enhance(2.5)
        yield ImageEnhance.Contrast(sharp).enhance(2.0)

        auto = ImageOps.autocontrast(gray)
        yield auto.filter(ImageFilter.MedianFilter(3))

        # Useful for dark stamped/dot-matrix dates.
        yield auto.point(lambda p: 255 if p > 155 else 0)

    @staticmethod
    def _group_words_into_lines(data):
        groups = defaultdict(list)
        n = len(data['text'])

        for i in range(n):
            text = (data['text'][i] or '').strip()
            if not text:
                continue

            try:
                conf = float(data['conf'][i])
            except (ValueError, TypeError):
                conf = -1

            if conf < 5:
                continue

            key = (
                data['block_num'][i],
                data['par_num'][i],
                data['line_num'][i],
            )

            groups[key].append({
                'text': text,
                'conf': conf,
                'left': int(data['left'][i]),
                'top': int(data['top'][i]),
                'width': int(data['width'][i]),
                'height': int(data['height'][i]),
            })

        lines = []

        for words in groups.values():
            words.sort(key=lambda x: x['left'])

            left = min(w['left'] for w in words)
            top = min(w['top'] for w in words)
            right = max(w['left'] + w['width'] for w in words)
            bottom = max(w['top'] + w['height'] for w in words)

            lines.append({
                'text': ' '.join(w['text'] for w in words),
                'left': left,
                'top': top,
                'width': right - left,
                'height': bottom - top,
                'conf': sum(w['conf'] for w in words) / len(words),
                'words': words,
            })

        lines.sort(key=lambda x: (x['top'], x['left']))
        return lines

    def _run_data_ocr(self, image, config):
        if USE_TESSEROCR:
            return self._group_words_into_lines(_tesserocr_image_to_data(image, config))
        data = pytesseract.image_to_data(
            image,
            config=config,
            output_type=Output.DICT,
        )
        return self._group_words_into_lines(data)

    def _find_expiry_label_boxes(self, lines):
        """
        Find USE/BY/EXP/etc. words from the first OCR pass.
        We intentionally use individual words because Tesseract often
        separates "USE BY" into two boxes.
        """
        boxes = []

        for line in lines:
            words = line.get('words', [])

            for w in words:
                token = re.sub(r'[^A-Za-z0-9.]', '', w['text']).upper()

                if token in self.EXPIRY_WORDS:
                    boxes.append({
                        'left': w['left'],
                        'top': w['top'],
                        'right': w['left'] + w['width'],
                        'bottom': w['top'] + w['height'],
                        'text': w['text'],
                        'confidence': w['conf'],
                    })

        # Combine adjacent USE + BY boxes into one label region.
        combined = []
        used = set()

        for i, a in enumerate(boxes):
            if i in used:
                continue

            best = a.copy()

            for j, b in enumerate(boxes):
                if j == i or j in used:
                    continue

                vertical_gap = abs(
                    ((a['top'] + a['bottom']) / 2) -
                    ((b['top'] + b['bottom']) / 2)
                )
                horizontal_gap = abs(b['left'] - a['right'])

                if vertical_gap <= max(a['bottom'] - a['top'], 20) * 1.8 and horizontal_gap <= 80:
                    best['left'] = min(best['left'], b['left'])
                    best['top'] = min(best['top'], b['top'])
                    best['right'] = max(best['right'], b['right'])
                    best['bottom'] = max(best['bottom'], b['bottom'])
                    best['text'] = f"{best['text']} {b['text']}"
                    used.add(j)

            used.add(i)
            combined.append(best)

        return self._merge_overlapping_boxes(combined)

    @staticmethod
    def _merge_overlapping_boxes(boxes):
        """Every full-image pass (5 variants x 3 configs) finds the same
        label again, so without this the focused crop below was OCR'd once
        per pass — ~120 redundant Tesseract runs per scan. Boxes covering
        the same region are merged into one (their union), which crops the
        same pixels exactly once."""
        merged = []

        for box in sorted(boxes, key=lambda b: (b['top'], b['left'])):
            for m in merged:
                ix = min(m['right'], box['right']) - max(m['left'], box['left'])
                iy = min(m['bottom'], box['bottom']) - max(m['top'], box['top'])
                if ix <= 0 or iy <= 0:
                    continue
                smaller = min(
                    (m['right'] - m['left']) * (m['bottom'] - m['top']),
                    (box['right'] - box['left']) * (box['bottom'] - box['top']),
                ) or 1
                if ix * iy >= 0.5 * smaller:
                    m['left'] = min(m['left'], box['left'])
                    m['top'] = min(m['top'], box['top'])
                    m['right'] = max(m['right'], box['right'])
                    m['bottom'] = max(m['bottom'], box['bottom'])
                    break
            else:
                merged.append(dict(box))

        return merged

    def _focused_expiry_ocr(self, image, initial_lines):
        """
        Crop around detected expiry labels.

        On the supplied biscuit image, the first OCR pass finds:
            USE at x~226, y~622
            BY  at x~253, y~622

        The focused crop then sees:
            USE BY 04/01/27

        without all the ingredients/background competing for OCR attention.
        """
        width, height = image.size
        boxes = self._find_expiry_label_boxes(initial_lines)

        focused_lines = []

        for box in boxes:
            # Include enough area to the right for the date and a little
            # context above/below for labels that wrap onto another line.
            x1 = max(0, int(box['left'] - 45))
            y1 = max(0, int(box['top'] - 45))
            x2 = min(width, int(box['right'] + 300))
            y2 = min(height, int(box['bottom'] + 55))

            if x2 <= x1 or y2 <= y1:
                continue

            crop = image.crop((x1, y1, x2, y2))

            # Upscale. The printed expiry characters are small.
            crop = crop.resize(
                (max(1, crop.width * 4), max(1, crop.height * 4)),
                Image.Resampling.LANCZOS,
            )

            gray = ImageOps.grayscale(crop)
            variants = [
                gray,
                ImageOps.autocontrast(gray),
                ImageEnhance.Contrast(gray).enhance(3.0),
                ImageOps.autocontrast(gray).point(
                    lambda p: 255 if p > 150 else 0
                ),
            ]

            for variant in variants:
                for cfg in (
                    '--oem 3 --psm 6',
                    '--oem 3 --psm 11',
                ):
                    try:
                        lines = self._run_data_ocr(variant, cfg)

                        for line in lines:
                            line['focused'] = True
                            line['crop_x'] = x1
                            line['crop_y'] = y1
                            line['source_label'] = box['text']
                            focused_lines.append(line)

                    except Exception:
                        pass

        return focused_lines

    def detect_text_with_layout(self, image):
        configs = [
            '--oem 3 --psm 6',
            '--oem 3 --psm 4',
            '--oem 3 --psm 11',
        ]

        all_lines = []
        errors = []

        # Normal full-image OCR.
        for variant_index, variant in enumerate(self._variants(image)):
            for cfg in configs:
                try:
                    lines = self._run_data_ocr(variant, cfg)

                    for line in lines:
                        line['variant'] = variant_index
                        line['config'] = cfg
                        line['focused'] = False
                        all_lines.append(line)

                except Exception as exc:
                    errors.append(str(exc))

        # Targeted OCR using the layout from the first pass.
        focused = self._focused_expiry_ocr(image, all_lines)
        all_lines.extend(focused)

        if not all_lines and errors:
            print(
                '[ocr] all OCR attempts failed — is Tesseract installed? '
                f'First error: {errors[0]}'
            )

        texts = [line['text'] for line in all_lines if line['text'].strip()]
        raw_text = PASS_SEPARATOR.join(texts)

        return raw_text, all_lines

    def detect_text(self, image):
        text, _ = self.detect_text_with_layout(image)
        return text

    def analyze(self, image):
        text, lines = self.detect_text_with_layout(image)

        fields = extract_date_fields(text, lines)

        return {
            # Existing API fields — keep these so your frontend continues
            # working.
            'text': text,
            'expiry_date': fields['expiry_date'],
            'confidence': fields['expiry_confidence'],
            'label': fields['expiry_label'],
            'ambiguous': fields['ambiguous'],

            # New information.
            'packing_date': fields['packing_date'],
            'ocr_lines': [
                {
                    'text': x['text'],
                    'left': x['left'],
                    'top': x['top'],
                    'width': x['width'],
                    'height': x['height'],
                    'confidence': round(x['conf'], 1),
                    'focused': bool(x.get('focused', False)),
                }
                for x in lines
            ],
        }

