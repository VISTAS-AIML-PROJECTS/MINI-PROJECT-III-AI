from datetime import date, timedelta


def _span(days: int) -> tuple[int, str]:
    """Express a day count in the largest unit it divides into evenly."""
    if days >= 60 and days % 30 == 0:
        return days // 30, 'month'
    if days >= 14 and days % 7 == 0:
        return days // 7, 'week'
    return days, 'day'


def format_shelf_life(days: int, days_max: int | None = None) -> str:
    """Human label for a rule: 5 -> "5 days", 21 -> "3 weeks",
    (21, 28) -> "3–4 weeks", (5, 7) -> "5–7 days". Ranges only switch to
    a larger unit when both ends convert exactly — never rounded."""
    if days_max is None or days_max == days:
        n, unit = _span(days)
        return f'{n} {unit}' + ('' if n == 1 else 's')
    lo, lo_unit = _span(days)
    hi, hi_unit = _span(days_max)
    if lo_unit != hi_unit:
        lo, hi, lo_unit = days, days_max, 'day'
    return f'{lo}–{hi} {lo_unit}s'


class ShelfLifeService:
    def get_rule(self, db, food_id, user_id, storage_condition):
        """Priority: this user's rule for this exact storage condition >
        any global (user_id=None) rule for this storage condition > the
        food's own system default. Returns a dict with shelf_life_days/
        source/storage_condition, or None if nothing is configured at
        all — callers must then ask the user to set one (never invent a
        number). Small per-food rule counts, so fetching both and
        filtering in Python (rather than two separate queries) is fine."""
        rules = list(db.shelf_life_rules.find(
            {'food_id': food_id, 'storage_condition': storage_condition}, {'_id': 0}
        ))
        user_rules = [r for r in rules if r.get('user_id') == user_id]
        if user_rules:
            return user_rules[0]
        global_rules = [r for r in rules if r.get('user_id') is None]
        if global_rules:
            return global_rules[0]
        food = db.foods.find_one({'id': food_id}, {'_id': 0})
        if food and food.get('default_shelf_life_days') is not None:
            return {
                'shelf_life_days': food['default_shelf_life_days'],
                'source': 'SYSTEM_DEFAULT',
                'storage_condition': food.get('default_storage_condition') or storage_condition,
            }
        return None

    def storage_options(self, db, food, user_id):
        """Every storage condition this food has configured data for, one
        entry each, using the same precedence as get_rule (own rule >
        global rule > the food's default). Only stored data is returned —
        a storage condition with no rule is simply absent."""
        by_storage = {}
        for r in db.shelf_life_rules.find({'food_id': food['id'], 'user_id': {'$in': [None, user_id]}}, {'_id': 0}):
            current = by_storage.get(r['storage_condition'])
            if current is None or (r.get('user_id') == user_id and current.get('user_id') != user_id):
                by_storage[r['storage_condition']] = r
        default_storage = food.get('default_storage_condition')
        if food.get('default_shelf_life_days') is not None and default_storage and default_storage not in by_storage:
            by_storage[default_storage] = {'storage_condition': default_storage, 'source': 'SYSTEM_DEFAULT',
                                           'shelf_life_days': food['default_shelf_life_days']}
        return [{
            'storage_condition': storage,
            'shelf_life_days': r['shelf_life_days'],
            'shelf_life_days_max': r.get('shelf_life_days_max'),
            'label': format_shelf_life(r['shelf_life_days'], r.get('shelf_life_days_max')),
            'source': r.get('source'),
            'notes': r.get('notes'),
        } for storage, r in sorted(by_storage.items())]

    def calculate_expiry(self, reference_date: date, days: int):
        return reference_date + timedelta(days=days)
