"""Small in-process sliding-window limiter for the auth endpoints.

State lives in this process's memory: correct for the single-instance
Render deployment, best-effort on serverless (each Vercel instance keeps
its own counters). No external infrastructure required.
"""
import threading
import time
from collections import defaultdict, deque


class SlidingWindowLimiter:
    def __init__(self, max_events: int, window_seconds: int):
        self.max_events = max_events
        self.window = window_seconds
        self._events: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def _prune(self, key: str, now: float) -> deque:
        q = self._events[key]
        while q and q[0] <= now - self.window:
            q.popleft()
        return q

    def retry_after(self, key: str) -> int:
        """Seconds until `key` may try again; 0 if not limited."""
        with self._lock:
            now = time.monotonic()
            q = self._prune(key, now)
            if len(q) < self.max_events:
                return 0
            return max(1, int(q[0] + self.window - now))

    def hit(self, key: str) -> None:
        with self._lock:
            self._prune(key, time.monotonic()).append(time.monotonic())

    def reset(self, key: str | None = None) -> None:
        with self._lock:
            if key is None:
                self._events.clear()
            else:
                self._events.pop(key, None)


# Failed logins per email address — throttles password guessing against
# one account without depending on (spoofable/proxied) client IPs.
login_failures = SlidingWindowLimiter(max_events=10, window_seconds=15 * 60)
# Registrations per client IP.
registrations = SlidingWindowLimiter(max_events=10, window_seconds=60 * 60)
