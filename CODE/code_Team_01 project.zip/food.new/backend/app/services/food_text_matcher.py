"""Identify a packaged food from the text printed on its own label.

Packaging almost always states what the product is ("Digestive Biscuits",
"Farm Fresh Milk"), which is a far more reliable signal than generic image
classification — the app's ImageNet-based recognizer was trained on raw
produce/animals and has no notion of a cereal box or a milk carton. This
module is checked first; the image classifier remains a fallback for items
without printed text (loose fruit/vegetables).
"""
from __future__ import annotations

import re
from typing import Any

MIN_VARIANT_LENGTH = 3


def _name_variants(food: dict[str, Any]):
    variants = [(food['name'], True)]
    aliases = food.get('aliases') or ''
    if isinstance(aliases, str):
        parts = [a.strip() for a in aliases.split(',') if a.strip()]
    else:
        parts = [a.strip() for a in aliases if a and a.strip()]
    variants += [(a, False) for a in parts]
    return variants


def match_food_in_text(text: str, foods: list[dict[str, Any]]):
    """Return the most specific known food whose name/alias appears as a
    whole word in `text`, or None. Prefers longer (more specific) matches
    so e.g. "Coconut Milk" wins over "Milk" when both are configured foods
    and both appear in the printed text."""
    if not text or not foods:
        return None

    normalized = text.upper()
    best = None

    for food in foods:
        for variant, is_primary_name in _name_variants(food):
            variant = variant.strip()
            if len(variant) < MIN_VARIANT_LENGTH:
                continue
            pattern = r'\b' + re.escape(variant.upper()) + r'\b'
            if not re.search(pattern, normalized):
                continue
            confidence = 0.95 if is_primary_name else 0.88
            if best is None or len(variant) > len(best['matched']):
                best = {'food': food, 'confidence': confidence, 'matched': variant}

    return best
