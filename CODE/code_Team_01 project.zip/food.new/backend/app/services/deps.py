from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from ..database import get_db
from .auth import decode_token

oauth = OAuth2PasswordBearer(tokenUrl='/api/auth/login')


def is_active(user: dict) -> bool:
    # Users created before is_active existed have no field — treat as active.
    return user.get('is_active', True) is not False


def current_user(token=Depends(oauth), db=Depends(get_db)):
    # Mongo documents come back as plain dicts, not ORM objects — every
    # route reads user['id'] / user['is_admin'] etc. rather than
    # attribute access.
    user = db.users.find_one({'id': decode_token(token)}, {'_id': 0, 'password_hash': 0})
    if not user: raise HTTPException(status_code=401, detail='User not found', headers={'WWW-Authenticate': 'Bearer'})
    if not is_active(user): raise HTTPException(status_code=401, detail='Account is disabled', headers={'WWW-Authenticate': 'Bearer'})
    return user


def admin_user(user=Depends(current_user)):
    if not user.get('is_admin'): raise HTTPException(status_code=403, detail='Admin access required')
    return user
