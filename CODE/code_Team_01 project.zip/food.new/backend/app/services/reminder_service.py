import logging
import smtplib
from datetime import date, datetime, time, timedelta, timezone
from email.mime.text import MIMEText
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pymongo.errors import DuplicateKeyError
from ..database import next_id, d2dt, dt2d
from ..config import settings

log = logging.getLogger(__name__)

EXPIRY_REMINDER = 'EXPIRY_REMINDER'
EXPIRED_ALERT = 'EXPIRED_ALERT'
# Reminders fire at this hour in the *user's* timezone, not the server's.
REMINDER_LOCAL_HOUR = 9


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def user_zone(tz_name: str | None) -> ZoneInfo:
    try:
        return ZoneInfo(tz_name or settings.default_timezone)
    except (ZoneInfoNotFoundError, ValueError):
        return ZoneInfo('UTC')


def user_today(db, user_id: int, now: datetime | None = None) -> date:
    """Today's date as the user experiences it — never the server's local
    date, which on Render/Vercel is UTC."""
    s = db.user_settings.find_one({'user_id': user_id}, {'timezone': 1})
    return (now or utcnow()).astimezone(user_zone(s.get('timezone') if s else None)).date()


def _local_reminder_time(d: date, tz: ZoneInfo) -> datetime:
    return datetime.combine(d, time(REMINDER_LOCAL_HOUR), tzinfo=tz).astimezone(timezone.utc)


def cancel_pending(db, inventory_id: int) -> int:
    return db.notifications.delete_many({'inventory_id': inventory_id, 'status': 'PENDING'}).deleted_count


def sync_reminders(db, item, now: datetime | None = None) -> int:
    """(Re)build the PENDING notifications for one inventory item from its
    current expiry date and the owner's settings. Safe to call after any
    change (create, edit, settings update): pending ones are replaced, and
    a notification already SENT for the same item/type/expiry date is
    never re-created."""
    now = now or utcnow()
    cancel_pending(db, item['id'])
    if item.get('consumed'):
        return 0
    s = db.user_settings.find_one({'user_id': item['user_id']}, {'_id': 0})
    if not s or not s.get('notifications_enabled'):
        return 0
    tz = user_zone(s.get('timezone'))
    expiry = dt2d(item['final_expiry_date'])
    plans = []
    if expiry >= now.astimezone(tz).date():
        days = s.get('default_reminder_days', settings.reminder_days_default)
        plans.append((EXPIRY_REMINDER, _local_reminder_time(expiry - timedelta(days=days), tz)))
    plans.append((EXPIRED_ALERT, _local_reminder_time(expiry + timedelta(days=1), tz)))

    created = 0
    for kind, when in plans:
        # expiry_date None also matches SENT notifications created before
        # this field existed, so legacy items aren't re-notified.
        already_sent = db.notifications.find_one({
            'inventory_id': item['id'], 'notification_type': kind, 'status': 'SENT',
            'expiry_date': {'$in': [d2dt(expiry), None]},
        })
        if already_sent:
            continue
        try:
            db.notifications.insert_one({
                'id': next_id('notifications'), 'user_id': item['user_id'], 'inventory_id': item['id'],
                'notification_type': kind, 'expiry_date': d2dt(expiry), 'scheduled_for': when,
                'sent_at': None, 'status': 'PENDING', 'created_at': now,
            })
            created += 1
        except DuplicateKeyError:
            pass  # a concurrent sync already scheduled it
    return created


def sync_user_reminders(db, user_id: int) -> int:
    return sum(sync_reminders(db, i) for i in db.inventory.find({'user_id': user_id, 'consumed': False}))


def _send_email(to_email, subject, body):
    """Returns True if actually sent, False if skipped or failed. Never
    raises — a bad SMTP config or a network hiccup should never crash the
    reminder sweep; it should just fall back to in-app-only delivery for
    that notification."""
    if not settings.smtp_host or not settings.smtp_user or not settings.smtp_password:
        return False
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = settings.smtp_from or settings.smtp_user
    msg['To'] = to_email
    try:
        with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as server:
            server.starttls()
            server.login(settings.smtp_user, settings.smtp_password)
            server.sendmail(msg['From'], [to_email], msg.as_string())
        return True
    except Exception as exc:
        log.warning('[email] reminder email failed: %s', type(exc).__name__)
        return False


def send_due(db, now: datetime | None = None):
    """Deliver every due PENDING notification. Because it selects on
    scheduled_for <= now, a missed or delayed sweep simply catches up on
    the next run. Each notification is claimed with a conditional
    PENDING -> SENT update, so overlapping sweeps (scheduler + cron +
    manual trigger) never deliver it twice. Email goes out only if SMTP
    is configured AND the user enabled email; the in-app bell always
    shows it. Called by the in-process scheduler (main.py), the Vercel
    cron endpoint and POST /notifications/run-scheduler."""
    now = now or utcnow()
    count = 0
    for n in list(db.notifications.find({'status': 'PENDING', 'scheduled_for': {'$lte': now}})):
        item = db.inventory.find_one({'id': n['inventory_id']})
        if not item or item.get('consumed'):
            db.notifications.delete_one({'id': n['id'], 'status': 'PENDING'})
            continue
        expiry = dt2d(item.get('final_expiry_date'))
        if n['notification_type'] == EXPIRY_REMINDER and expiry and expiry < user_today(db, n['user_id'], now):
            # Sweep ran too late for the "expiring soon" reminder — the
            # EXPIRED_ALERT supersedes it.
            db.notifications.delete_one({'id': n['id'], 'status': 'PENDING'})
            continue
        claimed = db.notifications.update_one({'id': n['id'], 'status': 'PENDING'},
                                              {'$set': {'status': 'SENT', 'sent_at': now}})
        if claimed.modified_count != 1:
            continue
        count += 1
        user = db.users.find_one({'id': n['user_id']})
        settings_doc = db.user_settings.find_one({'user_id': n['user_id']})
        if user and settings_doc and settings_doc.get('email_notifications'):
            product = item.get('product_name', 'An item')
            expiry_str = expiry.strftime('%d %B %Y') if expiry else 'soon'
            verb = 'has expired' if n['notification_type'] == EXPIRED_ALERT else 'is expiring'
            body = (
                f"Hi {user.get('name', 'there')},\n\n"
                f"{product} {verb} on {expiry_str}. Check your SmartFood inventory to update or use it.\n\n"
                f"— SmartFood"
            )
            _send_email(user['email'], f'SmartFood: {product} {verb}', body)
    return count
