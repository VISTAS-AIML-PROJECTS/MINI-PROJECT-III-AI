"""Replaceable food recognition adapters.

The default adapter uses a real ImageNet-pretrained ResNet50 when configured.
It is intentionally conservative: ImageNet predictions are only exposed when
there is an explicit mapping to one of the application's food classes.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Any

from PIL import Image

DEMO_LABELS = [
    'tomato', 'potato', 'onion', 'carrot', 'apple', 'banana', 'orange',
    'lemon', 'bread', 'milk', 'egg', 'chicken', 'fish', 'rice'
]

# Exact/substring mappings from ImageNet labels to our normalized food classes.
# This is knowledge about model labels, NOT shelf-life knowledge.
IMAGENET_TO_FOOD = {
    'Granny Smith': 'apple', 'golden apple': 'apple', 'red apple': 'apple',
    'banana': 'banana', 'orange': 'orange', 'lemon': 'lemon',
    'potato': 'potato', 'sweet potato': 'potato', 'head cabbage': 'cabbage',
    'acorn squash': 'squash', 'butternut squash': 'squash',
    'tomato': 'tomato', 'bell pepper': 'pepper', 'red pepper': 'pepper',
    'carrot': 'carrot', 'cauliflower': 'cauliflower', 'broccoli': 'broccoli',
    'zucchini': 'zucchini', 'cucumber': 'cucumber', 'mushroom': 'mushroom',
    'onion': 'onion', 'corn': 'corn', 'ear': 'corn',
    'bagel': 'bread', 'French loaf': 'bread', 'loaf': 'bread',
    'hotdog': 'hotdog', 'cheeseburger': 'burger', 'hamburger': 'burger',
    'egg': 'egg', 'hen': 'chicken', 'rooster': 'chicken', 'cock': 'chicken',
    'broiler': 'chicken', 'grouse': 'chicken', 'partridge': 'chicken',
    'salmon': 'fish', 'trout': 'fish', 'tench': 'fish', 'goldfish': 'fish',
    'carp': 'fish', 'puffer': 'fish', 'eel': 'fish', 'gar': 'fish',
    'sturgeon': 'fish', 'coho': 'fish', 'tuna': 'fish', 'shark': 'fish',
    'sushi': 'fish', 'custard apple': 'fruit',
}


def _normalize(label: str) -> str:
    return label.strip().lower().replace('_', ' ')


@lru_cache(maxsize=1)
def _load_imagenet():
    import torch
    from torchvision.models import ResNet50_Weights, resnet50

    weights = ResNet50_Weights.DEFAULT
    model = resnet50(weights=weights)
    model.eval()
    return model, weights.transforms(), weights.meta['categories']


class FoodRecognitionService:
    """Image classification adapter with explicit mock and ImageNet modes.

    FOOD_MODEL=imagenet loads a real pretrained model lazily. FOOD_MODEL=mock
    returns no predictions and is useful when ML dependencies/model weights
    are intentionally unavailable.
    """

    def __init__(self, model_name: str | None = None, min_supported_confidence: float = 0.01):
        self.model_name = (model_name or os.getenv('FOOD_MODEL', 'imagenet')).lower()
        self.min_supported_confidence = min_supported_confidence

    def classify(self, image: Image.Image) -> list[dict[str, Any]]:
        if self.model_name == 'mock':
            return []
        if self.model_name != 'imagenet':
            raise RuntimeError(f'Unsupported FOOD_MODEL: {self.model_name}')

        try:
            import torch
            model, transform, categories = _load_imagenet()
            tensor = transform(image.convert('RGB')).unsqueeze(0)
            with torch.inference_mode():
                probabilities = torch.softmax(model(tensor), dim=1)[0]
                values, indices = torch.topk(probabilities, k=min(20, len(categories)))

            # Aggregate ImageNet labels into application food classes and keep
            # the strongest probability observed for each mapped class.
            aggregated: dict[str, float] = {}
            for value, index in zip(values.tolist(), indices.tolist()):
                raw = categories[index]
                mapped = None
                for key, food in IMAGENET_TO_FOOD.items():
                    if _normalize(key) in _normalize(raw) or _normalize(raw) == _normalize(key):
                        mapped = food
                        break
                if mapped and value >= self.min_supported_confidence:
                    aggregated[mapped] = max(aggregated.get(mapped, 0.0), float(value))

            ranked = sorted(aggregated.items(), key=lambda x: x[1], reverse=True)[:3]
            return [{'label': label, 'confidence': round(conf, 4)} for label, conf in ranked]
        except ImportError as exc:
            raise RuntimeError('Real food recognition requires torch and torchvision.') from exc
        except Exception as exc:
            raise RuntimeError(f'Food recognition model unavailable: {exc}') from exc
