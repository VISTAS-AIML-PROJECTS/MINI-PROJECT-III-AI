import io, os, time, uuid, re
from datetime import date
from pathlib import Path
from fastapi import APIRouter, Depends, File, Query, Request, UploadFile, HTTPException
from pymongo.errors import DuplicateKeyError
from PIL import Image, ImageOps
from ..config import settings
from ..database import get_db, next_id, d2dt, dt2d
from ..schemas import *
from ..services.auth import hash_password,verify_password,create_token
from ..services.deps import current_user,admin_user,is_active
from ..services.ocr_service import OCRService
from ..services.food_recognition_service import FoodRecognitionService
from ..services.food_text_matcher import match_food_in_text
from ..services.shelf_life_service import ShelfLifeService
from ..services.reminder_service import sync_reminders, sync_user_reminders, cancel_pending, send_due, user_today, utcnow
from ..services.rate_limit import login_failures, registrations

router=APIRouter(prefix='/api')
ocr=OCRService(); recognizer=FoodRecognitionService(settings.model_name); shelf=ShelfLifeService()

# Inventory fields that are date-only (BSON has no bare date type, only
# datetime — see database.py d2dt/dt2d) and need conversion on every
# write and read.
DATE_FIELDS=['purchase_date','opened_date','printed_expiry_date','estimated_expiry_date','final_expiry_date']
MAX_PAGE=500

def _ci_exact(field, value):
    """Case-insensitive EXACT match filter (whole field, never a substring)."""
    return {field: {'$regex': f'^{re.escape(value)}$', '$options': 'i'}}

def _visible_foods(user):
    """The shared catalog (owner_id None/missing) plus the caller's own
    privately quick-added foods."""
    return {'owner_id': {'$in': [None, user['id']]}}

def _get_visible_food(db, fid, user):
    f=db.foods.find_one({'id':fid, **_visible_foods(user)}, {'_id':0})
    if not f: raise HTTPException(404,'Food not found')
    return f

def _inventory_out(doc):
    for f in DATE_FIELDS: doc[f]=dt2d(doc.get(f))
    return doc

def _own_inventory(db, iid, user):
    i=db.inventory.find_one({'id':iid,'user_id':user['id']}, {'_id':0})
    if not i: raise HTTPException(404,'Inventory item not found')
    return i

def _client_ip(request:Request):
    # Behind Render's proxy request.client is the proxy; the first
    # X-Forwarded-For hop is the caller (spoofable — best-effort only).
    fwd=request.headers.get('x-forwarded-for','').split(',')[0].strip()
    return fwd or (request.client.host if request.client else 'unknown')

def _too_many(retry_after:int):
    return HTTPException(429,'Too many attempts. Please try again later.',headers={'Retry-After':str(retry_after)})

# ---------------------------------------------------------------- auth

@router.post('/auth/register',response_model=TokenOut)
def register(x:RegisterIn,request:Request,db=Depends(get_db)):
    ip=_client_ip(request)
    if wait:=registrations.retry_after(ip): raise _too_many(wait)
    registrations.hit(ip)
    email=x.email.lower()
    if db.users.find_one({'email':email}): raise HTTPException(409,'Email already registered')
    now=utcnow(); uid=next_id('users')
    user={'id':uid,'name':x.name.strip(),'email':email,'password_hash':hash_password(x.password),
          'timezone':x.timezone,'is_active':True,'is_admin':False,'created_at':now,'updated_at':now}
    try:
        db.users.insert_one(dict(user))
    except DuplicateKeyError:
        raise HTTPException(409,'Email already registered')
    db.user_settings.insert_one({'id':next_id('user_settings'),'user_id':uid,'default_reminder_days':settings.reminder_days_default,
                                  'notifications_enabled':True,'email_notifications':False,
                                  'push_notifications':True,'timezone':x.timezone})
    return {'access_token':create_token(uid),'user':user}

@router.post('/auth/login',response_model=TokenOut)
def login(x:LoginIn,db=Depends(get_db)):
    email=x.email.lower()
    if wait:=login_failures.retry_after(email): raise _too_many(wait)
    u=db.users.find_one({'email':email}, {'_id':0})
    if not u or not verify_password(x.password,u['password_hash']):
        login_failures.hit(email)
        raise HTTPException(401,'Invalid email or password')
    if not is_active(u): raise HTTPException(403,'Account is disabled')
    login_failures.reset(email)
    return {'access_token':create_token(u['id']),'user':u}

@router.get('/auth/me',response_model=UserOut)
def me(user=Depends(current_user)): return user

@router.post('/auth/logout')
def logout(user=Depends(current_user)):
    # Tokens are stateless; the client discards its copy.
    return {'success':True}

# ---------------------------------------------------------------- foods

@router.get('/foods',response_model=list[FoodOut])
def foods(db=Depends(get_db),user=Depends(current_user)):
    return list(db.foods.find(_visible_foods(user), {'_id':0}).sort('name',1))

@router.get('/foods/{fid}',response_model=FoodOut)
def get_food(fid:int,db=Depends(get_db),user=Depends(current_user)):
    return _get_visible_food(db,fid,user)

@router.post('/foods',response_model=FoodOut)
def add_food(x:FoodIn,db=Depends(get_db),user=Depends(admin_user)):
    if db.foods.find_one({**_ci_exact('name',x.name.strip()),'owner_id':None}): raise HTTPException(409,f'Food "{x.name}" already exists')
    now=utcnow()
    doc=x.model_dump(exclude={'aliases','image_model_label'})
    doc.update({'id':next_id('foods'),'name':x.name.strip(),'owner_id':None,'aliases':','.join(x.aliases),
                'image_model_label':x.image_model_label or x.name.lower(),
                'created_at':now,'updated_at':now})
    try:
        db.foods.insert_one(dict(doc))
    except DuplicateKeyError:
        raise HTTPException(409,f'Food "{x.name}" already exists')
    return doc

@router.put('/foods/{fid}',response_model=FoodOut)
def edit_food(fid:int,x:FoodIn,db=Depends(get_db),user=Depends(admin_user)):
    if not db.foods.find_one({'id':fid}): raise HTTPException(404,'Food not found')
    updates=x.model_dump()
    updates['aliases']=','.join(updates['aliases'])
    updates['updated_at']=utcnow()
    try:
        db.foods.update_one({'id':fid},{'$set':updates})
    except DuplicateKeyError:
        raise HTTPException(409,f'Food "{x.name}" already exists')
    return db.foods.find_one({'id':fid}, {'_id':0})

@router.delete('/foods/{fid}')
def delete_food(fid:int,db=Depends(get_db),user=Depends(admin_user)):
    """Removes the food and its shelf-life rules (which are meaningless
    without it). Users' inventory items and their reminders are kept —
    they carry their own product_name/expiry — but lose the dangling
    food_id link. Scan history is never touched."""
    r=db.foods.delete_one({'id':fid})
    if r.deleted_count==0: raise HTTPException(404,'Food not found')
    rules_removed=db.shelf_life_rules.delete_many({'food_id':fid}).deleted_count
    db.inventory.update_many({'food_id':fid},{'$set':{'food_id':None,'updated_at':utcnow()}})
    return {'success':True,'rules_removed':rules_removed}

@router.post('/foods/quick-add',response_model=FoodOut)
def quick_add_food(x:QuickFoodIn,db=Depends(get_db),user=Depends(current_user)):
    """Any signed-in user can register a food that isn't in the catalog
    yet (the Scan page's 'not recognized' fallback). The new food is
    PRIVATE to that user (owner_id) so one user can't pollute everyone's
    catalog; the shared catalog stays admin-managed. If a visible food
    with that name already exists, only the caller's own shelf-life rule
    is saved/updated."""
    name=x.name
    if not name: raise HTTPException(400,'Food name is required')
    now=utcnow()
    existing=db.foods.find_one({**_ci_exact('name',name),**_visible_foods(user)})
    if existing:
        fid=existing['id']
    else:
        fid=next_id('foods')
        try:
            db.foods.insert_one({'id':fid,'name':name,'owner_id':user['id'],'category':x.category or 'Uncategorized',
                                  'scientific_name':None,'aliases':'','image_model_label':name.lower(),
                                  'default_shelf_life_days':x.shelf_life_days,
                                  'default_storage_condition':x.storage_condition,
                                  'created_at':now,'updated_at':now})
        except DuplicateKeyError:
            raise HTTPException(409,f'Food "{name}" already exists')
    rule=db.shelf_life_rules.find_one({'food_id':fid,'user_id':user['id'],'storage_condition':x.storage_condition})
    if rule:
        db.shelf_life_rules.update_one({'id':rule['id']},{'$set':{'shelf_life_days':x.shelf_life_days,'updated_at':now}})
    else:
        db.shelf_life_rules.insert_one({'id':next_id('shelf_life_rules'),'food_id':fid,'user_id':user['id'],
                                         'shelf_life_days':x.shelf_life_days,'storage_condition':x.storage_condition,
                                         'source':'USER_CUSTOM','confidence':None,'notes':None,
                                         'created_at':now,'updated_at':now})
    return db.foods.find_one({'id':fid}, {'_id':0})

# ---------------------------------------------------------------- shelf life

@router.get('/shelf-life',response_model=list[RuleOut])
def rules(db=Depends(get_db),user=Depends(current_user)):
    return list(db.shelf_life_rules.find({'$or':[{'user_id':None},{'user_id':user['id']}]}, {'_id':0}))

def _find_visible_food_by_name(db,name,user):
    """Case-insensitive match on the food's name, then on its aliases."""
    name=' '.join(name.split())
    f=db.foods.find_one({**_ci_exact('name',name),**_visible_foods(user)}, {'_id':0})
    if f: return f
    alias={'aliases':{'$regex':f'(^|,)\\s*{re.escape(name)}\\s*(,|$)','$options':'i'}}
    return db.foods.find_one({**alias,**_visible_foods(user)}, {'_id':0})

@router.get('/shelf-life/recommendation',response_model=ShelfLifeRecommendationOut)
def shelf_life_recommendation(food_id:int|None=None,name:str|None=Query(None,max_length=120),storage_condition:str|None=None,
                              reference_date:date|None=None,db=Depends(get_db),user=Depends(current_user)):
    """Fresh-food flow: recommended shelf life for a food, per storage
    condition, from the existing shelf-life rules (never invented). With
    no storage_condition, the food's default storage is used."""
    if food_id is not None: f=_get_visible_food(db,food_id,user)
    elif name and name.strip():
        f=_find_visible_food_by_name(db,name,user)
        if not f: raise HTTPException(404,f'No shelf-life data for "{name.strip()}" yet.')
    else: raise HTTPException(400,'Provide food_id or name')
    options=shelf.storage_options(db,f,user['id'])
    ref=reference_date or user_today(db,user['id'])
    chosen=storage_condition or f.get('default_storage_condition') or (options[0]['storage_condition'] if options else None)
    rec=next((o for o in options if o['storage_condition']==chosen),None)
    if not storage_condition and not rec and options: rec=options[0]; chosen=rec['storage_condition']
    message=None
    if not options: message=f"No shelf-life rule is configured for {f['name']} yet."
    elif not rec: message=f"No shelf-life rule for {f['name']} stored as {chosen.replace('_',' ')}. Available: {', '.join(o['storage_condition'].replace('_',' ') for o in options)}."
    return {'food':f,'storage_condition':chosen,'recommendation':rec,'options':options,'reference_date':ref,
            'expected_expiry_date':shelf.calculate_expiry(ref,rec['shelf_life_days']) if rec else None,'message':message}

@router.post('/shelf-life',response_model=RuleOut)
def add_rule(x:RuleIn,db=Depends(get_db),user=Depends(current_user)):
    _get_visible_food(db,x.food_id,user)
    now=utcnow()
    r=db.shelf_life_rules.find_one({'food_id':x.food_id,'user_id':user['id'],'storage_condition':x.storage_condition})
    if r:
        rid=r['id']
        db.shelf_life_rules.update_one({'id':rid},{'$set':{'shelf_life_days':x.shelf_life_days,'shelf_life_days_max':x.shelf_life_days_max,'notes':x.notes,
                                                             'source':'USER_CUSTOM','updated_at':now}})
    else:
        rid=next_id('shelf_life_rules')
        doc=x.model_dump(exclude={'source'})
        doc.update({'id':rid,'user_id':user['id'],'source':'USER_CUSTOM','confidence':None,
                    'created_at':now,'updated_at':now})
        db.shelf_life_rules.insert_one(dict(doc))
    return db.shelf_life_rules.find_one({'id':rid}, {'_id':0})

@router.put('/shelf-life/{rid}',response_model=RuleOut)
def edit_rule(rid:int,x:RuleIn,db=Depends(get_db),user=Depends(current_user)):
    if not db.shelf_life_rules.find_one({'id':rid,'user_id':user['id']}): raise HTTPException(404,'Rule not found')
    _get_visible_food(db,x.food_id,user)
    updates=x.model_dump()
    updates['source']='USER_CUSTOM'
    updates['updated_at']=utcnow()
    db.shelf_life_rules.update_one({'id':rid,'user_id':user['id']},{'$set':updates})
    return db.shelf_life_rules.find_one({'id':rid}, {'_id':0})

@router.delete('/shelf-life/{rid}')
def delete_rule(rid:int,db=Depends(get_db),user=Depends(current_user)):
    r=db.shelf_life_rules.delete_one({'id':rid,'user_id':user['id']})
    if r.deleted_count==0: raise HTTPException(404,'Rule not found')
    return {'success':True}

# ---------------------------------------------------------------- scans

def read_upload_image(file:UploadFile)->Image.Image:
    """Validated upload -> RGB PIL image with EXIF orientation applied
    (phone cameras often store photos sideways plus an EXIF rotate flag)."""
    if not file.content_type or not file.content_type.startswith('image/'): raise HTTPException(400,'Only image uploads are allowed')
    limit=settings.max_upload_mb*1024*1024
    data=file.file.read(limit+1)
    if len(data)>limit: raise HTTPException(413,'Image is too large')
    try:
        Image.open(io.BytesIO(data)).verify()
        return ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert('RGB')
    except Exception: raise HTTPException(400,'Invalid image')

def save_upload(file:UploadFile):
    im=read_upload_image(file)
    os.makedirs(settings.upload_dir,exist_ok=True); path=Path(settings.upload_dir)/f'{uuid.uuid4().hex}.jpg'
    im.save(path,'JPEG',quality=85)
    return str(path),im

# Plain `def`, not `async def`: Tesseract (several passes), PIL and the
# optional ResNet50 are CPU-bound and blocking. FastAPI runs sync
# endpoints in its threadpool, so a scan no longer stalls every other
# request on the event loop.
@router.post('/scans/analyze',response_model=AnalyzeResponse)
def analyze(file:UploadFile=File(...),storage_condition:str='room_temperature',reference_date:date|None=None,food_id:int|None=None,db=Depends(get_db),user=Depends(current_user)):
    started=time.perf_counter(); path,img=save_upload(file)
    o=ocr.analyze(img); pred=None; expiry=None; reason=None; predictions=[]; food_source=None; classification_error=None

    # Identify the food itself — independent of whether a printed expiry
    # date is found below. Packaging almost always prints the product's
    # own name, so that's checked first (far more reliable for packaged
    # goods than the generic ImageNet classifier, which knows raw produce
    # and animals, not cereal boxes or milk cartons). Image classification
    # is only used as a fallback, for items without matching printed text.
    if food_id:
        f=db.foods.find_one({'id':food_id, **_visible_foods(user)}, {'_id':0})
        if f:
            pred=Prediction(label=f['name'],confidence=1.0); predictions=[pred]; food_source='USER_CONFIRMED'
    else:
        text_match=match_food_in_text(o['text'], list(db.foods.find(_visible_foods(user), {'_id':0})))
        if text_match:
            pred=Prediction(label=text_match['food']['name'],confidence=text_match['confidence'])
            predictions=[pred]; food_source='PACKAGE_TEXT'
        else:
            try:
                predictions=[Prediction(**p) for p in recognizer.classify(img)]
            except RuntimeError as exc:
                classification_error=str(exc)
            if predictions:
                pred=predictions[0]; food_source='IMAGE_CLASSIFICATION'

    if o['expiry_date'] and o['confidence']>=settings.ocr_confidence_threshold and not o['ambiguous']:
        expiry=ExpiryResult(date=o['expiry_date'],type='PRINTED',source='PACKAGE')
    else:
        # No usable printed expiry date — every message from here on says
        # why first: either nothing was read, or a date WAS read but isn't
        # reliable enough to accept automatically (never presented as
        # certain).
        if o['expiry_date']:
            why='several different expiry dates were found' if o['ambiguous'] else f"the reading is only {round(o['confidence']*100)}% confident"
            ocr_note=f"Expiry date needs verification: a printed date ({o['expiry_date']:%d %B %Y}) was read, but {why}. "
        else:
            ocr_note='No printed expiry date was detected on this package. '
        if classification_error:
            reason=ocr_note+classification_error
        if not pred and not reason:
            reason=ocr_note+'No reliable food classification result is available. Choose the food manually.'
        elif pred and pred.confidence>=settings.classification_high_threshold:
            f=db.foods.find_one({**_ci_exact('name',pred.label),**_visible_foods(user)}, {'_id':0})
            if not f: reason=ocr_note+f'Food "{pred.label}" is not configured in the shelf-life database. Add a rule or choose another food.'
            else:
                rule=shelf.get_rule(db,f['id'],user['id'],storage_condition)
                if not rule: reason=ocr_note+'No shelf-life rule is configured for this food and storage condition.'
                else:
                    ref=reference_date or user_today(db,user['id']); expiry=ExpiryResult(date=shelf.calculate_expiry(ref,rule['shelf_life_days']),type='ESTIMATED',shelf_life_days=rule['shelf_life_days'],source=rule['source'])
        elif pred and pred.confidence>=settings.classification_medium_threshold:
            reason=ocr_note+'The food recognition confidence is medium. Please confirm the food before calculating an estimated expiry.'
        elif pred:
            reason=ocr_note+'Food recognition confidence is low. Choose the food manually.'
    requires=expiry is None
    if expiry and expiry.type=='PRINTED': requires=False
    if o['expiry_date'] and expiry and expiry.type!='PRINTED':
        # A printed date was read but not trusted, and a shelf-life estimate
        # was produced instead: the user must still be told to check it.
        requires=True
        reason=reason or ocr_note+'A shelf-life estimate is shown instead — check the package and confirm the date.'
    expiry_status,days_left=_expiry_status(db,user['id'],expiry.date if expiry else None)
    elapsed=time.perf_counter()-started
    sid=next_id('scans')
    image_url='/uploads/'+Path(path).name
    db.scans.insert_one({
        'id':sid,'user_id':user['id'],'image_url':image_url,
        'raw_ocr_text':o['text'],'detected_product':pred.label if pred else None,
        'detected_expiry_date':d2dt(o['expiry_date']),
        'ocr_confidence':o['confidence'],'classification_confidence':pred.confidence if pred else 0,
        'final_result':expiry.model_dump_json() if expiry else reason or '',
        'processing_time':elapsed,'created_at':utcnow(),
    })
    return {'success':True,'scan_id':sid,'image_url':image_url,'food':pred,'food_source':food_source,'predictions':predictions,'ocr':o,'expiry':expiry,'requires_confirmation':requires,'confirmation_reason':reason,'processing_time':elapsed,'expiry_status':expiry_status,'days_until_expiry':days_left}

def _expiry_status(db,user_id,expiry:date|None):
    """SAFE / EXPIRING_SOON / EXPIRES_TODAY / EXPIRED relative to the user's
    own date, with "soon" meaning within their reminder lead time — the
    same definition the dashboard counts use."""
    if not expiry: return None,None
    days_left=(expiry-user_today(db,user_id)).days
    s=db.user_settings.find_one({'user_id':user_id})
    lead=s.get('default_reminder_days',settings.reminder_days_default) if s else settings.reminder_days_default
    if days_left<0: return 'EXPIRED',days_left
    if days_left==0: return 'EXPIRES_TODAY',days_left
    return ('EXPIRING_SOON' if days_left<=lead else 'SAFE'),days_left

@router.post('/scans/manual-estimate')
def manual_estimate(food_id:int,shelf_life_days:int,storage_condition:str='room_temperature',reference_date:date|None=None,db=Depends(get_db),user=Depends(current_user)):
    if shelf_life_days < 0: raise HTTPException(400,'Shelf life cannot be negative')
    f=_get_visible_food(db,food_id,user)
    ref=reference_date or user_today(db,user['id'])
    return {'date':shelf.calculate_expiry(ref,shelf_life_days),'type':'ESTIMATED','shelf_life_days':shelf_life_days,'source':'USER_CUSTOM','food':{'id':f['id'],'name':f['name'],'category':f['category']}}

@router.post('/banana/classify')
def classify_banana(file:UploadFile=File(...),user=Depends(current_user)):
    """Banana ripeness (overripe / ripe / rotten / unripe) from one photo of
    ONE clearly visible banana, using the V1 MobileNetV3Small checkpoint.
    Returns a ripeness label + confidence only — never a shelf life. Below
    the confidence threshold the result is flagged `uncertain`."""
    from ..services.banana_service import BananaModelUnavailable, classifier
    image=read_upload_image(file)
    try:
        return classifier.classify(image)
    except BananaModelUnavailable as exc:
        raise HTTPException(503,f'Banana classifier unavailable: {exc}')

@router.get('/scans',response_model=list[ScanOut])
def scans(skip:int=Query(0,ge=0),limit:int=Query(100,ge=1,le=MAX_PAGE),db=Depends(get_db),user=Depends(current_user)):
    rows=list(db.scans.find({'user_id':user['id']}, {'_id':0}).sort('created_at',-1).skip(skip).limit(limit))
    for r in rows: r['detected_expiry_date']=dt2d(r.get('detected_expiry_date'))
    return rows

@router.get('/scans/{sid}',response_model=ScanOut)
def scan(sid:int,db=Depends(get_db),user=Depends(current_user)):
    s=db.scans.find_one({'id':sid,'user_id':user['id']}, {'_id':0})
    if not s: raise HTTPException(404,'Scan not found')
    s['detected_expiry_date']=dt2d(s.get('detected_expiry_date'))
    return s

# ---------------------------------------------------------------- inventory

@router.get('/inventory',response_model=list[InventoryOut])
def inventory(db=Depends(get_db),user=Depends(current_user)):
    rows=list(db.inventory.find({'user_id':user['id'],'consumed':False}, {'_id':0}).sort('final_expiry_date',1))
    return [_inventory_out(r) for r in rows]

@router.post('/inventory',response_model=InventoryOut)
def add_inventory(x:InventoryIn,db=Depends(get_db),user=Depends(current_user)):
    now=utcnow()
    doc=x.model_dump()
    for f in DATE_FIELDS: doc[f]=d2dt(doc.get(f))
    iid=next_id('inventory')
    doc.update({'id':iid,'user_id':user['id'],'consumed':False,'created_at':now,'updated_at':now})
    db.inventory.insert_one(dict(doc))
    sync_reminders(db,doc)
    return _inventory_out(db.inventory.find_one({'id':iid}, {'_id':0}))

@router.get('/inventory/{iid}',response_model=InventoryOut)
def get_inventory(iid:int,db=Depends(get_db),user=Depends(current_user)):
    return _inventory_out(_own_inventory(db,iid,user))

@router.put('/inventory/{iid}',response_model=InventoryOut)
def edit_inventory(iid:int,x:InventoryIn,db=Depends(get_db),user=Depends(current_user)):
    _own_inventory(db,iid,user)
    updates=x.model_dump()
    for f in DATE_FIELDS: updates[f]=d2dt(updates.get(f))
    updates['updated_at']=utcnow()
    db.inventory.update_one({'id':iid,'user_id':user['id']},{'$set':updates})
    out=db.inventory.find_one({'id':iid}, {'_id':0})
    sync_reminders(db,out)  # expiry date may have changed
    return _inventory_out(out)

@router.put('/inventory/{iid}/consume',response_model=InventoryOut)
def consume_inventory(iid:int,db=Depends(get_db),user=Depends(current_user)):
    _own_inventory(db,iid,user)
    db.inventory.update_one({'id':iid,'user_id':user['id']},{'$set':{'consumed':True,'updated_at':utcnow()}})
    cancel_pending(db,iid)
    return _inventory_out(db.inventory.find_one({'id':iid}, {'_id':0}))

@router.delete('/inventory/{iid}')
def del_inventory(iid:int,db=Depends(get_db),user=Depends(current_user)):
    _own_inventory(db,iid,user)
    db.inventory.delete_one({'id':iid,'user_id':user['id']})
    db.notifications.delete_many({'inventory_id':iid,'user_id':user['id']})
    return {'success':True}

# ---------------------------------------------------------------- notifications

@router.get('/notifications',response_model=list[NotificationOut])
def notifications(skip:int=Query(0,ge=0),limit:int=Query(100,ge=1,le=MAX_PAGE),db=Depends(get_db),user=Depends(current_user)):
    if os.environ.get('VERCEL'):
        # Serverless: no background scheduler, so deliver due reminders on read.
        send_due(db)
    rows=list(db.notifications.find({'user_id':user['id']}, {'_id':0}).sort('scheduled_for',-1).skip(skip).limit(limit))
    items={i['id']:i for i in db.inventory.find({'id':{'$in':[n['inventory_id'] for n in rows]},'user_id':user['id']},
                                                 {'_id':0,'id':1,'product_name':1,'final_expiry_date':1})}
    out=[]
    for n in rows:
        item=items.get(n['inventory_id'])
        out.append(NotificationOut(
            id=n['id'],inventory_id=n['inventory_id'],notification_type=n['notification_type'],
            scheduled_for=n['scheduled_for'],sent_at=n.get('sent_at'),status=n['status'],created_at=n['created_at'],
            product_name=item['product_name'] if item else None,
            final_expiry_date=dt2d(item['final_expiry_date']) if item else None,
        ))
    return out

@router.post('/notifications/test')
def test_notification(user=Depends(current_user)): return {'success':True,'message':'Test notification queued for the current user'}

@router.post('/notifications/run-scheduler')
def run_scheduler(db=Depends(get_db),user=Depends(admin_user)):
    return {'sent':send_due(db)}

# ---------------------------------------------------------------- settings

@router.get('/settings',response_model=SettingsOut)
def get_settings(db=Depends(get_db),user=Depends(current_user)):
    s=db.user_settings.find_one({'user_id':user['id']}, {'_id':0})
    if not s:
        s={'id':next_id('user_settings'),'user_id':user['id'],'default_reminder_days':settings.reminder_days_default,
           'notifications_enabled':True,'email_notifications':False,'push_notifications':True,
           'timezone':user.get('timezone') or settings.default_timezone}
        db.user_settings.insert_one(dict(s))
    return s

@router.put('/settings',response_model=SettingsOut)
def put_settings(x:SettingsIn,db=Depends(get_db),user=Depends(current_user)):
    updates=x.model_dump()
    if db.user_settings.find_one({'user_id':user['id']}):
        db.user_settings.update_one({'user_id':user['id']},{'$set':updates})
    else:
        updates.update({'id':next_id('user_settings'),'user_id':user['id']})
        db.user_settings.insert_one(dict(updates))
    db.users.update_one({'id':user['id']},{'$set':{'timezone':x.timezone,'updated_at':utcnow()}})
    # Reminder lead time, timezone or on/off may have changed.
    sync_user_reminders(db,user['id'])
    return db.user_settings.find_one({'user_id':user['id']}, {'_id':0})

# ---------------------------------------------------------------- dashboard

@router.get('/dashboard')
def dashboard(db=Depends(get_db),user=Depends(current_user)):
    items=list(db.inventory.find({'user_id':user['id'],'consumed':False}, {'_id':0}))
    today=user_today(db,user['id'])  # the user's date, not the server's
    s=db.user_settings.find_one({'user_id':user['id']})
    days=s.get('default_reminder_days',settings.reminder_days_default) if s else settings.reminder_days_default
    fd=lambda v: dt2d(v)
    return {
        'total_items':len(items),
        'expiring_today':sum(fd(i['final_expiry_date'])==today for i in items),
        'expiring_soon':sum(today<fd(i['final_expiry_date'])<=date.fromordinal(today.toordinal()+days) for i in items),
        'expired':sum(fd(i['final_expiry_date'])<today for i in items),
        'estimated':sum(i['expiry_type']=='ESTIMATED' for i in items),
        'printed':sum(i['expiry_type']=='PRINTED' for i in items),
    }

# ---------------------------------------------------------------- admin

@router.post('/admin/foods/import')
async def import_csv(file:UploadFile=File(...),db=Depends(get_db),user=Depends(admin_user)):
    import csv
    try:
        raw=(await file.read()).decode('utf-8-sig')
    except UnicodeDecodeError:
        raise HTTPException(400,'CSV must be UTF-8 encoded')
    rows=list(csv.DictReader(io.StringIO(raw))); required={'food_name','category','shelf_life_days','storage_condition'}
    if not rows or not required.issubset(rows[0]): raise HTTPException(400,f'CSV must contain {sorted(required)}')
    parsed=[]
    for n,row in enumerate(rows,start=2):
        try: days=int(row['shelf_life_days'])
        except (TypeError,ValueError): raise HTTPException(400,f'Row {n}: shelf_life_days must be a whole number')
        if days<0: raise HTTPException(400,f'Row {n}: shelf life cannot be negative')
        name=(row['food_name'] or '').strip()
        if not name: raise HTTPException(400,f'Row {n}: food_name is required')
        # Optional range upper bound ("3–4 weeks" = 21 and 28).
        raw_max=(row.get('shelf_life_days_max') or '').strip()
        try: days_max=int(raw_max) if raw_max else None
        except ValueError: raise HTTPException(400,f'Row {n}: shelf_life_days_max must be a whole number')
        if days_max is not None and days_max<days: raise HTTPException(400,f'Row {n}: shelf_life_days_max must be >= shelf_life_days')
        parsed.append((name,(row['category'] or '').strip(),days,days_max,(row['storage_condition'] or '').strip() or 'room_temperature'))
    # One row per (food, storage condition): a new food is created on its
    # first row; every row upserts that food's global rule for its storage
    # condition, so a dataset can list several storage conditions per food.
    created=0; rules_imported=0
    for name,category,days,days_max,storage in parsed:
        now=utcnow()
        food=db.foods.find_one({**_ci_exact('name',name),'owner_id':None})
        if food: fid=food['id']
        else:
            fid=next_id('foods')
            db.foods.insert_one({'id':fid,'name':name,'owner_id':None,'category':category,'scientific_name':None,
                                  'aliases':'','image_model_label':name.lower(),'default_shelf_life_days':days,
                                  'default_storage_condition':storage,
                                  'created_at':now,'updated_at':now})
            created+=1
        rule=db.shelf_life_rules.find_one({'food_id':fid,'user_id':None,'storage_condition':storage})
        if rule:
            db.shelf_life_rules.update_one({'id':rule['id']},{'$set':{'shelf_life_days':days,'shelf_life_days_max':days_max,
                                                                      'source':'IMPORTED','updated_at':now}})
        else:
            db.shelf_life_rules.insert_one({'id':next_id('shelf_life_rules'),'food_id':fid,'user_id':None,
                                             'shelf_life_days':days,'shelf_life_days_max':days_max,'storage_condition':storage,
                                             'source':'IMPORTED','confidence':None,'notes':None,
                                             'created_at':now,'updated_at':now})
        rules_imported+=1
    return {'created':created,'skipped_duplicates':len(rows)-created,'rules_imported':rules_imported}

@router.get('/admin/foods/export')
def export_csv(db=Depends(get_db),user=Depends(admin_user)):
    import csv
    from fastapi.responses import StreamingResponse
    foods_list=list(db.foods.find({'owner_id':None}, {'_id':0}).sort('name',1))
    buf=io.StringIO(); w=csv.writer(buf)
    w.writerow(['food_name','category','shelf_life_days','storage_condition'])
    for f in foods_list:
        w.writerow([f['name'],f['category'],f.get('default_shelf_life_days') or 0,f.get('default_storage_condition') or 'room_temperature'])
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]),media_type='text/csv',headers={'Content-Disposition':'attachment; filename=foods_export.csv'})
