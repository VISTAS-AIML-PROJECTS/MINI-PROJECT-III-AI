# SmartFood Backend — Local Setup (MongoDB)

Focus: get this running on your own machine against your MongoDB Atlas
cluster (or a local MongoDB), with zero deployment platforms involved.
Deployment (Render/GitHub Pages) is a separate, later step — see
`../DEPLOYMENT.md` in the project root when you're ready for that.

## 1. Get a working MongoDB connection string

**Using Atlas (recommended, free):**
1. https://cloud.mongodb.com → your cluster → **Database Access** →
   confirm your database user's password. **Use only letters and
   numbers** for the password — special characters need URL-encoding and
   are the #1 source of silent auth failures.
2. **Network Access** → **Add IP Address** → **Allow Access From
   Anywhere** (`0.0.0.0/0`) — needed even for local dev unless your home
   IP is already whitelisted.
3. **Database** → **Connect** → **Drivers** → copy the connection
   string, replace `<password>` with your actual password.

**Or run MongoDB locally instead** (no Atlas account needed):
```bash
docker run -d -p 27017:27017 --name local-mongo mongo
```
Then your connection string is just `mongodb://localhost:27017`.

## 2. Configure the backend

```bash
cd backend
cp .env.example .env
```
Edit `.env`:
```
MONGODB_URL=<your connection string from step 1>
MONGODB_DATABASE=food_expiry
JWT_SECRET_KEY=<output of: python -c "import secrets; print(secrets.token_urlsafe(48))">
```
Leave everything else in `.env` as-is for local testing.

## 3. Install and run

```bash
python -m venv .venv
source .venv/Scripts/activate   # Windows Git Bash
# or: source .venv/bin/activate  # Mac/Linux

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

If `torch`/`torchvision` cause install trouble (large download, needs a
matching Python version — see earlier troubleshooting), you can skip
real AI recognition for now: comment out those two lines in
`requirements.txt`, then set `MODEL_NAME=mock` in `.env`.

## 4. Seed demo data

```bash
SEED_ADMIN_PASSWORD='<choose a strong password>' python seed.py
```
Creates:
```
Demo:  demo@example.com  / DemoPass123!
Admin: admin@example.com / (the SEED_ADMIN_PASSWORD you set; skipped if unset)
```
Safe to re-run — only creates what doesn't already exist. It refuses to
seed anything other than a local MongoDB unless you add `--allow-remote`.

## 5. Start the server

```bash
python -m uvicorn app.main:app --reload --port 8000
```

Confirm it's actually working — open in a browser:
```
http://127.0.0.1:8000/health
```
Should show `{"status":"ok",...}`. If this fails, the problem is your
`MONGODB_URL` (wrong password, or Atlas IP whitelist) — fix that before
touching the frontend at all.

## 6. Run the frontend against it

```bash
cd ../frontend
npm install
npm run dev
```
Open `http://localhost:5173` — the dev server already proxies `/api`
requests to `http://127.0.0.1:8000` (see `vite.config.ts`), so no env
var setup needed for local testing.

Log in with the demo account. If this works end-to-end locally, the
*code* is confirmed correct — any later deployment issue is purely
platform configuration (Render env vars, GitHub Pages variables), not a
bug to chase in the code itself.

## 7. Run the tests

```bash
cd backend
pytest
```
