import os
import sys
from datetime import datetime, timezone
from app.config import settings, LOCAL_MONGODB_URL
from app.database import db, next_id, init_indexes
from app.services.auth import hash_password

# Guard against seeding the production database by accident: anything
# other than the local default must be confirmed with --allow-remote.
if settings.mongodb_url != LOCAL_MONGODB_URL and '--allow-remote' not in sys.argv:
    sys.exit('Refusing to seed a non-local MongoDB. Re-run with --allow-remote if that is intended.')

init_indexes()

if not db.users.find_one({'email': 'demo@example.com'}):
    now = datetime.now(timezone.utc)
    uid = next_id('users')
    db.users.insert_one({
        'id': uid, 'name': 'Demo User', 'email': 'demo@example.com',
        'password_hash': hash_password('DemoPass123!'), 'timezone': 'Asia/Kolkata',
        'is_admin': False, 'is_active': True, 'created_at': now, 'updated_at': now,
    })
    db.user_settings.insert_one({
        'id': next_id('user_settings'), 'user_id': uid, 'default_reminder_days': 3,
        'notifications_enabled': True, 'email_notifications': False,
        'push_notifications': True, 'timezone': 'Asia/Kolkata',
    })

    foods = [
        ('Tomato', 'Vegetable', 4, 'room_temperature'), ('Potato', 'Vegetable', 14, 'room_temperature'),
        ('Onion', 'Vegetable', 14, 'room_temperature'), ('Carrot', 'Vegetable', 21, 'refrigerator'),
        ('Apple', 'Fruit', 14, 'refrigerator'), ('Banana', 'Fruit', 5, 'room_temperature'),
        ('Orange', 'Fruit', 10, 'refrigerator'), ('Lemon', 'Fruit', 14, 'refrigerator'),
        ('Bread', 'Bakery', 5, 'room_temperature'), ('Milk', 'Dairy', 7, 'refrigerator'),
        ('Egg', 'Dairy', 21, 'refrigerator'), ('Chicken', 'Meat', 2, 'refrigerator'),
        ('Fish', 'Seafood', 2, 'refrigerator'), ('Rice', 'Grain', 30, 'pantry'),
    ]
    for n, c, d, s in foods:
        fid = next_id('foods')
        db.foods.insert_one({
            'id': fid, 'name': n, 'category': c, 'scientific_name': None, 'aliases': n.lower(),
            'image_model_label': n.lower(), 'default_shelf_life_days': d, 'default_storage_condition': s,
            'created_at': now, 'updated_at': now,
        })
        db.shelf_life_rules.insert_one({
            'id': next_id('shelf_life_rules'), 'food_id': fid, 'user_id': None, 'shelf_life_days': d,
            'storage_condition': s, 'source': 'SYSTEM_DEFAULT', 'confidence': None,
            'notes': 'DEMO/CONFIGURABLE VALUE — not food-safety guidance',
            'created_at': now, 'updated_at': now,
        })

# Admin account — needed to reach the Admin food-catalog page in the
# frontend (add/edit/delete foods, CSV import/export) and to trigger the
# manual /notifications/run-scheduler sweep. Regular users never see or
# need this account.
# The password must come from the environment — a known default admin
# password would hand anyone admin access to a deployed database.
admin_password = os.environ.get('SEED_ADMIN_PASSWORD', '')
if len(admin_password) < 12:
    print('Skipping admin account: set SEED_ADMIN_PASSWORD (12+ characters) to create admin@example.com.')
elif not db.users.find_one({'email': 'admin@example.com'}):
    now = datetime.now(timezone.utc)
    aid = next_id('users')
    db.users.insert_one({
        'id': aid, 'name': 'Admin', 'email': 'admin@example.com',
        'password_hash': hash_password(admin_password), 'timezone': 'Asia/Kolkata',
        'is_admin': True, 'is_active': True, 'created_at': now, 'updated_at': now,
    })
    db.user_settings.insert_one({
        'id': next_id('user_settings'), 'user_id': aid, 'default_reminder_days': 3,
        'notifications_enabled': True, 'email_notifications': False,
        'push_notifications': True, 'timezone': 'Asia/Kolkata',
    })

print('Demo: demo@example.com / DemoPass123!')
if len(admin_password) >= 12:
    print('Admin: admin@example.com / (password from SEED_ADMIN_PASSWORD)')
