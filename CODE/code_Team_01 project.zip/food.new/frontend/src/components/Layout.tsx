import {
  Bell,
  ChevronRight,
  Clock3,
  History,
  LayoutDashboard,
  Leaf,
  LogOut,
  Menu,
  Salad,
  ScanLine,
  Settings,
  ShieldCheck,
  Sprout,
  X,
} from "lucide-react";
import { ReactNode, useEffect, useRef, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { getCurrentUser, getNotifications, logout as logoutSession } from "../services/api";
import { NotificationItem } from "../types";

interface LayoutProps {
  children: ReactNode;
}

const navigation = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/scan", label: "Smart Scan", icon: ScanLine },
  { path: "/food", label: "My Food", icon: Salad },
  { path: "/shelf-life", label: "Shelf Life", icon: Clock3 },
  { path: "/history", label: "History", icon: History },
  { path: "/settings", label: "Settings", icon: Settings },
];

function timeAgo(iso?: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function notificationText(n: NotificationItem) {
  const name = n.product_name || "An item";
  if (n.notification_type === "EXPIRED_ALERT") return `${name} has expired.`;
  return `${name} is due for an expiry reminder${n.final_expiry_date ? ` (expires ${n.final_expiry_date})` : ""}.`;
}

export default function Layout({ children }: LayoutProps) {
  const [mobileMenu, setMobileMenu] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [notifLoading, setNotifLoading] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  const location = useLocation();
  const navigate = useNavigate();
  const user = getCurrentUser();

  const currentPage = navigation.find((item) => item.path === location.pathname)?.label ?? "Dashboard";
  const pendingCount = notifications.filter((n) => n.status === "PENDING").length;

  function logout() {
    logoutSession();
    navigate("/login");
  }

  async function loadNotifications() {
    setNotifLoading(true);
    try {
      setNotifications(await getNotifications());
    } catch {
      setNotifications([]);
    } finally {
      setNotifLoading(false);
    }
  }

  useEffect(() => {
    loadNotifications();
    // Refresh periodically so newly-sent reminders (the backend flips
    // PENDING -> SENT roughly every 60s) show up without a manual refresh.
    const t = setInterval(loadNotifications, 60_000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  function toggleNotifications() {
    setNotifOpen((v) => !v);
    if (!notifOpen) loadNotifications();
  }

  const NotificationPanel = (
    <div className="panel-strong absolute right-0 top-[52px] z-40 w-[320px] overflow-hidden">
      <div className="flex items-center justify-between border-b px-4 py-3" style={{ borderColor: "var(--card-border)" }}>
        <p className="font-bold text-sm" style={{ color: "var(--ink)" }}>Notifications</p>
        {pendingCount > 0 && (
          <span className="status-pill status-soon">{pendingCount} pending</span>
        )}
      </div>
      <div className="max-h-[360px] overflow-y-auto">
        {notifLoading ? (
          <div className="p-4 space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="skeleton-warm h-12 w-full" />
            ))}
          </div>
        ) : notifications.length === 0 ? (
          <div className="p-6 text-center">
            <Bell size={22} style={{ color: "var(--ink-dim)" }} className="mx-auto mb-2" />
            <p className="text-sm" style={{ color: "var(--ink-dim)" }}>No reminders yet.</p>
            <p className="mt-1 text-xs" style={{ color: "var(--ink-dim)" }}>
              You'll see expiry reminders here once food is added.
            </p>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: "var(--card-border)" }}>
            {notifications.map((n) => (
              <div key={n.id} className="flex items-start gap-2.5 px-4 py-3">
                <span
                  className="mt-1 h-2 w-2 shrink-0 rounded-full"
                  style={{ background: n.status === "PENDING" ? "var(--sun)" : n.status === "SENT" ? "var(--leaf)" : "var(--ink-dim)" }}
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs leading-5" style={{ color: "var(--ink)" }}>{notificationText(n)}</p>
                  <p className="mt-0.5 text-[10px]" style={{ color: "var(--ink-dim)" }}>
                    {n.status === "SENT" ? `Sent ${timeAgo(n.sent_at)}` : `Scheduled ${timeAgo(n.scheduled_for)}`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      {/* Ambient field blobs */}
      <div
        className="field-blob fixed"
        style={{ width: 460, height: 460, top: -170, left: -170, background: "rgba(183,217,74,0.14)" }}
      />
      <div
        className="field-blob fixed"
        style={{ width: 380, height: 380, bottom: -140, right: -120, background: "rgba(244,185,66,0.12)" }}
      />

      {/* =========================================
          DESKTOP RAIL — floating card, not a fixed dark sidebar
      ========================================== */}
      <div className="hidden lg:block lg:fixed lg:left-5 lg:top-5 lg:bottom-5 lg:z-40 lg:w-[248px]">
        <aside className="rail flex h-full flex-col p-5">
          <div className="mb-8 flex items-center gap-3 px-1">
            <div className="brand-mark">
              <Sprout size={18} />
            </div>
            <div>
              <div className="text-[16px] font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                SmartFood
              </div>
              <div className="eyebrow">Freshness tracker</div>
            </div>
          </div>

          <div className="mb-3 px-3 eyebrow">Menu</div>

          <nav className="space-y-1.5">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === "/"}
                  className={({ isActive }) => `rail-link ${isActive ? "rail-link-active" : ""}`}
                >
                  <Icon size={18} strokeWidth={2} />
                  <span>{item.label}</span>
                  {item.path === "/scan" && (
                    <span
                      className="ml-auto rounded-full px-2 py-0.5 text-[9px] font-black text-white"
                      style={{ background: "var(--terracotta)" }}
                    >
                      AI
                    </span>
                  )}
                </NavLink>
              );
            })}
            {user?.is_admin && (
              <NavLink
                to="/admin"
                className={({ isActive }) => `rail-link ${isActive ? "rail-link-active" : ""}`}
              >
                <ShieldCheck size={18} strokeWidth={2} />
                <span>Admin</span>
              </NavLink>
            )}
          </nav>

          <div className="mt-auto">
            <div className="rail-tip">
              <div
                className="mb-3 flex h-9 w-9 items-center justify-center rounded-2xl"
                style={{ background: "rgba(63,143,82,0.14)", color: "var(--leaf-deep)" }}
              >
                <Leaf size={17} />
              </div>
              <p className="text-sm font-bold" style={{ color: "var(--ink)" }}>Smart expiry rule</p>
              <p className="mt-1 text-xs leading-5" style={{ color: "var(--ink-mid)" }}>
                Printed manufacturer dates always take priority over shelf-life estimates.
              </p>
            </div>

            <button
              onClick={logout}
              className="mt-4 flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-sm font-semibold transition hover:bg-[rgba(201,80,63,0.08)]"
              style={{ color: "var(--ink-mid)" }}
            >
              <LogOut size={17} />
              Sign out
            </button>
          </div>
        </aside>
      </div>

      {/* =========================================
          MAIN APPLICATION
      ========================================== */}
      <div className="relative z-10 lg:pl-[272px]">
        <header className="topbar sticky top-0 z-30">
          <div className="flex h-[72px] items-center justify-between px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3">
              <button onClick={() => setMobileMenu(true)} className="icon-chip lg:hidden" aria-label="Open navigation">
                <Menu size={20} />
              </button>
              <div>
                <div className="hidden eyebrow sm:block">SmartFood</div>
                <h1 className="text-lg font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                  {currentPage}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative" ref={notifRef}>
                <button onClick={toggleNotifications} className="icon-chip relative" aria-label="Notifications">
                  <Bell size={18} />
                  {pendingCount > 0 && (
                    <span
                      className="absolute right-[9px] top-[8px] h-1.5 w-1.5 rounded-full"
                      style={{ background: "var(--sun)", boxShadow: "0 0 8px var(--sun)" }}
                    />
                  )}
                </button>
                {notifOpen && NotificationPanel}
              </div>

              <div className="hidden h-9 w-px sm:block" style={{ background: "var(--card-border-strong)" }} />

              <div className="hidden items-center gap-2 sm:flex">
                <div className="brand-mark !h-9 !w-9 text-xs">{user?.name?.charAt(0).toUpperCase() || "U"}</div>
                <div className="leading-tight">
                  <p className="text-xs font-bold" style={{ color: "var(--ink)" }}>{user?.name || "User"}</p>
                  <p className="text-[10px]" style={{ color: "var(--ink-dim)" }}>
                    {user?.is_admin ? "Admin" : "Food manager"}
                  </p>
                </div>
              </div>

              <button onClick={logout} className="icon-chip" aria-label="Sign out" title="Sign out">
                <LogOut size={18} />
              </button>
            </div>
          </div>
        </header>

        <main className="min-h-[calc(100vh-72px)] px-4 pb-32 pt-6 sm:px-6 lg:px-8 lg:pb-10">
          <div className="mx-auto max-w-[1320px]">{children}</div>
        </main>
      </div>

      {/* =========================================
          MOBILE BOTTOM NAVIGATION
      ========================================== */}
      <nav className="mobile-bottom-nav lg:hidden">
        {navigation.slice(0, 5).map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === "/"}
              className={({ isActive }) => `mobile-nav-item ${isActive ? "active" : ""}`}
            >
              <Icon size={20} />
              <span>{item.label === "Smart Scan" ? "Scan" : item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* =========================================
          MOBILE DRAWER
      ========================================== */}
      {mobileMenu && (
        <div className="fixed inset-0 z-[100] lg:hidden">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setMobileMenu(false)} />
          <div className="mobile-drawer relative h-full w-[290px] p-5 shadow-2xl" style={{ background: "var(--paper)" }}>
            <div className="mb-10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="brand-mark">
                  <Sprout size={18} />
                </div>
                <div className="font-bold" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                  SmartFood
                </div>
              </div>
              <button className="transition" style={{ color: "var(--ink-dim)" }} onClick={() => setMobileMenu(false)} aria-label="Close navigation">
                <X size={20} />
              </button>
            </div>

            <nav className="space-y-1.5">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    end={item.path === "/"}
                    onClick={() => setMobileMenu(false)}
                    className={({ isActive }) => `rail-link ${isActive ? "rail-link-active" : ""}`}
                  >
                    <Icon size={18} />
                    <span>{item.label}</span>
                    <ChevronRight className="ml-auto" size={15} />
                  </NavLink>
                );
              })}
              {user?.is_admin && (
                <NavLink
                  to="/admin"
                  onClick={() => setMobileMenu(false)}
                  className={({ isActive }) => `rail-link ${isActive ? "rail-link-active" : ""}`}
                >
                  <ShieldCheck size={18} />
                  <span>Admin</span>
                  <ChevronRight className="ml-auto" size={15} />
                </NavLink>
              )}
            </nav>

            <button
              onClick={logout}
              className="mt-10 flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-sm font-semibold transition"
              style={{ color: "var(--ink-mid)" }}
            >
              <LogOut size={17} />
              Sign out
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
