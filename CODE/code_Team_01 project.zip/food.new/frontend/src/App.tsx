import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import Layout from "./components/Layout";
import { getCurrentUser } from "./services/api";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Scan from "./pages/Scan";
import Food from "./pages/Food";
import ShelfLife from "./pages/ShelfLife";
import History from "./pages/History";
import Settings from "./pages/Settings";
import Admin from "./pages/Admin";

export default function App() {
  return (
    // BASE_URL is Vite's runtime reflection of the `base` config option
    // (see vite.config.ts) — keeping BrowserRouter's basename in sync
    // with it is required for routing to work once deployed under a
    // subpath like GitHub Pages' /<repo-name>/.
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <Routes>
        {/* Public */}
        <Route path="/login" element={<Login />} />

        {/* Protected application */}
        <Route
          path="/*"
          element={
            <ProtectedApp />
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

function ProtectedApp() {
  const token = localStorage.getItem("token");

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  const user = getCurrentUser();

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/scan" element={<Scan />} />
        <Route path="/food" element={<Food />} />
        <Route path="/shelf-life" element={<ShelfLife />} />
        <Route path="/history" element={<History />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/admin" element={user?.is_admin ? <Admin /> : <Navigate to="/" replace />} />

        {/* Unknown route */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}
