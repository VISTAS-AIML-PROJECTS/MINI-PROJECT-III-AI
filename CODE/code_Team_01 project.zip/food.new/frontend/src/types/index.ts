export type ExpiryType = 'PRINTED' | 'ESTIMATED' | 'MANUAL';

export interface Food {
  id: number;
  name: string;
  category: string;
  default_shelf_life_days: number | null;
  default_storage_condition: string | null;
}

export interface ScanResult {
  success: boolean;
  image_url?: string;
  food: { label: string; confidence: number } | null;
  food_source?: "PACKAGE_TEXT" | "IMAGE_CLASSIFICATION" | "USER_CONFIRMED" | null;
  predictions: { label: string; confidence: number }[];
  ocr: { text: string; expiry_date: string | null; confidence: number; label?: string | null; ambiguous: boolean };
  expiry: { date: string; type: ExpiryType; shelf_life_days?: number; source?: string } | null;
  requires_confirmation: boolean;
  confirmation_reason?: string;
  processing_time: number;
  expiry_status?: ExpiryStatus | null;
  days_until_expiry?: number | null;
}

export type ExpiryStatus = "SAFE" | "EXPIRING_SOON" | "EXPIRES_TODAY" | "EXPIRED";

export interface ShelfLifeOption {
  storage_condition: string;
  shelf_life_days: number;
  shelf_life_days_max?: number | null;
  label: string;
  source?: string | null;
  notes?: string | null;
}

export interface ShelfLifeRecommendation {
  food: { id: number; name: string; category?: string | null };
  storage_condition: string | null;
  recommendation: ShelfLifeOption | null;
  options: ShelfLifeOption[];
  reference_date: string;
  expected_expiry_date: string | null;
  message?: string | null;
}

export interface Inventory {
  id: number;
  product_name: string;
  category?: string;
  final_expiry_date: string;
  expiry_type: ExpiryType;
  storage_condition: string;
  quantity: number;
  unit: string;
  confidence: number | null;
  detection_method: string;
  image_url?: string;
  consumed: boolean;
}

export interface ScanRecord {
  id: number;
  image_url?: string | null;
  raw_ocr_text?: string | null;
  detected_product?: string | null;
  detected_expiry_date?: string | null;
  ocr_confidence?: number | null;
  classification_confidence?: number | null;
  processing_time?: number | null;
  created_at?: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  timezone: string;
  is_admin: boolean;
  is_active?: boolean;
}

export interface NotificationItem {
  id: number;
  inventory_id: number;
  notification_type: string;
  scheduled_for: string;
  sent_at?: string | null;
  status: "PENDING" | "SENT" | "FAILED" | "CANCELLED" | string;
  created_at: string;
  product_name?: string | null;
  final_expiry_date?: string | null;
}

export interface ShelfLifeRule {
  id: number;
  food_id: number;
  user_id?: number | null;
  shelf_life_days: number;
  shelf_life_days_max?: number | null;
  storage_condition: string;
  source?: string;
  confidence?: number | null;
  notes?: string | null;
}

export interface UserSettings {
  default_reminder_days: number;
  additional_reminder_days?: string;
  notifications_enabled: boolean;
  email_notifications: boolean;
  push_notifications: boolean;
  timezone?: string;
}

export type BananaClass = "overripe" | "ripe" | "rotten" | "unripe";

export interface BananaResult {
  food: "banana";
  predicted_class: BananaClass;
  confidence: number;
  top3: { class: BananaClass; confidence: number }[];
  probabilities: Record<BananaClass, number>;
  uncertain: boolean;
  message: string | null;
  model: { name: string; sha256: string };
}
