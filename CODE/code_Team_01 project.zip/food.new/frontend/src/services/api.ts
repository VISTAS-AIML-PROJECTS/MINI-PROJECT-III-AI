const API = import.meta.env.VITE_API_URL || "http://localhost:8000/api";

export const SESSION_EXPIRED_KEY = "session_expired";

// A 401 on an authenticated request means the stored JWT is expired or
// invalid (or the account was disabled): drop the session and go to the
// login page instead of leaving every screen stuck on error states.
// Login/register 401s are just wrong credentials and are left to the form.
function handleUnauthorized(r: Response, hadToken: boolean) {
  if (r.status !== 401 || !hadToken) return;
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  sessionStorage.setItem(SESSION_EXPIRED_KEY, "1");
  window.location.assign(`${import.meta.env.BASE_URL}login`);
}

export async function api(path: string, opts: RequestInit = {}) {
  const token = localStorage.getItem("token");
  const h = new Headers(opts.headers);
  if (token) h.set("Authorization", `Bearer ${token}`);
  const r = await fetch(API + path, { ...opts, headers: h });
  if (!r.ok) {
    handleUnauthorized(r, !!token);
    let msg = "Request failed";
    try {
      const j = await r.json();
      msg = j.detail || msg;
    } catch {
      msg = (await r.text()) || msg;
    }
    throw new Error(msg);
  }
  if (r.status === 204) return null;
  return r.json();
}

// Like `api()`, but for endpoints that return plain text/CSV instead of JSON
// (e.g. the admin food-catalog export).
export async function apiText(path: string, opts: RequestInit = {}) {
  const token = localStorage.getItem("token");
  const h = new Headers(opts.headers);
  if (token) h.set("Authorization", `Bearer ${token}`);
  const r = await fetch(API + path, { ...opts, headers: h });
  if (!r.ok) {
    handleUnauthorized(r, !!token);
    let msg = "Request failed";
    try {
      msg = (await r.json()).detail || msg;
    } catch {
      msg = (await r.text()) || msg;
    }
    throw new Error(msg);
  }
  return r.text();
}

const jsonBody = (x: any) => ({ headers: { "Content-Type": "application/json" }, body: JSON.stringify(x) });

// --- Auth ---
// Register/login responses include the user object, which we persist so
// the UI can show the signed-in user's name and gate admin-only screens
// (Layout's Admin nav link, the /admin route guard) without a extra round trip.
function persistSession(res: any) {
  localStorage.setItem("token", res.access_token);
  localStorage.setItem("user", JSON.stringify(res.user));
  return res;
}

function clearSessionThen<T>(fn: () => Promise<T>) {
  localStorage.removeItem("token");
  return fn();
}

export const auth = {
  register: (x: any) => clearSessionThen(() => api("/auth/register", { method: "POST", ...jsonBody(x) })).then(persistSession),
  login: (x: any) => clearSessionThen(() => api("/auth/login", { method: "POST", ...jsonBody(x) })).then(persistSession),
};

export function getCurrentUser(): { id: number; name: string; email: string; timezone: string; is_admin: boolean } | null {
  const raw = localStorage.getItem("user");
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
}

// --- Foods / dashboard / rules ---
export const getFoods = () => api("/foods");
export const getInventory = () => api("/inventory");
export const getDashboard = () => api("/dashboard");
export const getRules = () => api("/shelf-life");

// Lets any signed-in user register a food that isn't in the catalog yet
// (used by the Scan page when nothing matches) — separate from the
// admin-only addFood() below.
export const quickAddFood = (x: { name: string; category?: string; shelf_life_days: number; storage_condition?: string }) =>
  api("/foods/quick-add", { method: "POST", ...jsonBody(x) });

// --- Admin: food catalog management ---
export const addFood = (x: any) => api("/foods", { method: "POST", ...jsonBody(x) });
export const updateFood = (id: number, x: any) => api(`/foods/${id}`, { method: "PUT", ...jsonBody(x) });
export const deleteFood = (id: number) => api(`/foods/${id}`, { method: "DELETE" });

export async function importFoodsCsv(file: File) {
  const fd = new FormData();
  fd.append("file", file);
  return api("/admin/foods/import", { method: "POST", body: fd });
}

export async function exportFoodsCsv(): Promise<void> {
  const csv = await apiText("/admin/foods/export");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "foods_export.csv";
  a.click();
  URL.revokeObjectURL(url);
}

// --- Scanning ---
export async function analyze(
  file: File,
  opts: { storage_condition?: string; reference_date?: string; food_id?: number } = {}
) {
  const fd = new FormData();
  fd.append("file", file);
  const q = new URLSearchParams();
  if (opts.storage_condition) q.set("storage_condition", opts.storage_condition);
  if (opts.reference_date) q.set("reference_date", opts.reference_date);
  if (opts.food_id) q.set("food_id", String(opts.food_id));
  return api(`/scans/analyze?${q.toString()}`, { method: "POST", body: fd });
}

export const getScans = () => api("/scans");

// Banana ripeness (one clearly visible banana) — V1 MobileNetV3Small model.
export async function classifyBanana(file: File) {
  const fd = new FormData();
  fd.append("file", file);
  return api("/banana/classify", { method: "POST", body: fd });
}

// --- Inventory ---
export const addInventory = (x: any) => api("/inventory", { method: "POST", ...jsonBody(x) });

export const updateInventory = (id: number, x: any) => api(`/inventory/${id}`, { method: "PUT", ...jsonBody(x) });

export const deleteInventory = (id: number) => api(`/inventory/${id}`, { method: "DELETE" });

export const markConsumed = (id: number) => api(`/inventory/${id}/consume`, { method: "PUT" });

// --- Fresh-food shelf life (recommendation from the shelf-life rules) ---
export function getShelfLifeRecommendation(q: { food_id?: number; name?: string; storage_condition?: string }) {
  const p = new URLSearchParams();
  if (q.food_id) p.set("food_id", String(q.food_id));
  if (q.name) p.set("name", q.name);
  if (q.storage_condition) p.set("storage_condition", q.storage_condition);
  return api(`/shelf-life/recommendation?${p.toString()}`);
}

// --- Shelf life rules ---
export const createRule = (x: any) => api("/shelf-life", { method: "POST", ...jsonBody(x) });
export const updateRule = (id: number, x: any) => api(`/shelf-life/${id}`, { method: "PUT", ...jsonBody(x) });
export const deleteRule = (id: number) => api(`/shelf-life/${id}`, { method: "DELETE" });

// --- Settings ---
export const getSettings = () => api("/settings");
export const updateSettings = (x: any) => api("/settings", { method: "PUT", ...jsonBody(x) });

// --- Notifications ---
// Reminders are auto-delivered by a background scheduler on the backend
// (every 60s, PENDING -> SENT once due) — getNotifications() returns each
// user's full history so the bell dropdown can show both.
export const getNotifications = () => api("/notifications");
export const testNotification = () => api("/notifications/test", { method: "POST" });
export const runScheduler = () => api("/notifications/run-scheduler", { method: "POST" });
