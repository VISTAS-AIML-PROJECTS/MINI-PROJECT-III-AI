import { Bell, Check, Mail, Save, Smartphone, TimerReset } from "lucide-react";
import { ReactNode, useEffect, useState } from "react";
import { getSettings, testNotification, updateSettings } from "../services/api";
import { UserSettings } from "../types";

const DEFAULT_SETTINGS: UserSettings = {
  default_reminder_days: 3,
  notifications_enabled: true,
  email_notifications: false,
  push_notifications: true,
  timezone: "Asia/Kolkata",
};

function ToggleRow({
  icon,
  label,
  description,
  checked,
  onChange,
}: {
  icon: ReactNode;
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-4 py-3">
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-2xl" style={{ background: "rgba(63,143,82,0.1)", color: "var(--leaf-deep)" }}>
          {icon}
        </div>
        <div>
          <p className="text-sm font-semibold" style={{ color: "var(--ink)" }}>{label}</p>
          <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
            {description}
          </p>
        </div>
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className="toggle-track"
        style={{ background: checked ? "var(--grad-leaf)" : "var(--cream-deep)" }}
      >
        <span className="toggle-knob" style={{ left: checked ? "22px" : "2px" }} />
      </button>
    </label>
  );
}

export default function Settings() {
  const [s, setS] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [testMsg, setTestMsg] = useState<string | null>(null);

  useEffect(() => {
    getSettings()
      .then((res) => setS({ ...DEFAULT_SETTINGS, ...res }))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  async function save() {
    setSaving(true);
    setSaved(false);
    try {
      await updateSettings(s);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  }

  async function sendTest() {
    setTestMsg(null);
    try {
      await testNotification();
      setTestMsg("Test notification sent.");
    } catch (e: any) {
      setTestMsg(e?.message || "Couldn't send a test notification.");
    }
  }

  const REMINDER_OPTIONS = [1, 2, 3, 5, 7];

  return (
    <div className="max-w-xl space-y-5">
      <div>
        <p className="eyebrow">Preferences</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
          Settings
        </h1>
      </div>

      {loading ? (
        <div className="skeleton-warm h-64 w-full" />
      ) : (
        <>
          <div className="panel-strong p-6">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl" style={{ background: "rgba(226,147,61,0.14)", color: "var(--amber)" }}>
                <TimerReset size={18} />
              </div>
              <div>
                <p className="eyebrow">Reminders</p>
                <h3 className="font-bold" style={{ color: "var(--ink)" }}>Expiry alerts</h3>
              </div>
            </div>

            <label className="field-label">Remind me before expiry</label>
            <div className="flex flex-wrap gap-2">
              {REMINDER_OPTIONS.map((d) => (
                <button
                  key={d}
                  onClick={() => setS({ ...s, default_reminder_days: d })}
                  className="rounded-full px-3.5 py-1.5 text-sm font-semibold transition"
                  style={
                    s.default_reminder_days === d
                      ? { background: "var(--grad-leaf)", color: "#fff" }
                      : { border: "1px solid var(--card-border-strong)", color: "var(--ink-mid)" }
                  }
                >
                  {d} day{d > 1 ? "s" : ""}
                </button>
              ))}
            </div>

            <div className="mt-2">
              <input
                type="number"
                min={0}
                value={s.default_reminder_days}
                onChange={(e) => setS({ ...s, default_reminder_days: +e.target.value })}
                className="input-earth mt-3 w-32"
              />
            </div>
          </div>

          <div className="panel-strong p-6" style={{ borderColor: "var(--card-border)" }}>
            <div className="mb-1 flex items-center gap-3 border-b pb-3" style={{ borderColor: "var(--card-border)" }}>
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl" style={{ background: "rgba(63,143,82,0.12)", color: "var(--leaf-deep)" }}>
                <Bell size={18} />
              </div>
              <div>
                <p className="eyebrow">Delivery</p>
                <h3 className="font-bold" style={{ color: "var(--ink)" }}>Notification channels</h3>
              </div>
            </div>

            <div className="divide-y" style={{ borderColor: "var(--card-border)" }}>
              <ToggleRow
                icon={<Bell size={16} />}
                label="Notifications enabled"
                description="Master switch for all expiry reminders"
                checked={s.notifications_enabled}
                onChange={(v) => setS({ ...s, notifications_enabled: v })}
              />
              <ToggleRow
                icon={<Mail size={16} />}
                label="Email notifications"
                description="Get reminders sent to your inbox"
                checked={s.email_notifications}
                onChange={(v) => setS({ ...s, email_notifications: v })}
              />
              <ToggleRow
                icon={<Smartphone size={16} />}
                label="Push notifications"
                description="Get reminders sent to this device"
                checked={s.push_notifications}
                onChange={(v) => setS({ ...s, push_notifications: v })}
              />
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <button onClick={save} disabled={saving} className="btn-grow flex-1">
              {saved ? <Check size={16} /> : <Save size={16} />}
              {saving ? "Saving..." : saved ? "Saved" : "Save settings"}
            </button>
            <button onClick={sendTest} className="btn-husk flex-1">
              Send test notification
            </button>
          </div>
          {testMsg && (
            <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
              {testMsg}
            </p>
          )}
        </>
      )}
    </div>
  );
}
