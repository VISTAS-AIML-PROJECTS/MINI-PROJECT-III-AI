import { AlertTriangle, CheckCircle2, Salad, Search, Sprout, Trash2, TimerReset, XCircle } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { deleteInventory, getInventory, markConsumed } from "../services/api";
import { Inventory } from "../types";

function getDaysRemaining(date: string) {
  const expiry = new Date(`${date}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.floor((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

function getStatus(date: string) {
  const days = getDaysRemaining(date);
  if (days < 0) return { label: "Expired", className: "status-expired", icon: XCircle, accent: "accent-rust" };
  if (days === 0) return { label: "Today", className: "status-today", icon: TimerReset, accent: "accent-terracotta" };
  if (days <= 3) return { label: "Soon", className: "status-soon", icon: AlertTriangle, accent: "accent-amber" };
  return { label: "Safe", className: "status-safe", icon: CheckCircle2, accent: "" };
}

function getFoodEmoji(name?: string) {
  const food = name?.toLowerCase() ?? "";
  if (food.includes("tomato")) return "🍅";
  if (food.includes("milk")) return "🥛";
  if (food.includes("bread")) return "🍞";
  if (food.includes("apple")) return "🍎";
  if (food.includes("banana")) return "🍌";
  if (food.includes("orange")) return "🍊";
  if (food.includes("egg")) return "🥚";
  if (food.includes("chicken")) return "🍗";
  if (food.includes("fish")) return "🐟";
  if (food.includes("rice")) return "🍚";
  if (food.includes("potato")) return "🥔";
  if (food.includes("carrot")) return "🥕";
  if (food.includes("onion")) return "🧅";
  return "🥗";
}

const FILTERS = [
  { key: "all", label: "All" },
  { key: "soon", label: "Expiring Soon" },
  { key: "today", label: "Today" },
  { key: "expired", label: "Expired" },
  { key: "PRINTED", label: "Printed" },
  { key: "ESTIMATED", label: "Estimated" },
];

export default function Food() {
  const [items, setItems] = useState<Inventory[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  async function load() {
    setLoading(true);
    try {
      setItems(await getInventory());
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const visible = useMemo(() => {
    return items
      .filter((i) => !i.consumed)
      .filter((i) => (search ? i.product_name.toLowerCase().includes(search.toLowerCase()) : true))
      .filter((i) => {
        if (filter === "all") return true;
        if (filter === "PRINTED" || filter === "ESTIMATED") return i.expiry_type === filter;
        const days = getDaysRemaining(i.final_expiry_date);
        if (filter === "soon") return days > 0 && days <= 3;
        if (filter === "today") return days === 0;
        if (filter === "expired") return days < 0;
        return true;
      })
      .sort((a, b) => new Date(a.final_expiry_date).getTime() - new Date(b.final_expiry_date).getTime());
  }, [items, search, filter]);

  async function handleConsumed(id: number) {
    setItems((prev) => prev.filter((i) => i.id !== id));
    try {
      await markConsumed(id);
    } catch {
      load();
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Remove this item from your inventory?")) return;
    setItems((prev) => prev.filter((i) => i.id !== id));
    try {
      await deleteInventory(id);
    } catch {
      load();
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="eyebrow">Kitchen inventory</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
            My Food
          </h1>
        </div>
        <Link to="/scan" className="btn-grow !py-2.5 !px-4 text-xs">
          <Sprout size={14} />
          Scan
        </Link>
      </div>

      <div className="relative">
        <Search size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2" style={{ color: "var(--ink-dim)" }} />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search your food..."
          className="input-earth !pl-11"
        />
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className="shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold transition"
            style={
              filter === f.key
                ? { background: "var(--grad-leaf)", color: "#fff" }
                : { border: "1px solid var(--card-border-strong)", background: "var(--paper)", color: "var(--ink-mid)" }
            }
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="skeleton-warm h-24 w-full" />
          ))}
        </div>
      ) : visible.length === 0 ? (
        <div className="panel flex flex-col items-center gap-3 p-10 text-center">
          <Salad size={30} style={{ color: "var(--leaf-deep)" }} />
          <div>
            <p className="font-bold" style={{ color: "var(--ink)" }}>No matching food</p>
            <p className="mt-1 text-sm" style={{ color: "var(--ink-dim)" }}>
              Scan your first item to start tracking expiry dates.
            </p>
          </div>
          <Link to="/scan" className="btn-grow">
            Scan Food
          </Link>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {visible.map((item) => {
            const status = getStatus(item.final_expiry_date);
            const StatusIcon = status.icon;
            return (
              <div key={item.id} className={`crate-card ${status.accent} p-4`}>
                <div className="flex items-start gap-3">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-2xl" style={{ background: "var(--cream-deep)" }}>
                    {getFoodEmoji(item.product_name)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate font-bold" style={{ color: "var(--ink)" }}>{item.product_name}</p>
                      <span className={`status-pill ${status.className} shrink-0`}>
                        <StatusIcon size={10} />
                        {status.label}
                      </span>
                    </div>
                    <p className="mt-1 text-xs" style={{ color: "var(--ink-mid)" }}>
                      Expires {new Date(item.final_expiry_date + "T00:00:00").toLocaleDateString()} ·{" "}
                      {item.storage_condition.replace("_", " ")}
                    </p>
                    <p className="mt-1 text-[11px]" style={{ color: "var(--ink-dim)" }}>
                      Detected by {item.detection_method} ·{" "}
                      {item.confidence ? `${Math.round(item.confidence * 100)}%` : "Manual"}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex gap-2 border-t pt-3" style={{ borderColor: "var(--card-border)" }}>
                  <button onClick={() => handleConsumed(item.id)} className="btn-husk flex-1 !py-2 text-xs">
                    <CheckCircle2 size={13} />
                    Consumed
                  </button>
                  <button onClick={() => handleDelete(item.id)} className="btn-danger-husk !py-2 !px-3 text-xs">
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
