import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  ChevronRight,
  Crosshair,
  Leaf,
  Loader2,
  ScanLine,
  Sprout,
  TimerReset,
  Upload,
  XCircle,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { analyze, addInventory, classifyBanana, getFoods, quickAddFood } from "../services/api";
import { BananaResult, ScanResult, Food, ExpiryStatus } from "../types";

const STORAGE: [string, string][] = [
  ["room_temperature", "Room temperature"],
  ["refrigerator", "Refrigerator"],
  ["freezer", "Freezer"],
  ["pantry", "Pantry"],
  ["opened", "Opened"],
  ["unopened", "Unopened"],
];

// Local calendar date — toISOString() is UTC, which in IST is still
// "yesterday" until 05:30.
const now = new Date();
const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

function pct(n: number | undefined | null) {
  return typeof n === "number" ? `${Math.round(n * 100)}%` : "Not available";
}

function prettyDate(s: string) {
  return new Date(s + "T00:00:00").toLocaleDateString(undefined, { day: "2-digit", month: "long", year: "numeric" });
}

// Status comes from the backend (user's timezone + reminder lead time).
const STATUS: Record<ExpiryStatus, { label: string; className: string; icon: typeof CheckCircle2 }> = {
  SAFE: { label: "Valid", className: "status-safe", icon: CheckCircle2 },
  EXPIRING_SOON: { label: "Valid · expiring soon", className: "status-soon", icon: AlertTriangle },
  EXPIRES_TODAY: { label: "Expires today", className: "status-today", icon: TimerReset },
  EXPIRED: { label: "Expired", className: "status-expired", icon: XCircle },
};

function daysText(days: number | null | undefined) {
  if (typeof days !== "number") return "";
  if (days === 0) return "today";
  if (days > 0) return `in ${days} day${days === 1 ? "" : "s"}`;
  return `${-days} day${days === -1 ? "" : "s"} ago`;
}

const PROGRESS_STEPS = ["Image captured", "Reading text", "Identifying food", "Calculating expiry"];
const BANANA_STEPS = ["Image captured", "Classifying banana"];

// "2026-12-15" -> "15/12/2026"
function dmy(s: string) {
  const [y, m, d] = s.split("-");
  return `${d}/${m}/${y}`;
}

const BANANA_STYLE: Record<string, { color: string; bg: string }> = {
  unripe: { color: "#2f7a3d", bg: "rgba(63,143,82,0.10)" },
  ripe: { color: "#9a6b00", bg: "rgba(244,185,66,0.14)" },
  overripe: { color: "#9a4f12", bg: "rgba(226,147,61,0.14)" },
  rotten: { color: "#a3382b", bg: "rgba(201,80,63,0.12)" },
};

function foodSourceLabel(source: ScanResult["food_source"]) {
  switch (source) {
    case "PACKAGE_TEXT":
      return "Read from the product's printed name";
    case "IMAGE_CLASSIFICATION":
      return "AI image recognition";
    case "USER_CONFIRMED":
      return "Confirmed by you";
    default:
      return null;
  }
}

export default function Scan() {
  const video = useRef<HTMLVideoElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const stream = useRef<MediaStream | null>(null);

  const [cameraOn, setCameraOn] = useState(false);
  const [mode, setMode] = useState<"packaged" | "banana">("packaged");
  const [br, setBr] = useState<BananaResult | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [r, setR] = useState<ScanResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [progressIdx, setProgressIdx] = useState(0);
  const [foods, setFoods] = useState<Food[]>([]);
  const [storage, setStorage] = useState("room_temperature");
  const [referenceDate, setReferenceDate] = useState(today);
  const [selectedFood, setSelectedFood] = useState("");
  const [manualExpiry, setManualExpiry] = useState("");
  const [manualMode, setManualMode] = useState(false);
  const [added, setAdded] = useState(false);
  const [addingNewFood, setAddingNewFood] = useState(false);
  const [newFoodName, setNewFoodName] = useState("");
  const [newFoodCategory, setNewFoodCategory] = useState("");
  const [newFoodDays, setNewFoodDays] = useState("");
  const [savingNewFood, setSavingNewFood] = useState(false);

  useEffect(() => () => stream.current?.getTracks().forEach((t) => t.stop()), []);

  // Local preview of the scanned product (the server copy isn't served back).
  const previewUrl = useMemo(() => (file ? URL.createObjectURL(file) : null), [file]);
  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  async function openCamera() {
    try {
      stream.current = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      if (video.current) {
        video.current.srcObject = stream.current;
        await video.current.play();
      }
      setCameraOn(true);
    } catch {
      alert("Camera permission was denied. You can upload an image instead.");
    }
  }

  async function capture() {
    if (!video.current || !canvas.current) return;
    canvas.current.width = video.current.videoWidth;
    canvas.current.height = video.current.videoHeight;
    canvas.current.getContext("2d")!.drawImage(video.current, 0, 0);
    canvas.current.toBlob(
      (b) => {
        if (b) {
          const f = new File([b], "capture.jpg", { type: "image/jpeg" });
          setFile(f);
          run(f);
        }
      },
      "image/jpeg",
      0.85
    );
  }

  function switchMode(next: "packaged" | "banana") {
    setMode(next);
    setR(null);
    setBr(null);
    setAdded(false);
  }

  async function runBanana(f: File) {
    setBusy(true);
    setBr(null);
    setR(null);
    setProgressIdx(0);
    try {
      const result: BananaResult = await classifyBanana(f);
      // Development log of the real model output (no client-side post-processing).
      console.info("[banana] model prediction", result.predicted_class, result.confidence, result.probabilities);
      setBr(result);
    } catch (e: any) {
      alert("Banana scan failed: " + e.message);
    } finally {
      setProgressIdx(BANANA_STEPS.length - 1);
      setBusy(false);
    }
  }

  async function run(f: File | null = file, foodId?: number) {
    if (!f) return;
    if (mode === "banana") return runBanana(f);
    setBusy(true);
    setR(null);
    setAdded(false);
    setProgressIdx(0);
    const progressTimer = setInterval(() => {
      setProgressIdx((i) => Math.min(i + 1, PROGRESS_STEPS.length - 1));
    }, 500);
    try {
      const result = await analyze(f, {
        storage_condition: storage,
        reference_date: referenceDate,
        food_id: foodId
      });
      setR(result);

      if (result.predictions.length === 0 || result.requires_confirmation) setFoods(await getFoods());
    } catch (e: any) {
      alert("Scan failed: " + e.message);
    } finally {
      clearInterval(progressTimer);
      setProgressIdx(PROGRESS_STEPS.length - 1);
      setBusy(false);
    }
  }

  async function confirmFood() {
    const id = Number(selectedFood);
    if (!id || !file) return;
    await run(file, id);
  }

  async function saveNewFoodAndAdd() {
    const name = newFoodName.trim();
    const days = Number(newFoodDays);
    if (!name || !newFoodDays || isNaN(days) || days < 0) {
      alert("Enter a food name and a valid (non-negative) shelf life in days.");
      return;
    }
    setSavingNewFood(true);
    try {
      const food = await quickAddFood({
        name,
        category: newFoodCategory.trim() || "Uncategorized",
        shelf_life_days: days,
        storage_condition: storage,
      });
      const ref = new Date(referenceDate + "T00:00:00");
      ref.setDate(ref.getDate() + days);
      const expiryDate = ref.toISOString().slice(0, 10);
      await addInventory({
        product_name: food.name,
        food_id: food.id,
        category: food.category,
        image_url: r?.image_url,
        final_expiry_date: expiryDate,
        expiry_type: "ESTIMATED",
        estimated_expiry_date: expiryDate,
        storage_condition: storage,
        quantity: 1,
        unit: "item",
        confidence: r?.food?.confidence ?? null,
        detection_method: "IMAGE_CLASSIFICATION",
        notes: "Estimated from a newly-configured shelf life; not a food-safety guarantee.",
      });
      setAdded(true);
      setR(null);
      setFile(null);
      setAddingNewFood(false);
      setNewFoodName("");
      setNewFoodCategory("");
      setNewFoodDays("");
    } catch (e: any) {
      alert("Couldn't save this food: " + e.message);
    } finally {
      setSavingNewFood(false);
    }
  }

  async function add() {
    if (!r) return;
    const foodName = r.food?.label || foods.find((x) => x.id === Number(selectedFood))?.name;
    if (!foodName) {
      setFoods(await getFoods());
      return;
    }
    const f = foods.find((x) => x.name.toLowerCase() === foodName.toLowerCase()) || foods.find((x) => x.id === Number(selectedFood));
    const expiryDate = manualMode ? manualExpiry : r.expiry?.date;
    if (!expiryDate) {
      alert("Enter or confirm an expiry date before adding.");
      return;
    }
    const type = manualMode ? "MANUAL" : r.expiry!.type;
    await addInventory({
      product_name: foodName,
      food_id: f?.id,
      category: f?.category,
      image_url: r.image_url,
      final_expiry_date: expiryDate,
      expiry_type: type,
      estimated_expiry_date: type === "ESTIMATED" ? expiryDate : null,
      printed_expiry_date: type === "PRINTED" ? expiryDate : null,
      storage_condition: storage,
      quantity: 1,
      unit: "item",
      confidence: type === "PRINTED" ? r.ocr.confidence : r.food?.confidence || null,
      detection_method:
        type === "PRINTED" ? "OCR" : type === "MANUAL" ? "USER_INPUT" : r.food_source === "PACKAGE_TEXT" ? "PACKAGE_TEXT" : "IMAGE_CLASSIFICATION",
      notes: type === "ESTIMATED" ? "Estimated from configured shelf life; not a food-safety guarantee." : undefined,
    });
    setAdded(true);
    setR(null);
    setFile(null);
    setManualMode(false);
    setManualExpiry("");
  }

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="eyebrow">Camera-first smart scan</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
            Scan Food
          </h1>
          <p className="mt-1 text-sm" style={{ color: "var(--ink-dim)" }}>
            {mode === "packaged"
              ? "Packaged food: scan the printed EXP / USE BY / BEST BEFORE date."
              : "Banana: photograph ONE banana clearly to check its condition."}
          </p>
        </div>
        <Link to="/shelf-life" className="btn-husk !py-2 !px-3 text-xs">
          <Leaf size={14} />
          Fresh produce? Shelf life
        </Link>
      </div>

      {/* What are we scanning? */}
      <div className="grid grid-cols-2 gap-2 rounded-2xl border p-1.5" style={{ borderColor: "var(--card-border)", background: "var(--paper)" }}>
        {([["packaged", "Packaged food · expiry date"], ["banana", "Banana · condition"]] as const).map(([m, label]) => (
          <button
            key={m}
            onClick={() => switchMode(m)}
            className={mode === m ? "btn-grow !py-2.5 text-sm" : "btn-husk !py-2.5 text-sm"}
            aria-pressed={mode === m}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Config */}
      {mode === "packaged" && (
      <div className="grid gap-3 md:grid-cols-2">
        <div>
          <label className="field-label">Storage condition</label>
          <select value={storage} onChange={(e) => setStorage(e.target.value)} className="input-earth">
            {STORAGE.map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="field-label">Reference date</label>
          <select value={referenceDate} onChange={(e) => setReferenceDate(e.target.value)} className="input-earth">
            <option value={today}>Scan date ({prettyDate(today)})</option>
          </select>
        </div>
      </div>
      )}

      {/* Scanner frame */}
      <div className="scan-plot">
        <div className="relative aspect-[4/3] w-full">
          <video ref={video} autoPlay playsInline muted className="h-full w-full object-cover" />
          {!cameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center" style={{ color: "rgba(255,255,255,0.55)" }}>
              <Camera size={34} style={{ color: "var(--lime)" }} />
              <p className="text-sm">Camera preview will appear here</p>
            </div>
          )}
          <div className="scan-leaf-corner tl" />
          <div className="scan-leaf-corner tr" />
          <div className="scan-leaf-corner bl" />
          <div className="scan-leaf-corner br" />
          <div className="pointer-events-none absolute inset-[14%] rounded-3xl border border-dashed" style={{ borderColor: "rgba(183,217,74,0.4)" }} />
          <div className="pointer-events-none absolute bottom-4 left-0 right-0 flex justify-center">
            <span className="rounded-full border px-3 py-1.5 text-xs backdrop-blur" style={{ borderColor: "rgba(255,255,255,0.15)", background: "rgba(0,0,0,0.5)", color: "rgba(255,255,255,0.9)" }}>
              {mode === "packaged" ? "Packaged food: place the printed date inside the frame" : "Banana: one banana, filling the frame"}
            </span>
          </div>
        </div>
        <canvas ref={canvas} className="hidden" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button onClick={openCamera} className="btn-husk">
          <Crosshair size={17} />
          Open camera
        </button>
        <button onClick={capture} disabled={!cameraOn} className="btn-grow">
          <ScanLine size={17} />
          Capture
        </button>
      </div>

      <label className="panel flex cursor-pointer items-center justify-center gap-2 rounded-2xl p-5 text-center text-sm font-semibold transition hover:border-[var(--leaf)]" style={{ color: "var(--ink)" }}>
        <Upload size={16} />
        Upload image
        <input
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) {
              setFile(f);
              run(f);
            }
          }}
        />
      </label>

      {file && !r && !br && !busy && (
        <button onClick={() => run()} className="btn-grow w-full">
          <Sprout size={17} />
          Analyze image
        </button>
      )}

      {/* Processing */}
      {busy && (
        <div className="panel-strong p-6">
          <div className="flex items-center gap-3">
            <Loader2 size={20} className="animate-spin" style={{ color: "var(--leaf)" }} />
            <b style={{ color: "var(--ink)" }}>Analyzing image…</b>
          </div>
          <div className="mt-4 space-y-2.5">
            {(mode === "banana" ? BANANA_STEPS : PROGRESS_STEPS).map((step, i) => (
              <div key={step} className="flex items-center gap-2 text-sm" style={{ color: i <= progressIdx ? "var(--ink)" : "var(--ink-dim)" }}>
                {i < progressIdx ? (
                  <CheckCircle2 size={14} style={{ color: "var(--leaf-deep)" }} />
                ) : i === progressIdx ? (
                  <span className="pulse-dot" />
                ) : (
                  <span className="h-2 w-2 rounded-full border" style={{ borderColor: "var(--card-border-strong)" }} />
                )}
                {step}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Success */}
      {added && (
        <div className="flex items-center gap-3 rounded-2xl border p-4" style={{ borderColor: "rgba(63,143,82,0.25)", background: "rgba(63,143,82,0.08)" }}>
          <CheckCircle2 size={20} style={{ color: "var(--leaf-deep)" }} />
          <div>
            <p className="font-bold" style={{ color: "var(--ink)" }}>Added to My Food</p>
            <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
              Scan another item whenever you're ready.
            </p>
          </div>
        </div>
      )}

      {/* Banana result */}
      {br && (() => {
        const style = BANANA_STYLE[br.predicted_class] || BANANA_STYLE.ripe;
        return (
          <div className="panel-strong p-6">
            <div className="flex items-center gap-4">
              {previewUrl && (
                <img src={previewUrl} alt="Scanned banana" className="h-20 w-20 shrink-0 rounded-2xl border object-cover" style={{ borderColor: "var(--card-border)" }} />
              )}
              <div>
                <p className="eyebrow">Banana scan</p>
                <p className="text-xs" style={{ color: "var(--ink-dim)" }}>Model: {br.model.name}</p>
              </div>
            </div>

            {br.uncertain && (
              <div className="mt-5 flex items-start gap-3 rounded-xl border p-4 text-sm" style={{ borderColor: "rgba(226,147,61,0.3)", background: "rgba(226,147,61,0.1)", color: "#8a5c14" }}>
                <AlertTriangle size={16} className="mt-0.5 shrink-0" />
                <div>
                  <b>Banana condition is uncertain.</b>
                  <p className="mt-0.5">Please capture one banana clearly.</p>
                </div>
              </div>
            )}

            <div className="mt-5 rounded-3xl border p-5 text-center" style={{ borderColor: "var(--card-border)", background: br.uncertain ? "var(--cream-deep)" : style.bg }}>
              <p className="text-xs font-extrabold uppercase tracking-[0.14em]" style={{ color: "var(--ink-mid)" }}>
                Banana Condition{br.uncertain ? " (uncertain)" : ""}
              </p>
              <p className="mt-2 text-5xl font-bold uppercase tracking-tight" style={{ fontFamily: "var(--font-display)", color: br.uncertain ? "var(--ink-dim)" : style.color }}>
                {br.predicted_class}
              </p>
              <p className="mt-3 text-sm" style={{ color: "var(--ink-mid)" }}>Confidence</p>
              <p className="mono text-2xl font-bold" style={{ color: "var(--ink)" }}>{pct(br.confidence)}</p>
            </div>

            <div className="mt-4 space-y-1.5">
              {br.top3.map((t, i) => (
                <div key={t.class} className="flex items-center justify-between rounded-xl border px-3 py-2 text-sm" style={{ borderColor: "var(--card-border)", background: "var(--cream-deep)", color: "var(--ink)" }}>
                  <span className="capitalize">{i + 1}. {t.class}</span>
                  <span className="mono">{pct(t.confidence)}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs" style={{ color: "var(--ink-dim)" }}>
              Ripeness condition only — not a shelf-life or food-safety guarantee.
            </p>
          </div>
        );
      })()}

      {/* Result */}
      {r && (
        <div className="panel-strong p-6">
          {/* Product */}
          <div className="flex items-center gap-4">
            {previewUrl && (
              <img src={previewUrl} alt="Scanned product" className="h-20 w-20 shrink-0 rounded-2xl border object-cover" style={{ borderColor: "var(--card-border)" }} />
            )}
            <div className="min-w-0">
              <p className="eyebrow">Product</p>
              <h2 className="text-2xl font-bold" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                {r.food?.label || "Packaged food"}
              </h2>
              {r.food && foodSourceLabel(r.food_source) && (
                <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
                  {foodSourceLabel(r.food_source)} · {pct(r.food.confidence)}
                </p>
              )}
            </div>
          </div>

          {/* No printed date found: never invent one */}
          {!r.ocr.expiry_date && (
            <div className="mt-5 flex items-start gap-3 rounded-xl border p-4 text-sm" style={{ borderColor: "rgba(226,147,61,0.3)", background: "rgba(226,147,61,0.1)", color: "#8a5c14" }}>
              <XCircle size={16} className="mt-0.5 shrink-0" />
              <div>
                <b>Expiry date could not be detected clearly.</b>
                <p className="mt-0.5">Please capture the date area again.</p>
                {r.confirmation_reason && <p className="mt-1 text-xs opacity-80">{r.confirmation_reason}</p>}
              </div>
            </div>
          )}

          {/* The answer: expiry date, status, confidence */}
          {r.expiry && (() => {
            const status = r.expiry_status ? STATUS[r.expiry_status] : null;
            const StatusIcon = status?.icon;
            const printed = r.expiry.type === "PRINTED";
            return (
              <div className="mt-5 rounded-3xl border p-5 text-center" style={{ borderColor: printed ? "rgba(63,143,82,0.3)" : "rgba(226,147,61,0.35)", background: printed ? "rgba(63,143,82,0.07)" : "rgba(226,147,61,0.08)" }}>
                <p className="text-xs font-extrabold uppercase tracking-[0.14em]" style={{ color: "var(--ink-mid)" }}>
                  {printed ? "Detected Expiry Date" : "Estimated expiry date"}
                </p>
                <p className="mono mt-2 text-4xl font-bold tracking-tight sm:text-5xl" style={{ color: "var(--ink)" }}>
                  {dmy(r.expiry.date)}
                </p>
                <p className="text-sm" style={{ color: "var(--ink-mid)" }}>{prettyDate(r.expiry.date)}</p>
                <div className="mt-3 flex flex-wrap items-center justify-center gap-3 text-sm" style={{ color: "var(--ink-mid)" }}>
                  {status && StatusIcon && (
                    <span className={`status-pill ${status.className}`}>
                      <StatusIcon size={13} /> Status: {status.label} · {daysText(r.days_until_expiry)}
                    </span>
                  )}
                  <span>
                    Confidence <b className="mono" style={{ color: "var(--ink)" }}>{pct(printed ? r.ocr.confidence : r.food?.confidence)}</b>
                  </span>
                </div>
                <p className="mt-3 text-xs" style={{ color: "var(--ink-dim)" }}>
                  {printed
                    ? "Read from the printed date on the package (OCR)."
                    : `Estimated: ${r.expiry.shelf_life_days} days shelf life (${r.expiry.source}). Not a manufacturer date or food-safety guarantee.`}
                </p>
              </div>
            );
          })()}

          {/* A date was read but not trusted: never shown as certain */}
          {r.ocr.expiry_date && r.expiry?.type !== "PRINTED" && (
            <div className="mt-4 rounded-2xl border p-4" style={{ borderColor: "rgba(244,185,66,0.45)", background: "rgba(244,185,66,0.1)" }}>
              <p className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wide" style={{ color: "#8a5c14" }}>
                <AlertTriangle size={14} /> Expiry date needs verification
              </p>
              <p className="mono mt-1 text-2xl font-bold" style={{ color: "var(--ink)" }}>{prettyDate(r.ocr.expiry_date)}</p>
              <p className="mt-1 text-xs" style={{ color: "var(--ink-mid)" }}>
                Confidence {pct(r.ocr.confidence)}.{" "}
                {r.ocr.ambiguous
                  ? "Several different dates were found on this package — check which one is the expiry date."
                  : "Not clear enough to accept automatically — check it against the package."}
              </p>
              <button
                onClick={() => {
                  setManualMode(true);
                  setManualExpiry(r.ocr.expiry_date!);
                }}
                className="btn-husk mt-3 w-full !py-2 text-sm"
              >
                Use this date
              </button>
            </div>
          )}

          {r.expiry ? (
            <>
              <button onClick={() => setManualMode(!manualMode)} className="btn-husk mt-4 w-full">
                {manualMode ? "Use detected date" : "Enter expiry manually"}
              </button>
              {manualMode && (
                <input
                  type="date"
                  value={manualExpiry}
                  onChange={(e) => setManualExpiry(e.target.value)}
                  className="input-earth mt-3"
                />
              )}
              <button onClick={add} className="btn-grow mt-3 w-full">
                Add to My Food
              </button>
            </>
          ) : (
            <>
              {r.predictions.length > 0 && (
                <div className="mt-4">
                  <p className="font-semibold" style={{ color: "var(--ink)" }}>
                    {r.food_source === "PACKAGE_TEXT" ? "Found on the package" : "AI candidates"}
                  </p>
                  {r.predictions.map((p) => (
                    <div key={p.label} className="mt-2 flex justify-between rounded-xl border p-3 text-sm" style={{ borderColor: "var(--card-border)", background: "var(--cream-deep)", color: "var(--ink)" }}>
                      <span className="capitalize">{p.label}</span>
                      <span className="mono" style={{ color: "var(--leaf-deep)" }}>
                        {pct(p.confidence)}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-4">
                <label className="field-label">Choose food</label>
                <select value={selectedFood} onChange={(e) => setSelectedFood(e.target.value)} className="input-earth">
                  <option value="">Select manually</option>
                  {foods.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} · {f.default_shelf_life_days ?? "no default"} days
                    </option>
                  ))}
                </select>
                <button disabled={!selectedFood} onClick={confirmFood} className="btn-grow mt-3 w-full disabled:opacity-40">
                  Confirm food & calculate
                  <ChevronRight size={16} />
                </button>
              </div>

              <button
                onClick={() => {
                  setAddingNewFood((v) => !v);
                  if (!addingNewFood && r.food?.label) setNewFoodName(r.food.label);
                }}
                className="btn-husk mt-3 w-full"
              >
                <Sprout size={16} />
                {addingNewFood ? "Cancel" : "This food isn't in the list — add it"}
              </button>

              {addingNewFood && (
                <div className="panel mt-3 space-y-3 p-4">
                  <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
                    You haven't configured a shelf life for this item yet. Set one now — it'll be
                    saved for future scans of this food, for you and available to reuse.
                  </p>
                  <div>
                    <label className="field-label">Food name</label>
                    <input className="input-earth" value={newFoodName} onChange={(e) => setNewFoodName(e.target.value)} placeholder="e.g. Dragon fruit" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="field-label">Category</label>
                      <input className="input-earth" value={newFoodCategory} onChange={(e) => setNewFoodCategory(e.target.value)} placeholder="e.g. Fruit" />
                    </div>
                    <div>
                      <label className="field-label">Shelf life (days)</label>
                      <input className="input-earth" type="number" min={0} value={newFoodDays} onChange={(e) => setNewFoodDays(e.target.value)} placeholder="e.g. 7" />
                    </div>
                  </div>
                  <button onClick={saveNewFoodAndAdd} disabled={savingNewFood} className="btn-grow w-full">
                    {savingNewFood ? "Saving..." : "Save & Calculate"}
                  </button>
                </div>
              )}

              <button onClick={() => setManualMode(true)} className="btn-husk mt-3 w-full">
                Enter expiry manually
              </button>
              {manualMode && (
                <>
                  <input
                    type="date"
                    value={manualExpiry}
                    onChange={(e) => setManualExpiry(e.target.value)}
                    className="input-earth mt-3"
                  />
                  <button onClick={add} className="btn-grow mt-3 w-full">
                    Save manual result
                  </button>
                </>
              )}
            </>
          )}

          {r.ocr.text && (
            <details className="mt-4">
              <summary className="cursor-pointer text-xs font-semibold" style={{ color: "var(--ink-dim)" }}>
                View raw OCR result
              </summary>
              <pre className="mono mt-2 max-h-40 overflow-auto whitespace-pre-wrap rounded-xl p-3 text-xs" style={{ background: "var(--cream-deep)", color: "var(--ink-mid)" }}>
                {r.ocr.text}
              </pre>
            </details>
          )}
        </div>
      )}

      <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
        Estimated expiry dates are storage/shelf-life estimates, not food-safety guarantees. Always
        follow the manufacturer's printed date and inspect food appropriately.
      </p>
    </div>
  );
}
