import { Download, Pencil, Plus, ShieldCheck, Trash2, Upload, X } from "lucide-react";
import { ChangeEvent, FormEvent, useEffect, useRef, useState } from "react";
import { addFood, deleteFood, exportFoodsCsv, getFoods, importFoodsCsv, updateFood } from "../services/api";
import { Food } from "../types";

const STORAGE: [string, string][] = [
  ["room_temperature", "Room"],
  ["refrigerator", "Refrigerator"],
  ["freezer", "Freezer"],
  ["pantry", "Pantry"],
  ["opened", "Opened"],
  ["unopened", "Unopened"],
];

const BLANK = { name: "", category: "", default_shelf_life_days: "", default_storage_condition: "room_temperature" };

export default function Admin() {
  const [foods, setFoods] = useState<Food[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState(BLANK);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [importMsg, setImportMsg] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setFoods(await getFoods());
    } catch (e: any) {
      setError(e?.message || "Couldn't load the food catalog.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function startEdit(f: Food) {
    setEditingId(f.id);
    setForm({
      name: f.name,
      category: f.category,
      default_shelf_life_days: String(f.default_shelf_life_days ?? ""),
      default_storage_condition: f.default_storage_condition || "room_temperature",
    });
  }

  function cancelEdit() {
    setEditingId(null);
    setForm(BLANK);
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.category.trim() || form.default_shelf_life_days === "") return;
    setSaving(true);
    setError(null);
    const payload = {
      name: form.name.trim(),
      category: form.category.trim(),
      default_shelf_life_days: Number(form.default_shelf_life_days),
      default_storage_condition: form.default_storage_condition,
      aliases: [],
    };
    try {
      if (editingId) {
        await updateFood(editingId, payload);
      } else {
        await addFood(payload);
      }
      cancelEdit();
      await load();
    } catch (e: any) {
      setError(e?.message || "Couldn't save this food.");
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: number) {
    if (!confirm("Delete this food from the catalog? Existing inventory items referencing it are unaffected.")) return;
    setFoods((prev) => prev.filter((f) => f.id !== id));
    try {
      await deleteFood(id);
    } catch {
      load();
    }
  }

  async function handleImport(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportMsg(null);
    try {
      const res = await importFoodsCsv(file);
      setImportMsg(`Imported ${res.created} new food(s); ${res.rules_imported ?? 0} shelf-life rule(s) added or updated.`);
      await load();
    } catch (e: any) {
      setImportMsg(e?.message || "Import failed.");
    }
    e.target.value = "";
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl" style={{ background: "rgba(63,143,82,0.14)", color: "var(--leaf-deep)" }}>
          <ShieldCheck size={20} />
        </div>
        <div>
          <p className="eyebrow">Admin</p>
          <h1 className="text-2xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
            Food Catalog Management
          </h1>
        </div>
      </div>

      {error && (
        <div className="rounded-2xl border p-3 text-sm" style={{ borderColor: "rgba(201,80,63,0.25)", background: "rgba(201,80,63,0.08)", color: "var(--rust)" }}>
          {error}
        </div>
      )}

      {/* Add / edit form */}
      <div className="panel-strong p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-bold" style={{ color: "var(--ink)" }}>{editingId ? "Edit food" : "Add a new food"}</h2>
          {editingId && (
            <button onClick={cancelEdit} className="btn-husk !py-1.5 !px-3 text-xs">
              <X size={13} /> Cancel edit
            </button>
          )}
        </div>
        <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="field-label">Name</label>
            <input className="input-earth" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Spinach" required />
          </div>
          <div>
            <label className="field-label">Category</label>
            <input className="input-earth" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. Vegetable" required />
          </div>
          <div>
            <label className="field-label">Default shelf life (days)</label>
            <input
              className="input-earth"
              type="number"
              min={0}
              value={form.default_shelf_life_days}
              onChange={(e) => setForm({ ...form, default_shelf_life_days: e.target.value })}
              placeholder="e.g. 5"
              required
            />
          </div>
          <div>
            <label className="field-label">Default storage</label>
            <select
              className="input-earth"
              value={form.default_storage_condition}
              onChange={(e) => setForm({ ...form, default_storage_condition: e.target.value })}
            >
              {STORAGE.map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
            </select>
          </div>
          <button type="submit" disabled={saving} className="btn-grow sm:col-span-2">
            {editingId ? <Pencil size={16} /> : <Plus size={16} />}
            {saving ? "Saving..." : editingId ? "Save changes" : "Add food"}
          </button>
        </form>
      </div>

      {/* CSV import / export */}
      <div className="panel-strong p-6">
        <h2 className="mb-3 font-bold" style={{ color: "var(--ink)" }}>Bulk catalog tools</h2>
        <p className="mb-4 text-sm" style={{ color: "var(--ink-dim)" }}>
          CSV columns: <span className="mono">food_name, category, shelf_life_days, storage_condition</span>
        </p>
        <div className="flex flex-wrap gap-3">
          <button onClick={() => fileInput.current?.click()} className="btn-husk">
            <Upload size={16} /> Import CSV
          </button>
          <input ref={fileInput} type="file" accept=".csv" onChange={handleImport} className="hidden" />
          <button onClick={() => exportFoodsCsv()} className="btn-husk">
            <Download size={16} /> Export CSV
          </button>
        </div>
        {importMsg && <p className="mt-3 text-xs" style={{ color: "var(--ink-dim)" }}>{importMsg}</p>}
      </div>

      {/* Catalog list */}
      <div className="panel-strong p-6">
        <h2 className="mb-3 font-bold" style={{ color: "var(--ink)" }}>Catalog ({foods.length})</h2>
        {loading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="skeleton-warm h-14 w-full" />
            ))}
          </div>
        ) : foods.length === 0 ? (
          <p className="py-6 text-center text-sm" style={{ color: "var(--ink-dim)" }}>No foods in the catalog yet.</p>
        ) : (
          <div className="divide-y" style={{ borderColor: "var(--card-border)" }}>
            {foods.map((f) => (
              <div key={f.id} className="flex items-center justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="font-semibold" style={{ color: "var(--ink)" }}>{f.name}</p>
                  <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
                    {f.category} · {f.default_shelf_life_days ?? "—"} days · {(f.default_storage_condition || "room_temperature").replace("_", " ")}
                  </p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <button onClick={() => startEdit(f)} className="btn-husk !py-2 !px-3 text-xs">
                    <Pencil size={13} />
                  </button>
                  <button onClick={() => remove(f.id)} className="btn-danger-husk !py-2 !px-3 text-xs">
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
