import {
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  Clock3,
  Salad,
  ScanLine,
  Sprout,
  TimerReset,
  XCircle,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

import { getDashboard, getInventory } from "../services/api";
import { Inventory } from "../types";

interface DashboardStats {
  total_items?: number;
  expiring_today?: number;
  expiring_soon?: number;
  expired?: number;
  estimated?: number;
  printed?: number;
}

function formatDate(date: string) {
  return new Date(`${date}T00:00:00`).toLocaleDateString("en-IN", { day: "2-digit", month: "short" });
}

function getDaysRemaining(date: string) {
  const expiry = new Date(`${date}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.floor((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

function getStatus(date: string) {
  const days = getDaysRemaining(date);

  if (days < 0) return { label: "Expired", text: `${Math.abs(days)}d ago`, className: "status-expired", icon: XCircle };
  if (days === 0) return { label: "Today", text: "Today", className: "status-today", icon: TimerReset };
  if (days <= 3) return { label: "Soon", text: `${days}d`, className: "status-soon", icon: AlertTriangle };
  return { label: "Safe", text: `${days}d`, className: "status-safe", icon: CheckCircle2 };
}

function accentFor(date: string) {
  const days = getDaysRemaining(date);
  if (days < 0) return "accent-rust";
  if (days === 0) return "accent-terracotta";
  if (days <= 3) return "accent-amber";
  return "";
}

function getFoodEmoji(name?: string) {
  const food = name?.toLowerCase() ?? "";
  if (food.includes("tomato")) return "🍅";
  if (food.includes("milk")) return "🥛";
  if (food.includes("bread")) return "🍞";
  if (food.includes("apple")) return "🍎";
  if (food.includes("banana")) return "🍌";
  if (food.includes("orange")) return "🍊";
  if (food.includes("egg")) return "🥚";
  if (food.includes("chicken")) return "🍗";
  if (food.includes("fish")) return "🐟";
  if (food.includes("rice")) return "🍚";
  if (food.includes("potato")) return "🥔";
  if (food.includes("carrot")) return "🥕";
  if (food.includes("onion")) return "🧅";
  return "🥗";
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({});
  const [inventory, setInventory] = useState<Inventory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadDashboard() {
    try {
      setLoading(true);
      setError("");
      const [dashboardData, inventoryData] = await Promise.all([getDashboard(), getInventory()]);
      setStats(dashboardData);
      setInventory(inventoryData);
    } catch (error: any) {
      setError(error?.message || "Unable to connect to the database.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadDashboard();
  }, []);

  const upcoming = useMemo(() => {
    return [...inventory]
      .filter((item) => !item.consumed)
      .sort((a, b) => new Date(a.final_expiry_date).getTime() - new Date(b.final_expiry_date).getTime())
      .slice(0, 5);
  }, [inventory]);

  const total = stats.total_items ?? 0;
  const printedPercentage = total > 0 ? Math.round(((stats.printed ?? 0) / total) * 100) : 0;
  const estimatedPercentage = total > 0 ? Math.round(((stats.estimated ?? 0) / total) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* HERO */}
      <section className="hero-panel p-6 sm:p-8 lg:p-10">
        <div className="relative z-10 flex flex-col gap-10 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-[620px]">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/30 px-3 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.12em]" style={{ color: "#21301f" }}>
              <Sprout size={12} />
              AI-powered food tracking
            </div>

            <h2
              className="max-w-[600px] text-4xl font-bold tracking-[-0.02em] sm:text-5xl lg:text-[3.4rem]"
              style={{ fontFamily: "var(--font-display)", color: "#1a2818" }}
            >
              Stay ahead of
              <span className="block">food waste.</span>
            </h2>

            <p className="mt-5 max-w-[480px] text-sm leading-6 sm:text-base" style={{ color: "#2f3f2a" }}>
              Scan packaged food for printed expiry dates, or use configurable shelf-life
              estimates for fresh food.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/scan" className="btn-grow !bg-[#213421] !shadow-[0_10px_22px_rgba(20,30,18,0.35)]">
                <ScanLine size={18} />
                Scan Food
              </Link>
              <Link to="/shelf-life" className="btn-grow">
                <Sprout size={18} />
                Fresh food shelf life
              </Link>
              <Link to="/food" className="inline-flex items-center gap-2 rounded-2xl border border-white/50 bg-white/35 px-5 py-3 text-sm font-bold" style={{ color: "#21301f" }}>
                View inventory
                <ArrowUpRight size={16} />
              </Link>
            </div>
          </div>

          <div className="hidden items-center justify-center pr-4 lg:flex">
            <div className="hero-produce flex items-center justify-center">
              <div className="text-center">
                <div className="text-5xl">🧺</div>
                <div className="mt-3 text-[10px] font-extrabold uppercase tracking-[0.14em]" style={{ color: "#21301f" }}>
                  Smart scan
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ERROR */}
      {error && (
        <div className="flex flex-col gap-3 rounded-2xl border p-4 text-sm sm:flex-row sm:items-center sm:justify-between" style={{ borderColor: "rgba(201,80,63,0.25)", background: "rgba(201,80,63,0.08)", color: "var(--rust)" }}>
          <div className="flex items-center gap-2">
            <XCircle size={17} />
            <span>{error}</span>
          </div>
          <button onClick={loadDashboard} className="rounded-xl px-4 py-2 text-xs font-black" style={{ background: "rgba(201,80,63,0.15)" }}>
            Retry
          </button>
        </div>
      )}

      {/* STATISTICS */}
      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { title: "Total food", value: stats.total_items ?? 0, icon: Salad },
          { title: "Expiring today", value: stats.expiring_today ?? 0, icon: TimerReset },
          { title: "Expiring soon", value: stats.expiring_soon ?? 0, icon: AlertTriangle },
          { title: "Expired", value: stats.expired ?? 0, icon: XCircle },
        ].map((card) => {
          const Icon = card.icon;
          return (
            <div className="stat-tile" key={card.title}>
              <div className="relative z-10">
                <div className="mb-5 flex items-center justify-between">
                  <span className="text-xs font-semibold" style={{ color: "var(--ink-mid)" }}>
                    {card.title}
                  </span>
                  <div className="flex h-8 w-8 items-center justify-center rounded-xl" style={{ background: "rgba(63,143,82,0.1)", color: "var(--leaf-deep)" }}>
                    <Icon size={15} />
                  </div>
                </div>
                {loading ? (
                  <div className="skeleton-warm h-10 w-16" />
                ) : (
                  <div className="text-4xl font-bold tracking-[-0.02em]" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                    {card.value}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </section>

      {/* CONTENT */}
      <section className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        {/* EXPIRY LIST */}
        <div className="panel-strong p-5 sm:p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="eyebrow">Freshness board</p>
              <h3 className="mt-1 text-xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                Upcoming expirations
              </h3>
            </div>
            <Link to="/food" className="text-xs font-bold" style={{ color: "var(--leaf-deep)" }}>
              View all
            </Link>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4].map((item) => (
                <div key={item} className="skeleton-warm h-[76px] w-full" />
              ))}
            </div>
          ) : upcoming.length === 0 ? (
            <div className="rounded-2xl border border-dashed p-8 text-center" style={{ borderColor: "var(--card-border-strong)" }}>
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl" style={{ background: "rgba(183,217,74,0.16)", color: "var(--leaf-deep)" }}>
                <Salad size={20} />
              </div>
              <h4 className="mt-4 font-bold" style={{ color: "var(--ink)" }}>Your kitchen is empty</h4>
              <p className="mt-1 text-sm" style={{ color: "var(--ink-dim)" }}>
                Scan your first food item to start tracking.
              </p>
              <Link to="/scan" className="btn-grow mt-5 inline-flex !py-2.5 !px-4 text-xs">
                Scan food
              </Link>
            </div>
          ) : (
            <div className="space-y-2.5">
              {upcoming.map((item) => {
                const status = getStatus(item.final_expiry_date);
                const StatusIcon = status.icon;
                return (
                  <div key={item.id} className={`crate-card ${accentFor(item.final_expiry_date)} flex items-center gap-3 px-4 py-3.5`}>
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-xl" style={{ background: "var(--cream-deep)" }}>
                      {getFoodEmoji(item.product_name)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold" style={{ color: "var(--ink)" }}>{item.product_name}</p>
                      <div className="mt-1 flex flex-wrap items-center gap-2">
                        <span className={`status-pill ${status.className}`}>{status.label}</span>
                        <span className="text-[10px]" style={{ color: "var(--ink-dim)" }}>
                          {item.expiry_type === "ESTIMATED" ? "Estimated" : item.expiry_type === "PRINTED" ? "Printed" : "Manual"}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="mono text-xs font-bold" style={{ color: "var(--ink)" }}>{formatDate(item.final_expiry_date)}</p>
                      <p className="mt-1 flex items-center justify-end gap-1 text-[10px]" style={{ color: "var(--ink-dim)" }}>
                        <StatusIcon size={11} />
                        {status.text}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* RIGHT COLUMN */}
        <div className="space-y-6">
          {/* Tracking mix */}
          <div className="panel-strong p-5 sm:p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl" style={{ background: "rgba(226,147,61,0.14)", color: "var(--amber)" }}>
                <Clock3 size={18} />
              </div>
              <div>
                <p className="eyebrow">Tracking mix</p>
                <h3 className="font-bold" style={{ color: "var(--ink)" }}>Expiry sources</h3>
              </div>
            </div>

            <div className="mt-6 space-y-5">
              <div>
                <div className="mb-2 flex justify-between text-xs">
                  <span className="font-semibold" style={{ color: "var(--ink-mid)" }}>Printed dates</span>
                  <strong className="mono" style={{ color: "var(--ink)" }}>{stats.printed ?? 0}</strong>
                </div>
                <div className="progress-track">
                  <div className="progress-fill" style={{ width: `${printedPercentage}%` }} />
                </div>
              </div>

              <div>
                <div className="mb-2 flex justify-between text-xs">
                  <span className="font-semibold" style={{ color: "var(--ink-mid)" }}>Estimated dates</span>
                  <strong className="mono" style={{ color: "var(--ink)" }}>{stats.estimated ?? 0}</strong>
                </div>
                <div className="progress-track">
                  <div className="progress-fill" style={{ width: `${estimatedPercentage}%`, background: "var(--grad-warm)" }} />
                </div>
              </div>
            </div>
          </div>

          {/* Smart rule */}
          <div className="panel p-5" style={{ borderColor: "rgba(63,143,82,0.25)", background: "rgba(183,217,74,0.06)" }}>
            <div className="flex gap-3">
              <CheckCircle2 className="mt-0.5 shrink-0" size={18} style={{ color: "var(--leaf-deep)" }} />
              <div>
                <p className="text-sm font-bold" style={{ color: "var(--ink)" }}>Smart expiry rule</p>
                <p className="mt-1 text-xs leading-5" style={{ color: "var(--ink-mid)" }}>
                  Manufacturer-printed expiry dates always take precedence over shelf-life
                  estimates.
                </p>
              </div>
            </div>
          </div>

          {/* Scan CTA */}
          <Link to="/scan" className="group relative block overflow-hidden rounded-[26px] p-5 transition hover:-translate-y-1" style={{ background: "var(--grad-leaf)" }}>
            <div className="relative z-10 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 text-white/75">
                  <ScanLine size={17} />
                  <span className="text-[10px] font-extrabold uppercase tracking-[0.12em]">
                    Ready to scan?
                  </span>
                </div>
                <p className="mt-2 text-xl font-bold tracking-tight text-white" style={{ fontFamily: "var(--font-display)" }}>
                  Add food to your kitchen
                </p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/20 text-white transition group-hover:rotate-6">
                <ArrowUpRight size={19} />
              </div>
            </div>
            <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-white/20 blur-2xl" />
          </Link>
        </div>
      </section>

      {/* SAFETY DISCLAIMER */}
      <div className="flex gap-3 rounded-2xl border p-4" style={{ borderColor: "rgba(226,147,61,0.3)", background: "rgba(226,147,61,0.08)" }}>
        <AlertTriangle className="mt-0.5 shrink-0" size={16} style={{ color: "var(--amber)" }} />
        <p className="text-[11px] leading-5" style={{ color: "#7a5518" }}>
          Estimated expiry dates are based on configured shelf-life information and storage
          conditions. They are not a guarantee of food safety. Always follow the manufacturer's
          printed date and inspect food appropriately.
        </p>
      </div>
    </div>
  );
}
