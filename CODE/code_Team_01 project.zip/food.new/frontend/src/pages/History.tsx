import { ChevronDown, Clock3, FileText, ScanEye } from "lucide-react";
import { useEffect, useState } from "react";
import { getScans } from "../services/api";
import { ScanRecord } from "../types";

function pct(n: number | null | undefined) {
  return typeof n === "number" ? `${Math.round(n * 100)}%` : "—";
}

function timeAgo(iso?: string) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

export default function History() {
  const [scans, setScans] = useState<ScanRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<number | null>(null);

  useEffect(() => {
    getScans()
      .then(setScans)
      .catch(() => setScans([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <p className="eyebrow">Detection log</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
          Scan History
        </h1>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="skeleton-warm h-20 w-full" />
          ))}
        </div>
      ) : scans.length === 0 ? (
        <div className="panel flex flex-col items-center gap-3 p-10 text-center">
          <Clock3 size={30} style={{ color: "var(--amber)" }} />
          <div>
            <p className="font-bold" style={{ color: "var(--ink)" }}>No scans yet</p>
            <p className="mt-1 text-sm" style={{ color: "var(--ink-dim)" }}>
              Your scan history will show up here.
            </p>
          </div>
        </div>
      ) : (
        <div className="relative space-y-3 pl-6">
          <div className="absolute left-[9px] top-2 bottom-2 w-px" style={{ background: "linear-gradient(to bottom, rgba(183,217,74,0.5), rgba(226,147,61,0.15))" }} />
          {scans.map((s) => {
            const isOpen = expanded === s.id;
            return (
              <div key={s.id} className="relative">
                <span
                  className="absolute -left-6 top-5 h-2.5 w-2.5 rounded-full"
                  style={{ background: "var(--leaf)", boxShadow: "0 0 10px rgba(63,143,82,0.6)" }}
                />
                <div className="panel p-4">
                  <button onClick={() => setExpanded(isOpen ? null : s.id)} className="flex w-full items-center gap-3 text-left">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl" style={{ background: "rgba(226,147,61,0.14)", color: "var(--amber)" }}>
                      <ScanEye size={17} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-bold capitalize" style={{ color: "var(--ink)" }}>{s.detected_product || "Unrecognized item"}</p>
                      <p className="text-xs" style={{ color: "var(--ink-dim)" }}>
                        {timeAgo(s.created_at)}
                      </p>
                    </div>
                    <ChevronDown size={16} className={`transition-transform ${isOpen ? "rotate-180" : ""}`} style={{ color: "var(--ink-dim)" }} />
                  </button>

                  {isOpen && (
                    <div className="mt-4 space-y-2 border-t pt-3 text-sm" style={{ borderColor: "var(--card-border)" }}>
                      <div className="flex justify-between">
                        <span style={{ color: "var(--ink-dim)" }}>OCR confidence</span>
                        <span className="mono" style={{ color: "var(--ink)" }}>{pct(s.ocr_confidence)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span style={{ color: "var(--ink-dim)" }}>Classification confidence</span>
                        <span className="mono" style={{ color: "var(--ink)" }}>{pct(s.classification_confidence)}</span>
                      </div>
                      {s.detected_expiry_date && (
                        <div className="flex justify-between">
                          <span style={{ color: "var(--ink-dim)" }}>Detected expiry</span>
                          <span className="mono" style={{ color: "var(--ink)" }}>{s.detected_expiry_date}</span>
                        </div>
                      )}
                      {s.raw_ocr_text && (
                        <div>
                          <p className="mb-1 flex items-center gap-1.5" style={{ color: "var(--ink-dim)" }}>
                            <FileText size={12} /> Raw OCR text
                          </p>
                          <pre className="mono max-h-32 overflow-auto whitespace-pre-wrap rounded-xl p-3 text-xs" style={{ background: "var(--cream-deep)", color: "var(--ink-mid)" }}>
                            {s.raw_ocr_text}
                          </pre>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
