import { CheckCircle2, Clock3, Leaf, Loader2, Plus, Search, Trash2 } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { addInventory, createRule, deleteRule, getFoods, getRules, getShelfLifeRecommendation } from "../services/api";
import { Food, ShelfLifeRecommendation, ShelfLifeRule } from "../types";

const STORAGE: [string, string][] = [
  ["room_temperature", "Room"],
  ["refrigerator", "Refrigerator"],
  ["freezer", "Freezer"],
  ["pantry", "Pantry"],
  ["opened", "Opened"],
  ["unopened", "Unopened"],
];

const STORAGE_LABEL: Record<string, string> = {
  room_temperature: "Room temperature",
  refrigerator: "Refrigerated",
  freezer: "Frozen",
  pantry: "Pantry",
  opened: "Opened",
  unopened: "Unopened",
};

function storageLabel(s: string | null | undefined) {
  return s ? STORAGE_LABEL[s] || s.replace(/_/g, " ") : "";
}

function prettyDate(s: string) {
  return new Date(s + "T00:00:00").toLocaleDateString(undefined, { day: "2-digit", month: "long", year: "numeric" });
}

function rangeText(r: ShelfLifeRule) {
  return r.shelf_life_days_max != null && r.shelf_life_days_max !== r.shelf_life_days
    ? `${r.shelf_life_days}–${r.shelf_life_days_max} days`
    : `${r.shelf_life_days} days`;
}

export default function ShelfLife() {
  const [foods, setFoods] = useState<Food[]>([]);
  const [rules, setRules] = useState<ShelfLifeRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [foodId, setFoodId] = useState("");
  const [days, setDays] = useState("");
  const [maxDays, setMaxDays] = useState("");
  const [storage, setStorage] = useState("room_temperature");
  const [saving, setSaving] = useState(false);

  // Fresh-food lookup
  const [query, setQuery] = useState("");
  const [rec, setRec] = useState<ShelfLifeRecommendation | null>(null);
  const [recError, setRecError] = useState("");
  const [recLoading, setRecLoading] = useState(false);
  const [recAdded, setRecAdded] = useState(false);

  async function lookup(name: string, storageCondition?: string) {
    if (!name.trim()) return;
    setRecLoading(true);
    setRecError("");
    setRecAdded(false);
    try {
      setRec(await getShelfLifeRecommendation({ name: name.trim(), storage_condition: storageCondition }));
    } catch (e: any) {
      setRec(null);
      setRecError(e?.message || "Couldn't look up this food.");
    } finally {
      setRecLoading(false);
    }
  }

  function submitLookup(e: FormEvent) {
    e.preventDefault();
    lookup(query);
  }

  async function addRecommendation() {
    if (!rec?.recommendation || !rec.expected_expiry_date) return;
    await addInventory({
      product_name: rec.food.name,
      food_id: rec.food.id,
      category: rec.food.category,
      purchase_date: rec.reference_date,
      final_expiry_date: rec.expected_expiry_date,
      estimated_expiry_date: rec.expected_expiry_date,
      expiry_type: "ESTIMATED",
      storage_condition: rec.recommendation.storage_condition,
      quantity: 1,
      unit: "item",
      confidence: null,
      detection_method: "SHELF_LIFE_RULE",
      notes: `Recommended shelf life ${rec.recommendation.label} (${storageLabel(rec.recommendation.storage_condition)}); not a food-safety guarantee.`,
    });
    setRecAdded(true);
  }

  async function load() {
    setLoading(true);
    try {
      const [f, r] = await Promise.all([getFoods(), getRules()]);
      setFoods(f);
      setRules(r);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function save() {
    if (!foodId || !days) return;
    setSaving(true);
    try {
      await createRule({
        food_id: +foodId,
        shelf_life_days: +days,
        shelf_life_days_max: maxDays ? +maxDays : null,
        storage_condition: storage,
      });
      setDays("");
      setMaxDays("");
      setFoodId("");
      await load();
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: number) {
    if (!confirm("Delete this shelf-life rule?")) return;
    setRules((prev) => prev.filter((r) => r.id !== id));
    try {
      await deleteRule(id);
    } catch {
      load();
    }
  }

  function foodName(id: number) {
    return foods.find((f) => f.id === id)?.name || `Food #${id}`;
  }

  return (
    <div className="space-y-5">
      <div>
        <p className="eyebrow">Fresh fruit &amp; vegetables</p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
          Fresh Food Shelf Life
        </h1>
        <p className="mt-1 text-sm" style={{ color: "var(--ink-dim)" }}>
          Pick a food to see how long it keeps, from the shelf-life rules below.
        </p>
      </div>

      {/* Fresh-food recommendation */}
      <div className="panel-strong p-6">
        <form onSubmit={submitLookup} className="flex gap-2">
          <input
            className="input-earth"
            list="fresh-foods"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. Apple, Banana, Potato"
            aria-label="Food"
          />
          <datalist id="fresh-foods">
            {foods.map((f) => (
              <option key={f.id} value={f.name} />
            ))}
          </datalist>
          <button type="submit" disabled={!query.trim() || recLoading} className="btn-grow shrink-0 disabled:opacity-40">
            {recLoading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
            Shelf life
          </button>
        </form>

        {recError && (
          <p className="mt-4 rounded-xl border p-3 text-sm" style={{ borderColor: "rgba(226,147,61,0.3)", background: "rgba(226,147,61,0.1)", color: "#8a5c14" }}>
            {recError} Add it from <b>Scan Food</b> (“This food isn't in the list”), or ask an admin to add it to the catalog.
          </p>
        )}

        {rec && (
          <div className="mt-5">
            <p className="text-center text-2xl font-extrabold uppercase tracking-[0.08em]" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
              {rec.food.name}
            </p>

            {rec.recommendation ? (
              <div className="mt-3 rounded-3xl border p-5 text-center" style={{ borderColor: "rgba(63,143,82,0.3)", background: "rgba(63,143,82,0.07)" }}>
                <p className="text-xs font-extrabold uppercase tracking-[0.14em]" style={{ color: "var(--ink-mid)" }}>
                  Recommended shelf life
                </p>
                <p className="mt-2 text-5xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                  {rec.recommendation.label}
                </p>
                <p className="mt-2 text-sm" style={{ color: "var(--ink-mid)" }}>
                  Storage: <b>{storageLabel(rec.recommendation.storage_condition)}</b>
                </p>
                {rec.expected_expiry_date && (
                  <p className="mt-1 text-sm" style={{ color: "var(--ink-mid)" }}>
                    Bought today? Use or check by <b>{prettyDate(rec.expected_expiry_date)}</b>
                  </p>
                )}
                <p className="mt-3 text-xs" style={{ color: "var(--ink-dim)" }}>
                  Source: {rec.recommendation.source || "rule"}
                  {rec.recommendation.notes ? ` · ${rec.recommendation.notes}` : ""}
                </p>
              </div>
            ) : (
              <p className="mt-3 rounded-xl border p-3 text-sm" style={{ borderColor: "rgba(226,147,61,0.3)", background: "rgba(226,147,61,0.1)", color: "#8a5c14" }}>
                {rec.message}
              </p>
            )}

            {rec.options.length > 1 && (
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {rec.options.map((o) => (
                  <button
                    key={o.storage_condition}
                    onClick={() => lookup(rec.food.name, o.storage_condition)}
                    className={`status-pill ${o.storage_condition === rec.storage_condition ? "status-safe" : ""}`}
                    style={o.storage_condition === rec.storage_condition ? undefined : { background: "var(--cream-deep)", color: "var(--ink-mid)" }}
                  >
                    {storageLabel(o.storage_condition)} · {o.label}
                  </button>
                ))}
              </div>
            )}

            {rec.recommendation && (
              recAdded ? (
                <p className="mt-4 flex items-center justify-center gap-2 text-sm font-semibold" style={{ color: "var(--leaf-deep)" }}>
                  <CheckCircle2 size={16} /> Added to My Food — you'll get a reminder before it's due.
                </p>
              ) : (
                <button onClick={addRecommendation} className="btn-grow mt-4 w-full">
                  <Leaf size={16} />
                  Add to My Food
                </button>
              )
            )}
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl font-bold" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>My Shelf Life Rules</h2>
        <p className="mt-1 text-sm" style={{ color: "var(--ink-dim)" }}>
          Demo values are configurable estimates, not authoritative safety guidance. Your own
          rule always overrides the global default for your scans.
        </p>
      </div>

      <div className="panel-strong p-6">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl" style={{ background: "rgba(226,147,61,0.14)", color: "var(--amber)" }}>
            <Clock3 size={18} />
          </div>
          <h2 className="font-bold" style={{ color: "var(--ink)" }}>Add / override a rule</h2>
        </div>

        <label className="field-label">Food</label>
        <select value={foodId} onChange={(e) => setFoodId(e.target.value)} className="input-earth">
          <option value="">Choose food</option>
          {foods.map((x) => (
            <option value={x.id} key={x.id}>
              {x.name} · default {x.default_shelf_life_days ?? "—"} days
            </option>
          ))}
        </select>

        <div className="mt-3 grid grid-cols-3 gap-3">
          <div>
            <label className="field-label">Days</label>
            <input
              className="input-earth"
              type="number"
              min={0}
              placeholder="e.g. 6"
              value={days}
              onChange={(e) => setDays(e.target.value)}
            />
          </div>
          <div>
            <label className="field-label">Max days (optional)</label>
            <input
              className="input-earth"
              type="number"
              min={days || 0}
              placeholder="e.g. 9"
              value={maxDays}
              onChange={(e) => setMaxDays(e.target.value)}
            />
          </div>
          <div>
            <label className="field-label">Storage</label>
            <select className="input-earth" value={storage} onChange={(e) => setStorage(e.target.value)}>
              {STORAGE.map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </select>
          </div>
        </div>

        <button onClick={save} disabled={saving || !foodId || !days} className="btn-grow mt-4 w-full disabled:opacity-40">
          <Plus size={16} />
          {saving ? "Saving..." : "Save rule"}
        </button>
      </div>

      <div className="panel-strong p-6">
        <h2 className="mb-3 font-bold" style={{ color: "var(--ink)" }}>Your rules</h2>
        {loading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="skeleton-warm h-12 w-full" />
            ))}
          </div>
        ) : rules.length === 0 ? (
          <p className="py-6 text-center text-sm" style={{ color: "var(--ink-dim)" }}>
            No custom rules yet — add one above to override a default shelf life.
          </p>
        ) : (
          <div className="divide-y" style={{ borderColor: "var(--card-border)" }}>
            {rules.map((x) => (
              <div key={x.id} className="flex items-center justify-between gap-3 py-3 text-sm">
                <div>
                  <p className="font-semibold capitalize" style={{ color: "var(--ink)" }}>{foodName(x.food_id)}</p>
                  <p className="mt-0.5" style={{ color: "var(--ink-dim)" }}>
                    <span className="mono" style={{ color: "var(--leaf-deep)" }}>
                      {rangeText(x)}
                    </span>{" "}
                    · {x.storage_condition.replace("_", " ")} · {x.source || "USER_CUSTOM"}
                  </p>
                </div>
                <button onClick={() => remove(x.id)} className="btn-danger-husk !py-2 !px-3 text-xs">
                  <Trash2 size={13} />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
