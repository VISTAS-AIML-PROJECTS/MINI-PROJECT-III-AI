import { ArrowRight, Leaf, ScanLine, ShieldCheck, Sprout } from "lucide-react";
import { FormEvent, useState } from "react";
import { auth, SESSION_EXPIRED_KEY } from "../services/api";

export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
  });

  const [error, setError] = useState(() => {
    // Set by the API client when a request came back 401 (expired/invalid token).
    if (sessionStorage.getItem(SESSION_EXPIRED_KEY)) {
      sessionStorage.removeItem(SESSION_EXPIRED_KEY);
      return "Your session has expired. Please sign in again.";
    }
    return "";
  });
  const [loading, setLoading] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();

    try {
      setLoading(true);
      setError("");

      // auth.login/register already persist the token + user to
      // localStorage (see services/api.ts persistSession).
      if (mode === "login") {
        await auth.login({ email: form.email, password: form.password });
      } else {
        await auth.register(form);
      }
      window.location.href = import.meta.env.BASE_URL;
    } catch (err: any) {
      setError(err?.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative min-h-screen overflow-hidden" style={{ background: "var(--cream)" }}>
      <div className="field-blob fixed" style={{ width: 520, height: 520, top: -200, left: -160, background: "rgba(183,217,74,0.18)" }} />
      <div className="field-blob fixed" style={{ width: 420, height: 420, bottom: -160, right: -140, background: "rgba(244,185,66,0.16)" }} />

      <div className="relative z-10 grid min-h-screen lg:grid-cols-[1.1fr_.9fr]">
        {/* Brand panel */}
        <section className="relative hidden overflow-hidden lg:flex">
          <div className="relative z-10 flex w-full flex-col justify-between p-12 xl:p-20">
            <div className="flex items-center gap-3">
              <div className="brand-mark">
                <Sprout size={18} />
              </div>
              <div className="font-bold" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                SmartFood
              </div>
            </div>

            <div>
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 eyebrow" style={{ borderColor: "var(--card-border-strong)", background: "var(--paper)" }}>
                <Leaf size={12} />
                Know what's fresh, before it's not
              </div>

              <h1
                className="max-w-[650px] text-6xl font-bold tracking-[-0.02em]"
                style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}
              >
                From the crate
                <span className="block" style={{ color: "var(--leaf-deep)" }}>to your table.</span>
              </h1>

              <p className="mt-6 max-w-[500px] text-base leading-7" style={{ color: "var(--ink-mid)" }}>
                Scan packages for printed expiry dates, or let AI estimate shelf life for fresh
                produce — with reminders before anything goes to waste.
              </p>
            </div>

            <div className="flex gap-8" style={{ color: "var(--ink-dim)" }}>
              <div>
                <ShieldCheck size={18} style={{ color: "var(--leaf)" }} />
                <p className="mt-2 text-xs">Private inventory</p>
              </div>
              <div>
                <ScanLine size={18} style={{ color: "var(--terracotta)" }} />
                <p className="mt-2 text-xs">AI-assisted scanning</p>
              </div>
              <div>
                <Leaf size={18} style={{ color: "var(--amber)" }} />
                <p className="mt-2 text-xs">Custom shelf life</p>
              </div>
            </div>
          </div>
        </section>

        {/* Form */}
        <section className="flex items-center justify-center p-5 sm:p-10">
          <div className="panel-strong w-full max-w-[440px] p-8">
            <div className="mb-8 lg:hidden">
              <div className="brand-mark">
                <Sprout size={18} />
              </div>
              <h1 className="mt-5 text-3xl font-bold tracking-tight" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                SmartFood
              </h1>
            </div>

            <div className="mb-8">
              <p className="eyebrow">{mode === "login" ? "Welcome back" : "Get started"}</p>
              <h2 className="mt-2 text-3xl font-bold tracking-[-0.01em]" style={{ fontFamily: "var(--font-display)", color: "var(--ink)" }}>
                {mode === "login" ? "Your kitchen, smarter." : "Create your account."}
              </h2>
              <p className="mt-2 text-sm" style={{ color: "var(--ink-dim)" }}>
                {mode === "login" ? "Sign in to continue managing your food." : "Start tracking your food expiry intelligently."}
              </p>
            </div>

            <form onSubmit={submit} className="space-y-4">
              {mode === "register" && (
                <div>
                  <label className="field-label">Name</label>
                  <input
                    className="input-earth"
                    placeholder="Your name"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    required
                  />
                </div>
              )}

              <div>
                <label className="field-label">Email</label>
                <input
                  className="input-earth"
                  type="email"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="field-label">Password</label>
                <input
                  className="input-earth"
                  type="password"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  required
                />
              </div>

              {error && (
                <div className="rounded-2xl border p-3 text-sm" style={{ borderColor: "rgba(201,80,63,0.25)", background: "rgba(201,80,63,0.08)", color: "var(--rust)" }}>
                  {error}
                </div>
              )}

              <button disabled={loading} className="btn-grow group w-full">
                {loading ? "Please wait..." : mode === "login" ? "Sign in" : "Create account"}
                {!loading && <ArrowRight size={17} className="transition group-hover:translate-x-1" />}
              </button>
            </form>

            <button
              type="button"
              onClick={() => setMode(mode === "login" ? "register" : "login")}
              className="mt-6 w-full text-center text-sm font-semibold"
              style={{ color: "var(--ink-mid)" }}
            >
              {mode === "login" ? "Don't have an account? Create one" : "Already have an account? Sign in"}
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
