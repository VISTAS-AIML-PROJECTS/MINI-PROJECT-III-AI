import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  // GitHub Pages serves project sites from /<repo-name>/, not from the
  // domain root. Set via VITE_BASE_PATH in CI (see
  // .github/workflows/deploy-pages.yml); defaults to "/" for local dev
  // and for Vercel/Netlify (which serve from the root).
  base: process.env.VITE_BASE_PATH || "/",

  plugins: [
    react(),
    tailwindcss(),
  ],

  server: {
    host: "0.0.0.0",
    port: 5173,
    allowedHosts: true,

    proxy: {
      "/api": {
        target: "http://127.0.0.1:8000",
        changeOrigin: true,
      },
    },
  },
});
