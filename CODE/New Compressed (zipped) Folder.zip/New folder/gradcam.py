import numpy as np
import tensorflow as tf
from PIL import Image

def make_gradcam_heatmap(img_array, model):
    # Find the nested CNN base model (MobileNetV2)
    base_model = None
    for layer in model.layers:
        if isinstance(layer, tf.keras.Model):
            base_model = layer
            break

    if base_model is None:
        raise ValueError("CNN base model not found")

    last_conv = None
    for layer in reversed(base_model.layers):
        try:
            if len(layer.output.shape) == 4:
                last_conv = layer
                break
        except Exception:
            pass

    if last_conv is None:
        raise ValueError("Convolution layer not found")

    grad_model = tf.keras.models.Model(
        inputs=base_model.inputs,
        outputs=[last_conv.output, base_model.output]
    )

    with tf.GradientTape() as tape:
        conv_output, base_output = grad_model(img_array, training=False)
        # Use the classifier head attached to the full model.
        x = base_output
        for layer in model.layers:
            if layer.name != base_model.name:
                try:
                    x = layer(x, training=False)
                except TypeError:
                    x = layer(x)
        prediction = x
        loss = prediction[:, 0]

    grads = tape.gradient(loss, conv_output)
    weights = tf.reduce_mean(grads, axis=(0, 1, 2))
    conv_output = conv_output[0]
    heatmap = conv_output @ weights[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)
    heatmap = tf.maximum(heatmap, 0)
    heatmap /= tf.reduce_max(heatmap) + 1e-8
    return heatmap.numpy()

def save_gradcam_overlay(image_path, heatmap, output_path):
    original = Image.open(image_path).convert("RGB")
    hm = Image.fromarray(np.uint8(heatmap * 255)).resize(original.size)
    h = np.asarray(hm).astype(np.float32) / 255.0
    base = np.asarray(original).astype(np.float32)

    overlay = np.zeros_like(base)
    overlay[..., 0] = 255 * h
    overlay[..., 1] = 70 * h
    overlay[..., 2] = 20 * h

    result = np.clip(0.55 * base + 0.45 * overlay, 0, 255).astype(np.uint8)
    Image.fromarray(result).save(output_path)
