import os
import tensorflow as tf

BASE=os.path.dirname(os.path.abspath(__file__))
DATA=os.path.join(BASE,"dataset")
OUT=os.path.join(BASE,"model","skin_cancer_model.keras")
os.makedirs(os.path.dirname(OUT),exist_ok=True)
SIZE=(224,224)

train=tf.keras.utils.image_dataset_from_directory(DATA,validation_split=.2,subset="training",seed=42,image_size=SIZE,batch_size=32,label_mode="binary")
val=tf.keras.utils.image_dataset_from_directory(DATA,validation_split=.2,subset="validation",seed=42,image_size=SIZE,batch_size=32,label_mode="binary")
base=tf.keras.applications.MobileNetV2(input_shape=SIZE+(3,),include_top=False,weights="imagenet")
base.trainable=False
inp=tf.keras.Input(shape=SIZE+(3,))
x=tf.keras.layers.RandomFlip("horizontal")(inp)
x=tf.keras.layers.RandomRotation(.08)(x)
x=tf.keras.layers.RandomZoom(.1)(x)
x=tf.keras.applications.mobilenet_v2.preprocess_input(x)
x=base(x,training=False)
x=tf.keras.layers.GlobalAveragePooling2D()(x)
x=tf.keras.layers.Dropout(.25)(x)
out=tf.keras.layers.Dense(1,activation="sigmoid")(x)
model=tf.keras.Model(inp,out)
model.compile(optimizer="adam",loss="binary_crossentropy",metrics=["accuracy"])
model.fit(train,validation_data=val,epochs=10)
model.save(OUT)
print("Saved:",OUT)
