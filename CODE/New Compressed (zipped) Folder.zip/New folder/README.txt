SKINCHECK AI COMPLETE PROJECT

1. Install Python 3.10 or 3.11.
2. Open this folder in VS Code.
3. Terminal:
   pip install -r requirements.txt

4. Put your labelled dataset into:
   dataset/benign/
   dataset/malignant/

5. Train:
   python train.py

6. Run:
   python app.py

7. Browser:
   http://127.0.0.1:5000

Pages: Home, Upload, Prediction Result, Workflow, About.
The result includes class, confidence and Grad-CAM style heatmap after training.

This is a college research prototype, not a medical diagnosis.
