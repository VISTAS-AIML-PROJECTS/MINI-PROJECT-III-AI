import os
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from predict import SkinCancerPredictor

BASE=os.path.dirname(os.path.abspath(__file__))
UPLOAD=os.path.join(BASE,"static","uploads")
os.makedirs(UPLOAD,exist_ok=True)
app=Flask(__name__)
app.secret_key="skincheck"
predictor=SkinCancerPredictor()

def allowed(f): return "." in f and f.rsplit(".",1)[1].lower() in {"jpg","jpeg","png"}

@app.route("/")
def home(): return render_template("index.html")

@app.route("/predict",methods=["GET","POST"])
def predict_page():
    if request.method=="GET": return render_template("upload.html")
    if "image" not in request.files or not request.files["image"].filename:
        flash("Please select an image."); return redirect(url_for("predict_page"))
    f=request.files["image"]
    if not allowed(f.filename):
        flash("Only JPG, JPEG and PNG are supported."); return redirect(url_for("predict_page"))
    name=secure_filename(f.filename); path=os.path.join(UPLOAD,name); f.save(path)
    result=predictor.predict(path)
    return render_template("result.html",image=url_for("static",filename="uploads/"+name),result=result)

@app.route("/about")
def about(): return render_template("about.html")

@app.route("/workflow")
def workflow(): return render_template("workflow.html")

if __name__=="__main__": app.run(debug=True)
