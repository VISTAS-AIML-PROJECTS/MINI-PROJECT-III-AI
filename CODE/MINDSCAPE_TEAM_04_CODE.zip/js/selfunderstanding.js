const SelfUnderstanding = {
  PROMPTS: [
    "What is one thing that took energy from you today, and one thing that gave you energy?",
    "What would you say to a friend who felt the way you feel right now?",
    "What is something you are avoiding, and what is the smallest first step?",
    "Which of your values did you act on this week?",
    "What are you telling yourself about a current challenge? Is it fully true?",
    "When did you feel most like yourself recently?",
    "What do you need more of in your life right now? What do you need less of?",
    "What is something you did well lately that you haven't given yourself credit for?",
    "What emotion has been showing up most this week, and what might it be pointing to?",
    "What boundary would make your days easier?",
    "Who made you feel supported recently, and how could you thank them?",
    "What would a good day look like for you tomorrow?"
  ],
  FEELINGS: ["Anxious", "Sad", "Angry", "Guilty", "Ashamed", "Overwhelmed", "Frustrated", "Lonely", "Hopeful", "Calm", "Other"],

  todayPrompt() {
    const n = Number(Utils.dateKey().replace(/-/g, ""));
    return this.PROMPTS[n % this.PROMPTS.length];
  },

  render() {
    return `
      <h1>🧠 Self-Understanding</h1>
      <div class="card">
        <h3>Reflection of the day</h3>
        <p class="quote">${Utils.escape(this.todayPrompt())}</p>
        <textarea id="su-ref-text" rows="4" placeholder="Take your time. There are no wrong answers."></textarea>
        <button class="btn" id="su-ref-save">Save reflection</button>
      </div>

      <div class="card">
        <h3>Thought record</h3>
        <p class="sub">A self-help exercise for examining a difficult thought. It is not therapy.</p>
        <label class="field">What happened? (the situation)
          <textarea id="tr-situation" rows="2"></textarea></label>
        <label class="field">What went through your mind? (the thought)
          <textarea id="tr-thought" rows="2"></textarea></label>
        <div class="row">
          <label class="field grow">Main feeling
            <select id="tr-feeling">${this.FEELINGS.map(f => `<option>${f}</option>`).join("")}</select></label>
          <label class="field grow">Intensity: <b id="tr-int-val">5</b>/10
            <input type="range" id="tr-intensity" min="0" max="10" value="5"></label>
        </div>
        <label class="field">Evidence that supports the thought
          <textarea id="tr-for" rows="2"></textarea></label>
        <label class="field">Evidence against it, or another way to see it
          <textarea id="tr-against" rows="2"></textarea></label>
        <label class="field">A more balanced thought
          <textarea id="tr-balanced" rows="2"></textarea></label>
        <button class="btn" id="tr-save">Save thought record</button>
        <p id="tr-msg" class="msg"></p>
      </div>

      <div class="card">
        <h3>Your thought records</h3>
        <div id="tr-list"></div>
      </div>
      <div class="card">
        <h3>Your reflections</h3>
        <div id="ref-list"></div>
      </div>`;
  },

  init() {
    document.getElementById("tr-intensity").addEventListener("input", e => {
      document.getElementById("tr-int-val").textContent = e.target.value;
    });
    document.getElementById("su-ref-save").addEventListener("click", () => {
      const text = document.getElementById("su-ref-text").value.trim();
      if (!text) return Utils.toast("Write your reflection first.");
      Storage.save("reflections", { prompt: this.todayPrompt(), text, dateKey: Utils.dateKey() });
      Companion.react("self-understanding", `Question: ${this.todayPrompt()} My answer: ${text}`, "Respond to their actual answer with understanding, and ask one gentle follow-up question.");
      document.getElementById("su-ref-text").value = "";
      this.renderLists();
      Companion.react("self-understanding", text, "They just answered this reflection prompt: \"" + this.todayPrompt() + "\". Respond to what they personally wrote, gently, like a friend who really listened.");
      Utils.toast("Reflection saved ✔");
    });
    document.getElementById("tr-save").addEventListener("click", () => this.saveRecord());
    document.getElementById("tr-list").addEventListener("click", e => this.handleDelete(e, "thoughts"));
    document.getElementById("ref-list").addEventListener("click", e => this.handleDelete(e, "reflections"));
    this.renderLists();
  },

  handleDelete(e, key) {
    const btn = e.target.closest("button[data-id]");
    if (btn && confirm("Delete this item?")) {
      Storage.remove(key, Number(btn.dataset.id));
      this.renderLists();
    }
  },

  saveRecord() {
    const v = id => document.getElementById(id).value.trim();
    const rec = {
      situation: v("tr-situation"), thought: v("tr-thought"),
      feeling: v("tr-feeling"), intensity: Number(v("tr-intensity")),
      evidenceFor: v("tr-for"), evidenceAgainst: v("tr-against"), balanced: v("tr-balanced")
    };
    const msg = document.getElementById("tr-msg");
    if (!rec.situation || !rec.thought) { msg.textContent = "Fill in at least the situation and the thought."; msg.classList.add("error"); return; }
    msg.classList.remove("error");
    Storage.save("thoughts", rec);
    Companion.react("self-understanding", `Situation: ${rec.situation || ""} Thought: ${rec.thought || ""}`, "Respond kindly to this specific situation and thought. This is self-help, not therapy.");
    ["tr-situation", "tr-thought", "tr-for", "tr-against", "tr-balanced"].forEach(i => { document.getElementById(i).value = ""; });
    this.renderLists();
    Utils.toast("Thought record saved ✔");
    Companion.react("self-understanding", `Situation: ${rec.situation}. Thought: ${rec.thought}. Balanced view: ${rec.balanced || "not written yet"}.`, "This is a thought-record exercise, not therapy. Gently affirm the balanced perspective they found, or if they left it blank, encourage them to try finishing that part.");
  },

  renderLists() {
    const thoughts = Storage.get("thoughts").slice().reverse();
    document.getElementById("tr-list").innerHTML = thoughts.length ? thoughts.map(t => `
      <div class="entry">
        <div class="entry-head"><strong>${Utils.escape(t.feeling)} (${t.intensity}/10)</strong><small>${new Date(t.date).toLocaleDateString()}</small></div>
        <p><b>Situation:</b> ${Utils.escape(t.situation)}</p>
        <p><b>Thought:</b> ${Utils.escape(t.thought)}</p>
        ${t.evidenceFor ? `<p><b>For:</b> ${Utils.escape(t.evidenceFor)}</p>` : ""}
        ${t.evidenceAgainst ? `<p><b>Against:</b> ${Utils.escape(t.evidenceAgainst)}</p>` : ""}
        ${t.balanced ? `<p><b>Balanced thought:</b> ${Utils.escape(t.balanced)}</p>` : ""}
        <div class="entry-actions"><button class="btn-small danger" data-id="${t.id}">Delete</button></div>
      </div>`).join("") : `<p class="empty">No thought records yet.</p>`;

    const refs = Storage.get("reflections").slice().reverse();
    document.getElementById("ref-list").innerHTML = refs.length ? refs.map(r => `
      <div class="entry">
        <div class="entry-head"><strong>${Utils.longDate(r.dateKey)}</strong></div>
        <p class="sub">${Utils.escape(r.prompt)}</p>
        <p>${Utils.escape(r.text).replace(/\n/g, "<br>")}</p>
        <div class="entry-actions"><button class="btn-small danger" data-id="${r.id}">Delete</button></div>
      </div>`).join("") : `<p class="empty">No reflections yet.</p>`;
  }
};
