const Achievements = {
  BADGES: [
    { icon: "📝", name: "First Words", desc: "Write your first journal entry", target: 1, get: () => Storage.get("journal").length },
    { icon: "✍️", name: "Storyteller", desc: "Write 10 journal entries", target: 10, get: () => Storage.get("journal").length },
    { icon: "📚", name: "Chronicler", desc: "Write 30 journal entries", target: 30, get: () => Storage.get("journal").length },
    { icon: "😊", name: "Mood Mapper", desc: "Log your mood on 7 different days", target: 7, get: () => new Set(Data.allMoods().map(m => m.dateKey)).size },
    { icon: "🙏", name: "Grateful Heart", desc: "Save 3 gratitude entries", target: 3, get: () => Storage.get("gratitude").length },
    { icon: "🌻", name: "Thankful Fortnight", desc: "Save 14 gratitude entries", target: 14, get: () => Storage.get("gratitude").length },
    { icon: "🌱", name: "Seed Planted", desc: "Create your first habit", target: 1, get: () => Storage.get("habits").length },
    { icon: "🔥", name: "On Fire", desc: "Reach a 7-day habit streak", target: 7, get: () => Data.bestStreak() },
    { icon: "✅", name: "Task Master", desc: "Complete 10 tasks", target: 10, get: () => Storage.get("tasks").filter(t => t.done).length },
    { icon: "⏱️", name: "Deep Focus", desc: "Finish 5 focus sessions", target: 5, get: () => Storage.get("focus").length },
    { icon: "🧠", name: "Self-Aware", desc: "Complete a thought record", target: 1, get: () => Storage.get("thoughts").length },
    { icon: "🖼️", name: "Visionary", desc: "Add 3 items to your vision board", target: 3, get: () => Storage.get("vision").length },
    { icon: "⚖️", name: "Balanced", desc: "Save your Life Balance Wheel", target: 1, get: () => (Storage.getObject("balance", {}).saved ? 1 : 0) },
    { icon: "🌿", name: "Calm Moment", desc: "Complete a grounding exercise", target: 1, get: () => Storage.get("grounding_log").length },
    { icon: "✨", name: "Curious Mind", desc: "Try an AI reflection", target: 1, get: () => Storage.get("ai_log").length }
  ],

  status() {
    return this.BADGES.map(b => {
      const cur = b.get();
      return { ...b, cur: Math.min(cur, b.target), earned: cur >= b.target };
    });
  },

  earnedCount() { return this.status().filter(b => b.earned).length; },

  init() {
    const fresh = this.checkNew();
    if (fresh.length) Companion.react("achievements", `I just earned the badge "${fresh[0].name}": ${fresh[0].desc}.`, "Celebrate this specific badge by name, like real good news.");
  },

  checkNew() {
    const seen = new Set(Storage.get("_badges_seen").map(x => x.name));
    const earnedNow = this.status().filter(b => b.earned);
    const fresh = earnedNow.filter(b => !seen.has(b.name));
    fresh.forEach(b => Storage.save("_badges_seen", { name: b.name }));
    return fresh;
  },

  render() {
    const list = this.status();
    const earned = list.filter(b => b.earned).length;
    return `
      <h1>🏆 Achievements</h1>
      <p class="sub">${earned} of ${list.length} badges earned</p>
      <div class="badges">
        ${list.map(b => `
          <div class="badge ${b.earned ? "earned" : ""}">
            <div class="badge-icon">${b.icon}</div>
            <strong>${Utils.escape(b.name)}</strong>
            <p>${Utils.escape(b.desc)}</p>
            <div class="bar"><div class="bar-fill" style="width:${(b.cur / b.target) * 100}%"></div></div>
            <small>${b.earned ? "Earned" : `${b.cur} / ${b.target}`}</small>
          </div>`).join("")}
      </div>`;
  }
};
