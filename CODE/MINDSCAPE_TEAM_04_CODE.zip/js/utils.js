const MOODS = [
  { emoji: "😄", label: "Happy",   score: 5 },
  { emoji: "😌", label: "Calm",    score: 4 },
  { emoji: "😐", label: "Neutral", score: 3 },
  { emoji: "😟", label: "Anxious", score: 2 },
  { emoji: "😔", label: "Sad",     score: 1 },
  { emoji: "😠", label: "Angry",   score: 1 }
];

const MOOD_COLORS = { 5: "#8fd694", 4: "#bfe39a", 3: "#f2e48b", 2: "#f6bf80", 1: "#ee9a9a" };

const HELP = {
  lines: [
    { name: "Tele-MANAS (India, free, 24x7)", number: "14416" },
    { name: "Emergency services (India)", number: "112" }
  ],
  note: "If you are outside India, find a local helpline at findahelpline.com. Please verify these numbers before relying on them."
};

const WISDOM = [
  { text: "This too shall pass.", by: "Proverb" },
  { text: "A journey of a thousand miles begins with a single step.", by: "Lao Tzu" },
  { text: "You can't pour from an empty cup. Take care of yourself first.", by: "Saying" },
  { text: "Feelings are visitors. Let them come and go without moving in.", by: "Reflection" },
  { text: "Small steps every day add up to big change.", by: "Reflection" },
  { text: "The best time to plant a tree was twenty years ago. The second best time is now.", by: "Proverb" },
  { text: "You do not have to be perfect to make progress.", by: "Reflection" },
  { text: "Rest is part of the work, not a reward for finishing it.", by: "Reflection" },
  { text: "Be gentle with yourself. You are learning as you go.", by: "Reflection" },
  { text: "Even the longest night ends with a sunrise.", by: "Saying" },
  { text: "Notice what is going well, even if it is small.", by: "Reflection" },
  { text: "Asking for help is a sign of strength, not weakness.", by: "Reflection" }
];

const Utils = {
  escape(str) {
    return String(str ?? "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  },

  dateKey(date = new Date()) {
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  },

  greeting() {
    const h = new Date().getHours();
    return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
  },

  moodObj(label) { return MOODS.find(m => m.label === label) || null; },

  lastDays(n) {
    const out = [];
    for (let i = n - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      out.push(this.dateKey(d));
    }
    return out;
  },

  shortDate(key) { const [, m, d] = key.split("-"); return `${d}/${m}`; },

  longDate(key) {
    const [y, m, d] = key.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  },

  quoteOfDay() {
    return WISDOM[Number(this.dateKey().replace(/-/g, "")) % WISDOM.length];
  },

  download(filename, text) {
    const blob = new Blob([text], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  },

  toast(msg) {
    const t = document.createElement("div");
    t.className = "toast";
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }
};

// Shared data helpers: moods (journal + quick check-ins) and habit streaks
const Data = {
  allMoods() {
    const fromJournal = Storage.get("journal").filter(e => e.mood)
      .map(e => ({ dateKey: Utils.dateKey(e.date), mood: e.mood, ts: new Date(e.date).getTime() }));
    const fromQuick = Storage.get("moods")
      .map(e => ({ dateKey: e.dateKey, mood: e.mood, ts: new Date(e.date).getTime() }));
    return fromJournal.concat(fromQuick)
      .map(m => ({ ...m, score: (Utils.moodObj(m.mood) || { score: 3 }).score }))
      .sort((a, b) => a.ts - b.ts);
  },

  moodOn(key) {
    const list = this.allMoods().filter(m => m.dateKey === key);
    return list.length ? list[list.length - 1] : null;
  },

  avgOn(key) {
    const list = this.allMoods().filter(m => m.dateKey === key);
    return list.length ? list.reduce((s, m) => s + m.score, 0) / list.length : null;
  },

  streakOf(daySet) {
    const d = new Date();
    if (!daySet.has(Utils.dateKey(d))) d.setDate(d.getDate() - 1);
    let n = 0;
    while (daySet.has(Utils.dateKey(d))) { n++; d.setDate(d.getDate() - 1); }
    return n;
  },

  doneDays() {
    const s = new Set();
    Storage.get("habits").forEach(h => (h.log || []).forEach(d => s.add(d)));
    return s;
  },

  // Current streak across all habits (null if there are no habits yet)
  streak() {
    if (!Storage.get("habits").length) return null;
    return this.streakOf(this.doneDays());
  },

  bestStreak() {
    const days = [...this.doneDays()].sort();
    let best = 0, run = 0, prev = null;
    days.forEach(k => {
      if (prev) {
        const p = new Date(prev + "T12:00:00");
        p.setDate(p.getDate() + 1);
        run = Utils.dateKey(p) === k ? run + 1 : 1;
      } else run = 1;
      best = Math.max(best, run);
      prev = k;
    });
    return best;
  }
};

// Voice input (Web Speech API) and output (SpeechSynthesis)
const Voice = {
  recSupported: ("SpeechRecognition" in window) || ("webkitSpeechRecognition" in window),
  ttsSupported: "speechSynthesis" in window,
  rec: null,

  wanted: false,

  // opts: { lang, onFinal(text), onInterim(text), onError(code), onEnd() }
  // Keeps listening through pauses (browsers stop on silence) until stop() is called.
  listen(opts = {}) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return false;
    this.stop();
    this.wanted = true;
    const begin = () => {
      const r = new SR();
      r.lang = opts.lang || navigator.language || "en-US";
      r.interimResults = true;
      r.continuous = true;
      r.onresult = ev => {
        let interim = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const t = ev.results[i][0].transcript;
          if (ev.results[i].isFinal) { if (opts.onFinal) opts.onFinal(t); } else interim += t;
        }
        if (opts.onInterim) opts.onInterim(interim);
      };
      r.onerror = ev => {
        if (ev.error === "no-speech" || ev.error === "aborted") return; // normal during pauses
        this.wanted = false;
        if (opts.onError) opts.onError(ev.error);
      };
      r.onend = () => {
        if (this.rec !== r) return; // a newer session replaced this one
        this.rec = null;
        if (this.wanted) {
          try { begin(); return; } catch { this.wanted = false; }
        }
        if (opts.onInterim) opts.onInterim("");
        if (opts.onEnd) opts.onEnd();
      };
      this.rec = r;
      r.start();
    };
    try { begin(); } catch { this.wanted = false; this.rec = null; return false; }
    return true;
  },

  stop() {
    this.wanted = false;
    if (this.rec) { try { this.rec.stop(); } catch {} }
  },

  // Browsers do not say whether a voice is male or female, so we recognise common names
  MALE_VOICE: /\b(male|man|ravi|hemant|prabhat|rishi|valluvar|mohan|midhun|guy|david|mark|james|daniel|george|ryan|thomas|alex|fred|aaron|arthur|oliver|rishabh|madhur)\b/i,
  FEMALE_VOICE: /\b(female|woman|heera|kalpana|swara|pallavi|shruti|sobhana|veena|neerja|zira|samantha|susan|karen|moira|tessa|fiona|victoria|hazel|aria|jenny|lekha|priya|aditi|kanya|sangeeta)\b/i,

  voiceFor(lang, gender) {
    if (!this.ttsSupported || !lang) return null;
    const base = lang.split("-")[0].toLowerCase();
    const voices = speechSynthesis.getVoices();
    const norm = v => v.lang.replace("_", "-").toLowerCase();
    const exact = voices.filter(v => norm(v) === lang.toLowerCase());
    const sameLang = voices.filter(v => norm(v).split("-")[0] === base);
    const pools = [exact, sameLang];
    if (gender) {
      const want = gender === "male" ? this.MALE_VOICE : this.FEMALE_VOICE, avoid = gender === "male" ? this.FEMALE_VOICE : this.MALE_VOICE;
      for (const pool of pools) { const hit = pool.find(v => want.test(v.name) && !avoid.test(v.name)); if (hit) return hit; }
      for (const pool of pools) { const ok = pool.find(v => !avoid.test(v.name)); if (ok) return ok; }   // at least not the opposite gender
    }
    return exact[0] || sameLang[0] || null;
  },

  // True only when the device has a voice built specifically for this language.
  // Absence does not mean MindScape stays silent -- speak() still tries, using
  // whatever default voice the browser has, which can often read the text anyway.
  hasVoice(lang) {
    if (!this.ttsSupported || !lang) return false;
    return !!this.voiceFor(lang);
  },


  speak(text, lang, cb = {}) {
    if (!this.ttsSupported || !text) { if (cb.onend) cb.onend(); return; }
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    if (lang) {
      u.lang = lang;
      const v = this.voiceFor(lang, cb.gender);
      try { if (v) u.voice = v; } catch (e) { /* ignore: fall back to the default voice for this language */ }
    }
    // Pitch always follows the character, so a male and a female character never sound alike even on a one-voice device
    if (cb.gender === "male") { u.pitch = 0.75; u.rate = 0.97; }
    else if (cb.gender === "female") { u.pitch = 1.25; u.rate = 1.0; }
    if (cb.onstart) u.onstart = cb.onstart;
    let fired = false;
    const done = ok => { if (fired) return; fired = true; if (cb.onend) cb.onend(ok); };
    u.onend = () => done(true);
    u.onerror = () => done(false);
    speechSynthesis.speak(u);
    // Some browsers silently drop utterances in an unsupported language instead of firing onerror.
    // If neither onstart nor onend/onerror fires within 2.5s, treat it as a failed attempt.
    setTimeout(() => { if (!fired && !speechSynthesis.speaking && !speechSynthesis.pending) done(false); }, 2500);
  },

  silence() {
    if (this.ttsSupported) speechSynthesis.cancel();
  }
};

if ("speechSynthesis" in window) { speechSynthesis.getVoices(); speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices(); }
