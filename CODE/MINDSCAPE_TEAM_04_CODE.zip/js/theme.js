// Theme: "system" (default), "light" or "dark". Applied before first paint via index.html.
const Theme = {
  KEY: "theme",
  get() { return localStorage.getItem(this.KEY) || "system"; },
  apply(mode = this.get()) {
    const dark = mode === "dark" || (mode === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.dataset.theme = dark ? "dark" : "light";
  },
  set(mode) {
    localStorage.setItem(this.KEY, mode);
    this.apply(mode);
  }
};
matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => Theme.apply());
Theme.apply();
