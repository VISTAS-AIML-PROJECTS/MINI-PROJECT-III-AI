const Auth = {
  KEY: "profile",

  getProfile() { return Storage.getObject(this.KEY, null); },
  isUnlocked() { return sessionStorage.getItem("unlocked") === "1"; },
  validPin(pin) { return /^\d{4,6}$/.test(pin); },

  // Legacy format: plain SHA-256 (fast to brute-force). Kept only to verify old PINs and upgrade them.
  async legacyHash(pin) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("mindscape:" + pin));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
  },

  // Current format: "pbkdf2$<iterations>$<salt hex>$<hash hex>" with a random per-profile salt
  async hashPin(pin, saltHex, iters = 200000) {
    const toHex = bytes => Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");
    const salt = saltHex ? Uint8Array.from(saltHex.match(/../g).map(h => parseInt(h, 16))) : crypto.getRandomValues(new Uint8Array(16));
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: iters, hash: "SHA-256" }, key, 256);
    return `pbkdf2$${iters}$${toHex(salt)}$${toHex(new Uint8Array(bits))}`;
  },

  async verifyPin(pin, profile) {
    const stored = profile.pinHash || "";
    if (stored.startsWith("pbkdf2$")) {
      const [, iters, salt] = stored.split("$");
      return (await this.hashPin(pin, salt, Number(iters))) === stored;
    }
    if ((await this.legacyHash(pin)) !== stored) return false;
    Storage.setObject(this.KEY, { ...profile, pinHash: await this.hashPin(pin) }); // silently upgrade old PIN
    return true;
  },

  init(onReady) {
    this.onReady = onReady;
    const profile = this.getProfile();
    if (!profile) this.showSetup();
    else if (profile.pinHash && !this.isUnlocked()) this.showUnlock(profile);
    else this.enter();
  },

  enter() {
    sessionStorage.setItem("unlocked", "1");
    document.body.classList.add("authed");
    this.onReady();
  },

  lock() {
    sessionStorage.removeItem("unlocked");
    location.reload();
  },

  authError(text) { document.getElementById("auth-msg").textContent = text; },

  onEnter(handler) {
    document.querySelector(".auth-card").addEventListener("keydown", e => { if (e.key === "Enter") handler(); });
  },

  wipe() {
    localStorage.clear();
    sessionStorage.clear();
    location.hash = "";
    location.reload();
  },

  showSetup() {
    document.getElementById("auth").innerHTML = `
      <div class="auth-card">
        <h1>🌿 MindScape</h1>
        <p class="sub">Create your private profile. Everything stays in this browser.</p>
        <input type="text" id="auth-name" placeholder="Your name" maxlength="30">
        <input type="password" id="auth-pin" placeholder="PIN (optional, 4-6 digits)" inputmode="numeric" maxlength="6">
        <input type="password" id="auth-pin2" placeholder="Confirm PIN" inputmode="numeric" maxlength="6">
        <button class="btn" id="auth-go">Get started</button>
        <p class="msg error" id="auth-msg"></p>
        <p class="note">The PIN is a simple privacy lock on this device, not secure authentication.</p>
      </div>`;

    const submit = async () => {
      const name = document.getElementById("auth-name").value.trim();
      const pin = document.getElementById("auth-pin").value;
      const pin2 = document.getElementById("auth-pin2").value;
      if (!name) return this.authError("Please enter your name.");
      let pinHash = null;
      if (pin) {
        if (!this.validPin(pin)) return this.authError("PIN must be 4-6 digits.");
        if (pin !== pin2) return this.authError("PINs do not match.");
        pinHash = await this.hashPin(pin);
      }
      Storage.setObject(this.KEY, { name, pinHash, created: new Date().toISOString() });
      this.enter();
    };
    document.getElementById("auth-go").addEventListener("click", submit);
    this.onEnter(submit);
  },

  showUnlock(profile) {
    document.getElementById("auth").innerHTML = `
      <div class="auth-card">
        <h1>Welcome back, ${Utils.escape(profile.name)}</h1>
        <p class="sub">Enter your PIN to open MindScape.</p>
        <input type="password" id="auth-pin" placeholder="PIN" inputmode="numeric" maxlength="6">
        <button class="btn" id="auth-go">Unlock</button>
        <p class="msg error" id="auth-msg"></p>
        <button class="link-btn" id="auth-forgot">Forgot PIN? Erase data and start over</button>
      </div>`;

    const submit = async () => {
      if (await this.verifyPin(document.getElementById("auth-pin").value, profile)) this.enter();
      else this.authError("Incorrect PIN.");
    };
    document.getElementById("auth-go").addEventListener("click", submit);
    document.getElementById("auth-pin").focus();
    this.onEnter(submit);
    document.getElementById("auth-forgot").addEventListener("click", () => {
      if (confirm("This erases ALL MindScape data on this browser. Continue?")) this.wipe();
    });
  },

  // ---------- Settings page ----------
  renderSettings() {
    const p = this.getProfile();
    const ai = Storage.getObject("ai_settings", {});
    return `
      <h1>⚙️ Settings</h1>
      <div class="card">
        <h3>Profile</h3>
        <input type="text" id="set-name" value="${Utils.escape(p.name)}" maxlength="30">
        <button class="btn" id="set-name-save">Save name</button>
      </div>
      <div class="card">
        <h3>Appearance</h3>
        <select id="set-theme">
          ${[["system", "Match my device"], ["light", "Light"], ["dark", "Dark"]].map(([v, l]) => `<option value="${v}" ${Theme.get() === v ? "selected" : ""}>${l}</option>`).join("")}
        </select>
      </div>
      <div class="card">
        <h3>PIN lock</h3>
        <p>${p.pinHash ? "A PIN is set." : "No PIN is set."}</p>
        <input type="password" id="set-pin" placeholder="New PIN (4-6 digits)" inputmode="numeric" maxlength="6">
        <button class="btn" id="set-pin-save">${p.pinHash ? "Change PIN" : "Set PIN"}</button>
        ${p.pinHash ? '<button class="btn btn-secondary" id="set-pin-remove">Remove PIN</button>' : ""}
      </div>
      <div class="card">
        <h3>Companion</h3>
        ${Auth.companionCard()}
      </div>
      <div class="card">
        <h3>AI reflection</h3>
        <p class="note">AI Reflection uses the same AI key as your companion. Add or test it above, under Companion → AI key. Without a key, AI Reflection uses a simple offline reply.</p>
      </div>
      <div class="card">
        <h3>Backup</h3>
        <p>Export all your data to a file, or restore it from a backup.</p>
        <button class="btn" id="set-export">Export data</button>
        <input type="file" id="set-import-file" accept=".json,application/json" hidden>
        <button class="btn btn-secondary" id="set-import">Import data</button>
      </div>
      <div class="card">
        <h3>Erase</h3>
        <p>Erase everything MindScape has stored in this browser.</p>
        <button class="btn danger-btn" id="set-erase">Erase all data</button>
      </div>
      <p id="set-msg" class="msg"></p>`;
  },

  settingsMsg(text, isError = false) {
    const el = document.getElementById("set-msg");
    if (!el) return;
    el.textContent = text;
    el.classList.toggle("error", isError);
  },

  companionCard() {
    const c = Companion.get();
    if (!c || !c.enabled) {
      return `
        <p class="note">A small on-screen companion that checks in when you log your mood, and chats with you by text or voice.</p>
        <div class="row">${Object.entries(Avatar.CHARS).map(([k, ch]) => `<button type="button" class="avatar-pick" data-avatar="${k}"><span class="avatar-thumb">${Avatar.svg(k, true)}</span><br>${ch.name}</button>`).join("")}</div>
        <p id="companion-setup-msg" class="msg"></p>`;
    }
    const current = Avatar.CHARS[c.avatar] || Avatar.CHARS.kai;
    return `
      <p><b>${current.name}</b> is active, in the ${c.corner} corner.</p>
      <label class="field">Favorite way to talk
        <select id="cset-style">
          <option value="story">📖 Stories</option>
          <option value="song">🎵 Songs</option>
          <option value="sports">🏅 Sports talk</option>
          <option value="quote">💬 Short thoughts</option>
        </select>
      </label>
      <label class="field">Language
        <select id="cset-lang">${Companion.LANGS.map(([code, name]) => `<option value="${code}">${name}</option>`).join("")}</select>
      </label>
      <label class="field">Corner
        <select id="cset-corner"><option value="right">Right</option><option value="left">Left</option></select>
      </label>
      <div class="row"><button type="button" class="btn btn-secondary" id="cset-demo">▶ Show me what my character can do</button></div>
      <label><input type="checkbox" id="cset-calm"> Calm motion (less movement)</label>
      <p class="note" id="cset-motion-note"></p>
      <label class="field">Character look
        <select id="cset-look"><option value="photo">Your exact pictures, cut into moving pieces (head, eyes, mouth)</option><option value="drawn">Drawn full-body cartoon (arms and legs move)</option></select>
      </label>
      <label><input type="checkbox" id="cset-voice"> Speak replies out loud</label>
      <label><input type="checkbox" id="cset-guide"> Guide me on every page (needs your AI key)</label>
      <h4>🔑 AI key (makes every story and reply brand new)</h4>
      <p class="note">Without a key the companion can only reuse a small set of built-in lines, which repeat. With a key every story and reply is written fresh. Two kinds work: a <b>free Google Gemini key</b> (starts with <b>AIza</b>, get it at aistudio.google.com/apikey) or an <b>Anthropic key</b> (starts with <b>sk-ant-</b>, paid, console.anthropic.com). The key stays in this browser only. Note: on Google's free tier, what you send may be used by Google to improve its products, so avoid very private details.</p>
      <input type="password" id="cset-key" placeholder="Paste your AI key here (AIza… for Gemini or sk-ant-… for Anthropic)" autocomplete="off">
      <div class="row"><button type="button" class="btn btn-secondary" id="cset-testkey">Test key</button></div>
      <h4>📚 My sources</h4>
      <p class="note">Add your own teachings, book notes or quotes. The companion will use them to guide its answers and stories, and says where an idea comes from. Stored in this browser; the few passages that fit each message are sent to the AI with it.</p>
      <input type="text" id="cset-src-name" placeholder="Name of the source (for example: My notes, Tirukural, Mom's advice)">
      <textarea id="cset-src-text" rows="5" placeholder="Paste text here. Separate passages with a blank line."></textarea>
      <div class="row"><button type="button" class="btn btn-secondary" id="cset-src-add">Add this source</button>
      <label class="btn btn-secondary" style="cursor:pointer">Add Word, PDF, text or subtitle files<input type="file" id="cset-src-file" accept=".docx,.pdf,.txt,.md,.srt,.vtt,application/pdf,text/plain" multiple hidden></label></div>
      <div class="row" style="gap:8px;align-items:center"><input type="text" id="cset-src-url" placeholder="Or paste a web link: a page, PDF or Word file" style="flex:1;min-width:200px"><button type="button" class="btn btn-secondary" id="cset-src-url-add">Add link</button></div>
      <div id="cset-src-yt" hidden style="border:1px solid var(--line);border-radius:12px;padding:10px;margin:8px 0">
        <b>🎬 YouTube video</b> <span class="note" id="cset-src-yt-id"></span>
        <p class="note">A browser app cannot read a video's words from the link, so paste the transcript: 1) open the video on YouTube; 2) tap <b>…more</b> under the video and press <b>Show transcript</b>; 3) select all the transcript text and copy it; 4) paste it here. (Videos without captions have no transcript.)</p>
        <textarea id="cset-src-yt-text" rows="5" placeholder="Paste the transcript here"></textarea>
        <div class="row"><button type="button" class="btn btn-secondary" id="cset-src-yt-add">Add video transcript</button></div>
      </div>
      <p class="note">Links work only when the website allows apps to read it. If one is refused, copy the page text and paste it above, or save the page as a PDF and add the file.</p>
      <p class="note" id="cset-src-status"></p>
      <div id="cset-src-list"></div>
      <h4>🔊 Voice check</h4>
      <p class="note">Spoken replies use voices installed on this device. A ✗ means this device has no voice for that language, so the text shows but nothing can be heard.</p>
      <div id="voice-check"></div>
      <p class="note">Android phones: install the language in Google's Speech Services. Windows: the Edge browser usually has natural Hindi, Tamil, Telugu and Malayalam voices. Computers' Chrome often has none for Tamil, Telugu or Malayalam.</p>
      <div class="row">
        <button class="btn" id="cset-save">Save</button>
        <button class="btn btn-secondary" id="cset-change-avatar">Change character</button>
        <button class="btn btn-secondary" id="cset-refresh">Refresh app (get newest version)</button>
        <button class="btn btn-secondary" id="cset-off">Turn off companion</button>
      </div>`;
  },

  initCompanionCard() {
    const c = Companion.get();
    document.querySelectorAll(".avatar-pick").forEach(b => b.addEventListener("click", () => {
      Companion.setup({ avatar: b.dataset.avatar, style: "story", corner: "right", lang: "en-IN", voiceOn: true });
      Companion.mount();
      router();
    }));
    if (!c || !c.enabled) return;
    const style = document.getElementById("cset-style");
    const lang = document.getElementById("cset-lang");
    const corner = document.getElementById("cset-corner");
    const voice = document.getElementById("cset-voice");
    const guide = document.getElementById("cset-guide");
    if (!style) return;
    guide.checked = c.guideOn !== false;
    document.getElementById("cset-look").value = Avatar.look();
    document.getElementById("cset-calm").checked = !!c.calm;
    document.getElementById("cset-motion-note").textContent = (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) ? "Your device has \"reduce motion\" switched on. MindScape ignores that for your character so it always moves; tick Calm motion if you want less." : "";
    document.getElementById("cset-demo").addEventListener("click", () => { Companion.toggle(true, true); Companion.demoMoves(); });
    document.getElementById("cset-key").value = Storage.getObject("ai_settings", {}).apiKey || "";
    const drawVoices = () => {
      const box = document.getElementById("voice-check");
      if (!box) return;
      box.innerHTML = Companion.voiceReport().map(r => `<div class="voice-row"><span class="vs">${r.voice ? "✓" : "✗"} ${r.name}${r.voice ? " — " + Utils.escape(r.voice.name) : " — no voice found"}</span><button type="button" class="btn-small" data-test="${r.code}">▶ Test</button></div>`).join("");
    };
    drawVoices();
    if (window.speechSynthesis) speechSynthesis.addEventListener("voiceschanged", drawVoices);
    document.getElementById("voice-check").addEventListener("click", e => {
      const b = e.target.closest("[data-test]");
      if (!b) return;
      const code = b.dataset.test;
      Voice.speak(Companion.SAMPLES[code], code, { onend: ok => { if (ok === false) Utils.toast("This device could not speak " + (Companion.LANG_NAMES[code] || code) + "."); } });
    });
    style.value = c.style; lang.value = c.lang || "en-IN"; corner.value = c.corner; voice.checked = c.voiceOn !== false;
    document.getElementById("cset-save").addEventListener("click", () => {
      const btn = document.getElementById("cset-save");
      btn.classList.remove("is-ok", "is-err"); btn.classList.add("is-busy"); btn.disabled = true; const label = btn.textContent; btn.textContent = "Saving…";
      Companion.update({ style: style.value, lang: lang.value, corner: corner.value, voiceOn: voice.checked, guideOn: guide.checked, look: document.getElementById("cset-look").value, lookV3: true, calm: document.getElementById("cset-calm").checked }); Companion.applyCalm();
      { const k = document.getElementById("cset-key").value.trim(); const s = Storage.getObject("ai_settings", {}); if (k !== (s.apiKey || "")) { s.apiKey = k; Storage.setObject("ai_settings", s); } }
      Companion.mount();
      btn.classList.remove("is-busy"); btn.classList.add("is-ok"); btn.textContent = "Saved ✔"; btn.disabled = false;
      setTimeout(() => { btn.classList.remove("is-ok"); btn.textContent = label; }, 2000);
      this.settingsMsg("Companion settings saved ✔");
    });
    const status = m => { const el = document.getElementById("cset-src-status"); if (el) el.textContent = m || ""; };
    const renderSources = () => {
      const items = Companion.sources(), box = document.getElementById("cset-src-list"); if (!box) return;
      const total = items.reduce((n, s) => n + s.text.length, 0);
      box.innerHTML = items.length ? items.map((s, i) => `<div class="row" style="align-items:center;justify-content:space-between;gap:8px;margin-top:6px"><span>${s.url ? "🔗" : "📖"} <b>${Utils.escape(s.name)}</b> · ${s.text.length.toLocaleString()} characters${s.url ? " · " + Utils.escape(s.url.replace(/^https?:\/\//, "").slice(0, 40)) : ""}</span><button type="button" class="btn btn-secondary" data-src-del="${i}">Remove</button></div>`).join("") + `<p class="note">Total saved: ${total.toLocaleString()} characters${Companion._srcFailed ? " (this browser could not keep them after you close it)" : ""}.</p>` : '<p class="note">No sources added yet.</p>';
      box.querySelectorAll("[data-src-del]").forEach(bt => bt.addEventListener("click", async () => { const it = Companion.sources()[+bt.dataset.srcDel]; if (it) await Companion.removeSource(it.id); renderSources(); }));
    };
    const LIMIT = 12000000;
    const addSource = async (name, text, url) => {
      text = String(text || "").trim(); if (!text) return this.settingsMsg("Nothing to add: no text found.");
      if (Companion.sources().reduce((n, x) => n + x.text.length, 0) + text.length > LIMIT) return this.settingsMsg("That is too much text in total (limit 12 million characters). Remove a source first.");
      await Companion.addSource(name, text, url); renderSources();
      this.settingsMsg(`✔ Added "${(name || "My source").slice(0, 40)}" (${text.length.toLocaleString()} characters). The companion will now draw on it.`);
    };
    document.getElementById("cset-src-add").addEventListener("click", async () => {
      await addSource(document.getElementById("cset-src-name").value, document.getElementById("cset-src-text").value);
      document.getElementById("cset-src-text").value = ""; document.getElementById("cset-src-name").value = "";
    });
    document.getElementById("cset-src-file").addEventListener("change", async e => {
      const files = Array.from(e.target.files); e.target.value = "";
      for (const f of files) {
        try {
          status(`Reading ${f.name}…`);
          const text = await SourceImport.read(f, status);
          await addSource(files.length === 1 && document.getElementById("cset-src-name").value || f.name.replace(/\.[^.]+$/, ""), text);
        } catch (err) { this.settingsMsg(`✘ ${f.name}: ${err.message}`); }
      }
      status(""); document.getElementById("cset-src-name").value = "";
    });
    let ytPending = null;
    document.getElementById("cset-src-yt-add").addEventListener("click", async () => {
      const text = SourceImport.cleanTranscript(document.getElementById("cset-src-yt-text").value);
      if (text.length < 40) return this.settingsMsg("Paste the transcript text first.");
      await addSource(document.getElementById("cset-src-name").value || "YouTube video " + (ytPending ? ytPending.id : ""), text, ytPending && ytPending.url);
      document.getElementById("cset-src-yt-text").value = ""; document.getElementById("cset-src-yt").hidden = true; ytPending = null; document.getElementById("cset-src-name").value = "";
    });
    document.getElementById("cset-src-url-add").addEventListener("click", async () => {
      const box = document.getElementById("cset-src-url"), links = box.value.split(/[\s,]+/).filter(Boolean);
      if (!links.length) return this.settingsMsg("Paste a web link first.");
      for (const link of links) {
        try { status("Reading " + link + "…"); const r = await SourceImport.readUrl(link, status); await addSource(document.getElementById("cset-src-name").value || r.name, r.text, link); }
        catch (err) {
          if (err.code === "youtube") { ytPending = { url: err.url, id: err.videoId }; document.getElementById("cset-src-yt").hidden = false; document.getElementById("cset-src-yt-id").textContent = "(" + err.videoId + ")"; document.getElementById("cset-src-yt-text").focus(); this.settingsMsg("That is a YouTube video. Paste its transcript in the box that just opened."); }
          else this.settingsMsg("✘ " + err.message);
        }
      }
      status(""); box.value = ""; document.getElementById("cset-src-name").value = "";
    });
    Companion.loadSources().then(renderSources); renderSources();
    document.getElementById("cset-testkey").addEventListener("click", async () => {
      const btn = document.getElementById("cset-testkey");
      const k = document.getElementById("cset-key").value.replace(/[\s"'`]/g, "");
      if (!k) return this.settingsMsg("Paste your AI key first.");
      btn.classList.remove("is-ok", "is-err"); btn.classList.add("is-busy"); btn.disabled = true; const label = btn.textContent; btn.textContent = "Testing…";
      if (!k.startsWith("sk-ant-") && !k.startsWith("AIza")) this.settingsMsg("This key does not look right. " + AIClient.keyHelp() + " Testing anyway…");
      const s = Storage.getObject("ai_settings", {}); s.apiKey = k; Storage.setObject("ai_settings", s);
      try {
        await Companion.callAI("react", { title: "Key test", text: "hello", prompt: "Reply with the single word: ready" });
        this.settingsMsg("✔ Your key works. The companion can now write fresh replies and stories.");
        btn.classList.remove("is-busy"); btn.classList.add("is-ok"); btn.textContent = "✔ Works";
      } catch (err) {
        this.settingsMsg("✘ " + err.message);
        btn.classList.remove("is-busy"); btn.classList.add("is-err"); btn.textContent = "✘ Failed";
      }
      btn.disabled = false;
      setTimeout(() => { btn.classList.remove("is-ok", "is-err"); btn.textContent = label; }, 3000);
    });
    document.getElementById("cset-refresh").addEventListener("click", async () => {
      try { const regs = await navigator.serviceWorker.getRegistrations(); await Promise.all(regs.map(r => r.unregister())); } catch (e) {}
      try { const keys = await caches.keys(); await Promise.all(keys.map(k => caches.delete(k))); } catch (e) {}
      location.reload();
    });
    document.getElementById("cset-change-avatar").addEventListener("click", () => {
      Companion.disable();
      router();
    });
    document.getElementById("cset-off").addEventListener("click", () => {
      Companion.disable();
      Companion.mount();
      router();
    });
  },

  initSettings() {
    const $ = id => document.getElementById(id);
    this.initCompanionCard();

    $("set-theme").addEventListener("change", e => Theme.set(e.target.value));

    $("set-name-save").addEventListener("click", () => {
      const name = $("set-name").value.trim();
      if (!name) return this.settingsMsg("Name cannot be empty.", true);
      Storage.setObject(this.KEY, { ...this.getProfile(), name });
      buildSidebar();
      this.settingsMsg("Name saved ✔");
    });

    $("set-pin-save").addEventListener("click", async () => {
      const pin = $("set-pin").value;
      if (!this.validPin(pin)) return this.settingsMsg("PIN must be 4-6 digits.", true);
      Storage.setObject(this.KEY, { ...this.getProfile(), pinHash: await this.hashPin(pin) });
      buildSidebar();
      router();
      this.settingsMsg("PIN saved ✔");
    });

    if ($("set-pin-remove")) $("set-pin-remove").addEventListener("click", () => {
      Storage.setObject(this.KEY, { ...this.getProfile(), pinHash: null });
      buildSidebar();
      router();
      this.settingsMsg("PIN removed ✔");
    });

    $("set-export").addEventListener("click", () => {
      Utils.download(`mindscape-backup-${Utils.dateKey()}.json`, Storage.exportAll());
      this.settingsMsg("Backup downloaded ✔");
    });

    $("set-import").addEventListener("click", () => $("set-import-file").click());
    $("set-import-file").addEventListener("change", e => {
      const file = e.target.files[0];
      if (!file) return;
      const fr = new FileReader();
      fr.onload = () => {
        if (!confirm("Importing replaces ALL current data with the backup. Continue?")) return;
        try {
          Storage.importAll(fr.result);
          location.reload();
        } catch (err) {
          this.settingsMsg(err.message || "That file could not be imported.", true);
        }
      };
      fr.readAsText(file);
    });

    $("set-erase").addEventListener("click", () => {
      if (confirm("Erase ALL MindScape data on this browser? This cannot be undone.")) this.wipe();
    });
  }
};
