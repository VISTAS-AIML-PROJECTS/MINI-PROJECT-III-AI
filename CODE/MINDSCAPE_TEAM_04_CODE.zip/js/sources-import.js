// Reads text out of files the user adds under Settings -> Companion -> My sources.
// Supports: Word (.docx), PDF (.pdf), and plain text (.txt, .md). Everything happens in the browser.
const SourceImport = (() => {
  const loadScript = src => new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = () => rej(new Error("Could not load " + src)); document.head.appendChild(s); });

  // ----- .docx: a zip file containing word/document.xml -----
  async function inflateRaw(bytes) {
    if (typeof DecompressionStream === "undefined") throw new Error("This browser cannot open Word files. Please update your browser or paste the text instead.");
    const ds = new DecompressionStream("deflate-raw"), w = ds.writable.getWriter(); w.write(bytes); w.close();
    return new Uint8Array(await new Response(ds.readable).arrayBuffer());
  }
  async function unzipEntry(buf, wanted) {
    const dv = new DataView(buf), u8 = new Uint8Array(buf);
    let e = buf.byteLength - 22; while (e >= 0 && dv.getUint32(e, true) !== 0x06054b50) e--;
    if (e < 0) throw new Error("This does not look like a valid Word (.docx) file.");
    const count = dv.getUint16(e + 10, true); let p = dv.getUint32(e + 16, true);
    for (let i = 0; i < count; i++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true);
      const name = new TextDecoder().decode(u8.subarray(p + 46, p + 46 + nlen));
      if (name === wanted) {
        const lnl = dv.getUint16(off + 26, true), lxl = dv.getUint16(off + 28, true), start = off + 30 + lnl + lxl, data = u8.subarray(start, start + csize);
        return method === 0 ? data : inflateRaw(data);
      }
      p += 46 + nlen + xlen + clen;
    }
    return null;
  }
  async function readDocx(file) {
    const xml = await unzipEntry(await file.arrayBuffer(), "word/document.xml");
    if (!xml) throw new Error("No text found in this Word file (is it an older .doc? Save it as .docx and try again).");
    const doc = new DOMParser().parseFromString(new TextDecoder().decode(xml), "application/xml");
    const paras = [];
    doc.getElementsByTagName("w:p").forEach ? 0 : 0;
    for (const p of Array.from(doc.getElementsByTagName("w:p"))) {
      let t = "";
      for (const n of Array.from(p.getElementsByTagName("*"))) {
        if (n.nodeName === "w:t") t += n.textContent; else if (n.nodeName === "w:tab") t += " "; else if (n.nodeName === "w:br") t += " ";
      }
      t = t.replace(/\s+/g, " ").trim(); if (t) paras.push(t);
    }
    return paras.join("\n");
  }

  // ----- .pdf: text layer via pdf.js (loaded only when needed) -----
  async function readPdf(file, progress) {
    if (!window.pdfjsLib) { await loadScript("assets/lib/pdf.classic.js"); await loadScript("assets/lib/pdf.worker.classic.js"); }
    pdfjsLib.GlobalWorkerOptions.workerSrc = "assets/lib/pdf.worker.classic.js";
    const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false }).promise;
    const out = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i), tc = await page.getTextContent();
      let line = "", lines = [];
      for (const it of tc.items) { line += it.str; if (it.hasEOL) { lines.push(line); line = ""; } else if (it.str && !/\s$/.test(it.str)) line += " "; }
      if (line.trim()) lines.push(line);
      out.push(lines.join(" ").replace(/\s+/g, " ").trim());
      page.cleanup();
      if (progress && (i % 5 === 0 || i === pdf.numPages)) { progress(`Reading page ${i} of ${pdf.numPages}…`); await new Promise(r => setTimeout(r)); }
    }
    const text = out.filter(Boolean).join("\n");
    if (text.length < 20) throw new Error("No readable text found. This PDF may be scanned pictures of pages, which this app cannot read.");
    return text;
  }

  // ----- YouTube: a browser cannot fetch a video's words, so the person pastes the transcript -----
  function parseYouTube(raw) {
    try {
      const u = new URL(/^https?:\/\//i.test(raw) ? raw : "https://" + raw), h = u.hostname.replace(/^(www|m|music)\./, "");
      if (h === "youtu.be") return u.pathname.slice(1).split("/")[0] || null;
      if (h === "youtube.com" || h === "youtube-nocookie.com") {
        if (u.searchParams.get("v")) return u.searchParams.get("v");
        const m = u.pathname.match(/^\/(shorts|embed|live|v)\/([\w-]{6,})/); return m ? m[2] : "video";
      }
    } catch (e) {}
    return null;
  }
  // YouTube's "Show transcript" copies as: 0:05 / words / 0:09 / words ... Remove the timestamps and join the lines
  function cleanTranscript(t) {
    const lines = String(t || "").replace(/\r/g, "").split("\n").map(l => l.trim()).filter(Boolean)
      .filter(l => !/^(\d{1,2}:)?\d{1,2}:\d{2}$/.test(l) && !/^\d+\s*(seconds?|minutes?|hours?)(,\s*\d+\s*seconds?)?$/i.test(l))
      .map(l => l.replace(/^(\d{1,2}:)?\d{1,2}:\d{2}\s+/, ""));
    const out = []; let para = "";
    for (const l of lines) { para += (para ? " " : "") + l; if (para.length > 500 && /[.!?।]$/.test(l)) { out.push(para); para = ""; } }
    if (para) out.push(para);
    return out.join("\n");
  }
  // .srt / .vtt subtitle files: drop cue numbers, times and tags; auto-captions repeat lines, so skip repeats
  function readSubtitles(text) {
    const out = []; let prev = "";
    for (let l of String(text).replace(/\r/g, "").split("\n")) {
      l = l.trim();
      if (!l || /^WEBVTT/i.test(l) || /^NOTE\b/.test(l) || /^\d+$/.test(l) || /-->/.test(l) || /^(Kind|Language):/i.test(l)) continue;
      l = l.replace(/<[^>]+>/g, "").replace(/\{[^}]*\}/g, "").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").trim();
      if (l && l !== prev && !prev.endsWith(l)) { out.push(l); prev = l; }
    }
    return cleanTranscript(out.join(" ").replace(/\s+/g, " ").replace(/([.!?।])\s+/g, "$1\n"));
  }

  // ----- web pages: turn HTML into readable text -----
  function htmlToText(html, baseTitle) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const title = (doc.querySelector("title") || {}).textContent || baseTitle || "";
    doc.querySelectorAll("script, style, noscript, svg, nav, footer, header, aside, form, iframe, button, [aria-hidden=true]").forEach(n => n.remove());
    const root = doc.querySelector("article") || doc.querySelector("main") || doc.body || doc.documentElement;
    const BLOCK = /^(P|DIV|SECTION|ARTICLE|LI|UL|OL|H[1-6]|BR|TR|BLOCKQUOTE|PRE|TABLE|DD|DT)$/;
    let out = "";
    (function walk(n) {
      if (n.nodeType === 3) { out += n.nodeValue.replace(/\s+/g, " "); return; }
      if (n.nodeType !== 1) return;
      const block = BLOCK.test(n.tagName);
      if (block) out += "\n";
      n.childNodes.forEach(walk);
      if (block) out += "\n";
    })(root);
    const text = out.split("\n").map(l => l.replace(/\s+/g, " ").trim()).filter(Boolean).join("\n");
    return { title: title.replace(/\s+/g, " ").trim(), text };
  }

  async function readUrl(raw, progress) {
    let url = String(raw || "").trim(); if (!url) throw new Error("Paste a web link first.");
    if (!/^https?:\/\//i.test(url)) url = "https://" + url;
    let u; try { u = new URL(url); } catch (e) { throw new Error("That does not look like a valid web link."); }
    if (parseYouTube(u.href)) { const e = new Error("YouTube video"); e.code = "youtube"; e.videoId = parseYouTube(u.href); e.url = u.href; throw e; }
    if (/(^|\.)vimeo\.com$/.test(u.hostname)) throw new Error("Video pages have no readable text. Paste the transcript instead.");
    if (location.protocol === "https:" && u.protocol === "http:") throw new Error("This app is on a secure (https) page, so it cannot open an insecure http:// link. Try the https:// version.");
    progress && progress("Fetching " + u.hostname + "…");
    let res;
    try { res = await fetch(u.href, { mode: "cors", credentials: "omit", redirect: "follow" }); }
    catch (e) { throw new Error(`Could not read ${u.hostname}. Most likely that website does not allow other apps to read it (or you are offline). Workaround: open the page, select all, copy, and paste it into the text box here, or save the page as a PDF and add that file.`); }
    if (!res.ok) throw new Error(`The website answered with an error (${res.status}).`);
    const type = (res.headers.get("content-type") || "").toLowerCase(), path = u.pathname.toLowerCase();
    const fname = decodeURIComponent(path.split("/").pop() || "") || u.hostname;
    const blob = await res.blob();
    if (blob.size > 30 * 1024 * 1024) throw new Error("That link is too big (limit 30 MB).");
    if (type.includes("pdf") || path.endsWith(".pdf")) return { name: fname.replace(/\.pdf$/i, "") || u.hostname, text: await readPdf(new File([blob], fname || "file.pdf"), progress) };
    if (path.endsWith(".docx") || type.includes("wordprocessingml")) return { name: fname.replace(/\.docx$/i, "") || u.hostname, text: await readDocx(new File([blob], fname || "file.docx")) };
    const body = await blob.text();
    if (type.includes("html") || /^\s*<(!doctype|html)/i.test(body)) { const h = htmlToText(body, u.hostname); if (h.text.length < 40) throw new Error("No readable text found on that page (it may load its text with scripts). Paste the text instead."); return { name: (h.title || u.hostname).slice(0, 60), text: h.text }; }
    if (type.startsWith("text/") || /\.(txt|md|text)$/.test(path) || type.includes("json")) return { name: fname || u.hostname, text: body };
    throw new Error("This kind of link is not supported. Use a web page, PDF, Word file or text file.");
  }

  async function read(file, progress) {
    const n = file.name.toLowerCase();
    if (file.size > 60 * 1024 * 1024) throw new Error("That file is too big (limit 60 MB).");
    if (n.endsWith(".docx")) return readDocx(file);
    if (n.endsWith(".pdf") || file.type === "application/pdf") return readPdf(file, progress);
    if (/\.(srt|vtt)$/.test(n)) return readSubtitles(await file.text());
    if (n.endsWith(".doc")) throw new Error("Old .doc files cannot be read. Open it in Word and save as .docx, then add it again.");
    if (/\.(txt|md|text)$/.test(n) || file.type.startsWith("text/")) return file.text();
    throw new Error("This file type is not supported. Use Word (.docx), PDF, .txt or .md.");
  }
  return { read, readUrl, parseYouTube, cleanTranscript, readSubtitles };
})();
