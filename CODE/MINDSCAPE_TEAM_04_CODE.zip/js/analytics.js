const Analytics = {
  AREAS: ["Health", "Career", "Finance", "Relationships", "Growth", "Recreation", "Environment", "Spirituality"],
  TARGET: 8,

  getBalance() {
    const b = Storage.getObject("balance", {});
    const values = {};
    this.AREAS.forEach(a => { values[a] = (b.values && b.values[a]) || 5; });
    return { values, saved: !!b.saved };
  },

  avgScore(keys) {
    const list = keys.map(k => Data.avgOn(k)).filter(v => v !== null);
    return list.length ? list.reduce((s, v) => s + v, 0) / list.length : null;
  },

  render() {
    const days30 = Utils.lastDays(30);
    const week = Utils.lastDays(7);
    const prevWeek = Utils.lastDays(14).slice(0, 7);
    const avgThis = this.avgScore(week);
    const avgPrev = this.avgScore(prevWeek);

    let insight = "Log your mood a few times this week to see how it is changing.";
    if (avgThis !== null && avgPrev !== null) {
      const diff = avgThis - avgPrev;
      insight = Math.abs(diff) < 0.2
        ? "Your mood this week is about the same as last week."
        : diff > 0 ? `Your mood this week is up ${diff.toFixed(1)} points from last week.`
                   : `Your mood this week is down ${Math.abs(diff).toFixed(1)} points from last week.`;
    } else if (avgThis !== null) {
      insight = `Your average mood this week is ${avgThis.toFixed(1)} out of 5.`;
    }

    const points = days30.map(d => ({ label: Utils.shortDate(d), value: Data.avgOn(d) })).filter(p => p.value !== null);

    const moods30 = Data.allMoods().filter(m => days30.includes(m.dateKey));
    const dist = MOODS.map(m => ({
      label: `${m.emoji} ${m.label}`,
      value: moods30.filter(x => x.mood === m.label).length
    }));
    const maxDist = Math.max(1, ...dist.map(d => d.value));

    const habits = Storage.get("habits");
    const habitBars = habits.length
      ? Charts.bars(week.map(d => {
          const done = habits.filter(h => (h.log || []).includes(d)).length;
          return { label: Utils.shortDate(d), value: done, text: `${done}/${habits.length}` };
        }), habits.length)
      : `<p class="empty">Add habits to see your weekly completion.</p>`;

    const tasks = Storage.get("tasks");
    const focus = Storage.get("focus");
    const stats = [
      ["Journal entries", Storage.get("journal").length],
      ["Mood average (7 days)", avgThis === null ? "-" : avgThis.toFixed(1) + " / 5"],
      ["Best habit streak", Data.bestStreak() + " days"],
      ["Tasks done", `${tasks.filter(t => t.done).length} / ${tasks.length}`],
      ["Focus minutes", focus.reduce((s, f) => s + f.minutes, 0)],
      ["Gratitude entries", Storage.get("gratitude").length]
    ];

    const bal = this.getBalance();
    return `
      <h1>📈 Analytics</h1>
      <div class="dash-grid">
        ${stats.map(([l, v]) => `<div class="card stat"><h4>${l}</h4><div class="stat-mid">${v}</div></div>`).join("")}
      </div>

      <div class="card">
        <h3>Mood trend (last 30 days)</h3>
        <p class="sub">${insight}</p>
        ${Charts.line(points)}
      </div>

      <div class="two-col">
        <div class="card">
          <h3>Mood mix (30 days)</h3>
          ${moods30.length ? Charts.bars(dist, maxDist) : `<p class="empty">No moods logged in the last 30 days.</p>`}
        </div>
        <div class="card">
          <h3>Habits this week</h3>
          ${habitBars}
        </div>
      </div>

      <div class="card">
        <h3>Life Balance Wheel</h3>
        <p class="sub">Rate each area from 1 to 10. The dashed line is a balanced target of ${this.TARGET}.</p>
        <div class="wheel">
          <div id="wheel-chart"></div>
          <div class="sliders" id="wheel-sliders">
            ${this.AREAS.map(a => `
              <label class="slider">${a}: <b id="val-${a}">${bal.values[a]}</b>
                <input type="range" min="1" max="10" value="${bal.values[a]}" data-area="${a}"></label>`).join("")}
          </div>
        </div>
      </div>`;
  },

  drawWheel(values) {
    document.getElementById("wheel-chart").innerHTML = Charts.radar(this.AREAS, [
      { values: this.AREAS.map(() => this.TARGET), color: "#9aa7b5", dashed: true },
      { values: this.AREAS.map(a => values[a]), color: "#5b8def" }
    ]);
  },

  init() {
    const values = this.getBalance().values;
    this.drawWheel(values);
    const sliders = document.getElementById("wheel-sliders");
    sliders.addEventListener("input", e => {
      const area = e.target.dataset.area;
      if (!area) return;
      values[area] = Number(e.target.value);
      document.getElementById("val-" + area).textContent = values[area];
      this.drawWheel(values);
    });
    sliders.addEventListener("change", () => {
      Storage.setObject("balance", { values, saved: true });
    });
  }
};
