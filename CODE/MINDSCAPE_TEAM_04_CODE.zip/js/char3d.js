// Kei: a real 3D character you can turn through 360 degrees.
// Built from simple 3D shapes with a small WebGL renderer written for this app (no libraries):
// toon shading + black outlines for an anime look. Head, eyes, eyelids, brows, mouth, arms, legs and
// feet are separate moving parts, driven by the same signals as the other characters
// (talking, listening, waving, mood, breathing) and the same acts (walk, jump, dance, nod...).
const Char3D = (() => {
  const rgb = h => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255];
  const COL = {
    skin: rgb("#f1cdb3"), skin2: rgb("#e6b99d"), hair: rgb("#dcc58f"), hair2: rgb("#bfa56c"),
    jacket: rgb("#1b1c22"), navy: rgb("#22407a"), tee: rgb("#d9dcde"), jeans: rgb("#35496a"), jeans2: rgb("#2c3d5a"),
    shoe: rgb("#1a1a1f"), sole: rgb("#f2f2f2"), iris: rgb("#5e8fd6"), pupil: rgb("#10121a"), white: rgb("#ffffff"),
    mouth: rgb("#7d3b43"), blush: rgb("#f2a29c"), frame: rgb("#101014"), zip: rgb("#8a8d93"), cuff: rgb("#14151a")
  };

  // ---------- tiny matrix library (column-major) ----------
  const I = () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
  const mul = (a, b) => { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; };
  const tr = (m, x, y, z) => { const o = new Float32Array(m); o[12] = m[0] * x + m[4] * y + m[8] * z + m[12]; o[13] = m[1] * x + m[5] * y + m[9] * z + m[13]; o[14] = m[2] * x + m[6] * y + m[10] * z + m[14]; return o; };
  const rX = (m, a) => { if (!a) return m; const c = Math.cos(a), s = Math.sin(a); return mul(m, new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1])); };
  const rY = (m, a) => { if (!a) return m; const c = Math.cos(a), s = Math.sin(a); return mul(m, new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1])); };
  const rZ = (m, a) => { if (!a) return m; const c = Math.cos(a), s = Math.sin(a); return mul(m, new Float32Array([c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1])); };
  const sc = (m, x, y, z) => { const o = new Float32Array(m); o[0] *= x; o[1] *= x; o[2] *= x; o[4] *= y; o[5] *= y; o[6] *= y; o[8] *= z; o[9] *= z; o[10] *= z; return o; };
  const persp = (fov, asp, n, f) => { const t = 1 / Math.tan(fov / 2); return new Float32Array([t / asp, 0, 0, 0, 0, t, 0, 0, 0, 0, (f + n) / (n - f), -1, 0, 0, 2 * f * n / (n - f), 0]); };
  const normalMat = m => {
    const A = m[0], B = m[4], C = m[8], D = m[1], E = m[5], F = m[9], G = m[2], H = m[6], Ii = m[10];
    const det = A * (E * Ii - F * H) - B * (D * Ii - F * G) + C * (D * H - E * G), k = 1 / (det || 1);
    const c00 = E * Ii - F * H, c01 = -(D * Ii - F * G), c02 = D * H - E * G;
    const c10 = -(B * Ii - C * H), c11 = A * Ii - C * G, c12 = -(A * H - B * G);
    const c20 = B * F - C * E, c21 = -(A * F - C * D), c22 = A * E - B * D;
    return new Float32Array([c00 * k, c10 * k, c20 * k, c01 * k, c11 * k, c21 * k, c02 * k, c12 * k, c22 * k]);
  };

  // ---------- mesh generators: positions, shading normals, smooth outline directions ----------
  const norm = v => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
  function build(verts, idx) { return { v: new Float32Array(verts), i: new Uint16Array(idx) }; }
  function sphere(lat = 18, lon = 24) {
    const v = [], ix = [];
    for (let a = 0; a <= lat; a++) for (let b = 0; b <= lon; b++) {
      const th = a * Math.PI / lat, ph = b * 2 * Math.PI / lon, p = [Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph)];
      v.push(...p, ...p, ...p);
    }
    for (let a = 0; a < lat; a++) for (let b = 0; b < lon; b++) { const x = a * (lon + 1) + b, y = x + lon + 1; ix.push(x, x + 1, y, y, x + 1, y + 1); }
    return build(v, ix);
  }
  function cube() {
    const v = [], ix = [], F = [[[0, 0, 1], [1, 0, 0], [0, 1, 0]], [[0, 0, -1], [-1, 0, 0], [0, 1, 0]], [[1, 0, 0], [0, 0, -1], [0, 1, 0]], [[-1, 0, 0], [0, 0, 1], [0, 1, 0]], [[0, 1, 0], [1, 0, 0], [0, 0, -1]], [[0, -1, 0], [1, 0, 0], [0, 0, 1]]];
    F.forEach(([n, u, w], f) => {
      [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([a, b]) => {
        const p = [n[0] * .5 + u[0] * a * .5 + w[0] * b * .5, n[1] * .5 + u[1] * a * .5 + w[1] * b * .5, n[2] * .5 + u[2] * a * .5 + w[2] * b * .5];
        v.push(...p, ...n, ...norm(p));
      });
      const o = f * 4; ix.push(o, o + 1, o + 2, o, o + 2, o + 3);
    });
    return build(v, ix);
  }
  function cylinder(a0 = 0, a1 = Math.PI * 2, seg = 28, caps = true) {
    const v = [], ix = [];
    for (let s = 0; s <= seg; s++) {
      const a = a0 + (a1 - a0) * s / seg, c = Math.cos(a), si = Math.sin(a);
      for (const y of [-.5, .5]) v.push(c, y, si, c, 0, si, ...norm([c, y * .6, si]));
    }
    for (let s = 0; s < seg; s++) { const o = s * 2; ix.push(o, o + 1, o + 2, o + 1, o + 3, o + 2); }
    if (caps) for (const y of [-.5, .5]) {
      const base = v.length / 9; v.push(0, y, 0, 0, Math.sign(y), 0, 0, Math.sign(y), 0);
      for (let s = 0; s <= seg; s++) { const a = a0 + (a1 - a0) * s / seg; v.push(Math.cos(a), y, Math.sin(a), 0, Math.sign(y), 0, ...norm([Math.cos(a), y * 1.5, Math.sin(a)])); }
      for (let s = 0; s < seg; s++) y > 0 ? ix.push(base, base + 2 + s, base + 1 + s) : ix.push(base, base + 1 + s, base + 2 + s);
    }
    return build(v, ix);
  }
  function torus(R = 1, r = .13, u = 28, w = 10) {
    const v = [], ix = [];
    for (let a = 0; a <= u; a++) for (let b = 0; b <= w; b++) {
      const U = a * 2 * Math.PI / u, V = b * 2 * Math.PI / w, n = [Math.cos(V) * Math.cos(U), Math.cos(V) * Math.sin(U), Math.sin(V)];
      v.push((R + r * Math.cos(V)) * Math.cos(U), (R + r * Math.cos(V)) * Math.sin(U), r * Math.sin(V), ...n, ...n);
    }
    for (let a = 0; a < u; a++) for (let b = 0; b < w; b++) { const x = a * (w + 1) + b, y = x + w + 1; ix.push(x, x + 1, y, y, x + 1, y + 1); }
    return build(v, ix);
  }
  const GAP = .44, FRONT = Math.PI / 2;
  const SRC = { sphere: sphere(), cube: cube(), cyl: cylinder(), arc: cylinder(FRONT + GAP, FRONT + Math.PI * 2 - GAP, 30, false), collar: cylinder(FRONT + .8, FRONT + Math.PI * 2 - .8, 24, false), torus: torus() };

  const VS = `precision mediump float; attribute vec3 aP,aN,aO; uniform mat4 uM,uVP; uniform mat3 uNM; uniform float uOut; varying vec3 vN,vW;
    void main(){ vec4 w=uM*vec4(aP,1.0); vec3 n=normalize(uNM*aN); if(uOut>0.0){ w.xyz+=normalize(uNM*aO)*uOut; } vN=n; vW=w.xyz; gl_Position=uVP*w; }`;
  const FS = `precision mediump float; varying vec3 vN,vW; uniform vec3 uC,uL,uCam; uniform float uOut,uShine,uAlpha;
    void main(){ if(uOut>0.0){ gl_FragColor=vec4(0.07,0.07,0.10,1.0); return; }
      vec3 n=normalize(vN); float d=dot(n,normalize(uL)); float t=d>0.30?1.0:(d>-0.15?0.80:0.60);
      vec3 V=normalize(uCam-vW); float rim=pow(1.0-max(dot(n,V),0.0),3.0)*0.22;
      vec3 col=uC*t+rim*vec3(0.55,0.65,1.0);
      float sp=pow(max(dot(reflect(-normalize(uL),n),V),0.0),22.0)*uShine; col+=sp;
      gl_FragColor=vec4(col*uAlpha,uAlpha); }`;

  // ---------- one renderer + one character per canvas ----------
  const ACT_MS = { walk: 2200, jump: 900, dance: 2400, nod: 1300, shake: 1200, tilt: 1500, cheer: 1700, comfort: 2400, hearts: 2000, wink: 900, think: 1800 };
  const KEYS = ["rootY", "hipRoll", "hipYaw", "tPitch", "tYaw", "tRoll", "hPitch", "hYaw", "hRoll", "brow", "chest", "aLf", "aLa", "aLe", "aRf", "aRa", "aRe", "lLf", "lLk", "lRf", "lRk", "mouth", "blush"];
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

  function Inst(el) {
    this.el = el; this.canvas = el.querySelector("canvas"); this.mode = el.dataset.mode || "stage";
    this.gl = this.canvas.getContext("webgl", { alpha: true, antialias: true, premultipliedAlpha: true });
    if (!this.gl) { el.innerHTML = `<div class="kei-nogl">3D is not supported on this device</div>`; return; }
    this.pose = {}; KEYS.forEach(k => this.pose[k] = 0); this.pose.chest = 1;
    this.yawBase = this.mode === "stage" ? 0.25 : 0.12; this.yaw = this.yawBase; this.autoSpin = false; this.spin = null; this.act = null;
    this.dist = this.mode === "stage" ? 4.15 : 0.95; this.manual = 0; this.nextBlink = 1.5; this.blinkStart = -9; this.frames = 0; this.last = 0;
    this.initGL(); this.bindUI(); this.raf = requestAnimationFrame(t => this.loop(t));
  }
  Inst.prototype.initGL = function () {
    const gl = this.gl, sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
    const p = this.prog = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(p); gl.useProgram(p);
    this.loc = {}; ["uM", "uVP", "uNM", "uOut", "uC", "uL", "uCam", "uShine", "uAlpha"].forEach(n => this.loc[n] = gl.getUniformLocation(p, n));
    this.att = ["aP", "aN", "aO"].map(n => gl.getAttribLocation(p, n));
    this.mesh = {};
    for (const k in SRC) { const vb = gl.createBuffer(), ib = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, SRC[k].v, gl.STATIC_DRAW); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, SRC[k].i, gl.STATIC_DRAW); this.mesh[k] = { vb, ib, n: SRC[k].i.length }; }
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  };
  Inst.prototype.bindUI = function () {
    const el = this.el, cv = this.canvas; let down = null;
    cv.addEventListener("pointerdown", e => { if (this.mode !== "stage") return; down = e.clientX; cv.setPointerCapture(e.pointerId); this.spin = null; });
    cv.addEventListener("pointermove", e => { if (down === null) return; this.yaw += (e.clientX - down) * 0.012; down = e.clientX; this.manual = performance.now(); });
    const up = () => { down = null; }; cv.addEventListener("pointerup", up); cv.addEventListener("pointercancel", up);
    cv.addEventListener("dblclick", () => { this.yaw = this.yawBase; this.autoSpin = false; });
    cv.addEventListener("wheel", e => { if (this.mode !== "stage") return; e.preventDefault(); this.dist = clamp(this.dist * (e.deltaY > 0 ? 1.06 : .94), 2.4, 6); }, { passive: false });
    const q = s => el.querySelector(s);
    if (q(".kei-spin")) q(".kei-spin").addEventListener("click", () => { this.spin = { start: performance.now(), from: this.yaw, ms: 3600 }; });
    if (q(".kei-auto")) q(".kei-auto").addEventListener("click", e => { this.autoSpin = !this.autoSpin; e.currentTarget.classList.toggle("on", this.autoSpin); });
    if (q(".kei-reset")) q(".kei-reset").addEventListener("click", () => { this.yaw = this.yawBase; this.autoSpin = false; this.dist = 4.15; const a = q(".kei-auto"); if (a) a.classList.remove("on"); });
  };
  Inst.prototype.doAct = function (name) { if (ACT_MS[name]) this.act = { name, start: performance.now() / 1000, ms: ACT_MS[name] / 1000 }; };

  // ----- pose targets from state + act -----
  Inst.prototype.targets = function (t, st) {
    const T = {}; KEYS.forEach(k => T[k] = 0); T.chest = 1;
    const br = Math.sin(t * 1.6);
    T.chest = 1 + .012 * br; T.tPitch = .02 * br; T.hRoll = .03 * Math.sin(t * .7); T.hYaw = .05 * Math.sin(t * .5); T.hipRoll = .012 * Math.sin(t * .5);
    T.aLa = .1 + .02 * Math.sin(t * 1.1); T.aRa = .1 + .02 * Math.sin(t * 1.1 + 1); T.aLe = .14; T.aRe = .14; T.aLf = .03 * Math.sin(t * .8); T.aRf = .03 * Math.sin(t * .8 + 1);
    if (st.sad) { T.hPitch += .22; T.tPitch += .08; T.aLa = .03; T.aRa = .03; T.rootY -= .01; }
    if (st.happy) { T.blush = 1; T.rootY += .012 * Math.abs(Math.sin(t * 3)); T.hRoll += .04; }
    if (st.listening) { T.hYaw += .28; T.hRoll += .08; T.brow = 1; }
    if (st.inhale) { T.chest = 1.035; T.aLa += .08; T.aRa += .08; }
    if (st.talking) {
      T.mouth = clamp(Math.abs(Math.sin(t * 12.5)) * (.55 + .45 * Math.pow(Math.sin(t * 3.1), 2)) + .12, 0, 1);
      T.hPitch += .04 * Math.sin(t * 5); T.hYaw += .08 * Math.sin(t * 2.3);
      T.aRf = .55 + .3 * Math.sin(t * 3); T.aRe = 1.1 + .3 * Math.sin(t * 3.7); T.aRa = .3;
    }
    if (st.waving) { T.aRa = 2.45; T.aRf = 0; T.aRe = .35 + .55 * Math.sin(t * 10); T.hRoll += .1; T.blush = 1; }
    let blinkR = null;
    const a = this.act;
    if (a) {
      const p = (t - a.start) / a.ms;
      if (p >= 1) this.act = null; else {
        const env = Math.sin(Math.PI * clamp(p, 0, 1)), ease = Math.min(1, p * 6, (1 - p) * 6);
        switch (a.name) {
          case "walk": { const ph = t * 6.2; T.lLf = .6 * Math.sin(ph) * ease; T.lRf = -.6 * Math.sin(ph) * ease; T.lLk = (.5 + .5 * Math.sin(ph + 1.3)) * .75 * ease; T.lRk = (.5 + .5 * Math.sin(ph + 1.3 + Math.PI)) * .75 * ease;
            T.aLf = -.5 * Math.sin(ph) * ease; T.aRf = .5 * Math.sin(ph) * ease; T.aLe = .3 * ease + .14; T.aRe = .3 * ease + .14; T.rootY += .022 * Math.abs(Math.sin(ph)) * ease; T.tYaw = .14 * Math.sin(ph) * ease; T.hipYaw = -.1 * Math.sin(ph) * ease; break; }
          case "jump": { const c = p < .2 ? p / .2 : (p > .8 ? (1 - (p - .8) / .2) * .8 : 0), air = p > .2 && p < .8 ? Math.sin(Math.PI * (p - .2) / .6) : 0;
            T.rootY += .4 * air - .1 * c; T.lLk = T.lRk = .95 * c + .45 * air; T.lLf = T.lRf = .5 * c + .1 * air; T.tPitch += .22 * c; T.aLa = T.aRa = .25 + 2.0 * air; T.aLe = T.aRe = .3; T.mouth = .5 * air; break; }
          case "cheer": { const hop = Math.abs(Math.sin(Math.PI * p * 3)); T.aLa = T.aRa = .3 + 2.45 * ease; T.aLe = T.aRe = .25; T.rootY += .15 * hop * ease; T.lLk = T.lRk = .35 * (1 - hop) * ease; T.mouth = .7 * ease; T.blush = 1; T.hPitch -= .1 * ease; break; }
          case "dance": { const s = Math.sin(t * 7); T.hipRoll = .13 * s * ease; T.tRoll = -.09 * s * ease; T.aLa = 1.2 + .6 * s; T.aRa = 1.2 - .6 * s; T.aLe = T.aRe = .9; T.hRoll += .13 * s * ease; T.rootY += .035 * Math.abs(Math.sin(t * 7)) * ease; T.lLf = .25 * s * ease; T.lRf = -.25 * s * ease; T.lLk = T.lRk = .2 * ease; T.blush = 1; break; }
          case "nod": T.hPitch += .3 * Math.sin(p * Math.PI * 4) * ease; break;
          case "shake": T.hYaw += .5 * Math.sin(p * Math.PI * 6) * ease; break;
          case "tilt": T.hRoll -= .25 * env; T.hYaw += .15 * env; break;
          case "think": T.hRoll -= .2 * env; T.hYaw += .2 * env; T.aRf = .75 * ease; T.aRe = 2.05 * ease; T.aRa = .1; T.brow = env; break;
          case "comfort": T.hPitch += .3 * env; T.tPitch += .12 * env; T.aLf = T.aRf = .35 * env; T.aLe = T.aRe = .6 * env; break;
          case "hearts": T.aLf = T.aRf = .5 * ease; T.aLe = T.aRe = 1.9 * ease; T.aLa = T.aRa = .25 * ease; T.hRoll += .12 * env; T.blush = 1; T.hPitch += .08 * Math.sin(p * Math.PI * 4) * ease; break;
          case "wink": blinkR = env; break;
        }
      }
    }
    return { T, blinkR };
  };

  // ----- build the figure as a list of parts -----
  Inst.prototype.figure = function (P, blinkL, blinkR, yaw) {
    const parts = [], add = (mesh, m, s, c, o = {}) => parts.push({ mesh, m: sc(m, s[0], s[1], s[2]), c, shine: o.shine || 0, out: o.out !== false, alpha: o.alpha || 1 });
    let root = rY(tr(I(), 0, Math.max(P.rootY, -.12), 0), yaw);
    const hips = rY(rZ(tr(root, 0, .99, 0), P.hipRoll), P.hipYaw);
    add("cyl", tr(hips, 0, 0, 0), [.158, .16, .098], COL.jeans);
    // torso (waist to shoulders)
    const torso = rX(rZ(rY(tr(hips, 0, .06, 0), P.tYaw), P.tRoll), P.tPitch), ch = P.chest;
    add("cyl", tr(torso, 0, .23, 0), [.148 * ch, .46, .088 * ch], COL.tee);
    add("arc", tr(torso, 0, .235, 0), [.178 * ch, .44, .104 * ch], COL.jacket);
    add("arc", tr(torso, 0, .40, 0), [.181 * ch, .115, .107 * ch], COL.navy);
    add("collar", tr(torso, 0, .515, -.004), [.092, .075, .078], COL.jacket);
    add("cyl", tr(torso, 0, .50, .004), [.06, .05, .055], COL.tee, { out: false });
    for (const s of [1, -1]) { const ang = FRONT + s * (GAP + .0), x = Math.cos(ang) * .18 * ch, z = Math.sin(ang) * .105 * ch; add("cube", tr(torso, x, .235, z + .003), [.008, .44, .008], COL.zip, { out: false }); }
    add("cyl", tr(torso, 0, .55, 0), [.045, .1, .045], COL.skin);
    // head
    const hb = rZ(rX(rY(tr(torso, 0, .545, 0), P.hYaw), P.hPitch), P.hRoll), H = tr(hb, 0, .115, 0);
    add("sphere", H, [.108, .125, .114], COL.skin, { shine: .12 });
    add("sphere", tr(H, 0, -.07, .012), [.082, .075, .09], COL.skin);
    for (const s of [1, -1]) add("sphere", tr(H, s * .108, -.01, -.005), [.02, .042, .014], COL.skin);
    // hair
    add("sphere", tr(H, 0, .02, -.03), [.118, .12, .118], COL.hair, { shine: .18 });
    add("sphere", tr(H, 0, -.012, -.055), [.114, .112, .1], COL.hair2);
    for (const s of [1, -1]) add("sphere", tr(H, s * .1, .0, -.002), [.03, .085, .07], COL.hair);
    const locks = [[-.082, .082, .05, .3], [-.052, .09, .048, .12], [-.022, .094, .042, -.05], [.012, .092, .05, .06], [.045, .09, .046, -.14], [.078, .082, .052, -.28]];
    locks.forEach(([x, y, h, a]) => add("sphere", rZ(tr(H, x, y, .094), a), [.03, h, .022], COL.hair, { shine: .15 }));
    add("sphere", tr(H, .01, .135, -.005), [.032, .03, .03], COL.hair); add("sphere", tr(H, -.035, .128, -.012), [.026, .03, .026], COL.hair);
    // face
    for (const s of [1, -1]) {
      const ex = s * .044, ey = -.004, bl = s === 1 ? blinkL : blinkR;
      add("sphere", tr(H, ex, ey, .098), [.03, .021, .014], COL.white, { out: false });
      add("sphere", tr(H, ex, ey, .106), [.0155, .0155, .008], COL.iris, { out: false });
      add("sphere", tr(H, ex, ey, .112), [.0075, .0075, .005], COL.pupil, { out: false });
      add("sphere", tr(H, ex + .005, ey + .006, .116), [.004, .004, .003], COL.white, { out: false });
      add("sphere", tr(H, ex, ey + .021 - bl * .016, .1), [.034, .009 + .024 * bl, .017], COL.skin);
      add("cube", rZ(tr(H, ex, .036 + P.brow * .012, .106), s * -.14), [.04, .007, .01], COL.hair2, { out: false });
      add("torus", tr(H, ex, ey, .122), [.045, .038, .05], COL.frame, { out: false, shine: .3 });
      add("cube", tr(H, s * .1, .0, .052), [.005, .005, .14], COL.frame, { out: false });
      if (P.blush > .5) add("sphere", tr(H, s * .068, -.034, .098), [.022, .011, .005], COL.blush, { out: false });
    }
    add("cube", tr(H, 0, .004, .124), [.02, .005, .006], COL.frame, { out: false });
    add("sphere", tr(H, 0, -.036, .112), [.011, .018, .016], COL.skin2, { out: false });
    add("sphere", tr(H, 0, -.082, .103), [.024 + .004 * P.blush, .003 + .022 * P.mouth, .008], COL.mouth, { out: false });
    // arms
    for (const s of [1, -1]) {
      const k = s === 1 ? "L" : "R", f = P["a" + k + "f"], ab = P["a" + k + "a"], eb = P["a" + k + "e"];
      const sh = rX(rZ(tr(torso, s * .2 * 1, .43, 0), s * ab), -f);
      add("sphere", sh, [.064, .064, .064], COL.navy);
      add("cyl", tr(sh, 0, -.15, 0), [.052, .30, .052], COL.jacket);
      add("cube", tr(sh, s * .05, -.15, 0), [.012, .27, .03], COL.navy, { out: false });
      const el = rX(tr(sh, 0, -.30, 0), -eb);
      add("sphere", el, [.05, .05, .05], COL.jacket);
      add("cyl", tr(el, 0, -.14, 0), [.046, .28, .046], COL.jacket);
      add("cube", tr(el, s * .046, -.14, 0), [.012, .25, .028], COL.navy, { out: false });
      add("cyl", tr(el, 0, -.285, 0), [.05, .05, .05], COL.cuff);
      add("sphere", tr(el, 0, -.34, .004), [.034, .06, .027], COL.skin);
      add("sphere", tr(el, -s * .03, -.31, .02), [.013, .032, .013], COL.skin, { out: false });
    }
    // legs
    for (const s of [1, -1]) {
      const k = s === 1 ? "L" : "R", lg = rX(tr(hips, s * .088, -.04, 0), -P["l" + k + "f"]);
      add("cyl", tr(lg, 0, -.225, 0), [.075, .45, .079], COL.jeans);
      const kn = rX(tr(lg, 0, -.45, 0), P["l" + k + "k"]);
      add("sphere", kn, [.062, .062, .066], COL.jeans);
      add("cyl", tr(kn, 0, -.21, 0), [.058, .42, .062], COL.jeans2);
      const an = tr(kn, 0, -.42, 0);
      add("cube", tr(an, 0, -.035, .045), [.098, .07, .24], COL.shoe);
      add("sphere", tr(an, 0, -.03, .15), [.049, .035, .06], COL.shoe);
      add("cube", tr(an, 0, -.075, .05), [.102, .03, .25], COL.sole);
      for (const z of [-.01, .035, .08]) add("cube", rX(tr(an, s * .051, -.03, z), -.5), [.005, .02, .05], COL.sole, { out: false });
    }
    // soft ground shadow
    parts.push({ mesh: "cyl", m: sc(tr(I(), 0, .002, 0), .3 * (1 - clamp(P.rootY * 1.4, 0, .5)), .004, .24 * (1 - clamp(P.rootY * 1.4, 0, .5))), c: [0, 0, 0], shine: 0, out: false, alpha: .22, shadow: true });
    return parts;
  };

  Inst.prototype.draw = function (parts, vp, cam, outW) {
    const gl = this.gl, L = this.loc;
    gl.uniformMatrix4fv(L.uVP, false, vp); gl.uniform3fv(L.uL, [-.45, .75, .9]); gl.uniform3fv(L.uCam, cam);
    const pass = (outline) => {
      gl.cullFace(outline ? gl.FRONT : gl.BACK);
      for (const p of parts) {
        if (outline && !p.out) continue; if (!outline && p.shadow) continue;
        const m = this.mesh[p.mesh];
        gl.bindBuffer(gl.ARRAY_BUFFER, m.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.ib);
        this.att.forEach((a, i) => { gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 36, i * 12); });
        gl.uniformMatrix4fv(L.uM, false, p.m); gl.uniformMatrix3fv(L.uNM, false, normalMat(p.m));
        gl.uniform3fv(L.uC, p.c); gl.uniform1f(L.uShine, p.shine); gl.uniform1f(L.uOut, outline ? outW : 0); gl.uniform1f(L.uAlpha, p.alpha);
        gl.drawElements(gl.TRIANGLES, m.n, gl.UNSIGNED_SHORT, 0);
      }
    };
    pass(true); pass(false);
    gl.cullFace(gl.BACK); gl.depthMask(false);
    for (const p of parts) if (p.shadow) { const m = this.mesh[p.mesh]; gl.bindBuffer(gl.ARRAY_BUFFER, m.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.ib); this.att.forEach((a, i) => { gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 36, i * 12); }); gl.uniformMatrix4fv(L.uM, false, p.m); gl.uniformMatrix3fv(L.uNM, false, normalMat(p.m)); gl.uniform3fv(L.uC, p.c); gl.uniform1f(L.uShine, 0); gl.uniform1f(L.uOut, 0); gl.uniform1f(L.uAlpha, p.alpha); gl.drawElements(gl.TRIANGLES, m.n, gl.UNSIGNED_SHORT, 0); }
    gl.depthMask(true);
  };

  Inst.prototype.loop = function (now) {
    if (!this.el.isConnected) { return this.dispose(); }
    this.raf = requestAnimationFrame(t => this.loop(t));
    if (document.hidden) return;
    const cv = this.canvas, dpr = Math.min(window.devicePixelRatio || 1, 2), w = cv.clientWidth, h = cv.clientHeight;
    if (!w || !h) return;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const t = now / 1000, dt = clamp(t - (this.last || t), 0, .05); this.last = t;
    const cl = this.el.classList, st = { talking: cl.contains("talking"), listening: cl.contains("listening"), waving: cl.contains("waving"), sad: cl.contains("mood-sad"), happy: cl.contains("mood-happy"), inhale: cl.contains("inhale") };
    const { T, blinkR } = this.targets(t, st), P = this.pose;
    for (const k of KEYS) { const rate = k === "mouth" ? 34 : 13; P[k] += (T[k] - P[k]) * Math.min(1, dt * rate); }
    // blinking
    if (t > this.nextBlink) { this.blinkStart = t; this.nextBlink = t + 2.4 + Math.random() * 3.2; }
    const bp = (t - this.blinkStart) / .17, blink = bp >= 0 && bp < 1 ? Math.sin(Math.PI * bp) : 0, bR = blinkR !== null ? Math.max(blink, blinkR) : blink;
    // turning: drag, spin 360, auto spin, gentle return to front
    const nowMs = performance.now();
    if (this.spin) { const sp = clamp((nowMs - this.spin.start) / this.spin.ms, 0, 1), e = sp < .5 ? 2 * sp * sp : 1 - Math.pow(-2 * sp + 2, 2) / 2; this.yaw = this.spin.from + e * Math.PI * 2; if (sp >= 1) this.spin = null; }
    else if (this.autoSpin) this.yaw += dt * .6;
    else if (this.mode === "stage" && nowMs - this.manual > 7000 && Math.abs(this.yaw - this.yawBase) > .01) { const twoPi = Math.PI * 2; let d = ((this.yawBase - this.yaw) % twoPi + 3 * Math.PI) % twoPi - Math.PI; this.yaw += d * Math.min(1, dt * 1.5); }
    // draw
    const gl = this.gl; gl.viewport(0, 0, cv.width, cv.height); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const face = this.mode !== "stage", ty = face ? 1.71 : .98, d = face ? this.dist : this.dist, pitch = face ? 0 : .05;
    const V = tr(rX(tr(I(), 0, 0, -d), pitch), 0, -ty, 0), PM = persp(30 * Math.PI / 180, cv.width / cv.height, .1, 20), vp = mul(PM, V);
    const visH = 2 * d * Math.tan(15 * Math.PI / 180), outW = visH / cv.height * (face ? 2.2 : 1.9);
    const parts = this.figure(P, blink, bR, this.yaw);
    this.draw(parts, vp, [0, ty * .6, d], outW);
    if (this.el.closest(".avatar-thumb") && ++this.frames > 3) { cancelAnimationFrame(this.raf); }
  };
  Inst.prototype.dispose = function () { cancelAnimationFrame(this.raf); const e = this.gl && this.gl.getExtension("WEBGL_lose_context"); if (e) e.loseContext(); const i = insts.indexOf(this); if (i >= 0) insts.splice(i, 1); };

  const insts = [];
  function init(el) { if (el.dataset.ready) return; el.dataset.ready = "1"; const i = new Inst(el); if (i.gl) insts.push(i); }
  function scan(root) { (root.querySelectorAll ? root.querySelectorAll(".kei3d") : []).forEach(init); if (root.classList && root.classList.contains("kei3d")) init(root); }
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => n.nodeType === 1 && scan(n)))).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener("DOMContentLoaded", () => scan(document));
  return { act: name => insts.forEach(i => i.doAct(name)), count: () => insts.length, _all: insts };
})();
