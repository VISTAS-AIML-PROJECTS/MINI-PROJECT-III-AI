const Library = {
  tab: "resources",
  cat: "All",

  RESOURCES: [
    { cat: "Calm", title: "Box breathing", text: "Breathe in for 4, hold for 4, out for 4, hold for 4. Repeat for a few minutes. It slows your heart rate and settles racing thoughts." },
    { cat: "Calm", title: "Progressive muscle relaxation", text: "Tense each muscle group for 5 seconds, then release for 10. Start at your feet and work up to your face." },
    { cat: "Calm", title: "Name it to tame it", text: "Say what you feel in one word, such as 'anxious' or 'frustrated'. Labelling an emotion often lowers its intensity." },
    { cat: "Sleep", title: "A steady wind-down", text: "Keep a regular bedtime, dim lights an hour before, and keep screens away from the bed. Write tomorrow's to-do list so your mind can let go." },
    { cat: "Sleep", title: "If you cannot sleep", text: "After about 20 minutes awake, get up and do something quiet in low light. Return to bed when you feel sleepy." },
    { cat: "Stress", title: "Break big tasks down", text: "Write the next smallest step, not the whole project. Finishing a tiny step builds momentum." },
    { cat: "Stress", title: "Move for five minutes", text: "A short walk or stretch can lift mood and clear your head. It does not need to be a full workout." },
    { cat: "Stress", title: "Talk to someone", text: "Sharing what is on your mind with a friend, family member, or mentor often makes it lighter." },
    { cat: "Study", title: "Focus in short bursts", text: "Work for 25 minutes, then rest for 5. Use the focus timer in Habits & Tasks." },
    { cat: "Study", title: "Plan the night before", text: "Pick your top three priorities for tomorrow. Starting with a clear plan reduces morning stress." },
    { cat: "Support", title: "When to reach out", text: "If low mood, anxiety, or hopeless thoughts last for weeks or get in the way of daily life, please talk to a doctor, counsellor, or someone you trust." },
    { cat: "Support", title: "About MindScape", text: "MindScape is a self-reflection tool. It does not diagnose or treat any condition and is not a replacement for professional care." }
  ],

  favs() { return Storage.getObject("wisdom_favs", []); },

  render() {
    return `
      <h1>📚 Library</h1>
      <div class="card support">
        <h3>Need to talk to someone now?</h3>
        ${HELP.lines.map(l => `<p><b>${Utils.escape(l.name)}:</b> <a class="link" href="tel:${l.number}">${l.number}</a></p>`).join("")}
        <p class="note">${Utils.escape(HELP.note)}</p>
      </div>
      <div class="tabs">
        <button class="tab ${this.tab === "resources" ? "active" : ""}" data-tab="resources">Resources</button>
        <button class="tab ${this.tab === "wisdom" ? "active" : ""}" data-tab="wisdom">Wisdom</button>
        <button class="tab ${this.tab === "create" ? "active" : ""}" data-tab="create">✨ Create</button>
      </div>
      <div id="lib-body"></div>`;
  },

  init() {
    document.querySelectorAll(".tab").forEach(t => t.addEventListener("click", () => {
      this.tab = t.dataset.tab;
      document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === t));
      this.draw();
    }));
    document.getElementById("lib-body").addEventListener("click", e => {
      const chip = e.target.closest(".chip");
      if (chip) { this.cat = chip.dataset.cat; return this.draw(); }
      const star = e.target.closest("button[data-fav]");
      if (star) {
        const i = Number(star.dataset.fav);
        const favs = new Set(this.favs());
        if (favs.has(i)) favs.delete(i); else favs.add(i);
        Storage.setObject("wisdom_favs", [...favs]);
        this.draw();
      }
    });
    this.draw();
  },

  draw() {
    const body = document.getElementById("lib-body");
    if (this.tab === "create") { body.innerHTML = Creator.html(); Creator.init(body); return; }
    if (this.tab === "resources") {
      const cats = ["All", ...new Set(this.RESOURCES.map(r => r.cat))];
      const items = this.RESOURCES.filter(r => this.cat === "All" || r.cat === this.cat);
      body.innerHTML = `
        <div class="chips">${cats.map(c => `<button class="chip ${c === this.cat ? "active" : ""}" data-cat="${c}">${c}</button>`).join("")}</div>
        ${items.map(r => `<div class="card"><h3>${Utils.escape(r.title)}</h3><p>${Utils.escape(r.text)}</p></div>`).join("")}`;
    } else {
      const q = Utils.quoteOfDay();
      const favs = new Set(this.favs());
      body.innerHTML = `
        <div class="card"><h4>Quote of the day</h4>
          <p class="quote">“${Utils.escape(q.text)}”<small>${Utils.escape(q.by)}</small></p></div>
        ${WISDOM.map((w, i) => `
          <div class="card wisdom">
            <p class="quote">“${Utils.escape(w.text)}”<small>${Utils.escape(w.by)}</small></p>
            <button class="btn-small" data-fav="${i}" aria-label="Save to favourites">${favs.has(i) ? "★ Saved" : "☆ Save"}</button>
          </div>`).join("")}`;
    }
  }
};
