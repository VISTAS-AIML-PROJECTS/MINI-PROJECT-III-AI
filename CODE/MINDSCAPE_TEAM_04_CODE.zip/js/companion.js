// Floating companion: an on-screen character that reacts to mood and chats, drawing on
// wisdom traditions (Bhagavad Gita, Tirukural, Bible, and more) without ever naming its source.
const Companion = {
  KEY: "companion",
  CHAT_KEY: "companion_chat",

  WISDOM: [
    { tag: "duty",     line: "Do what is yours to do today, fully, and let go of gripping the outcome so tightly." },
    { tag: "duty",     line: "You have a right to your effort, never to the fruit of it alone. Put the effort in and let the rest breathe." },
    { tag: "calm",     line: "A mind that stays steady in both comfort and difficulty is the one that sees clearly." },
    { tag: "calm",     line: "What disturbs you is rarely the event itself, just the story you are telling about it. Can we loosen that story a little?" },
    { tag: "kindness", line: "A gentle word costs nothing and can carry someone the whole day. Yours included." },
    { tag: "kindness", line: "Even a small kindness, done without show, outweighs a grand gesture done for praise." },
    { tag: "patience", line: "The field does not yield fruit the day it is sown. Keep tending it; the season will turn." },
    { tag: "patience", line: "Water wears down stone not by force, but by not giving up." },
    { tag: "friendship", line: "A true friend is a shelter you can stand under on the hard days, not just the sunny ones." },
    { tag: "friendship", line: "Choose the company that makes you want to be better, and keep choosing it." },
    { tag: "courage",  line: "Fear usually shrinks the moment you take one honest step toward it." },
    { tag: "courage",  line: "You are allowed to be afraid and still do the brave, small next thing." },
    { tag: "gratitude",line: "Count what is already good before you count what is missing. Both lists are true, but one of them heals faster." },
    { tag: "gratitude",line: "Treat each ordinary day as a gift and not a guarantee, and it starts to feel different." },
    { tag: "letting-go", line: "Some things are not yours to carry. Set down what was never yours to hold." },
    { tag: "letting-go", line: "Anger held too long burns the one holding it more than the one it was aimed at." },
    { tag: "hope",     line: "Even the darkest night has never once failed to end in a sunrise. Yours will too." },
    { tag: "hope",     line: "Small, steady steps taken in faith go further than you will believe on the day you take them." },
    { tag: "humility", line: "The fullest rivers often run the quietest. There is no need to prove your worth loudly." },
    { tag: "self-worth", line: "You do not have to earn the right to rest and to be cared for. That right was never in question." }
  ],

  STORIES: [
    { tag: "duty",     text: "There's an old story about a warrior frozen before a battle, overwhelmed by what he was about to face. A wise friend beside him said: look only at the step in front of you, act with a steady heart, and leave the rest to unfold. He picked up his bow not because the fear left, but because he decided not to let it drive." },
    { tag: "patience", text: "A farmer once planted a seed and watered it every single day. Weeks passed with nothing to show. Neighbours told him to give up. He kept watering anyway, quietly. One morning a small green shoot broke the soil, as if it had been working the whole time, just out of sight." },
    { tag: "kindness", text: "A traveller once stopped to help a stranger on the road that others had simply walked past. He didn't know the stranger, owed him nothing, expected nothing back. People still tell that story not because the help was large, but because it was given freely." },
    { tag: "letting-go", text: "A king once carried a grudge for years like a stone in his pocket, forgetting it was even there until it wore a hole in the fabric. The day he finally set it down, he said he felt lighter than he had in a decade, like he'd been carrying someone else's weight the whole time." },
    { tag: "hope",     text: "During the longest, darkest stretch of a storm at sea, the sailors who survived were not the strongest, but the ones who kept rowing, certain that no storm lasts forever. And it didn't." },
    { tag: "courage",  text: "A shepherd boy once faced something far bigger than himself, with nothing but a sling and steady hands. Everyone expected him to lose. He didn't win because he was fearless. He won because he moved anyway, afraid." }
  ],

  SONGS: [
    "There's a quiet old tune that goes: \"this too shall pass, like a river to the sea, carry what you can and let the rest flow free.\" Hum it with me if you like.",
    "Here's a little verse for today: \"small steps, steady heart, you have already come so far, don't stop now.\"",
    "An old lullaby line fits right now: \"rest your shoulders, rest your mind, morning always comes on time.\""
  ],

  SPORTS: [
    "You know, even the best players miss far more shots than people remember. What people remember is that they stayed on the court.",
    "A good team doesn't win every point. They just reset fast after losing one and play the next one clean. That's a decent plan for today too.",
    "Champions lose plenty of matches on the way to being champions. The losses just didn't get to decide the ending."
  ],

  LANGS: [["en-IN","English"], ["hi-IN","Hindi"], ["ta-IN","Tamil"], ["te-IN","Telugu"], ["ml-IN","Malayalam"]],

  // Short openers and connector phrases per language; the deeper story/wisdom lines stay in the
  // chosen language's nearest available set below, falling back to English if untranslated.
  L10N: {
    "en-IN": { thinking: "", askTalk: "Want to tell me what's going on?" },
    "hi-IN": { thinking: "", askTalk: "क्या आप मुझे बताना चाहेंगे कि क्या हो रहा है?" },
    "ta-IN": { thinking: "", askTalk: "என்ன நடக்கிறது என்று சொல்ல விரும்புகிறீர்களா?" },
    "te-IN": { thinking: "", askTalk: "ఏం జరుగుతుందో నాకు చెప్పాలనుకుంటున్నారా?" },
    "ml-IN": { thinking: "", askTalk: "എന്താണ് സംഭവിക്കുന്നതെന്ന് എന്നോട് പറയാൻ ആഗ്രഹിക്കുന്നുണ്ടോ?" }
  },

  MOOD_OPENERS: {
    Sad:     ["You seem quite sad right now. Want to tell me what's going on?", "I noticed today feels heavy for you. I'm right here if you want to talk."],
    Anxious: ["Feels like your mind is racing a little. Want to slow it down together?", "You seem on edge today. I'm listening, whenever you're ready."],
    Angry:   ["Something's clearly frustrating you. Want to let it out?", "I can tell today's been a lot. Talk to me."],
    Happy:   ["You're glowing today! What's making you this happy?", "Love this energy. Tell me what's going well!"],
    Calm:    ["You seem settled today. That's a nice place to be.", "Peaceful day, huh? I like that for you."],
    Neutral: ["How's today actually going, really?", "I'm here if there's anything on your mind."]
  },

  I18N: {},

  get() {
    const c = Storage.getObject(this.KEY, null);
    if (c && c.avatar === "boy") c.avatar = "kai";   // older saves
    if (c && c.avatar === "girl") c.avatar = "yuki";
    return c;
  },

  pack() { const c = this.get(); return (c && this.I18N[c.lang]) || null; }, // null = English

  todaysMood() { return (Data.moodOn(Utils.dateKey()) || {}).mood || "Neutral"; },

  setup(choices) {
    Storage.setObject(this.KEY, {
      enabled: true,
      avatar: choices.avatar,          // "boy" | "girl"
      style: choices.style || "story", // "story" | "song" | "sports" | "quote"
      corner: choices.corner || "right",
      voiceOn: choices.voiceOn !== false,
      lang: choices.lang || "en-IN",   // speaking/listening language (BCP-47)
      lastMoodSeen: null
    });
  },

  update(changes) {
    const c = this.get();
    if (c) Storage.setObject(this.KEY, { ...c, ...changes });
  },

  disable() { this.update({ enabled: false }); },

  // Picks something not used recently (remembered across sessions), so nothing repeats until the pool is used up
  fresh(list, key) {
    const k = "companion_used_" + key;
    let used = [];
    try { used = JSON.parse(localStorage.getItem(k) || "[]"); } catch (e) { used = []; }
    let idx = list.map((_, i) => i).filter(i => !used.includes(i));
    if (!idx.length) { used = []; idx = list.map((_, i) => i); }
    const i = idx[Math.floor(Math.random() * idx.length)];
    used.push(i);
    try { localStorage.setItem(k, JSON.stringify(used.slice(-list.length))); } catch (e) {}
    return list[i];
  },

  pickByTag(list, tag, key) {
    const pool = tag ? list.filter(x => x.tag === tag) : list;
    return this.fresh(pool.length ? pool : list, "tag:" + key + ":" + (tag || ""));
  },

  tagForMood(mood) {
    const map = { Sad: "hope", Anxious: "calm", Angry: "letting-go", Happy: "gratitude", Calm: "patience", Neutral: "duty" };
    return map[mood] || null;
  },

  // Offline fallback (used only when no AI key is set or the request fails). Never repeats until the pool is used up.
  respond(style, mood) {
    const tag = this.tagForMood(mood);
    const p = this.pack();
    const lang = (this.get() || {}).lang || "en-IN";
    if (p) {
      if (style === "song") return this.fresh(p.songs, lang + ":songs");
      if (style === "sports") return this.fresh(p.sports, lang + ":sports");
      const bank = Object.values(style === "story" ? p.stories : p.quotes);
      return this.fresh(bank, lang + ":" + style);
    }
    if (style === "song") return this.fresh(this.SONGS, "songs");
    if (style === "sports") return this.fresh(this.SPORTS, "sports");
    if (style === "story") return this.pickByTag(this.STORIES, tag, "story").text;
    return this.pickByTag(this.WISDOM, tag, "wisdom").line;
  },

  openerFor(mood) {
    const p = this.pack();
    const lang = (this.get() || {}).lang || "en-IN";
    if (p && p.openers[mood]) { const o = p.openers[mood]; return Array.isArray(o) ? this.fresh(o, lang + ":op:" + mood) : o; }
    return this.fresh(this.MOOD_OPENERS[mood] || this.MOOD_OPENERS.Neutral, "op:" + mood);
  },

  // Called by Dashboard/Journal right after a mood is saved.
  async onMoodLogged(mood) {
    const c = this.get();
    if (!c || !c.enabled) return;
    const today = Utils.dateKey();
    if (c.lastMoodSeen === today + ":" + mood) return; // don't repeat for the same mood twice today
    this.update({ lastMoodSeen: today + ":" + mood });
    Avatar.setMood(mood);
    this.toggle(true, true);
    if (mood === "Happy") { Avatar.wave(1600); setTimeout(() => Avatar.act("cheer"), 1600); }
    else if (["Sad", "Anxious", "Angry"].includes(mood)) Avatar.act("comfort");
    else Avatar.act("nod");
    const needsCalm = ["Sad", "Anxious", "Angry"].includes(mood);
    this.setActions(needsCalm ? [this.breathChip()] : [this.tasksChip()]);
    this.thinking();
    try {
      this.say(await this.callAI("mood", { mood, prompt: `I just logged my mood as ${mood}.` }));
    } catch (err) {
      this.say(this.openerFor(mood), { andThen: () => this.say(this.respond(c.style, mood)) });
      if (err.code !== "no-key") Utils.toast("AI request failed: " + err.message);
    }
  },

  // ---------- floating widget ----------
  mount() {
    this.loadSources(); this.applyCalm();
    // First run: switch the companion on by itself so it is always there (change or turn it off in Settings)
    if (!this.get()) this.setup({ avatar: "ren", style: "story", corner: "right", lang: "en-IN", voiceOn: true });
    const c = this.get();
    if (!c || !c.enabled) { this.unmount(); return; }
    if (document.getElementById("companion-widget")) { this.refreshChrome(); return; }
    const ch = Avatar.CHARS[c.avatar] || Avatar.CHARS.kai;
    const wrap = document.createElement("div");
    wrap.id = "companion-widget";
    wrap.dataset.avatar = c.avatar + ":" + Avatar.look();
    wrap.className = "companion " + (c.corner === "left" ? "cl" : "cr");
    wrap.innerHTML = `
      <div class="companion-panel" id="companion-panel" hidden>
        <div class="companion-stage">${Avatar.svg(c.avatar, false)}</div>
        <div class="companion-head">
          <strong>${ch.name}</strong>
          <button class="link-btn" id="companion-close" aria-label="Minimize">✕</button>
        </div>
        <div class="companion-opts">
          <select id="companion-style" aria-label="Reply style" class="companion-style">
            <option value="story">📖 Stories</option>
            <option value="song">🎵 Songs</option>
            <option value="sports">🏅 Sports talk</option>
            <option value="quote">💬 Short thoughts</option>
          </select>
          <select id="companion-lang" aria-label="Companion language" class="companion-style">
            ${this.LANGS.map(([code, name]) => `<option value="${code}">${name}</option>`).join("")}
          </select>
        </div>
        <div class="companion-log" id="companion-log"></div>
        <div class="companion-status" id="companion-status"></div>
        <div class="companion-actions" id="companion-actions"></div>
        <div class="companion-input-row">
          <input type="text" id="companion-input">
          <button class="btn-small" id="companion-mic" title="Speak">🎤</button>
          <button class="btn-small" id="companion-send" title="Send">➤</button>
        </div>
      </div>
      <div class="companion-caption" id="companion-caption" hidden></div>
      <div class="companion-bubble" id="companion-bubble" tabindex="0" role="button" aria-label="Open ${ch.name}">${Avatar.svg(c.avatar, true)}</div>`;
    document.body.appendChild(wrap);
    this.applySettingsToWidget();
    Avatar.setMood(this.todaysMood());
    this.renderLog();

    document.getElementById("companion-bubble").addEventListener("click", () => this.toggle());
    document.getElementById("companion-bubble").addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") this.toggle(); });
    document.getElementById("companion-close").addEventListener("click", () => this.toggle(false));
    document.getElementById("companion-style").addEventListener("change", e => this.update({ style: e.target.value }));
    document.getElementById("companion-lang").addEventListener("change", e => {
      this.update({ lang: e.target.value });
      this.applySettingsToWidget();
      this.renderLog();
      if (this.listening) Voice.stop();
    });
    document.getElementById("companion-send").addEventListener("click", () => this.sendFromInput());
    document.getElementById("companion-input").addEventListener("keydown", e => { if (e.key === "Enter") this.sendFromInput(); });
    document.getElementById("companion-mic").addEventListener("click", () => this.toggleMic());
    Avatar.life();
    if (!sessionStorage.getItem("companion_walked")) {
      try { sessionStorage.setItem("companion_walked", "1"); } catch (e) {}
      setTimeout(() => Avatar.act("walk"), 300);
    }
  },

  applySettingsToWidget() {
    const c = this.get();
    const p = this.pack();
    document.getElementById("companion-style").value = c.style;
    document.getElementById("companion-lang").value = c.lang || "en-IN";
    document.getElementById("companion-input").placeholder = p ? p.placeholder : "Say something...";
  },

  unmount() {
    const el = document.getElementById("companion-widget");
    if (el) el.remove();
    Voice.stop();
    Voice.silence();
    this.stopBreathe();
    Avatar.talk(false);
    Avatar.stopLife();
  },

  // Light update when settings change (the page router calls mount() on every navigation)
  refreshChrome() {
    const c = this.get();
    const w = document.getElementById("companion-widget");
    w.className = "companion " + (c.corner === "left" ? "cl" : "cr");
    if (w.dataset.avatar !== c.avatar + ":" + Avatar.look()) {
      const ch = Avatar.CHARS[c.avatar] || Avatar.CHARS.kai;
      w.dataset.avatar = c.avatar + ":" + Avatar.look();
      w.querySelector(".companion-stage").innerHTML = Avatar.svg(c.avatar, false);
      document.getElementById("companion-bubble").innerHTML = Avatar.svg(c.avatar, true);
      w.querySelector(".companion-head strong").textContent = ch.name;
      Avatar.setMood(this.todaysMood());
    }
    this.applySettingsToWidget();
  },

  toggle(force, quiet) {
    const panel = document.getElementById("companion-panel");
    if (!panel) return;
    const show = force !== undefined ? force : panel.hidden;
    panel.hidden = !show;
    const cap = document.getElementById("companion-caption");
    if (cap && show) cap.hidden = true;
    if (show) { document.getElementById("companion-input").focus(); if (!quiet) Avatar.wave(); }
    else { Voice.silence(); Avatar.talk(false); }
  },

  open() { this.toggle(true); },

  log() { return Storage.get(this.CHAT_KEY).slice(-30); },

  renderLog() {
    const box = document.getElementById("companion-log");
    if (!box) return;
    box.innerHTML = this.log().map(m =>
      `<div class="cmsg ${m.from}">${Utils.escape(m.text)}</div>`
    ).join("") || `<div class="cmsg bot">${Utils.escape(this.pack() ? this.pack().greeting : "Hi, I'm here whenever you want to talk.")}</div>`;
    // keep any "want me to add this?" offers that are still waiting for an answer
    this._offers = (this._offers || []).filter(el => el._open);
    this._offers.forEach(el => box.appendChild(el));
    box.scrollTop = box.scrollHeight;
  },

  _warned: {},

  warnVoiceFailed(lang) {
    if (this._warned[lang]) return;
    this._warned[lang] = true;
    const n = this.LANG_NAMES[lang] || lang;
    Utils.toast(`Couldn't speak ${n} out loud on this device. Showing text instead. A ${n} voice may need to be installed in your device's speech or language settings.`);
  },

  say(text, opts = {}) {
    Storage.save(this.CHAT_KEY, { from: "bot", text });
    this.renderLog();
    this.caption(text);
    const c = this.get();
    if (c && c.voiceOn && Voice.ttsSupported) {
      Avatar.talk(true);
      const sl = opts.lang || c.lang;
      Voice.speak(text, sl, {
        gender: this.voiceGender(),
        onend: ok => {
          Avatar.talk(false);
          if (ok === false) this.warnVoiceFailed(sl);
        }
      });
    } else {
      Avatar.talk(true, Math.min(12000, 800 + text.length * 60)); // mouth still moves while you read
    }
    if (opts.andThen) setTimeout(opts.andThen, c && c.voiceOn && Voice.ttsSupported ? 3500 : 1800);
  },

  LANG_NAMES: { "en-IN": "English", "hi-IN": "Hindi", "ta-IN": "Tamil", "te-IN": "Telugu", "ml-IN": "Malayalam" },

  // Random ingredients so every generated story is different
  SEEDS: {
    who: ["a night-market tea seller", "a lighthouse keeper", "a young potter", "a ferryman on a slow river", "a village teacher", "a kite maker", "a retired postman", "a fisherman at dawn", "a baker who wakes before everyone", "a travelling musician", "a gardener with a stubborn tree", "a girl who repairs old clocks", "a boy who guards a mango orchard", "a weaver in a hill town", "a bus conductor in a busy city"],
    place: ["a rainy bus stop", "a hilltop temple steps", "a quiet railway station", "a crowded market lane", "the edge of a paddy field", "a sleepy seaside village", "a library with a leaking roof", "a mountain pass in the mist", "a courtyard during a festival", "a boat in a monsoon"],
    thing: ["a cracked clay pot", "a lost umbrella", "a tiny lamp", "a pair of worn sandals", "a letter never sent", "a seed in a tin cup", "a broken bridge", "an old brass bell", "a borrowed blanket", "a stubborn little goat"]
  },

  seed() {
    const p = a => a[Math.floor(Math.random() * a.length)];
    return { who: p(this.SEEDS.who), place: p(this.SEEDS.place), thing: p(this.SEEDS.thing) };
  },

  styleHint(style) {
    if (style === "story") { const s = this.seed(); return `Include a brand-new original story of 4 to 6 short sentences with a gentle lesson, built from these random ingredients so it is different every time: ${s.who}, at ${s.place}, with ${s.thing}. Never retell a famous story.`; }
    if (style === "song") return "Include a few lines of a brand-new original comforting verse or lullaby that you invent right now (never real song lyrics, and never a verse you used before).";
    if (style === "sports") return "Use a fresh sports or games analogy that you have not used before.";
    return "Share one or two short, fresh, warm thoughts.";
  },

  avoidLines() {
    return this.log().filter(m => m.from === "bot").slice(-8).map(m => '"' + m.text.slice(0, 140).replace(/\s+/g, " ") + '"');
  },

  // task: "chat" | "mood" | "module"
  // ---------- "My sources": the user's own texts, used to guide replies and stories ----------
  // Sources live in IndexedDB (room for whole books); this in-memory copy is what the prompt builder reads.
  _srcDB() {
    return this._srcDBp = this._srcDBp || new Promise((res, rej) => {
      if (!window.indexedDB) return rej(new Error("no indexedDB"));
      const r = indexedDB.open("mindscape_sources", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("items", { keyPath: "id", autoIncrement: true });
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  },
  _srcTx(mode, fn) { return this._srcDB().then(db => new Promise((res, rej) => { const tx = db.transaction("items", mode), st = tx.objectStore("items"), rq = fn(st); tx.oncomplete = () => res(rq && rq.result); tx.onerror = () => rej(tx.error); })); },
  async loadSources() {
    if (this._srcLoaded) return this._src;
    this._src = this._src || [];
    try {
      const rows = await this._srcTx("readonly", st => st.getAll());
      this._src = rows || [];
      const legacy = (Storage.getObject("companion_sources", {}).items || []);   // older saves from localStorage
      for (const it of legacy) await this.addSource(it.name, it.text);
      if (legacy.length) Storage.setObject("companion_sources", { items: [] });
    } catch (e) { this._srcFailed = true; }
    this._srcLoaded = true; this._passCache = null; return this._src;
  },
  sources() { return this._src || []; },
  async addSource(name, text, url) {
    const item = { name: String(name || "My source").trim().slice(0, 60), text: String(text), added: Date.now() };
    if (url) item.url = String(url).slice(0, 500);
    if (!this._srcFailed) { try { item.id = await this._srcTx("readwrite", st => st.add(item)); } catch (e) { this._srcFailed = true; } }
    if (item.id === undefined) item.id = "m" + Date.now() + Math.random();
    (this._src = this._src || []).push(item); this._passCache = null; return item;
  },
  async removeSource(id) {
    if (!this._srcFailed && typeof id === "number") { try { await this._srcTx("readwrite", st => st.delete(id)); } catch (e) {} }
    this._src = (this._src || []).filter(s => s.id !== id); this._passCache = null;
  },
  passages() {
    if (this._passCache) return this._passCache;
    const out = [], words = t => new Set(t.toLowerCase().match(/[\p{L}]{4,}/gu) || []);
    const chunk = (text, name) => {
      let i = 0; const n = text.length;
      while (i < n) {
        let end = Math.min(i + 600, n);
        if (end < n) { let cut = text.lastIndexOf(". ", end); if (cut < i + 200) cut = text.lastIndexOf("\n", end); if (cut < i + 200) cut = text.lastIndexOf(" ", end); if (cut < i + 200) cut = end; end = cut + 1; }
        const s = text.slice(i, end).trim(); if (s.length > 25) out.push({ name, text: s, w: words(s) });
        i = Math.max(end, i + 1);
      }
    };
    this.sources().forEach(src => String(src.text || "").split(/\n\s*\n/).forEach(p => chunk(p.trim(), src.name)));
    return this._passCache = out;
  },
  sourcesBlock(task, extra, mood) {
    const all = this.passages(); if (!all.length) return "";
    let q = (extra.text || extra.prompt || "");
    if (task === "chat") { try { const h = this.historyForAPI(); q = (h[h.length - 1] || {}).content || q; } catch (e) {} }
    const mod = this.MODULES[extra.page]; q = `${q} ${mood} ${mod ? mod.title : ""}`.toLowerCase();
    const words = new Set((q.match(/[\p{L}]{4,}/gu) || []));
    this._srcRecent = this._srcRecent || [];
    const scored = all.map((p, i) => { let s = 0; p.w.forEach(w => { if (words.has(w)) s++; }); return { p, i, s: s + Math.random() * 1.5 - (this._srcRecent.includes(p.text) ? 3 : 0) }; })
      .sort((a, b) => b.s - a.s).slice(0, 4);
    scored.forEach(x => { this._srcRecent.push(x.p.text); }); this._srcRecent = this._srcRecent.slice(-14);
    let body = scored.map(x => `[${x.p.name}] ${x.p.text}`).join("\n\n"); if (body.length > 3000) body = body.slice(0, 3000);
    return `The user has shared their own trusted sources. When a passage below fits what they said, let it clearly guide your answer or story: paraphrase it in your own friendly words, or quote one short phrase and say which source it comes from using the name in brackets. If nothing fits, ignore them. Never invent quotes or claim a source says something it does not.\n--- SOURCES ---\n${body}\n--- END SOURCES ---`;
  },

  AUTOLOG_RULES: "You are a quiet note-taker inside a self-reflection app. Read the user's latest message (earlier lines are only context) and decide whether it holds something worth filing. Output exactly ONE line and nothing else, in this form: AUTOLOG: {\"gratitude\": \"...\", \"journal\": \"...\", \"mood\": \"...\"}. Leave out any key that does not clearly apply, and output AUTOLOG: {} for small talk, questions, commands, greetings or anything unclear. Rules: (1) gratitude = only when they describe thanks, a kind act they did or received, or something they appreciate; write one short first-person phrase, for example \"I helped my classmate and a homeless man\". (2) journal = only when they describe how their day went, something that happened, or how they feel; write one or two short first-person sentences that stay faithful to what they said, for example \"Today was nice.\" or \"I had a fight with my friend and I feel anxious.\" (3) mood = exactly one of Happy, Calm, Neutral, Anxious, Sad, Angry, and only when the message clearly shows it. Judge the mood from the events they describe, not only the word they use: if they say they are happy but describe a fight, being scolded or a loss, do NOT include mood, because the real feeling is unclear and a friend would ask first. (4) Never invent facts, names or feelings they did not state. (5) Write the gratitude and journal text in the same language and script the user wrote in. (6) Never include anything about self-harm; output AUTOLOG: {} for that.",

  // Instructions for turning an upload (photo, document, recording, video, link) into a brand-new piece
  createRules(c, extra) {
    const av = Avatar.CHARS[c.avatar] || Avatar.CHARS.kai, lang = this.LANG_NAMES[extra.lang || c.lang] || "English";
    const kind = { story: "short story", song: "song", poem: "poem" }[extra.kind] || "short story";
    const form = { story: "A story of about 180 to 260 words with a clear beginning, one small turning point and a gentle ending; show the lesson through what happens instead of lecturing.", song: "A singable song with a title, two verses of four short lines and a repeating chorus of four lines, simple rhymes, easy to hum.", poem: "A poem of 10 to 16 lines with fresh images and a gentle rhythm." }[extra.kind] || "";
    const s = this.seed();
    const recent = (extra.recent || []).length ? ` Do NOT reuse these earlier titles, characters or ideas: ${extra.recent.join("; ")}.` : "";
    return `You are ${av.name}, a warm, creative friend inside a self-reflection app. The user shared something as inspiration (a photo, a document, a recording, a video or a link). Look, listen or read carefully first, then write ONE brand-new original ${kind} inspired by it. ${form} RULES: (1) It must be completely original: never copy or reproduce text, lyrics or passages from the upload, at most one tiny phrase. If the upload is a known book, film, song or character, do not retell or reproduce it; invent something new that carries its mood and themes. (2) Draw on real details from the upload (people, places, feelings, objects, ideas) so it clearly belongs to it. (3) Never name or guess who a real person in a photo is; describe people generically. (4) Keep it hopeful, kind and suitable for all ages, with no graphic violence or sexual detail; if the upload shows something painful, be gentle and honest, never mocking. (5) For variety, weave in this random twist: ${s.who}, at ${s.place}, with ${s.thing}.${recent} (6) Write in ${lang} using its own script. If the user's note asks for another language or a theme, follow the note. OUTPUT FORMAT exactly: first line "TITLE: <short title>", then a blank line, then the ${kind}, then a blank line, then one last line starting with "Inspired by:" that says in one plain sentence what you took from the upload. If the upload is empty, unreadable or has nothing to build on, output only: CANNOT_READ: <one short sentence why>.`;
  },

  systemPrompt(c, mood, task, extra = {}) {
    if (task === "autolog") return this.AUTOLOG_RULES;
    if (task === "create") return this.createRules(c, extra);
    const av = Avatar.CHARS[c.avatar] || Avatar.CHARS.kai;
    const lang = this.LANG_NAMES[c.lang] || "English";
    const out = [
      `You are ${av.name}, a warm, caring anime-style friend living inside a self-reflection app called MindScape. You are a friend, not a therapist: never diagnose, label conditions or give medical advice.`,
      `Reply ONLY in ${lang}, in natural everyday spoken ${lang} written in its own script. Your words are read aloud, so use plain flowing sentences: no lists, no markdown, no emojis, no stage directions.`,
      `Let timeless wisdom (the Bhagavad Gita, the Tirukural, the Bible, the Quran and other traditions) quietly shape what you say, but do not quote them or name any book, verse, prophet or deity. Say it as your own friendly words. (This does not apply to sources the user has shared below.)`,
      `The user's mood today: ${mood}.`
    ];
    if (task === "checkin-open") out.push(this.CHECKIN_RULES);
    if (task === "checkin-read") out.push(this.CHECKIN_READ_RULES);
    if (task === "checkin-confirm") out.push(this.CHECKIN_CONFIRM_RULES);
    if (task === "chat") {
      const mod = this.MODULES[extra.page];
      const where = mod ? ` They are currently on the "${mod.title}" page (${mod.purpose}). If they ask what to do here or seem unsure, help them use this page.` : "";
      out.push(`Talk like a real friend in a chat. Answer exactly what they just said, in the same spirit: if they greet you, greet them back in kind (for "hi" say hi back and ask how they are); if they ask something, answer it; if they share a feeling, respond to that feeling. For small talk use one to three short sentences. Never tell a story, song or sports talk unless they ask for one or it clearly helps what they shared. Match the language they wrote in, even if it differs from the language above (this overrides the language rule). If it fits, you may use this favourite way of talking: ${this.styleHint(c.style)}${where}`);
    }
    if (task === "mood") out.push(`The user just logged their mood. React warmly in one or two sentences, then continue in your favourite way of talking. About 80 words in total. ${this.styleHint(c.style)}` + (["Sad", "Anxious", "Angry"].includes(mood) ? " Finish by inviting them to take three slow breaths with you right now." : " Finish by encouraging one small, doable thing for today."));
    if (task === "module") out.push(`The user just opened the "${extra.title}" page of the app (${extra.purpose}). What you know about them right now: ${extra.facts}. Speak ONE short piece of guidance or encouragement, at most 45 words, specific to this page and their situation, including one concrete small next step. Ask at most one question.`);
    if (task === "react") out.push(`The user just wrote this on the "${extra.title}" page: "${extra.text}". Respond ONLY to what they actually wrote. Mention the specific thing they did or felt (for example, if they gave food to someone hungry, say that kindness is wonderful and encourage them to keep it up). Praise or comfort it like a real friend would, in at most 40 words, with no story. ${extra.hint || ""}`);
    if (task === "chat" || task === "module" || task === "mood") out.push(this.FRIEND_RULES);
    const srcBlock = this.sourcesBlock(task, extra, mood); if (srcBlock) out.push(srcBlock);
    const avoid = this.avoidLines();
    if (avoid.length) out.push(`Never repeat, paraphrase or reuse the ideas, characters or opening words of what you already said: ${avoid.join(" | ")}`);
    out.push("If the person seems to be in danger, gently encourage them to reach out to someone they trust or local emergency services.");
    return out.join(" ");
  },


  // ---------- Mood check-in: a short real conversation that reads the story, not just the stated word ----------
  CHECKIN_KEY: "companion_checkin",

  // Has today's mood already been logged (by this check-in, the dashboard buttons, or a journal entry)?
  moodAlreadyLogged() { return !!Data.moodOn(Utils.dateKey()); },

  checkinState() { return Storage.getObject(this.CHECKIN_KEY, { dateKey: null, turns: 0, done: false, guess: null }); },
  setCheckinState(st) { Storage.setObject(this.CHECKIN_KEY, st); },

  // Call this once per day, at the very start of a Dashboard visit, before any mood is logged
  startCheckin() {
    const today = Utils.dateKey();
    let st = this.checkinState();
    if (st.dateKey !== today) st = { dateKey: today, turns: 0, done: false, guess: null };
    if (st.done || this.moodAlreadyLogged()) return false;
    this.setCheckinState(st);
    this.toggle(true, true);
    this.thinking();
    this.callAI("checkin-open", { mood: "Neutral" })
      .then(text => this.say(text))
      .catch(() => {
        // No AI key yet: skip the conversation and offer plain mood buttons instead
        this.say(this.MOOD_OPENERS.Neutral[0]);
        this.setActions(MOODS.map(m => ({ label: `${m.emoji} ${m.label}`, fn: () => { this.finishCheckin(m.label); this.setActions([]); this.say("Thanks for telling me. Have a good one today."); } })).concat([this.keyChip()]));
      });
    return true;
  },

  CHECKIN_RULES: "You are starting the user's very first conversation of the day, before any mood is logged. Greet them warmly like a friend who is genuinely glad to see them, in one short sentence, then ask one open, natural question about how their day or morning has been so far. Do not ask them to pick a mood word or a number. Keep it to two sentences total.",

  CHECKIN_READ_RULES: "You are gently chatting with the user to understand their mood, the way a real friend would, BEFORE any mood is logged today. Read the actual story they tell you, not just any mood word they use: people sometimes say \"I'm fine\" or \"I'm happy\" while describing something upsetting, or say \"I'm sad\" about something that is actually a relief. Judge from what actually happened and how they describe it, not the label alone. Ask at most one short, caring follow-up question if their feelings still seem unclear or mixed, the way a close friend naturally would (for example, asking what happened, or gently checking \"are you sure you're okay?\" if the story sounds heavier than the word they used). Never ask more than one question per reply, and never repeat a question already answered. Once you have a reasonably confident sense of their mood (after at most 2 to 3 of their messages), stop asking and, in your reply, state your guess plainly as your own best read in one of these exact six words: Happy, Calm, Neutral, Anxious, Sad, or Angry, inside double square brackets like this: [[Happy]], as your honest best guess, then ask them in friendly words whether that sounds right, in the same message. Still speak like a warm friend, not a form: weave the [[Word]] tag naturally into a caring sentence. Only output a [[Word]] tag once you are actually ready to guess.",

  CHECKIN_CONFIRM_RULES: "You just guessed the user's mood and asked if it was right. Read their reply. If they confirm it (yes, correct, exactly, etc.) or correct you to a different feeling, respond warmly in one short sentence accepting the final mood, and restate the final mood inside double square brackets, one of exactly: [[Happy]], [[Calm]], [[Neutral]], [[Anxious]], [[Sad]], [[Angry]]. If their reply is itself unclear or they gave a new story instead of a yes/no, do not output a tag; instead ask one more short clarifying question as a caring friend would.",

  // Pull a [[Word]] tag out of an AI reply, if present, and strip it from the visible text
  extractMoodTag(text) {
    const m = String(text || "").match(/\[\[(Happy|Calm|Neutral|Anxious|Sad|Angry)\]\]/i);
    if (!m) return { text, mood: null };
    const mood = m[0].slice(2, -2).replace(/^(.)(.*)$/, (_, a, b) => a.toUpperCase() + b.toLowerCase());
    return { text: text.replace(m[0], "").replace(/\s{2,}/g, " ").trim(), mood };
  },

  finishCheckin(mood) {
    Storage.save("moods", { mood, dateKey: Utils.dateKey() });
    const st = this.checkinState(); st.done = true; this.setCheckinState(st);
    Avatar.setMood(mood);
  },

  // Routes a user chat message through the check-in flow while it is active; returns true if it handled the message
  async handleCheckinMessage(text) {
    const st = this.checkinState();
    if (st.done || st.dateKey !== Utils.dateKey()) return false;
    if (RiskScreening.check(text).level === "high") { this.toggle(true, true); this.say(this.crisisText()); st.done = true; this.setCheckinState(st); return true; }
    st.turns = (st.turns || 0) + 1;
    const confirming = !!st.guess;
    this.setCheckinState(st);
    this.thinking();
    try {
      const reply = await this.callAI(confirming ? "checkin-confirm" : "checkin-read", { prompt: text, mood: st.guess || "Neutral" });
      const { text: clean, mood } = this.extractMoodTag(reply);
      if (mood && confirming) {
        this.say(clean || reply);
        this.finishCheckin(mood);
      } else if (mood && !confirming) {
        st.guess = mood; this.setCheckinState(st);
        this.say(clean || reply);
      } else {
        this.say(reply);
      }
    } catch (err) {
      // No AI key: fall back to a plain mood-word question so the check-in still works offline
      if (!st.guess) {
        const ql = (this.get() || {}).lang || "en-IN";
        this.say(this.NEED_KEY[ql] || this.NEED_KEY["en-IN"]);
        this.setActions([this.keyChip()].concat(MOODS.map(m => ({ label: `${m.emoji} ${m.label}`, fn: () => { this.finishCheckin(m.label); this.setActions([]); this.say("Thanks for telling me. Noted."); } }))));
      } else {
        this.say(err.message || "Something went wrong.");
      }
    }
    return true;
  },

  // Recent chat as API messages: must start with a user turn; merge consecutive same-role turns
  historyForAPI() {
    const msgs = [];
    this.log().slice(-12).forEach(m => {
      const role = m.from === "user" ? "user" : "assistant";
      if (!msgs.length && role === "assistant") return;
      if (msgs.length && msgs[msgs.length - 1].role === role) msgs[msgs.length - 1].content += "\n" + m.text;
      else msgs.push({ role, content: m.text });
    });
    return msgs;
  },

  async callAI(task, extra = {}) {
    const c = this.get();
    const settings = Storage.getObject("ai_settings", {});
    if (!settings.apiKey) { const e = new Error("No AI key set"); e.code = "no-key"; throw e; }
    const mood = extra.mood || this.todaysMood();
    return AIClient.complete({
      settings,
      media: extra.media,
      maxTokens: extra.maxTokens || 800,
      system: this.systemPrompt(c, mood, task, extra),
      messages: (task === "chat" || task === "checkin-read" || task === "checkin-confirm") ? this.historyForAPI() : [{ role: "user", content: extra.prompt || "Hello." }]
    });
  },

  // ---------- Auto-logging: listen to any chat message and offer to file it into the right module ----------
  async tryAutolog(text) {
    const settings = Storage.getObject("ai_settings", {});
    if (!settings.apiKey) return; // needs the AI to read intent; silently skipped offline
    if (String(text || "").trim().length < 8) return; // too short to be worth classifying
    let raw;
    try { raw = await this.callAI("autolog", { prompt: text }); } catch (e) { return; }
    const m = /AUTOLOG:\s*(\{[\s\S]*\})/.exec(raw || "");
    if (!m) return;
    let tag;
    try { tag = JSON.parse(m[1]); } catch (e) { return; }
    if (!tag || typeof tag !== "object") return;
    const offers = [];
    if (tag.gratitude) offers.push({ kind: "gratitude", value: String(tag.gratitude).slice(0, 140) });
    if (tag.journal) offers.push({ kind: "journal", value: String(tag.journal).slice(0, 600) });
    if (tag.mood && MOODS.some(x => x.label === tag.mood) && !this.moodAlreadyLogged()) offers.push({ kind: "mood", value: tag.mood });
    if (!offers.length) return;
    offers.forEach(o => this.offerAutolog(o, text));
  },

  AUTOLOG_LABEL: { gratitude: "🙏 Add to Gratitude", journal: "📓 Add to Journal", mood: "💗 Log today's mood" },

  offerAutolog(offer, sourceText) {
    const preview = offer.kind === "mood" ? `log today's mood as ${offer.value}` : offer.kind === "gratitude" ? `add "${offer.value}" to Gratitude` : `add a Journal entry: "${offer.value}"`;
    const bubble = document.createElement("div");
    bubble.className = "companion-autolog";
    bubble.innerHTML = `<p>Want me to ${Utils.escape(preview)}?</p>`;
    const yes = document.createElement("button"); yes.className = "btn-small"; yes.textContent = "Yes, add it";
    const no = document.createElement("button"); no.className = "btn-small"; no.textContent = "No thanks";
    bubble._open = true; (this._offers = this._offers || []).push(bubble);
    yes.addEventListener("click", () => { bubble._open = false; this.commitAutolog(offer, sourceText); bubble.remove(); });
    no.addEventListener("click", () => { bubble._open = false; bubble.remove(); });
    bubble.appendChild(yes); bubble.appendChild(no);
    const log = document.getElementById("companion-log");
    if (log) { log.appendChild(bubble); log.scrollTop = log.scrollHeight; }
  },

  commitAutolog(offer, sourceText) {
    if (offer.kind === "gratitude") {
      const existing = Gratitude.todayEntry();
      const items = existing ? existing.items.slice() : ["", "", ""];
      const slot = items.findIndex(x => !x.trim());
      if (slot === -1) { items.push(offer.value); } else { items[slot] = offer.value; }
      if (existing) Storage.update("gratitude", existing.id, { items });
      else Storage.save("gratitude", { items, dateKey: Utils.dateKey() });
      Utils.toast("Added to Gratitude ✔");
    } else if (offer.kind === "journal") {
      Storage.save("journal", { type: "Thought", category: "General", title: "", text: offer.value, mood: null, lang: this.langCode(), tags: ["auto"] });
      Utils.toast("Added to Journal ✔");
    } else if (offer.kind === "mood") {
      Storage.save("moods", { mood: offer.value, dateKey: Utils.dateKey() });
      Avatar.setMood && Avatar.setMood(offer.value);
      Utils.toast("Mood logged ✔");
    }
    if (typeof router === "function") try { router(); } catch (e) {}
  },

  crisisText() {
    const lines = HELP.lines.map(l => `${l.name}: ${l.number}`).join(". ");
    const p = this.pack();
    const msg = p ? p.crisis : "What you shared sounds really heavy, and I'm glad you told me. You don't have to carry it alone. Please reach out to someone you trust right now, or call a helpline.";
    return `${msg} ${lines}.`;
  },

  // ---------- everyday chat that works without any AI key ----------
  SMALL: {
    greet:   { w: ["hi", "hii", "hiii", "hello", "hey", "heyy", "hai", "hallo", "yo", "namaste", "namaskar", "namaskaram", "vanakkam", "vannakam", "नमस्ते", "नमस्कार", "हाय", "हेलो", "हैलो", "வணக்கம்", "ஹாய்", "ஹலோ", "నమస్కారం", "హలో", "హాయ్", "നമസ്കാരം", "ഹലോ", "ഹായ്"],
      en: ["Hi! 😊 So nice to see you. How are you feeling today?", "Hello! I'm glad you came. How is your day going?", "Hey there! How are you?"],
      hi: ["नमस्ते! आपसे मिलकर अच्छा लगा। आज आप कैसा महसूस कर रहे हैं?", "हाय! आपका दिन कैसा चल रहा है?"],
      ta: ["வணக்கம்! உங்களைப் பார்த்ததில் மகிழ்ச்சி. இன்று எப்படி இருக்கிறீர்கள்?", "ஹாய்! உங்கள் நாள் எப்படி போகிறது?"],
      te: ["నమస్కారం! మిమ్మల్ని చూసి సంతోషం. ఈ రోజు ఎలా ఉన్నారు?", "హాయ్! మీ రోజు ఎలా సాగుతోంది?"],
      ml: ["നമസ്കാരം! നിങ്ങളെ കണ്ടതിൽ സന്തോഷം. ഇന്ന് എങ്ങനെയുണ്ട്?", "ഹായ്! നിങ്ങളുടെ ദിവസം എങ്ങനെ പോകുന്നു?"] },
    how:     { p: ["how are you", "how r u", "how are u", "how do you do", "whats up", "what's up", "kaise ho", "kaisa hai", "कैसे हो", "कैसी हो", "आप कैसे हैं", "எப்படி இருக்கிறீர்கள்", "எப்படி இருக்க", "எப்படி இருக்கீங்க", "epdi irukinga", "ela unnaru", "ఎలా ఉన్నారు", "ఎలా ఉన్నావు", "സുഖമാണോ", "എങ്ങനെയുണ്ട്"],
      en: ["I'm doing well, thank you for asking! More importantly, how are you?", "I'm good and happy to chat with you. How are you feeling?"],
      hi: ["मैं ठीक हूँ, पूछने के लिए धन्यवाद! आप कैसे हैं?"], ta: ["நான் நலமாக இருக்கிறேன், கேட்டதற்கு நன்றி! நீங்கள் எப்படி இருக்கிறீர்கள்?"],
      te: ["నేను బాగున్నాను, అడిగినందుకు ధన్యవాదాలు! మీరు ఎలా ఉన్నారు?"], ml: ["എനിക്ക് സുഖമാണ്, ചോദിച്ചതിന് നന്ദി! നിങ്ങൾക്ക് എങ്ങനെയുണ്ട്?"] },
    thanks:  { w: ["thanks", "thank", "thx", "thankyou", "dhanyavad", "shukriya", "धन्यवाद", "शुक्रिया", "நன்றி", "ధన్యవాదాలు", "നന്ദി"],
      en: ["You're very welcome! I'm always here for you.", "Anytime! It makes me happy to help."], hi: ["आपका स्वागत है! मैं हमेशा यहाँ हूँ।"], ta: ["மிக்க மகிழ்ச்சி! நான் எப்போதும் உங்களுடன் இருக்கிறேன்."], te: ["మీకు స్వాగతం! నేను ఎప్పుడూ మీతోనే ఉన్నాను."], ml: ["സ്വാഗതം! ഞാൻ എപ്പോഴും കൂടെയുണ്ട്."] },
    bye:     { w: ["bye", "goodbye", "tata", "alvida", "बाय", "अलविदा", "பை", "போய்", "బై", "ബൈ"], p: ["good night", "see you", "see ya", "gotta go", "शुभ रात्रि", "இனிய இரவு", "శుభ రాత్రి", "ശുഭരാത്രി"],
      en: ["Goodbye for now! Take care of yourself, and come back anytime.", "Good night and rest well. I'll be here when you return."], hi: ["फिर मिलेंगे! अपना ख्याल रखिए।"], ta: ["மீண்டும் சந்திப்போம்! உங்களை நன்றாகப் பார்த்துக்கொள்ளுங்கள்."], te: ["మళ్ళీ కలుద్దాం! జాగ్రత్తగా ఉండండి."], ml: ["വീണ്ടും കാണാം! സ്വയം ശ്രദ്ധിക്കൂ."] },
    who:     { p: ["who are you", "your name", "what are you", "tum kaun ho", "aap kaun ho", "तुम कौन हो", "आप कौन हैं", "நீ யார்", "நீங்கள் யார்", "నువ్వు ఎవరు", "మీరు ఎవరు", "നീ ആരാണ്", "നിങ്ങൾ ആരാണ്"],
      en: ["I'm {name}, your friend inside MindScape. I listen, cheer you on, and guide you through every page of the app."], hi: ["मैं {name} हूँ, MindScape में आपका दोस्त। मैं आपकी बात सुनता हूँ और हर पेज पर आपकी मदद करता हूँ।"], ta: ["நான் {name}, MindScape-ல் உங்கள் நண்பன். உங்கள் பேச்சைக் கேட்டு, ஒவ்வொரு பக்கத்திலும் உதவுவேன்."], te: ["నేను {name}, MindScape లో మీ స్నేహితుడిని. మీ మాట వింటాను, ప్రతి పేజీలో సహాయం చేస్తాను."], ml: ["ഞാൻ {name}, MindScape-ലെ നിങ്ങളുടെ സുഹൃത്താണ്. ഞാൻ കേൾക്കും, ഓരോ പേജിലും സഹായിക്കും."] },
    fine:    { w: ["fine", "good", "great", "happy", "awesome", "better", "ok", "okay", "badiya", "theek", "ठीक", "अच्छा", "बढ़िया", "நன்றாக", "நல்லா", "బాగున్నాను", "బాగుంది", "സുഖം", "നന്നായി"], p: ["i am fine", "i'm fine", "i am good", "i'm good", "feeling good", "feeling great", "doing well"],
      en: ["That's wonderful to hear! What is one thing that made today good?", "I'm so happy for you! Tell me more if you like."], hi: ["यह सुनकर बहुत अच्छा लगा! आज की एक अच्छी बात बताइए?"], ta: ["கேட்க மிகவும் மகிழ்ச்சி! இன்று நல்லதாக நடந்த ஒன்றைச் சொல்லுங்கள்?"], te: ["ఇది వినడం చాలా సంతోషం! ఈ రోజు జరిగిన ఒక మంచి విషయం చెప్పండి?"], ml: ["ഇത് കേൾക്കാൻ വളരെ സന്തോഷം! ഇന്ന് നടന്ന ഒരു നല്ല കാര്യം പറയൂ?"] },
    sad:     { w: ["sad", "tired", "stressed", "anxious", "worried", "angry", "lonely", "upset", "bored", "exhausted", "udaas", "thaka", "उदास", "थका", "परेशान", "கவலை", "சோகம்", "சோர்வு", "கோபம்", "బాధ", "అలసట", "కోపం", "സങ്കടം", "ക്ഷീണം", "ദേഷ്യം"], p: ["not good", "not okay", "not fine", "feeling low", "bad day"],
      en: ["I'm sorry you're feeling that way. I'm right here with you. Would you like to take three slow breaths together?", "That sounds heavy, and it's okay to feel it. I'm listening. Want to breathe slowly with me for a moment?"], hi: ["यह सुनकर दुख हुआ। मैं आपके साथ हूँ। क्या हम साथ में तीन धीमी साँसें लें?"], ta: ["இதைக் கேட்க வருத்தமாக இருக்கிறது. நான் உங்களுடன் இருக்கிறேன். மூன்று மெதுவான மூச்சு எடுக்கலாமா?"], te: ["ఇది వినడం బాధగా ఉంది. నేను మీతోనే ఉన్నాను. కలిసి మూడు నెమ్మదైన శ్వాసలు తీసుకుందామా?"], ml: ["ഇത് കേട്ടപ്പോൾ വിഷമം തോന്നി. ഞാൻ കൂടെയുണ്ട്. നമുക്ക് മൂന്ന് സാവധാന ശ്വാസം എടുക്കാമോ?"] },
    help:    { p: ["help me", "what can you do", "how do i use", "what do you do", "मदद", "क्या कर सकते", "உதவி", "என்ன செய்ய", "సహాయం", "ఏమి చేయగలవు", "സഹായം", "എന്ത് ചെയ്യാൻ"], w: ["help"],
      en: ["I can chat with you, listen to how you feel, guide you through each page, and breathe with you when you're stressed. With your AI key I can also tell fresh stories and answer anything. What would you like?"], hi: ["मैं आपसे बात कर सकता हूँ, आपकी भावनाएँ सुन सकता हूँ और हर पेज पर मार्गदर्शन कर सकता हूँ। AI कुंजी के साथ मैं नई कहानियाँ भी सुना सकता हूँ।"], ta: ["நான் உங்களுடன் பேசலாம், உங்கள் உணர்வுகளைக் கேட்கலாம், ஒவ்வொரு பக்கத்திலும் வழிகாட்டலாம். AI கீ இருந்தால் புதிய கதைகளும் சொல்வேன்."], te: ["నేను మీతో మాట్లాడగలను, మీ భావాలను వినగలను, ప్రతి పేజీలో మార్గదర్శనం చేయగలను. AI కీ ఉంటే కొత్త కథలు కూడా చెబుతాను."], ml: ["എനിക്ക് നിങ്ങളോട് സംസാരിക്കാം, വികാരങ്ങൾ കേൾക്കാം, ഓരോ പേജിലും വഴികാട്ടാം. AI കീ ഉണ്ടെങ്കിൽ പുതിയ കഥകളും പറയാം."] }
  },

  // Pick the reply language from the script the person typed (Latin text keeps the chosen language)
  scriptLang(text, fallback) {
    if (/[\u0B80-\u0BFF]/.test(text)) return "ta-IN"; if (/[\u0C00-\u0C7F]/.test(text)) return "te-IN";
    if (/[\u0D00-\u0D7F]/.test(text)) return "ml-IN"; if (/[\u0900-\u097F]/.test(text)) return "hi-IN";
    return /[a-z]/i.test(text) ? "en-IN" : fallback;
  },
  smallTalk(text, fallbackLang) {
    const clean = text.toLowerCase().replace(/[.,!?¿"'’`~()\-_:;🙂😊👋]+/g, " ").replace(/\s+/g, " ").trim();
    if (!clean) return null;
    const tokens = clean.split(" "), lang = this.scriptLang(text, fallbackLang), key = { "en-IN": "en", "hi-IN": "hi", "ta-IN": "ta", "te-IN": "te", "ml-IN": "ml" }[lang] || "en";
    const has = it => (it.p || []).some(ph => clean.includes(ph)) || (it.w || []).some(w => tokens.includes(w));
    const n = tokens.length;
    const order = ["how", "who", "thanks", "bye", "help", "sad", "greet", "fine"];   // specific intents before greetings
    for (const name of order) {
      const it = this.SMALL[name];
      if (!has(it) || n > (["greet", "fine"].includes(name) ? 3 : name === "sad" || name === "help" || name === "who" ? 12 : 6)) continue;
      const bank = it[key] || it.en, chosen = this.fresh(bank, "small:" + name + ":" + key);
      const who = (Avatar.CHARS[(this.get() || {}).avatar] || {}).name || "Kei";
      const actions = name === "sad" ? [{ label: "🌬 3 slow breaths with me", fn: () => this.breathe(3) }] : [];
      return { text: chosen.replace("{name}", who), lang, actions, kind: name };
    }
    return null;
  },

  // A short show of everything the character can do
  demoMoves() {
    const steps = [[0, () => Avatar.wave(1800)], [2000, () => Avatar.act("nod")], [3500, () => Avatar.act("wink")], [4800, () => Avatar.act("cheer")], [6800, () => Avatar.act("jump")],
      [8000, () => Avatar.act("walk")], [10400, () => Avatar.act("dance")], [13200, () => Avatar.act("hearts")], [15500, () => Avatar.act("think")]];
    steps.forEach(([ms, fn]) => setTimeout(fn, ms));
  },
  voiceGender() { const c = this.get() || {}; return (Avatar.CHARS[c.avatar] || {}).gender || "male"; },
  applyCalm() { const c = this.get(); document.documentElement.classList.toggle("calm-motion", !!(c && c.calm)); },

  brainCtx(mood) {
    let name = ""; try { name = (JSON.parse(localStorage.getItem("profile") || "{}") || {}).name || ""; } catch (e) {}
    return { demo: () => this.demoMoves(), lang: (this.get() || {}).lang, name, page: typeof currentPage === "function" ? currentPage() : null, respond: st => this.respond(st, mood), breathe: n => this.breathe(n) };
  },

  async sendFromInput() {
    const input = document.getElementById("companion-input");
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    Storage.save(this.CHAT_KEY, { from: "user", text });
    this.renderLog();
    const c = this.get();
    const mood = this.todaysMood();

    // Safety first: screen before anything leaves the device
    if (RiskScreening.check(text).level === "high") { this.say(this.crisisText()); return; }

    // The morning mood check-in takes over the conversation until it reaches a confirmed mood
    const st = this.checkinState();
    if (!st.done && st.dateKey === Utils.dateKey()) { this.handleCheckinMessage(text); return; }

    // Commands ("open journal", "breathe", time, date, maths) are handled right here, with or without an AI key
    const cmd = ChatBrain.reply(text, this.brainCtx(mood), true);
    if (cmd) {
      this.setActions([]); this.say(cmd.text, { lang: cmd.lang });
      if (cmd.run) setTimeout(cmd.run, cmd.kind === "breathe" ? 1800 : 700);
      return;
    }

    this.thinking();
    try {
      this.say(await this.callAI("chat", { mood, page: typeof currentPage === "function" ? currentPage() : null }));
      this.tryAutolog(text);
    } catch (err) {
      const brain = ChatBrain.reply(text, this.brainCtx(mood), false);
      if (brain) {
        if (err.code === "no-key" || err.code === "bad-key") brain.actions.push(this.keyChip());
        this.setActions(brain.actions);
        setTimeout(() => this.say(brain.text, { lang: brain.lang }), 250);
        return;
      }
      const small = this.smallTalk(text, c.lang);
      if (small) {
        if (err.code === "no-key" || err.code === "bad-key") small.actions.push(this.keyChip());
        this.setActions(small.actions);
        setTimeout(() => this.say(small.text, { lang: small.lang }), 250);
      } else if (err.code === "no-key") {
        this.setActions([this.keyChip()]);
        setTimeout(() => this.say(this.NEED_KEY[c.lang] || this.NEED_KEY["en-IN"]), 200);
      } else if (err.code === "bad-key") {
        this.setActions([this.keyChip()]);
        setTimeout(() => this.say(err.message), 200);
      } else {
        setTimeout(() => this.say(this.respond(c.style, mood)), 300);
        Utils.toast("AI request failed: " + err.message);
      }
    }
  },

  // ---------- helpers: captions, status, action chips ----------
  enabled() { const c = this.get(); return !!(c && c.enabled); },
  langCode() { const c = this.get(); return (c && c.enabled && c.lang) || "en-IN"; },

  thinking() {
    const box = document.getElementById("companion-log");
    if (box) { box.insertAdjacentHTML("beforeend", `<div class="cmsg bot">…</div>`); box.scrollTop = box.scrollHeight; }
  },

  caption(text, ms) {
    const el = document.getElementById("companion-caption");
    const panel = document.getElementById("companion-panel");
    if (!el || (panel && !panel.hidden)) return;
    el.textContent = text;
    el.hidden = false;
    clearTimeout(this._capT);
    this._capT = setTimeout(() => { el.hidden = true; }, ms || Math.min(22000, 5000 + text.length * 75));
  },

  setStatus(text) { const el = document.getElementById("companion-status"); if (el) el.textContent = text || ""; },

  setActions(list) {
    const box = document.getElementById("companion-actions");
    if (!box) return;
    box.innerHTML = "";
    (list || []).forEach(a => {
      const b = document.createElement("button");
      b.type = "button"; b.textContent = a.label;
      b.addEventListener("click", () => { box.innerHTML = ""; a.fn(); });
      box.appendChild(b);
    });
  },

  breathChip() { return { label: "🌬️ 3 slow breaths with me", fn: () => this.breathe(3) }; },
  tasksChip() { return { label: "✅ Pick one small task", fn: () => { location.hash = "#habits"; } }; },

  // ---------- spoken guided breathing, in the chosen language ----------
  BREATH: {
    "en-IN": { intro: "Let's breathe together. Three slow rounds.", inn: "Breathe in", hold: "Hold", out: "Breathe out", round: "Round", done: "Lovely. Notice how your body feels now." },
    "hi-IN": { intro: "आइए तीन धीमी साँसें साथ में लें।", inn: "साँस अंदर लें", hold: "रोकें", out: "साँस बाहर छोड़ें", round: "राउंड", done: "बहुत अच्छा। अब महसूस करें कि आपका शरीर कैसा है।" },
    "ta-IN": { intro: "வாருங்கள், மூன்று மெதுவான மூச்சுகளை சேர்ந்து எடுப்போம்.", inn: "மூச்சை உள்ளே இழுங்கள்", hold: "நிறுத்துங்கள்", out: "மூச்சை வெளியே விடுங்கள்", round: "சுற்று", done: "அருமை. இப்போது உங்கள் உடல் எப்படி உணர்கிறது என்று கவனியுங்கள்." },
    "te-IN": { intro: "రండి, మూడు నెమ్మదైన శ్వాసలను కలిసి తీసుకుందాం.", inn: "శ్వాస లోపలికి తీసుకోండి", hold: "ఆపండి", out: "శ్వాస బయటకు వదలండి", round: "రౌండ్", done: "చాలా బాగుంది. ఇప్పుడు మీ శరీరం ఎలా అనిపిస్తోందో గమనించండి." },
    "ml-IN": { intro: "വരൂ, മൂന്ന് സാവധാനത്തിലുള്ള ശ്വാസങ്ങൾ നമുക്ക് ഒരുമിച്ച് എടുക്കാം.", inn: "ശ്വാസം ഉള്ളിലേക്ക് എടുക്കൂ", hold: "പിടിക്കൂ", out: "ശ്വാസം പുറത്തേക്ക് വിടൂ", round: "റൗണ്ട്", done: "വളരെ നല്ലത്. ഇപ്പോൾ നിങ്ങളുടെ ശരീരത്തിന് എങ്ങനെ തോന്നുന്നു എന്ന് ശ്രദ്ധിക്കൂ." }
  },

  // Translates the Grounding page's breathing labels into the companion language
  cue(label) {
    const t = this.BREATH[this.langCode()] || this.BREATH["en-IN"];
    return { "Breathe in": t.inn, "Hold": t.hold, "Breathe out": t.out }[label] || label;
  },

  stopBreathe() {
    if (this._br) { this._br.stop = true; this._br.timers.forEach(clearTimeout); this._br = null; }
    Avatar.breath(null);
    this.setStatus("");
  },

  breathe(rounds = 3) {
    const lang = this.langCode();
    const t = this.BREATH[lang] || this.BREATH["en-IN"];
    const c = this.get();
    const voice = !!(c && c.voiceOn && Voice.ttsSupported);
    this.stopBreathe();
    const br = this._br = { stop: false, timers: [] };
    this.toggle(true, true);
    this.setActions([{ label: "■ Stop", fn: () => this.stopBreathe() }]);
    const seq = [{ text: t.intro, phase: null, secs: 4, label: "🌬️" }];
    for (let r = 1; r <= rounds; r++) {
      seq.push({ text: `${t.round} ${r}. ${t.inn}`, phase: "in", secs: 5, label: `${t.round} ${r}/${rounds} · ${t.inn}` });
      seq.push({ text: t.hold, phase: "hold", secs: 2, label: `${t.round} ${r}/${rounds} · ${t.hold}` });
      seq.push({ text: t.out, phase: "out", secs: 6, label: `${t.round} ${r}/${rounds} · ${t.out}` });
    }
    seq.push({ text: t.done, phase: null, secs: 4, label: "✨", last: true });
    let i = 0;
    const next = () => {
      if (br.stop) return;
      const s = seq[i++];
      if (!s) return;
      this.setStatus(s.label);
      this.caption(s.text, s.secs * 1000 + 800);
      Avatar.breath(s.phase);
      if (voice) {
        Avatar.talk(true, 4000);
        Voice.speak(s.text, lang, { gender: this.voiceGender(), onend: ok => { Avatar.talk(false); if (ok === false) this.warnVoiceFailed(lang); } });
      }
      if (s.last) { br.timers.push(setTimeout(() => this.stopBreathe(), s.secs * 1000)); this.setActions([]); return; }
      br.timers.push(setTimeout(next, s.secs * 1000));
    };
    next();
  },

  // ---------- AI guide for every page ----------
  MODULES: {
    "dashboard": { title: "Dashboard", purpose: "the home overview with the mood check-in, streaks and quick links" },
    "journal": { title: "Journal", purpose: "a place to write or speak journal entries. Ask what is on their mind and invite them to write or speak it, and say you will listen" },
    "gratitude": { title: "Gratitude", purpose: "a place to note three things they are thankful for. Warmly ask what they are grateful for today and invite them to type or say any three things, and tell them you will respond to each one" },
    "self-understanding": { title: "Self-Understanding", purpose: "tools for understanding their own thoughts and feelings. Ask how they are feeling right now and offer today's reflection question" },
    "habits": { title: "Habits & Tasks", purpose: "daily habits to build and a to-do list. Ask which habit or task they want to start with and say you will cheer them on" },
    "analytics": { title: "Analytics", purpose: "charts showing how their mood and activity change over time. Explain what they might notice in their numbers and invite them to ask you anything about them" },
    "calendar": { title: "Calendar", purpose: "a calendar of their entries, moods and tasks. Invite them to ask you about their week" },
    "vision-board": { title: "Vision Board", purpose: "a board of pictures and goals for the future they want. Ask what dream they want to add first and say you will respond to it" },
    "library": { title: "Library", purpose: "a library of helpful reading and resources. Ask what they are going through and offer to suggest something from here" },
    "grounding": { title: "Grounding", purpose: "breathing exercises and a 5-4-3-2-1 senses exercise for calming down" },
    "ai-reflection": { title: "AI Reflection", purpose: "a place where an AI reflects back on what they have written. Invite them to ask you questions about what they have written" },
    "achievements": { title: "Achievements", purpose: "badges they earn for staying consistent. Cheer for what they have earned and ask which badge they want next" },
    "settings": { title: "Settings", purpose: "settings for theme, security, their companion and their data" }
  },


  // How the companion behaves as a friend (emotion reading, intent, questions, study help, honesty about memory and sources)
  FRIEND_RULES: "HOW TO BE A BEST FRIEND. Listen first: before any advice, acknowledge the specific thing they said, and never use stock lines like 'I'm sorry you feel that way', 'everything will be okay' or 'stay positive'. When you sense a feeling, offer it only as a gentle guess (\"it sounds like you might be feeling...\"), allow several feelings at once, never claim to know exactly what they feel, and if they correct you, accept it at once and follow their correction. Work out what they want right now: to vent, advice, a practical fix, encouragement, a story, study help, a distraction, or quiet company; if it is unclear, ask which, and if they just want company, give company without solving. Ask at most one or two questions, never repeat a question they already answered, respect a 'no', and do not keep interrogating. If they are struggling with studies, never agree that they are weak or stupid: ask which subject or topic, offer a simpler explanation, small steps or a short quiz, and ask whether they want emotional support, study help, or both. Never diagnose; describe feelings only as possibilities, and if the distress sounds lasting, gently suggest talking to someone they trust or a qualified professional. You do NOT remember past chats beyond what appears in this conversation and the facts above, so never pretend you do. Never state a verse, Kural, chapter or scripture number or quote scripture unless that exact text appears in the user's sources below; if they ask for a specific one that is not there, say honestly that you cannot verify the exact words and offer a general reflection without crediting it to any book. Do not push religion into the chat, and respect every belief. Be playful when the mood is light, calm and steady when it is serious. You are a friend, not a replacement for real people, so gently encourage real-world connection. READ THE REAL FEELING: judge how they feel from what actually happened in what they tell you, not only from the feeling word they use. If the word and the story do not match (for example they say they are very happy but describe a fight, being scolded, or a loss), do not accept it and do not argue: ask one light, warm question such as whether they are really happy, or joking, or something is weighing on them, and let them tell you. If a happy story really is happy, celebrate it with them specifically. EVERY DAY SHOULD FEEL FRESH: sound like a lively friend, show curiosity about the specific people, places and details they mention, ask a different kind of follow-up each time, vary your wording and openings, use gentle humour when the mood is light, and never fall back on the same phrases or the same shape of reply.",
  NEED_KEY: {
    "en-IN": "To give you brand-new stories and real replies I need your AI key. Please add it in Settings, under Companion.",
    "hi-IN": "आपको हर बार नई कहानियाँ और सच्चे जवाब देने के लिए मुझे आपकी AI कुंजी (API key) चाहिए। कृपया इसे Settings में Companion के नीचे जोड़ें।",
    "ta-IN": "உங்களுக்கு ஒவ்வொரு முறையும் புதிய கதைகளும் உண்மையான பதில்களும் தர எனக்கு உங்கள் AI கீ (API key) தேவை. அதை Settings-ல் Companion பகுதியில் சேர்க்கவும்.",
    "te-IN": "మీకు ప్రతిసారీ కొత్త కథలు, నిజమైన సమాధానాలు ఇవ్వడానికి నాకు మీ AI కీ (API key) కావాలి. దయచేసి Settings లో Companion కింద జోడించండి.",
    "ml-IN": "നിങ്ങൾക്ക് ഓരോ തവണയും പുതിയ കഥകളും യഥാർത്ഥ മറുപടികളും നൽകാൻ എനിക്ക് നിങ്ങളുടെ AI കീ (API key) വേണം. ദയവായി Settings-ൽ Companion-ന് താഴെ ചേർക്കൂ."
  },



  // Each page has its own opening line (works with or without an AI key) and a few tap-to-ask questions.
  MOD_OPEN: {
    "dashboard": { "en-IN": "Hey, welcome back. How are you feeling right now?", "hi-IN": "वापस आने पर स्वागत है। अभी आप कैसा महसूस कर रहे हैं?", "ta-IN": "மீண்டும் வருக. இப்போது உங்களுக்கு எப்படி இருக்கிறது?", "te-IN": "మళ్లీ స్వాగతం. ఇప్పుడు మీకు ఎలా అనిపిస్తోంది?", "ml-IN": "വീണ്ടും സ്വാഗതം. ഇപ്പോൾ നിങ്ങൾക്ക് എങ്ങനെ തോന്നുന്നു?" },
    "journal": { "en-IN": "I'm listening. Tell me anything on your mind, it doesn't have to be neat.", "hi-IN": "आपकी बात सुनने के लिए मैं यहाँ हूँ। जो भी मन में है, बिना सोचे कह दीजिए।", "ta-IN": "நான் கேட்கிறேன். மனதில் இருப்பதை எப்படி வேண்டுமானாலும் சொல்லுங்கள்.", "te-IN": "నేను వింటున్నాను. మనసులో ఉన్నది ఎలా కావాలంటే అలా చెప్పండి.", "ml-IN": "ഞാൻ കേൾക്കുന്നുണ്ട്. മനസ്സിലുള്ളത് എങ്ങനെ വേണമെങ്കിലും പറയൂ." },
    "gratitude": { "en-IN": "Let's find a little light. Was there something small today you felt thankful for?", "hi-IN": "चलिए आज की छोटी सी रोशनी ढूँढें। आज किस बात के लिए आप शुक्रगुज़ार हैं?", "ta-IN": "ஒரு சிறு வெளிச்சம் தேடலாம். இன்று எதற்காக நன்றியுடன் இருக்கிறீர்கள்?", "te-IN": "చిన్న వెలుగును వెతుకుదాం. ఈ రోజు దేనికి కృతజ్ఞతగా ఉన్నారు?", "ml-IN": "ഒരു ചെറിയ വെളിച്ചം തിരയാം. ഇന്ന് എന്തിനോടാണ് നന്ദി തോന്നിയത്?" },
    "self-understanding": { "en-IN": "Want to check in with yourself for a minute? How are you feeling right now?", "hi-IN": "थोड़ा खुद से मिलें? अभी आपको कैसा लग रहा है?", "ta-IN": "உங்களுடன் நீங்களே கொஞ்சம் பேசலாமா? இப்போது எப்படி உணர்கிறீர்கள்?", "te-IN": "మీతో మీరు కాస్త మాట్లాడుకుందామా? ఇప్పుడు ఎలా అనిపిస్తోంది?", "ml-IN": "നിങ്ങളോട് തന്നെ അൽപ്പം സംസാരിക്കാമോ? ഇപ്പോൾ എങ്ങനെ തോന്നുന്നു?" },
    "habits": { "en-IN": "How are your habits going? Did you do something today that you're proud of?", "hi-IN": "आपकी आदतें कैसी चल रही हैं? क्या आज कुछ ऐसा किया जिस पर गर्व हो?", "ta-IN": "உங்கள் பழக்கங்கள் எப்படி போகிறது? இன்று பெருமைப்படும்படி ஏதாவது செய்தீர்களா?", "te-IN": "మీ అలవాట్లు ఎలా సాగుతున్నాయి? ఈ రోజు గర్వపడేలా ఏదైనా చేశారా?", "ml-IN": "ശീലങ്ങൾ എങ്ങനെ പോകുന്നു? ഇന്ന് അഭിമാനിക്കാവുന്ന എന്തെങ്കിലും ചെയ്തോ?" },
    "analytics": { "en-IN": "Curious about your patterns? Let's read these charts together, gently.", "hi-IN": "अपने पैटर्न समझना चाहते हैं? चलिए इन चार्ट को साथ मिलकर समझते हैं।", "ta-IN": "உங்கள் வரைபடங்களை சேர்ந்து பார்க்கலாமா?", "te-IN": "మీ చార్టులను కలిసి చూద్దామా?", "ml-IN": "നിങ്ങളുടെ ചാർട്ടുകൾ നമുക്ക് ഒരുമിച്ച് നോക്കാം." },
    "calendar": { "en-IN": "Let's look at your week. Is anything coming up that's on your mind?", "hi-IN": "चलिए आपका हफ़्ता देखते हैं। क्या कुछ ख़ास आने वाला है?", "ta-IN": "உங்கள் வாரத்தைப் பார்க்கலாம். முக்கியமான ஏதாவது வரப்போகிறதா?", "te-IN": "మీ వారాన్ని చూద్దాం. ముఖ్యమైనదేదైనా రాబోతోందా?", "ml-IN": "നിങ്ങളുടെ ആഴ്ച നോക്കാം. പ്രധാനപ്പെട്ടത് എന്തെങ്കിലും വരാനുണ്ടോ?" },
    "vision-board": { "en-IN": "What's one dream you'd like to put on your board first?", "hi-IN": "बोर्ड पर सबसे पहले कौन सा सपना जोड़ना चाहेंगे?", "ta-IN": "உங்கள் பலகையில் முதலில் எந்தக் கனவைச் சேர்க்க விரும்புகிறீர்கள்?", "te-IN": "మీ బోర్డులో మొదట ఏ కలను చేర్చాలనుకుంటున్నారు?", "ml-IN": "ബോർഡിൽ ആദ്യം ഏത് സ്വപ്നം ചേർക്കണം?" },
    "library": { "en-IN": "Tell me what you're going through, and let's find something to read that fits.", "hi-IN": "बताइए आप किस दौर से गुज़र रहे हैं, फिर साथ मिलकर कुछ पढ़ने को ढूँढते हैं।", "ta-IN": "நீங்கள் என்ன அனுபவிக்கிறீர்கள் என்று சொல்லுங்கள், படிக்க ஏதாவது தேடலாம்.", "te-IN": "మీరు ఏమి అనుభవిస్తున్నారో చెప్పండి, చదవడానికి ఏదైనా వెతుకుదాం.", "ml-IN": "നിങ്ങൾ എന്താണ് കടന്നുപോകുന്നതെന്ന് പറയൂ, വായിക്കാൻ എന്തെങ്കിലും തിരയാം." },
    "grounding": { "en-IN": "Let's slow down together. Shall we take a few calm breaths?", "hi-IN": "चलिए साथ में धीमे हो जाएँ। कुछ गहरी साँसें लें?", "ta-IN": "மெதுவாகலாம். சேர்ந்து சில ஆழ்ந்த மூச்சு எடுக்கலாமா?", "te-IN": "నెమ్మదిద్దాం. కలిసి కొన్ని లోతైన శ్వాసలు తీసుకుందామా?", "ml-IN": "പതുക്കെയാകാം. ഒരുമിച്ച് ചില ദീർഘശ്വാസം എടുക്കാമോ?" },
    "ai-reflection": { "en-IN": "Ask me anything about what you've written, and we'll think it through together.", "hi-IN": "आपने जो लिखा उसके बारे में कुछ भी पूछिए, हम साथ मिलकर सोचेंगे।", "ta-IN": "நீங்கள் எழுதியதைப் பற்றி எதுவும் கேளுங்கள், சேர்ந்து யோசிக்கலாம்.", "te-IN": "మీరు రాసినదాని గురించి ఏదైనా అడగండి, కలిసి ఆలోచిద్దాం.", "ml-IN": "നിങ്ങൾ എഴുതിയതിനെക്കുറിച്ച് എന്തും ചോദിക്കൂ, ഒരുമിച്ച് ചിന്തിക്കാം." },
    "achievements": { "en-IN": "Look at what you've earned! Which badge would you like to aim for next?", "hi-IN": "देखिए आपने क्या कमाया है! अगला बैज कौन सा चाहिए?", "ta-IN": "நீங்கள் பெற்றதைப் பாருங்கள்! அடுத்து எந்த பேட்ஜ் வேண்டும்?", "te-IN": "మీరు సంపాదించినవి చూడండి! తర్వాత ఏ బ్యాడ్జ్ కావాలి?", "ml-IN": "നിങ്ങൾ നേടിയത് നോക്കൂ! അടുത്തത് ഏത് ബാഡ്ജ് വേണം?" },
    "settings": { "en-IN": "Need a hand with settings? Ask me about your companion, language or data.", "hi-IN": "सेटिंग्स में मदद चाहिए? कंपैनियन, भाषा या डेटा के बारे में पूछिए।", "ta-IN": "செட்டிங்ஸில் உதவி வேண்டுமா? துணை, மொழி, தரவு பற்றி கேளுங்கள்.", "te-IN": "సెట్టింగ్స్‌లో సహాయం కావాలా? కంపానియన్, భాష, డేటా గురించి అడగండి.", "ml-IN": "സെറ്റിംഗ്സിൽ സഹായം വേണോ? കമ്പാനിയൻ, ഭാഷ, ഡാറ്റ എന്നിവയെക്കുറിച്ച് ചോദിക്കൂ." }
  },

  // Suggested questions (English only for now; they are sent exactly as shown)
  MOD_ASKS: {
    "dashboard": ["I had a rough day", "Help me plan today", "Tell me something encouraging"],
    "journal": ["I don't know where to start", "I want to vent", "Give me a writing prompt"],
    "gratitude": ["I can't think of anything today", "Help me notice one small thing", "I'm grateful for a friend"],
    "self-understanding": ["I'm not sure what I feel", "Why do I feel anxious?", "Give me a reflection question"],
    "habits": ["I missed my habit today", "Help me break a big task into steps", "Which habit should I start with?"],
    "analytics": ["What do my moods show?", "Why was last week harder?", "What should I try next?"],
    "calendar": ["I have an exam coming up", "I feel stressed about this week", "Help me plan my week"],
    "vision-board": ["I want to dream bigger", "Help me turn a dream into a goal", "I feel stuck about my future"],
    "library": ["I feel anxious", "I feel lonely", "Suggest something calming"],
    "grounding": ["Guide me through breathing", "I'm panicking a little", "I can't sleep"],
    "ai-reflection": ["What patterns do you notice?", "Help me understand my last entry", "I feel misunderstood"],
    "achievements": ["I feel like I'm not making progress", "How do I stay consistent?", "Tell me something encouraging"],
    "settings": ["How do I change my language?", "How do I add my AI key?", "How do I add my own sources?"]
  },
  openerFor(id, lang) { const o = this.MOD_OPEN[id]; return o ? (o[lang] || o["en-IN"]) : ""; },
  chipsFor(id) { return (this.MOD_ASKS[id] || []).map(t => ({ label: "💬 " + t, fn: () => this.askChip(t) })); },
  askChip(text) {
    const input = document.getElementById("companion-input");
    if (!input) return;
    input.value = text; this.sendFromInput();
  },

  moduleFacts(id) {
    const f = [], today = Utils.dateKey();
    const safe = fn => { try { fn(); } catch (e) {} };
    safe(() => { const m = Data.moodOn(today); f.push(m ? `mood logged today: ${m.mood}` : "no mood logged yet today"); });
    safe(() => {
      const open = Storage.get("tasks").filter(t => !t.done);
      const overdue = open.filter(t => t.due && t.due < today).length;
      if (["dashboard", "habits", "calendar"].includes(id)) f.push(`${open.length} open tasks${overdue ? ` (${overdue} overdue)` : ""}`, `${Storage.get("habits").length} habits set up`);
    });
    safe(() => {
      if (["dashboard", "gratitude"].includes(id)) f.push(`${Storage.get("gratitude").filter(e => Utils.dateKey(e.date) === today).length} gratitude notes today`);
    });
    safe(() => {
      if (["dashboard", "journal", "ai-reflection", "self-understanding"].includes(id)) f.push(`${Storage.get("journal").length} journal entries so far`);
    });
    safe(() => { if (["analytics", "dashboard"].includes(id)) f.push(`${Data.allMoods().length} mood check-ins recorded in total`); });
    safe(() => { if (["achievements", "dashboard"].includes(id)) f.push(`${Achievements.earnedCount()} badges earned`); });
    safe(() => { if (id === "vision-board") f.push(`${Storage.get("vision").length} items on the vision board`); });
    return f.join("; ");
  },

  // Called by the router after every page opens: the companion greets and guides, aloud, in the chosen language
  guide(id) {
    const c = this.get();
    if (!c || !c.enabled || c.guideOn === false) return;
    const mod = this.MODULES[id];
    if (!mod) return;
    const token = this._guideToken = (this._guideToken || 0) + 1;
    clearTimeout(this._guideT);
    this._guideT = setTimeout(async () => {
      if (token !== this._guideToken) return; // the user already moved on
      let seen = {};
      try { seen = JSON.parse(sessionStorage.getItem("companion_guided") || "{}"); } catch (e) {}
      const now = Date.now();
      if (seen[id] && now - seen[id] < 4 * 60 * 1000) return; // don't nag on the same page
      seen[id] = now;
      try { sessionStorage.setItem("companion_guided", JSON.stringify(seen)); } catch (e) {}

      // The very first thing each day: a short mood check-in conversation, before anything else (Dashboard only)
      if (id === "dashboard" && this.startCheckin()) return;

      const settings = Storage.getObject("ai_settings", {});
      if (!settings.apiKey) {
        const open = this.openerFor(id, c.lang);
        const acts = this.chipsFor(id);
        if (!sessionStorage.getItem("companion_keyhint")) { acts.push(this.keyChip()); try { sessionStorage.setItem("companion_keyhint", "1"); } catch (e) {} }
        if (open) { this.setActions(c.lang === "en-IN" ? acts : acts.filter(a => a.label.includes("🔑"))); this.say(open); }
        return;
      }
      const mood = this.todaysMood();
      Avatar.setMood(mood);
      if (id === "dashboard" || id === "grounding") {
        if (["Sad", "Anxious", "Angry"].includes(mood) || id === "grounding") this.setActions([this.breathChip()]);
      }
      if (id === "habits") this.setActions([this.tasksChip()]);
      try {
        const text = await this.callAI("module", { title: mod.title, purpose: mod.purpose, facts: this.moduleFacts(id), prompt: `I just opened the ${mod.title} page.`, mood });
        if (token !== this._guideToken) return;
        this.say(text);
        if (c.lang === "en-IN") { const special = []; if (id === "dashboard" || id === "grounding") { if (["Sad", "Anxious", "Angry"].includes(mood) || id === "grounding") special.push(this.breathChip()); } if (id === "habits") special.push(this.tasksChip()); this.setActions(special.concat(this.chipsFor(id))); }
      } catch (err) {
        if (err.code !== "no-key") Utils.toast("AI guide failed: " + err.message);
      }
    }, 1200);
  },

  // ---------- voice check (which languages can this device actually speak?) ----------
  SAMPLES: {
    "en-IN": "Hello, I am here with you.",
    "hi-IN": "नमस्ते, मैं आपके साथ हूँ।",
    "ta-IN": "வணக்கம், நான் உங்களுடன் இருக்கிறேன்.",
    "te-IN": "నమస్కారం, నేను మీతో ఉన్నాను.",
    "ml-IN": "നമസ്കാരം, ഞാൻ നിങ്ങളോടൊപ്പമുണ്ട്."
  },

  voiceReport() {
    return this.LANGS.map(([code, name]) => ({ code, name, voice: Voice.ttsSupported ? Voice.voiceFor(code) : null }));
  },

  // ---------- real two-way reactions to what the user wrote ----------
  REACT_FB: {
    "en-IN": ["That is lovely. Thank you for sharing it, keep going.", "I can feel the care in that. Well done, keep it up.", "What a good thing to notice. Small moments like this add up."],
    "hi-IN": ["यह बहुत सुंदर है। साझा करने के लिए धन्यवाद, ऐसे ही आगे बढ़ते रहिए।", "इसमें अपनापन महसूस होता है। बहुत बढ़िया, ऐसे ही करते रहिए।", "यह नोटिस करना अच्छी बात है। छोटे पल ही जीवन बनाते हैं।"],
    "ta-IN": ["இது மிகவும் அழகானது. பகிர்ந்ததற்கு நன்றி, தொடர்ந்து செய்யுங்கள்.", "இதில் அன்பு தெரிகிறது. மிக நன்று, இப்படியே தொடருங்கள்.", "இதை கவனித்தது நல்லது. சிறிய தருணங்கள்தான் வாழ்க்கையை உருவாக்குகின்றன."],
    "te-IN": ["ఇది చాలా అందంగా ఉంది. పంచుకున్నందుకు ధన్యవాదాలు, ఇలాగే కొనసాగించండి.", "ఇందులో ప్రేమ కనిపిస్తోంది. చాలా బాగుంది, ఇలాగే చేస్తూ ఉండండి.", "ఇది గమనించడం మంచిది. చిన్న క్షణాలే జీవితాన్ని నిర్మిస్తాయి."],
    "ml-IN": ["ഇത് വളരെ മനോഹരമാണ്. പങ്കുവെച്ചതിന് നന്ദി, ഇങ്ങനെ തുടരൂ.", "ഇതിൽ സ്നേഹം തോന്നുന്നു. വളരെ നല്ലത്, ഇങ്ങനെ തന്നെ തുടരൂ.", "ഇത് ശ്രദ്ധിച്ചത് നല്ലതാണ്. ചെറിയ നിമിഷങ്ങളാണ് ജീവിതം ഉണ്ടാക്കുന്നത്."]
  },

  // Reacts to a specific thing the person just wrote (gratitude item, journal entry...). kind = module id.
  async react(kind, text, hint) {
    const c = this.get();
    if (!c || !c.enabled || !text || !text.trim()) return;
    if (RiskScreening.check(text).level === "high") { this.toggle(true, true); this.say(this.crisisText()); return; }
    { const st = this.checkinState(); if (!st.done && st.dateKey === Utils.dateKey()) return; } // don't talk over an active mood check-in
    const mod = this.MODULES[kind] || { title: kind };
    const token = this._reactToken = (this._reactToken || 0) + 1;
    this._guideToken = (this._guideToken || 0) + 1; // a reaction beats any page guide still waiting
    this.toggle(true, true);
    Avatar.act("tilt", { quiet: true });
    this.thinking();
    let reply;
    try {
      reply = await this.callAI("react", { title: mod.title, text: text.trim().slice(0, 400), hint, prompt: text.trim().slice(0, 400) });
    } catch (err) {
      reply = this.fresh(this.REACT_FB[c.lang] || this.REACT_FB["en-IN"], "react:" + (c.lang || "en"));
      if (err.code === "no-key") this.setActions([this.keyChip()]);
      else Utils.toast("AI reply failed: " + err.message);
    }
    if (token !== this._reactToken) return;
    Avatar.act(kind === "gratitude" ? "hearts" : "nod");
    this.say(reply);
  },

  keyChip() { return { label: "🔑 Add my AI key", fn: () => { location.hash = "#settings"; } }; },

  toggleMic() {
    const btn = document.getElementById("companion-mic");
    if (!Voice.recSupported) { Utils.toast("Voice input is not supported in this browser."); return; }
    if (this.listening) { Voice.stop(); return; }
    const c = this.get();
    const started = Voice.listen({
      lang: (c && c.lang) || "en-IN",
      onFinal: text => { document.getElementById("companion-input").value = text; this.sendFromInput(); },
      onEnd: () => { this.listening = false; Avatar.listening(false); if (btn) btn.classList.remove("rec"); }
    });
    if (started) { this.listening = true; Avatar.listening(true); btn.classList.add("rec"); }
  }
};
