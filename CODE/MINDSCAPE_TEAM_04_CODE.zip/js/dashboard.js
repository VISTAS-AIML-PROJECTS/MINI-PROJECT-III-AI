const Dashboard = {
  render() {
    const profile = Auth.getProfile();
    const today = Utils.dateKey();

    const mood = Data.moodOn(today);
    const moodObj = mood ? Utils.moodObj(mood.mood) : null;
    const streak = Data.streak();
    const tasks = Storage.get("tasks");
    const pending = tasks.filter(t => !t.done).length;
    const gratitudeDone = Storage.get("gratitude").some(g => g.dateKey === today);
    const journal = Storage.get("journal");
    const latest = journal.length ? journal[journal.length - 1] : null;
    const quote = Utils.quoteOfDay();
    const badges = Achievements.status();
    const earned = badges.filter(b => b.earned).length;

    const moodCard = moodObj
      ? `<div class="stat-big">${moodObj.emoji}</div><p>${moodObj.label}</p>`
      : `<div class="stat-big">-</div><p>No mood logged today</p>`;
    const streakCard = streak === null
      ? `<div class="stat-big">-</div><p>Add a habit to start a streak</p>`
      : `<div class="stat-big">🔥 ${streak}</div><p>${streak === 1 ? "day" : "days"} in a row</p>`;
    const taskCard = tasks.length === 0
      ? `<div class="stat-big">-</div><p>No tasks yet</p>`
      : `<div class="stat-big">${pending}</div><p>${pending === 1 ? "task" : "tasks"} to do</p>`;
    const gratitudeCard = gratitudeDone
      ? `<div class="stat-big">✔</div><p>Done for today</p>`
      : `<div class="stat-big">🙏</div><p>Not yet today</p>`;

    let latestCard = `<p class="empty">No journal entries yet. Your first one is a great place to start.</p>`;
    if (latest) {
      const m = Utils.moodObj(latest.mood);
      const text = latest.text || "";
      latestCard = `
        <div class="entry-head">
          <strong>${m ? m.emoji : "📝"} ${Utils.escape(latest.title) || "Untitled"}</strong>
          <small>${new Date(latest.date).toLocaleString()}</small>
        </div>
        <p>${Utils.escape(text.slice(0, 160))}${text.length > 160 ? "…" : ""}</p>`;
    }

    return `
      <h1>${Utils.greeting()}, ${Utils.escape(profile.name)}</h1>
      <p class="sub">${new Date().toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>

      <div class="card">
        <h4>How are you feeling right now?</h4>
        <p class="sub">Just talk to your companion. It reads how you really feel from what you tell it and logs your mood, gratitude and journal for you, after asking you first.</p>
        <button type="button" class="btn" id="dash-chat">Talk to my companion</button>
      </div>

      <div class="dash-grid">
        <div class="card stat"><h4>Today's mood</h4>${moodCard}<a class="link" href="#journal">Write about it</a></div>
        <div class="card stat"><h4>Habit streak</h4>${streakCard}<a class="link" href="#habits">Go to habits</a></div>
        <div class="card stat"><h4>Open tasks</h4>${taskCard}<a class="link" href="#habits">See tasks</a></div>
        <div class="card stat"><h4>Gratitude</h4>${gratitudeCard}<a class="link" href="#gratitude">Open gratitude</a></div>
        <div class="card stat"><h4>Badges</h4><div class="stat-big">🏆 ${earned}</div><p>of ${badges.length} earned</p><a class="link" href="#achievements">See badges</a></div>
        <div class="card stat"><h4>Feeling overwhelmed?</h4><div class="stat-big">🌿</div><p>Try a short breathing exercise</p><a class="link" href="#grounding">Open grounding</a></div>
        <div class="card wide"><h4>Latest journal entry</h4>${latestCard}<a class="link" href="#journal">Open journal</a></div>
        <div class="card wide"><h4>Thought for today</h4>
          <p class="quote">“${Utils.escape(quote.text)}”<small>${Utils.escape(quote.by)}</small></p></div>
      </div>`;
  },

  init() {
    const chat = document.getElementById("dash-chat");
    if (chat) chat.addEventListener("click", () => { try { Companion.toggle(true); } catch (e) {} });
  }
};
