const NAV = [
  { id: "dashboard",          label: "Dashboard",          icon: "🏠" },
  { id: "journal",            label: "Journal",            icon: "📓" },
  { id: "gratitude",          label: "Gratitude",          icon: "🙏" },
  { id: "self-understanding", label: "Self-Understanding", icon: "🧠" },
  { id: "habits",             label: "Habits & Tasks",     icon: "✅" },
  { id: "analytics",          label: "Analytics",          icon: "📈" },
  { id: "calendar",           label: "Calendar",           icon: "🗓️" },
  { id: "vision-board",       label: "Vision Board",       icon: "🖼️" },
  { id: "library",            label: "Library",            icon: "📚" },
  { id: "grounding",          label: "Grounding",          icon: "🌿" },
  { id: "ai-reflection",      label: "AI Reflection",      icon: "✨" },
  { id: "achievements",       label: "Achievements",       icon: "🏆" },
  { id: "settings",           label: "Settings",           icon: "⚙️" }
];

// Each page: render() returns HTML, init() wires events, leave() cleans up timers/voice
const pages = {
  "dashboard":          { mod: Dashboard,         render: () => Dashboard.render(),         init: () => Dashboard.init() },
  "journal":            { mod: Journal,           render: () => Journal.render(),           init: () => Journal.init() },
  "gratitude":          { mod: Gratitude,         render: () => Gratitude.render(),         init: () => Gratitude.init() },
  "self-understanding": { mod: SelfUnderstanding, render: () => SelfUnderstanding.render(), init: () => SelfUnderstanding.init() },
  "habits":             { mod: Habits,            render: () => Habits.render(),            init: () => Habits.init() },
  "analytics":          { mod: Analytics,         render: () => Analytics.render(),         init: () => Analytics.init() },
  "calendar":           { mod: Calendar,          render: () => Calendar.render(),          init: () => Calendar.init() },
  "vision-board":       { mod: Vision,            render: () => Vision.render(),            init: () => Vision.init() },
  "library":            { mod: Library,           render: () => Library.render(),           init: () => Library.init() },
  "grounding":          { mod: Grounding,         render: () => Grounding.render(),         init: () => Grounding.init() },
  "ai-reflection":      { mod: AI,                render: () => AI.render(),                init: () => AI.init() },
  "achievements":       { mod: Achievements,      render: () => Achievements.render(),      init: () => Achievements.init() },
  "settings":           { mod: Auth,              render: () => Auth.renderSettings(),      init: () => Auth.initSettings() }
};

let activePage = null;

function currentPage() {
  const id = location.hash.slice(1) || "dashboard";
  return pages[id] ? id : "dashboard";
}

function setActive() {
  const page = currentPage();
  document.querySelectorAll(".sidebar .nav-links a").forEach(a => {
    a.classList.toggle("active", a.getAttribute("href") === "#" + page);
  });
}

function buildSidebar() {
  const profile = Auth.getProfile();
  document.getElementById("sidebar").innerHTML = `
    <h2>🌿 MindScape</h2>
    <button class="nav-toggle" id="nav-toggle" aria-expanded="false" aria-controls="nav-links">☰ Menu</button>
    <div class="nav-links" id="nav-links">
      ${NAV.map(n => `<a href="#${n.id}">${n.icon} ${n.label}</a>`).join("")}
    </div>
    <div class="sidebar-user">
      <span>👤 ${Utils.escape(profile.name)}</span>
      <small style="display:block;opacity:.6;font-size:.7rem">Build 28 · Create from uploads</small>
      ${profile.pinHash ? '<button class="link-btn" id="lock-btn">🔒 Lock</button>' : ""}
    </div>`;
  const lockBtn = document.getElementById("lock-btn");
  if (lockBtn) lockBtn.addEventListener("click", () => Auth.lock());
  const toggle = document.getElementById("nav-toggle");
  const sidebar = document.getElementById("sidebar");
  toggle.addEventListener("click", () => {
    const open = sidebar.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open);
  });
  setActive();
}

function router() {
  // Clean up the page we are leaving (timers, microphone, speech)
  if (activePage && activePage.mod && activePage.mod.leave) activePage.mod.leave();
  Voice.stop();
  Voice.silence();
  Companion.mount();

  const page = pages[currentPage()];
  activePage = page;
  document.getElementById("content").innerHTML = page.render();
  if (page.init) page.init();
  Companion.guide(currentPage());
  setActive();
  document.getElementById("sidebar").classList.remove("open"); // close mobile menu after navigating
}

function startApp() {
  buildSidebar();
  window.addEventListener("hashchange", () => { router(); window.scrollTo(0, 0); });
  router();
}

window.addEventListener("load", () => Auth.init(startApp));
