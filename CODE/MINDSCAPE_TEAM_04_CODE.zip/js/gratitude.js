const Gratitude = {
  KEY: "gratitude",

  todayEntry() { return Storage.get(this.KEY).find(e => e.dateKey === Utils.dateKey()); },

  render() {
    const t = this.todayEntry();
    const v = t ? t.items : ["", "", ""];
    return `
      <h1>🙏 Gratitude</h1>
      <div class="card">
        <h3>Three things I'm grateful for today</h3>
        ${[0, 1, 2].map(i => `<input type="text" class="g-item" placeholder="${i + 1}." value="${Utils.escape(v[i] || "")}" maxlength="140">`).join("")}
        <button class="btn" id="g-save">${t ? "Update today's entry" : "Save today's entry"}</button>
        <p id="g-msg" class="msg"></p>
      </div>
      <div class="card">
        <h3>Past entries</h3>
        <div id="g-list"></div>
      </div>`;
  },

  init() {
    document.getElementById("g-save").addEventListener("click", () => this.save());
    // The companion answers each thing as soon as it is written (when you leave the box or press Enter)
    const items = Array.from(document.querySelectorAll(".g-item"));
    items.forEach((inp, i) => {
      inp.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); inp.blur(); if (items[i + 1]) items[i + 1].focus(); } });
      inp.addEventListener("change", () => {
        const v = inp.value.trim();
        if (!v) return;
        const left = items.filter(x => !x.value.trim()).length;
        Companion.react("gratitude", v, left ? `They have ${left} more gratitude box(es) to fill: invite them to write the next one.` : "That completes their three; congratulate them and encourage them to save today's entry.");
      });
    });
    document.getElementById("g-list").addEventListener("click", e => {
      const btn = e.target.closest("button[data-id]");
      if (btn && confirm("Delete this entry?")) {
        Storage.remove(this.KEY, Number(btn.dataset.id));
        router();
      }
    });
    this.renderList();
  },

  save() {
    const items = Array.from(document.querySelectorAll(".g-item")).map(i => i.value.trim());
    if (!items.some(Boolean)) {
      document.getElementById("g-msg").textContent = "Write at least one thing first.";
      return;
    }
    const existing = this.todayEntry();
    if (existing) Storage.update(this.KEY, existing.id, { items });
    else Storage.save(this.KEY, { items, dateKey: Utils.dateKey() });
    router();
    Utils.toast("Gratitude saved ✔");
  },

  renderList() {
    const entries = Storage.get(this.KEY).slice().reverse();
    const list = document.getElementById("g-list");
    if (!entries.length) { list.innerHTML = `<p class="empty">No entries yet. Add today's three things above.</p>`; return; }
    list.innerHTML = entries.map(e => `
      <div class="entry">
        <div class="entry-head">
          <strong>${Utils.longDate(e.dateKey)}</strong>
          <button class="btn-small danger" data-id="${e.id}">Delete</button>
        </div>
        <ul>${e.items.filter(Boolean).map(i => `<li>${Utils.escape(i)}</li>`).join("")}</ul>
      </div>`).join("");
  }
};
