// Animated anime companion characters. Each character is hand-built as layered SVG parts
// (head, hair, eyes, brows, mouth, torso, arms, legs) drawn to closely match the look of the
// picture you provided for that character. Because every part is its own shape, each one can
// move independently: the arms swing, legs step, head turns, eyes blink, mouth talks -- a real
// animated character, not a still picture.
const Avatar = {
  CHARS: {
    kai: {
      gender: "male",
      name: "Kai",
      skin: "#f3d9c4", skinSh: "#e3c0a8",
      hair: "#cfd6ea", hairSh: "#aab2d6", hairHi: "#eef1fb",
      eye: "#6e7fd6", eyeHi: "#ffffff",
      outfit: "#4b5386", outfitSh: "#373d66", outfitLi: "#6a74b8",
      accent: "#2b2f52", // headphones
      bg1: "#161a33", bg2: "#2b3366" // starry night
    },
    ren: {
      gender: "male",
      name: "Ren",
      skin: "#f1d7c3", skinSh: "#e0bda4",
      hair: "#20233f", hairSh: "#12142a", hairHi: "#3e4470",
      eye: "#8a93c8", eyeHi: "#ffffff",
      outfit: "#141733", outfitSh: "#0a0c1e", outfitLi: "#2a2f5c",
      accent: "#d8b35a", // gold trim
      bg1: "#232852", bg2: "#3a4080"
    },
    lian: {
      gender: "male",
      name: "Lian",
      skin: "#f6e3d3", skinSh: "#e6cbb5",
      hair: "#2b2622", hairSh: "#171412", hairHi: "#4a433c",
      eye: "#7a6a56", eyeHi: "#ffffff",
      outfit: "#f5f1e8", outfitSh: "#d8d0bd", outfitLi: "#ffffff",
      accent: "#c9a24a", // gold trim on hanfu
      bg1: "#dfe3ea", bg2: "#c7ccd8"
    },
    kei: {
      gender: "male",
      name: "Kei",
      skin: "#f1cdb3", skinSh: "#dfb599",
      hair: "#dcc58f", hairSh: "#bfa56c", hairHi: "#f1e2b8",
      eye: "#5e8fd6", eyeHi: "#ffffff",
      outfit: "#1b1c22", outfitSh: "#121317", outfitLi: "#22407a",
      accent: "#22407a",
      bg1: "#2a2f44", bg2: "#454c6c"
    },
    yuki: {
      gender: "female",
      name: "Yuki",
      skin: "#f4dcc9", skinSh: "#e4c3ab",
      hair: "#6b4a3a", hairSh: "#4f3527", hairHi: "#8d6a54",
      eye: "#6a4f3f", eyeHi: "#ffffff",
      outfit: "#e8e3e6", outfitSh: "#cfc7cc", outfitLi: "#ffffff",
      accent: "#ffffff", // earmuffs
      bg1: "#2a2f44", bg2: "#454c6c"
    }
  },

  // ---------- part builders (shared skeleton, per-character colours & silhouette tweaks) ----------
  _head(id, k, big) {
    // Hairstyles differ per character to echo the reference picture
    const hairShapes = {
      kai:  `<path class="hr-back" d="M38 54 Q30 10 100 6 Q170 10 162 54 Q168 96 150 110 L132 86 Q100 70 68 86 L50 110 Q32 96 38 54Z" fill="${k.hairSh}"/>
             <path class="hr-front" d="M40 56 Q34 14 100 10 Q166 14 160 56 Q150 30 100 30 Q50 30 40 56Z" fill="${k.hair}"/>
             <path d="M58 24 Q100 12 142 24 Q130 18 100 18 Q70 18 58 24Z" fill="${k.hairHi}" opacity=".8"/>
             <path d="M46 50 Q40 70 46 96" stroke="${k.hairSh}" stroke-width="5" fill="none" stroke-linecap="round"/>
             <path d="M154 50 Q160 70 154 96" stroke="${k.hairSh}" stroke-width="5" fill="none" stroke-linecap="round"/>`,
      ren:  `<path class="hr-back" d="M34 58 Q26 6 100 2 Q174 6 166 58 Q172 100 148 118 L128 90 Q100 74 72 90 L52 118 Q28 100 34 58Z" fill="${k.hairSh}"/>
             <path class="hr-front" d="M38 60 Q30 16 100 12 Q170 16 162 60 Q148 28 100 26 Q52 28 38 60Z" fill="${k.hair}"/>
             <path d="M70 20 Q100 10 130 20 L124 34 Q100 26 76 34Z" fill="${k.hairHi}" opacity=".7"/>
             <path d="M42 52 Q33 78 42 104" stroke="${k.hairSh}" stroke-width="6" fill="none" stroke-linecap="round"/>
             <path d="M158 52 Q167 78 158 104" stroke="${k.hairSh}" stroke-width="6" fill="none" stroke-linecap="round"/>
             <path d="M90 6 Q100 -6 112 6 Q104 4 100 10 Q96 4 90 6Z" fill="${k.accent}"/>`,
      lian: `<path class="hr-back" d="M36 60 Q28 8 100 4 Q172 8 164 60 Q174 110 150 140 L120 100 Q100 88 80 100 L50 140 Q26 110 36 60Z" fill="${k.hairSh}"/>
             <path class="hr-front" d="M40 58 Q32 18 100 14 Q168 18 160 58 Q148 30 100 30 Q52 30 40 58Z" fill="${k.hair}"/>
             <path d="M64 22 Q100 12 136 22 Q118 18 100 18 Q82 18 64 22Z" fill="${k.hairHi}" opacity=".6"/>
             <circle cx="100" cy="16" r="7" fill="${k.accent}"/>`,
      yuki: `<path class="hr-back" d="M34 56 Q26 10 100 8 Q174 10 166 56 Q176 92 154 108 L136 80 Q100 64 64 80 L46 108 Q24 92 34 56Z" fill="${k.hairSh}"/>
             <path class="hr-front" d="M38 56 Q30 20 100 16 Q170 20 162 56 Q148 32 100 32 Q52 32 38 56Z" fill="${k.hair}"/>
             <path d="M60 26 Q100 16 140 26 Q120 22 100 22 Q80 22 60 26Z" fill="${k.hairHi}" opacity=".6"/>
             <path d="M40 50 C 20 70, 24 100, 44 110" stroke="${k.hairSh}" stroke-width="7" fill="none" stroke-linecap="round"/>
             <path d="M160 50 C 180 70, 176 100, 156 110" stroke="${k.hairSh}" stroke-width="7" fill="none" stroke-linecap="round"/>`
    };
    return `
      <ellipse cx="100" cy="98" rx="52" ry="58" fill="${k.skin}"/>
      <ellipse cx="68" cy="104" rx="10" ry="7" fill="${k.skinSh}" opacity=".5"/>
      <ellipse cx="132" cy="104" rx="10" ry="7" fill="${k.skinSh}" opacity=".5"/>
      ${hairShapes[id] || hairShapes.kai}
      <g class="eyes">
        <g class="eye eye-l">
          <path d="M66 96 Q78 84 92 96 Q78 104 66 96Z" fill="${k.eyeHi}"/>
          <circle cx="79" cy="95" r="7.5" fill="${k.eye}"/><circle cx="81.5" cy="92" r="2.4" fill="#fff"/>
        </g>
        <g class="eye eye-r">
          <path d="M108 96 Q122 84 134 96 Q122 104 108 96Z" fill="${k.eyeHi}"/>
          <circle cx="121" cy="95" r="7.5" fill="${k.eye}"/><circle cx="123.5" cy="92" r="2.4" fill="#fff"/>
        </g>
        <path class="brow brow-l" d="M66 82 Q78 76 92 81" stroke="${k.hairSh}" stroke-width="3.4" fill="none" stroke-linecap="round"/>
        <path class="brow brow-r" d="M108 81 Q122 76 134 82" stroke="${k.hairSh}" stroke-width="3.4" fill="none" stroke-linecap="round"/>
      </g>
      <g class="lids">
        <rect class="lid lid-l" x="64" y="88" width="30" height="16" rx="8" fill="${k.skin}" transform="scale(1,0.06)" transform-origin="79 96"/>
        <rect class="lid lid-r" x="106" y="88" width="30" height="16" rx="8" fill="${k.skin}" transform="scale(1,0.06)" transform-origin="121 96"/>
      </g>
      <g class="mouth" transform-origin="100 122">
        <path class="m-smile" d="M88 120 Q100 128 112 120" stroke="#9a5a52" stroke-width="3.2" fill="none" stroke-linecap="round"/>
        <ellipse class="m-talk" cx="100" cy="121" rx="10" ry="7" fill="#7a3f3a" opacity="0"/>
        <path class="m-sad" d="M88 126 Q100 118 112 126" stroke="#9a5a52" stroke-width="3.2" fill="none" stroke-linecap="round" opacity="0"/>
      </g>
      <ellipse class="blush" cx="68" cy="112" rx="9" ry="5" fill="#ff9d9d" opacity="0"/>
      <ellipse class="blush" cx="132" cy="112" rx="9" ry="5" fill="#ff9d9d" opacity="0"/>
      <path class="tear" d="M70 108 Q66 120 71 126 Q76 120 70 108Z" fill="#9fd4ff" opacity="0"/>
    `;
  },

  _accessory(id, k) {
    if (id === "kai") return `<path d="M34 70 Q30 30 100 24 Q170 30 166 70" stroke="${k.accent}" stroke-width="12" fill="none" stroke-linecap="round"/>
      <circle cx="34" cy="78" r="13" fill="${k.accent}"/><circle cx="166" cy="78" r="13" fill="${k.accent}"/>
      <circle cx="34" cy="78" r="6" fill="${k.hairHi}"/><circle cx="166" cy="78" r="6" fill="${k.hairHi}"/>`;
    if (id === "yuki") return `<path d="M30 66 Q26 24 100 18 Q174 24 170 66" stroke="#fff" stroke-width="13" fill="none" stroke-linecap="round"/>
      <ellipse cx="30" cy="76" rx="15" ry="17" fill="#fff"/><ellipse cx="170" cy="76" rx="15" ry="17" fill="#fff"/>
      <ellipse cx="30" cy="76" rx="8" ry="10" fill="#f3d9e4"/><ellipse cx="170" cy="76" rx="8" ry="10" fill="#f3d9e4"/>`;
    if (id === "lian") return `<ellipse cx="100" cy="-6" rx="70" ry="16" fill="none" stroke="${k.accent}" stroke-width="3" opacity=".8"/>`;
    return "";
  },

  _body(id, k) {
    const outfits = {
      kai:  `<path d="M58 0 L142 0 L156 92 Q100 112 44 92 Z" fill="${k.outfit}"/>
             <path d="M58 0 L80 0 L70 60 L52 50Z" fill="${k.outfitLi}"/>
             <path d="M70 10 L130 10 L124 40 L76 40Z" fill="${k.outfitSh}" opacity=".5"/>
             <circle cx="100" cy="22" r="6" fill="${k.accent}"/>`,
      ren:  `<path d="M54 0 L146 0 L160 96 Q100 118 40 96 Z" fill="${k.outfit}"/>
             <path d="M54 0 L100 14 L146 0 L140 20 L100 34 L60 20Z" fill="${k.outfitLi}"/>
             <path d="M100 14 L100 96" stroke="${k.accent}" stroke-width="3" opacity=".8"/>
             <path d="M62 24 Q100 36 138 24" stroke="${k.accent}" stroke-width="3.5" fill="none"/>
             <path d="M58 46 Q100 58 142 46" stroke="${k.accent}" stroke-width="3" fill="none" opacity=".8"/>
             <circle cx="100" cy="20" r="5" fill="${k.accent}"/>`,
      lian: `<path d="M52 0 L148 0 L166 100 Q100 126 34 100 Z" fill="${k.outfit}"/>
             <path d="M52 0 L100 24 L148 0 L142 14 L100 36 L58 14Z" fill="${k.outfitLi}"/>
             <path d="M70 10 Q100 22 130 10" stroke="${k.accent}" stroke-width="3" fill="none"/>
             <path d="M62 50 Q100 64 138 50" stroke="${k.accent}" stroke-width="2.6" fill="none" opacity=".8"/>
             <path d="M58 80 Q100 94 142 80" stroke="${k.accent}" stroke-width="2.6" fill="none" opacity=".6"/>`,
      yuki: `<path d="M56 0 L144 0 L158 94 Q100 116 42 94 Z" fill="${k.outfit}"/>
             <path d="M56 0 L80 0 L68 50 L48 40Z" fill="${k.outfitLi}"/>
             <circle cx="78" cy="30" r="4" fill="${k.accent}" opacity=".7"/><circle cx="122" cy="30" r="4" fill="${k.accent}" opacity=".7"/>
             <circle cx="100" cy="46" r="4" fill="${k.accent}" opacity=".7"/>`
    };
    return outfits[id] || outfits.kai;
  },

  // Full layered character markup. Each g.part has its own transform-origin set in CSS so it can move on its own.
  figure(id) {
    const k = this.CHARS[id] || this.CHARS.kai;
    return `
      <svg class="av-rig" viewBox="-40 100 280 330" preserveAspectRatio="xMidYMax meet">
        <defs>
          <radialGradient id="bgGlow-${id}" cx="50%" cy="35%" r="75%">
            <stop offset="0%" stop-color="${k.bg2}"/><stop offset="100%" stop-color="${k.bg1}"/>
          </radialGradient>
        </defs>
        <rect class="av-bg" x="-300" y="-60" width="800" height="560" fill="url(#bgGlow-${id})"/>
        <g class="part leg-l" transform-origin="78 300">
          <path d="M62 300 L60 410 L94 410 L92 300Z" fill="${k.outfitSh}"/>
          <path d="M58 404 L96 404 L98 420 L56 420Z" fill="#2a2a32"/>
        </g>
        <g class="part leg-r" transform-origin="122 300">
          <path d="M108 300 L106 410 L140 410 L138 300Z" fill="${k.outfit}"/>
          <path d="M104 404 L142 404 L144 420 L102 420Z" fill="#2a2a32"/>
        </g>
        <g class="part arm-l" transform-origin="54 200">
          <path d="M54 190 Q34 210 38 270 Q40 300 56 300 L70 296 Q58 260 62 210Z" fill="${k.outfit}"/>
          <circle cx="56" cy="300" r="13" fill="${k.skin}"/>
        </g>
        <g class="part torso" transform-origin="100 300">
          ${this.figBody(id, k)}
        </g>
        <g class="part arm-r" transform-origin="146 200">
          <path d="M146 190 Q166 210 162 270 Q160 300 144 300 L130 296 Q142 260 138 210Z" fill="${k.outfitSh}"/>
          <circle cx="144" cy="300" r="13" fill="${k.skin}"/>
          <g class="hand-wave" transform-origin="144 300"><circle cx="144" cy="300" r="13" fill="${k.skin}"/></g>
        </g>
        <g class="part head" transform-origin="100 220">
          <g transform="translate(0,120) scale(0.78)">
            ${this._accessory(id, k)}
            ${this._head(id, k)}
          </g>
        </g>
      </svg>`;
  },

  figBody(id, k) {
    return `<g transform="translate(0,188)">${this._body(id, k)}</g>`;
  },

  // ---------- face-only crop for the round chat bubble / thumbnail ----------
  faceSvg(id) {
    const k = this.CHARS[id] || this.CHARS.kai;
    return `<svg class="av-rig av-face" viewBox="10 -10 180 200" preserveAspectRatio="xMidYMid meet">
      <defs><radialGradient id="bgGlowF-${id}" cx="50%" cy="35%" r="75%"><stop offset="0%" stop-color="${k.bg2}"/><stop offset="100%" stop-color="${k.bg1}"/></radialGradient></defs>
      <rect x="-20" y="-20" width="240" height="240" fill="url(#bgGlowF-${id})"/>
      <g class="part head" transform-origin="100 90">${this._accessory(id, k)}${this._head(id, k)}</g>
    </svg>`;
  },


  // =====================================================================================
  // PHOTO PUPPET: your exact pictures, cut into moving pieces.
  // The body layer is the full picture. The head layer is a soft-edged copy of the picture's head
  // that turns, nods and bobs on its own, pivoting at the neck. Eyelids, a mouth and cheek blush are
  // drawn on top of the head layer, so eyes blink and the mouth opens while speaking.
  // =====================================================================================
  PUPPET: {
    kai:  { w: 720, h: 1280, head: { cx: 49, cy: 25, rx: 22, ry: 14.5 }, pivot: [44, 36], skin: "#c9bfd6",
            eyes: [[36.4, 26.7, 6.0, "#a79db9"], [48.1, 26.6, 6.5, "#b296b9"]], mouth: [43.9, 32.3, 3.2, "#7c4458"], glow: [64, 28.5, 5.5, "#38e8ff"],
            stage: { s: 1.55, cx: .50, cy: .29 }, face: { s: 2.4, cx: .47, cy: .25 } },
    ren:  { w: 720, h: 1017, head: { cx: 60, cy: 27, rx: 34, ry: 27 }, pivot: [58, 52], skin: "#dcc7d2",
            eyes: [[55.6, 28.8, 7.5, "#c4adb8"], [73.2, 33.3, 8.5, "#b69eac"]], mouth: [62.4, 44, 3.4, "#9a4f5c"],
            stage: { s: 1.1, cx: .58, cy: .34 }, face: { s: 2.0, cx: .60, cy: .30 } },
    lian: { w: 720, h: 783, head: { cx: 61.5, cy: 7, rx: 10, ry: 10 }, pivot: [61, 16], skin: "#f1e3dd",
            eyes: null, mouth: null, skirt: 46,
            stage: { s: 2.0, cx: .58, cy: .22 }, face: { s: 4.5, cx: .60, cy: .10 } },
    yuki: { w: 720, h: 720, head: { cx: 48, cy: 30, rx: 29, ry: 27 }, pivot: [55, 52], skin: "#f0e0e2",
            eyes: [[50.6, 33.3, 9.5, "#e6d9db"], [62.8, 33.8, 8.5, "#dccdd0"]], mouth: [57.6, 45.3, 3.0, "#a95b63"],
            stage: { s: 1.18, cx: .48, cy: .45 }, face: { s: 2.0, cx: .54, cy: .38 } }
  },

  puppet(id, headOnly) {
    const p = this.PUPPET[id] || this.PUPPET.kai, k = this.CHARS[id] || this.CHARS.kai;
    const v = headOnly ? p.face : p.stage, img = `url(assets/characters/${id}.jpg)`;
    const hd = p.head;
    const mask = `radial-gradient(ellipse ${hd.rx}% ${hd.ry}% at ${hd.cx}% ${hd.cy}%, #000 62%, transparent 100%)`;
    const eye = (e, i) => `<i class="pp-lid ${i ? "pp-lid-r" : "pp-lid-l"}" style="left:${e[0]}%;top:${e[1]}%;width:${e[2] * 0.92}%;--sk:${e[3]}"></i>`;
    const blush = (e) => `<i class="pp-blush" style="left:${e[0]}%;top:${e[1] + e[2] * 0.55}%;width:${e[2] * 1.2}%"></i>`;
    const face = (p.eyes ? p.eyes.map(eye).join("") + p.eyes.map(blush).join("") : "") +
      (p.mouth ? `<i class="pp-mouth" style="left:${p.mouth[0]}%;top:${p.mouth[1]}%;width:${p.mouth[2]}%;--mc:${p.mouth[3]}"></i>` : "") +
      (p.glow ? `<i class="pp-glow" style="left:${p.glow[0]}%;top:${p.glow[1]}%;width:${p.glow[2] * 2}%;background:radial-gradient(circle, ${p.glow[3]}cc, transparent 70%)"></i>` : "");
    const skirt = p.skirt ? `<div class="part pp-skirt" style="background-image:${img};clip-path:inset(${p.skirt}% 0 0 0);transform-origin:50% ${p.skirt}%"></div>` : "";
    return `<div class="av-svg pp-wrap mood-neutral" data-char="${id}" role="img" aria-label="${k.name}">
      <div class="pp" style="--s:${v.s};--cx:${v.cx};--cy:${v.cy};aspect-ratio:${p.w}/${p.h}">
        <div class="pp-scale">
          <div class="part torso pp-body" style="background-image:${img}"></div>
          ${skirt}
          <div class="part head pp-head" style="background-image:${img};-webkit-mask-image:${mask};mask-image:${mask};transform-origin:${p.pivot[0]}% ${p.pivot[1]}%">${face}</div>
        </div>
      </div>
      <div class="pp-hand">👋</div>
      <div class="av-fx"></div><div class="av-bars"><i></i><i></i><i></i><i></i><i></i></div></div>`;
  },

  // Default is YOUR exact pictures (cut into moving pieces); the drawn cartoon is only used if chosen in Settings
  look() { try { const c = Companion.get() || {}; return c.lookV3 ? (c.look || "photo") : "photo"; } catch (e) { return "photo"; } },

  // Kei is a real 3D model (js/char3d.js): drag to turn, or use the buttons for a 360 degree spin
  kei3d(headOnly) {
    const ui = headOnly ? "" : `<div class="kei-ui"><button type="button" class="kei-spin" title="Turn all the way round">↻ 360°</button><button type="button" class="kei-auto" title="Keep turning">Auto-spin</button><button type="button" class="kei-reset" title="Back to the front">Reset</button></div><div class="kei-hint">Drag to turn · scroll to zoom</div>`;
    return `<div class="av-svg kei3d mood-neutral" data-char="kei" data-mode="${headOnly ? "face" : "stage"}" role="img" aria-label="Kei"><canvas></canvas>${ui}<div class="av-fx"></div></div>`;
  },

  svg(id, headOnly) {
    if (id === "kei") return this.kei3d(headOnly);
    if (this.look() === "photo" && this.PUPPET[id]) return this.puppet(id, headOnly);
    const k = this.CHARS[id] || this.CHARS.kai;
    const inner = headOnly ? this.faceSvg(id) : this.figure(id);
    return `<div class="av-svg mood-neutral" data-char="${id}" role="img" aria-label="${k.name}">${inner}
      <div class="av-fx"></div><div class="av-bars"><i></i><i></i><i></i><i></i><i></i></div></div>`;
  },

  all() { return document.querySelectorAll(".av-svg"); },

  setMood(m) {
    const cls = "mood-" + ({ Happy: "happy", Sad: "sad", Anxious: "sad", Angry: "sad", Calm: "calm" }[m] || "neutral");
    this.all().forEach(s => { s.classList.remove("mood-happy", "mood-sad", "mood-calm", "mood-neutral"); s.classList.add(cls); });
  },

  wave(ms = 2400) {
    this.all().forEach(s => s.classList.add("waving"));
    clearTimeout(this._waveT);
    this._waveT = setTimeout(() => this.all().forEach(s => s.classList.remove("waving")), ms);
  },

  listening(on) { this.all().forEach(s => s.classList.toggle("listening", on)); },

  // Talking: mouth opens/closes, head bobs slightly, arm gestures -- all independent parts
  talk(on, maxMs) {
    clearTimeout(this._talkStop);
    this.all().forEach(s => s.classList.toggle("talking", !!on));
    if (on) this._talkStop = setTimeout(() => this.talk(false), maxMs || 25000);
  },

  // Guided breathing: chest/torso rises on the in-breath
  breath(phase) {
    this.all().forEach(s => { s.classList.remove("inhale", "exhale"); if (phase === "in") s.classList.add("inhale"); else if (phase === "out") s.classList.add("exhale"); });
  },

  // ---- lifelike one-shot acts: real limbs swing, legs step, head turns ----
  ACTS: {
    walk:    { ms: 2200, fx: [] },
    jump:    { ms: 900,  fx: ["✨", "⭐"] },
    dance:   { ms: 2400, fx: ["🎵", "🎶", "✨"] },
    nod:     { ms: 1300, fx: ["💛", "🌸"] },
    shake:   { ms: 1200, fx: [] },
    tilt:    { ms: 1500, fx: ["❓"] },
    cheer:   { ms: 1700, fx: ["🎉", "✨", "⭐", "💛"] },
    comfort: { ms: 2400, fx: ["💙", "🌧️"] },
    hearts:  { ms: 2000, fx: ["💗", "💖", "💕"] },
    wink:    { ms: 900,  fx: ["✨"] },
    think:   { ms: 1800, fx: ["💭"] }
  },

  act(name, opts = {}) {
    const def = this.ACTS[name];
    if (!def) return;
    this.all().forEach(s => {
      Object.keys(this.ACTS).forEach(n => s.classList.remove("act-" + n));
      void s.offsetWidth;
      s.classList.add("act-" + name);
    });
    if (typeof Char3D !== "undefined") Char3D.act(name);
    if (def.fx.length && !opts.quiet) this.fx(def.fx, name === "cheer" || name === "hearts" ? 9 : 5);
    clearTimeout(this._actT);
    this._actT = setTimeout(() => this.all().forEach(s => s.classList.remove("act-" + name)), def.ms);
  },

  fx(list, n) {
    document.querySelectorAll(".av-fx").forEach(box => {
      n = Math.min(n, Math.max(0, 14 - box.children.length));
      for (let i = 0; i < n; i++) {
        const p = document.createElement("span");
        p.textContent = list[Math.floor(Math.random() * list.length)];
        p.style.left = (Math.random() < .5 ? 3 + Math.random() * 20 : 77 + Math.random() * 18) + "%";
        p.style.animationDelay = (Math.random() * 0.7).toFixed(2) + "s";
        p.style.fontSize = (1 + Math.random() * 0.9).toFixed(2) + "rem";
        box.appendChild(p);
        setTimeout(() => p.remove(), 2600);
      }
    });
  },

  life() {
    if (this._life) return;
    const tick = () => {
      this._life = setTimeout(tick, 4500 + Math.random() * 5000);
      if (document.hidden) return;
      const busy = this.all()[0] && ["talking", "listening", "inhale", "exhale", "waving"].some(c => this.all()[0].classList.contains(c));
      if (busy) return;
      const pick = ["tilt", "nod", "jump", "walk", "wink", "think", "wave", "dance"];
      const choice = pick[Math.floor(Math.random() * pick.length)];
      if (choice === "wave") this.wave(1800); else this.act(choice, { quiet: true });
    };
    this._life = setTimeout(tick, 5000);
  },
  stopLife() { clearTimeout(this._life); this._life = null; }
};
