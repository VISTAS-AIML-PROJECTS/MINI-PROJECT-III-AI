// One place that talks to the AI. The provider is chosen from the key itself:
//   sk-ant-...  -> Anthropic (Claude, paid)
//   AIza...     -> Google Gemini (has a free tier)
const AIClient = {
  GEMINI_MODELS: ["gemini-3.1-flash-lite", "gemini-3-flash-preview", "gemini-3.5-flash"], // tried in order if one is not available
  _okGemini: null,

  clean(k) { return String(k || "").replace(/[\s"'`]/g, ""); },
  provider(key) { return /^AIza/.test(this.clean(key)) ? "gemini" : "anthropic"; },
  keyHelp() { return "Anthropic keys start with sk-ant- (console.anthropic.com). Free Google Gemini keys start with AIza (aistudio.google.com/apikey)."; },

  fail(msg, code) { const e = new Error(msg); if (code) e.code = code; return e; },

  // system: string, messages: [{role:"user"|"assistant", content}], returns the reply text
  async complete({ system, messages, maxTokens = 800, settings, media }) {
    const key = this.clean(settings && settings.apiKey);
    if (!key) throw this.fail("No AI key set", "no-key");
    return this.provider(key) === "gemini"
      ? this.gemini(key, system, messages, maxTokens, media)
      : this.anthropic(key, settings, system, messages, maxTokens, media);
  },

  async anthropic(key, settings, system, messages, maxTokens, media) {
    if (media && media.length) {
      const bad = media.find(m => m.kind !== "inline" || !/^image\//.test(m.mime));
      if (bad) throw this.fail("Audio, video and YouTube links need a free Google Gemini key (starts with AIza). Claude keys can read photos, PDFs and Word files only.", "needs-gemini");
      messages = messages.map(m => ({ ...m }));
      const last = messages[messages.length - 1];
      last.content = [...media.map(m => ({ type: "image", source: { type: "base64", media_type: m.mime, data: m.data } })), { type: "text", text: String(last.content || "") }];
    }
    let res;
    try {
      res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({ model: settings.model || "claude-sonnet-5-5", max_tokens: maxTokens, system, messages })
      });
    } catch (e) { throw this.fail("Could not reach Anthropic. Check your internet connection and that the app is opened from a web address, not a file."); }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401) throw this.fail("Anthropic rejected your AI key as invalid. " + this.keyHelp(), "bad-key");
      if (res.status === 403) throw this.fail("Your AI key does not have permission for this request.", "bad-key");
      if (res.status === 429) throw this.fail("Too many requests right now. Wait a minute and try again.");
      throw this.fail((data.error && data.error.message) || `HTTP ${res.status}`);
    }
    const part = (data.content || []).find(p => p.type === "text");
    if (!part) throw this.fail("No reply received.");
    return part.text.trim();
  },

  async gemini(key, system, messages, maxTokens, media) {
    // Gemini wants "model" instead of "assistant", and turns must alternate
    const contents = [];
    for (const m of messages) {
      const role = m.role === "assistant" ? "model" : "user", text = String(m.content || "");
      if (contents.length && contents[contents.length - 1].role === role) contents[contents.length - 1].parts[0].text += "\n" + text;
      else contents.push({ role, parts: [{ text }] });
    }
    if (!contents.length || contents[0].role !== "user") contents.unshift({ role: "user", parts: [{ text: "Hello." }] });
    if (media && media.length) {
      const extra = media.map(m => m.kind === "youtube" ? { file_data: { file_uri: m.url } } : { inline_data: { mime_type: m.mime, data: m.data } });
      const last = contents[contents.length - 1];
      last.parts = [...extra, ...last.parts];
    }
    const body = JSON.stringify({ systemInstruction: { parts: [{ text: system || "" }] }, contents, generationConfig: { maxOutputTokens: Math.max(maxTokens, 2048) } });
    const order = this._okGemini ? [this._okGemini, ...this.GEMINI_MODELS.filter(m => m !== this._okGemini)] : this.GEMINI_MODELS;
    let lastErr = null;
    for (const model of order) {
      let res;
      try {
        res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
          method: "POST", headers: { "content-type": "application/json", "x-goog-api-key": key }, body
        });
      } catch (e) { throw this.fail("Could not reach Google Gemini. Check your internet connection."); }
      const data = await res.json().catch(() => ({}));
      const apiMsg = (data.error && data.error.message) || "";
      if (res.ok) {
        const parts = (((data.candidates || [])[0] || {}).content || {}).parts || [];
        const text = parts.map(p => p.text || "").join("").trim();
        if (!text) { lastErr = this.fail("Gemini sent no text back (it may have blocked the reply). Try again."); continue; }
        this._okGemini = model;
        return text;
      }
      if (res.status === 400 && /api key/i.test(apiMsg)) throw this.fail("Google rejected your Gemini key as invalid. " + this.keyHelp(), "bad-key");
      if (res.status === 401 || res.status === 403) throw this.fail("Google rejected your Gemini key (no permission). Create a fresh free key at aistudio.google.com/apikey.", "bad-key");
      if (res.status === 429) throw this.fail("Gemini's free limit was reached for now. Wait a minute and try again, or try tomorrow.");
      const modelProblem = res.status === 404 || (res.status === 400 && /model/i.test(apiMsg) && !/video|youtube|audio|image|file|media/i.test(apiMsg));
      if (modelProblem) { lastErr = this.fail(apiMsg || `Model ${model} not available`); continue; } // try the next model name
      if (res.status === 400) throw this.fail(apiMsg || "Gemini could not use that upload.");
      throw this.fail(apiMsg || `HTTP ${res.status}`);
    }
    throw lastErr || this.fail("Gemini did not answer.");
  }
};
