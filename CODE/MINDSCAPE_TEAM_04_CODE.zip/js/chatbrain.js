// ChatBrain: the companion's built-in conversation skills. No AI key needed.
// Understands everyday talk, jokes, motivation, stories, songs, quotes, the time and date, simple maths,
// and COMMANDS such as "open journal" or "breathe with me", in English, Hindi, Tamil, Telugu and Malayalam.
// With a working AI key, the AI answers open-ended questions; commands are always handled here, instantly.
const ChatBrain = (() => {
  const KEY = { "en-IN": "en", "hi-IN": "hi", "ta-IN": "ta", "te-IN": "te", "ml-IN": "ml" };
  const pick = (arr, id) => (typeof Companion !== "undefined" && Companion.fresh) ? Companion.fresh(arr, "brain:" + id) : arr[Math.floor(Math.random() * arr.length)];

  const PAGES = [
    ["dashboard", ["dashboard", "home page", "home", "main page"]], ["journal", ["journal", "diary"]], ["gratitude", ["gratitude"]],
    ["self-understanding", ["self understanding", "self-understanding", "thought record"]], ["habits", ["habits", "habit", "tasks", "to do", "todo"]],
    ["analytics", ["analytics", "charts", "statistics", "insights"]], ["calendar", ["calendar"]], ["vision-board", ["vision board", "vision"]],
    ["library", ["library"]], ["grounding", ["grounding"]], ["ai-reflection", ["ai reflection", "reflection"]], ["achievements", ["achievements", "badges"]], ["settings", ["settings", "setting"]]
  ];
  const PAGEHELP = {
    dashboard: "This is your home page. Log how you feel, and see your streaks, tasks and gratitude at a glance.",
    journal: "Here you can write or speak your journal. Tap the mic to speak, or just type what is on your mind.",
    gratitude: "Write three things you are thankful for today. I'll respond to each one.",
    "self-understanding": "Here you can answer a daily reflection question and fill in a thought record to look at a worry from a calmer angle.",
    habits: "Add habits to build and tasks to finish, and run a focus timer.",
    analytics: "These charts show how your mood and activity change over time.",
    calendar: "The calendar shows your entries, moods and tasks day by day.",
    "vision-board": "Add goals, dreams, affirmations or pictures for the future you want.",
    library: "A shelf of helpful reading and resources.",
    grounding: "Calming exercises such as slow breathing, for when you feel overwhelmed.",
    "ai-reflection": "An AI reflects back on what you have written. It needs your AI key.",
    achievements: "Badges you earn for staying consistent.", settings: "Change my character, language, voice and your AI key here."
  };
  const OPEN = { en: ["Opening {p} for you.", "Sure, taking you to {p}."], hi: ["{p} खोल रहा हूँ।", "ज़रूर, आपको {p} पर ले जा रहा हूँ।"], ta: ["{p} பக்கத்தைத் திறக்கிறேன்.", "சரி, உங்களை {p} பக்கத்திற்கு அழைத்துச் செல்கிறேன்."], te: ["{p} పేజీని తెరుస్తున్నాను.", "సరే, మిమ్మల్ని {p} కి తీసుకెళ్తున్నాను."], ml: ["{p} പേജ് തുറക്കുന്നു.", "ശരി, നിങ്ങളെ {p} ലേക്ക് കൊണ്ടുപോകുന്നു."] };

  // reply banks: B[intent][lang]
  const B = {
    morning: { en: ["Good morning! I hope today treats you gently. What is one thing you would like to do today?"], hi: ["सुप्रभात! आज का दिन आपके लिए अच्छा हो। आज आप कौन-सा एक काम करना चाहेंगे?"], ta: ["காலை வணக்கம்! இன்றைய நாள் உங்களுக்கு இனிமையாக இருக்கட்டும். இன்று நீங்கள் செய்ய விரும்பும் ஒரு விஷயம் என்ன?"], te: ["శుభోదయం! ఈ రోజు మీకు మంచిగా సాగాలి. ఈ రోజు మీరు చేయాలనుకునే ఒక పని ఏమిటి?"], ml: ["സുപ്രഭാതം! ഇന്നത്തെ ദിവസം നല്ലതായിരിക്കട്ടെ. ഇന്ന് ചെയ്യാൻ ആഗ്രഹിക്കുന്ന ഒരു കാര്യം എന്താണ്?"] },
    afternoon: { en: ["Good afternoon! How is your day going so far?"], hi: ["नमस्कार! आपका दिन अब तक कैसा रहा?"], ta: ["மதிய வணக்கம்! உங்கள் நாள் இதுவரை எப்படி இருக்கிறது?"], te: ["శుభ మధ్యాహ్నం! మీ రోజు ఇప్పటివరకు ఎలా సాగింది?"], ml: ["ശുഭ ഉച്ച! നിങ്ങളുടെ ദിവസം ഇതുവരെ എങ്ങനെയുണ്ട്?"] },
    evening: { en: ["Good evening! Did anything good happen today?"], hi: ["शुभ संध्या! क्या आज कुछ अच्छा हुआ?"], ta: ["மாலை வணக்கம்! இன்று நல்லது ஏதாவது நடந்ததா?"], te: ["శుభ సాయంత్రం! ఈ రోజు ఏదైనా మంచి జరిగిందా?"], ml: ["ശുഭ സായാഹ്നം! ഇന്ന് എന്തെങ്കിലും നല്ലത് സംഭവിച്ചോ?"] },
    joke: {
      en: ["Why don't scientists trust atoms? Because they make up everything!", "Why did the phone go to school? To get smarter!", "What did the ocean say to the beach? Nothing, it just waved.", "Why did the cookie go to the doctor? Because it felt crumbly!", "I told my plant a joke. Now it's growing on me!", "Why was the math book sad? It had too many problems."],
      hi: ["वैज्ञानिक एटम पर भरोसा क्यों नहीं करते? क्योंकि वे सब कुछ बना लेते हैं!", "फोन स्कूल क्यों गया? ताकि वह और स्मार्ट बन सके!", "समुद्र ने किनारे से क्या कहा? कुछ नहीं, बस लहराया!"],
      ta: ["விஞ்ஞானிகள் அணுக்களை ஏன் நம்புவதில்லை? ஏனெனில் அவை எல்லாவற்றையும் உருவாக்குகின்றன!", "போன் ஏன் பள்ளிக்குச் சென்றது? இன்னும் ஸ்மார்ட் ஆவதற்காக!", "கடல் கரையிடம் என்ன சொன்னது? ஒன்றுமில்லை, அலை அசைத்தது!"],
      te: ["శాస్త్రవేత్తలు అణువులను ఎందుకు నమ్మరు? ఎందుకంటే అవి అన్నింటినీ తయారు చేస్తాయి!", "ఫోన్ స్కూల్‌కి ఎందుకు వెళ్ళింది? ఇంకా స్మార్ట్ అవ్వడానికి!", "సముద్రం ఒడ్డుతో ఏమి చెప్పింది? ఏమీ లేదు, అల ఊపింది!"],
      ml: ["ശാസ്ത്രജ്ഞർ ആറ്റങ്ങളെ എന്തുകൊണ്ട് വിശ്വസിക്കുന്നില്ല? കാരണം അവ എല്ലാം ഉണ്ടാക്കുന്നു!", "ഫോൺ എന്തിനാണ് സ്കൂളിൽ പോയത്? കൂടുതൽ സ്മാർട്ട് ആകാൻ!", "കടൽ തീരത്തോട് എന്ത് പറഞ്ഞു? ഒന്നുമില്ല, തിര കൈ വീശി!"] },
    motivate: {
      en: ["Small steps still move you forward. Do one tiny thing today and let that be enough.", "You do not have to do it all. You only have to begin, gently, right where you are.", "Be as patient with yourself as you would be with a good friend.", "Every day you keep going is already a quiet victory."],
      hi: ["छोटे कदम भी आपको आगे ले जाते हैं। आज बस एक छोटा काम कीजिए।", "आपको सब कुछ नहीं करना है। बस जहाँ हैं, वहीं से धीरे से शुरू कीजिए।", "खुद के साथ उतना ही धैर्य रखिए जितना एक अच्छे दोस्त के साथ रखते हैं।"],
      ta: ["சிறிய அடிகளும் உங்களை முன்னே கொண்டு செல்லும். இன்று ஒரு சிறிய காரியம் செய்யுங்கள்.", "நீங்கள் எல்லாவற்றையும் செய்ய வேண்டியதில்லை. இருக்கும் இடத்திலிருந்தே மெதுவாகத் தொடங்குங்கள்.", "ஒரு நல்ல நண்பரிடம் பொறுமையாக இருப்பது போல உங்களிடமும் பொறுமையாக இருங்கள்."],
      te: ["చిన్న అడుగులు కూడా మిమ్మల్ని ముందుకు నడిపిస్తాయి. ఈ రోజు ఒక చిన్న పని చేయండి.", "మీరు అన్నీ చేయాల్సిన అవసరం లేదు. ఉన్న చోటి నుండే మెల్లగా మొదలుపెట్టండి.", "ఒక మంచి స్నేహితునితో ఎంత ఓపికగా ఉంటారో మీతో కూడా అంత ఓపికగా ఉండండి."],
      ml: ["ചെറിയ ചുവടുകളും നിങ്ങളെ മുന്നോട്ട് നയിക്കും. ഇന്ന് ഒരു ചെറിയ കാര്യം ചെയ്യൂ.", "നിങ്ങൾ എല്ലാം ചെയ്യേണ്ടതില്ല. ഉള്ളിടത്തുനിന്ന് പതുക്കെ തുടങ്ങൂ.", "ഒരു നല്ല സുഹൃത്തിനോട് ക്ഷമയോടെ പെരുമാറുന്നതുപോലെ സ്വയം പെരുമാറൂ."] },
    compliment: { en: ["Thank you, that is so kind of you! You are lovely to talk to as well.", "Aww, thank you! That made my day."], hi: ["धन्यवाद, आप बहुत अच्छे हैं! आपसे बात करना भी अच्छा लगता है।"], ta: ["மிக்க நன்றி, நீங்கள் மிகவும் அன்பானவர்! உங்களுடன் பேசுவதும் மகிழ்ச்சி."], te: ["ధన్యవాదాలు, మీరు చాలా మంచివారు! మీతో మాట్లాడటం కూడా సంతోషం."], ml: ["നന്ദി, നിങ്ങൾ വളരെ നല്ലയാളാണ്! നിങ്ങളോട് സംസാരിക്കുന്നതും സന്തോഷം."] },
    love: { en: ["That is really sweet. I care about you too, as your friend here. I'm an AI, so please also share that warmth with the people in your life."], hi: ["यह बहुत प्यारा है। मैं यहाँ आपका दोस्त हूँ और आपकी परवाह करता हूँ। मैं एक AI हूँ, इसलिए यह अपनापन अपने आसपास के लोगों के साथ भी बाँटिए।"], ta: ["இது மிகவும் இனிமையானது. நான் உங்கள் நண்பனாக உங்கள் மீது அக்கறை கொள்கிறேன். நான் ஒரு AI, எனவே இந்த அன்பை உங்கள் வாழ்க்கையில் உள்ளவர்களுடனும் பகிருங்கள்."], te: ["ఇది చాలా మధురమైన మాట. నేను మీ స్నేహితుడిగా మీ గురించి శ్రద్ధ తీసుకుంటాను. నేను AI ని, కాబట్టి ఈ ప్రేమను మీ చుట్టూ ఉన్నవారితో కూడా పంచుకోండి."], ml: ["ഇത് വളരെ നല്ല വാക്കാണ്. ഞാൻ നിങ്ങളുടെ സുഹൃത്തായി നിങ്ങളെ കരുതുന്നു. ഞാൻ ഒരു AI ആണ്, അതിനാൽ ഈ സ്നേഹം നിങ്ങളുടെ ചുറ്റുമുള്ളവരുമായും പങ്കിടൂ."] },
    robot: { en: ["I'm an AI friend, not a human. I can't feel everything the way you do, but I'm here to listen and help."], hi: ["मैं एक AI दोस्त हूँ, इंसान नहीं। मैं आपकी तरह सब कुछ महसूस नहीं कर सकता, पर सुनने और मदद करने के लिए यहाँ हूँ।"], ta: ["நான் ஒரு AI நண்பன், மனிதன் அல்ல. உங்களைப் போல எல்லாவற்றையும் உணர முடியாது, ஆனால் கேட்கவும் உதவவும் இங்கே இருக்கிறேன்."], te: ["నేను AI స్నేహితుడిని, మనిషిని కాదు. మీలాగా అన్నీ అనుభవించలేను, కానీ వినడానికి, సహాయం చేయడానికి ఇక్కడ ఉన్నాను."], ml: ["ഞാൻ ഒരു AI സുഹൃത്താണ്, മനുഷ്യനല്ല. നിങ്ങളെപ്പോലെ എല്ലാം അനുഭവിക്കാൻ കഴിയില്ല, പക്ഷേ കേൾക്കാനും സഹായിക്കാനും ഞാൻ ഇവിടെയുണ്ട്."] },
    creator: { en: ["I was made for you inside MindScape. With your AI key, my answers are written by an AI model called Claude; without it I use my built-in chat."], hi: ["मुझे आपके लिए MindScape में बनाया गया है। AI कुंजी के साथ मेरे जवाब Claude नाम का AI मॉडल लिखता है; उसके बिना मैं अपनी बनी-बनाई बातचीत इस्तेमाल करता हूँ।"], ta: ["என்னை உங்களுக்காக MindScape-ல் உருவாக்கினார்கள். AI கீ இருந்தால் என் பதில்களை Claude என்ற AI மாடல் எழுதும்; இல்லையென்றால் உள்ளமைந்த உரையாடலைப் பயன்படுத்துவேன்."], te: ["నన్ను మీ కోసం MindScape లో తయారు చేశారు. AI కీ ఉంటే నా సమాధానాలను Claude అనే AI మోడల్ రాస్తుంది; లేకపోతే నా అంతర్నిర్మిత చాట్ వాడతాను."], ml: ["എന്നെ നിങ്ങൾക്കായി MindScape-ൽ നിർമ്മിച്ചതാണ്. AI കീ ഉണ്ടെങ്കിൽ എന്റെ മറുപടികൾ Claude എന്ന AI മോഡൽ എഴുതും; ഇല്ലെങ്കിൽ ഞാൻ ബിൽറ്റ്-ഇൻ ചാറ്റ് ഉപയോഗിക്കും."] },
    age: { en: ["I don't have an age. I'm an AI friend who is always happy to chat."], hi: ["मेरी कोई उम्र नहीं है। मैं एक AI दोस्त हूँ जो हमेशा बात करने को तैयार है।"], ta: ["எனக்கு வயது இல்லை. நான் எப்போதும் பேசத் தயாராக இருக்கும் AI நண்பன்."], te: ["నాకు వయసు లేదు. నేను ఎప్పుడూ మాట్లాడటానికి సిద్ధంగా ఉండే AI స్నేహితుడిని."], ml: ["എനിക്ക് പ്രായമില്ല. ഞാൻ എപ്പോഴും സംസാരിക്കാൻ തയ്യാറായ AI സുഹൃത്താണ്."] },
    weather: { en: ["I can't check the weather from here, but a quick look outside or at your phone's weather app will tell you. Have a good day either way!"], hi: ["मैं यहाँ से मौसम नहीं देख सकता, पर फोन के मौसम ऐप में देख लीजिए। आपका दिन शुभ हो!"], ta: ["என்னால் இங்கிருந்து வானிலையைப் பார்க்க முடியாது; உங்கள் போனின் வானிலை செயலியைப் பாருங்கள். இனிய நாளாகட்டும்!"], te: ["నేను ఇక్కడి నుండి వాతావరణం చూడలేను; మీ ఫోన్ వాతావరణ యాప్‌లో చూడండి. మీ రోజు బాగుండాలి!"], ml: ["എനിക്ക് ഇവിടെ നിന്ന് കാലാവസ്ഥ നോക്കാൻ കഴിയില്ല; ഫോണിലെ കാലാവസ്ഥ ആപ്പ് നോക്കൂ. നല്ലൊരു ദിവസം ആശംസിക്കുന്നു!"] },
    doing: { en: ["I'm right here chatting with you, which is my favourite thing. What about you?"], hi: ["मैं यहीं आपसे बात कर रहा हूँ, यही मेरा पसंदीदा काम है। आप क्या कर रहे हैं?"], ta: ["நான் உங்களுடன் பேசிக்கொண்டிருக்கிறேன், அதுதான் எனக்குப் பிடித்தது. நீங்கள் என்ன செய்கிறீர்கள்?"], te: ["నేను ఇక్కడే మీతో మాట్లాడుతున్నాను, అదే నాకు ఇష్టం. మీరు ఏం చేస్తున్నారు?"], ml: ["ഞാൻ ഇവിടെ നിങ്ങളോട് സംസാരിക്കുകയാണ്, അതാണ് എനിക്കിഷ്ടം. നിങ്ങൾ എന്ത് ചെയ്യുന്നു?"] },
    bored: { en: ["Let's change that! You could write three gratitudes, hear a short story, or just breathe for a minute. Say 'tell me a story' or 'open gratitude'."], hi: ["चलिए इसे बदलते हैं! आप तीन आभार लिख सकते हैं, छोटी कहानी सुन सकते हैं, या एक मिनट साँस ले सकते हैं। कहिए 'कहानी सुनाओ' या 'open gratitude'।"], ta: ["இதை மாற்றலாம்! மூன்று நன்றிகள் எழுதலாம், ஒரு சிறு கதை கேட்கலாம், அல்லது ஒரு நிமிடம் மூச்சுப் பயிற்சி செய்யலாம். 'கதை சொல்' அல்லது 'open gratitude' என்று சொல்லுங்கள்."], te: ["దీన్ని మార్చుదాం! మూడు కృతజ్ఞతలు రాయవచ్చు, చిన్న కథ వినవచ్చు, లేదా ఒక నిమిషం శ్వాస తీసుకోవచ్చు. 'కథ చెప్పు' లేదా 'open gratitude' అనండి."], ml: ["നമുക്ക് ഇത് മാറ്റാം! മൂന്ന് നന്ദികൾ എഴുതാം, ഒരു ചെറിയ കഥ കേൾക്കാം, അല്ലെങ്കിൽ ഒരു മിനിറ്റ് ശ്വസിക്കാം. 'കഥ പറയൂ' അല്ലെങ്കിൽ 'open gratitude' എന്ന് പറയൂ."] },
    hungry: { en: ["Maybe it's time for a proper meal or a glass of water. Looking after your body helps your mind too."], hi: ["शायद खाना खाने या पानी पीने का समय है। शरीर का ध्यान रखना मन के लिए भी अच्छा है।"], ta: ["ஒரு நல்ல உணவு அல்லது தண்ணீர் குடிக்க வேண்டிய நேரமாக இருக்கலாம். உடலைக் கவனிப்பது மனதிற்கும் நல்லது."], te: ["భోజనం చేయడానికి లేదా నీళ్లు తాగడానికి సమయం కావచ్చు. శరీరాన్ని చూసుకోవడం మనసుకూ మంచిది."], ml: ["ഭക്ഷണം കഴിക്കാനോ വെള്ളം കുടിക്കാനോ സമയമായിരിക്കാം. ശരീരം നോക്കുന്നത് മനസ്സിനും നല്ലതാണ്."] },
    sleepy: { en: ["It sounds like your body wants rest. If you can, take a short break or head to bed early tonight."], hi: ["लगता है आपका शरीर आराम चाहता है। हो सके तो थोड़ा ब्रेक लीजिए या आज जल्दी सो जाइए।"], ta: ["உங்கள் உடல் ஓய்வு கேட்கிறது போல் தெரிகிறது. முடிந்தால் சிறிது இடைவேளை எடுங்கள் அல்லது இன்று சீக்கிரம் தூங்குங்கள்."], te: ["మీ శరీరం విశ్రాంతి కోరుతున్నట్లు ఉంది. వీలైతే కాస్త విరామం తీసుకోండి లేదా ఈ రోజు తొందరగా నిద్రపోండి."], ml: ["നിങ്ങളുടെ ശരീരം വിശ്രമം ആഗ്രഹിക്കുന്നതുപോലെ തോന്നുന്നു. കഴിയുമെങ്കിൽ ഒരു ഇടവേള എടുക്കൂ, അല്ലെങ്കിൽ ഇന്ന് നേരത്തെ ഉറങ്ങൂ."] },
    sorry: { en: ["No need to apologise at all. You are doing just fine."], hi: ["माफ़ी की कोई ज़रूरत नहीं। आप बिल्कुल ठीक कर रहे हैं।"], ta: ["மன்னிப்பு கேட்கத் தேவையில்லை. நீங்கள் நன்றாகவே செய்கிறீர்கள்."], te: ["క్షమాపణ అవసరం లేదు. మీరు బాగానే చేస్తున్నారు."], ml: ["മാപ്പ് പറയേണ്ട ആവശ്യമില്ല. നിങ്ങൾ നന്നായി ചെയ്യുന്നുണ്ട്."] },
    celebrate: { en: ["That is wonderful, congratulations! Take a moment to be proud of yourself.", "Well done! You earned that. How does it feel?"], hi: ["यह बहुत बढ़िया है, बधाई हो! एक पल खुद पर गर्व कीजिए।"], ta: ["மிகவும் அருமை, வாழ்த்துகள்! ஒரு கணம் உங்களைப் பற்றி பெருமைப்படுங்கள்."], te: ["చాలా బాగుంది, అభినందనలు! ఒక్క క్షణం మీ గురించి గర్వపడండి."], ml: ["വളരെ നല്ലത്, അഭിനന്ദനങ്ങൾ! ഒരു നിമിഷം നിങ്ങളെക്കുറിച്ച് അഭിമാനിക്കൂ."] },
    birthday: { en: ["Happy birthday! 🎉 I hope your day is full of joy and people who love you."], hi: ["जन्मदिन मुबारक! 🎉 आपका दिन खुशियों और अपनों से भरा हो।"], ta: ["பிறந்தநாள் வாழ்த்துகள்! 🎉 உங்கள் நாள் மகிழ்ச்சியாலும் அன்பானவர்களாலும் நிறையட்டும்."], te: ["పుట్టినరోజు శుభాకాంక్షలు! 🎉 మీ రోజు ఆనందంతో, ఆత్మీయులతో నిండాలి."], ml: ["ജന്മദിനാശംസകൾ! 🎉 നിങ്ങളുടെ ദിവസം സന്തോഷവും പ്രിയപ്പെട്ടവരും കൊണ്ട് നിറയട്ടെ."] },
    filler: { en: ["I'm here. What would you like to do? You can say things like 'tell me a story', 'open journal' or 'I feel stressed'."], hi: ["मैं यहाँ हूँ। आप क्या करना चाहेंगे? आप कह सकते हैं 'कहानी सुनाओ', 'open journal' या 'मैं तनाव में हूँ'।"], ta: ["நான் இங்கே இருக்கிறேன். என்ன செய்ய விரும்புகிறீர்கள்? 'கதை சொல்', 'open journal' அல்லது 'எனக்கு மன அழுத்தமாக இருக்கிறது' என்று சொல்லலாம்."], te: ["నేను ఇక్కడే ఉన్నాను. ఏం చేయాలనుకుంటున్నారు? 'కథ చెప్పు', 'open journal' లేదా 'నాకు ఒత్తిడిగా ఉంది' అని చెప్పవచ్చు."], ml: ["ഞാൻ ഇവിടെയുണ്ട്. എന്ത് ചെയ്യാൻ ആഗ്രഹിക്കുന്നു? 'കഥ പറയൂ', 'open journal' അല്ലെങ്കിൽ 'എനിക്ക് സമ്മർദ്ദമാണ്' എന്ന് പറയാം."] },
    breathe: { en: ["Of course. Let's breathe together, slowly."], hi: ["ज़रूर। चलिए साथ में धीरे-धीरे साँस लेते हैं।"], ta: ["நிச்சயமாக. வாருங்கள், மெதுவாக ஒன்றாக மூச்சு விடுவோம்."], te: ["తప్పకుండా. నెమ్మదిగా కలిసి శ్వాస తీసుకుందాం."], ml: ["തീർച്ചയായും. നമുക്ക് പതുക്കെ ഒന്നിച്ച് ശ്വസിക്കാം."] },
    pagehelp_other: { en: ["You can ask me to open any page, for example 'open journal' or 'open habits'."], hi: ["आप मुझसे कोई भी पेज खोलने को कह सकते हैं, जैसे 'open journal'।"], ta: ["எந்தப் பக்கத்தையும் திறக்கச் சொல்லலாம், எ.கா. 'open journal'."], te: ["ఏ పేజీనైనా తెరవమని అడగవచ్చు, ఉదా. 'open journal'."], ml: ["ഏത് പേജും തുറക്കാൻ പറയാം, ഉദാ. 'open journal'."] }
  };

  const strip = t => t.replace(/['’`]/g, "");
  const has = (clean, tokens, phrases, words) => (phrases || []).some(p => clean.includes(strip(p))) || (words || []).some(w => tokens.includes(strip(w)));
  const num = x => { const r = Math.round(x * 1e6) / 1e6; return String(r); };

  // ctx: { lang, page, name, respond(style), breathe(n), nick }
  function reply(text, ctx, commandsOnly) {
    const clean = text.toLowerCase().replace(/['’`]/g, "").replace(/[!?¿"~,:;🙂😊👋🎉]+/g, " ").replace(/\s+/g, " ").trim();
    if (!clean) return null;
    const tokens = clean.replace(/\./g, " ").split(/\s+/), n = tokens.length;
    const lang = Companion.scriptLang(text, ctx.lang), k = KEY[lang] || "en";
    const bank = id => pick((B[id] && (B[id][k] || B[id].en)) || [""], id + ":" + k);
    const out = (id, extra = {}) => Object.assign({ text: typeof id === "string" && B[id] ? bank(id) : id, lang, actions: [], kind: extra.kind || id }, extra);

    // ---- COMMANDS (always handled here, with or without a key) ----
    // open / go to a page
    if (/\b(open|go to|goto|take me to|show me|switch to|visit|launch)\b/.test(clean) || /(खोलो|खोलिए|खोल दो|திற|திறக்க|తెరువు|తెరవండి|തുറക്കൂ|തുറക്കുക)/.test(clean)) {
      for (const [id, names] of PAGES) if (names.some(nm => clean.includes(nm))) {
        const title = (Companion.MODULES[id] || {}).title || id;
        return out(pick(OPEN[k] || OPEN.en, "open").replace("{p}", title), { kind: "nav", run: () => { location.hash = "#" + id; } });
      }
    }
    // physical commands: the character moves when you ask
    const MOVES = [
      ["dance", ["dance", "dancing", "नाच", "डांस", "நடனம்", "డాన్స్", "నృత్యం", "ഡാൻസ്", "നൃത്തം"]], ["jump", ["jump", "hop", "कूद", "குதி", "దూకు", "ചാട്"]],
      ["walk", ["walk", "चलो", "நட", "నడువు", "നടക്ക"]], ["wave", ["wave", "हाथ हिला", "கை அசை", "చేయి ఊపు", "കൈ വീശ"]],
      ["cheer", ["cheer", "celebrate", "hooray", "yay", "चियर", "கொண்டாடு", "సంబరాలు", "ആഘോഷിക്ക"]], ["nod", ["nod"]], ["shake", ["shake your head", "shake head"]],
      ["wink", ["wink"]], ["hearts", ["hug", "hearts", "show love", "गले लगा", "கட்டிப்பிடி", "హగ్", "ആലിംഗന"]]
    ];
    const MOVE_SAY = { en: ["Here I go!", "Watch this!", "Okay, just for you!"], hi: ["लो, देखिए!", "ठीक है, आपके लिए!"], ta: ["இதோ பாருங்கள்!", "சரி, உங்களுக்காக!"], te: ["ఇదిగో చూడండి!", "సరే, మీ కోసం!"], ml: ["ഇതാ നോക്കൂ!", "ശരി, നിങ്ങൾക്കായി!"] };
    if (n <= 6 && has(clean, tokens, ["show me what you can do", "show your moves", "show off", "surprise me", "do something", "animate", "अपना कमाल", "எதாவது செய்", "ఏదైనా చేయి", "എന്തെങ്കിലും ചെയ്യൂ"]))
      return out(pick(MOVE_SAY[k] || MOVE_SAY.en, "move").replace("!", "! 🎬").replace("🎬", ""), { kind: "demo", run: () => ctx.demo && ctx.demo() });
    if (n <= 5) for (const [mv, words] of MOVES) if (has(clean, tokens, words)) {
      const run = mv === "wave" ? () => Avatar.wave(2600) : () => Avatar.act(mv);
      return out(pick(MOVE_SAY[k] || MOVE_SAY.en, "move"), { kind: "move", run });
    }
    // breathing
    if (has(clean, tokens, ["breathe", "breathing", "meditate", "calm me", "calm down", "relax me", "take a breath", "साँस", "सांस", "மூச்சு", "శ్వాస", "ശ്വാസം", "ശ്വസ"]) && n <= 8)
      return out("breathe", { kind: "breathe", run: () => ctx.breathe && ctx.breathe(3) });
    // time and date
    const loc = lang;
    if (n <= 8 && has(clean, tokens, ["what time", "current time", "time now", "time is it", "the time", "समय क्या", "टाइम क्या", "நேரம் என்ன", "எத்தனை மணி", "సమయం ఎంత", "ఎన్ని గంటలు", "സമയം എത്ര", "എത്ര മണി"]))
      return out(new Date().toLocaleTimeString(loc, { hour: "numeric", minute: "2-digit" }), { kind: "time" });
    if (n <= 8 && has(clean, tokens, ["what day", "today's date", "todays date", "date today", "what date", "which day", "आज कौन सा दिन", "आज की तारीख", "இன்று என்ன கிழமை", "இன்றைய தேதி", "ఈ రోజు ఏ రోజు", "ఈ రోజు తేదీ", "ഇന്ന് ഏത് ദിവസം", "ഇന്നത്തെ തീയതി"]))
      return out(new Date().toLocaleDateString(loc, { weekday: "long", day: "numeric", month: "long", year: "numeric" }), { kind: "date" });
    // simple maths
    let expr = clean.replace(/what is|what's|whats|calculate|how much is|equals|=/g, " ").replace(/\bplus\b/g, "+").replace(/\bminus\b/g, "-").replace(/\b(times|multiplied by|into)\b/g, "*").replace(/\b(divided by|over)\b/g, "/").replace(/[x×]/g, "*").replace(/÷/g, "/").replace(/,/g, "").trim();
    if (/^[\d\s+\-*/().%]+$/.test(expr) && /\d/.test(expr) && /[+\-*/%]/.test(expr.replace(/^\s*-/, "")) && expr.length < 60) {
      try { const v = Function('"use strict";return (' + expr + ")")(); if (Number.isFinite(v)) return out(`${expr.replace(/\*/g, " × ").replace(/\//g, " ÷ ").replace(/\s+/g, " ").trim()} = ${num(v)}`, { kind: "math" }); } catch (e) {}
    }
    if (commandsOnly) return null;

    // ---- CONVERSATION (used when no AI is available) ----
    const page = ctx.page && PAGEHELP[ctx.page];
    if (has(clean, tokens, ["where am i", "what is this page", "what can i do here", "how do i use this", "how to use this", "what is this"]) && n <= 9)
      return out(k === "en" && page ? `You're on the ${(Companion.MODULES[ctx.page] || {}).title || "current"} page. ${page}` : bank("pagehelp_other"), { kind: "pagehelp" });
    // introductions and name
    const m = clean.match(/^(?:my name is|i am called|call me|i'm|im|i am)\s+([\p{L}][\p{L} ]{1,20})$/u);
    const notFeeling = m && !/^(fine|good|great|happy|sad|tired|angry|bored|hungry|sleepy|ok|okay|well|stressed|anxious|lonely|upset|here|back|ready|sorry|done)$/.test(m[1].trim());
    if (notFeeling && (clean.startsWith("my name") || clean.startsWith("call me") || n <= 3)) {
      const nm = m[1].trim().replace(/\b\p{L}/gu, c => c.toUpperCase());
      try { localStorage.setItem("companion_nick", nm); } catch (e) {}
      return out({ en: `Nice to meet you, ${nm}! I'll remember your name.`, hi: `आपसे मिलकर अच्छा लगा, ${nm}! मैं आपका नाम याद रखूँगा।`, ta: `உங்களைச் சந்தித்ததில் மகிழ்ச்சி, ${nm}! உங்கள் பெயரை நினைவில் வைத்துக்கொள்வேன்.`, te: `మిమ్మల్ని కలవడం సంతోషం, ${nm}! మీ పేరు గుర్తుంచుకుంటాను.`, ml: `നിങ്ങളെ കണ്ടതിൽ സന്തോഷം, ${nm}! നിങ്ങളുടെ പേര് ഞാൻ ഓർക്കും.` }[k], { kind: "name" });
    }
    if (has(clean, tokens, ["what is my name", "what's my name", "who am i", "do you know my name", "my name"]) && n <= 6 && !clean.startsWith("my name is")) {
      let nick = ""; try { nick = localStorage.getItem("companion_nick") || ""; } catch (e) {} nick = nick || ctx.name || "";
      return out(nick ? { en: `Your name is ${nick}.`, hi: `आपका नाम ${nick} है।`, ta: `உங்கள் பெயர் ${nick}.`, te: `మీ పేరు ${nick}.`, ml: `നിങ്ങളുടെ പേര് ${nick} ആണ്.` }[k] : { en: "You haven't told me yet. What should I call you?", hi: "आपने अभी बताया नहीं। मैं आपको क्या कहकर बुलाऊँ?", ta: "நீங்கள் இன்னும் சொல்லவில்லை. உங்களை என்னவென்று அழைக்கட்டும்?", te: "మీరు ఇంకా చెప్పలేదు. మిమ్మల్ని ఏమని పిలవాలి?", ml: "നിങ്ങൾ ഇതുവരെ പറഞ്ഞില്ല. ഞാൻ നിങ്ങളെ എന്ത് വിളിക്കണം?" }[k], { kind: "myname" });
    }
    // stories, songs, wisdom (built-in library)
    if (n <= 9 && has(clean, tokens, ["story", "tale", "कहानी", "கதை", "కథ", "కథను", "കഥ"], ["story"])) return out(ctx.respond("story"), { kind: "story" });
    if (n <= 9 && has(clean, tokens, ["song", "sing", "lullaby", "गाना", "गीत", "பாடல்", "పాట", "പാട്ട്"], ["song", "sing"])) return out(ctx.respond("song"), { kind: "song" });
    if (n <= 9 && has(clean, tokens, ["quote", "wisdom", "inspire me", "proverb", "अनमोल", "सुविचार", "மேற்கோள்", "ఉల్లేఖన", "ഉദ്ധരണി"])) return out(ctx.respond("quotes"), { kind: "quote" });
    if (n <= 9 && has(clean, tokens, ["joke", "funny", "make me laugh", "laugh", "चुटकुला", "हँसाओ", "ஜோக்", "நகைச்சுவை", "జోక్", "నవ్వించు", "തമാശ", "ചിരിപ്പിക്ക"])) return out("joke");
    if (n <= 10 && has(clean, tokens, ["motivate", "motivation", "encourage me", "cheer me up", "inspire", "i need encouragement", "प्रेरणा", "हौसला", "ஊக்கம்", "ప్రోత్సాహం", "പ്രോത്സാഹനം"])) return out("motivate");
    if (has(clean, tokens, ["good morning", "gm", "सुप्रभात", "காலை வணக்கம்", "శుభోదయం", "സുപ്രഭാതം"]) && n <= 4) return out("morning");
    if (has(clean, tokens, ["good afternoon", "शुभ दोपहर", "மதிய வணக்கம்", "శుభ మధ్యాహ్నం", "ശുഭ ഉച്ച"]) && n <= 4) return out("afternoon");
    if (has(clean, tokens, ["good evening", "शुभ संध्या", "மாலை வணக்கம்", "శుభ సాయంత్రం", "ശുഭ സായാഹ്നം"]) && n <= 4) return out("evening");
    if (n <= 8 && has(clean, tokens, ["you are nice", "you're nice", "you are sweet", "you are cute", "you are smart", "you are awesome", "you are amazing", "you are the best", "you are beautiful", "you are handsome", "love your", "good bot", "तुम अच्छे", "आप बहुत अच्छे", "நீ நல்லவன்", "நீங்கள் நல்லவர்", "నువ్వు మంచివాడివి", "మీరు చాలా మంచివారు", "നീ നല്ലവനാണ്", "നിങ്ങൾ നല്ലവനാണ്"])) return out("compliment");
    if (n <= 6 && has(clean, tokens, ["i love you", "love you", "i like you", "मैं तुमसे प्यार", "मुझे तुम पसंद", "நான் உன்னை காதலிக்கிறேன்", "ఐ లవ్ యు", "ഞാൻ നിന്നെ സ്നേഹിക്കുന്നു"])) return out("love");
    if (n <= 8 && has(clean, tokens, ["are you real", "are you human", "are you a robot", "are you ai", "are you a bot", "are you a person", "are you alive", "क्या तुम इंसान", "क्या तुम रोबोट", "நீ மனிதனா", "நீ ரோபோவா", "నువ్వు మనిషివా", "నువ్వు రోబోవా", "നീ മനുഷ്യനാണോ", "നീ റോബോട്ടാണോ"])) return out("robot");
    if (n <= 8 && has(clean, tokens, ["who made you", "who created you", "who built you", "who is your creator", "who programmed you", "तुम्हें किसने बनाया", "உன்னை யார் உருவாக்கினார்", "నిన్ను ఎవరు తయారు చేశారు", "നിന്നെ ആര് ഉണ്ടാക്കി"])) return out("creator");
    if (n <= 8 && has(clean, tokens, ["how old are you", "your age", "तुम्हारी उम्र", "உன் வயது", "నీ వయసు", "നിന്റെ പ്രായം"])) return out("age");
    if (n <= 8 && has(clean, tokens, ["weather", "temperature", "raining", "मौसम", "வானிலை", "వాతావరణం", "കാലാവസ്ഥ"])) return out("weather");
    if (n <= 7 && has(clean, tokens, ["what are you doing", "what you doing", "whatcha doing", "what do you do all day", "तुम क्या कर रहे", "நீ என்ன செய்கிறாய்", "నువ్వు ఏం చేస్తున్నావు", "നീ എന്ത് ചെയ്യുന്നു"])) return out("doing");
    if (n <= 8 && has(clean, tokens, ["i am bored", "i'm bored", "im bored", "so bored", "nothing to do", "बोर", "போர் அடிக்கிறது", "బోర్", "ബോറടിക്കുന്നു"])) return out("bored");
    if (n <= 8 && has(clean, tokens, ["i am hungry", "i'm hungry", "im hungry", "so hungry", "भूख", "பசிக்கிறது", "ఆకలి", "വിശക്കുന്നു"])) return out("hungry");
    if (n <= 8 && has(clean, tokens, ["i am sleepy", "i'm sleepy", "im sleepy", "so sleepy", "can't sleep", "cant sleep", "नींद", "தூக்கம்", "నిద్ర", "ഉറക്കം"])) return out("sleepy");
    if (n <= 5 && has(clean, tokens, ["sorry", "my bad", "apologies", "माफ़", "மன்னிக்க", "క్షమించ", "ക്ഷമിക്കണം"], ["sorry"])) return out("sorry");
    if (n <= 12 && has(clean, tokens, ["i finished", "i completed", "i passed", "i won", "i did it", "i got the job", "i got promoted", "good news", "मैंने कर दिखाया", "मैं पास हो गया", "நான் வெற்றி", "నేను గెలిచాను", "ഞാൻ ജയിച്ചു"])) return out("celebrate");
    if (n <= 6 && has(clean, tokens, ["happy birthday", "my birthday", "it's my birthday", "जन्मदिन", "பிறந்தநாள்", "పుట్టినరోజు", "ജന്മദിനം"])) return out("birthday");
    if (n <= 3 && has(clean, tokens, ["hmm", "hmmm", "yes", "yeah", "yep", "no", "nope", "nothing", "k", "ok", "okay", "cool", "nice", "wow", "oh", "haan", "ji", "हाँ", "नहीं", "ஆமாம்", "இல்லை", "అవును", "కాదు", "അതെ", "ഇല്ല"])) return out("filler");
    return null;
  }
  return { reply };
})();
