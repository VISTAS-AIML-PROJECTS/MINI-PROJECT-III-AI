// Safety gate: every entry is screened BEFORE anything is sent to the AI API.
const RiskScreening = {
  HIGH: /\b(kill myself|killing myself|end my life|take my own life|suicid\w*|want to die|wanna die|don'?t want to (live|be alive|exist)|better off dead|no reason to live|hurt myself|harm myself|self[- ]?harm|cut myself|overdose|end it all)\b/i,
  MODERATE: /\b(hopeless|worthless|can'?t cope|can'?t go on|give up|panic attack|empty inside|nobody cares|hate myself|trapped|numb)\b/i,

  check(text) {
    if (this.HIGH.test(text)) return { level: "high" };
    if (this.MODERATE.test(text)) return { level: "moderate" };
    return { level: "clear" };
  }
};

const AI = {
  SYSTEM: "You are a warm, supportive reflection assistant inside a self-reflection app. You are not a therapist. Do not diagnose, label conditions, or give medical advice. In 120 to 180 words, reflect back the feelings and themes you notice, acknowledge them kindly, offer one gentle practical idea, and end with one open reflective question. Write plain text with no lists. If the person seems to be in danger, encourage them to contact a trusted person or local emergency services.",

  render() {
    const entries = Storage.get("journal").slice().reverse().slice(0, 15);
    return `
      <h1>✨ AI Reflection</h1>
      <div class="card">
        <p class="note">MindScape supports self-reflection. It does not diagnose or treat. Every entry is risk-screened first, and nothing is sent to the AI until you click Reflect.</p>
        <label class="field">Use a recent journal entry (optional)
          <select id="ai-pick">
            <option value="">Write something new</option>
            ${entries.map(e => `<option value="${e.id}">${Utils.escape((e.title || "Untitled").slice(0, 40))} (${new Date(e.date).toLocaleDateString()})</option>`).join("")}
          </select>
        </label>
        <label class="field">Reply language
          <select id="ai-lang">${Companion.LANGS.map(([code, name]) => `<option value="${code}">${name}</option>`).join("")}</select>
        </label>
        <textarea id="ai-text" rows="6" placeholder="What would you like to reflect on?"></textarea>
        <div class="row">
          <button class="btn" id="ai-go">Reflect</button>
          <span id="ai-mode" class="sub"></span>
        </div>
      </div>
      <div id="ai-out"></div>`;
  },

  init() {
    const s = Storage.getObject("ai_settings", {});
    document.getElementById("ai-mode").textContent = s.apiKey
      ? "AI mode on"
      : "Offline mode. Add an API key in Settings for AI-written reflections.";
    document.getElementById("ai-pick").addEventListener("change", e => {
      const entry = Storage.get("journal").find(x => x.id === Number(e.target.value));
      document.getElementById("ai-text").value = entry ? entry.text : "";
    });
    const langSel = document.getElementById("ai-lang");
    langSel.value = localStorage.getItem("reflect_lang") || (Companion.get() && Companion.get().lang) || "en-IN";
    langSel.addEventListener("change", () => localStorage.setItem("reflect_lang", langSel.value));
    document.getElementById("ai-go").addEventListener("click", () => this.reflect());
    document.getElementById("ai-out").addEventListener("click", e => {
      if (e.target.closest("#ai-read")) Voice.speak(document.getElementById("ai-reply").textContent, document.getElementById("ai-lang").value);
    });
  },

  leave() { Voice.silence(); },

  supportPanel() {
    return `
      <div class="card support">
        <h3>Let's pause and take care of you first</h3>
        <p>What you wrote sounds very heavy. You do not have to handle this alone. Please consider reaching out to someone you trust, or to a helpline, right now.</p>
        ${HELP.lines.map(l => `<p><b>${Utils.escape(l.name)}:</b> <a class="link" href="tel:${l.number}">${l.number}</a></p>`).join("")}
        <p class="note">${Utils.escape(HELP.note)}</p>
        <p>When you are ready, a grounding exercise can help you settle your body and breathing.</p>
        <a class="btn" href="#grounding">Open grounding exercises</a>
      </div>`;
  },

  async reflect() {
    const text = document.getElementById("ai-text").value.trim();
    const out = document.getElementById("ai-out");
    if (!text) { Utils.toast("Write something to reflect on first."); return; }

    // Stage 1: risk screening, before any AI call
    const risk = RiskScreening.check(text);
    if (risk.level === "high") { out.innerHTML = this.supportPanel(); return; }

    out.innerHTML = `<div class="card"><p class="sub">Reflecting...</p></div>`;
    const settings = Storage.getObject("ai_settings", {});
    let reply, mode;
    try {
      const lang = document.getElementById("ai-lang").value;
      if (settings.apiKey) { reply = await this.callAPI(text, settings, lang); mode = "ai"; }
      else { reply = this.offline(text); mode = "offline"; }
    } catch (err) {
      out.innerHTML = `<div class="card"><p class="msg error">The AI request failed: ${Utils.escape(err.message)}</p>
        <p class="sub">Check your API key and model in Settings, and open the app through Live Server rather than a file.</p></div>`;
      return;
    }
    Storage.save("ai_log", { mode });
    out.innerHTML = `
      ${risk.level === "moderate" ? `<div class="card support"><p>It sounds like things feel difficult. If this feeling lasts or grows, please talk to someone you trust or a helpline (${HELP.lines[0].name}: <a class="link" href="tel:${HELP.lines[0].number}">${HELP.lines[0].number}</a>).</p></div>` : ""}
      <div class="card">
        <h3>Your reflection</h3>
        <p id="ai-reply" class="reply">${Utils.escape(reply).replace(/\n/g, "<br>")}</p>
        ${mode === "offline" ? `<p class="note">${document.getElementById("ai-lang").value !== "en-IN" ? "Offline reflections are in English only. Add an API key in Settings to get this in your chosen language. " : ""}This is a simple offline reflection. Add an API key in Settings for a fuller AI reflection.</p>` : ""}
        ${Voice.ttsSupported ? `<button class="btn-small" id="ai-read">🔊 Read aloud</button>` : ""}
        <p class="note">Self-reflection support only, not medical or clinical advice.</p>
      </div>`;
  },

  async callAPI(text, s, lang) {
    return AIClient.complete({
      settings: s,
      maxTokens: 400,
      system: this.SYSTEM + ` Reply in ${(Companion.LANG_NAMES[lang] || "English")}.`,
      messages: [{ role: "user", content: text }]
    });
  },

  offline(text) {
    const lower = text.toLowerCase();
    const themes = [
      [/exam|study|test|assignment|deadline|college|marks/, "the pressure around studies and deadlines"],
      [/friend|family|mother|father|parents|sister|brother/, "the people close to you"],
      [/tired|sleep|exhaust|drained/, "feeling worn out"],
      [/worr|anxi|nervous|scared|fear/, "worry about what might happen"],
      [/sad|cry|lonely|down|upset/, "feeling low"],
      [/happy|excited|proud|grateful|good/, "the good moments"]
    ].filter(([re]) => re.test(lower)).map(([, t]) => t);
    const topic = themes.length ? themes.slice(0, 2).join(" and ") : "what you shared";
    return `Thank you for putting this into words. I notice that ${topic} seems to matter a lot to you right now, and it makes sense to feel the way you do.\n\n` +
      `One gentle idea: pick the smallest next step that would help today, and give yourself credit for taking it. A few slow breaths before you start can also help.\n\n` +
      `A question to sit with: what do you most need right now, and what is one small way you could give that to yourself?`;
  }
};
