const Journal = {
  TYPES: ["Thought", "Dream", "Mood note", "Other"],
  CATEGORIES: ["General", "Study / Work", "Family", "Friends", "Health", "Relationships", "Growth", "Other"],
  LANGS: [["en-IN", "English (India)"], ["en-US", "English (US)"], ["en-GB", "English (UK)"], ["hi-IN", "Hindi"], ["ta-IN", "Tamil"], ["te-IN", "Telugu"], ["ml-IN", "Malayalam"], ["kn-IN", "Kannada"]],
  selectedMood: null,
  editingId: null,
  listening: false,

  render() {
    const opt = list => list.map(x => `<option>${x}</option>`).join("");
    return `
      <h1>📓 Journal</h1>
      <div class="card">
        <h3>How are you feeling?</h3>
        <div class="mood-picker" id="mood-picker">
          ${MOODS.map(m => `<button type="button" class="mood-btn" data-mood="${m.label}" title="${m.label}">${m.emoji}</button>`).join("")}
        </div>
        <div class="row">
          <select id="journal-type" aria-label="Entry type">${opt(this.TYPES)}</select>
          <select id="journal-cat" aria-label="Category">${opt(this.CATEGORIES)}</select>
        </div>
        <input type="text" id="journal-title" placeholder="Title (optional)">
        <textarea id="journal-text" rows="6" placeholder="Write what's on your mind, or tap 🎤 Speak and just talk..."></textarea>
        <p id="journal-live" class="live" aria-live="polite"></p>
        <input type="text" id="journal-tags" placeholder="Tags, separated by commas (e.g. exams, family)">
        <div class="row">
          <button id="journal-save" class="btn">Save entry</button>
          <button id="journal-voice" class="btn btn-secondary" type="button">🎤 Speak</button>
          <select id="journal-lang" aria-label="Speaking language">
            ${Journal.LANGS.map(([code, name]) => `<option value="${code}">${name}</option>`).join("")}
          </select>
          <button id="journal-cancel" class="btn btn-secondary" type="button" style="display:none">Cancel edit</button>
        </div>
        <p class="note">Voice typing uses your browser's speech service. In Chrome and Edge, audio is sent online to be converted to text. Say "full stop", "comma", "question mark" or "new line" to add punctuation.</p>
        <p id="journal-msg" class="msg"></p>
      </div>
      <div class="card">
        <div class="row">
          <input type="text" id="journal-search" placeholder="Search entries...">
          <select id="journal-filter" aria-label="Filter by type">
            <option value="">All types</option>${opt(this.TYPES)}
          </select>
        </div>
        <div id="entry-list"></div>
      </div>`;
  },

  init() {
    this.selectedMood = null;
    this.editingId = null;
    this.listening = false;

    document.getElementById("mood-picker").addEventListener("click", e => {
      const btn = e.target.closest(".mood-btn");
      if (btn) this.selectMood(btn.dataset.mood);
    });
    document.getElementById("journal-save").addEventListener("click", () => this.save());
    document.getElementById("journal-cancel").addEventListener("click", () => this.resetForm());
    document.getElementById("journal-voice").addEventListener("click", () => this.toggleVoice());
    const lang = document.getElementById("journal-lang");
    const saved = localStorage.getItem("voice_lang");
    lang.value = this.LANGS.some(l => l[0] === saved) ? saved : "en-IN";
    lang.addEventListener("change", () => {
      localStorage.setItem("voice_lang", lang.value);
      if (this.listening) { Voice.stop(); this.message("Language changed. Tap Speak to continue."); }
    });
    document.getElementById("journal-search").addEventListener("input", () => this.renderList());
    document.getElementById("journal-filter").addEventListener("change", () => this.renderList());
    document.getElementById("entry-list").addEventListener("click", e => {
      const btn = e.target.closest("button[data-action]");
      if (!btn) return;
      const id = Number(btn.dataset.id);
      if (btn.dataset.action === "edit") this.edit(id);
      if (btn.dataset.action === "delete") this.remove(id);
      if (btn.dataset.action === "read") {
        const entry = Storage.get("journal").find(x => x.id === id);
        if (!entry) return;
        const text = (entry.title ? entry.title + ". " : "") + entry.text;
        const lang = entry.lang || "en-IN";
        Voice.speak(text, lang, {
          onend: ok => {
            if (ok === false) {
              const name = (this.LANGS.find(l => l[0] === lang) || [, lang])[1];
              this.message(`Couldn't speak this in ${name} on this device. A ${name} voice may need to be installed in your device's speech settings.`, 5000);
            }
          }
        });
      }
    });
    this.renderList();
  },

  leave() { Voice.stop(); Voice.silence(); },

  selectMood(label) {
    this.selectedMood = label;
    document.querySelectorAll("#mood-picker .mood-btn").forEach(b =>
      b.classList.toggle("selected", b.dataset.mood === label));
  },

  message(text, ms = 2500) {
    const el = document.getElementById("journal-msg");
    if (!el) return;
    el.textContent = text;
    clearTimeout(this._msgTimer);
    this._msgTimer = setTimeout(() => { el.textContent = ""; }, ms);
  },

  VOICE_ERRORS: {
    "not-allowed": "Microphone is blocked. Click the lock icon in the address bar, allow the microphone, then try again.",
    "service-not-allowed": "Microphone is blocked. Click the lock icon in the address bar, allow the microphone, then try again.",
    "audio-capture": "No microphone was found. Check that one is connected.",
    "network": "Voice typing needs an internet connection.",
    "language-not-supported": "This language is not supported by your browser's speech service."
  },

  // Turn spoken words into tidy text: punctuation commands and capital letters
  formatSpeech(raw, existing) {
    let t = raw.trim()
      .replace(/\s*\bnew paragraph\b\s*/gi, "\n\n")
      .replace(/\s*\bnew line\b\s*/gi, "\n")
      .replace(/\s*\bfull stop\b\s*/gi, ". ")
      .replace(/\s*\bquestion mark\b\s*/gi, "? ")
      .replace(/\s*\bcomma\b\s*/gi, ", ");
    const atStart = !existing.trim() || /[.?!]\s*$/.test(existing) || /\n\s*$/.test(existing);
    if (atStart) t = t.charAt(0).toUpperCase() + t.slice(1);
    t = t.replace(/([.?!]\s+)([a-z])/g, (m, a, b) => a + b.toUpperCase());
    const sep = existing && !/\s$/.test(existing) && !/^[\s.,?!]/.test(t) ? " " : "";
    return sep + t;
  },

  toggleVoice() {
    const btn = document.getElementById("journal-voice");
    const live = document.getElementById("journal-live");
    const ta = document.getElementById("journal-text");
    if (!Voice.recSupported) {
      this.message("Voice typing is not supported in this browser. Try Chrome or Edge.", 5000);
      return;
    }
    if (this.listening) { Voice.stop(); return; }
    const done = () => {
      this.listening = false;
      const b = document.getElementById("journal-voice");
      if (b) { b.textContent = "🎤 Speak"; b.classList.remove("rec"); }
      const l = document.getElementById("journal-live");
      if (l) l.textContent = "";
    };
    const started = Voice.listen({
      lang: document.getElementById("journal-lang").value,
      onFinal: text => {
        const box = document.getElementById("journal-text");
        if (!box) return;
        box.value += this.formatSpeech(text, box.value);
        box.scrollTop = box.scrollHeight;
      },
      onInterim: text => {
        const l = document.getElementById("journal-live");
        if (l) l.textContent = text ? "🎤 " + text : (Voice.wanted ? "🎤 Listening… just start talking" : "");
      },
      onError: code => this.message(this.VOICE_ERRORS[code] || "Voice typing stopped (" + code + "). Please try again.", 7000),
      onEnd: done
    });
    if (started) {
      this.listening = true;
      btn.textContent = "⏹ Stop";
      btn.classList.add("rec");
      live.textContent = "🎤 Listening… just start talking";
      ta.focus();
    }
  },

  save() {
    const text = document.getElementById("journal-text").value.trim();
    if (!text) { this.message("Please write something first."); return; }
    const entry = {
      type: document.getElementById("journal-type").value,
      category: document.getElementById("journal-cat").value,
      title: document.getElementById("journal-title").value.trim(),
      text,
      mood: this.selectedMood,
      lang: document.getElementById("journal-lang").value, // language to use for Read Aloud
      tags: document.getElementById("journal-tags").value.split(",").map(t => t.trim()).filter(Boolean)
    };
    if (this.editingId) Storage.update("journal", this.editingId, entry);
    else Storage.save("journal", entry);
    this.resetForm();
    this.renderList();
    this.message("Entry saved ✔");
    Companion.react("journal", text, "Respond to what they wrote and its feeling, and gently encourage them to keep writing.");
  },

  edit(id) {
    const entry = Storage.get("journal").find(e => e.id === id);
    if (!entry) return;
    this.editingId = id;
    document.getElementById("journal-type").value = entry.type || "Thought";
    document.getElementById("journal-cat").value = entry.category || "General";
    document.getElementById("journal-title").value = entry.title || "";
    document.getElementById("journal-text").value = entry.text;
    document.getElementById("journal-tags").value = (entry.tags || []).join(", ");
    if (entry.lang) document.getElementById("journal-lang").value = entry.lang;
    if (entry.mood) this.selectMood(entry.mood);
    document.getElementById("journal-save").textContent = "Update entry";
    document.getElementById("journal-cancel").style.display = "inline-block";
    window.scrollTo({ top: 0, behavior: "smooth" });
  },

  remove(id) {
    if (!confirm("Delete this entry?")) return;
    Storage.remove("journal", id);
    this.renderList();
  },

  resetForm() {
    ["journal-title", "journal-text", "journal-tags"].forEach(i => { document.getElementById(i).value = ""; });
    document.getElementById("journal-type").selectedIndex = 0;
    document.getElementById("journal-cat").selectedIndex = 0;
    this.selectedMood = null;
    this.editingId = null;
    document.querySelectorAll("#mood-picker .mood-btn").forEach(b => b.classList.remove("selected"));
    document.getElementById("journal-save").textContent = "Save entry";
    document.getElementById("journal-cancel").style.display = "none";
  },

  renderList() {
    const q = document.getElementById("journal-search").value.toLowerCase();
    const type = document.getElementById("journal-filter").value;
    const entries = Storage.get("journal").slice().reverse().filter(e =>
      (!type || (e.type || "Thought") === type) &&
      (!q || (e.title || "").toLowerCase().includes(q) || (e.text || "").toLowerCase().includes(q) ||
        (e.mood || "").toLowerCase().includes(q) || (e.category || "").toLowerCase().includes(q) ||
        (e.tags || []).some(t => t.toLowerCase().includes(q))));

    const list = document.getElementById("entry-list");
    if (!entries.length) { list.innerHTML = `<p class="empty">No entries found. Write your first one above.</p>`; return; }

    list.innerHTML = entries.map(e => {
      const m = Utils.moodObj(e.mood);
      return `
        <div class="entry">
          <div class="entry-head">
            <strong>${m ? m.emoji : "📝"} ${Utils.escape(e.title) || "Untitled"}</strong>
            <small>${new Date(e.date).toLocaleString()}</small>
          </div>
          <div class="tags">
            <span class="tag type">${Utils.escape(e.type || "Thought")}</span>
            <span class="tag">${Utils.escape(e.category || "General")}</span>
            ${(e.tags || []).map(t => `<span class="tag">#${Utils.escape(t)}</span>`).join("")}
          </div>
          <p>${Utils.escape(e.text).replace(/\n/g, "<br>")}</p>
          <div class="entry-actions">
            <button class="btn-small" data-action="edit" data-id="${e.id}">Edit</button>
            ${Voice.ttsSupported ? `<button class="btn-small" data-action="read" data-id="${e.id}">🔊 Read</button>` : ""}
            <button class="btn-small danger" data-action="delete" data-id="${e.id}">Delete</button>
          </div>
        </div>`;
    }).join("");
  }
};
