const Charts = {
  // data: [{label, value}]
  line(data, { min = 1, max = 5, w = 640, h = 240 } = {}) {
    if (!data.length) return `<p class="empty">Log a few moods to see your trend.</p>`;
    const pad = 34, iw = w - pad * 2, ih = h - pad * 2;
    const x = i => pad + (data.length === 1 ? iw / 2 : i * iw / (data.length - 1));
    const y = v => pad + ih - ((v - min) / (max - min)) * ih;
    let grid = "";
    for (let v = min; v <= max; v++) {
      grid += `<line x1="${pad}" x2="${w - pad}" y1="${y(v)}" y2="${y(v)}" stroke="#e6eaee"/>` +
              `<text x="8" y="${y(v) + 4}" font-size="11" fill="#7a8591">${v}</text>`;
    }
    const pts = data.map((d, i) => `${x(i)},${y(d.value)}`).join(" ");
    const dots = data.map((d, i) =>
      `<circle cx="${x(i)}" cy="${y(d.value)}" r="4.5" fill="#5b8def"><title>${Utils.escape(d.label)}: ${d.value.toFixed(1)}</title></circle>`).join("");
    const step = Math.ceil(data.length / 8);
    const labels = data.map((d, i) => i % step === 0
      ? `<text x="${x(i)}" y="${h - 10}" font-size="10" text-anchor="middle" fill="#7a8591">${Utils.escape(d.label)}</text>` : "").join("");
    return `<svg viewBox="0 0 ${w} ${h}" class="chart" role="img" aria-label="Mood trend">${grid}<polyline points="${pts}" fill="none" stroke="#5b8def" stroke-width="2.5"/>${dots}${labels}</svg>`;
  },

  // items: [{label, value, text?}] value is 0..max
  bars(items, max = 100) {
    return items.map(it => `
      <div class="bar-row">
        <span class="bar-label">${Utils.escape(it.label)}</span>
        <div class="bar"><div class="bar-fill" style="width:${Math.max(0, Math.min(100, (it.value / max) * 100))}%"></div></div>
        <b class="bar-val">${Utils.escape(it.text ?? it.value)}</b>
      </div>`).join("");
  },

  // series: [{values:[], color, dashed?}]
  radar(labels, series, max = 10, size = 380) {
    const c = size / 2, r = size / 2 - 62, n = labels.length;
    const pt = (i, v) => {
      const a = -Math.PI / 2 + i * 2 * Math.PI / n;
      const d = r * v / max;
      return [c + d * Math.cos(a), c + d * Math.sin(a)];
    };
    const rings = [2, 4, 6, 8, 10].map(v =>
      `<polygon points="${labels.map((_, i) => pt(i, v * max / 10).join(",")).join(" ")}" fill="none" stroke="#e6eaee"/>`).join("");
    const axes = labels.map((_, i) => { const [px, py] = pt(i, max); return `<line x1="${c}" y1="${c}" x2="${px}" y2="${py}" stroke="#e6eaee"/>`; }).join("");
    const texts = labels.map((l, i) => {
      const [px, py] = pt(i, max * 1.2);
      const anchor = Math.abs(px - c) < 8 ? "middle" : px > c ? "start" : "end";
      return `<text x="${px}" y="${py + 4}" font-size="12" text-anchor="${anchor}" fill="#2b2f36">${Utils.escape(l)}</text>`;
    }).join("");
    const polys = series.map(s => {
      const pts = s.values.map((v, i) => pt(i, v).join(",")).join(" ");
      return `<polygon points="${pts}" fill="${s.dashed ? "none" : s.color}" fill-opacity="${s.dashed ? 0 : 0.25}" stroke="${s.color}" stroke-width="2" ${s.dashed ? 'stroke-dasharray="6 4"' : ""}/>`;
    }).join("");
    return `<svg viewBox="0 0 ${size} ${size}" class="chart radar" role="img" aria-label="Life balance wheel">${rings}${axes}${polys}${texts}</svg>`;
  }
};
