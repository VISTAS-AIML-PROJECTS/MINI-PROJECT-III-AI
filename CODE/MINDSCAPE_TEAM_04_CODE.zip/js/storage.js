const Storage = {
  _write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      alert("Browser storage is full. Delete some items or export a backup first.");
      return false;
    }
  },

  get(key) {
    try {
      return JSON.parse(localStorage.getItem(key)) || [];
    } catch {
      return [];
    }
  },

  save(key, item) {
    const items = this.get(key);
    item.id = Date.now() + Math.floor(Math.random() * 1000);
    item.date = item.date || new Date().toISOString();
    items.push(item);
    this._write(key, items);
    return item;
  },

  update(key, id, changes) {
    const items = this.get(key).map(i => i.id === id ? { ...i, ...changes } : i);
    this._write(key, items);
  },

  remove(key, id) {
    this._write(key, this.get(key).filter(i => i.id !== id));
  },

  getObject(key, fallback = {}) {
    try {
      const value = JSON.parse(localStorage.getItem(key));
      return value ?? fallback;
    } catch {
      return fallback;
    }
  },

  setObject(key, value) {
    return this._write(key, value);
  },

  // Backup everything except the AI key
  exportAll() {
    const data = {};
    Object.keys(localStorage).forEach(k => {
      if (k !== "ai_settings") data[k] = localStorage.getItem(k);
    });
    return JSON.stringify({ app: "MindScape", version: 1, exported: new Date().toISOString(), data }, null, 2);
  },

  importAll(text) {
    const obj = JSON.parse(text);
    if (!obj || obj.app !== "MindScape" || typeof obj.data !== "object") {
      throw new Error("This is not a MindScape backup file.");
    }
    const keepAI = localStorage.getItem("ai_settings");
    localStorage.clear();
    Object.entries(obj.data).forEach(([k, v]) => localStorage.setItem(k, v));
    if (keepAI) localStorage.setItem("ai_settings", keepAI);
  },

  clearAll() {
    localStorage.clear();
  }
};
