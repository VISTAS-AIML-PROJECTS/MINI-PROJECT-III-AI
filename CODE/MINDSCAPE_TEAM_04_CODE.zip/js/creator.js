// Library -> Create tab: turn an upload (photo, PDF, Word, text, audio, video) or a YouTube link
// into a brand-new original story, song or poem written by the companion.
const Creator = {
  RECENT_KEY: "creations_recent",
  MAX_MEDIA_MB: 12,        // audio / video sent inside the request (Gemini limit is ~20 MB for the whole request)
  MAX_TEXT_CHARS: 24000,
  file: null,
  last: null,              // { title, body, kind }

  recent() { return Storage.getObject(this.RECENT_KEY, []); },
  remember(title) { const r = this.recent().filter(t => t !== title); r.unshift(title); Storage.setObject(this.RECENT_KEY, r.slice(0, 10)); },

  html() {
    return `
      <div class="card">
        <h3>✨ Create from your upload</h3>
        <p class="note">Add a photo, PDF, Word file, text, audio or video, or paste a YouTube link. Your companion reads, looks at or listens to it and writes a brand-new original story, song or poem inspired by it, and never repeats an earlier one. Audio, video and YouTube links need a free Gemini key (starts with AIza). Photos, PDFs and Word files work with either key.</p>
        <div class="row" style="gap:8px;align-items:center">
          <label class="btn btn-secondary" style="cursor:pointer">📎 Choose a file<input type="file" id="cr-file" accept="image/*,audio/*,video/*,.pdf,.docx,.txt,.md,.srt,.vtt" hidden></label>
          <span class="note" id="cr-file-name">No file chosen</span>
        </div>
        <input type="text" id="cr-yt" placeholder="Or paste a YouTube link (public video)" style="width:100%;margin-top:8px">
        <input type="text" id="cr-note" placeholder="Anything you want in it? (optional, for example: about courage, in Tamil)" style="width:100%;margin-top:8px">
        <div class="row" style="gap:8px;align-items:center;margin-top:8px">
          <select id="cr-kind"><option value="story">📖 Story</option><option value="song">🎵 Song</option><option value="poem">🪶 Poem</option></select>
          <button type="button" class="btn" id="cr-go">✨ Create</button>
        </div>
        <p class="note" id="cr-status" aria-live="polite"></p>
      </div>
      <div id="cr-out"></div>`;
  },

  init(root) {
    this.file = null;
    const $ = id => root.querySelector("#" + id);
    $("cr-file").addEventListener("change", e => {
      this.file = e.target.files[0] || null;
      $("cr-file-name").textContent = this.file ? `${this.file.name} (${(this.file.size / 1048576).toFixed(1)} MB)` : "No file chosen";
    });
    $("cr-go").addEventListener("click", () => this.create(root, false));
    this.drawResult(root);
  },

  say(root, msg, isErr) { const el = root.querySelector("#cr-status"); if (el) { el.textContent = msg || ""; el.className = "note" + (isErr ? " error" : ""); } },

  // ----- reading the upload -----
  b64(blob) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(",")[1]); r.onerror = () => rej(new Error("Could not read that file.")); r.readAsDataURL(blob); }); },

  async photo(file) {
    let bmp;
    try { bmp = await createImageBitmap(file); }
    catch (e) { throw new Error("Could not open that photo. Try a JPG or PNG (iPhone HEIC photos may need to be saved as JPG first)."); }
    const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height)), cv = document.createElement("canvas");
    cv.width = Math.max(1, Math.round(bmp.width * scale)); cv.height = Math.max(1, Math.round(bmp.height * scale));
    cv.getContext("2d").drawImage(bmp, 0, 0, cv.width, cv.height);
    const blob = await new Promise(res => cv.toBlob(res, "image/jpeg", 0.85));
    return { kind: "inline", mime: "image/jpeg", data: await this.b64(blob) };
  },

  async prepare(root, key) {
    const gemini = AIClient.provider(key) === "gemini", out = { media: [], text: "", what: "" };
    const link = (root.querySelector("#cr-yt").value || "").trim();
    if (link) {
      const full = /^https?:\/\//i.test(link) ? link : "https://" + link, vid = SourceImport.parseYouTube(full);
      if (!vid) throw new Error("That does not look like a YouTube link.");
      if (!gemini) throw new Error("YouTube links need a free Google Gemini key (starts with AIza). With a Claude key, paste the video's transcript in Settings → Companion → My sources instead.");
      out.media.push({ kind: "youtube", url: "https://www.youtube.com/watch?v=" + vid }); out.what = "a YouTube video"; out.youtube = true;
    }
    const f = this.file;
    if (f) {
      const n = f.name.toLowerCase(), t = f.type || "";
      if (t.startsWith("image/")) { this.say(root, "Looking at your photo…"); out.media.push(await this.photo(f)); out.what = out.what || "a photo"; }
      else if (t.startsWith("audio/") || t.startsWith("video/")) {
        if (!gemini) throw new Error("Audio and video need a free Google Gemini key (starts with AIza). Claude keys cannot listen to recordings or watch videos.");
        if (f.size > this.MAX_MEDIA_MB * 1048576) throw new Error(`That file is ${(f.size / 1048576).toFixed(1)} MB. Files over ${this.MAX_MEDIA_MB} MB do not fit. Trim it shorter, or upload the video to YouTube and paste the link above.`);
        this.say(root, "Sending your recording…"); out.media.push({ kind: "inline", mime: t || (n.endsWith(".mp3") ? "audio/mpeg" : "video/mp4"), data: await this.b64(f) }); out.what = t.startsWith("audio/") ? "a recording" : "a video";
      } else {
        this.say(root, "Reading your document…");
        const text = String(await SourceImport.read(f, m => this.say(root, m)) || "").trim();
        if (text.length < 20) throw new Error("I could not find readable text in that file. If it is a scanned PDF, try a photo of the page instead.");
        out.text = text.length > this.MAX_TEXT_CHARS ? text.slice(0, this.MAX_TEXT_CHARS) + "\n[...the rest was left out because it is long]" : text; out.what = out.what || "a document";
      }
    }
    if (!out.media.length && !out.text) throw new Error("Choose a file or paste a YouTube link first.");
    return out;
  },

  // ----- creating -----
  async create(root, again) {
    const btn = root.querySelector("#cr-go"), c = Companion.get() || {};
    const settings = Storage.getObject("ai_settings", {}), key = AIClient.clean(settings.apiKey);
    if (!key) return this.say(root, "Add your AI key first (Settings → Companion). A free Gemini key works.", true);
    const kind = root.querySelector("#cr-kind").value, note = (root.querySelector("#cr-note").value || "").trim().slice(0, 300);
    const label = btn.textContent; btn.disabled = true; btn.classList.add("is-busy"); btn.textContent = "Creating…";
    let usedYouTube = false;
    try {
      const up = await this.prepare(root, key); usedYouTube = !!up.youtube;
      this.say(root, "Writing something new for you…");
      let prompt = `Create a ${kind} inspired by ${up.what}.` + (note ? ` The user's note: "${note}".` : "") + (again ? " This is a request for a DIFFERENT version, so choose a different angle, characters and ending than before." : "");
      if (up.text) prompt += `\n--- UPLOADED TEXT (inspiration only, do not copy) ---\n${up.text}\n--- END ---`;
      const raw = await Companion.callAI("create", { prompt, media: up.media, kind, lang: c.lang, recent: this.recent(), maxTokens: 1600 });
      if (/^\s*CANNOT_READ/i.test(raw)) { this.last = null; this.drawResult(root); return this.say(root, raw.replace(/^\s*CANNOT_READ:?\s*/i, "I could not use that upload: "), true); }
      const tm = /^\s*TITLE:\s*(.+)$/im.exec(raw), title = (tm ? tm[1] : "A new " + kind).replace(/[*_#]/g, "").trim();
      let body = raw.replace(/^\s*TITLE:.*$/im, "").trim();
      this.last = { title, body, kind }; this.remember(title);
      this.drawResult(root); this.say(root, "");
    } catch (err) {
      this.say(root, "✘ " + err.message + (usedYouTube && err.code !== "bad-key" ? " (YouTube links only work for public videos.)" : ""), true);
    } finally { btn.disabled = false; btn.classList.remove("is-busy"); btn.textContent = label; }
  },

  drawResult(root) {
    const out = root.querySelector("#cr-out"); if (!out) return;
    if (!this.last) { out.innerHTML = ""; return; }
    const { title, body } = this.last;
    out.innerHTML = `
      <div class="card">
        <h3>${Utils.escape(title)}</h3>
        <p style="white-space:pre-wrap">${Utils.escape(body)}</p>
        <div class="row" style="gap:8px;flex-wrap:wrap">
          ${Voice.ttsSupported ? `<button type="button" class="btn-small" id="cr-read">🔊 Read aloud</button>` : ""}
          <button type="button" class="btn-small" id="cr-again">🔁 Make a different one</button>
          <button type="button" class="btn-small" id="cr-save">💾 Save to Journal</button>
          <button type="button" class="btn-small" id="cr-copy">📋 Copy</button>
        </div>
        <p class="note" id="cr-msg"></p>
      </div>`;
    const msg = t => { const m = out.querySelector("#cr-msg"); if (m) m.textContent = t; };
    const r = out.querySelector("#cr-read");
    if (r) r.addEventListener("click", () => { Voice.stop(); Voice.speak(title + ". " + body, (Companion.get() || {}).lang || "en-IN", { gender: Companion.voiceGender(), onend: () => {} }); });
    out.querySelector("#cr-again").addEventListener("click", () => this.create(root, true));
    out.querySelector("#cr-save").addEventListener("click", () => { Storage.save("journal", { type: "Thought", category: "General", title, text: body, mood: null, lang: (Companion.get() || {}).lang || "en-IN", tags: ["created"] }); msg("Saved to your Journal ✔"); });
    out.querySelector("#cr-copy").addEventListener("click", async () => { try { await navigator.clipboard.writeText(title + "\n\n" + body); msg("Copied ✔"); } catch (e) { msg("Could not copy. Select the text and copy it."); } });
  }
};
