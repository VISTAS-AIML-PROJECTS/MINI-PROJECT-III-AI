const Vision = {
  COLORS: ["#ffe9a8", "#cfe8ff", "#d9f2d0", "#ffd6d6", "#e5d9ff", "#ffe0f0"],
  color: "#ffe9a8",

  render() {
    return `
      <h1>🖼️ Vision Board</h1>
      <div class="card">
        <h3>Add to your board</h3>
        <input type="text" id="v-text" placeholder="A goal, dream, or affirmation" maxlength="120">
        <div class="row">
          <div class="swatches" id="v-swatches">
            ${this.COLORS.map(c => `<button type="button" class="swatch ${c === this.color ? "selected" : ""}" data-c="${c}" style="background:${c}" aria-label="Card color"></button>`).join("")}
          </div>
          <button class="btn" id="v-add-text">Add text card</button>
        </div>
        <hr>
        <div class="row">
          <input type="file" id="v-file" accept="image/*">
          <button class="btn" id="v-add-img">Add image</button>
        </div>
        <p class="note">Images are shrunk and stored in your browser only.</p>
      </div>
      <div id="v-board" class="board"></div>`;
  },

  init() {
    document.getElementById("v-swatches").addEventListener("click", e => {
      const b = e.target.closest(".swatch");
      if (!b) return;
      this.color = b.dataset.c;
      document.querySelectorAll(".swatch").forEach(s => s.classList.toggle("selected", s === b));
    });
    document.getElementById("v-add-text").addEventListener("click", () => {
      const input = document.getElementById("v-text");
      const text = input.value.trim();
      if (!text) return Utils.toast("Type something first.");
      Storage.save("vision", { kind: "text", text, color: this.color });
      Companion.react("vision-board", `I added to my vision board: ${text}`, "Respond to this specific goal or dream with excitement and suggest one small step toward it.");
      input.value = "";
      this.draw();
      Companion.react("vision-board", text, "They just added this goal or affirmation to their vision board. Encourage them warmly about this specific dream.");
    });
    document.getElementById("v-add-img").addEventListener("click", async () => {
      const file = document.getElementById("v-file").files[0];
      if (!file) return Utils.toast("Choose an image first.");
      try {
        const src = await this.readImage(file);
        Storage.save("vision", { kind: "image", src });
        document.getElementById("v-file").value = "";
        this.draw();
      } catch {
        Utils.toast("That image could not be read.");
      }
    });
    document.getElementById("v-board").addEventListener("click", e => {
      const b = e.target.closest("button[data-id]");
      if (b && confirm("Remove this item?")) {
        Storage.remove("vision", Number(b.dataset.id));
        this.draw();
      }
    });
    this.draw();
  },

  readImage(file) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onerror = reject;
      fr.onload = () => {
        const img = new Image();
        img.onerror = reject;
        img.onload = () => {
          const max = 480;
          const s = Math.min(1, max / Math.max(img.width, img.height));
          const c = document.createElement("canvas");
          c.width = Math.round(img.width * s);
          c.height = Math.round(img.height * s);
          c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
          resolve(c.toDataURL("image/jpeg", 0.7));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  },

  draw() {
    const items = Storage.get("vision");
    const board = document.getElementById("v-board");
    if (!items.length) { board.innerHTML = `<div class="card"><p class="empty">Your board is empty. Add a goal or an image above.</p></div>`; return; }
    board.innerHTML = items.map(it => it.kind === "image"
      ? `<div class="vcard img"><img src="${it.src}" alt="Vision board image"><button class="x" data-id="${it.id}" aria-label="Remove">✕</button></div>`
      : `<div class="vcard" style="background:${Utils.escape(it.color)}"><p>${Utils.escape(it.text)}</p><button class="x" data-id="${it.id}" aria-label="Remove">✕</button></div>`
    ).join("");
  }
};
