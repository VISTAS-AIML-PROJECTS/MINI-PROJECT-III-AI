const Grounding = {
  PATTERNS: {
    box: { name: "Box breathing (4-4-4-4)", steps: [["Breathe in", 4, 1], ["Hold", 4, 1], ["Breathe out", 4, 0.6], ["Hold", 4, 0.6]] },
    calm: { name: "Calming breath (4-7-8)", steps: [["Breathe in", 4, 1], ["Hold", 7, 1], ["Breathe out", 8, 0.6]] }
  },
  SENSES: [
    ["5", "things you can see", "Look around slowly. Name five things you can see."],
    ["4", "things you can feel", "Notice four things you can touch or feel: your feet on the floor, the chair, your clothes."],
    ["3", "things you can hear", "Listen closely. Name three sounds, near or far."],
    ["2", "things you can smell", "Notice two scents, or recall two smells you like."],
    ["1", "thing you can taste", "Notice one taste in your mouth, or take a sip of water."]
  ],
  bt: null, breathing: false, cycles: 0, patternKey: "box", senseStep: 0,

  render() {
    return `
      <h1>🌿 Grounding</h1>
      <div class="card support">
        <h3>If you feel overwhelmed right now</h3>
        <p>Pause. Put both feet on the floor and take a slow breath. The exercises below can help you settle.
        If you feel unsafe, please contact someone right away.</p>
        ${HELP.lines.map(l => `<p><b>${Utils.escape(l.name)}:</b> <a class="link" href="tel:${l.number}">${l.number}</a></p>`).join("")}
      </div>

      <div class="card center">
        <h3>Guided breathing</h3>
        <select id="g-pattern">${Object.entries(this.PATTERNS).map(([k, p]) => `<option value="${k}">${p.name}</option>`).join("")}</select>
        <div class="breath-wrap"><div class="breath" id="breath"></div><div class="breath-text" id="breath-text">Ready</div></div>
        <p class="sub" id="breath-cycles">Cycles: 0</p>
        <label class="inline"><input type="checkbox" id="g-voice"> Read prompts aloud</label>
        <div class="row center"><button class="btn" id="breath-btn">Start</button></div>
        ${Companion.enabled() ? '<div class="row center"><button class="btn btn-secondary" id="breath-ai">🧘 Guide me aloud · 3 rounds</button></div>' : ""}
      </div>

      <div class="card">
        <h3>5-4-3-2-1 senses exercise</h3>
        <div id="sense-box"></div>
      </div>`;
  },

  init() {
    this.breathing = false; this.cycles = 0; this.senseStep = 0; this.patternKey = "box";
    document.getElementById("g-pattern").addEventListener("change", e => { this.patternKey = e.target.value; if (this.breathing) this.stopBreath(false); });
    document.getElementById("breath-btn").addEventListener("click", () => this.breathing ? this.stopBreath(true) : this.startBreath());
    const ai = document.getElementById("breath-ai");
    if (ai) ai.addEventListener("click", () => { if (this.breathing) this.stopBreath(false); Companion.breathe(3); });
    document.getElementById("sense-box").addEventListener("click", e => {
      if (!e.target.closest("#sense-next")) return;
      if (this.senseStep >= this.SENSES.length) { this.senseStep = 0; }
      else {
        this.senseStep++;
        if (this.senseStep >= this.SENSES.length) { Storage.save("grounding_log", { type: "senses" }); Companion.react("grounding", "I just finished the 5-4-3-2-1 senses grounding exercise.", "Warmly acknowledge they took the time to ground themselves, briefly."); }
      }
      this.drawSense();
    });
    this.drawSense();
  },

  leave() {
    clearTimeout(this.bt);
    this.breathing = false;
    Voice.silence();
  },

  drawSense() {
    const box = document.getElementById("sense-box");
    if (this.senseStep >= this.SENSES.length) {
      box.innerHTML = `<p class="quote">Well done. Take one more slow breath. Notice how your body feels now.</p>
        <button class="btn" id="sense-next">Start again</button>`;
      return;
    }
    const [n, what, hint] = this.SENSES[this.senseStep];
    box.innerHTML = `
      <p class="sense-n">${n}</p>
      <p class="quote">${what}</p>
      <p class="sub">${hint}</p>
      <button class="btn" id="sense-next">${this.senseStep === this.SENSES.length - 1 ? "Finish" : "Next"}</button>`;
    if (document.getElementById("g-voice") && document.getElementById("g-voice").checked) Voice.speak(`${n} ${what}. ${hint}`);
  },

  startBreath() {
    this.breathing = true; this.cycles = 0;
    document.getElementById("breath-btn").textContent = "Stop";
    document.getElementById("breath-cycles").textContent = "Cycles: 0";
    const steps = this.PATTERNS[this.patternKey].steps;
    const circle = document.getElementById("breath");
    const text = document.getElementById("breath-text");
    let i = 0;
    const run = () => {
      if (!this.breathing) return;
      const [label, secs, scale] = steps[i % steps.length];
      circle.style.transition = `transform ${secs}s ease-in-out`;
      circle.style.transform = `scale(${scale})`;
      text.textContent = `${label} · ${secs}`;
      if (document.getElementById("g-voice").checked) Voice.speak(Companion.cue(label), Companion.langCode());
      this.bt = setTimeout(() => {
        i++;
        if (i % steps.length === 0) {
          this.cycles++;
          const c = document.getElementById("breath-cycles");
          if (c) c.textContent = `Cycles: ${this.cycles}`;
        }
        run();
      }, secs * 1000);
    };
    run();
  },

  stopBreath(log) {
    clearTimeout(this.bt);
    this.breathing = false;
    Voice.silence();
    const btn = document.getElementById("breath-btn");
    if (btn) btn.textContent = "Start";
    const circle = document.getElementById("breath");
    if (circle) { circle.style.transition = "transform 1s"; circle.style.transform = "scale(0.6)"; }
    const text = document.getElementById("breath-text");
    if (text) text.textContent = "Ready";
    if (log && this.cycles >= 1) {
      Storage.save("grounding_log", { type: "breathing", cycles: this.cycles });
      Utils.toast("Nice work. Breathing session saved ✔");
    }
  }
};
