const Habits = {
  tid: null, running: false, remaining: 1500, endAt: 0, minutes: 25,

  render() {
    return `
      <h1>✅ Habits & Tasks</h1>
      <div class="two-col">
        <div class="card">
          <h3>Habits</h3>
          <div class="row">
            <input type="text" id="h-name" placeholder="New habit (e.g. Drink water)" maxlength="40">
            <button class="btn" id="h-add">Add</button>
          </div>
          <div id="h-list"></div>
        </div>
        <div>
          <div class="card center">
            <h3>⏱️ Focus timer</h3>
            <div class="timer" id="f-time">25:00</div>
            <label class="inline">Minutes <input type="number" id="f-min" min="1" max="120" value="25" class="num"></label>
            <div class="row center">
              <button class="btn" id="f-start">Start</button>
              <button class="btn btn-secondary" id="f-reset">Reset</button>
            </div>
            <p class="sub" id="f-stats"></p>
          </div>
          <div class="card">
            <h3>Tasks</h3>
            <div class="row">
              <input type="text" id="t-text" placeholder="New task" maxlength="100">
              <input type="date" id="t-due" aria-label="Due date">
              <button class="btn" id="t-add">Add</button>
            </div>
            <div id="t-list"></div>
          </div>
        </div>
      </div>`;
  },

  init() {
    this.running = false;
    this.minutes = 25;
    this.remaining = 1500;

    document.getElementById("h-add").addEventListener("click", () => this.addHabit());
    document.getElementById("h-name").addEventListener("keydown", e => { if (e.key === "Enter") this.addHabit(); });
    document.getElementById("h-list").addEventListener("click", e => this.habitClick(e));

    document.getElementById("t-add").addEventListener("click", () => this.addTask());
    document.getElementById("t-text").addEventListener("keydown", e => { if (e.key === "Enter") this.addTask(); });
    document.getElementById("t-list").addEventListener("click", e => this.taskClick(e));

    document.getElementById("f-start").addEventListener("click", () => this.toggleTimer());
    document.getElementById("f-reset").addEventListener("click", () => this.reset());
    document.getElementById("f-min").addEventListener("change", () => { if (!this.running) this.reset(); });

    this.renderHabits();
    this.renderTasks();
    this.showStats();
  },

  leave() {
    clearInterval(this.tid);
    this.tid = null;
    this.running = false;
  },

  // ---------- Habits ----------
  addHabit() {
    const input = document.getElementById("h-name");
    const name = input.value.trim();
    if (!name) return;
    Storage.save("habits", { name, log: [] });
    Companion.react("habits", `I added a new habit: ${name}`, "Encourage this specific habit and suggest one tiny way to start it today.");
    input.value = "";
    this.renderHabits();
  },

  toggleDay(id, day) {
    const h = Storage.get("habits").find(x => x.id === id);
    if (!h) return;
    const log = new Set(h.log || []);
    const wasOff = !log.has(day);
    if (log.has(day)) log.delete(day); else log.add(day);
    Storage.update("habits", id, { log: [...log].sort() });
    this.renderHabits();
    if (wasOff && day === Utils.dateKey()) {
      const streak = Data.streakOf(log);
      Companion.react("habits", `I just marked the habit "${h.name}" as done today. My current streak is ${streak} day(s).`, "Celebrate this specific habit and streak by name, briefly.");
    }
  },

  habitClick(e) {
    const btn = e.target.closest("button");
    if (!btn) return;
    const id = Number(btn.dataset.id);
    if (btn.dataset.day) this.toggleDay(id, btn.dataset.day);
    else if (btn.dataset.act === "del" && confirm("Delete this habit and its history?")) {
      Storage.remove("habits", id);
      this.renderHabits();
    }
  },

  renderHabits() {
    const habits = Storage.get("habits");
    const today = Utils.dateKey();
    const days = Utils.lastDays(7);
    const list = document.getElementById("h-list");
    if (!habits.length) { list.innerHTML = `<p class="empty">No habits yet. Add one above to start a streak.</p>`; return; }

    list.innerHTML = habits.map(h => {
      const log = h.log || [];
      const streak = Data.streakOf(new Set(log));
      const doneToday = log.includes(today);
      return `
        <div class="habit">
          <div class="entry-head"><strong>${Utils.escape(h.name)}</strong><span class="streak">🔥 ${streak}</span></div>
          <div class="dots">
            ${days.map(d => {
              const [y, m, dd] = d.split("-").map(Number);
              const wd = new Date(y, m - 1, dd).toLocaleDateString(undefined, { weekday: "narrow" });
              return `<button class="dot ${log.includes(d) ? "on" : ""} ${d === today ? "today" : ""}" data-id="${h.id}" data-day="${d}" title="${d}">${wd}</button>`;
            }).join("")}
          </div>
          <div class="entry-actions">
            <button class="btn-small" data-id="${h.id}" data-day="${today}">${doneToday ? "✓ Done today" : "Mark done today"}</button>
            <button class="btn-small danger" data-id="${h.id}" data-act="del">Delete</button>
          </div>
        </div>`;
    }).join("");
  },

  // ---------- Tasks ----------
  addTask() {
    const text = document.getElementById("t-text").value.trim();
    if (!text) return;
    Storage.save("tasks", { text, due: document.getElementById("t-due").value || "", done: false });
    Companion.react("habits", `I added a task: ${text}`, "Respond to this specific task, encourage them, and offer to help break it into a small first step.");
    document.getElementById("t-text").value = "";
    document.getElementById("t-due").value = "";
    this.renderTasks();
  },

  taskClick(e) {
    const clear = e.target.closest("#t-clear");
    if (clear) {
      Storage.get("tasks").filter(t => t.done).forEach(t => Storage.remove("tasks", t.id));
      return this.renderTasks();
    }
    const id = Number(e.target.dataset.id || (e.target.closest("[data-id]") || {}).dataset?.id);
    if (e.target.matches("input[type=checkbox]")) {
      Storage.update("tasks", id, { done: e.target.checked });
      this.renderTasks();
      if (e.target.checked) {
        const t = Storage.get("tasks").find(x => x.id === id);
        if (t) Companion.react("habits", `I just completed this task: "${t.text}".`, "Congratulate them for finishing this specific task, briefly, and ask if they want to tackle another one.");
      }
    } else if (e.target.closest("button[data-act=del]")) {
      Storage.remove("tasks", id);
      this.renderTasks();
    }
  },

  renderTasks() {
    const today = Utils.dateKey();
    const tasks = Storage.get("tasks").slice().sort((a, b) =>
      (a.done - b.done) || ((a.due || "9999") > (b.due || "9999") ? 1 : -1));
    const list = document.getElementById("t-list");
    if (!tasks.length) { list.innerHTML = `<p class="empty">No tasks yet. Add your first one above.</p>`; return; }
    const anyDone = tasks.some(t => t.done);
    list.innerHTML = tasks.map(t => `
      <div class="task">
        <label><input type="checkbox" data-id="${t.id}" ${t.done ? "checked" : ""}>
          <span class="${t.done ? "done" : ""}">${Utils.escape(t.text)}</span></label>
        ${t.due ? `<small class="${!t.done && t.due < today ? "overdue" : ""}">${Utils.shortDate(t.due)}</small>` : ""}
        <button class="btn-small danger" data-id="${t.id}" data-act="del">✕</button>
      </div>`).join("") +
      (anyDone ? `<button class="link-btn" id="t-clear">Clear completed</button>` : "");
  },

  // ---------- Focus timer ----------
  fmt(sec) { return String(Math.floor(sec / 60)).padStart(2, "0") + ":" + String(sec % 60).padStart(2, "0"); },

  showTime() { const el = document.getElementById("f-time"); if (el) el.textContent = this.fmt(this.remaining); },

  showStats() {
    const today = Utils.dateKey();
    const sessions = Storage.get("focus").filter(f => f.dateKey === today);
    const mins = sessions.reduce((s, f) => s + f.minutes, 0);
    const el = document.getElementById("f-stats");
    if (el) el.textContent = `Today: ${sessions.length} session${sessions.length === 1 ? "" : "s"}, ${mins} min`;
  },

  toggleTimer() {
    const btn = document.getElementById("f-start");
    if (this.running) {
      clearInterval(this.tid);
      this.running = false;
      btn.textContent = "Resume";
      return;
    }
    if (this.remaining <= 0) this.reset();
    this.running = true;
    this.endAt = Date.now() + this.remaining * 1000;
    btn.textContent = "Pause";
    this.tid = setInterval(() => this.tick(), 250);
  },

  tick() {
    this.remaining = Math.max(0, Math.round((this.endAt - Date.now()) / 1000));
    this.showTime();
    if (this.remaining <= 0) this.finish();
  },

  finish() {
    clearInterval(this.tid);
    this.running = false;
    Storage.save("focus", { minutes: this.minutes, dateKey: Utils.dateKey() });
    Companion.react("habits", `I just finished a ${this.minutes} minute focus session.`, "Celebrate the focus session and suggest a short rest.");
    Utils.toast("Focus session complete 🎉");
    this.reset();
    this.showStats();
  },

  reset() {
    clearInterval(this.tid);
    this.running = false;
    const v = Math.min(120, Math.max(1, parseInt(document.getElementById("f-min").value, 10) || 25));
    this.minutes = v;
    this.remaining = v * 60;
    document.getElementById("f-start").textContent = "Start";
    this.showTime();
  }
};
