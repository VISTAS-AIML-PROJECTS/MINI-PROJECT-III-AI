const Calendar = {
  y: null, m: null, sel: null,

  render() {
    if (this.y === null) {
      const n = new Date();
      this.y = n.getFullYear(); this.m = n.getMonth(); this.sel = Utils.dateKey();
    }
    return `
      <h1>🗓️ Calendar</h1>
      <div class="card">
        <div class="cal-head">
          <button class="btn-small" id="cal-prev" aria-label="Previous month">‹</button>
          <h3 id="cal-title"></h3>
          <button class="btn-small" id="cal-next" aria-label="Next month">›</button>
          <button class="btn-small" id="cal-today">Today</button>
        </div>
        <div id="cal-grid" class="cal-grid"></div>
        <div class="legend">
          ${[5, 4, 3, 2, 1].map(s => `<span><i style="background:${MOOD_COLORS[s]}"></i>${["", "Low", "Uneasy", "Okay", "Good", "Great"][s]}</span>`).join("")}
          <span>📓 journal</span><span>🙏 gratitude</span><span>✅ habit</span>
        </div>
      </div>
      <div class="card" id="cal-detail"></div>`;
  },

  init() {
    document.getElementById("cal-prev").addEventListener("click", () => { this.shift(-1); });
    document.getElementById("cal-next").addEventListener("click", () => { this.shift(1); });
    document.getElementById("cal-today").addEventListener("click", () => {
      const n = new Date(); this.y = n.getFullYear(); this.m = n.getMonth(); this.sel = Utils.dateKey(); this.draw();
    });
    document.getElementById("cal-grid").addEventListener("click", e => {
      const cell = e.target.closest("button[data-key]");
      if (cell) { this.sel = cell.dataset.key; this.draw(); }
    });
    this.draw();
  },

  shift(n) {
    this.m += n;
    if (this.m < 0) { this.m = 11; this.y--; }
    if (this.m > 11) { this.m = 0; this.y++; }
    this.draw();
  },

  draw() {
    const title = new Date(this.y, this.m, 1).toLocaleDateString(undefined, { month: "long", year: "numeric" });
    document.getElementById("cal-title").textContent = title;

    const journal = Storage.get("journal"), gratitude = Storage.get("gratitude"), habits = Storage.get("habits");
    const jDays = new Set(journal.map(e => Utils.dateKey(e.date)));
    const gDays = new Set(gratitude.map(g => g.dateKey));
    const hDays = Data.doneDays();
    const today = Utils.dateKey();

    const first = new Date(this.y, this.m, 1).getDay();
    const total = new Date(this.y, this.m + 1, 0).getDate();
    let html = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(d => `<div class="cal-dow">${d}</div>`).join("");
    for (let i = 0; i < first; i++) html += `<div class="cal-blank"></div>`;

    for (let d = 1; d <= total; d++) {
      const key = Utils.dateKey(new Date(this.y, this.m, d));
      const avg = Data.avgOn(key);
      const bg = avg === null ? "" : `background:${MOOD_COLORS[Math.round(avg)]};`;
      const icons = (jDays.has(key) ? "📓" : "") + (gDays.has(key) ? "🙏" : "") + (hDays.has(key) ? "✅" : "");
      html += `<button class="cal-cell ${key === today ? "today" : ""} ${key === this.sel ? "sel" : ""}" style="${bg}" data-key="${key}">
        <span class="cal-num">${d}</span><span class="cal-icons">${icons}</span></button>`;
    }
    document.getElementById("cal-grid").innerHTML = html;
    this.detail(this.sel, { journal, gratitude, habits });
  },

  detail(key, { journal, gratitude, habits }) {
    const moods = Data.allMoods().filter(m => m.dateKey === key);
    const entries = journal.filter(e => Utils.dateKey(e.date) === key);
    const grat = gratitude.find(g => g.dateKey === key);
    const doneHabits = habits.filter(h => (h.log || []).includes(key));
    const dueTasks = Storage.get("tasks").filter(t => t.due === key);
    const focusMin = Storage.get("focus").filter(f => f.dateKey === key).reduce((s, f) => s + f.minutes, 0);

    const nothing = !moods.length && !entries.length && !grat && !doneHabits.length && !dueTasks.length && !focusMin;
    document.getElementById("cal-detail").innerHTML = `
      <h3>${Utils.longDate(key)}</h3>
      ${nothing ? `<p class="empty">Nothing recorded for this day.</p>` : ""}
      ${moods.length ? `<p><b>Moods:</b> ${moods.map(m => (Utils.moodObj(m.mood) || {}).emoji + " " + m.mood).join(", ")}</p>` : ""}
      ${entries.map(e => `<div class="entry"><strong>${Utils.escape(e.title) || "Untitled"}</strong> <span class="tag">${Utils.escape(e.type || "Thought")}</span>
        <p>${Utils.escape((e.text || "").slice(0, 200))}${(e.text || "").length > 200 ? "…" : ""}</p></div>`).join("")}
      ${grat ? `<p><b>Grateful for:</b></p><ul>${grat.items.filter(Boolean).map(i => `<li>${Utils.escape(i)}</li>`).join("")}</ul>` : ""}
      ${doneHabits.length ? `<p><b>Habits done:</b> ${doneHabits.map(h => Utils.escape(h.name)).join(", ")}</p>` : ""}
      ${dueTasks.length ? `<p><b>Tasks due:</b> ${dueTasks.map(t => (t.done ? "✓ " : "") + Utils.escape(t.text)).join(", ")}</p>` : ""}
      ${focusMin ? `<p><b>Focus time:</b> ${focusMin} min</p>` : ""}`;
  }
};
