// Offline cache for the app shell. Bump VERSION when you change any file.
const VERSION = "mindscape-v29";
const FILES = ["./", "index.html", "manifest.json", "icon.svg", "css/style.css", "js/achievements.js", "js/ai.js", "js/aiclient.js", "js/creator.js", "js/analytics.js", "js/app.js", "js/auth.js", "js/avatar.js", "js/char3d.js", "js/sources-import.js", "js/chatbrain.js", "assets/lib/pdf.classic.js", "assets/lib/pdf.worker.classic.js", "js/calendar.js", "js/charts.js", "js/companion-i18n.js", "js/companion.js", "js/dashboard.js", "js/gratitude.js", "js/grounding.js", "js/habits.js", "js/journal.js", "js/library.js", "js/selfunderstanding.js", "js/storage.js", "js/theme.js", "js/utils.js", "js/vision.js", "assets/characters/kai.jpg", "assets/characters/lian.jpg", "assets/characters/ren.jpg", "assets/characters/yuki.jpg"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET" || new URL(e.request.url).origin !== location.origin) return; // never cache API calls
  // Newest files first (so updates show straight away); the saved copy is only used when offline
  e.respondWith(
    fetch(e.request, { cache: "no-cache" })
      .then(res => { const copy = res.clone(); caches.open(VERSION).then(c => c.put(e.request, copy)).catch(() => {}); return res; })
      .catch(() => caches.match(e.request))
  );
});
