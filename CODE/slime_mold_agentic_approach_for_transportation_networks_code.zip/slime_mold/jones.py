"""
jones.py - Jones-style agent-based Physarum model on a raster, plus network extraction.
Upgraded with:
  * Demand/population weight support per station (`weights`)
  * Continuous Gaussian population density field (`pop_sigma_px`, `wPop`, Hill saturation)
  * Anti-fixation local crowding suppression (`anti_fix_beta`) so agents expand outward
    instead of clumping in the dense city core.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, asdict

import numpy as np
from scipy import ndimage as ndi

EARTH_R = 6_371_008.8  # metres


# ----------------------------------------------------------------------------
# parameters
# ----------------------------------------------------------------------------
@dataclass
class JonesParams:
    SA: float = 45.0        # sensor angle, degrees (Table 1: 22.5 or 45; 45 = 'minimising' regime)
    RA: float = 45.0        # rotation angle, degrees (Table 1: 45)
    SO: float = 9.0         # sensor offset, pixels (Table 1: 9)
    depT: float = 5.0       # deposition per successful step (Table 1: 5)
    decayT: float = 0.1     # trail decay factor (Table 1: 0.1)
    diffK: int = 3          # diffusion kernel size (Table 1: 3)
    pct_p: float = 2.0      # population as % of raster area (Table 1: 3-15; Fig 19 uses 2)
    wProj: float = 0.05     # station stimulus projection weight (Table 1: 0.01-0.1)
    SS: float = 1.0         # step size, pixels per step
    pCD: float = 0.0        # probability of random direction change
    periodic: bool = False  # Table 1 default is periodic; off here, see README
    stimulus_value: float = 255.0   # ASSUMPTION: 8-bit grey level of a stimulus pixel
    station_radius_px: float = 1.5  # footprint of a station stimulus
    # --- Population-Weighted & Anti-Fixation Extensions ---
    use_pop_field: bool = False     # Project continuous population density field around hubs
    wPop: float = 0.02              # Population field projection weight
    pop_sigma_px: float = 14.0      # Gaussian spread radius (px) for urban population density
    anti_fix_beta: float = 0.0      # Anti-fixation crowding suppression factor (e.g., 0.04)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        names = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in d.items() if k in names})


@dataclass
class ExtractParams:
    window: int = 50          # average the trail over the last N steps (1 = final field only)
    threshold: float = 0.35   # trail threshold as a fraction of the reference level
    ref_percentile: float = 99.0   # reference level = this percentile of the trail field
    catch_radius_px: float = 3.0   # station catchment radius for "touching" a trail
    min_blob_px: int = 4      # drop isolated trail specks smaller than this

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        names = cls.__dataclass_fields__.keys()
        return cls(**{k: v for k, v in d.items() if k in names})


# ----------------------------------------------------------------------------
# geography <-> raster
# ----------------------------------------------------------------------------
@dataclass
class Grid:
    lat0: float
    lng0: float
    xmin: float
    ymax: float
    scale: float   # metres per pixel
    W: int
    H: int

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        return cls(**d)

    def latlng_to_px(self, lat, lng):
        """Return (col, row) floats. Row 0 is the northern edge."""
        lat, lng = np.asarray(lat, float), np.asarray(lng, float)
        x = np.radians(lng - self.lng0) * EARTH_R * math.cos(math.radians(self.lat0))
        y = np.radians(lat - self.lat0) * EARTH_R
        return (x - self.xmin) / self.scale, (self.ymax - y) / self.scale

    def px_to_latlng(self, col, row):
        col, row = np.asarray(col, float), np.asarray(row, float)
        x = col * self.scale + self.xmin
        y = self.ymax - row * self.scale
        lat = np.degrees(y / EARTH_R) + self.lat0
        lng = np.degrees(x / (EARTH_R * math.cos(math.radians(self.lat0)))) + self.lng0
        return lat, lng

    def bounds(self):
        """[[south, west], [north, east]] of the raster, for map overlays."""
        n, w = self.px_to_latlng(-0.5, -0.5)
        s, e = self.px_to_latlng(self.W - 0.5, self.H - 0.5)
        return [[float(s), float(w)], [float(n), float(e)]]


def make_grid(lats, lngs, resolution, pad=0.15) -> Grid:
    """Raster covering all stations, padded, with the longer side = `resolution` pixels."""
    lats, lngs = np.asarray(lats, float), np.asarray(lngs, float)
    lat0, lng0 = float(lats.mean()), float(lngs.mean())
    x = np.radians(lngs - lng0) * EARTH_R * math.cos(math.radians(lat0))
    y = np.radians(lats - lat0) * EARTH_R
    span = max(x.max() - x.min(), y.max() - y.min(), 1.0)
    p = pad * span
    xmin, xmax, ymin, ymax = x.min() - p, x.max() + p, y.min() - p, y.max() + p
    wm, hm = xmax - xmin, ymax - ymin
    scale = max(wm, hm) / resolution
    return Grid(lat0, lng0, float(xmin), float(ymax), float(scale),
                int(math.ceil(wm / scale)), int(math.ceil(hm / scale)))


# ----------------------------------------------------------------------------
# the simulation
# ----------------------------------------------------------------------------
def stimulus_layer(shape, stations_px, params: JonesParams, weights=None):
    """Per-step stimulus added to the trail map: stimulus_value * wProj * weight on station pixels,
    plus optional sub-linearly saturated population density field."""
    H, W = shape
    yy, xx = np.mgrid[0:H, 0:W]
    mask = np.zeros(shape, bool)
    w_layer = np.zeros(shape, np.float32)
    if weights is None:
        weights = [1.0] * len(stations_px)

    for (c, r), w in zip(stations_px, weights):
        m = (xx - c) ** 2 + (yy - r) ** 2 <= params.station_radius_px ** 2
        m[int(np.clip(round(r), 0, H - 1)), int(np.clip(round(c), 0, W - 1))] = True
        mask |= m
        w_layer = np.maximum(w_layer, m.astype(np.float32) * float(w))

    stim = (w_layer * params.stimulus_value * params.wProj).astype(np.float32)

    if params.use_pop_field and params.wPop > 0 and len(stations_px) > 0:
        pop = np.zeros(shape, np.float32)
        sigma2 = 2.0 * max(1.0, float(params.pop_sigma_px)) ** 2
        for (c, r), w in zip(stations_px, weights):
            dist2 = (xx - c) ** 2 + (yy - r) ** 2
            pop += float(w) * np.exp(-dist2 / sigma2)
        pmax = float(pop.max())
        if pmax > 0:
            pop /= pmax
            # Hill / Michaelis-Menten sub-linear saturation prevents central fixation
            pop_sat = (pop ** 0.55) / (0.35 + (pop ** 0.55))
            stim += (pop_sat * params.stimulus_value * params.wPop).astype(np.float32)

    return stim, mask


def n_agents_from_pct(shape, pct):
    return max(1, int(round(shape[0] * shape[1] * pct / 100.0)))


def simulate(shape, stations_px, params: JonesParams, iterations, seed,
             n_agents=None, avg_window=50, progress=None, weights=None):
    """
    Run one Jones-style simulation.

    Returns dict with: final (last trail map), avg (mean trail over the last
    `avg_window` steps), agents_xy, seed, n_agents, iterations, seconds.
    `progress(i, total)` is called ~100 times so a UI can update / be interrupted.
    """
    t0 = time.time()
    H, W = shape
    rng = np.random.default_rng(seed)
    n = n_agents if n_agents is not None else n_agents_from_pct(shape, params.pct_p)
    n = int(min(n, H * W))

    SA, RA = math.radians(params.SA), math.radians(params.RA)
    SO, SS = params.SO, params.SS
    per = params.periodic
    kernel = max(1, int(params.diffK))
    keep = 1.0 - params.decayT
    stim, _ = stimulus_layer(shape, stations_px, params, weights=weights)
    beta = float(getattr(params, "anti_fix_beta", 0.0))

    trail = np.zeros((H, W), np.float32)
    flat = trail.reshape(-1)

    # initial agents: distinct random cells, random heading
    cidx = rng.choice(H * W, size=n, replace=False)
    x = (cidx % W).astype(np.float64)
    y = (cidx // W).astype(np.float64)
    h = rng.uniform(0, 2 * math.pi, n)
    occ = np.zeros(H * W, bool)
    occ[cidx] = True

    acc = np.zeros((H, W), np.float64)
    acc_n = 0
    first_avg = max(0, iterations - max(1, avg_window))
    tick = max(1, iterations // 100)

    def sense(offset):
        a = h + offset
        sx = np.rint(x + SO * np.cos(a)).astype(np.int64)
        sy = np.rint(y + SO * np.sin(a)).astype(np.int64)
        if per:
            return trail[sy % H, sx % W]
        ok = (sx >= 0) & (sx < W) & (sy >= 0) & (sy < H)
        v = np.zeros(n, np.float32)
        v[ok] = trail[sy[ok], sx[ok]]
        return v

    for it in range(iterations):
        # 1. MOTOR
        nx = x + SS * np.cos(h)
        ny = y + SS * np.sin(h)
        if per:
            nx %= W
            ny %= H
        tx = np.rint(nx).astype(np.int64)
        ty = np.rint(ny).astype(np.int64)
        if per:
            tx %= W
            ty %= H
            inb = np.ones(n, bool)
        else:
            inb = (tx >= 0) & (tx < W) & (ty >= 0) & (ty < H)
            tx = np.clip(tx, 0, W - 1)
            ty = np.clip(ty, 0, H - 1)
        tidx = ty * W + tx
        free = inb & (~occ[tidx] | (tidx == cidx))
        cand = np.flatnonzero(free)
        moved = np.zeros(n, bool)
        if cand.size:
            perm = rng.permutation(cand)
            _, first = np.unique(tidx[perm], return_index=True)
            moved[perm[first]] = True
        occ[cidx[moved]] = False
        occ[tidx[moved]] = True
        x[moved], y[moved], cidx[moved] = nx[moved], ny[moved], tidx[moved]
        flat[tidx[moved]] += params.depT
        stuck = ~moved
        if stuck.any():
            h[stuck] = rng.uniform(0, 2 * math.pi, int(stuck.sum()))
        if params.pCD > 0:
            r = rng.random(n) < params.pCD
            h[r] = rng.uniform(0, 2 * math.pi, int(r.sum()))

        # 2. SENSE + rotate (Jones's rule)
        F, FL, FR = sense(0.0), sense(-SA), sense(SA)
        fwd = (F > FL) & (F > FR)
        low = (F < FL) & (F < FR)
        rot = np.zeros(n)
        coin = np.where(rng.random(n) < 0.5, -RA, RA)
        rot[low] = coin[low]
        mid = ~fwd & ~low
        rot[mid & (FL < FR)] = RA
        rot[mid & (FR < FL)] = -RA
        h += rot

        # 3. stimuli (with optional anti-fixation local crowding suppression), 4. diffusion + decay
        if beta > 0.0:
            trail += stim / (1.0 + beta * trail)
        else:
            trail += stim
        trail = ndi.uniform_filter(trail, size=kernel, mode="wrap" if per else "constant")
        trail *= keep
        flat = trail.reshape(-1)

        if it >= first_avg:
            acc += trail
            acc_n += 1
        if progress and (it % tick == 0 or it == iterations - 1):
            progress(it + 1, iterations)

    return {
        "final": trail.copy(),
        "avg": (acc / max(acc_n, 1)).astype(np.float32),
        "agents_xy": np.column_stack([x, y]).astype(np.float32),
        "seed": int(seed),
        "n_agents": int(n),
        "iterations": int(iterations),
        "seconds": round(time.time() - t0, 2),
    }


# ----------------------------------------------------------------------------
# field -> station graph
# ----------------------------------------------------------------------------
_EIGHT = np.ones((3, 3), int)


def _disc_masks(shape, stations_px, radius):
    H, W = shape
    yy, xx = np.mgrid[0:H, 0:W]
    out = []
    for c, r in stations_px:
        m = (xx - c) ** 2 + (yy - r) ** 2 <= radius ** 2
        m[int(np.clip(round(r), 0, H - 1)), int(np.clip(round(c), 0, W - 1))] = True
        out.append(m)
    return out


def extract_graph(field, stations_px, ep: ExtractParams):
    """
    Turn a trail field into a station-to-station graph.
    """
    from skimage.morphology import skeletonize
    from skimage.graph import route_through_array

    field = np.asarray(field, np.float32)
    H, W = field.shape
    ref = float(np.percentile(field, ep.ref_percentile))
    info = {"ref_level": ref, "threshold_value": None, "mask_fraction": 0.0}
    n = len(stations_px)
    if ref <= 0 or n < 2:
        return {"edges": [], "skeleton": np.zeros((H, W), bool), "info": info}

    thr = ep.threshold * ref
    mask = field > thr
    info["threshold_value"] = float(thr)

    lab, k = ndi.label(mask, structure=_EIGHT)
    if k:
        sizes = ndi.sum(mask, lab, index=np.arange(1, k + 1))
        small = np.isin(lab, 1 + np.flatnonzero(sizes < ep.min_blob_px))
        mask &= ~small
    info["mask_fraction"] = float(mask.mean())

    skel = skeletonize(mask)
    discs = _disc_masks((H, W), stations_px, ep.catch_radius_px)
    all_discs = np.any(discs, axis=0)
    corridor = skel & ~all_discs
    clab, kc = ndi.label(corridor, structure=_EIGHT)

    # stations touching each corridor (disc dilated by 1 px so they can abut)
    touch = {}
    for j, d in enumerate(discs):
        ring = ndi.binary_dilation(d, structure=_EIGHT, iterations=1)
        for c in np.unique(clab[ring & corridor]):
            if c > 0:
                touch.setdefault(int(c), set()).add(j)

    edges = []
    for c, members in touch.items():
        members = sorted(members)
        if len(members) < 2:
            continue
        via_branch = len(members) > 2
        region = clab == c
        for ai in range(len(members)):
            for bi in range(ai + 1, len(members)):
                a, b = members[ai], members[bi]
                allowed = region | discs[a] | discs[b]
                cost = np.where(allowed, 1.0, 1e6)
                (r0, c0) = (int(np.clip(round(stations_px[a][1]), 0, H - 1)),
                            int(np.clip(round(stations_px[a][0]), 0, W - 1)))
                (r1, c1) = (int(np.clip(round(stations_px[b][1]), 0, H - 1)),
                            int(np.clip(round(stations_px[b][0]), 0, W - 1)))
                path, total = route_through_array(cost, (r0, c0), (r1, c1),
                                                  fully_connected=True, geometric=True)
                if total >= 1e6:      # no real path inside the allowed region
                    continue
                edges.append({"a": a, "b": b, "via_branch": via_branch,
                              "path_px": round(float(total), 2)})
    best = {}
    for e in edges:
        k = (e["a"], e["b"])
        if k not in best or e["path_px"] < best[k]["path_px"]:
            best[k] = e
    edges = [best[k] for k in sorted(best)]
    return {"edges": edges, "skeleton": skel, "info": info}
