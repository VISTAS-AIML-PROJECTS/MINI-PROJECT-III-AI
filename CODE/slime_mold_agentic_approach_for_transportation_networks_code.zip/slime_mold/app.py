"""
app.py - Streamlit dashboard for the Jones-style slime-mould network prototype.
Upgraded with Coimbatore Greenfield Metro preset, Population + Anti-Fixation controls,
Red/Green Line Folium rendering, and a built-in Matplotlib comparison figure generator.

Run:  streamlit run app.py
"""

import hashlib
import io
import json
import time

import folium
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image, ImageDraw
from streamlit_folium import st_folium

import core
from jones import (ExtractParams, JonesParams, Grid, extract_graph, make_grid,
                   n_agents_from_pct, simulate)

st.set_page_config(page_title="Slime Mould Network Optimizer", layout="wide")

CHENNAI = (13.0827, 80.2707)
COIMBATORE = (11.0183, 76.9725)
EX_CSV = "example_stations_chennai.csv"
CBE_CSV = "example_stations_coimbatore.csv"
CBE_EDGES_CSV = "example_connections_coimbatore.csv"

# ----------------------------------------------------------------------------
# configuration state (every widget is keyed so projects can restore it)
# ----------------------------------------------------------------------------
SIM_DEFAULTS = dict(
    cfg_SA=45.0, cfg_RA=45.0, cfg_SO=9.0, cfg_depT=5.0, cfg_decayT=0.1, cfg_diffK=3,
    cfg_pct=2.0, cfg_wProj=0.05, cfg_res=200, cfg_agent_mode="From %p", cfg_nagents=1000,
    cfg_iters=4000, cfg_runs=8, cfg_seed=42, cfg_diffseed=True, cfg_periodic=False,
    cfg_pCD=0.0, cfg_stimval=255.0, cfg_stimrad=1.5, cfg_window=50,
    cfg_use_pop=False, cfg_wPop=0.02, cfg_pop_sigma=14.0, cfg_antifix=0.0,
)
EXT_DEFAULTS = dict(cfg_thr=0.35, cfg_refpct=99.0, cfg_catch=3.0, cfg_minblob=4)
VIEW_DEFAULTS = dict(cfg_cons=0.7, cfg_show_unc=True, cfg_excl_branch=False)
ALL_DEFAULTS = {**SIM_DEFAULTS, **EXT_DEFAULTS, **VIEW_DEFAULTS}

# Optimal tuned preset for Coimbatore Greenfield Metro (balances trunk corridors + orbital resilience)
COIMBATORE_PRESET = dict(
    cfg_SA=32.5, cfg_RA=40.0, cfg_SO=11.0, cfg_depT=5.5, cfg_decayT=0.08, cfg_diffK=3,
    cfg_pct=4.5, cfg_wProj=0.045, cfg_res=240, cfg_agent_mode="From %p", cfg_nagents=2500,
    cfg_iters=3500, cfg_runs=6, cfg_seed=42, cfg_diffseed=True, cfg_periodic=False,
    cfg_pCD=0.01, cfg_stimval=255.0, cfg_stimrad=2.0, cfg_window=60,
    cfg_use_pop=True, cfg_wPop=0.025, cfg_pop_sigma=15.0, cfg_antifix=0.04,
    cfg_thr=0.28, cfg_refpct=98.5, cfg_catch=4.0, cfg_minblob=5,
    cfg_cons=0.5, cfg_show_unc=True, cfg_excl_branch=False,
)

for k, v in ALL_DEFAULTS.items():
    st.session_state.setdefault(k, v)
for k, v in dict(stations_base=core.empty_stations(), ed_ver=0, stations_valid=core.empty_stations(),
                 existing=pd.DataFrame(columns=["source_id", "target_id"]), map_view=None,
                 click_done=None, runs=[], fields={}, run_status="none", res_stations=None,
                 res_grid=None, res_sim_sig=None, res_ext_sig=None, res_origin="",
                 plan_n=0, project_name="coimbatore_metro").items():
    st.session_state.setdefault(k, v)


def reset_defaults():
    for k, v in ALL_DEFAULTS.items():
        st.session_state[k] = v


def apply_coimbatore_preset():
    for k, v in COIMBATORE_PRESET.items():
        st.session_state[k] = v


# ---- apply a project loaded on the previous run (must happen before widgets exist) ----
pend = st.session_state.pop("_pending_project", None)
if pend:
    proj, arrays = pend
    for k, v in proj["config"].items():
        if k in ALL_DEFAULTS:
            st.session_state[k] = type(ALL_DEFAULTS[k])(v) if not isinstance(ALL_DEFAULTS[k], str) else v
    sdf, _, _ = core.validate_stations(pd.DataFrame(proj["stations"]))
    st.session_state.stations_base = sdf if sdf is not None else core.empty_stations()
    st.session_state.stations_valid = st.session_state.stations_base
    st.session_state.ed_ver += 1
    st.session_state.existing = pd.DataFrame(proj.get("existing_edges", []),
                                             columns=["source_id", "target_id"])
    st.session_state.project_name = proj.get("name", "my_network")
    st.session_state.map_view = None
    res = proj.get("results")
    if res and res.get("runs"):
        st.session_state.runs = res["runs"]
        st.session_state.fields = arrays
        st.session_state.res_stations = res["stations"]
        st.session_state.res_grid = res["grid"]
        st.session_state.res_sim_sig = res.get("sim_signature")
        st.session_state.res_ext_sig = res.get("ext_signature")
        st.session_state.run_status = res.get("status", {}).get("state", "complete")
        st.session_state.plan_n = res.get("status", {}).get("planned_runs", len(res["runs"]))
        st.session_state.res_origin = f"loaded from saved project '{proj.get('name', '')}'"
    else:
        st.session_state.runs, st.session_state.fields = [], {}
        st.session_state.run_status, st.session_state.res_origin = "none", ""
    st.session_state.load_msg = "Project loaded."


def sim_params() -> JonesParams:
    s = st.session_state
    return JonesParams(SA=s.cfg_SA, RA=s.cfg_RA, SO=s.cfg_SO, depT=s.cfg_depT, decayT=s.cfg_decayT,
                       diffK=int(s.cfg_diffK), pct_p=s.cfg_pct, wProj=s.cfg_wProj, pCD=s.cfg_pCD,
                       periodic=s.cfg_periodic, stimulus_value=s.cfg_stimval,
                       station_radius_px=s.cfg_stimrad, use_pop_field=bool(s.cfg_use_pop),
                       wPop=float(s.cfg_wPop), pop_sigma_px=float(s.cfg_pop_sigma),
                       anti_fix_beta=float(s.cfg_antifix))


def ext_params() -> ExtractParams:
    s = st.session_state
    return ExtractParams(window=int(s.cfg_window), threshold=s.cfg_thr, ref_percentile=s.cfg_refpct,
                         catch_radius_px=s.cfg_catch, min_blob_px=int(s.cfg_minblob))


def n_agents_now(shape):
    s = st.session_state
    return int(s.cfg_nagents) if s.cfg_agent_mode == "Explicit count" else n_agents_from_pct(shape, s.cfg_pct)


def signature(kind, stations):
    s = st.session_state
    if kind == "sim":
        cols = [c for c in ["id", "lat", "lng", "weight"] if c in stations.columns]
        payload = {"st": stations[cols].round(7).values.tolist(),
                   "cfg": {k: s[k] for k in SIM_DEFAULTS}}
    else:
        payload = {k: s[k] for k in EXT_DEFAULTS}
    return hashlib.md5(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()[:12]


def est_seconds(shape, n_agents, iters, runs):
    ms = 0.30 + 0.00055 * n_agents + 0.0000090 * shape[0] * shape[1]
    return runs * iters * ms / 1000.0


# ----------------------------------------------------------------------------
# drawing helpers
# ----------------------------------------------------------------------------
MUTE_CSS = "<style>.leaflet-tile-pane{filter:grayscale(1) brightness(1.12) contrast(.7) opacity(.9)}</style>"


def base_map(center, zoom):
    m = folium.Map(location=center, zoom_start=zoom, tiles="OpenStreetMap", control_scale=True)
    m.get_root().html.add_child(folium.Element(MUTE_CSS))
    return m


def add_stations(m, stations, label=True):
    for _, s in stations.iterrows():
        w_str = f" | w={s['weight']:.2f}" if "weight" in s and pd.notna(s["weight"]) else ""
        folium.CircleMarker(
            [s["lat"], s["lng"]], radius=8 if s["interchange"] else 6,
            color="#c8452d", weight=3 if s["interchange"] else 2, fill=True,
            fill_color="#ffffff", fill_opacity=1,
            tooltip=folium.Tooltip(f"{s['name']} ({s['id']}{w_str})", permanent=label, direction="right"),
        ).add_to(m)


def add_existing(m, stations, existing):
    st_i = stations.set_index("id")
    for _, e in existing.iterrows():
        if e["source_id"] in st_i.index and e["target_id"] in st_i.index:
            a, b = st_i.loc[e["source_id"]], st_i.loc[e["target_id"]]
            line_name = str(e.get("line", "existing connection"))
            if "Red" in line_name:
                col = "#D90429"
            elif "Green" in line_name:
                col = "#1B998B"
            else:
                col = "#3d5a80"
            folium.PolyLine([[a["lat"], a["lng"]], [b["lat"], b["lng"]]], color=col, weight=3.5,
                            opacity=0.88, dash_array="6 6",
                            tooltip=f"Proposed/Existing: {line_name}").add_to(m)


def field_image(field, skel=None, stations_px=None, width=560):
    ref = float(np.percentile(field, 99.5)) or 1.0
    g = np.clip(field / (ref * 1.2), 0, 1)
    rgb = np.stack([255 * (1 - g)] * 3, axis=-1).astype(np.uint8)
    if skel is not None:
        rgb[skel] = (214, 40, 40)
    k = max(1, width // field.shape[1])
    img = Image.fromarray(rgb).resize((field.shape[1] * k, field.shape[0] * k), Image.NEAREST)
    if stations_px is not None:
        d = ImageDraw.Draw(img)
        for c, r in stations_px:
            x, y = (c + 0.5) * k, (r + 0.5) * k
            d.ellipse([x - 5, y - 5, x + 5, y + 5], outline=(30, 90, 220), fill=(255, 255, 255), width=2)
    return img


# ============================================================================
st.title("Slime-Mould Network Optimizer")
st.caption("Agent-based, raster Physarum model to compute efficient logistics and transportation networks (Chennai & Coimbatore Metro).")
if "load_msg" in st.session_state:
    st.success(st.session_state.pop("load_msg"))

tabA, tabB, tabC, tabD = st.tabs(["A. Map and stations", "B. Model configuration",
                                  "C. Simulation results", "D. Export and project"])

# ============================================================================
# TAB A
# ============================================================================
with tabA:
    left, right = st.columns([3, 2])

    with right:
        st.subheader("Station editor")
        b1, b2 = st.columns(2)
        if b1.button("Load Coimbatore Metro (Greenfield + Red/Green DPR)", type="primary"):
            df, e, w = core.parse_stations_csv(open(CBE_CSV, "rb").read())
            if df is not None:
                st.session_state.stations_base = df
                st.session_state.ed_ver += 1
                st.session_state.map_view = {"center": COIMBATORE, "zoom": 12}
                st.session_state.project_name = "coimbatore_metro"
                ex_e, _ = core.parse_edges_csv(open(CBE_EDGES_CSV, "rb").read(), set(df["id"]))
                if ex_e is not None:
                    st.session_state.existing = ex_e
                apply_coimbatore_preset()
                st.rerun()

        if b2.button("Load Chennai example"):
            df, e, w = core.parse_stations_csv(open(EX_CSV, "rb").read())
            if df is not None:
                st.session_state.stations_base = df
                st.session_state.ed_ver += 1
                st.session_state.map_view = None
                st.session_state.project_name = "chennai_metro"
                ex_e, _ = core.parse_edges_csv(open("example_connections_chennai.csv", "rb").read(), set(df["id"]))
                if ex_e is not None:
                    st.session_state.existing = ex_e
                st.rerun()

        base = st.session_state.stations_base
        edited = st.data_editor(
            base, key=f"editor_{st.session_state.ed_ver}", num_rows="dynamic", hide_index=True,
            column_config={
                "id": st.column_config.TextColumn("ID", help="Unique. Leave blank to auto-assign."),
                "name": st.column_config.TextColumn("Name"),
                "lat": st.column_config.NumberColumn("Latitude", format="%.6f", min_value=-90, max_value=90),
                "lng": st.column_config.NumberColumn("Longitude", format="%.6f", min_value=-180, max_value=180),
                "interchange": st.column_config.CheckboxColumn("Interchange"),
                "weight": st.column_config.NumberColumn("Demand Weight", format="%.2f", min_value=0.1, max_value=10.0),
            })
        clean, errs, warns = core.validate_stations(edited)
        if errs:
            for e in errs[:6]:
                st.error(e)
            st.caption("Fix the table to continue; the last valid station set is still in use.")
        else:
            st.session_state.stations_valid = clean
        for w in warns:
            st.warning(w)
        stations = st.session_state.stations_valid
        st.metric("Stations", len(stations))
        st.caption("Select a row and press Delete to remove it. Edit cells directly.")

        with st.expander("Add a station by coordinates", expanded=False):
            c1, c2 = st.columns(2)
            nm = c1.text_input("Name", key="man_name")
            sid = c2.text_input("ID (optional)", key="man_id")
            la = c1.number_input("Latitude", -90.0, 90.0, COIMBATORE[0], format="%.6f", key="man_lat")
            ln = c2.number_input("Longitude", -180.0, 180.0, COIMBATORE[1], format="%.6f", key="man_lng")
            ic = st.checkbox("Interchange", key="man_ic")
            if st.button("Add station"):
                row = pd.DataFrame([{"id": sid.strip(), "name": nm.strip(), "lat": la, "lng": ln, "interchange": ic}])
                new, e, w = core.validate_stations(pd.concat([stations, row], ignore_index=True))
                if new is None:
                    st.error(" ".join(e))
                else:
                    st.session_state.stations_base = new
                    st.session_state.ed_ver += 1
                    st.rerun()

        with st.expander("Import stations from CSV", expanded=False):
            up = st.file_uploader("CSV with name, latitude, longitude (id, interchange, weight optional)",
                                  type=["csv"], key="up_stations")
            mode = st.radio("When importing", ["Replace current stations", "Append"], horizontal=True)
            if up is not None and st.button("Import CSV"):
                df, e, w = core.parse_stations_csv(up)
                if df is None:
                    for x in e[:5]:
                        st.error(x)
                else:
                    if mode == "Append" and len(stations):
                        df, e, w = core.validate_stations(pd.concat([stations, df], ignore_index=True))
                    if df is None:
                        for x in e[:5]:
                            st.error(x)
                    else:
                        st.session_state.stations_base = df
                        st.session_state.ed_ver += 1
                        st.session_state.map_view = None
                        st.rerun()

        with st.expander("Existing / Proposed DPR connections (optional)", expanded=False):
            st.caption("CSV with source_id,target_id,line. Red Line is drawn crimson dashed, Green Line teal dashed.")
            upe = st.file_uploader("Existing connections CSV", type=["csv"], key="up_edges")
            if upe is not None and st.button("Import connections"):
                ex_e, e = core.parse_edges_csv(upe, set(stations["id"]))
                if ex_e is None:
                    for x in e:
                        st.error(x)
                else:
                    st.session_state.existing = ex_e
                    st.rerun()
            st.write(f"{len(st.session_state.existing)} connection(s) loaded.")

    with left:
        st.subheader("Map")
        st.caption("Click the map to choose a location, then add it as a station. Zoom and pan freely.")
        mv = st.session_state.map_view
        if mv is None:
            if len(stations):
                mv = {"center": (float(stations["lat"].mean()), float(stations["lng"].mean())), "zoom": 12}
            else:
                mv = {"center": COIMBATORE, "zoom": 11}
            st.session_state.map_view = mv
        m = base_map(mv["center"], mv["zoom"])
        add_existing(m, stations, st.session_state.existing)
        add_stations(m, stations)
        out = st_folium(m, key="map_a", height=520, use_container_width=True, center=mv["center"], zoom=mv["zoom"],
                        returned_objects=["last_clicked", "center", "zoom"])
        if out:
            if out.get("center") and out.get("zoom"):
                st.session_state.map_view = {"center": (out["center"]["lat"], out["center"]["lng"]),
                                             "zoom": out["zoom"]}
            clk = out.get("last_clicked")
            if clk and (clk["lat"], clk["lng"]) != st.session_state.click_done:
                st.info(f"Clicked location: {clk['lat']:.6f}, {clk['lng']:.6f}")
                c1, c2, c3 = st.columns([3, 1, 1])
                cname = c1.text_input("Station name", key="click_name",
                                      placeholder=f"Station {len(stations) + 1}")
                cic = c2.checkbox("Interchange", key="click_ic")
                if c3.button("Add here"):
                    row = pd.DataFrame([{"id": "", "name": cname.strip(), "lat": round(clk["lat"], 6),
                                         "lng": round(clk["lng"], 6), "interchange": cic}])
                    new, e, w = core.validate_stations(pd.concat([stations, row], ignore_index=True))
                    if new is None:
                        st.error(" ".join(e))
                    else:
                        st.session_state.stations_base = new
                        st.session_state.click_done = (clk["lat"], clk["lng"])
                        st.session_state.ed_ver += 1
                        st.session_state.pop("click_name", None)
                        st.rerun()

# ============================================================================
# TAB B
# ============================================================================
with tabB:
    s = st.session_state
    pcol1, pcol2, _ = st.columns([1, 1, 2])
    pcol1.button("Apply Coimbatore Optimal Preset", type="primary", on_click=apply_coimbatore_preset)
    pcol2.button("Reset all to paper-based defaults", on_click=reset_defaults)

    cA, cB, cC = st.columns(3)
    with cA:
        st.subheader("Agent")
        st.number_input("Sensor angle SA (deg)", 1.0, 179.0, step=0.5, key="cfg_SA",
                        help="Coimbatore Optimal: 32.5° (encourages orbital loops + Steiner junctions). Paper default: 45°.")
        st.number_input("Rotation angle RA (deg)", 1.0, 179.0, step=0.5, key="cfg_RA",
                        help="Coimbatore Optimal: 40.0°. Smooths radial turns along Avinashi & Sathy Rd.")
        st.number_input("Sensor offset SO (px)", 1.0, 60.0, step=1.0, key="cfg_SO",
                        help="Coimbatore Optimal: 11 px (~1.1 km lookahead at res=240). Paper: 9.")
        st.number_input("Deposition depT", 0.1, 100.0, step=0.5, key="cfg_depT", help="Coimbatore Optimal: 5.5.")
    with cB:
        st.subheader("Framework")
        st.number_input("Decay decayT", 0.0001, 0.9, step=0.01, format="%.4f", key="cfg_decayT",
                        help="Coimbatore Optimal: 0.08 (keeps peripheral corridors alive longer).")
        st.selectbox("Diffusion kernel diffK", [3, 5, 7], key="cfg_diffK", help="Mean filter size. Paper: 3.")
        st.number_input("Population %p of raster area", 0.1, 60.0, step=0.5, key="cfg_pct",
                        help="Coimbatore Optimal: 4.5% (ensures enough agents to span 20 city-wide hubs).")
        st.number_input("Stimulus weight wProj", 0.001, 1.0, step=0.005, format="%.3f", key="cfg_wProj",
                        help="Coimbatore Optimal: 0.045. Higher = tighter MST; lower = more redundant loops.")
    with cC:
        st.subheader("Raster and runs")
        st.number_input("Raster resolution (px, longer side)", 60, 500, step=10, key="cfg_res")
        st.radio("Agent number set by", ["From %p", "Explicit count"], horizontal=True, key="cfg_agent_mode")
        if s.cfg_agent_mode == "Explicit count":
            st.number_input("Number of agents", 10, 200000, step=100, key="cfg_nagents")
        st.number_input("Iterations per run", 100, 100000, step=500, key="cfg_iters")
        st.number_input("Independent runs", 1, 200, step=1, key="cfg_runs")
        st.number_input("Random seed (base)", 0, 2**31 - 1, step=1, key="cfg_seed")
        st.checkbox("Use a different seed for each run (base + run index)", key="cfg_diffseed")

    with st.expander("Population Density Field & Anti-Fixation Controls (Coimbatore Greenfield Mode)", expanded=True):
        pf1, pf2, pf3, pf4 = st.columns(4)
        pf1.checkbox("Enable Population Density Field", key="cfg_use_pop",
                     help="Projects a sub-linearly saturated Gaussian urban population field around demand-weighted hubs.")
        pf2.number_input("Population field weight wPop", 0.0, 0.5, step=0.005, format="%.3f", key="cfg_wPop",
                         help="Coimbatore Optimal: 0.025.")
        pf3.number_input("Urban spread sigma (px)", 2.0, 60.0, step=1.0, key="cfg_pop_sigma",
                         help="Coimbatore Optimal: 15 px.")
        pf4.number_input("Anti-fixation crowding beta", 0.0, 0.5, step=0.01, format="%.3f", key="cfg_antifix",
                         help="Coimbatore Optimal: 0.04. Suppresses nutrient projection where trail is already saturated so agents expand outward.")

    with st.expander("Advanced model options"):
        a1, a2, a3, a4 = st.columns(4)
        a1.checkbox("Periodic boundary", key="cfg_periodic")
        a2.number_input("Random direction change pCD", 0.0, 1.0, step=0.01, key="cfg_pCD")
        a3.number_input("Stimulus pixel value", 1.0, 255.0, step=5.0, key="cfg_stimval")
        a4.number_input("Station footprint radius (px)", 0.0, 6.0, step=0.5, key="cfg_stimrad")

    st.subheader("Network extraction")
    e1, e2, e3, e4, e5 = st.columns(5)
    e1.number_input("Average trail over last N steps", 1, 5000, step=10, key="cfg_window")
    e2.number_input("Trail threshold (x reference)", 0.02, 3.0, step=0.02, key="cfg_thr")
    e3.number_input("Reference percentile", 50.0, 100.0, step=0.5, key="cfg_refpct")
    e4.number_input("Station catchment radius (px)", 1.0, 15.0, step=0.5, key="cfg_catch")
    e5.number_input("Ignore specks smaller than (px)", 0, 200, step=1, key="cfg_minblob")

    # ---- feasibility summary and warnings ----
    stn = st.session_state.stations_valid
    if len(stn) >= 2:
        g = make_grid(stn["lat"], stn["lng"], int(s.cfg_res))
        shape = (g.H, g.W)
        na = n_agents_now(shape)
        secs = est_seconds(shape, na, int(s.cfg_iters), int(s.cfg_runs))
        st.info(f"Raster {g.W} x {g.H} px at about {g.scale:.0f} m per pixel; {na:,} agents; "
                f"rough estimate {secs:.0f} s for {int(s.cfg_runs)} run(s).")
    else:
        st.info("Add at least two stations in tab A.")

# ============================================================================
# TAB C
# ============================================================================
def run_all():
    s = st.session_state
    stn = s.stations_valid.copy()
    g = make_grid(stn["lat"], stn["lng"], int(s.cfg_res))
    shape = (g.H, g.W)
    c, r = g.latlng_to_px(stn["lat"].values, stn["lng"].values)
    px = list(zip(c, r))
    weights = stn["weight"].values.tolist() if "weight" in stn.columns else None
    jp, ep = sim_params(), ext_params()
    n_runs, iters = int(s.cfg_runs), int(s.cfg_iters)
    na = n_agents_now(shape)

    s.runs, s.fields = [], {}
    s.res_stations = stn.to_dict("records")
    s.res_grid = g.to_dict()
    s.res_sim_sig, s.res_ext_sig = signature("sim", stn), signature("ext", stn)
    s.run_status, s.plan_n, s.res_origin = "running", n_runs, "simulated in this session"

    bar = st.progress(0.0, text="Starting...")
    t0 = time.time()
    for i in range(n_runs):
        seed = int(s.cfg_seed) + (i if s.cfg_diffseed else 0)
        rec = {"index": i, "seed": seed, "status": "ok", "error": "", "edges": []}

        def cb(it, tot, i=i):
            done = (i + it / tot) / n_runs
            bar.progress(min(done, 1.0), text=f"Run {i + 1}/{n_runs}, step {it}/{tot}  "
                                              f"(elapsed {time.time() - t0:.0f}s). Press Stop to interrupt.")
        try:
            res = simulate(shape, px, jp, iters, seed, n_agents=na if s.cfg_agent_mode == "Explicit count" else None,
                           avg_window=ep.window, progress=cb, weights=weights)
            ex = extract_graph(res["avg"], px, ep)
            rec.update(seconds=res["seconds"], n_agents=res["n_agents"], iterations=iters,
                       ref_level=ex["info"]["ref_level"], mask_fraction=ex["info"]["mask_fraction"],
                       edges=[{"a": stn.iloc[e["a"]]["id"], "b": stn.iloc[e["b"]]["id"],
                               "via_branch": bool(e["via_branch"]),
                               "path_km": round(e["path_px"] * g.scale / 1000.0, 4)} for e in ex["edges"]])
            if not np.isfinite(res["avg"]).all():
                raise ValueError("trail field contains non-finite values")
            s.fields[f"avg_{i}"] = res["avg"]
            s.fields[f"final_{i}"] = res["final"]
        except Exception as exc:
            rec.update(status="failed", error=f"{type(exc).__name__}: {exc}")
        s.runs = s.runs + [rec]
    bar.progress(1.0, text=f"Finished {n_runs} run(s) in {time.time() - t0:.0f}s")
    s.run_status = "complete"


def reextract():
    s = st.session_state
    g = Grid.from_dict(s.res_grid)
    stn = pd.DataFrame(s.res_stations)
    c, r = g.latlng_to_px(stn["lat"].values, stn["lng"].values)
    px, ep = list(zip(c, r)), ext_params()
    for rec in s.runs:
        key = f"avg_{rec['index']}"
        if rec["status"] != "ok" or key not in s.fields:
            continue
        ex = extract_graph(s.fields[key], px, ep)
        rec["edges"] = [{"a": stn.iloc[e["a"]]["id"], "b": stn.iloc[e["b"]]["id"],
                         "via_branch": bool(e["via_branch"]),
                         "path_km": round(e["path_px"] * g.scale / 1000.0, 4)} for e in ex["edges"]]
        rec["ref_level"], rec["mask_fraction"] = ex["info"]["ref_level"], ex["info"]["mask_fraction"]
    s.res_ext_sig = signature("ext", stn)


with tabC:
    s = st.session_state
    cr1, cr2, cr3 = st.columns([1, 1, 4])
    run_clicked = cr1.button("Run Simulation", type="primary", disabled=len(s.stations_valid) < 2)
    cr2.button("Stop", help="Interrupts a running simulation. Runs already finished are kept.")
    if run_clicked:
        run_all()
    elif s.run_status == "running":
        s.run_status = "interrupted"

    runs = s.runs
    if s.run_status == "none" or not runs:
        st.info("No simulation has been run yet. Load Coimbatore or Chennai in Tab A, check parameters in Tab B, "
                "then press Run Simulation.")
    else:
        okn = sum(r["status"] == "ok" for r in runs)
        failed = [r for r in runs if r["status"] == "failed"]
        banner = {"complete": "complete", "interrupted": "INTERRUPTED"}.get(s.run_status, s.run_status)
        st.success(f"Status: {banner}. Results {s.res_origin}. Successful runs: {okn}; failed: {len(failed)}; "
                   f"planned: {s.plan_n}.")

        cur_stn = s.stations_valid
        if signature("sim", cur_stn) != s.res_sim_sig:
            st.warning("The stations or model parameters have changed since these results were produced. "
                       "Press Run Simulation to refresh.")
        elif signature("ext", cur_stn) != s.res_ext_sig:
            st.warning("Extraction settings differ from those used for these results.")
            if st.button("Re-extract networks from the stored trail fields with the current extraction settings"):
                reextract()
                st.rerun()

        stn_r = pd.DataFrame(s.res_stations)
        grid = Grid.from_dict(s.res_grid)

        v1, v2, v3 = st.columns([2, 2, 3])
        v1.slider("Minimum edge-frequency threshold", 0.0, 1.0, step=0.05, key="cfg_cons")
        v1.checkbox("Show less-consistent links (dashed)", key="cfg_show_unc")
        v1.checkbox("Hide links that only exist via a shared branching corridor", key="cfg_excl_branch")
        okidx = [r["index"] for r in runs if r["status"] == "ok"]
        pick = v2.selectbox("Show individual run", ["None"] + [f"Run {i + 1} (seed {runs[i]['seed']})" for i in okidx])
        show_heat = v2.checkbox("Trail-density heatmap on map", value=True)
        show_exist = v3.checkbox("Proposed Red/Green Line / Existing connections", value=True)
        show_mst = v3.checkbox("MST baseline (separate, not simulation output)", value=False)
        show_skel = v3.checkbox("Mould trail skeleton of the selected run", value=False)

        edges = core.consensus_edges(runs, stn_r, s.cfg_cons, exclude_branch_only=s.cfg_excl_branch)

        # ---------- map ----------
        mm = base_map([stn_r["lat"].mean(), stn_r["lng"].mean()], 12)
        mm.fit_bounds(grid.bounds())
        sel = None if pick == "None" else okidx[[f"Run {i + 1} (seed {runs[i]['seed']})" for i in okidx].index(pick)]
        fkey = f"avg_{sel if sel is not None else (okidx[-1] if okidx else 0)}"
        if show_heat and fkey in s.fields:
            f = s.fields[fkey]
            a = np.clip(f / ((np.percentile(f, 99.5) or 1.0) * 1.2), 0, 1)
            rgba = np.zeros(f.shape + (4,), np.uint8)
            rgba[..., 3] = (a * 200).astype(np.uint8)
            folium.raster_layers.ImageOverlay(image=rgba, bounds=grid.bounds(), opacity=0.8,
                                              mercator_project=True, name="trail density").add_to(mm)
        if show_skel and sel is not None and f"avg_{sel}" in s.fields:
            c_, r_ = grid.latlng_to_px(stn_r["lat"].values, stn_r["lng"].values)
            sk = extract_graph(s.fields[f"avg_{sel}"], list(zip(c_, r_)), ext_params())["skeleton"]
            rgba = np.zeros(sk.shape + (4,), np.uint8)
            rgba[sk] = (214, 40, 40, 255)
            folium.raster_layers.ImageOverlay(image=rgba, bounds=grid.bounds(), opacity=0.9,
                                              mercator_project=True, name="trail skeleton").add_to(mm)
        if show_exist:
            add_existing(mm, stn_r, s.existing)
        if show_mst:
            import networkx as nx
            G = nx.Graph()
            rr = stn_r.to_dict("records")
            for i in range(len(rr)):
                for j in range(i + 1, len(rr)):
                    G.add_edge(i, j, weight=core.haversine_km(rr[i]["lat"], rr[i]["lng"], rr[j]["lat"], rr[j]["lng"]))
            for i, j in nx.minimum_spanning_tree(G).edges():
                folium.PolyLine([[rr[i]["lat"], rr[i]["lng"]], [rr[j]["lat"], rr[j]["lng"]]], color="#2a6fdb",
                                weight=2, opacity=0.8, dash_array="10 6", tooltip="MST baseline").add_to(mm)
        if sel is not None:
            for e in runs[sel]["edges"]:
                if s.cfg_excl_branch and e.get("via_branch"):
                    continue
                a_ = stn_r[stn_r["id"] == e["a"]].iloc[0]
                b_ = stn_r[stn_r["id"] == e["b"]].iloc[0]
                folium.PolyLine([[a_["lat"], a_["lng"]], [b_["lat"], b_["lng"]]], color="#1f77b4", weight=3,
                                opacity=0.9, tooltip=f"run {sel + 1}: {e['a']}-{e['b']}").add_to(mm)
        for _, e in edges.iterrows():
            tip = (f"{e['source_name']} - {e['target_name']}: frequency {e['edge_frequency']:.2f} "
                   f"({e['runs_with_edge']}/{e['successful_runs']}), {e['length_km']:.2f} km")
            line = [[e["source_lat"], e["source_lng"]], [e["target_lat"], e["target_lng"]]]
            if e["meets_threshold"]:
                folium.PolyLine(line, color="#000000", weight=2 + 5 * e["edge_frequency"], opacity=0.9,
                                tooltip=tip).add_to(mm)
            elif s.cfg_show_unc:
                folium.PolyLine(line, color="#c8452d", weight=2, opacity=0.8, dash_array="6 6",
                                tooltip=tip).add_to(mm)
        add_stations(mm, stn_r)
        st_folium(mm, key="map_c", height=560, use_container_width=True, returned_objects=[])

        # ---------- statistics ----------
        met = core.summary_metrics(stn_r, edges, s.cfg_cons, runs)
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Stations", met["stations"])
        m2.metric("Successful runs", met["successful_runs"])
        m3.metric("Stable edges", met["stable_edges"], f"{met['unstable_edges']} less consistent", delta_color="off")
        m4.metric("Stable length (km)", met["total_stable_length_km"])
        m5.metric("TL / TL_MST", met.get("TL_over_TL_MST", "N/A"))

        t1, t2, t3, t4 = st.tabs(["Edge table", "Frequency distribution", "Trail fields", "Run log and extras"])
        with t1:
            if len(edges):
                show = edges[["source_name", "target_name", "length_km", "runs_with_edge", "successful_runs",
                              "edge_frequency", "meets_threshold", "branch_only", "mean_trail_path_km"]]
                st.dataframe(show, hide_index=True)
            else:
                st.info("No station-to-station connections were extracted. Try lowering the trail threshold in tab B.")
        with t2:
            if met["frequency_distribution"]:
                st.bar_chart(pd.Series(met["frequency_distribution"], name="edges"))
        with t3:
            if okidx:
                k = sel if sel is not None else okidx[-1]
                c_, r_ = grid.latlng_to_px(stn_r["lat"].values, stn_r["lng"].values)
                px_ = list(zip(c_, r_))
                ex = extract_graph(s.fields[f"avg_{k}"], px_, ext_params())
                i1, i2 = st.columns(2)
                i1.image(field_image(s.fields[f"final_{k}"], None, px_), caption=f"Run {k + 1}: final trail field")
                i2.image(field_image(s.fields[f"avg_{k}"], ex["skeleton"], px_),
                         caption=f"Run {k + 1}: averaged field used for extraction, with skeleton (red)")
        with t4:
            st.dataframe(pd.DataFrame([{k: v for k, v in r.items() if k != "edges"} | {"edges_found": len(r["edges"])}
                                       for r in runs]), hide_index=True)
            extra = {k: v for k, v in met.items() if k not in ("frequency_distribution",)}
            st.json(extra)

# ============================================================================
# TAB D
# ============================================================================
with tabD:
    s = st.session_state
    st.subheader("Project")
    s.project_name = st.text_input("Project name", value=s.project_name)

    def build_project():
        have = bool(s.runs) and s.res_stations is not None
        edges_ = core.consensus_edges(s.runs, pd.DataFrame(s.res_stations), s.cfg_cons, s.cfg_excl_branch) if have else None
        proj = {
            "name": s.project_name,
            "description": "Jones-style slime-mould network prototype project",
            "stations": s.stations_valid.to_dict("records"),
            "existing_edges": s.existing.to_dict("records"),
            "config": {k: s[k] for k in ALL_DEFAULTS},
            "reproducibility": {
                "model": "Jones (2010) agent/raster Physarum model with Population & Anti-Fixation",
                "jones_params": sim_params().to_dict(), "extract_params": ext_params().to_dict(),
                "seeds": [r["seed"] for r in s.runs] if have else [],
                "seed_rule": "base + run index" if s.cfg_diffseed else "same seed for every run",
            },
            "results": None,
        }
        arrays = None
        if have:
            proj["results"] = {
                "stations": s.res_stations, "grid": s.res_grid, "runs": s.runs,
                "status": {"state": s.run_status, "planned_runs": s.plan_n,
                           "completed_runs": len(s.runs),
                           "successful_runs": sum(r["status"] == "ok" for r in s.runs)},
                "sim_signature": s.res_sim_sig, "ext_signature": s.res_ext_sig,
                "summary": core.summary_metrics(pd.DataFrame(s.res_stations), edges_, s.cfg_cons, s.runs),
            }
            arrays = dict(s.fields)
        return proj, arrays

    proj, arrays = build_project()
    zbytes = core.build_project_zip(proj, arrays)
    st.download_button("Save project (.zip)", zbytes, file_name=f"{s.project_name or 'project'}.zip",
                       mime="application/zip")
    upl = st.file_uploader("Load project (.zip or .json)", type=["zip", "json"], key="up_project")
    if upl is not None and st.button("Load project"):
        p, arr, errs_ = core.load_project(upl.read())
        if p is None:
            for e in errs_:
                st.error(e)
        else:
            s["_pending_project"] = (p, arr)
            st.rerun()

    st.divider()
    st.subheader("Download results")
    st.download_button("Stations CSV", core.stations_csv(s.stations_valid), file_name="stations.csv", mime="text/csv")
    if s.runs and s.res_stations is not None and any(r["status"] == "ok" for r in s.runs):
        stn_r = pd.DataFrame(s.res_stations)
        edges_all = core.consensus_edges(s.runs, stn_r, s.cfg_cons, s.cfg_excl_branch)
        inc = st.checkbox("Include less-consistent links in GeoJSON", value=True)
        d1, d2, d3, d4 = st.columns(4)
        d1.download_button("Edges CSV", core.edges_csv(edges_all), file_name="edges.csv", mime="text/csv")
        d2.download_button("GeoJSON", core.to_geojson(stn_r, edges_all, inc), file_name="network.geojson",
                           mime="application/geo+json")
        repro = {"project": proj["name"], "reproducibility": proj["reproducibility"], "config": proj["config"],
                 "grid": s.res_grid, "runs": [{k: v for k, v in r.items() if k != "edges"} for r in s.runs],
                 "summary": proj["results"]["summary"]}
        d3.download_button("Parameters, seeds and summary (JSON)", json.dumps(repro, indent=1, default=str),
                           file_name="reproducibility.json", mime="application/json")
        d4.download_button("Run log CSV", pd.DataFrame([{k: v for k, v in r.items() if k != "edges"} | {"edges_found": len(r["edges"])}
                                                        for r in s.runs]).to_csv(index=False),
                           file_name="run_log.csv", mime="text/csv")
