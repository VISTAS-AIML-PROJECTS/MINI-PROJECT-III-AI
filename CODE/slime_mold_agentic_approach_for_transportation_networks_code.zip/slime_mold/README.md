# Jones-style slime-mould network prototype

Research prototype for the paper *"An Agentic Framework Using Slime Mold Intelligence for Resilient
Transportation Network Optimization: A Chennai Metro Case Study"*.

It implements the **agent-based, raster Jones model** (J. Jones, *Artificial Life* 16(2), 2010), not the
Tero-Takagi-Nakagaki conductivity model. Stations are placed on a map, a population of agents is simulated
on a raster covering them, a station-to-station graph is extracted from the resulting trail field, and
many stochastic runs are combined into a consensus network with per-edge frequencies.

## Setup and launch

```bash
cd jonesnet
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py               # opens http://localhost:8501
```

Verify the install first (about 30 s, no browser needed):

```bash
python tests.py
```

No API keys, database, Docker or cloud services are used. Map tiles come from OpenStreetMap (internet
needed for the basemap only; the simulation runs offline).

## Quick workflow

1. **A. Map and stations**: press *Load Chennai example*, or click the map then *Add here*, or type
   coordinates, or import a CSV. Edit or delete rows in the table directly.
2. **B. Model configuration**: defaults are paper-based. The header shows raster size, agent count and a
   rough time estimate, with warnings if a setting will be slow or unreasonable.
3. **C. Simulation results**: *Run Simulation* (default 8 runs x 4000 steps is about 30 s). Move the
   consensus slider, toggle uncertain links, inspect any single run, view the trail heatmap.
4. **D. Export and project**: save/load the project ZIP, download CSV/GeoJSON/JSON.

*Stop* interrupts a running simulation; runs that already finished are kept and clearly marked
"INTERRUPTED". Results loaded from a project are labelled as loaded; if stations or parameters changed
since the results were produced, a warning says the results belong to the old configuration.

## The model

Per scheduler step (`jones.py`, following the paper's Section 2, Fig. 3 and Table 1):

1. **Motor**: every agent tries to step `SS` pixels forward. If the target cell is free it moves and
   deposits `depT` into the trail map; otherwise it stays, deposits nothing and takes a random new heading.
2. **Sense and rotate**: three sensors (forward, front-left, front-right at +/-`SA`) sample the trail map
   `SO` pixels ahead. Jones's rule: if F > FL and F > FR keep heading; if F < FL and F < FR rotate randomly
   left or right by `RA`; else rotate by `RA` toward the stronger side.
3. **Stimuli**: station pixels are projected into the trail map each step (`stimulus value x wProj`).
4. **Diffuse and decay**: `diffK x diffK` mean filter, then multiply by `(1 - decayT)`.

Stochasticity comes from random initial positions and headings, random headings after blocked moves,
random choice on the F < FL, FR rule, random conflict winners and optional `pCD`.

### Parameters, defaults, and where they are uncertain

| Param | Default | Source / note |
|---|---|---|
| SA, RA | 45, 45 deg | Table 1 lists SA 22.5 or 45, RA 45. **45/45 is chosen deliberately**: the paper shows it yields the stable, minimising networks (Figs 5, 19); 22.5 never settles ("dynamic remodelling"). |
| SO | 9 px | Table 1. Scales network coarseness (Fig 10). Relative to your raster, not to metres. |
| depT | 5 | Table 1. |
| decayT | 0.1 | Table 1. **Interpretation**: `trail *= (1 - decayT)` after diffusion. The paper does not give the formula; Fig 12's trend (higher decay = weaker gradient) is consistent with this. |
| diffK | 3 | Table 1. |
| %p | 2 | Table 1 gives 3-15 for free patterning; Fig 19 uses 2 for stimulus-guided networks. |
| wProj | 0.05 | Table 1: 0.01-0.1. **Assumption**: stimulus pixel grey level 255 (editable under Advanced), so a station adds `255 x wProj` per step. The paper does not state the grey level, so the numeric scale of wProj is not guaranteed to match the original implementation. |
| Boundary | non-periodic | Table 1 default is periodic. Off here so geography does not wrap around. Switchable. |
| SW, sMin | 1, 0 | Fixed as in Table 1. |
| Raster / iterations | 200 px, 4000 | **Not from the paper.** Chosen empirically on a 6-station synthetic city and the Chennai example. Fewer steps leave networks incomplete (tested: 2500 steps at 160 px left stations unlinked). |

Nothing here has been fitted to real Chennai Metro data. The defaults are a sensible starting point,
not validated values for your study; sweep them before drawing conclusions.

## Network extraction (`extract_graph`)

Transparent heuristic, run on the trail field averaged over the last N steps (N = 50 by default; set 1
for the final field only):

1. Threshold: `field > threshold x (99th percentile of the field)`.
2. Drop connected specks under 4 px.
3. Skeletonise the trail regions (scikit-image) to 1-pixel centre-lines.
4. Remove a catchment disc (3 px) around every station.
5. Label the remaining skeleton as corridors (8-connected).
6. A corridor touching exactly two stations is a **direct link** between them. A corridor touching three
   or more is a **shared branching corridor**: each pair on it is reported but flagged `branch_only` /
   `via_branch`. Tab C can hide these.
7. The skeleton path length for each pair is recorded (`mean_trail_path_km`).

**Consensus**: `edge frequency = runs containing the edge / successful runs`. Failed or interrupted runs
are never in the denominator. The threshold test is integer-exact (0.7 of 10 runs means >= 7).

The *shown* link is a straight line between the two stations (this is what "edge" means in the CSV and
GeoJSON). The mould's actual trail path is available as an overlay (skeleton) and as a length column.
A minimum spanning tree can be drawn as a **separate, labelled baseline**; it is never mixed into the
simulation output.

## Exports

* `stations.csv`: station_id, station_name, latitude, longitude, interchange_flag
* `edges.csv`: source/target ID, name and coordinates, haversine `length_km`, `runs_with_edge`,
  `successful_runs`, `edge_frequency`, `meets_threshold`, `branch_only`, `mean_trail_path_km`
* `network.geojson`: Point and LineString features (EPSG:4326, lon/lat order) with endpoint IDs, length,
  frequency; every link carries `status: "conceptual candidate alignment"`. Opens in QGIS.
* `reproducibility.json`: all parameters, extraction settings, per-run seeds and seed rule, grid geometry
* `run_log.csv`: seed, status, seconds, agents, edges found per run (failures included)
* Project ZIP: `project.json` plus `fields.npz` (final and averaged trail arrays per run)

Stations CSV for import: `name` plus latitude/longitude required (aliases `lat`/`latitude`,
`lon`/`lng`/`longitude`); `id` and `interchange` optional. See `example_stations_chennai.csv`. The
example coordinates are **approximate and illustrative**, and `example_connections_chennai.csv` is a
rough sketch of existing links; verify both before using them in a paper.

## Tests (`python tests.py`)

16 tests: coordinate/duplicate/missing/malformed-CSV validation, grid round-trip, simulation determinism
and different-seed divergence, no two agents ever sharing a cell, periodic boundary, multi-run graph
validity, extraction on a hand-built field with a known answer, **consensus frequencies on a deterministic
example** (including failed runs being excluded and the 7/10 vs 0.7 boundary), CSV/GeoJSON contents,
metrics, and project save/load. The UI was also driven headlessly with Streamlit's `AppTest`: load
example, run, interrupt detection, project restore.

## Status

**The Jones-style simulation ran successfully** in testing. On the Chennai example (10 stations,
195 x 200 raster at about 82 m per pixel, 780 agents, 4000 steps, 10 independent seeds): 10/10 runs
succeeded, about 3.9 s each; 9 links appeared in >= 90% of runs and joined all 10 stations.
Observation, not a validation: that stable network had the same total length as the straight-line MST
(25.602 km), consistent with the paper's report that strongly weighted stimuli tighten the network toward an
MST (Fig 20). Lower `wProj` for looser, Steiner-like networks.

## Completed

Everything in the brief's priority list 1-7: Jones simulation, click/manual/CSV stations with validation
and editing, all listed parameters, multi-run consensus with frequency threshold, individual-run /
consensus / uncertain / existing / MST-baseline layers, CSV + GeoJSON + project exports, save/load,
and the optional metrics (mean shortest path, components, bridge fraction).

## Known limitations

* **Vectorised conflict resolution** differs from Jones's sequential random-order update: an agent cannot
  follow into a cell vacated earlier in the same step. This changes fine dynamics, not the qualitative
  behaviour. It has not been benchmarked against the original code.
* **No road or terrain constraints.** The raster is empty space (equirectangular, fine at city scale), so
  paths ignore roads, rivers and land use. Obstacles would be a straightforward extension (paper Section 2).
* **Extraction is a heuristic, not validated.** Results depend on the threshold, catchment radius and
  averaging window. Shared branching corridors produce station-pair edges that do not each correspond to a
  separate physical link (a Y-junction of three stations yields three pairs). Use the *branch_only* flag.
  Trail spurs that run to the raster edge are ignored but visible in the skeleton overlay.
* **Stimulus scale (wProj) and decayT interpretation** are assumptions (table above).
* **Straight-line edges.** Lengths are haversine distances between stations, not route lengths.
  `mean_trail_path_km` is the skeleton length at raster resolution, an approximation.
* **Optional metrics** (mean shortest path, bridge fraction) are descriptive on straight-line lengths and
  are not validated planning measures. The MST figure is a separate baseline.
* **Demand is uniform**; no ridership, cost or travel-time model.
* **Speed**: single-threaded NumPy. Roughly 1 ms per step at 1,300 agents. The pre-run time estimate is
  conservative and indicative only.
* **Stop** works by interrupting at the next progress update (about every 1% of a run); an in-flight run
  is discarded, finished runs are kept.
* Reproducibility holds for the same seed and the same NumPy version.
* Not implemented: the paper's plasmodial-shrinkage (Section 4.2), damage/repair experiments, the
  chemorepulsion mode.

## Files

| File | Purpose |
|---|---|
| `app.py` | Streamlit dashboard (4 tabs) |
| `jones.py` | Jones model, raster/geo transform, network extraction |
| `core.py` | Validation, CSV import, consensus, exports, metrics, project bundle |
| `tests.py` | Test suite |
| `example_stations_chennai.csv`, `example_connections_chennai.csv` | Illustrative example data |
| `requirements.txt` | Dependencies |


## Coimbatore Metro:
