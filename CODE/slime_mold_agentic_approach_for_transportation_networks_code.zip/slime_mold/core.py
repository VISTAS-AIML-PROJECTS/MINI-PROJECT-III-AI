"""
core.py - everything that is not the simulation and not the UI:
station validation / CSV import, consensus network, exports, project bundle, metrics.
"""

from __future__ import annotations

import io
import json
import math
import zipfile
from datetime import datetime, timezone

import numpy as np
import pandas as pd

APP_VERSION = "0.2"
SCHEMA = 1
STATION_COLS = ["id", "name", "lat", "lng", "interchange"]
NOTE = ("Conceptual candidate connection between two stations, derived from a stochastic "
        "Jones-style slime-mould simulation. A straight line between stations; not a surveyed "
        "or engineered alignment.")


# ----------------------------------------------------------------------------
# geometry
# ----------------------------------------------------------------------------
def haversine_km(lat1, lng1, lat2, lng2):
    R = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(min(1.0, math.sqrt(a)))


# ----------------------------------------------------------------------------
# stations
# ----------------------------------------------------------------------------
def empty_stations():
    return pd.DataFrame({"id": pd.Series(dtype=str), "name": pd.Series(dtype=str),
                         "lat": pd.Series(dtype=float), "lng": pd.Series(dtype=float),
                         "interchange": pd.Series(dtype=bool)})


def next_id(existing):
    used = set(map(str, existing))
    i = 1
    while f"S{i}" in used:
        i += 1
    return f"S{i}"


def _truthy(v):
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "y", "t")
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return False
    return bool(v)


def validate_stations(df):
    """
    Returns (clean_df | None, errors, warnings).
    clean_df is None when there are errors; blank IDs are auto-assigned, blank names
    default to the ID. Optional 'weight' column is preserved if present.
    """
    errors, warnings = [], []
    if df is None or len(df) == 0:
        return empty_stations(), errors, warnings
    d = df.copy()
    has_weight = "weight" in d.columns
    for col in STATION_COLS:
        if col not in d.columns:
            d[col] = np.nan if col in ("lat", "lng") else ("" if col != "interchange" else False)
    keep_cols = STATION_COLS + (["weight"] if has_weight else [])
    d = d[keep_cols]
    d = d[~(d["id"].isna() & d["name"].isna() & d["lat"].isna() & d["lng"].isna())].reset_index(drop=True)

    d["lat"] = pd.to_numeric(d["lat"], errors="coerce")
    d["lng"] = pd.to_numeric(d["lng"], errors="coerce")
    for i, row in d.iterrows():
        label = f"Row {i + 1}"
        if pd.isna(row["lat"]) or pd.isna(row["lng"]):
            errors.append(f"{label}: latitude and longitude must both be numbers.")
            continue
        if not -90 <= row["lat"] <= 90:
            errors.append(f"{label}: latitude {row['lat']} is outside -90..90.")
        if not -180 <= row["lng"] <= 180:
            errors.append(f"{label}: longitude {row['lng']} is outside -180..180.")

    ids = d["id"].fillna("").astype(str).str.strip()
    names = d["name"].fillna("").astype(str).str.strip()
    taken = {x for x in ids if x}
    new_ids = []
    for x in ids:
        if x:
            new_ids.append(x)
        else:
            nid = next_id(taken)
            taken.add(nid)
            new_ids.append(nid)
    d["id"] = new_ids
    dup = d["id"][d["id"].duplicated(keep=False)].unique()
    for x in dup:
        errors.append(f"Duplicate station ID '{x}'. IDs must be unique.")
    d["name"] = [n if n else i for n, i in zip(names, d["id"])]
    d["interchange"] = d["interchange"].map(_truthy)
    if has_weight:
        d["weight"] = pd.to_numeric(d["weight"], errors="coerce").fillna(1.0).clip(0.1, 10.0)

    if not errors:
        c = d.round({"lat": 6, "lng": 6})
        same = c[c.duplicated(["lat", "lng"], keep=False)]
        if len(same):
            warnings.append("Some stations share identical coordinates: "
                            + ", ".join(same["id"]) + ". They will merge on the raster.")
    return (None if errors else d.reset_index(drop=True)), errors, warnings


_ALIASES = {
    "id": ["id", "station_id", "stationid", "code"],
    "name": ["name", "station", "station_name", "stationname", "label"],
    "lat": ["lat", "latitude", "y"],
    "lng": ["lng", "lon", "long", "longitude", "x"],
    "interchange": ["interchange", "is_interchange", "transfer"],
    "weight": ["weight", "demand", "pop_weight", "importance"],
}


def parse_stations_csv(file_or_bytes):
    """Parse an uploaded CSV. Returns (df | None, errors, warnings)."""
    try:
        raw = file_or_bytes.read() if hasattr(file_or_bytes, "read") else file_or_bytes
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8-sig")
        df = pd.read_csv(io.StringIO(raw))
    except Exception as exc:
        return None, [f"Could not read the CSV file ({type(exc).__name__}: {exc})."], []
    if df.empty:
        return None, ["The CSV file has no rows."], []
    lower = {c.strip().lower(): c for c in df.columns}
    rename = {}
    for std, opts in _ALIASES.items():
        for o in opts:
            if o in lower:
                rename[lower[o]] = std
                break
    df = df.rename(columns=rename)
    missing = [c for c in ("lat", "lng") if c not in df.columns]
    if missing:
        return None, [f"Missing column(s): {', '.join(missing)}. Found: {', '.join(map(str, df.columns))}. "
                      "Expected a name column plus latitude/longitude (aliases lat/latitude, lon/lng/longitude)."], []
    if "name" not in df.columns and "id" not in df.columns:
        return None, ["The CSV needs a 'name' (or 'id') column."], []
    return validate_stations(df)


def parse_edges_csv(file_or_bytes, station_ids):
    """Existing connections CSV with columns source_id,target_id (and optional line). Returns (df, errors)."""
    try:
        raw = file_or_bytes.read() if hasattr(file_or_bytes, "read") else file_or_bytes
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8-sig")
        df = pd.read_csv(io.StringIO(raw), dtype=str)
    except Exception as exc:
        return None, [f"Could not read connections CSV ({exc})."]
    lower = {c.strip().lower(): c for c in df.columns}
    s = next((lower[k] for k in ("source_id", "source", "from", "a") if k in lower), None)
    t = next((lower[k] for k in ("target_id", "target", "to", "b") if k in lower), None)
    lcol = next((lower[k] for k in ("line", "corridor", "route") if k in lower), None)
    if not s or not t:
        return None, ["Connections CSV needs source_id and target_id columns."]
    cols = [s, t] + ([lcol] if lcol else [])
    out = df[cols].rename(columns={s: "source_id", t: "target_id", **({lcol: "line"} if lcol else {})}).dropna(subset=["source_id", "target_id"])
    bad = out[~out["source_id"].isin(station_ids) | ~out["target_id"].isin(station_ids)]
    if len(bad):
        return None, [f"{len(bad)} connection(s) reference unknown station IDs, e.g. "
                      f"{bad.iloc[0]['source_id']} -> {bad.iloc[0]['target_id']}."]
    return out.reset_index(drop=True), []


# ----------------------------------------------------------------------------
# consensus
# ----------------------------------------------------------------------------
def meets(count, total, threshold):
    """count/total >= threshold, robust to floating point (0.7 of 10 runs -> 7)."""
    return total > 0 and count >= math.ceil(threshold * total - 1e-9)


def consensus_edges(runs, stations, threshold, exclude_branch_only=False):
    """
    Edge frequency = runs containing the edge / total SUCCESSFUL runs.
    """
    ok = [r for r in runs if r.get("status") == "ok"]
    total = len(ok)
    cols = ["source_id", "source_name", "target_id", "target_name",
            "source_lat", "source_lng", "target_lat", "target_lng", "length_km",
            "runs_with_edge", "successful_runs", "edge_frequency", "meets_threshold",
            "branch_only", "mean_trail_path_km"]
    if total == 0:
        return pd.DataFrame(columns=cols)
    st = stations.set_index("id")
    order = {sid: i for i, sid in enumerate(stations["id"])}
    cnt, br, paths = {}, {}, {}
    for r in ok:
        seen = set()
        for e in r["edges"]:
            a, b = sorted((e["a"], e["b"]), key=lambda s: order.get(s, 1e9))
            if (a, b) in seen:
                continue
            seen.add((a, b))
            cnt[(a, b)] = cnt.get((a, b), 0) + 1
            br[(a, b)] = br.get((a, b), 0) + (1 if e.get("via_branch") else 0)
            if e.get("path_km") is not None:
                paths.setdefault((a, b), []).append(e["path_km"])
    rows = []
    for (a, b), c in cnt.items():
        if a not in st.index or b not in st.index:
            continue
        sa, sb = st.loc[a], st.loc[b]
        branch_only = br[(a, b)] == c
        if exclude_branch_only and branch_only:
            continue
        rows.append({
            "source_id": a, "source_name": sa["name"], "target_id": b, "target_name": sb["name"],
            "source_lat": sa["lat"], "source_lng": sa["lng"], "target_lat": sb["lat"], "target_lng": sb["lng"],
            "length_km": round(haversine_km(sa["lat"], sa["lng"], sb["lat"], sb["lng"]), 4),
            "runs_with_edge": c, "successful_runs": total,
            "edge_frequency": round(c / total, 4),
            "meets_threshold": meets(c, total, threshold),
            "branch_only": branch_only,
            "mean_trail_path_km": round(float(np.mean(paths[(a, b)])), 4) if (a, b) in paths else None,
        })
    df = pd.DataFrame(rows, columns=cols)
    return df.sort_values(["edge_frequency", "source_id"], ascending=[False, True]).reset_index(drop=True)


# ----------------------------------------------------------------------------
# exports
# ----------------------------------------------------------------------------
def stations_csv(stations):
    base_cols = [c for c in STATION_COLS if c in stations.columns]
    out = stations[base_cols].rename(columns={"id": "station_id", "name": "station_name",
                                              "lat": "latitude", "lng": "longitude",
                                              "interchange": "interchange_flag"})
    return out.to_csv(index=False)


def edges_csv(edges):
    return edges.to_csv(index=False)


def to_geojson(stations, edges, include_uncertain=True):
    feats = []
    for _, s in stations.iterrows():
        feats.append({"type": "Feature",
                      "geometry": {"type": "Point", "coordinates": [float(s["lng"]), float(s["lat"])]},
                      "properties": {"feature_type": "station", "station_id": s["id"],
                                     "name": s["name"], "interchange": bool(s["interchange"])}})
    for _, e in edges.iterrows():
        if not include_uncertain and not e["meets_threshold"]:
            continue
        feats.append({"type": "Feature",
                      "geometry": {"type": "LineString",
                                   "coordinates": [[float(e["source_lng"]), float(e["source_lat"])],
                                                   [float(e["target_lng"]), float(e["target_lat"])]]},
                      "properties": {"feature_type": "candidate_link", "source_id": e["source_id"],
                                     "target_id": e["target_id"], "length_km": float(e["length_km"]),
                                     "edge_frequency": float(e["edge_frequency"]),
                                     "runs_with_edge": int(e["runs_with_edge"]),
                                     "successful_runs": int(e["successful_runs"]),
                                     "meets_threshold": bool(e["meets_threshold"]),
                                     "status": "conceptual candidate alignment", "note": NOTE}})
    return json.dumps({"type": "FeatureCollection", "name": "slime_mould_candidate_network",
                       "crs_note": "WGS84 (EPSG:4326), coordinates are [longitude, latitude]",
                       "features": feats}, indent=1)


# ----------------------------------------------------------------------------
# metrics (optional, clearly approximate)
# ----------------------------------------------------------------------------
def build_graph(stations, edges):
    import networkx as nx
    G = nx.Graph()
    for _, s in stations.iterrows():
        G.add_node(s["id"])
    for _, e in edges.iterrows():
        G.add_edge(e["source_id"], e["target_id"], weight=float(e["length_km"]))
    return G


def mst_baseline_km(stations):
    import networkx as nx
    G = nx.Graph()
    rows = stations.to_dict("records")
    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            G.add_edge(rows[i]["id"], rows[j]["id"],
                       weight=haversine_km(rows[i]["lat"], rows[i]["lng"], rows[j]["lat"], rows[j]["lng"]))
    if G.number_of_nodes() < 2:
        return 0.0
    return float(sum(d["weight"] for _, _, d in nx.minimum_spanning_edges(G, data=True)))


def summary_metrics(stations, all_edges, threshold, runs, with_graph_metrics=True):
    import networkx as nx
    ok = [r for r in runs if r.get("status") == "ok"]
    stable = all_edges[all_edges["meets_threshold"]] if len(all_edges) else all_edges
    m = {
        "stations": int(len(stations)),
        "successful_runs": len(ok),
        "failed_or_interrupted_runs": len(runs) - len(ok),
        "candidate_edges_seen": int(len(all_edges)),
        "stable_edges": int(len(stable)),
        "unstable_edges": int(len(all_edges) - len(stable)),
        "total_stable_length_km": round(float(stable["length_km"].sum()), 3) if len(stable) else 0.0,
        "consensus_threshold": threshold,
    }
    if len(all_edges):
        bins = [0, .2, .4, .6, .8, 1.0001]
        labels = ["0-0.2", "0.2-0.4", "0.4-0.6", "0.6-0.8", "0.8-1.0"]
        m["frequency_distribution"] = pd.cut(all_edges["edge_frequency"], bins=bins, labels=labels,
                                             right=False).value_counts().reindex(labels).fillna(0).astype(int).to_dict()
    else:
        m["frequency_distribution"] = {}
    if with_graph_metrics and len(stations) >= 2:
        G = build_graph(stations, stable) if len(stable) else build_graph(stations, all_edges.iloc[0:0])
        comps = list(nx.connected_components(G))
        m["connected_components"] = len(comps)
        big = G.subgraph(max(comps, key=len)).copy()
        m["largest_component_stations"] = big.number_of_nodes()
        mst_km = mst_baseline_km(stations)
        m["mst_baseline_km_separate"] = round(mst_km, 3)
        if big.number_of_nodes() >= 2:
            md_km = float(nx.average_shortest_path_length(big, weight="weight"))
            m["mean_shortest_path_km_largest_component"] = round(md_km, 3)
            bridges = list(nx.bridges(big))
            m["bridge_edges_in_largest_component"] = len(bridges)
            ft_frac = len(bridges) / big.number_of_edges() if big.number_of_edges() else None
            m["single_link_removal_disconnects_fraction"] = round(ft_frac, 3) if ft_frac is not None else None
            if mst_km > 0:
                m["TL_over_TL_MST"] = round(m["total_stable_length_km"] / mst_km, 3)
        m["_caveat"] = ("Graph metrics use straight-line station-to-station lengths on the stable "
                        "consensus edges. They are descriptive approximations, not validated "
                        "transport-planning measures.")
    return m


# ----------------------------------------------------------------------------
# project bundle (ZIP: project.json + fields.npz)
# ----------------------------------------------------------------------------
def build_project_zip(project: dict, arrays: dict | None) -> bytes:
    project = dict(project)
    project["schema_version"] = SCHEMA
    project["app_version"] = APP_VERSION
    project["saved_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("project.json", json.dumps(project, indent=1, default=_json_default))
        if arrays:
            nb = io.BytesIO()
            np.savez_compressed(nb, **arrays)
            z.writestr("fields.npz", nb.getvalue())
    return buf.getvalue()


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    raise TypeError(f"not JSON serialisable: {type(o)}")


def load_project(data: bytes):
    """Returns (project dict, arrays dict, errors)."""
    try:
        if data[:2] == b"PK":
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                proj = json.loads(z.read("project.json"))
                arrays = {}
                if "fields.npz" in z.namelist():
                    with np.load(io.BytesIO(z.read("fields.npz"))) as npz:
                        arrays = {k: npz[k] for k in npz.files}
        else:
            proj, arrays = json.loads(data.decode("utf-8")), {}
    except Exception as exc:
        return None, {}, [f"Could not read project file ({type(exc).__name__}: {exc})."]
    if not isinstance(proj, dict) or "stations" not in proj or "config" not in proj:
        return None, {}, ["This does not look like a project file saved by this app."]
    if proj.get("schema_version", 0) > SCHEMA:
        return None, {}, ["Project was saved by a newer version of the app."]
    return proj, arrays, []
