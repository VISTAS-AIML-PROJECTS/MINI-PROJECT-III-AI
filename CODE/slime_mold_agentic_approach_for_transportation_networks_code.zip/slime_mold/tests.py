"""
tests.py - run with:  python tests.py     (no pytest needed)
Covers: validation, CSV import, simulation, multi-run graphs, consensus frequencies,
exports, and project save/load.
"""
import io, json, traceback
import numpy as np, pandas as pd
import core
from jones import (JonesParams, ExtractParams, make_grid, simulate, extract_graph, stimulus_layer)

PASSED, FAILED = [], []

def test(fn):
    try:
        fn(); PASSED.append(fn.__name__); print(f"PASS  {fn.__name__}")
    except Exception:
        FAILED.append(fn.__name__); print(f"FAIL  {fn.__name__}"); traceback.print_exc()
    return fn

# a small synthetic city: 6 stations
LAT = np.array([11.341, 11.352, 11.330, 11.318, 11.345, 11.336])
LNG = np.array([77.717, 77.735, 77.745, 77.722, 77.700, 77.727])
def stations():
    return pd.DataFrame({"id": [f"S{i+1}" for i in range(6)], "name": [f"Stop {i+1}" for i in range(6)],
                         "lat": LAT, "lng": LNG, "interchange": [False]*5 + [True]})

@test
def validation_rejects_bad_coordinates():
    df = pd.DataFrame({"id": ["a", "b"], "name": ["A", "B"], "lat": [95, 10], "lng": [20, 200], "interchange": [False, False]})
    clean, errs, _ = core.validate_stations(df)
    assert clean is None and len(errs) == 2, errs

@test
def validation_rejects_duplicate_ids_and_missing_values():
    df = pd.DataFrame({"id": ["a", "a", "c"], "name": ["A", "B", "C"], "lat": [1, 2, None], "lng": [1, 2, 3], "interchange": [0, 0, 0]})
    clean, errs, _ = core.validate_stations(df)
    assert clean is None
    assert any("Duplicate" in e for e in errs) and any("numbers" in e for e in errs), errs

@test
def validation_autofills_ids_and_names():
    df = pd.DataFrame({"id": ["", "S1"], "name": ["", "x"], "lat": [1.0, 2.0], "lng": [1.0, 2.0], "interchange": [False, True]})
    clean, errs, _ = core.validate_stations(df)
    assert not errs and clean["id"].is_unique and clean.loc[0, "name"] == clean.loc[0, "id"]

@test
def csv_import_with_aliases_and_errors():
    good = b"Station,Latitude,Longitude\nA,13.0,80.0\nB,13.1,80.1\n"
    df, errs, _ = core.parse_stations_csv(good)
    assert df is not None and len(df) == 2 and not errs
    assert core.parse_stations_csv(b"name,foo\nA,1\n")[0] is None          # missing lat/lng
    assert core.parse_stations_csv(b"")[0] is None                          # empty
    assert core.parse_stations_csv(b"name,lat,lng\nA,abc,80\n")[0] is None # malformed number
    assert core.parse_stations_csv(b"\x00\x01\x02garbage")[0] is None       # not a CSV
    ex, errs, _ = core.parse_stations_csv(open("example_stations_chennai.csv", "rb").read())
    assert ex is not None and len(ex) == 10 and ex["interchange"].sum() == 2

@test
def grid_roundtrip():
    g = make_grid(LAT, LNG, 200)
    c, r = g.latlng_to_px(LAT, LNG)
    lat2, lng2 = g.px_to_latlng(c, r)
    assert np.allclose(lat2, LAT, atol=1e-9) and np.allclose(lng2, LNG, atol=1e-9)
    assert 0 < c.min() and c.max() < g.W and 0 < r.min() and r.max() < g.H

@test
def jones_sim_is_deterministic_and_nontrivial():
    g = make_grid(LAT, LNG, 120); c, r = g.latlng_to_px(LAT, LNG); px = list(zip(c, r))
    p = JonesParams()
    a = simulate((g.H, g.W), px, p, 300, seed=5)
    b = simulate((g.H, g.W), px, p, 300, seed=5)
    d = simulate((g.H, g.W), px, p, 300, seed=6)
    assert np.array_equal(a["final"], b["final"]), "same seed must reproduce"
    assert not np.array_equal(a["final"], d["final"]), "different seed must differ"
    assert np.isfinite(a["final"]).all() and a["final"].max() > 0 and a["final"].min() >= 0
    assert a["n_agents"] == round(g.H * g.W * p.pct_p / 100)

@test
def jones_agents_never_share_cells_and_stay_in_bounds():
    g = make_grid(LAT, LNG, 80); c, r = g.latlng_to_px(LAT, LNG)
    res = simulate((g.H, g.W), list(zip(c, r)), JonesParams(pct_p=10), 200, seed=1)
    xy = np.rint(res["agents_xy"]).astype(int)
    assert xy[:, 0].min() >= 0 and xy[:, 0].max() < g.W and xy[:, 1].min() >= 0 and xy[:, 1].max() < g.H
    assert len({(x, y) for x, y in xy}) == len(xy), "two agents share a cell"

@test
def jones_periodic_boundary_runs():
    g = make_grid(LAT, LNG, 80); c, r = g.latlng_to_px(LAT, LNG)
    res = simulate((g.H, g.W), list(zip(c, r)), JonesParams(periodic=True), 100, seed=2)
    assert np.isfinite(res["final"]).all()

@test
def stimulus_layer_marks_stations():
    g = make_grid(LAT, LNG, 100); c, r = g.latlng_to_px(LAT, LNG)
    stim, mask = stimulus_layer((g.H, g.W), list(zip(c, r)), JonesParams(wProj=0.1))
    assert mask.sum() >= 6 and abs(stim.max() - 25.5) < 1e-3

@test
def multi_run_produces_valid_graphs():
    # app default configuration (res 200, 4000 steps). Shorter runs leave the network incomplete.
    g = make_grid(LAT, LNG, 200); c, r = g.latlng_to_px(LAT, LNG); px = list(zip(c, r))
    found = []
    for seed in (11, 12, 13):
        res = simulate((g.H, g.W), px, JonesParams(), 4000, seed, avg_window=50)
        ex = extract_graph(res["avg"], px, ExtractParams())
        for e in ex["edges"]:
            assert 0 <= e["a"] < e["b"] < 6 and e["path_px"] > 0
        assert len({(e["a"], e["b"]) for e in ex["edges"]}) == len(ex["edges"]), "duplicate pair"
        found.append(len(ex["edges"]))
    assert min(found) >= 5, f"mould failed to connect all 6 stations (a tree needs >=5 edges): {found}"

@test
def extraction_on_synthetic_field_is_exact():
    # two blobs joined by a line; a third blob isolated -> exactly one edge
    f = np.zeros((60, 100), np.float32)
    f[30, 10:60] = 10.0
    px = [(10, 30), (59, 30), (85, 10)]
    for c, r in px: f[max(r-1,0):r+2, max(c-1,0):c+2] = 10.0
    ex = extract_graph(f, px, ExtractParams(threshold=0.5, ref_percentile=99, catch_radius_px=3))
    assert [(e["a"], e["b"]) for e in ex["edges"]] == [(0, 1)], ex["edges"]
    assert 40 < ex["edges"][0]["path_px"] < 55 and not ex["edges"][0]["via_branch"]

@test
def consensus_frequencies_deterministic():
    stn = stations()
    mk = lambda *pairs: {"status": "ok", "edges": [{"a": a, "b": b, "via_branch": False, "path_km": 1.0} for a, b in pairs]}
    runs = [mk(("S1", "S2"), ("S2", "S3")), mk(("S1", "S2")), mk(("S2", "S1")), mk(("S1", "S2"), ("S3", "S4")),
            {"status": "failed", "error": "boom", "edges": [{"a": "S1", "b": "S6", "via_branch": False}]}]
    e = core.consensus_edges(runs, stn, 0.7).set_index(["source_id", "target_id"])
    assert e.loc[("S1", "S2"), "edge_frequency"] == 1.0          # 4 of 4 (direction-insensitive)
    assert e.loc[("S2", "S3"), "edge_frequency"] == 0.25
    assert ("S1", "S6") not in e.index, "failed run must not count"
    assert e["successful_runs"].iloc[0] == 4
    assert e.loc[("S1", "S2"), "meets_threshold"] and not e.loc[("S2", "S3"), "meets_threshold"]
    # threshold boundary: 7 of 10 runs vs 0.7
    runs10 = [mk(("S1", "S2")) if i < 7 else mk() for i in range(10)]
    assert core.consensus_edges(runs10, stn, 0.7).iloc[0]["meets_threshold"]
    assert not core.consensus_edges(runs10, stn, 0.71).iloc[0]["meets_threshold"]
    assert len(core.consensus_edges([{"status": "failed", "edges": []}], stn, 0.5)) == 0

@test
def branch_only_filter():
    stn = stations()
    runs = [{"status": "ok", "edges": [{"a": "S1", "b": "S2", "via_branch": True, "path_km": 1}]}] * 2
    assert len(core.consensus_edges(runs, stn, 0.5)) == 1
    assert len(core.consensus_edges(runs, stn, 0.5, exclude_branch_only=True)) == 0

@test
def exports_csv_geojson():
    stn = stations()
    runs = [{"status": "ok", "edges": [{"a": "S1", "b": "S2", "via_branch": False, "path_km": 2.0}]}] * 3
    e = core.consensus_edges(runs, stn, 0.7)
    assert abs(e.iloc[0]["length_km"] - core.haversine_km(LAT[0], LNG[0], LAT[1], LNG[1])) < 1e-3
    assert 1.5 < core.haversine_km(0, 0, 0, 0.0179) < 2.1                       # ~1.99 km
    ecsv = pd.read_csv(io.StringIO(core.edges_csv(e)))
    for col in ["source_id", "source_name", "target_id", "target_name", "source_lat", "target_lng",
                "length_km", "runs_with_edge", "edge_frequency", "meets_threshold"]:
        assert col in ecsv.columns, col
    scsv = pd.read_csv(io.StringIO(core.stations_csv(stn)))
    assert list(scsv.columns) == ["station_id", "station_name", "latitude", "longitude", "interchange_flag"]
    gj = json.loads(core.to_geojson(stn, e))
    kinds = [f["geometry"]["type"] for f in gj["features"]]
    assert kinds.count("Point") == 6 and kinds.count("LineString") == 1
    line = [f for f in gj["features"] if f["geometry"]["type"] == "LineString"][0]
    assert line["properties"]["edge_frequency"] == 1.0 and "conceptual" in line["properties"]["status"]
    assert line["geometry"]["coordinates"][0] == [LNG[0], LAT[0]]               # lon, lat order

@test
def metrics_run():
    stn = stations()
    runs = [{"status": "ok", "edges": [{"a": a, "b": b, "via_branch": False} for a, b in
            [("S1", "S2"), ("S2", "S3"), ("S3", "S4"), ("S4", "S5"), ("S5", "S6")]]}] * 4
    e = core.consensus_edges(runs, stn, 0.7)
    m = core.summary_metrics(stn, e, 0.7, runs)
    assert m["stable_edges"] == 5 and m["connected_components"] == 1
    assert m["bridge_edges_in_largest_component"] == 5          # a chain: every link is a bridge
    assert m["mst_baseline_km_separate"] > 0

@test
def project_roundtrip():
    stn = stations()
    proj = {"name": "t", "stations": stn.to_dict("records"), "config": {"cfg_SA": 45.0}, "existing_edges": [],
            "results": {"runs": [{"seed": 1}]}}
    arrays = {"avg_0": np.random.rand(10, 12).astype(np.float32), "final_0": np.random.rand(10, 12).astype(np.float32)}
    z = core.build_project_zip(proj, arrays)
    p, arr, errs = core.load_project(z)
    assert not errs and p["name"] == "t" and len(p["stations"]) == 6 and p["schema_version"] == core.SCHEMA
    assert np.array_equal(arr["avg_0"], arrays["avg_0"])
    p2, a2, e2 = core.load_project(json.dumps(proj).encode())      # plain JSON works too
    assert p2 is not None and a2 == {}
    assert core.load_project(b"not a project")[0] is None
    assert core.load_project(json.dumps({"hello": 1}).encode())[0] is None

if __name__ == "__main__":
    print(f"\n{len(PASSED)} passed, {len(FAILED)} failed")
    raise SystemExit(1 if FAILED else 0)
