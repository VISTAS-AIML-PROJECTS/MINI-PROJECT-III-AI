# AEGIS-CMS — Crowd Management & Security System (Web Version)

A browser-based security control-room dashboard: live per-phase camera
feeds, YOLOv8 head counting, fire/smoke detection, QR-free VIP facial
recognition, and a Predictive Bottleneck Solver that forecasts crowd
build-up 5 minutes ahead — all served from a local Flask app.

This is a rebuild of the earlier Tkinter desktop version, moved to a web
UI, plus three fixes that came out of testing the first version:

1. **Test-video upload** — every camera panel now has a "Use test video"
   control, so you can demo the system with a downloaded/recorded clip
   instead of needing a live camera.
2. **Fewer false fire/smoke alarms** — glare/reflections were being read
   as smoke, and red/orange walls as fire. Both are fixed in
   `core/fire_smoke_detector.py` (details below).
3. **VIP registration fixed** — the upload path is now a proper web form
   with server-side validation, EXIF-rotation handling, and clear error
   messages instead of failing silently.

---

## 1. Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

**`dlib` install issues (Windows):** run `pip install cmake` first, then
`pip install dlib`. If it still fails, download a prebuilt `dlib` wheel
matching your Python version/OS and `pip install that_file.whl`.

First run needs internet once so `ultralytics` can download `yolov8n.pt`
(~6MB) — after that it's cached and works offline.

## 2. Run

```bash
python app.py
```

Open **http://127.0.0.1:5000** in your browser. Feeds intentionally start
unassigned so the same physical webcam is not silently duplicated into all
four zones. In each panel, open **Camera source**, choose the laptop camera,
USB/external camera, Camera 2, or Camera 3, and click **Use selected camera**.
Each panel keeps its own selection. You can instead assign a different test
video to each panel.

---

## 2.1 Testing with a video instead of a live camera

Every camera panel on the dashboard has a **"Camera source"** dropdown
with:
- **Use webcam** — enter a device index (`0`, `1`, ...) and click.
- **Use test video** — choose an `.mp4` / `.avi` / `.mov` / `.mkv` file
  from your computer and click. The file is uploaded to the server,
  saved under `uploads/test_videos/`, and that zone immediately switches
  to it. The video **loops automatically** so it can run through an
  entire demo/presentation without restarting.

Good demo clips to prepare in advance:
- A short clip of a crowded area (for the overcrowding + headcount demo).
- A short clip of a real flame or smoke (candle, controlled campfire
  footage, etc. — filmed safely, not live in the room) for the fire/smoke
  demo.
- A clip where crowd density visibly increases over ~30–60 seconds, to
  show the Predictive Bottleneck Solver flag it ahead of time.

---

## 3. Why the fire/smoke false positives happened, and what changed

A plain colour threshold can't tell a "red wall" from "fire" — they're
the same colour. Real fire and real smoke differ from static red objects
and glare in ways that are now explicitly checked in
`core/fire_smoke_detector.py`:

| Signal | Fire vs. a red wall | Smoke vs. glare |
|---|---|---|
| **Flicker** | Real flame's detected area visibly fluctuates frame-to-frame; a wall's doesn't. Now required: relative std-dev of area over recent frames ≥ `FIRE_FLICKER_MIN_STD_RATIO`. | — |
| **Shape** | Flame is irregular/jagged (contour fills a small % of its bounding box). A wall segment fills most of its box. Now required: `extent ≤ FIRE_MAX_EXTENT`. | Static glare patches tend to be a fairly solid blob filling their box; smoke is diffuse. Now required: `extent ≤ SMOKE_MAX_EXTENT`. |
| **Brightness ceiling** | — | Glare/reflections blow out near pure white (V≈255). The smoke colour mask now excludes anything above `SMOKE_MAX_V`, so blown-out highlights are never counted as smoke. |
| **Growth over time** | — | Smoke spreads/thickens over a few seconds; a light-fixture glare spot stays roughly the same size. Now required: the region must grow by ≥ `SMOKE_GROWTH_MIN_RATIO` and persist ≥2 seconds before an alert fires. |
| **Persistence** | A single stray frame doesn't trigger anything. | Same. |

All thresholds live at the top of `config.py` if your test footage needs
more/less sensitivity — for example, a very orange stage light might
still need `FIRE_FLICKER_MIN_STD_RATIO` raised slightly.

---

## 4. VIP registration — what was fixed

The registration endpoint (`POST /api/vip/register`) now:
- Validates the uploaded file is actually a readable image before doing
  anything else, and returns a specific error message instead of a
  generic failure.
- Auto-rotates photos taken on phones (EXIF orientation), and converts
  any image mode (RGBA, grayscale, palette) to plain RGB — both were
  silent failure points before.
- Downscales very large photos before face detection (faster + fewer
  detection failures on huge images).
- If more than one face appears in the photo, automatically picks the
  largest face rather than erroring out.
- Every registered VIP gets a unique ID (`VIP-0001`, `VIP-0002`, ...)
  which is shown back to you immediately in the form.

To register a VIP: click **"+ Register VIP"** in the VIP Tracking panel,
fill in name/tier, choose a clear front-facing photo, and submit. As soon
as that person's face appears in any camera feed, they'll be recognised
automatically — no QR code shown or scanned — and their current phase
will appear in the VIP Tracking list, updating every time they move to a
new phase.

---

## 5. Project structure

```
cms_web/
├── app.py                       # Flask app - routes, MJPEG streaming, APIs
├── config.py                    # zones, thresholds, upload settings
├── requirements.txt
├── core/
│   ├── database.py              # SQLite: VIPs, movement log, alerts, headcount history
│   ├── detection_engine.py      # YOLOv8 person detection / head count
│   ├── fire_smoke_detector.py   # false-positive-hardened fire/smoke detection
│   ├── vip_manager.py           # face registration + recognition (web-hardened)
│   ├── zone_manager.py          # per-zone overcrowding logic
│   ├── bottleneck_predictor.py  # 5-minute-ahead crowd trend prediction
│   ├── weather_module.py        # OpenWeatherMap check
│   └── stream_manager.py        # per-zone background processing threads
├── templates/index.html         # dashboard page
├── static/css/style.css         # flat/dark security-console styling
├── static/js/app.js             # polling + camera-source + VIP form logic
├── uploads/test_videos/         # uploaded demo videos land here
├── assets/vip_photos/           # stored VIP reference photos
└── data/crowd_system.db         # created on first run
```

---

## 6. Feature → code map (for your viva)

| Requested feature | Where it lives |
|---|---|
| Camera footage per phase | `core/stream_manager.py` (`_ZoneWorker`), streamed via `/video_feed/<zone_id>` in `app.py`; each panel has an independent source selector |
| Fire detection + alert | `core/fire_smoke_detector.py`, logged via `core/database.py` |
| Weather alert | `core/weather_module.py` |
| Overcrowding per phase, shows head count | `core/zone_manager.py`, rendered in the camera panel status pill |
| Area divided into phases | `ZONES` in `config.py` |
| VIP facial recognition, no QR | `core/vip_manager.py` |
| VIP database + unique ID | `vip_members` table, `core/database.py` |
| VIP phase tracking on entering a new zone | `_handle_vip_seen()` in `core/stream_manager.py`, VIP Tracking panel |
| Predictive Bottleneck Solver (5 min ahead) | `core/bottleneck_predictor.py` |
| Test-video upload | `/api/zone/<id>/source/video` in `app.py` + dashboard "Use test video" control |

---

## 7. Known limitations

- Colour-based fire/smoke detection is much more reliable than a plain
  threshold but still classical CV, not a trained model — extreme
  lighting or an unusually orange environment may still need threshold
  tuning in `config.py`.
- Person detection is performed on the native/high-resolution feed (up to
  1280px wide), rather than the old 480×360 preview. Small or fully occluded
  heads still cannot be guaranteed by a general person-detection model; use a
  clear overhead/wide camera view for the most reliable conference demo.
- Face recognition accuracy depends on lighting/angle. The tracker now
  requires two close-in-time matches before recording a VIP location, which
  prevents a one-frame false match from moving a VIP. Adjust
  `FACE_MATCH_TOLERANCE` only after testing with your own registered photos.
- Runs all zones as threads in a single Flask process — fine for a
  demo/prototype on one machine; a production deployment would split
  camera processing across edge devices reporting to a central server.
