const POLL_MS = 1500;
const VIP_POLL_MS = 3000;

function statusClass(status) {
  if (status === "OVERCROWDED") return "critical";
  if (status === "WARNING") return "warn";
  return "";
}

async function pollOverview() {
  try {
    const res = await fetch("/api/overview");
    const data = await res.json();
    renderOverview(data);
  } catch (e) {
    console.error("overview poll failed", e);
  } finally {
    setTimeout(pollOverview, POLL_MS);
  }
}

function renderOverview(data) {
  // zones
  data.zones.forEach(z => {
    const pill = document.getElementById(`pill-${z.zone_id}`);
    const countEl = document.getElementById(`count-${z.zone_id}`);
    if (!pill || !countEl) return;
    showRotation(z.zone_id, z.rotation);

    let label = z.status;
    if (z.status === "OVERCROWDED") label = `OVERCROWDING! (${z.head_count})`;
    if (z.fire) label = "FIRE ALERT";
    pill.textContent = label;
    pill.className = "cam-status-pill " + (z.fire ? "critical" : statusClass(z.status));
    countEl.textContent = `${z.head_count} / ${z.capacity}`;

    const note = document.getElementById(`src-note-${z.zone_id}`);
    if (note) {
      if (z.error) {
        note.textContent = "Error: " + z.error;
        note.style.color = "var(--critical)";
      } else {
        note.textContent = "Current: " + (z.source_label || "--");
        note.style.color = "var(--muted)";
      }
    }
  });

  // predictions
  const tbody = document.getElementById("pred-tbody");
  tbody.innerHTML = "";
  data.predictions.forEach(p => {
    const tr = document.createElement("tr");
    const forecast = p.will_bottleneck
      ? `<span class="pred-flag">LIKELY BOTTLENECK${p.downstream_risk.length ? " &rarr; " + p.downstream_risk.join(", ") : ""}</span>`
      : "normal";
    tr.innerHTML = `
      <td>${p.zone_id} ${p.name}</td>
      <td>${p.current_count}</td>
      <td>${p.predicted_count}</td>
      <td>${p.rate_per_min > 0 ? "+" : ""}${p.rate_per_min}/min</td>
      <td>${forecast}</td>
    `;
    tbody.appendChild(tr);
  });

  // alerts
  const feed = document.getElementById("alert-feed");
  if (data.alerts.length === 0) {
    feed.innerHTML = '<div class="alert-empty">No alerts yet.</div>';
  } else {
    feed.innerHTML = data.alerts.map(a => {
      const t = new Date(a.time).toLocaleTimeString();
      return `<div class="alert-item ${a.severity}">
        <span class="alert-time">${t}</span><strong>[${a.type}]</strong> ${a.message}
      </div>`;
    }).join("");
  }
}

async function pollVip() {
  try {
    const res = await fetch("/api/vip/status");
    const data = await res.json();
    renderVip(data);
  } catch (e) {
    console.error("vip poll failed", e);
  } finally {
    setTimeout(pollVip, VIP_POLL_MS);
  }
}

function renderVip(data) {
  const list = document.getElementById("vip-list");
  if (!data.vips || data.vips.length === 0) {
    list.innerHTML = '<div class="alert-empty">No VIP activity yet. Registered: ' + data.total_registered + '</div>';
    return;
  }
  list.innerHTML = data.vips.map(v => `
    <div class="vip-row">
      <span><span class="vip-id">${v.vip_id}</span> ${v.name} (${v.tier})</span>
      <span class="vip-zone">${v.zone_name}</span>
    </div>
  `).join("");
}

function toggleVipForm() {
  document.getElementById("vip-form").classList.toggle("hidden");
}

async function submitVip(evt) {
  evt.preventDefault();
  const msg = document.getElementById("vip-form-msg");
  msg.textContent = "Registering...";
  msg.className = "vip-form-msg";

  const name = document.getElementById("vip-name").value;
  const tier = document.getElementById("vip-tier").value;
  const photoInput = document.getElementById("vip-photo");

  if (!photoInput.files || photoInput.files.length === 0) {
    msg.textContent = "Please choose a photo file first.";
    msg.className = "vip-form-msg err";
    return false;
  }

  const fd = new FormData();
  fd.append("name", name);
  fd.append("tier", tier);
  fd.append("photo", photoInput.files[0]);

  try {
    const res = await fetch("/api/vip/register", { method: "POST", body: fd });
    const data = await res.json();
    if (data.ok) {
      msg.textContent = `Registered - assigned ID ${data.vip_id}`;
      msg.className = "vip-form-msg ok";
      document.getElementById("vip-form").reset();
      pollVip();
    } else {
      msg.textContent = data.error || "Registration failed.";
      msg.className = "vip-form-msg err";
    }
  } catch (e) {
    msg.textContent = "Network error while registering VIP.";
    msg.className = "vip-form-msg err";
  }
  return false;
}

async function setWebcam(zoneId) {
  const selector = document.getElementById(`webcam-idx-${zoneId}`);
  const idx = selector.value || 0;
  const label = selector.options[selector.selectedIndex].text;
  const note = document.getElementById(`src-note-${zoneId}`);
  note.textContent = "Switching to webcam...";
  try {
    const res = await fetch(`/api/zone/${zoneId}/source/webcam`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ index: parseInt(idx, 10), label }),
    });
    const data = await res.json();
    note.textContent = data.ok ? `Switched to ${data.source}` : (data.error || "Failed.");
  } catch (e) {
    note.textContent = "Network error.";
  }
}

async function setPhoneCamera(zoneId) {
  const address = document.getElementById(`phone-url-${zoneId}`).value.trim();
  const note = document.getElementById(`src-note-${zoneId}`);
  if (!address) {
    note.textContent = "Enter the IP address shown in the DroidCam app.";
    note.style.color = "var(--critical)";
    return;
  }
  note.textContent = "Connecting to phone...";
  note.style.color = "var(--muted)";
  try {
    const res = await fetch(`/api/zone/${zoneId}/source/url`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: address }),
    });
    const data = await res.json();
    note.textContent = data.ok ? `Phone camera: ${data.url}` : (data.error || "Failed.");
    note.style.color = data.ok ? "var(--ok)" : "var(--critical)";
  } catch (e) {
    note.textContent = "Network error.";
    note.style.color = "var(--critical)";
  }
}

async function rotateFeed(zoneId) {
  try {
    const res = await fetch(`/api/zone/${zoneId}/rotate`, { method: "POST" });
    const data = await res.json();
    if (data.ok) showRotation(zoneId, data.rotation);
  } catch (e) {
    console.error("rotate failed", e);
  }
}

function showRotation(zoneId, rotation) {
  const btn = document.getElementById(`rotate-${zoneId}`);
  if (btn) btn.textContent = rotation ? `↻ ${rotation}°` : "↻ Rotate";
  // A sideways-turned feed is portrait: show it whole instead of cropping it.
  const img = document.querySelector(`.camera-cell[data-zone="${zoneId}"] .camera-img`);
  if (img) img.classList.toggle("portrait", rotation === 90 || rotation === 270);
}

async function stopCamera(zoneId) {
  const note = document.getElementById(`src-note-${zoneId}`);
  note.textContent = "Stopping camera...";
  try {
    const res = await fetch(`/api/zone/${zoneId}/source/stop`, { method: "POST" });
    const data = await res.json();
    note.textContent = data.ok ? "Camera stopped." : (data.error || "Failed to stop camera.");
    note.style.color = data.ok ? "var(--muted)" : "var(--critical)";
  } catch (e) {
    note.textContent = "Network error while stopping camera.";
    note.style.color = "var(--critical)";
  }
}

async function stopAllCameras() {
  try {
    await fetch("/api/cameras/stop", { method: "POST" });
    document.querySelectorAll(".src-note").forEach(note => {
      note.textContent = "Camera stopped.";
      note.style.color = "var(--muted)";
    });
  } catch (e) {
    console.error("could not stop cameras", e);
  }
}

async function uploadTestVideo(zoneId) {
  const fileInput = document.getElementById(`video-file-${zoneId}`);
  const note = document.getElementById(`src-note-${zoneId}`);
  if (!fileInput.files || fileInput.files.length === 0) {
    note.textContent = "Choose a video file first.";
    note.style.color = "var(--critical)";
    return;
  }
    note.textContent = "Loading demo video...";
  note.style.color = "var(--muted)";

  const fd = new FormData();
  fd.append("video", fileInput.files[0]);

  try {
    const res = await fetch(`/api/zone/${zoneId}/source/video`, { method: "POST", body: fd });
    const data = await res.json();
    if (data.ok) {
      note.textContent = `Demo running: ${data.filename} (loops automatically)`;
      note.style.color = "var(--ok)";
    } else {
      note.textContent = data.error || "Upload failed.";
      note.style.color = "var(--critical)";
    }
  } catch (e) {
    note.textContent = "Network error while uploading video.";
    note.style.color = "var(--critical)";
  }
}

pollOverview();
pollVip();

// Feeds run on the server and keep running across page reloads; use
// "Stop all cameras" (or stop the server) to release the cameras.
