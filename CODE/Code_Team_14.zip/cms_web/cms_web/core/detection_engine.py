"""
core/detection_engine.py
-------------------------
Wraps a YOLOv8 model to detect and count people in a video frame.
Kept deliberately simple/CPU-friendly (yolov8n) so it runs on an average
laptop for a live demo.
"""

from collections import deque

import cv2
import torch
from ultralytics import YOLO

from config import (
    YOLO_MODEL_PATH, PERSON_CLASS_ID, DETECTION_CONFIDENCE,
    DETECTION_IMAGE_SIZE, DETECTION_IOU_THRESHOLD, COUNT_SMOOTHING_WINDOW,
    TORCH_THREADS_PER_FEED,
)

# Every zone runs its own model. With the default thread counts, two or
# more feeds oversubscribe the CPU and starve the Flask threads, which
# freezes the dashboard. A small per-feed thread count is just as fast.
torch.set_num_threads(TORCH_THREADS_PER_FEED)
cv2.setNumThreads(1)


class PersonDetector:
    def __init__(self, model_path: str = YOLO_MODEL_PATH):
        self.model = YOLO(model_path)
        self._recent_counts = deque(maxlen=COUNT_SMOOTHING_WINDOW)

    def detect(self, frame):
        """
        Run detection on a single BGR frame.

        Returns:
            head_count (int): number of people detected
            boxes (list[tuple]): (x1, y1, x2, y2, confidence) for each person
            annotated_frame (ndarray): frame with bounding boxes drawn
        """
        results = self.model.predict(
            frame,
            verbose=False,
            conf=DETECTION_CONFIDENCE,
            iou=DETECTION_IOU_THRESHOLD,
            imgsz=DETECTION_IMAGE_SIZE,
            classes=[PERSON_CLASS_ID],
        )

        boxes = []
        annotated = frame.copy()

        if results:
            r = results[0]
            for box in r.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                boxes.append((x1, y1, x2, y2, conf))

                # Plain rectangle + label - no glow/fancy overlay, this is a
                # security tool, not a showcase UI.
                cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 200, 0), 1)
                cv2.putText(
                    annotated, f"{conf:.2f}", (x1, max(y1 - 5, 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 200, 0), 1
                )

        raw_count = len(boxes)
        self._recent_counts.append(raw_count)
        # The median is deliberately used only for the displayed/alert count:
        # it prevents an occasional blurred frame from abruptly reporting a
        # much smaller crowd, while still following real changes quickly.
        head_count = int(round(sorted(self._recent_counts)[len(self._recent_counts) // 2]))
        cv2.putText(
            annotated, f"PEOPLE: {head_count}", (10, 20),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1
        )
        return head_count, boxes, annotated
