"""
core/stream_manager.py
------------------------
Runs one background processing thread per zone. Each thread:
  - opens its video source (webcam index OR an uploaded test video file)
  - runs person detection (head count) + fire/smoke detection + VIP face
    recognition
  - encodes the annotated frame as JPEG and stores it in a shared,
    lock-protected state object

The Flask MJPEG route just reads the latest JPEG bytes from that shared
state - it does not touch OpenCV directly, so multiple browser tabs can
watch the same feed without opening the camera twice.

Test-video support: if a zone's source is a video FILE (not a live
webcam), the thread loops it automatically when it reaches the end, so a
short demo clip can run indefinitely during a presentation.
"""

import os
import threading
import time
from collections import defaultdict, deque

import cv2

from config import (
    ZONES, FACE_RECOGNITION_EVERY_N_FRAMES, DETECTION_MAX_FRAME_WIDTH,
    VIP_CONFIRMATION_HITS, VIP_CONFIRMATION_WINDOW_SEC, TARGET_PROCESS_FPS,
    FIRE_ALERT_COOLDOWN_SEC,
)
from core.detection_engine import PersonDetector
from core.fire_smoke_detector import FireSmokeDetector
from core.zone_manager import ZoneManager
from core.vip_manager import VIPManager
from core import database


_ROTATE_CODES = {
    90: cv2.ROTATE_90_CLOCKWISE,
    180: cv2.ROTATE_180,
    270: cv2.ROTATE_90_COUNTERCLOCKWISE,
}


class ZoneState:
    """Thread-safe holder for the latest processed output of one zone."""
    def __init__(self):
        self.lock = threading.Lock()
        self.jpeg_bytes = None
        self.head_count = 0
        self.fire = False
        self.smoke = False
        self.vip_hits = []
        self.source_label = ""
        self.error = None
        self.running = False
        self.rotation = 0          # degrees clockwise; phones often send frames sideways
        self.owner = None          # the _ZoneWorker currently publishing to this state

    def snapshot(self):
        with self.lock:
            return {
                "head_count": self.head_count,
                "fire": self.fire,
                "smoke": self.smoke,
                "vip_hits": list(self.vip_hits),
                "source_label": self.source_label,
                "error": self.error,
                "running": self.running,
                "rotation": self.rotation,
            }


class _ZoneWorker(threading.Thread):
    def __init__(self, zone_id, source, source_label, state: ZoneState, vip_manager, on_vip_seen):
        super().__init__(daemon=True)
        self.zone_id = zone_id
        self.source = source
        self.source_label = source_label
        self.state = state
        self.vip_manager = vip_manager
        self.on_vip_seen = on_vip_seen
        self.stop_event = threading.Event()
        self.detector = PersonDetector()
        self.fire_detector = FireSmokeDetector()
        self.frame_idx = 0
        self._is_file_source = isinstance(source, str) and os.path.exists(source)
        self._is_stream_source = isinstance(source, str) and "://" in source
        self._vip_match_times = defaultdict(deque)
        self._last_fire_alert = float("-inf")

    def stop(self):
        self.stop_event.set()

    def run(self):
        if self.source is None:
            with self.state.lock:
                self.state.source_label = "NO CAMERA SELECTED"
                self.state.error = None
                self.state.running = False
            return

        cap = self._open_capture()
        if not cap.isOpened():
            with self.state.lock:
                self.state.error = (
                    f"Could not connect to phone at {self.source} - check the IP and "
                    "that the phone is on the same Wi-Fi"
                    if self._is_stream_source else f"Could not open source: {self.source}"
                )
                self.state.running = False
            return

        # Do not let OpenCV retain a long queue of old webcam frames.
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        source_fps = cap.get(cv2.CAP_PROP_FPS) or TARGET_PROCESS_FPS
        video_frame_step = max(1, int(round(source_fps / TARGET_PROCESS_FPS))) if self._is_file_source else 1

        with self.state.lock:
            self.state.owner = self
            self.state.running = True
            self.state.error = None
            self.state.source_label = self.source_label or (
                "DEMO VIDEO" if self._is_file_source else f"WEBCAM {self.source}"
            )

        self._cap = cap
        consecutive_errors = 0
        try:
            while not self.stop_event.is_set():
                try:
                    if not self._process_one_frame(video_frame_step):
                        break
                    if consecutive_errors:
                        consecutive_errors = 0
                        with self.state.lock:
                            self.state.error = None
                except Exception as exc:
                    # One bad frame (or a briefly locked database) must not
                    # kill the feed for the rest of the demo - report and retry.
                    consecutive_errors += 1
                    print(f"[{self.zone_id}] frame error: {exc!r}")
                    with self.state.lock:
                        self.state.error = f"Recovering from error: {exc}"
                    time.sleep(min(0.5 * consecutive_errors, 3.0))
        finally:
            self._cap.release()
            with self.state.lock:
                # A newer worker may already own this zone; don't mark it stopped.
                if self.state.owner is self:
                    self.state.running = False

    def _process_one_frame(self, video_frame_step):
        """Read, analyse and publish one frame. Returns False once the worker
        has been stopped mid-frame."""
        cap = self._cap
        cycle_started = time.monotonic()
        ok, frame = cap.read()
        if not ok:
            if self._is_file_source:
                # loop the demo video instead of stopping
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                return True
            time.sleep(0.5)
            if self._is_stream_source:
                # phone Wi-Fi dropped - reconnect instead of freezing
                cap.release()
                self._cap = self._open_capture()
            return True

        self.frame_idx += 1
        # Rotate before detection: YOLO and face matching expect people upright.
        rotate_code = _ROTATE_CODES.get(self.state.rotation)
        if rotate_code is not None:
            frame = cv2.rotate(frame, rotate_code)
        # Do detection before display resizing.  The old fixed 480x360
        # resize removed the pixels needed to detect distant heads.
        # Limit the longer side so rotated (portrait) phone frames are capped too.
        height, width = frame.shape[:2]
        if max(width, height) > DETECTION_MAX_FRAME_WIDTH:
            factor = DETECTION_MAX_FRAME_WIDTH / max(width, height)
            frame = cv2.resize(frame, (int(width * factor), int(height * factor)))

        head_count, boxes, _ = self.detector.detect(frame)
        fire_result = self.fire_detector.detect(frame)
        annotated = fire_result["annotated"]

        # Fire/smoke analysis must receive the untouched camera frame,
        # then person overlays are restored on its annotated result.
        for x1, y1, x2, y2, confidence in boxes:
            cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 200, 0), 1)
            cv2.putText(annotated, f"{confidence:.2f}", (x1, max(y1 - 5, 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 200, 0), 1)
        cv2.putText(annotated, f"PEOPLE: {head_count}", (10, 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

        vip_hits = []
        if self.frame_idx % FACE_RECOGNITION_EVERY_N_FRAMES == 0:
            faces = self.vip_manager.identify_faces(frame)
            annotated = self.vip_manager.draw_faces(annotated, faces)
            vip_hits = [f for f in faces if f["vip_id"] is not None and self._confirm_vip_hit(f)]
            for hit in vip_hits:
                self.on_vip_seen(hit, self.zone_id)

        ok_enc, buf = cv2.imencode(".jpg", annotated, [int(cv2.IMWRITE_JPEG_QUALITY), 72])

        # stop_zone() may have cleared the state while this frame was
        # being processed; don't write a stale frame/count back over it.
        if self.stop_event.is_set():
            return False

        with self.state.lock:
            if ok_enc:
                self.state.jpeg_bytes = buf.tobytes()
            self.state.head_count = head_count
            self.state.fire = fire_result["fire"]
            self.state.smoke = False
            self.state.vip_hits = vip_hits

        if fire_result["fire"] and time.monotonic() - self._last_fire_alert >= FIRE_ALERT_COOLDOWN_SEC:
            self._last_fire_alert = time.monotonic()
            database.add_alert("FIRE", self.zone_id, "CRITICAL",
                                f"FIRE detected in {ZONES[self.zone_id]['name']}!")

        # A file source has no real-time clock. Skip frames to keep the
        # demo moving at its recorded pace instead of replaying it in
        # slow motion whenever inference takes longer than one frame.
        for _ in range(video_frame_step - 1):
            if not cap.grab():
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                break

        remaining = (1 / TARGET_PROCESS_FPS) - (time.monotonic() - cycle_started)
        if remaining > 0:
            time.sleep(remaining)
        return True

    def _open_capture(self):
        if self._is_stream_source:
            # Without timeouts an unreachable phone blocks for ~30s.
            return cv2.VideoCapture(self.source, cv2.CAP_FFMPEG, [
                cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000,
                cv2.CAP_PROP_READ_TIMEOUT_MSEC, 5000,
            ])
        return cv2.VideoCapture(self.source)

    def _confirm_vip_hit(self, hit):
        """Require repeated matches before a face changes the VIP location."""
        now = time.monotonic()
        hits = self._vip_match_times[hit["vip_id"]]
        hits.append(now)
        while hits and now - hits[0] > VIP_CONFIRMATION_WINDOW_SEC:
            hits.popleft()
        return len(hits) >= VIP_CONFIRMATION_HITS


class StreamManager:
    def __init__(self):
        self.vip_manager = VIPManager()
        self.zone_manager = ZoneManager()
        self.states = {zid: ZoneState() for zid in ZONES}
        self.workers = {}
        self._vip_last_zone = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    def start_all(self):
        for zid, cfg in ZONES.items():
            # Do not load a heavy YOLO worker for an unassigned feed.  The
            # worker is created only when the user actually starts a camera.
            if cfg["source"] is not None:
                self._start_worker(zid, cfg["source"])
            else:
                state = self.states[zid]
                with state.lock:
                    state.source_label = "NO CAMERA SELECTED"
                    state.running = False

    def _start_worker(self, zone_id, source, source_label=None):
        with self._lock:
            old = self.workers.get(zone_id)
            if old is not None:
                old.stop()
                # Wait for the old worker to release the camera, otherwise
                # re-selecting the same device fails to open. A phone stream
                # can take up to its 5s read timeout to notice the stop.
                if old.is_alive():
                    old.join(timeout=6)
            worker = _ZoneWorker(zone_id, source, source_label, self.states[zone_id],
                                  self.vip_manager, self._handle_vip_seen)
            self.workers[zone_id] = worker
            worker.start()

    def set_zone_source(self, zone_id, source, source_label=None):
        """source: int (camera index) or str path to a demo video file."""
        self._start_worker(zone_id, source, source_label)

    def stop_zone(self, zone_id):
        """Release one capture device and clear its visible state."""
        with self._lock:
            worker = self.workers.get(zone_id)
            if worker is not None:
                worker.stop()
        state = self.states[zone_id]
        with state.lock:
            state.jpeg_bytes = None
            state.head_count = 0
            state.fire = False
            state.smoke = False
            state.vip_hits = []
            state.source_label = "CAMERA STOPPED"
            state.error = None
            state.running = False

    def rotate_zone(self, zone_id):
        """Turn a feed a further 90 degrees clockwise; returns the new angle."""
        state = self.states[zone_id]
        with state.lock:
            state.rotation = (state.rotation + 90) % 360
            return state.rotation

    def stop_all_cameras(self):
        for zone_id in ZONES:
            self.stop_zone(zone_id)

    def _handle_vip_seen(self, hit, zone_id):
        vip_id = hit["vip_id"]
        if self._vip_last_zone.get(vip_id) != zone_id:
            self._vip_last_zone[vip_id] = zone_id
            self.vip_manager.record_sighting(vip_id, zone_id, ZONES[zone_id]["name"])
            database.add_alert(
                "VIP", zone_id, "INFO",
                f'{hit["name"]} ({vip_id}) entered {ZONES[zone_id]["name"]} - no QR check needed.'
            )

    # ------------------------------------------------------------------
    def get_zone_snapshot(self, zone_id):
        return self.states[zone_id].snapshot()

    def get_jpeg(self, zone_id):
        with self.states[zone_id].lock:
            return self.states[zone_id].jpeg_bytes

    def tick_zone_counts(self):
        """Call periodically (e.g. every ~1s) from a background scheduler
        to push each zone's latest head count into ZoneManager, which
        handles overcrowding thresholds + DB snapshots for the predictor."""
        results = {}
        for zid in ZONES:
            snap = self.states[zid].snapshot()
            results[zid] = self.zone_manager.update(zid, snap["head_count"])
        return results

    def stop_all(self):
        with self._lock:
            for w in self.workers.values():
                w.stop()
