"""
core/bottleneck_predictor.py
------------------------------
Predictive Bottleneck Solver
=============================
Predicts where crowd congestion is heading BEFORE it happens (default
horizon: 5 minutes / PREDICTION_HORIZON_SEC).

Method (kept simple and explainable for a viva, no external ML library
required):

1. Pull each zone's headcount history for the last HISTORY_WINDOW_SEC
   seconds from the database.
2. Fit a simple linear trend (least squares) of headcount vs time to get
   the crowd growth RATE (people / second) for that zone.
3. Project the count forward by PREDICTION_HORIZON_SEC using that rate
   -> predicted_count.
4. If predicted_count crosses the zone's WARNING/CRITICAL capacity
   threshold, raise a BOTTLENECK alert *ahead of time*, naming the zone,
   current count, predicted count and estimated time-to-threshold.
5. Additionally, using ZONE_FLOW_GRAPH (which phase leads to which), if an
   upstream zone is filling fast, downstream zones are flagged as
   "likely next bottleneck" so staff can pre-emptively redirect people.
"""

import time
from datetime import datetime, timedelta

from config import (
    ZONES, ZONE_FLOW_GRAPH, PREDICTION_HORIZON_SEC, HISTORY_WINDOW_SEC,
    WARNING_THRESHOLD, CRITICAL_THRESHOLD,
)
from core import database


def _linear_trend(points):
    """
    Least-squares slope/intercept for [(t_seconds, count), ...].
    Returns (slope, intercept). slope = people per second.
    """
    n = len(points)
    if n < 2:
        return 0.0, points[0][1] if points else 0.0

    sum_t = sum(p[0] for p in points)
    sum_c = sum(p[1] for p in points)
    sum_tc = sum(p[0] * p[1] for p in points)
    sum_tt = sum(p[0] * p[0] for p in points)

    denom = (n * sum_tt - sum_t * sum_t)
    if denom == 0:
        return 0.0, sum_c / n

    slope = (n * sum_tc - sum_t * sum_c) / denom
    intercept = (sum_c - slope * sum_t) / n
    return slope, intercept


class BottleneckPredictor:
    def __init__(self):
        self._last_alert_time = {}   # zone_id -> timestamp, to avoid spam

    def _zone_prediction(self, zone_id, current_count):
        capacity = ZONES[zone_id]["capacity"]
        since = (datetime.now() - timedelta(seconds=HISTORY_WINDOW_SEC)).isoformat()
        rows = database.get_recent_snapshots(zone_id, since)

        if len(rows) < 2:
            return {
                "zone_id": zone_id, "rate_per_min": 0.0,
                "predicted_count": current_count, "eta_seconds": None,
                "will_bottleneck": False,
            }

        t0 = datetime.fromisoformat(rows[0][1])
        points = [((datetime.fromisoformat(t) - t0).total_seconds(), c) for c, t in rows]

        slope, intercept = _linear_trend(points)   # people / second
        now_t = points[-1][0]
        predicted_count = max(0, slope * (now_t + PREDICTION_HORIZON_SEC) + intercept)

        will_bottleneck = predicted_count >= capacity * WARNING_THRESHOLD and slope > 0

        eta_seconds = None
        if slope > 0:
            threshold_count = capacity * CRITICAL_THRESHOLD
            if current_count < threshold_count:
                eta_seconds = max(0, (threshold_count - current_count) / slope)

        return {
            "zone_id": zone_id,
            "rate_per_min": round(slope * 60, 2),
            "predicted_count": round(predicted_count, 1),
            "eta_seconds": eta_seconds,
            "will_bottleneck": will_bottleneck,
        }

    def predict_all(self, zone_states):
        """
        zone_states: {zone_id: {"head_count": int, ...}} from ZoneManager.

        Returns list of prediction dicts, one per zone, each containing:
          zone_id, name, current_count, predicted_count (in 5 min),
          rate_per_min, will_bottleneck, downstream_risk (list of zone ids
          likely to receive overflow), eta_seconds
        """
        predictions = {}
        for zid, state in zone_states.items():
            pred = self._zone_prediction(zid, state["head_count"])
            pred["name"] = ZONES[zid]["name"]
            pred["current_count"] = state["head_count"]
            pred["capacity"] = ZONES[zid]["capacity"]
            predictions[zid] = pred

        # propagate risk downstream through the flow graph
        for zid, pred in predictions.items():
            downstream_risk = []
            if pred["will_bottleneck"]:
                for nxt in ZONE_FLOW_GRAPH.get(zid, []):
                    downstream_risk.append(nxt)
            pred["downstream_risk"] = downstream_risk

        # raise alerts (rate-limited to 1 per zone per 60s)
        now = time.time()
        for zid, pred in predictions.items():
            if pred["will_bottleneck"]:
                last = self._last_alert_time.get(zid, 0)
                if now - last > 60:
                    self._last_alert_time[zid] = now
                    eta_txt = f"~{int(pred['eta_seconds'] // 60)}m {int(pred['eta_seconds'] % 60)}s" \
                        if pred["eta_seconds"] is not None else "soon"
                    msg = (
                        f"Predicted bottleneck in {pred['name']}: currently "
                        f"{pred['current_count']}, projected {pred['predicted_count']} "
                        f"in next 5 min (trend +{pred['rate_per_min']}/min). "
                        f"Est. time to critical: {eta_txt}."
                    )
                    database.add_alert("BOTTLENECK", zid, "WARNING", msg)

        return list(predictions.values())
