"""
core/zone_manager.py
---------------------
Tracks the live headcount for every phase/zone of the venue and decides
its status (NORMAL / WARNING / OVERCROWDED). Also writes periodic
snapshots to the database for the bottleneck predictor.
"""

import time

from config import ZONES, WARNING_THRESHOLD, CRITICAL_THRESHOLD, SAMPLE_INTERVAL_SEC
from core import database


class ZoneState:
    def __init__(self, zone_id, name, capacity, is_entrance):
        self.zone_id = zone_id
        self.name = name
        self.capacity = capacity
        self.is_entrance = is_entrance
        self.head_count = 0
        self.status = "NORMAL"
        self.last_snapshot_time = 0

    def update_count(self, count):
        self.head_count = count
        ratio = count / self.capacity if self.capacity else 0
        if ratio >= CRITICAL_THRESHOLD:
            self.status = "OVERCROWDED"
        elif ratio >= WARNING_THRESHOLD:
            self.status = "WARNING"
        else:
            self.status = "NORMAL"
        return self.status

    def maybe_snapshot(self):
        """Persist headcount roughly every SAMPLE_INTERVAL_SEC seconds."""
        now = time.time()
        if now - self.last_snapshot_time >= SAMPLE_INTERVAL_SEC:
            database.add_zone_snapshot(self.zone_id, self.head_count)
            self.last_snapshot_time = now


class ZoneManager:
    def __init__(self):
        self.zones = {
            zid: ZoneState(zid, cfg["name"], cfg["capacity"], cfg.get("is_entrance", False))
            for zid, cfg in ZONES.items()
        }

    def update(self, zone_id, count):
        zone = self.zones[zone_id]
        old_status = zone.status
        new_status = zone.update_count(count)
        zone.maybe_snapshot()

        alert_message = None
        if new_status in ("WARNING", "OVERCROWDED") and new_status != old_status:
            alert_message = (
                f"Overcrowding {new_status} in {zone.name}: "
                f"head count {zone.head_count}/{zone.capacity}"
            )
            severity = "CRITICAL" if new_status == "OVERCROWDED" else "WARNING"
            database.add_alert("OVERCROWD", zone_id, severity, alert_message)

        return {
            "zone_id": zone_id,
            "name": zone.name,
            "head_count": zone.head_count,
            "capacity": zone.capacity,
            "status": new_status,
            "alert_message": alert_message,
        }

    def get_all_states(self):
        return {
            zid: {
                "name": z.name,
                "head_count": z.head_count,
                "capacity": z.capacity,
                "status": z.status,
                "is_entrance": z.is_entrance,
            }
            for zid, z in self.zones.items()
        }

    def total_venue_count(self):
        return sum(z.head_count for z in self.zones.values())
