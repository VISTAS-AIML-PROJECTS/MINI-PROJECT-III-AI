"""
core/fire_smoke_detector.py
----------------------------
Classical computer-vision fire, smoke and spark detection - tuned to reject
the two most common false positives seen during testing:

  1. Camera glare / bright reflections being flagged as "smoke".
  2. Static red/orange walls, doors, clothing or signage being flagged as
     "fire".

Why those false positives happen, and how each is fixed
---------------------------------------------------------
A plain HSV colour threshold cannot tell the difference between "a red
wall" and "a fire", because a red wall IS the colour of fire. Real flame
differs from a static red object in two measurable ways, and both are
checked here before anything is reported:

  (a) FLICKER: real flame area changes noticeably from frame to frame
      (it's never a stable shape). A wall's "fire-coloured" pixel area
      barely changes at all. -> we keep a short rolling history of the
      detected area and require its relative standard deviation to be
      above FIRE_FLICKER_MIN_STD_RATIO.

  (b) SHAPE: a wall segment (or a rectangular red poster/door) mostly
      fills its own bounding box - contour_area / bbox_area is close to
      1.0. Flame is irregular and jagged, so that ratio is noticeably
      lower. -> we require "extent" below FIRE_MAX_EXTENT.

Similarly, glare differs from smoke:

  (a) BRIGHTNESS CEILING: glare/reflections blow out close to pure white
      (V near 255). Real smoke is hazy but not blown-out. -> the smoke
      colour mask now excludes very high V values (SMOKE_MAX_V).

  (b) GROWTH: smoke spreads and thickens over a few seconds; a glare hot
      spot from a light fixture or reflective surface stays roughly the
      same size. -> we require the smoke region's area to have grown by
      at least SMOKE_GROWTH_MIN_RATIO compared to when it was first seen.

  (c) SHAPE: like the wall/fire case, a static glare patch (e.g. light
      reflecting off a flat surface) tends to be a fairly regular blob
      that fills its bounding box; real smoke is diffuse and uneven.

None of this requires a trained model, so it's easy to explain in a viva,
and the thresholds are all in config.py if they need to be re-tuned for a
specific room/lighting setup.
"""

import time
from collections import deque

import cv2
import numpy as np

from config import (
    FIRE_MIN_AREA, SMOKE_MIN_AREA, FIRE_CONSECUTIVE_FRAMES,
    FIRE_FLICKER_MIN_STD_RATIO, FIRE_MAX_EXTENT,
    SMOKE_MAX_V, SMOKE_MIN_V, SMOKE_GROWTH_MIN_RATIO, SMOKE_MAX_EXTENT,
    SMOKE_DETECTION_ENABLED,
)


def _contour_metrics(mask):
    """Returns (area, bbox(x,y,w,h), extent) for the largest contour, or
    (0, None, 0) if the mask is empty. extent = contour_area / bbox_area,
    i.e. how "rectangular / solid" the blob is (1.0 = perfect rectangle)."""
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return 0, None, 0.0
    c = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(c)
    if area <= 0:
        return 0, None, 0.0
    x, y, w, h = cv2.boundingRect(c)
    bbox_area = max(w * h, 1)
    extent = area / bbox_area
    return area, (x, y, w, h), extent


class FireSmokeDetector:
    def __init__(self):
        self._fire_streak = 0
        self._fire_area_hist = deque(maxlen=12)

        self._smoke_area_hist = deque(maxlen=20)
        self._smoke_baseline_area = None
        self._smoke_first_seen = None

    # ------------------------------------------------------------------
    def _fire_color_mask(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        # Flame core: orange/yellow-red, high saturation, bright.
        lower = np.array([0, 120, 170])
        upper = np.array([30, 255, 255])
        mask = cv2.inRange(hsv, lower, upper)
        mask = cv2.erode(mask, None, iterations=1)
        mask = cv2.dilate(mask, None, iterations=2)
        return mask

    def _smoke_color_mask(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        # Smoke: low saturation, greyish, moderate brightness - explicitly
        # capped BELOW glare/blown-highlight brightness (see module docstring).
        lower = np.array([0, 0, SMOKE_MIN_V])
        upper = np.array([180, 50, SMOKE_MAX_V])
        mask = cv2.inRange(hsv, lower, upper)
        mask = cv2.dilate(mask, None, iterations=3)
        return mask

    @staticmethod
    def _relative_std(values):
        if len(values) < 4:
            return 0.0
        arr = np.array(values, dtype=np.float32)
        mean = arr.mean()
        if mean <= 0:
            return 0.0
        return float(arr.std() / mean)

    # ------------------------------------------------------------------
    def detect(self, frame):
        annotated = frame.copy()

        # ---------------- FIRE ----------------
        fire_mask = self._fire_color_mask(frame)
        fire_area, fire_box, fire_extent = _contour_metrics(fire_mask)
        self._fire_area_hist.append(fire_area if fire_area >= FIRE_MIN_AREA else 0)
        flicker_ratio = self._relative_std(self._fire_area_hist)

        is_flame_shape = fire_extent > 0 and fire_extent <= FIRE_MAX_EXTENT
        is_flickering = flicker_ratio >= FIRE_FLICKER_MIN_STD_RATIO
        fire_candidate = fire_area >= FIRE_MIN_AREA and is_flame_shape and is_flickering

        self._fire_streak = self._fire_streak + 1 if fire_candidate else 0
        fire_confirmed = self._fire_streak >= FIRE_CONSECUTIVE_FRAMES

        # ---------------- SMOKE ----------------
        smoke_area, smoke_box, smoke_extent = 0, None, 0.0
        if SMOKE_DETECTION_ENABLED:
            smoke_mask = self._smoke_color_mask(frame)
            smoke_area, smoke_box, smoke_extent = _contour_metrics(smoke_mask)

        smoke_confirmed = False
        if smoke_area >= SMOKE_MIN_AREA and smoke_extent <= SMOKE_MAX_EXTENT:
            now = time.time()
            if self._smoke_baseline_area is None:
                self._smoke_baseline_area = smoke_area
                self._smoke_first_seen = now
            growth_ratio = smoke_area / max(self._smoke_baseline_area, 1)
            elapsed = now - (self._smoke_first_seen or now)
            # require the region to have visibly grown, and to have
            # persisted for at least ~2s (rules out a single glare flash)
            if growth_ratio >= SMOKE_GROWTH_MIN_RATIO and elapsed >= 2.0:
                smoke_confirmed = True
        else:
            # region disappeared / never matched -> reset growth baseline
            self._smoke_baseline_area = None
            self._smoke_first_seen = None

        if not fire_confirmed and not smoke_confirmed:
            pass  # nothing to draw

        if fire_confirmed and fire_box:
            x, y, w, h = fire_box
            cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.putText(annotated, "FIRE", (x, max(y - 8, 12)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

        if smoke_confirmed and smoke_box and not fire_confirmed:
            x, y, w, h = smoke_box
            cv2.rectangle(annotated, (x, y), (x + w, y + h), (160, 160, 0), 2)
            cv2.putText(annotated, "SMOKE", (x, max(y - 8, 12)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (160, 160, 0), 2)

        return {
            "fire": fire_confirmed,
            "fire_box": fire_box if fire_confirmed else None,
            "smoke": smoke_confirmed,
            "smoke_box": smoke_box if smoke_confirmed else None,
            "annotated": annotated,
        }
