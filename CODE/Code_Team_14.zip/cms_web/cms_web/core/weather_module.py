"""
core/weather_module.py
------------------------
Simple weather-alert check for outdoor events (rain, storms etc. can
directly affect crowd safety and evacuation routes). Uses the free
OpenWeatherMap "current weather" endpoint.

If no API key is configured, this module fails silently and the GUI
simply shows "Weather: not configured" instead of crashing the app -
handy for a college demo where you may not want to set up an API key.
"""

import requests

from config import WEATHER_API_KEY, WEATHER_CITY, WEATHER_ALERT_KEYWORDS
from core import database


class WeatherMonitor:
    def __init__(self):
        self.enabled = bool(WEATHER_API_KEY) and WEATHER_API_KEY != "PUT_YOUR_OPENWEATHERMAP_API_KEY_HERE"
        self._last_condition = None

    def check(self):
        """Returns dict: {status, description, temp_c, alert: bool} """
        if not self.enabled:
            return {"status": "NOT_CONFIGURED", "description": "Weather API key not set", "temp_c": None, "alert": False}

        try:
            url = "https://api.openweathermap.org/data/2.5/weather"
            params = {"q": WEATHER_CITY, "appid": WEATHER_API_KEY, "units": "metric"}
            resp = requests.get(url, params=params, timeout=5)
            data = resp.json()

            description = data["weather"][0]["description"]
            temp_c = data["main"]["temp"]

            alert = any(keyword in description.lower() for keyword in WEATHER_ALERT_KEYWORDS)

            if alert and description != self._last_condition:
                database.add_alert(
                    "WEATHER", None, "WARNING",
                    f"Weather advisory for {WEATHER_CITY}: {description}, {temp_c} C"
                )
            self._last_condition = description

            return {
                "status": "ALERT" if alert else "OK",
                "description": description,
                "temp_c": temp_c,
                "alert": alert,
            }
        except Exception as exc:
            return {"status": "ERROR", "description": str(exc), "temp_c": None, "alert": False}
