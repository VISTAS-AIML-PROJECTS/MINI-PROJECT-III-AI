"""
core/database.py
-----------------
SQLite persistence layer for the Crowd Management System.

Tables
------
vip_members       : registered VIPs with their face encoding
vip_movement_log   : which zone/phase each VIP was last seen entering
zone_snapshots     : periodic headcount history per zone (used for the
                      predictive bottleneck solver + reporting)
alerts             : unified alert log (fire, overcrowding, weather, bottleneck)
"""

import sqlite3
import pickle
import threading
from datetime import datetime

from config import DB_PATH


_lock = threading.Lock()


def get_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with _lock, get_connection() as conn:
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS vip_members (
                vip_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                tier TEXT DEFAULT 'VIP',
                photo_path TEXT,
                face_encoding BLOB NOT NULL,
                registered_on TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS vip_movement_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vip_id TEXT NOT NULL,
                zone_id TEXT NOT NULL,
                zone_name TEXT NOT NULL,
                event_time TEXT NOT NULL,
                FOREIGN KEY (vip_id) REFERENCES vip_members(vip_id)
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS zone_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                zone_id TEXT NOT NULL,
                head_count INTEGER NOT NULL,
                snapshot_time TEXT NOT NULL
            )
        """)
        # The predictor queries recent snapshots per zone every 2s; without
        # this index that query slows down as the table grows during a run.
        c.execute("""
            CREATE INDEX IF NOT EXISTS idx_snapshots_zone_time
            ON zone_snapshots (zone_id, snapshot_time)
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                alert_type TEXT NOT NULL,      -- FIRE / SMOKE / OVERCROWD / WEATHER / BOTTLENECK
                zone_id TEXT,
                severity TEXT NOT NULL,        -- WARNING / CRITICAL
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()


# ---------------------------------------------------------------------------
# VIP MEMBERS
# ---------------------------------------------------------------------------
def add_vip(vip_id, name, tier, photo_path, face_encoding):
    with _lock, get_connection() as conn:
        conn.execute(
            "INSERT INTO vip_members (vip_id, name, tier, photo_path, face_encoding, registered_on) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (vip_id, name, tier, photo_path, pickle.dumps(face_encoding), datetime.now().isoformat()),
        )
        conn.commit()


def get_all_vips():
    with _lock, get_connection() as conn:
        rows = conn.execute("SELECT vip_id, name, tier, photo_path, face_encoding FROM vip_members").fetchall()
    result = []
    for vip_id, name, tier, photo_path, enc_blob in rows:
        result.append({
            "vip_id": vip_id,
            "name": name,
            "tier": tier,
            "photo_path": photo_path,
            "face_encoding": pickle.loads(enc_blob),
        })
    return result


def next_vip_id():
    with _lock, get_connection() as conn:
        count = conn.execute("SELECT COUNT(*) FROM vip_members").fetchone()[0]
    return f"VIP-{count + 1:04d}"


# ---------------------------------------------------------------------------
# VIP MOVEMENT LOG (which phase a VIP is currently in)
# ---------------------------------------------------------------------------
def log_vip_movement(vip_id, zone_id, zone_name):
    with _lock, get_connection() as conn:
        conn.execute(
            "INSERT INTO vip_movement_log (vip_id, zone_id, zone_name, event_time) VALUES (?, ?, ?, ?)",
            (vip_id, zone_id, zone_name, datetime.now().isoformat()),
        )
        conn.commit()


def get_current_vip_locations():
    """Return {vip_id: (zone_id, zone_name, event_time)} - latest sighting only."""
    with _lock, get_connection() as conn:
        rows = conn.execute("""
            SELECT vip_id, zone_id, zone_name, event_time FROM vip_movement_log
            WHERE id IN (SELECT MAX(id) FROM vip_movement_log GROUP BY vip_id)
        """).fetchall()
    return {r[0]: {"zone_id": r[1], "zone_name": r[2], "time": r[3]} for r in rows}


# ---------------------------------------------------------------------------
# ZONE HEADCOUNT SNAPSHOTS (feeds the predictive bottleneck solver)
# ---------------------------------------------------------------------------
def add_zone_snapshot(zone_id, head_count):
    with _lock, get_connection() as conn:
        conn.execute(
            "INSERT INTO zone_snapshots (zone_id, head_count, snapshot_time) VALUES (?, ?, ?)",
            (zone_id, head_count, datetime.now().isoformat()),
        )
        conn.commit()


def get_recent_snapshots(zone_id, since_iso):
    with _lock, get_connection() as conn:
        rows = conn.execute(
            "SELECT head_count, snapshot_time FROM zone_snapshots "
            "WHERE zone_id = ? AND snapshot_time >= ? ORDER BY snapshot_time ASC",
            (zone_id, since_iso),
        ).fetchall()
    return rows


# ---------------------------------------------------------------------------
# ALERTS
# ---------------------------------------------------------------------------
def add_alert(alert_type, zone_id, severity, message):
    with _lock, get_connection() as conn:
        conn.execute(
            "INSERT INTO alerts (alert_type, zone_id, severity, message, created_at) VALUES (?, ?, ?, ?, ?)",
            (alert_type, zone_id, severity, message, datetime.now().isoformat()),
        )
        conn.commit()


def get_recent_alerts(limit=50):
    with _lock, get_connection() as conn:
        rows = conn.execute(
            "SELECT alert_type, zone_id, severity, message, created_at FROM alerts "
            "ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return rows
