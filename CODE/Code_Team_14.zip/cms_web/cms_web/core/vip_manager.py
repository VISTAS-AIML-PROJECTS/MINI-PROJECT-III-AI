"""
core/vip_manager.py
--------------------
VIP registration + facial recognition, hardened for the web upload flow.

Fixes applied vs. the earlier desktop version (which had a flaky VIP
registration path):
  - Explicitly validates the uploaded file is a real, readable image
    before doing anything else, and returns a clear error message instead
    of a generic exception.
  - Downscales oversized photos before face detection (very large phone
    photos were slow and sometimes failed detection).
  - Converts EXIF-rotated / non-RGB images (RGBA, palette, grayscale)
    to plain RGB, which face_recognition/dlib otherwise reject or
    mis-encode.
  - If multiple faces are found in the registration photo, picks the
    largest (assumed to be the intended subject) instead of failing.
"""

import os
import uuid

import cv2
import numpy as np
import face_recognition
from PIL import Image, ImageOps

from config import (
    VIP_PHOTO_DIR, FACE_MATCH_TOLERANCE, FACE_DETECTION_MODEL,
    FACE_ANALYSIS_SCALE, MIN_FACE_SIZE_PX,
)
from core import database


class VIPManager:
    def __init__(self):
        os.makedirs(VIP_PHOTO_DIR, exist_ok=True)
        self.known_encodings = []
        self.known_ids = []
        self.known_names = []
        self.reload_from_db()

    def reload_from_db(self):
        # Build new lists and swap them in, so camera threads matching faces
        # never see a half-cleared list (that raised IndexError mid-frame).
        vips = database.get_all_vips()
        self.known_ids = [v["vip_id"] for v in vips]
        self.known_names = [v["name"] for v in vips]
        self.known_encodings = [v["face_encoding"] for v in vips]

    # ------------------------------------------------------------------
    @staticmethod
    def _load_as_rgb_array(image_path):
        """Robustly load an uploaded photo as an RGB numpy array, fixing
        the issues that most commonly break VIP registration: EXIF
        rotation, non-RGB colour modes, and oversized dimensions."""
        if not os.path.exists(image_path) or os.path.getsize(image_path) == 0:
            raise ValueError("Uploaded file is missing or empty.")

        try:
            img = Image.open(image_path)
            img = ImageOps.exif_transpose(img)         # respect phone camera rotation
            img = img.convert("RGB")                   # handles RGBA / grayscale / palette
        except Exception as exc:
            raise ValueError(f"File is not a readable image ({exc}).")

        # Downscale very large photos - speeds up detection and avoids
        # occasional dlib failures on huge images.
        max_dim = 1200
        if max(img.size) > max_dim:
            ratio = max_dim / max(img.size)
            img = img.resize((int(img.width * ratio), int(img.height * ratio)))

        return np.array(img)

    # ------------------------------------------------------------------
    def register_vip(self, name, tier, image_path):
        if not name or not name.strip():
            raise ValueError("Name is required.")

        rgb = self._load_as_rgb_array(image_path)

        face_locations = face_recognition.face_locations(rgb, model=FACE_DETECTION_MODEL)
        if not face_locations:
            raise ValueError(
                "No face detected in the photo. Use a clear, front-facing, "
                "well-lit photo with only one face visible."
            )

        encodings = face_recognition.face_encodings(rgb, face_locations)

        # If more than one face is present, keep the largest bounding box
        # (most likely the intended subject, e.g. taken up close).
        if len(encodings) > 1:
            def box_area(loc):
                top, right, bottom, left = loc
                return (bottom - top) * (right - left)
            best_idx = max(range(len(face_locations)), key=lambda i: box_area(face_locations[i]))
        else:
            best_idx = 0

        encoding = encodings[best_idx]

        vip_id = database.next_vip_id()
        saved_path = os.path.join(VIP_PHOTO_DIR, f"{vip_id}_{uuid.uuid4().hex[:6]}.jpg")
        Image.fromarray(rgb).save(saved_path, "JPEG", quality=90)

        database.add_vip(vip_id, name.strip(), tier.strip() or "VIP", saved_path, encoding)
        self.reload_from_db()
        return vip_id

    # ------------------------------------------------------------------
    def identify_faces(self, frame):
        """
        frame: BGR numpy array (as read by OpenCV).
        Returns list of {"vip_id": str|None, "name": str, "box": (top,right,bottom,left)}
        """
        scale = FACE_ANALYSIS_SCALE
        small = cv2.resize(frame, (0, 0), fx=scale, fy=scale)
        rgb_small = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb_small, model=FACE_DETECTION_MODEL)
        face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

        results = []
        for (top, right, bottom, left), encoding in zip(face_locations, face_encodings):
            box = tuple(int(v / scale) for v in (top, right, bottom, left))

            if min(box[2] - box[0], box[1] - box[3]) < MIN_FACE_SIZE_PX:
                continue

            vip_id, name = None, "Unregistered / Public"
            distance = None
            if self.known_encodings:
                distances = face_recognition.face_distance(self.known_encodings, encoding)
                best_idx = int(distances.argmin())
                distance = float(distances[best_idx])
                if distances[best_idx] <= FACE_MATCH_TOLERANCE:
                    vip_id = self.known_ids[best_idx]
                    name = self.known_names[best_idx]

            results.append({"vip_id": vip_id, "name": name, "box": box, "distance": distance})
        return results

    @staticmethod
    def draw_faces(frame, faces):
        for f in faces:
            top, right, bottom, left = f["box"]
            is_vip = f["vip_id"] is not None
            color = (61, 139, 217) if is_vip else (150, 150, 150)
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            label = f'VIP {f["vip_id"]}' if is_vip else "Guest"
            cv2.putText(frame, label, (left, max(top - 8, 12)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        return frame

    @staticmethod
    def record_sighting(vip_id, zone_id, zone_name):
        database.log_vip_movement(vip_id, zone_id, zone_name)
