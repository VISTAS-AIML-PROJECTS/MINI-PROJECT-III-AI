"""
app.py
------
Flask web application for the Crowd Management & Security System.

Run:
    python app.py
Then open http://127.0.0.1:5000 in a browser.
"""

import os
import threading
import time
import uuid

from flask import Flask, render_template, Response, request, jsonify

from config import (
    ZONES, VIP_PHOTO_DIR, TEST_VIDEO_DIR, ALLOWED_IMAGE_EXT, ALLOWED_VIDEO_EXT,
    MAX_UPLOAD_MB, WEATHER_CHECK_INTERVAL_SEC,
)
from core.database import init_db, get_recent_alerts, get_current_vip_locations, get_all_vips
from core.stream_manager import StreamManager
from core.bottleneck_predictor import BottleneckPredictor
from core.weather_module import WeatherMonitor

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

init_db()
stream_manager = StreamManager()
predictor = BottleneckPredictor()
weather_monitor = WeatherMonitor()

_state_lock = threading.Lock()
_latest = {"predictions": [], "weather": {"status": "PENDING", "description": "", "temp_c": None, "alert": False}}


# ---------------------------------------------------------------------------
# BACKGROUND LOOPS (run independently of any browser request, so predictions
# and weather stay fresh even between page polls)
# ---------------------------------------------------------------------------
def _background_loop():
    last_weather_check = 0
    while True:
        # An error in one pass (e.g. the database briefly locked by OneDrive
        # sync) must not stop status updates and predictions for good.
        try:
            stream_manager.tick_zone_counts()

            states = stream_manager.zone_manager.get_all_states()
            preds = predictor.predict_all(states)
            with _state_lock:
                _latest["predictions"] = preds

            now = time.time()
            if now - last_weather_check >= WEATHER_CHECK_INTERVAL_SEC or last_weather_check == 0:
                last_weather_check = now
                result = weather_monitor.check()
                with _state_lock:
                    _latest["weather"] = result
        except Exception as exc:
            print(f"[background] update error: {exc!r}")

        time.sleep(2)


threading.Thread(target=_background_loop, daemon=True).start()
stream_manager.start_all()


# ---------------------------------------------------------------------------
# PAGES
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html", zones=ZONES)


# ---------------------------------------------------------------------------
# MJPEG VIDEO STREAM
# ---------------------------------------------------------------------------
def _mjpeg_generator(zone_id):
    boundary = b"--frame"
    placeholder = _placeholder_jpeg()
    while True:
        jpeg = stream_manager.get_jpeg(zone_id) or placeholder
        yield (boundary + b"\r\n"
               b"Content-Type: image/jpeg\r\n\r\n" + jpeg + b"\r\n")
        time.sleep(1 / 12)


_placeholder_cache = None
def _placeholder_jpeg():
    global _placeholder_cache
    if _placeholder_cache is None:
        import cv2
        import numpy as np
        img = np.zeros((360, 480, 3), dtype="uint8")
        cv2.putText(img, "CONNECTING...", (120, 180), cv2.FONT_HERSHEY_SIMPLEX,
                    0.7, (120, 120, 120), 2)
        ok, buf = cv2.imencode(".jpg", img)
        _placeholder_cache = buf.tobytes() if ok else b""
    return _placeholder_cache


@app.route("/video_feed/<zone_id>")
def video_feed(zone_id):
    if zone_id not in ZONES:
        return "Unknown zone", 404
    return Response(_mjpeg_generator(zone_id),
                     mimetype="multipart/x-mixed-replace; boundary=frame")


# ---------------------------------------------------------------------------
# API - dashboard polling
# ---------------------------------------------------------------------------
@app.route("/api/overview")
def api_overview():
    zone_data = []
    total_count = 0
    any_fire = False
    for zid, cfg in ZONES.items():
        snap = stream_manager.get_zone_snapshot(zid)
        state = stream_manager.zone_manager.zones[zid]
        total_count += state.head_count
        any_fire = any_fire or snap["fire"]
        zone_data.append({
            "zone_id": zid,
            "name": cfg["name"],
            "head_count": state.head_count,
            "capacity": cfg["capacity"],
            "status": state.status,
            "fire": snap["fire"],
            "running": snap["running"],
            "error": snap["error"],
            "source_label": snap["source_label"],
            "rotation": snap["rotation"],
        })

    with _state_lock:
        predictions = _latest["predictions"]
        weather = _latest["weather"]

    threat_score = 0
    if any_fire:
        threat_score = max(threat_score, 90)
    if any(z["status"] == "OVERCROWDED" for z in zone_data):
        threat_score = max(threat_score, 70)
    elif any(z["status"] == "WARNING" for z in zone_data):
        threat_score = max(threat_score, 35)

    threat_level = "LOW"
    if threat_score >= 70:
        threat_level = "CRITICAL"
    elif threat_score >= 35:
        threat_level = "ELEVATED"

    # Smoke monitoring is intentionally absent from the presentation
    # dashboard. Do not show old SQLite smoke records either.
    try:
        alerts = [a for a in get_recent_alerts(limit=100) if a[0] != "SMOKE"][:30]
        alert_list = [
            {"type": a[0], "zone_id": a[1], "severity": a[2], "message": a[3], "time": a[4]}
            for a in alerts
        ]
        _latest["alerts"] = alert_list
    except Exception:
        # Database briefly locked (e.g. OneDrive sync): keep showing the
        # last alerts rather than failing the whole dashboard update.
        alert_list = _latest.get("alerts", [])

    return jsonify({
        "zones": zone_data,
        "total_count": total_count,
        "threat_score": threat_score,
        "threat_level": threat_level,
        "predictions": predictions,
        "weather": weather,
        "alerts": alert_list,
        "incident_count": len([a for a in alert_list if a["severity"] == "CRITICAL"]),
    })


@app.route("/api/vip/status")
def api_vip_status():
    locations = get_current_vip_locations()
    vips = {v["vip_id"]: v for v in get_all_vips()}
    out = []
    for vip_id, loc in locations.items():
        out.append({
            "vip_id": vip_id,
            "name": vips.get(vip_id, {}).get("name", "?"),
            "tier": vips.get(vip_id, {}).get("tier", "VIP"),
            "zone_id": loc["zone_id"],
            "zone_name": loc["zone_name"],
            "time": loc["time"],
        })
    return jsonify({"vips": out, "total_registered": len(vips)})


# ---------------------------------------------------------------------------
# API - VIP registration (fixed upload flow)
# ---------------------------------------------------------------------------
@app.route("/api/vip/register", methods=["POST"])
def api_vip_register():
    name = request.form.get("name", "").strip()
    tier = request.form.get("tier", "VIP").strip()
    photo = request.files.get("photo")

    if not name:
        return jsonify({"ok": False, "error": "Name is required."}), 400
    if photo is None or photo.filename == "":
        return jsonify({"ok": False, "error": "No photo file was received. Choose a photo and try again."}), 400

    ext = os.path.splitext(photo.filename)[1].lower()
    if ext not in ALLOWED_IMAGE_EXT:
        return jsonify({"ok": False, "error": f"Unsupported image type '{ext}'. Use .jpg, .jpeg or .png."}), 400

    tmp_path = os.path.join(VIP_PHOTO_DIR, f"_upload_{uuid.uuid4().hex[:8]}{ext}")
    photo.save(tmp_path)

    try:
        vip_id = stream_manager.vip_manager.register_vip(name, tier, tmp_path)
        return jsonify({"ok": True, "vip_id": vip_id, "name": name, "tier": tier or "VIP"})
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception as exc:
        return jsonify({"ok": False, "error": f"Registration failed: {exc}"}), 500
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


# ---------------------------------------------------------------------------
# API - swap a zone's camera source: live webcam index OR an uploaded test
# video (this is the "test run with a video" feature).
# ---------------------------------------------------------------------------
@app.route("/api/zone/<zone_id>/source/webcam", methods=["POST"])
def api_set_webcam(zone_id):
    if zone_id not in ZONES:
        return jsonify({"ok": False, "error": "Unknown zone."}), 404
    data = request.get_json(silent=True) or {}
    try:
        index = int(data.get("index", 0))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Webcam index must be a number."}), 400
    requested_label = str(data.get("label", "")).strip()
    default_label = "LAPTOP CAMERA" if index == 0 else f"WEBCAM {index}"
    source_label = requested_label.upper() or default_label
    stream_manager.set_zone_source(zone_id, index, source_label)
    return jsonify({"ok": True, "zone_id": zone_id, "source": source_label})


@app.route("/api/zone/<zone_id>/source/url", methods=["POST"])
def api_set_stream_url(zone_id):
    """Phone / IP camera. A bare IP (as shown in the DroidCam app) is
    expanded to DroidCam's default stream address."""
    if zone_id not in ZONES:
        return jsonify({"ok": False, "error": "Unknown zone."}), 404
    data = request.get_json(silent=True) or {}
    url = str(data.get("url", "")).strip()
    if not url:
        return jsonify({"ok": False, "error": "Enter the phone's IP address."}), 400
    if "://" not in url:
        host = url if ":" in url else f"{url}:4747"
        url = f"http://{host}/video"
    if not url.startswith(("http://", "https://", "rtsp://")):
        return jsonify({"ok": False, "error": "Address must start with http://, https:// or rtsp://."}), 400
    stream_manager.set_zone_source(zone_id, url, "PHONE CAMERA")
    return jsonify({"ok": True, "zone_id": zone_id, "url": url})


@app.route("/api/zone/<zone_id>/rotate", methods=["POST"])
def api_rotate(zone_id):
    if zone_id not in ZONES:
        return jsonify({"ok": False, "error": "Unknown zone."}), 404
    rotation = stream_manager.rotate_zone(zone_id)
    return jsonify({"ok": True, "zone_id": zone_id, "rotation": rotation})


@app.route("/api/zone/<zone_id>/source/stop", methods=["POST"])
def api_stop_camera(zone_id):
    if zone_id not in ZONES:
        return jsonify({"ok": False, "error": "Unknown zone."}), 404
    stream_manager.stop_zone(zone_id)
    return jsonify({"ok": True, "zone_id": zone_id, "source": "CAMERA STOPPED"})


@app.route("/api/cameras/stop", methods=["POST"])
def api_stop_all_cameras():
    stream_manager.stop_all_cameras()
    return jsonify({"ok": True})


@app.route("/api/zone/<zone_id>/source/video", methods=["POST"])
def api_set_video(zone_id):
    if zone_id not in ZONES:
        return jsonify({"ok": False, "error": "Unknown zone."}), 404

    video = request.files.get("video")
    if video is None or video.filename == "":
        return jsonify({"ok": False, "error": "No video file was received."}), 400

    ext = os.path.splitext(video.filename)[1].lower()
    if ext not in ALLOWED_VIDEO_EXT:
        return jsonify({"ok": False, "error": f"Unsupported video type '{ext}'. Use mp4, avi, mov or mkv."}), 400

    saved_path = os.path.join(TEST_VIDEO_DIR, f"{zone_id}_{uuid.uuid4().hex[:8]}{ext}")
    video.save(saved_path)

    stream_manager.set_zone_source(zone_id, saved_path)
    return jsonify({"ok": True, "zone_id": zone_id, "source": "test video", "filename": video.filename})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
