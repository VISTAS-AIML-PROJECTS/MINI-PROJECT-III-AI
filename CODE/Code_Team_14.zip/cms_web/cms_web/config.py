"""
config.py
---------
Central configuration for the web version of the Crowd Management & Security
System. Edit ZONES to match your venue; everything else has sane defaults
for a college demo.
"""

import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "crowd_system.db")
VIP_PHOTO_DIR = os.path.join(BASE_DIR, "assets", "vip_photos")
TEST_VIDEO_DIR = os.path.join(BASE_DIR, "uploads", "test_videos")

os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
os.makedirs(VIP_PHOTO_DIR, exist_ok=True)
os.makedirs(TEST_VIDEO_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# VENUE PHASES / ZONES
# `source` can be changed at runtime from the dashboard (webcam index or an
# uploaded test video) - the values below are only the defaults at startup.
# ---------------------------------------------------------------------------
ZONES = {
    # Leave feeds unassigned at startup.  A physical camera can only be
    # opened reliably by one zone at a time, and each panel has its own
    # source selector in the dashboard.
    "Z1": {"name": "Main Entrance",         "source": None, "capacity": 15, "is_entrance": True},
    "Z2": {"name": "Phase 1 - Main Hall",    "source": None, "capacity": 25, "is_entrance": False},
    "Z3": {"name": "Phase 2 - Food Court",   "source": None, "capacity": 20, "is_entrance": False},
    "Z4": {"name": "Phase 3 - Exit Corridor","source": None, "capacity": 10, "is_entrance": False},
}

ZONE_FLOW_GRAPH = {
    "Z1": ["Z2"],
    "Z2": ["Z3", "Z4"],
    "Z3": ["Z4"],
    "Z4": [],
}

WARNING_THRESHOLD = 0.75
CRITICAL_THRESHOLD = 1.0

# ---------------------------------------------------------------------------
# DETECTION SETTINGS
# ---------------------------------------------------------------------------
YOLO_MODEL_PATH = "yolov8n.pt"
PERSON_CLASS_ID = 0
# Recall matters more than precision for safety headcounts.  Duplicate boxes
# are removed by YOLO's NMS; this lower threshold retains smaller/farther
# people that the former 0.40 threshold discarded.
DETECTION_CONFIDENCE = 0.25
DETECTION_IMAGE_SIZE = 768       # strong small-person recall without 960px CPU lag
DETECTION_IOU_THRESHOLD = 0.55
DETECTION_MAX_FRAME_WIDTH = 960  # keep enough detail while avoiding 4-feed CPU saturation
COUNT_SMOOTHING_WINDOW = 5       # median removes one-frame missed detections
TARGET_PROCESS_FPS = 8           # live dashboard rate; prevents demo footage falling behind
TORCH_THREADS_PER_FEED = 2      # more threads per feed overloads the CPU when several feeds run
STREAM_OUTPUT_FPS = 12         # how often the browser <img> tag is refreshed

# --- Fire / smoke tuning ---------------------------------------------------
# These thresholds were tightened specifically to cut down two common false
# positives seen during testing: (1) camera glare / bright light reflections
# being read as smoke, and (2) plain red/orange walls or clothing being read
# as fire. See core/fire_smoke_detector.py for how each rule is used.
FIRE_MIN_AREA = 1400
SMOKE_MIN_AREA = 2200
FIRE_CONSECUTIVE_FRAMES = 6          # frames in a row before an alert fires
FIRE_FLICKER_MIN_STD_RATIO = 0.12    # real flame area fluctuates frame-to-frame; static red objects don't
FIRE_MAX_EXTENT = 0.72               # contour_area / bbox_area - flame is irregular; a wall/rectangle fills its box
FIRE_ALERT_COOLDOWN_SEC = 15

SMOKE_DETECTION_ENABLED = False      # smoke is switched off; only fire is detected
SMOKE_MAX_V = 205                   # excludes blown-out glare highlights (which sit near V=255)
SMOKE_MIN_V = 90
SMOKE_GROWTH_MIN_RATIO = 1.15        # smoke spreads over time; a static glare spot won't grow
SMOKE_MAX_EXTENT = 0.80              # a static rectangular glare patch fills its box; smoke is diffuse/uneven

# ---------------------------------------------------------------------------
# PREDICTIVE BOTTLENECK SOLVER
# ---------------------------------------------------------------------------
PREDICTION_HORIZON_SEC = 300
HISTORY_WINDOW_SEC = 120
SAMPLE_INTERVAL_SEC = 5

# ---------------------------------------------------------------------------
# WEATHER ALERTS
# ---------------------------------------------------------------------------
WEATHER_API_KEY = "PUT_YOUR_OPENWEATHERMAP_API_KEY_HERE"
WEATHER_CITY = "Chennai"
WEATHER_CHECK_INTERVAL_SEC = 600
WEATHER_ALERT_KEYWORDS = ["rain", "storm", "thunderstorm", "extreme", "tornado", "cyclone", "heavy"]

# ---------------------------------------------------------------------------
# FACE RECOGNITION (VIP)
# ---------------------------------------------------------------------------
FACE_MATCH_TOLERANCE = 0.45
FACE_DETECTION_MODEL = "hog"
FACE_RECOGNITION_EVERY_N_FRAMES = 15  # face matching is costly; 8fps / 15 is sufficient for tracking
FACE_ANALYSIS_SCALE = 0.75             # retain more facial detail than the old 0.5 scale
MIN_FACE_SIZE_PX = 36                  # ignore faces too small for a reliable identity
VIP_CONFIRMATION_HITS = 2              # two close-in-time matches before location is updated
VIP_CONFIRMATION_WINDOW_SEC = 3.0

ALLOWED_IMAGE_EXT = {".jpg", ".jpeg", ".png"}
ALLOWED_VIDEO_EXT = {".mp4", ".avi", ".mov", ".mkv"}
MAX_UPLOAD_MB = 300
