# BharatVoice AI — demo script

Everything below has been run against the live system. Nothing here is
aspirational; if a line doesn't work, that's a bug worth reporting.

## Start

Two terminals.

```bash
cd backend && uvicorn app.main:app --reload --port 8000
```

```bash
cd frontend && npm run dev
```

Open `http://localhost:5173`. Chrome or Edge for voice (Firefox and Safari
don't implement the Web Speech API).

Sanity check before you present: `cd backend && pytest` → 752 passed.

## The five-minute walkthrough

### 1. Language identification (the technical core)

Type each of these on the home screen. The reply comes back in the same
language, and the badge on the message shows what was detected.

| Type this | Detected | Point to make |
|---|---|---|
| `வணக்கம், எப்படி இருக்கீங்க` | `ta` | Native script — exact, no model needed |
| `नमस्ते, आप कैसे हैं` | `hi` | Devanagari |
| `నమస్కారం, మీరు ఎలా ఉన్నారు` | `te` | Telugu |
| `ನಮಸ್ಕಾರ, ನೀವು ಹೇಗಿದ್ದೀರಿ` | `kn` | Kannada |
| `vanakkam, epdi irukeenga` | `ta-en` | Romanized Tanglish — the hard case |
| `Chennai la weather epdi irukku` | `ta-en` | Code-mixed in one sentence |

**What to say:** the four scripts occupy disjoint Unicode blocks, so a
script histogram identifies native-script text exactly — no model, no
download, no latency. Romanized input has no script signal at all, which is
why it needs a separate cue-word stage.

### 2. Live data, cited and timestamped

```
what is the weather in Madurai
```

Point at the two chips under the answer: the freshness stamp
(`as of 26 September 2026, 11:45 PM IST`) and the source (`Open-Meteo ·
checked <date>`).

Then the same question in each language:

```
கோயம்புத்தூர் வானிலை எப்படி இருக்கு
दिल्ली में मौसम कैसा है
హైదరాబాద్ వాతావరణం ఎలా ఉంది
ಬೆಂಗಳೂರಿನ ಹವಾಮಾನ ಹೇಗಿದೆ
```

**What to say:** the Kannada one is the interesting case — `ಬೆಂಗಳೂರಿನ` is
the genitive form of `ಬೆಂಗಳೂರು`, so exact matching fails; place names are
stemmed and normalised to a canonical English spelling because that's what
geocoding services index.

### 3. Refusing instead of guessing

```
what is the weather
```

It asks *which place* rather than defaulting to a city. Earlier it silently
defaulted to Chennai, so a Coimbatore user got Chennai's weather with no
indication anything had been substituted.

**What to say:** three outcomes are kept distinct — no place given, lookup
failed, lookup succeeded. Only the third produces a number, and it always
carries a timestamp.

### 4. Emergency (the accessibility story)

Tap **Emergency numbers**, ideally with the browser at phone width
(DevTools → device toolbar → iPhone).

Each helpline is a tappable `tel:` row — 44px target, bold number in a
fixed-width column. On a real phone these open the dialer.

Switch language with the header toggle and tap it again: all nine labels
come back in that language.

### 5. Source-of-truth discipline

```
how to apply for aadhaar
आधार कार्ड कैसे बनवाएं
ಪಡಿತರ ಚೀಟಿ ಹೇಗೆ ಪಡೆಯುವುದು
```

Every answer carries the issuing portal as a source, plus a
"confirm on the official portal" note in the user's own language.

**What to say:** the helpline sources deliberately show *no* checked-on
date, because nobody has re-verified those numbers against the official
portal — and a test enforces that the field stays empty until someone does.
A fabricated verification date would be worse than none.

### 6. Reminders that fire

```
remind me in 1 minute to take my tablets
```

Carry on talking. About a minute later a banner drops in at the top and the
assistant speaks the reminder aloud. Tick to complete, cross to dismiss.

Also works in every language:

```
நாளை 6 மணிக்கு அம்மாவை கூப்பிட நினைவூட்டு
कल 7 बजे दवा लेने की याद दिलाना
```

And it admits when it can't work out a time:

```
remind me about something
```

**What to say:** the time is parsed into a real `due_at` datetime rather
than stored as the free-text label it used to be — a reminder you can't
compare to a clock can never go off. Each one fires exactly once, tracked
server-side, so it survives a page reload.

### 7. Breadth: seven more domains, all cited

Type these. Every answer carries the official portal as a source chip and
a "confirm the current details on <portal>" note in the user's own
language.

```
how do I apply for a scholarship
I want to open a bank account
someone is asking for my otp
I lost money in an online fraud
how to book a train ticket
which government scheme can I apply for
looking for a government job
nearest hospital
```

And in the other languages — same entries, same citations:

```
உதவித்தொகைக்கு எப்படி விண்ணப்பிக்க வேண்டும்
ऑनलाइन धोखाधड़ी में पैसे चले गए
ప్రభుత్వ ఉద్యోగం కావాలి
ಸರ್ಕಾರಿ ಯೋಜನೆ ಬಗ್ಗೆ ಹೇಳಿ
```

**What to say:** none of these portals has a free public API, so this is
curated text, not a lookup — and the interesting part is what the curation
is *not allowed* to contain. Three rules are enforced by tests, not by
review: no rupee amounts or percentages (the figures that go stale), no
eligibility verdicts, and every entry cited and translated into all five
languages. Ask myScheme's answer to name the eligibility rules and it
refuses on purpose: getting one wrong costs someone an application.

**The one to demo if you only demo one:** `I lost money in an online fraud`
— it names 1930 and the cyber crime portal, and says to call the bank
within the hour. That is an answer with a deadline attached.

### 8. Mandi prices (live, if you've set a key)

```
tomato mandi price
தக்காளி சந்தை விலை என்ன
प्याज मंडी भाव
```

Without a `DATA_GOV_API_KEY` it says live prices aren't switched on and
points at agmarknet.gov.in. With a key it returns real markets as a
bulleted list, a min–max range, the modal price and the dataset's own
arrival date — cheapest market first.

Set the key in the root `.env` if you're demoing through `docker compose`,
or `backend/.env` if you're running uvicorn directly (README → "Turning on
live mandi prices"). If you're unsure which is live, `docker compose exec
backend printenv DATA_GOV_API_KEY` settles it in one line.

**What to say:** this upstream was measured failing in two different ways —
a 45s timeout then 504 then 502 on one day, and an HTTP **200** carrying
`{"error": "Rate limit exceeded"}` on another. That second one is the
interesting case: a successful request is not a successful lookup, and
rendering that body as data would have shown "Rate limit exceeded" where a
price belongs. Ask what happens when it fails: nothing is invented, and the
crop name comes back in the user's language rather than AGMARKNET's
internal spelling, `Paddy(Dhan)(Common)`.

### 9. It explains itself, honestly

```
what is BharatVoice AI
why would I use this instead of ChatGPT
which languages do you support
does it work offline
is my data safe
where do you get your information
what if you don't understand me
```

**What to say:** this is the part most projects get wrong by overclaiming.
Ask the ChatGPT question in front of the examiner: the answer opens with
"it is not more capable than a general assistant" and says to use a general
assistant for general knowledge. The offline answer is "No." The privacy
answer states that conversations go into an unauthenticated database, that
spoken audio goes to Google when you use Chrome, and that place names go to
Open-Meteo — then tells you not to type your Aadhaar number.

Sixteen restraint tests in `tests/test_about.py` enforce this: no body may
contain "more accurate", "more private", "better than", "fully supported"
or "works offline", the comparison answer must contain the phrase "not more
capable", and the privacy answer must name all three places data goes.

The languages answer is *generated* from `about.LANGUAGE_SUPPORT`, so it
cannot claim a language is in better shape than the source records — flip
Telugu to reviewed in that table and the spoken answer changes with it.

### 10. Robustness (if asked)

```
remind me on 3/4/2026 to renew my passport
```

Sets a reminder and captures the date. Previously the arithmetic parser
read `3/4/2026` as a division and answered "That's 0.000371", silently
dropping the reminder.

```
9**9**9**9
```

Returns a normal reply. Exponentiation is rejected rather than evaluated —
on an unauthenticated endpoint it's a one-request denial of service.

## Questions you should expect, and honest answers

**"Is this really four languages?"**
Identification, understanding and replies, yes — verified end to end. The
Hindi, Telugu and Kannada *wording* has not been reviewed by a native
speaker; every such string is marked `# NEEDS REVIEW` in the source.

**"How accurate is the speech recognition?"**
That's the browser's Web Speech API, not ours, and it takes one locale at a
time — so users pick their language from the header. We have not measured
its per-language accuracy, and saying otherwise would be inventing a
number. Server-side ASR (Bhashini, free for non-commercial use, 22
languages) is the planned upgrade and would also enable automatic
spoken-language detection.

**"What happens when the microphone doesn't work?"**
It says so, which it did not use to. Block the microphone in site settings
and tap the orb: you get "Microphone access is blocked — tap the padlock in
your browser's address bar…" rather than an orb that appears to do nothing.
Every failure the API can report has its own message — no capture device,
speech service unreachable, recognition language unsupported, session never
started — and the orb returns to idle instead of pretending to listen.

**"Why doesn't it read the Tamil answer aloud on this laptop?"**
Because the device has no Tamil voice installed, and the app now says that
under the answer instead of going quiet. Voices are an operating-system
thing (Windows: Settings → Time & Language → Speech). The reply is always
shown in full as text, so a missing voice costs nothing but the audio.

**"Why doesn't it answer health questions?"**
Deliberate. Health, eligibility and financial advice are where a wrong
answer does real harm, so the assistant only returns curated, cited content
and declines otherwise.

**"What about the other domains in the proposal?"**
All of them answer now, in one of three ways. Weather and mandi prices are
live API adapters. Education, banking, scam awareness and travel are
curated cited text. Schemes, jobs and health facilities are cited deep
links that say plainly the assistant cannot search them — because NCS sits
behind a session, the Health Facility Registry needs ABDM onboarding, and
myScheme has no documented public API.

**"Why not just scrape the portals?"**
Because the markup changes without notice and the terms are restrictive or
absent — but mostly because a scraped paraphrase of a government
eligibility rule goes stale silently, and someone acts on it. The honest
failure is cheaper than the confident wrong answer.

## Known limitations — state these before you're asked

- Telugu and Kannada wording is unreviewed. So is the new Hindi.
- Reminders fire via 30-second polling, not push — they need the tab open.
  Background delivery needs user accounts and a service worker.
- Mandi prices need a free data.gov.in key. The key now reaches the
  container (Compose forwards it; that passthrough is tested), but the
  field mapping has still not been confirmed against a live response — no
  successful call has been possible without a key.
- Jobs, hospitals and scheme *search* are deep links, not lookups.
- Helpline numbers are only tappable as their own row, not mid-sentence.
- Voice failure messages are English only — they describe browser UI, and a
  machine translation would describe it wrongly.
- Spoken replies need a voice for that language installed on the device.
- Speech recognition has not been tested with a real microphone in all five
  languages; only the failure paths have.
- No authentication; all conversations and reminders are global.
- No screen-reader testing on a real device.
