/*
 * BharatVoice service worker — reminder notifications only.
 *
 * It exists so a reminder can arrive when the BharatVoice tab is closed:
 * the backend sends a web push (backend/app/services/push.py), the browser
 * wakes this worker, and the worker shows a system notification.
 *
 * It deliberately does nothing else. There is no fetch handler and no
 * caching, so it cannot serve a stale copy of the app or of an answer —
 * and "does it work offline?" keeps the honest answer it has today.
 */

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

const TITLES = {
  en: "Reminder",
  ta: "நினைவூட்டல்",
  hi: "रिमाइंडर",
  te: "రిమైండర్",
  kn: "ಜ್ಞಾಪನೆ",
};

self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { text: event.data ? event.data.text() : "" };
  }
  if (data.type !== "reminder" || !data.text) return;

  event.waitUntil(
    (async () => {
      const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      const visible = windows.filter((client) => client.visibilityState === "visible");

      // If the app is open and on screen, let the page handle it: it shows
      // the in-app alert and reads the reminder aloud, which a system
      // notification cannot do. Showing both would announce it twice.
      if (visible.length > 0) {
        visible.forEach((client) => client.postMessage({ type: "reminder", reminder: data }));
        return;
      }

      const language = (data.language || "en").split("-")[0];
      await self.registration.showNotification(TITLES[language] || TITLES.en, {
        body: data.text,
        tag: `reminder-${data.id}`, // a retried push replaces, not duplicates
        lang: language,
        requireInteraction: true, // stays until dismissed; a reminder that vanishes is missed
        data: { id: data.id },
      });
    })()
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    (async () => {
      const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      if (windows.length > 0) return windows[0].focus();
      return self.clients.openWindow("/");
    })()
  );
});
