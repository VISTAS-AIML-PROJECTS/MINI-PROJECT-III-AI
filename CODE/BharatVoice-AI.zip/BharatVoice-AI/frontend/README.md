# BharatVoice AI — Frontend

A modern, responsive React chat UI for the BharatVoice AI multilingual
assistant, with voice input/output, live waveform visualization, and light/
dark themes.

## Quick start

```bash
cd frontend
npm install
npm run dev
```

Opens at `http://localhost:5173`. The dev server proxies `/api/*` requests
to the FastAPI backend at `http://localhost:8000` (see `vite.config.js`) —
start the backend first (see `../backend/README.md`).

## How voice works out of the box

Voice input and output use the **browser's native Web Speech APIs**
(`SpeechRecognition` for input, `SpeechSynthesis` for output) — this means
the full voice experience works immediately, with zero backend ML
dependencies, in any Chromium-based browser (Chrome, Edge).

If the backend has Whisper/Coqui TTS installed (see backend README), the
chat response can include a server-generated `audio_url`, which the UI will
prefer over the browser's synthesis automatically — no frontend changes
needed to benefit from the upgrade.

## Design system

The visual identity is deliberately drawn from South Indian textile and
temple-architecture motifs rather than generic "AI chat app" defaults:

- **Palette** — deep indigo (Madras-check ink) as the grounding tone,
  marigold/turmeric as the primary action accent, peacock teal as the
  assistant's secondary identity color.
- **Type** — Fraunces (display) paired with Plus Jakarta Sans (UI/body) and
  Noto Sans Tamil for Tamil script legibility.
- **Signature element** — the voice waveform is rendered as a *kolam*
  (dot-grid rangoli) pattern that pulses outward with live microphone
  volume, and the assistant avatar is framed by a simplified *gopuram*
  (temple gateway) silhouette.

All tokens live in `src/theme.css`; component/layout styles are in
`src/index.css`.

## Project structure

```
frontend/
├── src/
│   ├── App.jsx                     # Top-level state: conversations, messages, send/receive
│   ├── main.jsx                    # React root, ThemeProvider
│   ├── theme.css                   # Design tokens (colors, type, radius) — light + dark
│   ├── index.css                   # Layout & component styles, responsive rules
│   ├── components/
│   │   ├── AssistantOrb.jsx        # Voice-first home surface (tap to talk)
│   │   ├── SuggestionChips.jsx     # Quick-tap prompts, localized per language
│   │   ├── ChatWindow.jsx          # Message list + empty state
│   │   ├── ChatBubble.jsx          # Single message bubble + NLU trace chips
│   │   ├── InputBar.jsx            # Text input + send + mic button
│   │   ├── MicButton.jsx           # Animated mic / waveform button
│   │   ├── Waveform.jsx            # Kolam dot-grid waveform (signature visual)
│   │   ├── AssistantAvatar.jsx     # Gopuram-framed avatar
│   │   ├── LanguageToggle.jsx      # Header language selector (Auto/ta/hi/te/kn/en)
│   │   ├── LanguageIndicator.jsx   # Detected-language badge per message
│   │   ├── HistoryDrawer.jsx       # Conversation history (slide-out drawer)
│   │   ├── RemindersPanel.jsx      # Saved reminders (slide-out drawer)
│   │   └── ThemeToggle.jsx         # Light/dark switch
│   ├── hooks/
│   │   ├── useSpeechRecognition.js # Browser STT + live volume meter
│   │   └── useSpeechSynthesis.js   # Browser TTS
│   ├── context/
│   │   └── ThemeContext.jsx        # Light/dark theme state, persisted
│   └── services/
│       └── api.js                  # Axios client for the FastAPI backend
├── index.html
├── package.json
└── vite.config.js
```

## Notes

- Browser support: voice input requires Chrome or Edge (Web Speech API
  isn't implemented in Firefox/Safari at the time of writing) — typing
  always works everywhere, and the UI shows a clear hint when voice isn't
  supported.
- Recognition language toggle (த / EN) sets the locale hint the browser
  uses for speech recognition; the backend's own language detector then
  re-confirms the language (or "ta-en" for code-mixed) from the transcribed
  text independently.
