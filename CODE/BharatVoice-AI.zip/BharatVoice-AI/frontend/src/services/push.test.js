import { describe, expect, it } from "vitest";
import { decodeKey, getPushStatus, isPushSupported, onPushedReminder } from "./push";

describe("decodeKey", () => {
  it("decodes base64url, including the characters plain base64 lacks", () => {
    // "-_" are base64url for "+/": bytes 0xfb 0xff.
    expect(Array.from(decodeKey("-_8"))).toEqual([0xfb, 0xff]);
  });

  it("handles a real 65-byte VAPID public key without padding", () => {
    const bytes = new Uint8Array(65).fill(7);
    bytes[0] = 4;
    const base64url = btoa(String.fromCharCode(...bytes))
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");
    const decoded = decodeKey(base64url);
    expect(decoded).toHaveLength(65);
    expect(decoded[0]).toBe(4);
  });
});

describe("without push support (jsdom has none)", () => {
  it("reports unsupported instead of throwing", async () => {
    expect(isPushSupported()).toBe(false);
    expect(await getPushStatus()).toBe("unsupported");
  });

  it("makes listening for pushed reminders a harmless no-op", () => {
    const stop = onPushedReminder(() => {});
    expect(() => stop()).not.toThrow();
  });
});
