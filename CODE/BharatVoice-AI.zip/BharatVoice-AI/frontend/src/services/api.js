import axios from "axios";
import { clearSession, identityHeaders } from "./identity";

// In dev, Vite proxies /api -> http://localhost:8000 (see vite.config.js)
const api = axios.create({
  baseURL: "/api",
  timeout: 20000,
});

// Every request says who it is from (see identity.js), so history and
// reminders are this browser's or this account's rather than everyone's.
api.interceptors.request.use((config) => {
  Object.assign(config.headers, identityHeaders());
  return config;
});

// A 401 on anything but the sign-in form means the stored session has
// expired. Drop it and tell the app, which falls back to guest — otherwise
// every later request would keep failing with the same dead token.
let onSessionExpired = () => {};
export function setSessionExpiredHandler(handler) {
  onSessionExpired = handler;
}

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const url = error?.config?.url || "";
    if (error?.response?.status === 401 && !url.startsWith("/auth/")) {
      clearSession();
      onSessionExpired();
    }
    return Promise.reject(error);
  }
);

/** Create an account. Resolves to { token, user }. */
export async function register({ username, password }) {
  const { data } = await api.post("/auth/register", { username, password });
  return data;
}

/** Sign in. Resolves to { token, user }. */
export async function login({ username, password }) {
  const { data } = await api.post("/auth/login", { username, password });
  return data;
}

/** End this sign-in on the server. */
export async function logout() {
  await api.post("/auth/logout");
}

/** Send a chat message (already-transcribed text) and get the AI's reply + NLU trace. */
export async function sendChatMessage({ text, conversationId, languageHint }) {
  const { data } = await api.post("/chat", {
    text,
    conversation_id: conversationId || null,
    language_hint: languageHint || null,
  });
  return data;
}

/** Upload recorded audio for server-side transcription (used only if Whisper is installed). */
export async function transcribeAudio(blob) {
  const form = new FormData();
  form.append("file", blob, "recording.webm");
  const { data } = await api.post("/speech/transcribe", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data;
}

/**
 * What the server can speak, per language: { languages: {ta: "bhashini"|null, …},
 * bhashini_configured, coqui_installed, any }.
 *
 * Asked once at startup. Combined with the browser's own voice list it is
 * everything needed to tell the user the truth about a language *before*
 * attempting playback — which is the difference between "no Tamil voice
 * here, so here's the text" and unexplained silence.
 */
export async function getSpeechCapabilities() {
  const { data } = await api.get("/speech/capabilities");
  return data;
}

/**
 * Server-side synthesis, used only when the device has no voice for the
 * language. Returns { audio_url, engine }; `audio_url: null` is a normal
 * answer meaning no server engine covers this language either.
 *
 * Its own timeout: synthesis is slower than a text reply, and the shared
 * 20s ceiling is already generous for chat.
 */
export async function synthesizeSpeech({ text, language }) {
  const { data } = await api.post(
    "/speech/synthesize",
    { text, language },
    { timeout: 30000 }
  );
  return data;
}

/** Fetch the list of past conversations for the sidebar. */
export async function listConversations() {
  const { data } = await api.get("/history/conversations");
  return data;
}

/** Fetch full message history for one conversation. */
export async function getConversation(conversationId) {
  const { data } = await api.get(`/history/conversations/${conversationId}`);
  return data;
}

/** Delete a conversation. */
export async function deleteConversation(conversationId) {
  const { data } = await api.delete(`/history/conversations/${conversationId}`);
  return data;
}

/** Fetch all saved reminders. */
export async function listReminders() {
  const { data } = await api.get("/reminders");
  return data;
}

/**
 * Reminders whose time has arrived and that haven't been shown yet.
 * The backend marks each as notified when it returns it, so a reminder
 * fires exactly once rather than on every poll.
 */
export async function listDueReminders() {
  const { data } = await api.get("/reminders/due");
  return data;
}

/** Mark a reminder as done. */
export async function markReminderDone(reminderId) {
  const { data } = await api.patch(`/reminders/${reminderId}/done`);
  return data;
}

/** Delete a reminder. */
export async function deleteReminder(reminderId) {
  const { data } = await api.delete(`/reminders/${reminderId}`);
  return data;
}

export default api;
