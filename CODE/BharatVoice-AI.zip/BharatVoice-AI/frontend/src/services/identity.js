/**
 * Who this browser is, as far as the backend is concerned.
 *
 * Two things are kept in localStorage:
 *
 *   - a guest id, generated once. It is sent on every request as
 *     `X-Guest-Id`, which gives this browser its own private history and
 *     reminders without anyone having to create an account.
 *   - a session token, present only after signing in. When it exists it is
 *     sent as `Authorization: Bearer …` and takes precedence.
 *
 * Every access is wrapped: Safari private mode throws on write, and a
 * browser with storage disabled should degrade to "shared, unsaved
 * identity" rather than a blank page.
 */
const GUEST_KEY = "bv.guestId";
const TOKEN_KEY = "bv.token";
const USER_KEY = "bv.user";

function read(key) {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function write(key, value) {
  try {
    if (value === null) localStorage.removeItem(key);
    else localStorage.setItem(key, value);
  } catch {
    /* storage unavailable: the identity lasts for this page load only */
  }
}

function randomId() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

let memoryGuestId = null;

export function getGuestId() {
  let id = read(GUEST_KEY) || memoryGuestId;
  if (!id) {
    id = randomId();
    memoryGuestId = id;
    write(GUEST_KEY, id);
  }
  return id;
}

export function getToken() {
  return read(TOKEN_KEY);
}

export function getStoredUser() {
  try {
    const raw = read(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function storeSession({ token, user }) {
  write(TOKEN_KEY, token);
  write(USER_KEY, JSON.stringify(user));
}

export function clearSession() {
  write(TOKEN_KEY, null);
  write(USER_KEY, null);
}

/** The headers that identify this caller. Signed in wins over guest, but
 *  the guest id is still sent so sign-in can adopt the guest's history. */
export function identityHeaders() {
  const headers = { "X-Guest-Id": getGuestId() };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
}
