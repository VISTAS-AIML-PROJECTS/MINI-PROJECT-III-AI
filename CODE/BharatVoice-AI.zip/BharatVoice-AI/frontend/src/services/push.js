/**
 * Reminder notifications that arrive with the app closed.
 *
 * The browser side of backend/app/services/push.py: register the service
 * worker, ask permission, subscribe with the server's public key, and tell
 * the server about the subscription.
 *
 * `getPushStatus()` reports one of:
 *   "unsupported"  this browser has no push (or the page is not secure)
 *   "unavailable"  the server cannot send push
 *   "blocked"      the user denied notification permission
 *   "off"          available, not enabled
 *   "on"           enabled on this browser
 * so the UI can say which, instead of showing a button that does nothing.
 */
import api from "./api";

export function isPushSupported() {
  return Boolean(
    typeof window !== "undefined" &&
      window.isSecureContext &&
      "serviceWorker" in navigator &&
      "PushManager" in window &&
      "Notification" in window
  );
}

/** base64url -> the Uint8Array `pushManager.subscribe` wants. */
export function decodeKey(base64url) {
  const padded = base64url + "=".repeat((4 - (base64url.length % 4)) % 4);
  const raw = atob(padded.replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from(raw, (ch) => ch.charCodeAt(0));
}

async function registration() {
  return navigator.serviceWorker.register("/sw.js");
}

async function currentSubscription() {
  const existing = await navigator.serviceWorker.getRegistration("/");
  return existing ? existing.pushManager.getSubscription() : null;
}

export async function getPushStatus() {
  if (!isPushSupported()) return "unsupported";
  if (Notification.permission === "denied") return "blocked";
  try {
    if (await currentSubscription()) return "on";
    const { data } = await api.get("/push/public-key");
    return data.enabled ? "off" : "unavailable";
  } catch {
    return "unavailable";
  }
}

/** Turn notifications on. Must be called from a click: browsers only show
 *  the permission prompt in response to a user gesture. */
export async function enablePush() {
  if (!isPushSupported()) return "unsupported";

  const permission = await Notification.requestPermission();
  if (permission !== "granted") return permission === "denied" ? "blocked" : "off";

  const { data } = await api.get("/push/public-key");
  if (!data.enabled) return "unavailable";

  const reg = await registration();
  await navigator.serviceWorker.ready;
  const subscription =
    (await reg.pushManager.getSubscription()) ||
    (await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: decodeKey(data.key),
    }));

  await api.post("/push/subscribe", subscription.toJSON());
  return "on";
}

export async function disablePush() {
  const subscription = await currentSubscription();
  if (!subscription) return "off";
  try {
    await api.post("/push/unsubscribe", { endpoint: subscription.endpoint });
  } finally {
    // Unsubscribe locally even if the server could not be told: the user
    // asked for notifications to stop, and this is what stops them.
    await subscription.unsubscribe();
  }
  return "off";
}

/**
 * Re-send this browser's subscription under whoever is signed in now.
 * Called after signing in or out, so reminders follow the person and stop
 * arriving for the previous one. A no-op when notifications are off.
 */
export async function syncPushOwner() {
  if (!isPushSupported()) return;
  try {
    const subscription = await currentSubscription();
    if (subscription) await api.post("/push/subscribe", subscription.toJSON());
  } catch {
    /* best effort: the next enable or sign-in will correct it */
  }
}

/** Listen for reminders the service worker hands to an open page. */
export function onPushedReminder(handler) {
  if (!isPushSupported()) return () => {};
  const listener = (event) => {
    if (event.data?.type === "reminder" && event.data.reminder) handler(event.data.reminder);
  };
  navigator.serviceWorker.addEventListener("message", listener);
  return () => navigator.serviceWorker.removeEventListener("message", listener);
}
