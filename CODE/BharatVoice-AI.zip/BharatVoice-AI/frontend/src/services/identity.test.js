import { describe, expect, it, vi } from "vitest";
import {
  clearSession,
  getGuestId,
  getStoredUser,
  getToken,
  identityHeaders,
  storeSession,
} from "./identity";

describe("guest id", () => {
  it("is generated once and then reused", () => {
    const first = getGuestId();
    expect(getGuestId()).toBe(first);
    expect(localStorage.getItem("bv.guestId")).toBe(first);
  });

  it("has the shape the backend accepts", () => {
    // backend/app/services/auth.py: ^[A-Za-z0-9_-]{16,64}$
    expect(getGuestId()).toMatch(/^[A-Za-z0-9_-]{16,64}$/);
  });

  it("still works when storage throws, as in Safari private mode", () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
      throw new Error("denied");
    });
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new Error("denied");
    });
    const id = getGuestId();
    expect(id).toMatch(/^[A-Za-z0-9_-]{16,64}$/);
    expect(getGuestId()).toBe(id); // stable for the page load
  });
});

describe("session", () => {
  const session = { token: "tok-123", user: { id: "u1", username: "kavya" } };

  it("round-trips through storage", () => {
    storeSession(session);
    expect(getToken()).toBe("tok-123");
    expect(getStoredUser()).toEqual(session.user);
  });

  it("is gone after clearSession", () => {
    storeSession(session);
    clearSession();
    expect(getToken()).toBeNull();
    expect(getStoredUser()).toBeNull();
  });

  it("treats a corrupted stored user as signed out, not a crash", () => {
    localStorage.setItem("bv.user", "{not json");
    expect(getStoredUser()).toBeNull();
  });
});

describe("identityHeaders", () => {
  it("sends only the guest id when signed out", () => {
    const headers = identityHeaders();
    expect(headers["X-Guest-Id"]).toBe(getGuestId());
    expect(headers.Authorization).toBeUndefined();
  });

  it("sends both when signed in, so sign-in can adopt guest history", () => {
    storeSession({ token: "tok-123", user: { id: "u1", username: "kavya" } });
    const headers = identityHeaders();
    expect(headers.Authorization).toBe("Bearer tok-123");
    expect(headers["X-Guest-Id"]).toBe(getGuestId());
  });
});
