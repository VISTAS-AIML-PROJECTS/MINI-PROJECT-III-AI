import { BellRing, Check, X } from "lucide-react";

/**
 * Shown when a reminder's time arrives.
 *
 * Reminders used to be saveable and listable but could never actually go
 * off, because the time was stored as free text. Now the backend parses a
 * real `due_at`, the app polls `/api/reminders/due`, and this is what the
 * user sees when one fires.
 *
 * It is a banner rather than a browser notification on purpose: the
 * Notifications API needs a permission prompt, is blocked by default on
 * many Android browsers, and would silently do nothing for exactly the
 * users this project is for. A banner works everywhere.
 */
export default function ReminderAlert({ reminder, onDone, onDismiss }) {
  if (!reminder) return null;

  return (
    <div className="reminder-alert" role="alert">
      <span className="reminder-alert__icon" aria-hidden="true">
        <BellRing size={18} />
      </span>

      <div className="reminder-alert__body">
        <span className="reminder-alert__label">Reminder</span>
        <span className="reminder-alert__text">{reminder.text}</span>
      </div>

      <div className="reminder-alert__actions">
        <button
          type="button"
          className="reminder-alert__btn reminder-alert__btn--primary"
          onClick={() => onDone(reminder.id)}
          aria-label="Mark reminder done"
          title="Done"
        >
          <Check size={16} />
        </button>
        <button
          type="button"
          className="reminder-alert__btn"
          onClick={onDismiss}
          aria-label="Dismiss reminder"
          title="Dismiss"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
}
