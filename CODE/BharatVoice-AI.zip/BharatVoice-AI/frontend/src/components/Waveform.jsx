import { useMemo } from "react";

/**
 * Signature visual element: a voice waveform rendered as a kolam
 * (South Indian dot-grid rangoli) pattern instead of a generic bar
 * equalizer. Dots pulse in size/opacity driven by live mic volume,
 * radiating outward from the center the way a kolam is drawn from a
 * central point outward.
 *
 * `volume` is 0..1. `active` toggles the idle vs. listening visual state.
 */
export default function Waveform({ volume = 0, active = false, size = 120 }) {
  // Generate a diamond kolam dot grid: rows of dots forming a rhombus.
  const dots = useMemo(() => {
    const rows = 7;
    const points = [];
    const center = (rows - 1) / 2;
    for (let row = 0; row < rows; row++) {
      const distFromCenter = Math.abs(row - center);
      const cols = rows - distFromCenter * 2;
      const start = (rows - cols) / 2;
      for (let col = 0; col < cols; col++) {
        const x = start + col;
        const ring = Math.max(Math.abs(x - center), Math.abs(row - center));
        points.push({ x, y: row, ring });
      }
    }
    return points;
  }, []);

  const grid = 7;
  const cell = size / grid;

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      width={size}
      height={size}
      role="img"
      aria-label={active ? "Listening — voice waveform active" : "Microphone idle"}
    >
      {dots.map((d, i) => {
        // Outer rings pulse a beat later than the center for a "breathing
        // outward" effect synced to the kolam's natural drawing order.
        const delay = d.ring * 0.06;
        const baseR = active ? 2.4 : 1.6;
        const pulseR = active ? baseR + volume * 3.2 : baseR;
        return (
          <circle
            key={i}
            cx={d.x * cell + cell / 2}
            cy={d.y * cell + cell / 2}
            r={pulseR}
            fill={active ? "var(--accent-primary)" : "var(--text-muted)"}
            opacity={active ? 0.55 + volume * 0.45 : 0.35}
            style={{
              transition: `r 120ms ease-out ${delay}s, opacity 120ms ease-out ${delay}s, fill 200ms ease`,
            }}
          />
        );
      })}
    </svg>
  );
}
