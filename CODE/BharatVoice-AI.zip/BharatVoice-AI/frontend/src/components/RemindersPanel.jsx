import { X, Bell, Check, Trash2 } from "lucide-react";
import PushToggle from "./PushToggle";

/**
 * Reminders are now real, persisted records (see backend/app/models.py ->
 * Reminder) rather than a demo confirmation message that vanished. This
 * panel lets a person see and manage everything they've asked BharatVoice
 * to remember, independent of any single conversation.
 */
export default function RemindersPanel({ open, onClose, reminders, loading, onMarkDone, onDelete }) {
  return (
    <>
      <div
        className={`drawer-backdrop ${open ? "drawer-backdrop--visible" : ""}`}
        onClick={onClose}
        aria-hidden="true"
      />
      {/* See HistoryDrawer: `inert` keeps the closed panel out of the tab
          order instead of leaving invisible buttons focusable. */}
      <aside
        className={`drawer drawer--right ${open ? "drawer--open" : ""}`}
        aria-hidden={!open}
        inert={open ? undefined : ""}
      >
        <div className="drawer__header">
          <span className="drawer__title">
            <Bell size={16} /> Reminders
          </span>
          <button className="icon-btn" onClick={onClose} aria-label="Close reminders">
            <X size={18} />
          </button>
        </div>

        <PushToggle visible={open} />

        <div className="reminders-list">
          {loading && <p className="drawer__empty">Loading…</p>}
          {!loading && reminders.length === 0 && (
            <p className="drawer__empty">
              No reminders yet — try saying "remind me to call amma at 6pm".
            </p>
          )}
          {reminders.map((r) => (
            <div key={r.id} className={`reminder-item ${r.is_done === "done" ? "reminder-item--done" : ""}`}>
              <div className="reminder-item__body">
                {r.when_label && <span className="reminder-item__when">{r.when_label}</span>}
                <span className="reminder-item__text">
                  {r.person ? `${r.person} — ` : ""}
                  {r.text}
                </span>
              </div>
              <div className="reminder-item__actions">
                {r.is_done !== "done" && (
                  <button
                    className="icon-btn icon-btn--ghost"
                    onClick={() => onMarkDone(r.id)}
                    aria-label="Mark reminder done"
                    title="Mark done"
                  >
                    <Check size={15} />
                  </button>
                )}
                <button
                  className="icon-btn icon-btn--ghost"
                  onClick={() => onDelete(r.id)}
                  aria-label="Delete reminder"
                  title="Delete"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </aside>
    </>
  );
}
