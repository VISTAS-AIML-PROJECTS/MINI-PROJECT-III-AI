import { useEffect, useRef } from "react";
import ChatBubble from "./ChatBubble";
import AssistantAvatar from "./AssistantAvatar";

/**
 * Scrollable message list. Auto-scrolls to the latest message and shows a
 * "typing" indicator while waiting on the backend, plus an inviting empty
 * state on first load.
 */
export default function ChatWindow({ messages, isThinking, onSpeak, voiceState, speakingId }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, isThinking]);

  if (messages.length === 0 && !isThinking) {
    return (
      // No greeting here any more. A screen that opens by saying hello in
      // one of five languages has to pick one, and the useful thing to put
      // in that space is what to do next.
      <div className="chat-empty">
        <AssistantAvatar size={64} />
        <h2>Ask in your language</h2>
        <p>
          Pick your language from the header, then tap the microphone and speak — or
          type below. Tamil, Hindi, Telugu, Kannada and English all work.
        </p>
        <div className="chat-empty__suggestions">
          <span>“இன்று சென்னையில் வானிலை எப்படி இருக்கும்?”</span>
          <span>“Remind me to call Amma at 6pm tomorrow”</span>
          <span>“What is BharatVoice AI?”</span>
        </div>
      </div>
    );
  }

  return (
    <div className="chat-window">
      {messages.map((m) => (
        <ChatBubble
          key={m.id}
          message={m}
          onSpeak={onSpeak}
          // Only the reply actually playing gets the live state; every other
          // bubble stays idle so exactly one shows a stop control.
          voiceState={m.id === speakingId ? voiceState : "idle"}
        />
      ))}

      {isThinking && (
        <div className="chat-row chat-row--assistant">
          <AssistantAvatar size={32} />
          <div className="chat-bubble chat-bubble--assistant chat-bubble--thinking">
            <span className="thinking-dot" />
            <span className="thinking-dot" />
            <span className="thinking-dot" />
          </div>
        </div>
      )}

      <div ref={bottomRef} />
    </div>
  );
}
