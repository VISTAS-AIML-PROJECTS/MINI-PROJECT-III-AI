/**
 * Assistant avatar framed by a simplified gopuram (temple gateway tower)
 * silhouette — a nod to South Indian architecture that also doubles as a
 * subtle "signal tower" metaphor for a voice assistant, avoiding the
 * generic circular-gradient-blob avatar look.
 */
export default function AssistantAvatar({ size = 44, speaking = false }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        position: "relative",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
      aria-hidden="true"
    >
      <svg viewBox="0 0 48 48" width={size} height={size}>
        <defs>
          <linearGradient id="gopuramGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--marigold-500)" />
            <stop offset="100%" stopColor="var(--peacock-500)" />
          </linearGradient>
        </defs>
        {/* Tiered gopuram silhouette */}
        <path
          d="M24 3 L30 10 L18 10 Z"
          fill="url(#gopuramGradient)"
          opacity={speaking ? 1 : 0.9}
        />
        <rect x="15" y="10" width="18" height="4" rx="1" fill="url(#gopuramGradient)" opacity="0.85" />
        <path d="M24 8 L27.5 14 L20.5 14 Z" fill="url(#gopuramGradient)" opacity="0.75" />
        <rect x="10" y="18" width="28" height="24" rx="6" fill="var(--bg-surface-raised)" stroke="var(--border-strong)" strokeWidth="1.5" />
        {/* Simple face — two eyes as dots, a soft smile arc */}
        <circle cx="19" cy="29" r={speaking ? 2 : 1.6} fill="var(--accent-primary)">
          {speaking && (
            <animate attributeName="r" values="1.6;2.4;1.6" dur="0.9s" repeatCount="indefinite" />
          )}
        </circle>
        <circle cx="29" cy="29" r={speaking ? 2 : 1.6} fill="var(--accent-primary)">
          {speaking && (
            <animate attributeName="r" values="1.6;2.4;1.6" dur="0.9s" begin="0.15s" repeatCount="indefinite" />
          )}
        </circle>
        <path d="M18 34 Q24 38 30 34" stroke="var(--accent-secondary)" strokeWidth="2" fill="none" strokeLinecap="round" />
      </svg>
    </div>
  );
}
