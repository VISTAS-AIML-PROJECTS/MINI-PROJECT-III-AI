import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import AccountPanel, { describeError } from "./AccountPanel";

function renderPanel(props = {}) {
  const handlers = {
    onClose: vi.fn(),
    onLogin: vi.fn().mockResolvedValue(undefined),
    onRegister: vi.fn().mockResolvedValue(undefined),
    onLogout: vi.fn(),
  };
  render(<AccountPanel open user={null} {...handlers} {...props} />);
  return handlers;
}

function fill(username, password) {
  fireEvent.change(screen.getByLabelText("Username"), { target: { value: username } });
  fireEvent.change(screen.getByLabelText("Password"), { target: { value: password } });
}

describe("AccountPanel", () => {
  it("says an account is optional", () => {
    renderPanel();
    expect(screen.getByText(/You don't need an account/)).toBeInTheDocument();
  });

  it("signs in with the trimmed username", async () => {
    const { onLogin, onRegister } = renderPanel();
    fill("  kavya ", "correct horse");
    fireEvent.click(screen.getByRole("button", { name: "Sign in" }));
    await waitFor(() =>
      expect(onLogin).toHaveBeenCalledWith({ username: "kavya", password: "correct horse" })
    );
    expect(onRegister).not.toHaveBeenCalled();
  });

  it("registers after switching mode", async () => {
    const { onLogin, onRegister } = renderPanel();
    fireEvent.click(screen.getByRole("button", { name: /Create an account/ }));
    fill("kavya", "correct horse");
    fireEvent.click(screen.getByRole("button", { name: "Create account" }));
    await waitFor(() => expect(onRegister).toHaveBeenCalled());
    expect(onLogin).not.toHaveBeenCalled();
  });

  it("shows the server's own message when sign-in is refused", async () => {
    renderPanel({
      onLogin: vi.fn().mockRejectedValue({
        response: { status: 401, data: { detail: "That username and password don't match." } },
      }),
    });
    fill("kavya", "wrong password");
    fireEvent.click(screen.getByRole("button", { name: "Sign in" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("don't match");
  });

  it("clears the password after a successful sign-in", async () => {
    renderPanel();
    fill("kavya", "correct horse");
    fireEvent.click(screen.getByRole("button", { name: "Sign in" }));
    await waitFor(() => expect(screen.getByLabelText("Password")).toHaveValue(""));
  });

  it("shows who is signed in, and signs out", () => {
    const { onLogout } = renderPanel({ user: { id: "u1", username: "kavya" } });
    expect(screen.getByText("kavya")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Sign out/ }));
    expect(onLogout).toHaveBeenCalled();
  });
});

describe("describeError", () => {
  it("uses the backend's sentence when there is one", () => {
    expect(describeError({ response: { data: { detail: "That username is already taken." } } })).toBe(
      "That username is already taken."
    );
  });

  it("turns a validation error into something a person can act on", () => {
    const error = { response: { data: { detail: [{ loc: ["body", "password"], msg: "too short" }] } } };
    expect(describeError(error)).toMatch(/8 characters/);
  });

  it("says the server is unreachable when there is no response", () => {
    expect(describeError(new Error("Network Error"))).toMatch(/reach the server/);
  });
});
