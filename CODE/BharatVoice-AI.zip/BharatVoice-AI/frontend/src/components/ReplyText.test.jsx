import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import ReplyText from "./ReplyText";

describe("ReplyText", () => {
  it("renders nothing for an empty reply", () => {
    const { container } = render(<ReplyText text="" />);
    expect(container).toBeEmptyDOMElement();
  });

  it("renders a short reply as a single paragraph", () => {
    render(<ReplyText text="It is 31°C in Chennai." />);
    expect(screen.getByText("It is 31°C in Chennai.").tagName).toBe("P");
  });

  it("renders helpline rows as tel: links", () => {
    render(<ReplyText text={"Emergency numbers:\n112 — All emergencies\n108 — Ambulance"} />);
    const links = screen.getAllByRole("link");
    expect(links.map((a) => a.getAttribute("href"))).toEqual(["tel:112", "tel:108"]);
  });

  it("renders lists and headings as real structure", () => {
    render(<ReplyText text={"### Steps\n1. Tap the orb\n2. Speak"} />);
    expect(screen.getByRole("heading", { name: "Steps" })).toBeInTheDocument();
    expect(screen.getAllByRole("listitem")).toHaveLength(2);
  });

  it("links a number in a sentence only when the backend marked it", () => {
    const text = "Report it by calling 1930 as soon as you notice it.";

    const { unmount } = render(<ReplyText text={text} />);
    expect(screen.queryByRole("link")).not.toBeInTheDocument();
    unmount();

    render(<ReplyText text={text} dialable={["1930"]} />);
    const link = screen.getByRole("link", { name: "Call 1930" });
    expect(link).toHaveAttribute("href", "tel:1930");
  });

  it("never links a calculator answer, whatever the digits", () => {
    render(<ReplyText text="That's 100." dialable={[]} />);
    expect(screen.queryByRole("link")).not.toBeInTheDocument();
  });

  it("links marked numbers inside list items too", () => {
    render(<ReplyText text={"- call 112 first\n- then 108"} dialable={["112", "108"]} />);
    expect(screen.getAllByRole("link")).toHaveLength(2);
  });
});
