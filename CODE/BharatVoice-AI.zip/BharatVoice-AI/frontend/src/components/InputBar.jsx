import { useEffect, useState } from "react";
import { Send } from "lucide-react";
import MicButton from "./MicButton";
import VoiceStatus from "./VoiceStatus";

/**
 * The bottom input bar in conversation view: text field + send + mic.
 * Speech recognition itself lives in App.jsx (shared with the home screen's
 * orb) and is passed in as `speech`, so both surfaces drive the same mic
 * session instead of racing each other.
 */
export default function InputBar({ onSend, disabled, speech }) {
  const [text, setText] = useState("");
  const {
    isSupported,
    isListening,
    isStarting,
    transcript,
    interimTranscript,
    volume,
    start,
    stop,
    reset,
  } = speech;

  // Stream the recognized speech into the input field live.
  useEffect(() => {
    const combined = [transcript, interimTranscript].filter(Boolean).join(" ");
    if (combined) setText(combined);
  }, [transcript, interimTranscript]);

  const handleSend = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setText("");
    reset();
    if (isListening) stop();
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // The placeholder says one thing: what this box is for. It used to read
  // "Type in தமிழ், English, or mix both…", which wrapped and clipped on a
  // phone and put language guidance somewhere it could not be acted on.
  // Which languages are available is the header toggle's job.
  const placeholder = isStarting
    ? "Starting the microphone…"
    : isListening
    ? "Listening…"
    : "Type your message…";

  return (
    <div className="input-bar">
      <VoiceStatus speech={speech} />

      <div className="input-bar__row">
        <textarea
          className="input-bar__textarea"
          placeholder={placeholder}
          rows={1}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
        />

        <button
          type="button"
          className="icon-btn icon-btn--primary"
          onClick={handleSend}
          disabled={disabled || !text.trim()}
          aria-label="Send message"
          title="Send"
        >
          <Send size={17} />
        </button>

        <MicButton
          isListening={isListening}
          isStarting={isStarting}
          volume={volume}
          onStart={start}
          onStop={stop}
          disabled={disabled || !isSupported}
        />
      </div>

      {!isSupported && (
        <p className="input-bar__hint">
          Voice input isn't supported in this browser — try Chrome or Edge, or just type
          your message.
        </p>
      )}
    </div>
  );
}
