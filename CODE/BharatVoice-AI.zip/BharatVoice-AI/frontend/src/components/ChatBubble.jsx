import { motion } from "framer-motion";
import { Loader2, Square, Volume2 } from "lucide-react";
import AssistantAvatar from "./AssistantAvatar";
import LanguageIndicator from "./LanguageIndicator";
import ReplyText from "./ReplyText";
import SourceList from "./SourceList";

/**
 * A single message bubble. User messages align right (marigold), assistant
 * messages align left (indigo surface) with the avatar + a speak-again
 * control + intent/entity trace for transparency into what the AI understood.
 */
export default function ChatBubble({ message, onSpeak, voiceState = "idle" }) {
  const isUser = message.role === "user";
  // The replay control doubles as a stop control. A button that only starts
  // playback is a dead end halfway through a long answer, and pressing it
  // again to interrupt is what everyone tries first.
  const busy = voiceState === "speaking" || voiceState === "loading";

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className={`chat-row ${isUser ? "chat-row--user" : "chat-row--assistant"}`}
    >
      {!isUser && <AssistantAvatar size={32} />}

      <div className="chat-bubble-stack">
        <div className={`chat-bubble ${isUser ? "chat-bubble--user" : "chat-bubble--assistant"}`}>
          {isUser ? (
            <p className="chat-bubble__text">{message.text}</p>
          ) : (
            <ReplyText text={message.text} dialable={message.dialable} />
          )}

          {!isUser && <SourceList sources={message.sources} staleness={message.staleness} />}

          <div className="chat-bubble__meta">
            {message.language && <LanguageIndicator language={message.language} confidence={message.language_confidence} />}
            {!isUser && (
              <button
                className="icon-btn icon-btn--ghost"
                onClick={() => onSpeak?.(message)}
                aria-label={busy ? "Stop playing this reply" : "Play this reply aloud"}
                title={busy ? "Stop" : "Play aloud"}
              >
                {voiceState === "loading" ? (
                  <Loader2 size={14} className="voice-status__spin" />
                ) : voiceState === "speaking" ? (
                  <Square size={14} />
                ) : (
                  <Volume2 size={14} />
                )}
              </button>
            )}
          </div>
        </div>

        {/* NLU trace: shown only for user messages so the assistant's
            understanding is transparent and debuggable. */}
        {isUser && (message.intent || (message.entities && message.entities.length > 0)) && (
          <div className="nlu-trace">
            {message.intent && (
              <span className="nlu-chip nlu-chip--intent">intent: {message.intent}</span>
            )}
            {message.entities?.map((e, i) => (
              <span key={i} className="nlu-chip">
                {e.type}: {e.value}
              </span>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}
