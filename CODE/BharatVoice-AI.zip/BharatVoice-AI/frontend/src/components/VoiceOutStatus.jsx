import { Loader2, Play, Volume2, VolumeX, X } from "lucide-react";
import { languageName } from "../hooks/useSpeechSynthesis";

/**
 * The state of reading a reply aloud, in words.
 *
 * `VoiceStatus` covers voice *in* (listening, mic errors); this covers voice
 * *out*, which has its own four things that can happen and used to show none
 * of them:
 *
 *   loading      server synthesis is running — seconds, not milliseconds,
 *                so an unexplained pause here reads as a hang
 *   speaking     audio is playing
 *   blocked      the browser refused to autoplay. Recoverable with one tap,
 *                so it gets a button rather than an apology. Previously this
 *                was swallowed by `.catch(() => {})` and produced silence
 *                with nothing on screen at all.
 *   unavailable  no voice for this language anywhere. Names the language and
 *                points at the text, which is still right there.
 *
 * It also takes the pre-emptive case: when autoplay is off, nothing is ever
 * attempted, so nothing sets a notice — but the user still benefits from
 * knowing that pressing replay will not produce sound. `language` enables
 * that check.
 *
 * `role="status"` rather than `role="alert"`: these follow from an action the
 * user just took, and an assertive live region would cut across a screen
 * reader every time a reply arrives.
 */
export default function VoiceOutStatus({ voice, language, className = "" }) {
  const { state, notice, clearNotice, playPending, availability } = voice;

  if (state === "loading") {
    return (
      <div className={`voice-status ${className}`} role="status">
        <Loader2 size={15} className="voice-status__spin" aria-hidden="true" />
        <span className="voice-status__text">Preparing the audio…</span>
      </div>
    );
  }

  if (state === "speaking") {
    return (
      <div className={`voice-status voice-status--live ${className}`} role="status">
        <Volume2 size={15} aria-hidden="true" />
        <span className="voice-status__text">Speaking…</span>
      </div>
    );
  }

  if (notice && state === "blocked") {
    return (
      <div className={`voice-status voice-status--note ${className}`} role="status">
        <VolumeX size={15} aria-hidden="true" />
        <span className="voice-status__text">{notice.message}</span>
        <button
          type="button"
          className="voice-status__action"
          onClick={playPending}
          aria-label="Play this reply aloud"
        >
          <Play size={13} aria-hidden="true" /> Play
        </button>
      </div>
    );
  }

  if (notice) {
    return (
      <div className={`voice-status voice-status--note ${className}`} role="status">
        <VolumeX size={15} aria-hidden="true" />
        <span className="voice-status__text">{notice.message}</span>
        <button
          type="button"
          className="voice-status__dismiss"
          onClick={clearNotice}
          aria-label="Dismiss this message"
        >
          <X size={14} />
        </button>
      </div>
    );
  }

  // Nothing has been attempted. Only speak up when we positively know there
  // is no voice — `via: "unknown"` means the voice list or the server's
  // capability report hasn't answered yet, and claiming a language cannot be
  // spoken and then contradicting it is worse than saying nothing.
  if (language) {
    const { via } = availability(language);
    if (via === null) {
      return (
        <div className={`voice-status voice-status--note ${className}`} role="status">
          <VolumeX size={15} aria-hidden="true" />
          <span className="voice-status__text">
            No {languageName(language)} voice is available on this device or the
            server, so this answer can only be read, not heard.
          </span>
        </div>
      );
    }
  }

  return null;
}
