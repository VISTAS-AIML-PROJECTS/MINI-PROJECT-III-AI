import { X, PlusCircle, MessageSquare, Trash2 } from "lucide-react";

/**
 * Conversation history, now a slide-out drawer rather than a permanently
 * docked sidebar — the voice-first home screen needs the full width, and
 * history becomes an on-demand lookup rather than the default view.
 */
export default function HistoryDrawer({
  open,
  onClose,
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
}) {
  return (
    <>
      <div
        className={`drawer-backdrop ${open ? "drawer-backdrop--visible" : ""}`}
        onClick={onClose}
        aria-hidden="true"
      />
      {/* `inert` (not just aria-hidden) when closed: the drawer stays in the
          DOM off-screen, so without it every button inside remains in the tab
          order and a keyboard user tabs into an invisible panel. aria-hidden
          on a container holding focusable elements is also an accessibility
          violation in its own right. */}
      <aside
        className={`drawer drawer--left ${open ? "drawer--open" : ""}`}
        aria-hidden={!open}
        inert={open ? undefined : ""}
      >
        <div className="drawer__header">
          <span className="drawer__title">Conversations</span>
          <button className="icon-btn" onClick={onClose} aria-label="Close conversations">
            <X size={18} />
          </button>
        </div>

        <button
          className="sidebar__new-btn"
          onClick={() => {
            onNew();
            onClose();
          }}
        >
          <PlusCircle size={17} />
          <span>New conversation</span>
        </button>

        <div className="sidebar__list">
          {conversations.length === 0 && <p className="drawer__empty">No conversations yet.</p>}
          {conversations.map((c) => (
            <div
              key={c.id}
              className={`sidebar__item ${c.id === activeId ? "sidebar__item--active" : ""}`}
              onClick={() => {
                onSelect(c.id);
                onClose();
              }}
            >
              <MessageSquare size={15} className="sidebar__item-icon" />
              <span className="sidebar__item-title">{c.title || "New Conversation"}</span>
              <button
                className="sidebar__item-delete"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(c.id);
                }}
                aria-label="Delete conversation"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
        </div>
      </aside>
    </>
  );
}
