import { Languages } from "lucide-react";
import { localeFor } from "../hooks/useSpeechSynthesis";

/**
 * Cycles through Auto and the five supported languages. Drives both the
 * speech recognition locale and the `language_hint` sent to /api/chat, so
 * this one control governs what BharatVoice listens and replies in.
 *
 * WHAT AUTO CAN AND CANNOT DO — the honest version, because the previous
 * one caused the bug in this project's brief.
 *
 * The browser's SpeechRecognition accepts exactly one locale per session
 * and cannot identify a language from audio. Auto used to hard-code
 * `en-IN`, which meant a user who selected Auto and spoke Tamil had their
 * speech decoded by an *English acoustic model*: the transcript came back
 * as Latin-script nonsense, the backend correctly identified that nonsense
 * as English, and the reply arrived in English. Nothing reported a
 * problem, because from each component's point of view nothing went wrong.
 *
 * Auto now does the best a browser-only build can:
 *
 *   1. It listens in the last language the backend actually detected, not
 *      always English. One Tamil exchange — typed, or spoken after picking
 *      தமிழ் once — and Auto keeps listening in Tamil.
 *   2. It shows which language that is, on the control itself, so the
 *      state is never invisible.
 *
 * What it still cannot do is detect Tamil from the first utterance of a
 * session that started in English. That needs server-side ASR with
 * language identification (Whisper, or Bhashini's ASR pipeline); the
 * `/api/speech/transcribe` endpoint and `services/speech_to_text.py` are
 * the place that goes, and `useSpeechRecognition` would send recorded audio
 * there instead of using the browser. Until then, picking your language
 * explicitly is materially more accurate than Auto, and the UI says so
 * rather than letting the user discover it from a wrong answer.
 */
export const LANGUAGE_MODES = [
  // `recLang: null` marks the mode whose locale is resolved at runtime.
  { code: null, label: "Auto", recLang: null, native: "Auto" },
  { code: "ta", label: "தமிழ்", recLang: "ta-IN", native: "தமிழ்" },
  { code: "hi", label: "हिंदी", recLang: "hi-IN", native: "हिंदी" },
  { code: "te", label: "తెలుగు", recLang: "te-IN", native: "తెలుగు" },
  { code: "kn", label: "ಕನ್ನಡ", recLang: "kn-IN", native: "ಕನ್ನಡ" },
  { code: "en", label: "English", recLang: "en-IN", native: "English" },
];

/**
 * The BCP-47 locale to hand the browser's recognizer.
 *
 * For an explicit language it is that language. For Auto it is the last
 * language the backend detected, falling back to en-IN on a cold start
 * because something has to be first and most code-mixed Indian speech is
 * recognized better by en-IN than by a wrong Indic model.
 */
export function recLangForMode(mode, autoLanguage) {
  if (mode?.recLang) return mode.recLang;
  return localeFor(autoLanguage || "en");
}

/** The label shown on the control, including what Auto resolved to. */
export function labelForMode(mode, autoLanguage) {
  if (mode?.code) return mode.label;
  const resolved = LANGUAGE_MODES.find(
    (m) => m.code && m.code === (autoLanguage || "en").split("-")[0]
  );
  return resolved ? `Auto · ${resolved.label}` : "Auto";
}

export default function LanguageToggle({ modeIndex, onChange, autoLanguage }) {
  const current = LANGUAGE_MODES[modeIndex];
  const next = () => onChange((modeIndex + 1) % LANGUAGE_MODES.length);
  const label = labelForMode(current, autoLanguage);

  const title = current.code
    ? `Language: ${current.label} — tap to change`
    : `Auto: listening in ${recLangForMode(current, autoLanguage)}. ` +
      `Auto cannot detect a spoken language on its own — pick your language for better recognition.`;

  return (
    <button
      type="button"
      className="icon-btn language-toggle"
      onClick={next}
      title={title}
      aria-label={`Language mode: ${label}. Tap to change.`}
    >
      <Languages size={17} />
      <span className="input-bar__lang-label">{label}</span>
    </button>
  );
}
