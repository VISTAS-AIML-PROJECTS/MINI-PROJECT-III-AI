import { AlertTriangle, Loader2, Mic, X } from "lucide-react";

/**
 * The one place voice state is explained to the user.
 *
 * The bug this exists to close: `useSpeechRecognition` has always produced
 * an error for a blocked microphone, a missing capture device, a network
 * failure reaching the browser's speech service and an unsupported
 * recognition language — and the home screen rendered none of them. Tapping
 * the orb and speaking did nothing, with no explanation anywhere on screen.
 *
 * Both surfaces (the home orb and the conversation input bar) render this,
 * so there is exactly one copy of the wording and one set of states.
 *
 * `role="status"` rather than `role="alert"`: this appears in response to
 * an action the user just took, and an assertive live region would
 * interrupt a screen reader mid-sentence every time the mic starts.
 */
export default function VoiceStatus({ speech, className = "" }) {
  const { status, error, clearError } = speech;

  if (error) {
    return (
      <div className={`voice-status voice-status--error ${className}`} role="status">
        <AlertTriangle size={15} aria-hidden="true" />
        <span className="voice-status__text">{error.message}</span>
        <button
          type="button"
          className="voice-status__dismiss"
          onClick={clearError}
          aria-label="Dismiss this message"
        >
          <X size={14} />
        </button>
      </div>
    );
  }

  if (status === "starting") {
    return (
      <div className={`voice-status ${className}`} role="status">
        <Loader2 size={15} className="voice-status__spin" aria-hidden="true" />
        <span className="voice-status__text">Starting the microphone…</span>
      </div>
    );
  }

  if (status === "listening") {
    return (
      <div className={`voice-status voice-status--live ${className}`} role="status">
        <Mic size={15} aria-hidden="true" />
        <span className="voice-status__text">Listening — speak now, then pause.</span>
      </div>
    );
  }

  return null;
}
