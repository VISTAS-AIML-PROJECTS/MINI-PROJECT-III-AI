import { Phone } from "lucide-react";
import { parseReply, splitDialable } from "../utils/replyFormat";

/**
 * Renders an assistant reply as structure rather than as one block of text.
 *
 * Why: the answers this assistant gives are mostly lists — nine helpline
 * numbers, seven things it can help with, four steps to try when it doesn't
 * understand, five sources. Rendered as a single centred paragraph, the
 * reader has to hunt for the start of each item, which is worst for exactly
 * the people this app is for: someone reading slowly, on a phone, in a
 * second language, possibly in a hurry.
 *
 * The markup contract lives in `utils/replyFormat.js` and is shared with
 * text-to-speech, so a marker rendered here is also a marker stripped
 * before speaking. Text with no markers renders as plain paragraphs, which
 * is what most replies are.
 */
/** Prose with any backend-marked helpline numbers turned into tel: links. */
function Dialable({ text, dialable }) {
  return splitDialable(text, dialable).map((segment, index) =>
    segment.number ? (
      <a
        key={index}
        className="helpline-inline"
        href={`tel:${segment.number}`}
        aria-label={`Call ${segment.number}`}
      >
        {segment.number}
      </a>
    ) : (
      segment.text
    )
  );
}

export default function ReplyText({ text, dialable }) {
  if (!text) return null;

  const blocks = parseReply(text);
  if (blocks.length === 0) return null;

  // The common case — a single paragraph — keeps the exact markup it had
  // before, so nothing about short replies changes.
  if (blocks.length === 1 && blocks[0].type === "paragraph") {
    return (
      <p className="chat-bubble__text">
        <Dialable text={blocks[0].text} dialable={dialable} />
      </p>
    );
  }

  return (
    <div className="chat-bubble__text reply-body">
      {blocks.map((block, index) => {
        switch (block.type) {
          case "heading":
            // h4, not h2: this sits inside a message, below the page's own
            // heading levels, and jumping straight to h2 would give a
            // screen-reader user a broken outline.
            return (
              <h4 key={index} className="reply-heading">
                {block.text}
              </h4>
            );

          case "helpline":
            return (
              <a key={index} className="helpline" href={`tel:${block.number}`}>
                <span className="helpline__icon" aria-hidden="true">
                  <Phone size={15} />
                </span>
                <span className="helpline__number">{block.number}</span>
                <span className="helpline__label">{block.label}</span>
              </a>
            );

          case "list": {
            const List = block.ordered ? "ol" : "ul";
            return (
              <List key={index} className="reply-list">
                {block.items.map((item, i) => (
                  <li key={i}>
                    <Dialable text={item} dialable={dialable} />
                  </li>
                ))}
              </List>
            );
          }

          default:
            return (
              <p key={index} className="reply-line">
                <Dialable text={block.text} dialable={dialable} />
              </p>
            );
        }
      })}
    </div>
  );
}
