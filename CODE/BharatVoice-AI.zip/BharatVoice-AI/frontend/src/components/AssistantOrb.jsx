import Waveform from "./Waveform";

/**
 * The primary voice interaction surface — a big, tappable orb that replaces
 * the old chat-first empty state. Tapping it starts/stops listening; its
 * visual state (idle / listening / speaking / thinking) tells the story at
 * a glance, reusing the existing kolam-dot Waveform as its "face" so the
 * assistant's visual identity stays consistent between the header avatar,
 * the mic button, and this hero surface.
 */
export default function AssistantOrb({ state = "idle", volume = 0, size = 220, onClick, disabled }) {
  return (
    <button
      type="button"
      className={`assistant-orb assistant-orb--${state}`}
      style={{ width: size, height: size }}
      onClick={onClick}
      disabled={disabled}
      aria-pressed={state === "listening"}
      aria-label={
        state === "listening"
          ? "Stop listening"
          : state === "speaking"
          ? "Assistant is speaking"
          : "Tap to speak"
      }
    >
      <span className="assistant-orb__glow" aria-hidden="true" />
      <span className="assistant-orb__ring" aria-hidden="true" />
      <span className="assistant-orb__core">
        <Waveform
          volume={volume}
          active={state === "listening" || state === "speaking"}
          size={Math.round(size * 0.55)}
        />
      </span>
    </button>
  );
}
