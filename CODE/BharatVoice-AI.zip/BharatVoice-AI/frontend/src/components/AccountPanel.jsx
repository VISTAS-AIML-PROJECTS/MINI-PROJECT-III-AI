import { useState } from "react";
import { X, User, LogOut } from "lucide-react";

/**
 * Sign in, create an account, or sign out.
 *
 * Accounts are optional: a browser that never opens this panel still has
 * its own private history. The reason to sign in is to see the same
 * conversations and reminders on another device, and the panel says so
 * rather than presenting a login wall in front of a voice assistant.
 */
export default function AccountPanel({ open, onClose, user, onLogin, onRegister, onLogout }) {
  const [mode, setMode] = useState("login"); // "login" | "register"
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event) => {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await (mode === "login" ? onLogin : onRegister)({ username: username.trim(), password });
      setPassword("");
    } catch (e) {
      setError(describeError(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div
        className={`drawer-backdrop ${open ? "drawer-backdrop--visible" : ""}`}
        onClick={onClose}
        aria-hidden="true"
      />
      {/* See HistoryDrawer for why this is `inert` when closed. */}
      <aside
        className={`drawer drawer--right ${open ? "drawer--open" : ""}`}
        aria-hidden={!open}
        inert={open ? undefined : ""}
      >
        <div className="drawer__header">
          <span className="drawer__title">
            <User size={16} /> Account
          </span>
          <button className="icon-btn" onClick={onClose} aria-label="Close account">
            <X size={18} />
          </button>
        </div>

        {user ? (
          <div className="account">
            <p className="account__who">
              Signed in as <strong>{user.username}</strong>
            </p>
            <p className="drawer__empty">
              Your conversations and reminders are saved to this account and follow you to any
              device you sign in on.
            </p>
            <button type="button" className="account__submit" onClick={onLogout}>
              <LogOut size={15} /> Sign out
            </button>
          </div>
        ) : (
          <form className="account" onSubmit={submit}>
            <p className="drawer__empty">
              You don't need an account. Without one, your history stays on this browser only.
              Sign in to see it on your other devices too.
            </p>

            <label className="account__label" htmlFor="account-username">
              Username
            </label>
            <input
              id="account-username"
              className="account__input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              autoCapitalize="none"
              spellCheck={false}
              required
              minLength={3}
              maxLength={32}
            />

            <label className="account__label" htmlFor="account-password">
              Password
            </label>
            <input
              id="account-password"
              className="account__input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              required
              minLength={8}
              maxLength={128}
            />
            {mode === "register" && (
              <p className="account__hint">At least 8 characters. There is no password reset yet.</p>
            )}

            {error && (
              <p className="account__error" role="alert">
                {error}
              </p>
            )}

            <button type="submit" className="account__submit" disabled={busy}>
              {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
            </button>

            <button
              type="button"
              className="account__switch"
              onClick={() => {
                setMode(mode === "login" ? "register" : "login");
                setError(null);
              }}
            >
              {mode === "login" ? "New here? Create an account" : "Have an account? Sign in"}
            </button>
          </form>
        )}
      </aside>
    </>
  );
}

/** The backend's own sentence when it sent one; otherwise say what failed
 *  in terms the user can act on. */
export function describeError(error) {
  const detail = error?.response?.data?.detail;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail) && detail.length > 0) {
    const field = detail[0]?.loc?.[detail[0].loc.length - 1];
    if (field === "password") return "Passwords need at least 8 characters.";
    if (field === "username") return "Usernames need 3 to 32 characters.";
    return "Please check the username and password.";
  }
  if (!error?.response) return "Couldn't reach the server. Check that the backend is running.";
  return "Something went wrong. Please try again.";
}
