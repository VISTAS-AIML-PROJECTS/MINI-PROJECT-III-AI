import { Mic } from "lucide-react";
import Waveform from "./Waveform";

/**
 * The voice-input control in the conversation view. Idle shows a calm mic
 * icon; listening morphs into the kolam waveform pulsing with live volume.
 * Clicking again stops recording.
 *
 * `isStarting` is its own state rather than being folded into
 * `isListening`. The gap between asking for the microphone and the browser
 * confirming it opened can be a second or more — long enough that a button
 * which already claims to be listening is lying, and long enough for a user
 * to tap again and cancel the session they just started.
 */
export default function MicButton({
  isListening,
  isStarting,
  volume,
  onStart,
  onStop,
  disabled,
}) {
  const active = isListening || isStarting;

  return (
    <button
      type="button"
      className={`mic-button ${isListening ? "mic-button--active" : ""} ${
        isStarting ? "mic-button--starting" : ""
      }`}
      onClick={active ? onStop : onStart}
      disabled={disabled}
      aria-pressed={active}
      aria-label={
        isStarting
          ? "Starting the microphone"
          : isListening
          ? "Stop recording"
          : "Start voice input"
      }
    >
      <span className="mic-button__ring" aria-hidden="true" />
      <span className="mic-button__icon">
        {isListening ? <Waveform volume={volume} active size={40} /> : <Mic size={22} />}
      </span>
    </button>
  );
}
