import { useEffect, useState } from "react";
import { BellRing, BellOff } from "lucide-react";
import { disablePush, enablePush, getPushStatus } from "../services/push";

// What to tell the user in each state. Every state has words: a control
// that is silently absent or silently inert is how "reminders don't work"
// gets reported for what is really a blocked permission.
const COPY = {
  off: "Get reminders as notifications, even when this page is closed.",
  on: "Notifications are on for this browser. Reminders arrive even when this page is closed.",
  blocked:
    "Notifications are blocked for this site. Allow them in your browser's site settings, then try again.",
  unsupported:
    "This browser can't show notifications for this page. Reminders will appear while the page is open.",
  unavailable:
    "The server can't send notifications right now. Reminders will appear while the page is open.",
};

/**
 * The switch for reminder notifications, shown at the top of the reminders
 * panel. `visible` is the panel's open state: the status is re-checked each
 * time it opens, since permission can change in browser settings meanwhile.
 */
export default function PushToggle({ visible }) {
  const [status, setStatus] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!visible) return undefined;
    let cancelled = false;
    getPushStatus().then((next) => {
      if (!cancelled) setStatus(next);
    });
    return () => {
      cancelled = true;
    };
  }, [visible]);

  if (!status) return null;

  const toggle = async () => {
    setBusy(true);
    try {
      setStatus(await (status === "on" ? disablePush() : enablePush()));
    } catch {
      setStatus(await getPushStatus());
    } finally {
      setBusy(false);
    }
  };

  const canToggle = status === "on" || status === "off";

  return (
    <div className="push-toggle">
      <p className="push-toggle__text" role="status">
        {COPY[status]}
      </p>
      {canToggle && (
        <button type="button" className="push-toggle__button" onClick={toggle} disabled={busy}>
          {status === "on" ? <BellOff size={14} /> : <BellRing size={14} />}
          {busy ? "Please wait…" : status === "on" ? "Turn off" : "Turn on notifications"}
        </button>
      )}
    </div>
  );
}
