const LABELS = {
  ta: { label: "தமிழ்", full: "Tamil" },
  hi: { label: "हिंदी", full: "Hindi" },
  te: { label: "తెలుగు", full: "Telugu" },
  kn: { label: "ಕನ್ನಡ", full: "Kannada" },
  en: { label: "EN", full: "English" },
  "ta-en": { label: "த/EN", full: "Tamil-English mix" },
  "hi-en": { label: "हि/EN", full: "Hindi-English mix" },
  "te-en": { label: "తె/EN", full: "Telugu-English mix" },
  "kn-en": { label: "ಕ/EN", full: "Kannada-English mix" },
};

/** Small pill badge showing the detected language of a message. */
export default function LanguageIndicator({ language = "en", confidence }) {
  const info = LABELS[language] || { label: language, full: language };
  return (
    <span
      className="language-indicator"
      title={confidence ? `${info.full} · ${Math.round(confidence * 100)}% confidence` : info.full}
    >
      {info.label}
    </span>
  );
}
