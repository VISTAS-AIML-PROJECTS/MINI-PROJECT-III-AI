import { ExternalLink } from "lucide-react";

/**
 * Shows where a fact-bearing answer came from.
 *
 * The backend already attaches a `sources` list to every reply that makes
 * a claim about the world (government documents, emergency helplines) and
 * leaves it empty for chit-chat and arithmetic. Displaying it is what turns
 * that contract from an internal detail into something a citizen — or a
 * frontline helper answering on their behalf — can actually check.
 *
 * `checked_on` is rendered only when the backend supplies it. It is
 * currently null for the helpline list because nobody has re-verified those
 * numbers against the official portal yet; showing "checked: —" would imply
 * a verification that hasn't happened.
 */
export default function SourceList({ sources, staleness }) {
  if ((!sources || sources.length === 0) && !staleness) return null;

  return (
    <div className="source-list">
      {/* Freshness first: for live data the age of the reading matters more
          than which service produced it. A temperature with no timestamp is
          indistinguishable from a stale one. */}
      {staleness && <span className="source-chip source-chip--fresh">{staleness}</span>}
      {(sources || []).map((source, index) => {
        const label = source.checked_on
          ? `${source.title} · checked ${source.checked_on}`
          : source.title;

        if (!source.url) {
          return (
            <span key={index} className="source-chip source-chip--plain">
              {label}
            </span>
          );
        }

        return (
          <a
            key={index}
            className="source-chip"
            href={source.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            <ExternalLink size={12} aria-hidden="true" />
            {label}
          </a>
        );
      })}
    </div>
  );
}
