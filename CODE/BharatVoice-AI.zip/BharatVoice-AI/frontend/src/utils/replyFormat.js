/**
 * The reply markup contract, in one place.
 *
 * The backend writes plain text. Where an answer is genuinely a list — the
 * emergency helplines, "what can you help with", "where does the
 * information come from" — it marks the structure with three tokens and
 * nothing else:
 *
 *     ### Heading        a section heading
 *     - item             a bullet
 *     1. item            a numbered step
 *     112 — label        a dialable helpline row
 *
 * Both consumers of a reply live here so they cannot disagree:
 * `parseReply` turns the text into blocks for `ReplyText` to render, and
 * `toSpeech` strips the same markers before text-to-speech. Getting that
 * second one wrong is how an assistant ends up reading "hash hash hash" to
 * someone who cannot see the screen.
 *
 * Anything not matching a marker stays a paragraph, so an untouched
 * backend answer renders exactly as it did before.
 */

// Deliberately narrow: only a line shaped exactly like
// `112 — All-in-one national emergency` becomes a dial link. A looser rule
// (any 3-5 digit run) would turn the 1930 in a mandi price into the fraud
// helpline — which is a mistake this project already made once and
// reverted. The em-dash form is produced by `format_emergency_reply` on
// the backend and by nothing else.
const HELPLINE_LINE = /^(\d{3,5})\s*—\s*(.+)$/;
const HEADING_LINE = /^###\s+(.+)$/;
const BULLET_LINE = /^[-•]\s+(.+)$/;
const NUMBERED_LINE = /^(\d{1,2})[.)]\s+(.+)$/;

/**
 * Split a line of prose around the helpline numbers the backend marked as
 * dialable, so they can be rendered as tel: links.
 *
 * `dialable` comes from the server (`ChatResponse.dialable`) and is the
 * whole safety argument: this function never decides that a number is a
 * phone number. With an empty list it returns the text untouched, which is
 * what every calculator, weather and mandi answer gets — so "That's 100."
 * stays a sum and ₹1930 stays a price.
 *
 * Returns an array of { text } and { number } segments.
 */
export function splitDialable(text, dialable) {
  const numbers = (dialable || []).filter((n) => /^\d{3,5}$/.test(n));
  if (!text || numbers.length === 0) return [{ text: text || "" }];

  // Longest first so 1098 is not read as 109 + 8, and digit boundaries so
  // 112 inside 11234 is left alone. \p{Nd} covers Indic digits too.
  const pattern = new RegExp(
    `(?<!\\p{Nd})(${[...numbers].sort((a, b) => b.length - a.length).join("|")})(?!\\p{Nd})`,
    "gu"
  );

  const segments = [];
  let last = 0;
  for (const match of text.matchAll(pattern)) {
    if (match.index > last) segments.push({ text: text.slice(last, match.index) });
    segments.push({ number: match[1] });
    last = match.index + match[1].length;
  }
  if (last < text.length) segments.push({ text: text.slice(last) });
  return segments;
}

/**
 * Split reply text into renderable blocks.
 *
 * Returns an array of:
 *   { type: "heading",  text }
 *   { type: "list",     ordered, items: [string] }
 *   { type: "helpline", number, label }
 *   { type: "paragraph", text }
 */
export function parseReply(text) {
  if (!text) return [];

  const blocks = [];
  let list = null; // the run of consecutive bullets/numbers being collected

  const closeList = () => {
    if (list) blocks.push(list);
    list = null;
  };

  for (const rawLine of String(text).split("\n")) {
    const line = rawLine.trim();

    if (!line) {
      closeList();
      continue;
    }

    const heading = HEADING_LINE.exec(line);
    if (heading) {
      closeList();
      blocks.push({ type: "heading", text: heading[1] });
      continue;
    }

    const helpline = HELPLINE_LINE.exec(line);
    if (helpline) {
      closeList();
      blocks.push({ type: "helpline", number: helpline[1], label: helpline[2] });
      continue;
    }

    const numbered = NUMBERED_LINE.exec(line);
    if (numbered) {
      // A numbered step, not a date or a price: the helpline check above
      // has already run, and "3. " at the start of a line is not a shape
      // the arithmetic or weather answers produce.
      if (!list || !list.ordered) {
        closeList();
        list = { type: "list", ordered: true, items: [] };
      }
      list.items.push(numbered[2]);
      continue;
    }

    const bullet = BULLET_LINE.exec(line);
    if (bullet) {
      if (!list || list.ordered) {
        closeList();
        list = { type: "list", ordered: false, items: [] };
      }
      list.items.push(bullet[1]);
      continue;
    }

    // A plain line that follows a list belongs to the text after it, not
    // to the list — closing here is what keeps the closing sentence of an
    // answer from being swallowed as a final bullet.
    closeList();
    blocks.push({ type: "paragraph", text: line });
  }

  closeList();
  return blocks;
}

/**
 * The same text, prepared to be spoken aloud.
 *
 * Markers are removed rather than read. The em-dash in a helpline row
 * becomes a comma so the number and its label don't run together, and each
 * block is separated by a full stop so the voice pauses between items
 * instead of reciting one breathless sentence.
 */
export function toSpeech(text) {
  return parseReply(text)
    .map((block) => {
      switch (block.type) {
        case "heading":
          return block.text.replace(/[:：]$/, "");
        case "helpline":
          return `${block.number}, ${block.label}`;
        case "list":
          return block.items.join(". ");
        default:
          return block.text;
      }
    })
    .filter(Boolean)
    .join(". ")
    .replace(/\.\s*\./g, ".")
    .trim();
}
