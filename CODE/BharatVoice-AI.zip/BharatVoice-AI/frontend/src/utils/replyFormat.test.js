import { describe, expect, it } from "vitest";
import { parseReply, splitDialable, toSpeech } from "./replyFormat";

describe("parseReply", () => {
  it("returns nothing for empty text", () => {
    expect(parseReply("")).toEqual([]);
    expect(parseReply(null)).toEqual([]);
  });

  it("keeps an unmarked reply as one paragraph", () => {
    expect(parseReply("It is 31°C in Chennai.")).toEqual([
      { type: "paragraph", text: "It is 31°C in Chennai." },
    ]);
  });

  it("reads headings, bullets and numbered steps", () => {
    const blocks = parseReply("### What I can do\n- weather\n- reminders\n\n1. Tap the orb\n2. Speak");
    expect(blocks).toEqual([
      { type: "heading", text: "What I can do" },
      { type: "list", ordered: false, items: ["weather", "reminders"] },
      { type: "list", ordered: true, items: ["Tap the orb", "Speak"] },
    ]);
  });

  it("turns a full helpline row into a dialable block", () => {
    expect(parseReply("112 — All-in-one national emergency")).toEqual([
      { type: "helpline", number: "112", label: "All-in-one national emergency" },
    ]);
  });

  it("does not treat a price or a sum as a helpline row", () => {
    // The em-dash row shape is the only thing that qualifies.
    for (const text of ["That's 100.", "1930 rupees per quintal", "100 - 40 is 60"]) {
      expect(parseReply(text)[0].type).toBe("paragraph");
    }
  });

  it("does not swallow the sentence after a list as a final bullet", () => {
    const blocks = parseReply("- one\n- two\nCall if you need more.");
    expect(blocks[1]).toEqual({ type: "paragraph", text: "Call if you need more." });
  });

  it("starts a new list when bullets switch to numbers", () => {
    const blocks = parseReply("- a\n1. b");
    expect(blocks.map((b) => b.ordered)).toEqual([false, true]);
  });
});

describe("toSpeech", () => {
  it("never reads the markers aloud", () => {
    const spoken = toSpeech("### Emergency numbers:\n112 — Police\n- stay calm");
    expect(spoken).not.toMatch(/#|—|^- /);
    expect(spoken).toBe("Emergency numbers. 112, Police. stay calm");
  });

  it("leaves plain text alone", () => {
    expect(toSpeech("வணக்கம்")).toBe("வணக்கம்");
  });
});

describe("splitDialable", () => {
  it("links nothing when the backend marked nothing", () => {
    // The regression this design exists for: a calculator answer.
    expect(splitDialable("That's 100.", [])).toEqual([{ text: "That's 100." }]);
    expect(splitDialable("That's 100.", undefined)).toEqual([{ text: "That's 100." }]);
  });

  it("links a marked number inside a sentence", () => {
    expect(splitDialable("Call 1930 as soon as you notice it.", ["1930"])).toEqual([
      { text: "Call " },
      { number: "1930" },
      { text: " as soon as you notice it." },
    ]);
  });

  it("works in Indic-script sentences", () => {
    const segments = splitDialable("1930 என்ற எண்ணை அழையுங்கள்", ["1930"]);
    expect(segments[0]).toEqual({ number: "1930" });
  });

  it("does not link a marked number inside a longer number", () => {
    expect(splitDialable("Order 11234 and ₹19305", ["112", "1930"])).toEqual([
      { text: "Order 11234 and ₹19305" },
    ]);
  });

  it("treats Indic digits as part of a number", () => {
    expect(splitDialable("१112", ["112"])).toEqual([{ text: "१112" }]);
  });

  it("prefers the longer helpline when two overlap", () => {
    expect(splitDialable("Call 1098 now", ["109", "1098"])).toEqual([
      { text: "Call " },
      { number: "1098" },
      { text: " now" },
    ]);
  });

  it("links every occurrence", () => {
    const numbers = splitDialable("112 or 108, then 112", ["112", "108"])
      .filter((s) => s.number)
      .map((s) => s.number);
    expect(numbers).toEqual(["112", "108", "112"]);
  });

  it("ignores anything in the list that is not a short number", () => {
    // Defence in depth: the list is server data, and it goes into a RegExp.
    expect(splitDialable("call (.*) now", ["(.*)", "9876543210"])).toEqual([
      { text: "call (.*) now" },
    ]);
  });
});
