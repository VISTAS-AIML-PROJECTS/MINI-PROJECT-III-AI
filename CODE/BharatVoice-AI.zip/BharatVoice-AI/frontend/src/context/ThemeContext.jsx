import { createContext, useContext, useEffect, useState } from "react";

const ThemeContext = createContext(null);

/**
 * Provides light/dark theme state to the whole app and persists the user's
 * choice across sessions via localStorage.
 *
 * Defaults to dark rather than to the OS preference. Following the OS is
 * the more thoughtful default in the abstract, but it means the app opens
 * in whatever state the machine it is demonstrated on happens to be in —
 * and "ink" is the theme this design leads with. An explicit choice from
 * the toggle still wins and is remembered.
 */
export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem("bharatvoice-theme") || "dark";
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("bharatvoice-theme", theme);
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within a ThemeProvider");
  return ctx;
}
