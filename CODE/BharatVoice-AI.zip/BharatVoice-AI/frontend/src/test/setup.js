import "@testing-library/jest-dom/vitest";
import { afterEach } from "vitest";
import { cleanup } from "@testing-library/react";

// Each test starts with an empty page and empty storage, so no test can
// pass or fail because of what an earlier one left behind.
afterEach(() => {
  cleanup();
  localStorage.clear();
});
