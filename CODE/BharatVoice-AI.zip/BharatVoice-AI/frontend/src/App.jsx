import { useEffect, useState, useCallback, useRef } from "react";
import { Menu, Bell, Home as HomeIcon, Keyboard, Send, Volume2, VolumeX, User } from "lucide-react";
import ChatWindow from "./components/ChatWindow";
import InputBar from "./components/InputBar";
import HistoryDrawer from "./components/HistoryDrawer";
import RemindersPanel from "./components/RemindersPanel";
import AccountPanel from "./components/AccountPanel";
import ThemeToggle from "./components/ThemeToggle";
import LanguageToggle, {
  LANGUAGE_MODES,
  labelForMode,
  recLangForMode,
} from "./components/LanguageToggle";
import VoiceOutStatus from "./components/VoiceOutStatus";
import AssistantAvatar from "./components/AssistantAvatar";
import AssistantOrb from "./components/AssistantOrb";
import ReplyText from "./components/ReplyText";
import SourceList from "./components/SourceList";
import ReminderAlert from "./components/ReminderAlert";
import VoiceStatus from "./components/VoiceStatus";
import { useSpeechRecognition } from "./hooks/useSpeechRecognition";
import { useSpeechSynthesis } from "./hooks/useSpeechSynthesis";
import {
  sendChatMessage,
  listConversations,
  getConversation,
  deleteConversation,
  listReminders,
  listDueReminders,
  markReminderDone,
  deleteReminder,
  login,
  register,
  logout,
  setSessionExpiredHandler,
} from "./services/api";
import { clearSession, getStoredUser, storeSession } from "./services/identity";
import { onPushedReminder, syncPushOwner } from "./services/push";

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export default function App() {
  const [screen, setScreen] = useState("home"); // "home" (voice-first orb) | "conversation" (transcript)
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isThinking, setIsThinking] = useState(false);
  const [backendOnline, setBackendOnline] = useState(true);

  const [historyOpen, setHistoryOpen] = useState(false);
  const [remindersOpen, setRemindersOpen] = useState(false);
  const [reminders, setReminders] = useState([]);
  const [remindersLoading, setRemindersLoading] = useState(false);

  const [languageModeIndex, setLanguageModeIndex] = useState(0);
  const languageMode = LANGUAGE_MODES[languageModeIndex];

  const [showTypeInput, setShowTypeInput] = useState(false);
  const [homeText, setHomeText] = useState("");

  const [dueReminder, setDueReminder] = useState(null);

  const [accountOpen, setAccountOpen] = useState(false);
  const [user, setUser] = useState(() => getStoredUser());

  // Shown when a voice session ended having heard nothing. Without it, the
  // orb went quiet and the user had no way to tell "it didn't hear me" from
  // "it's broken" — which is what "the orb doesn't respond" turned out to
  // mean in practice.
  const [voiceNotice, setVoiceNotice] = useState(null);

  // The language Auto listens in. Seeded from the last session and updated
  // from every reply's detected language, because a browser recognizer has
  // to be handed one locale up front and cannot work it out from the audio.
  // Without this, Auto listened in en-IN forever and decoded Tamil speech
  // with an English acoustic model — the cause of "I spoke Tamil and got an
  // English answer".
  const [autoLanguage, setAutoLanguage] = useState(() => {
    try {
      return localStorage.getItem("bv.autoLanguage") || "en";
    } catch {
      return "en";
    }
  });

  // Autoplay is what the app is for — a voice assistant that needs a tap to
  // be heard is not one. But it has to be escapable: a shared room, a
  // classroom demo, a user reading rather than listening. Defaults to on.
  const [autoSpeak, setAutoSpeak] = useState(() => {
    try {
      return localStorage.getItem("bv.autoSpeak") !== "off";
    } catch {
      return true;
    }
  });

  // Which reply is being read aloud. Without this the voice state is
  // global, so starting one reply turns every other reply's play button
  // into a stop button — each bubble claiming to be the one speaking.
  const [speakingId, setSpeakingId] = useState(null);

  const voiceAutoSendRef = useRef(false);
  const lastSessionRef = useRef(0);

  const recLang = recLangForMode(languageMode, autoLanguage);
  const speech = useSpeechRecognition({
    lang: recLang,
    languageLabel: labelForMode(languageMode, autoLanguage),
  });
  const voice = useSpeechSynthesis();
  const { speak, isSpeaking } = voice;

  // Remember both choices across reloads. Wrapped because Safari private
  // mode throws on write rather than no-opping.
  useEffect(() => {
    try {
      localStorage.setItem("bv.autoLanguage", autoLanguage);
    } catch {
      /* a forgotten preference is not worth an error */
    }
  }, [autoLanguage]);

  useEffect(() => {
    try {
      localStorage.setItem("bv.autoSpeak", autoSpeak ? "on" : "off");
    } catch {
      /* as above */
    }
  }, [autoSpeak]);

  // ---- Conversations ----

  const refreshConversations = useCallback(async () => {
    try {
      const list = await listConversations();
      setConversations(list);
      setBackendOnline(true);
    } catch {
      setBackendOnline(false);
    }
  }, []);

  useEffect(() => {
    refreshConversations();
  }, [refreshConversations]);

  const handleSelectConversation = async (id) => {
    setActiveId(id);
    setScreen("conversation");
    try {
      const conv = await getConversation(id);
      setMessages(
        conv.messages.map((m) => ({
          id: m.id,
          role: m.role,
          text: m.text,
          language: m.language,
          intent: m.intent,
          entities: m.entities,
          sources: m.sources,
          dialable: m.dialable,
        }))
      );
    } catch {
      setBackendOnline(false);
    }
  };

  const handleNewConversation = () => {
    setActiveId(null);
    setMessages([]);
    setScreen("home");
  };

  const handleDeleteConversation = async (id) => {
    try {
      await deleteConversation(id);
      if (id === activeId) handleNewConversation();
      refreshConversations();
    } catch {
      setBackendOnline(false);
    }
  };

  // ---- Reminders ----

  const refreshReminders = useCallback(async () => {
    setRemindersLoading(true);
    try {
      const list = await listReminders();
      setReminders(list);
    } catch {
      setBackendOnline(false);
    } finally {
      setRemindersLoading(false);
    }
  }, []);

  // Poll for reminders whose time has come. The backend marks each as
  // notified when it hands it over, so one fires exactly once even across
  // reloads. 30s is granular enough for "remind me at 6pm" and cheap enough
  // to leave running; a background scheduler with web-push is the upgrade,
  // and it needs user accounts first.
  useEffect(() => {
    let cancelled = false;

    const check = async () => {
      try {
        const due = await listDueReminders();
        if (!cancelled && due.length > 0) {
          setDueReminder(due[0]);
          speak(due[0].text, due[0].language || "en");
          refreshReminders();
        }
      } catch {
        // Backend down — the offline pill already tells the user.
      }
    };

    check();
    const timer = setInterval(check, 30000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [speak, refreshReminders]);

  // A reminder delivered by web push while the app is open and visible:
  // the service worker hands it here instead of showing a system
  // notification, so it gets the same alert and spoken reminder as one
  // found by the poll above.
  useEffect(
    () =>
      onPushedReminder((reminder) => {
        setDueReminder(reminder);
        speak(reminder.text, reminder.language || "en");
        refreshReminders();
      }),
    [speak, refreshReminders]
  );

  const handleDismissDueReminder = () => setDueReminder(null);

  const handleCompleteDueReminder = async (id) => {
    setDueReminder(null);
    await handleMarkReminderDone(id);
  };

  const openReminders = () => {
    setRemindersOpen(true);
    refreshReminders();
  };

  const handleMarkReminderDone = async (id) => {
    try {
      await markReminderDone(id);
      refreshReminders();
    } catch {
      setBackendOnline(false);
    }
  };

  const handleDeleteReminder = async (id) => {
    try {
      await deleteReminder(id);
      refreshReminders();
    } catch {
      setBackendOnline(false);
    }
  };

  // ---- Account ----

  // Whoever the caller is has just changed, so everything on screen that
  // belonged to the previous identity has to go: showing one person's open
  // conversation to the next person at the same screen is the exact leak
  // accounts exist to prevent.
  const resetForIdentityChange = useCallback(() => {
    setActiveId(null);
    setMessages([]);
    setReminders([]);
    setDueReminder(null);
    setScreen("home");
    refreshConversations();
  }, [refreshConversations]);

  const handleLogin = async (credentials) => {
    const session = await login(credentials);
    storeSession(session);
    setUser(session.user);
    syncPushOwner();
    // Signing in adopts this browser's guest history, so the open
    // conversation is still the user's own and is left on screen.
    refreshConversations();
    refreshReminders();
    setAccountOpen(false);
  };

  const handleRegister = async (credentials) => {
    const session = await register(credentials);
    storeSession(session);
    setUser(session.user);
    syncPushOwner();
    refreshConversations();
    refreshReminders();
    setAccountOpen(false);
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch {
      // Signing out locally still has to work with the backend down.
    }
    clearSession();
    setUser(null);
    // Hand this browser's notifications back to the guest identity, so the
    // account's reminders stop arriving on a device it has signed out of.
    syncPushOwner();
    resetForIdentityChange();
    setAccountOpen(false);
  };

  useEffect(() => {
    setSessionExpiredHandler(() => {
      setUser(null);
      syncPushOwner();
      resetForIdentityChange();
    });
    return () => setSessionExpiredHandler(() => {});
  }, [resetForIdentityChange]);

  // ---- Sending messages ----

  // `keepScreen` lets the voice-first home screen stay put and show the
  // reply in its own card. Without it, the first utterance jumped straight
  // to the chat transcript, which made the orb — the app's primary surface —
  // a one-use launcher and left the home reply card unreachable.
  const handleSend = async (text, { keepScreen = false } = {}) => {
    if (!keepScreen) setScreen("conversation");
    const localUserMessage = { id: uid(), role: "user", text };
    setMessages((prev) => [...prev, localUserMessage]);
    setIsThinking(true);

    try {
      const data = await sendChatMessage({
        text,
        conversationId: activeId,
        languageHint: languageMode.code,
      });

      setMessages((prev) =>
        prev.map((m) =>
          m.id === localUserMessage.id
            ? {
                ...m,
                language: data.nlu.language,
                language_confidence: data.nlu.language_confidence,
                intent: data.nlu.intent,
                entities: data.nlu.entities,
              }
            : m
        )
      );

      const assistantMessage = {
        id: data.message_id,
        role: "assistant",
        text: data.reply_text,
        language: data.reply_language,
        sources: data.sources,
        dialable: data.dialable,
        staleness: data.staleness,
        audio_url: data.audio_url,
      };
      setMessages((prev) => [...prev, assistantMessage]);

      if (!activeId) {
        setActiveId(data.conversation_id);
        refreshConversations();
      }

      if (["set_reminder", "list_reminders"].includes(data.nlu.intent)) {
        refreshReminders();
      }

      // Auto's next recognition locale. The backend has just told us what
      // language this exchange was actually in, which is the best signal a
      // browser-only build will ever get about what to listen for next.
      const detected = (data.reply_language || data.nlu.language || "").split("-")[0];
      if (detected && detected !== "und") setAutoLanguage(detected);

      // One call, one decision, one place that explains itself. `speak`
      // walks device voice -> server synthesis -> "no voice for this
      // language, here is the text" and reports which happened.
      if (autoSpeak) {
        setSpeakingId(data.message_id);
        speak(data.reply_text, data.reply_language);
      }
      setBackendOnline(true);
    } catch (e) {
      setBackendOnline(false);
      setMessages((prev) => [
        ...prev,
        {
          id: uid(),
          role: "assistant",
          text: "I couldn't reach the BharatVoice backend. Make sure the FastAPI server is running on port 8000 (see backend/README.md).",
          language: "en",
        },
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  // The replay control. Pressing it while something is playing stops it,
  // so the same button is never a dead end mid-utterance.
  const handleSpeak = (message) => {
    // Pressing the control on the reply that is currently playing stops it;
    // pressing it on a different reply switches to that one.
    if ((voice.isSpeaking || voice.isLoadingAudio) && speakingId === message.id) {
      voice.stop();
      setSpeakingId(null);
      return;
    }
    setSpeakingId(message.id);
    speak(message.text, message.language || "en");
  };

  // ---- Home screen orb: tap to talk, auto-sends on recognition end ----

  const handleOrbTap = () => {
    if (speech.isListening) {
      speech.stop();
      return;
    }
    setVoiceNotice(null);
    speech.clearError();
    voiceAutoSendRef.current = true;
    speech.reset();
    speech.start();
  };

  // Send what was heard once the browser closes the recognition session.
  //
  // This watches `sessionEnd`, a counter the hook bumps every time a
  // session ends for any reason, rather than a false-edge on `isListening`.
  // A counter cannot be missed when two sessions end close together, and it
  // still fires when a session ends without ever having started — which is
  // the case (blocked mic, no capture device) the old edge-detection
  // silently dropped.
  useEffect(() => {
    if (speech.sessionEnd === lastSessionRef.current) return;
    lastSessionRef.current = speech.sessionEnd;

    if (!voiceAutoSendRef.current) return; // dictation into the input bar
    voiceAutoSendRef.current = false;

    // Take the interim text too: if the browser ends the session before
    // promoting the last phrase to final, that phrase is still the best
    // record of what the user said, and dropping it looks like being
    // ignored.
    const heard = [speech.transcript, speech.interimTranscript]
      .filter(Boolean)
      .join(" ")
      .trim();

    if (heard) {
      handleSend(heard, { keepScreen: screen === "home" });
      speech.reset();
    } else if (!speech.error) {
      // An error already explains itself; only speak up when the session
      // ended cleanly having heard nothing at all.
      setVoiceNotice(
        "I didn't catch anything. Tap the orb and speak again, a little closer to the microphone — or type your message."
      );
    }
    // Keyed on the session counter alone: this must run once per session,
    // not on every transcript keystroke.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [speech.sessionEnd]);

  const handleHomeTypeSend = () => {
    const trimmed = homeText.trim();
    if (!trimmed) return;
    handleSend(trimmed, { keepScreen: true });
    setHomeText("");
    setShowTypeInput(false);
  };

  // The orb's own state. "speaking" covers both a device voice and server
  // audio because the hook reports one state for both, and "thinking" covers
  // waiting on synthesis as well as on the reply — from the user's side both
  // are the assistant working on an answer they cannot hear yet.
  const orbState = speech.isListening
    ? "listening"
    : isSpeaking
    ? "speaking"
    : isThinking || voice.isLoadingAudio
    ? "thinking"
    : "idle";
  const liveTranscript = [speech.transcript, speech.interimTranscript].filter(Boolean).join(" ");
  const lastAssistantMessage = [...messages].reverse().find((m) => m.role === "assistant");

  // Home-screen copy per language. Falls back to English so an
  // untranslated string is a visible gap, never a crash.
  //
  // There is no greeting here any more. "Vanakkam!" was the first and
  // largest thing on the screen, and it cost a full heading's worth of
  // space to say nothing actionable — while also committing a five-language
  // app to one language's hello before the user had chosen theirs. The
  // instruction below takes that space instead.
  //
  // No "…or pick a suggestion below" any more either: the chips were
  // removed, and a prompt that points at controls which aren't there is
  // worse than a shorter one.
  const PROMPTS = {
    ta: "பேச orb-ஐ தட்டுங்கள், அல்லது தட்டச்சு செய்யுங்கள்",
    hi: "बोलने के लिए ऑर्ब दबाइए, या टाइप कीजिए",
    te: "మాట్లాడటానికి ఆర్బ్ నొక్కండి, లేదా టైప్ చేయండి",
    kn: "ಮಾತನಾಡಲು ಆರ್ಬ್ ಒತ್ತಿರಿ, ಅಥವಾ ಟೈಪ್ ಮಾಡಿ",
    en: "Tap the orb to speak, or type your question",
  };
  const LISTENING = {
    ta: "கேட்கிறேன்…",
    hi: "सुन रहा हूँ…",
    te: "వింటున్నాను…",
    kn: "ಕೇಳುತ್ತಿದ್ದೇನೆ…",
    en: "Listening…",
  };
  const STARTING = {
    ta: "மைக்ரோஃபோனைத் தொடங்குகிறேன்…",
    hi: "माइक्रोफ़ोन शुरू कर रहा हूँ…",
    te: "మైక్రోఫోన్ ప్రారంభిస్తున్నాను…",
    kn: "ಮೈಕ್ರೊಫೋನ್ ಪ್ರಾರಂಭಿಸುತ್ತಿದ್ದೇನೆ…",
    en: "Starting the microphone…",
  };
  const uiLang = languageMode.code || "en";
  const subtitle =
    liveTranscript && speech.isListening
      ? liveTranscript
      : speech.isStarting
      ? STARTING[uiLang] || STARTING.en
      : speech.isListening
      ? LISTENING[uiLang] || LISTENING.en
      : PROMPTS[uiLang] || PROMPTS.en;

  // Whether this device can actually read the last reply aloud. The browser
  // has no Indic voices installed by default on most desktops, and without
  // this the app just goes quiet and looks broken. "unknown" means the
  // voice list hasn't loaded yet, which is not the same as "missing" — so
  // nothing is claimed either way.
  const replyLanguage = lastAssistantMessage?.language || uiLang;

  return (
    <div className="app-shell">
      <HistoryDrawer
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        conversations={conversations}
        activeId={activeId}
        onSelect={handleSelectConversation}
        onNew={handleNewConversation}
        onDelete={handleDeleteConversation}
      />

      <RemindersPanel
        open={remindersOpen}
        onClose={() => setRemindersOpen(false)}
        reminders={reminders}
        loading={remindersLoading}
        onMarkDone={handleMarkReminderDone}
        onDelete={handleDeleteReminder}
      />

      <AccountPanel
        open={accountOpen}
        onClose={() => setAccountOpen(false)}
        user={user}
        onLogin={handleLogin}
        onRegister={handleRegister}
        onLogout={handleLogout}
      />

      <div className="main-panel">
        <ReminderAlert
          reminder={dueReminder}
          onDone={handleCompleteDueReminder}
          onDismiss={handleDismissDueReminder}
        />

        <header className="top-bar">
          <button className="icon-btn" onClick={() => setHistoryOpen(true)} aria-label="Open conversation history">
            <Menu size={20} />
          </button>

          <button
            type="button"
            className="top-bar__brand"
            onClick={() => setScreen("home")}
            aria-label="Go to assistant home"
          >
            <AssistantAvatar size={30} speaking={isSpeaking} />
            <span>BharatVoice</span>
          </button>

          <div className="top-bar__actions">
            {!backendOnline && <span className="status-pill status-pill--offline">Offline</span>}
            {screen === "conversation" && (
              <button className="icon-btn" onClick={() => setScreen("home")} aria-label="Go home" title="Home">
                <HomeIcon size={18} />
              </button>
            )}
            <LanguageToggle
              modeIndex={languageModeIndex}
              onChange={setLanguageModeIndex}
              autoLanguage={autoLanguage}
            />
            {/* Replies play automatically by default — a voice assistant that
                needs a tap to be heard isn't one. This is the escape hatch
                for a shared room or a user who would rather read; the replay
                button on each reply still works when it's off. */}
            <button
              className="icon-btn"
              onClick={() => {
                if (autoSpeak) voice.stop();
                setAutoSpeak((on) => !on);
              }}
              aria-pressed={autoSpeak}
              aria-label={
                autoSpeak
                  ? "Replies play aloud automatically. Tap to turn off."
                  : "Replies do not play automatically. Tap to turn on."
              }
              title={autoSpeak ? "Auto-play replies: on" : "Auto-play replies: off"}
            >
              {autoSpeak ? <Volume2 size={18} /> : <VolumeX size={18} />}
            </button>
            <button className="icon-btn" onClick={openReminders} aria-label="Open reminders" title="Reminders">
              <Bell size={18} />
            </button>
            <button
              className="icon-btn"
              onClick={() => setAccountOpen(true)}
              aria-label={user ? `Account: signed in as ${user.username}` : "Sign in or create an account"}
              title={user ? `Signed in as ${user.username}` : "Sign in"}
            >
              <User size={18} />
              {user && <span className="icon-btn__dot" aria-hidden="true" />}
            </button>
            <ThemeToggle />
          </div>
        </header>

        {screen === "home" ? (
          <div className="home-screen">
            <div className="home-screen__greeting">
              <p className={speech.isListening ? "home-screen__subtitle--live" : ""}>{subtitle}</p>
            </div>

            <AssistantOrb
              state={orbState}
              volume={speech.volume}
              size={200}
              onClick={handleOrbTap}
            />

            {/* Every voice failure the hook can produce is explained here.
                Until this existed, a blocked microphone, a missing capture
                device and an unreachable speech service all looked the
                same from the home screen: nothing at all. */}
            <VoiceStatus speech={speech} className="voice-status--home" />

            {voiceNotice && !speech.error && (
              <p className="voice-status voice-status--note" role="status">
                {voiceNotice}
              </p>
            )}

            {!speech.isSupported && (
              <p className="input-bar__hint">
                Voice input isn't supported here — try Chrome or Edge, or type below.
              </p>
            )}

            <button
              type="button"
              className="home-screen__type-toggle"
              onClick={() => setShowTypeInput((v) => !v)}
            >
              <Keyboard size={15} />
              {{ ta: "தட்டச்சு செய்", hi: "टाइप करें", te: "టైప్ చేయండి", kn: "ಟೈಪ್ ಮಾಡಿ" }[uiLang] ||
                "Type instead"}
            </button>

            {showTypeInput && (
              <div className="home-screen__text-row">
                <input
                  autoFocus
                  className="home-screen__text-input"
                  value={homeText}
                  onChange={(e) => setHomeText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleHomeTypeSend()}
                  /* Just says what the box is for. Which languages are
                     available is the header toggle's job, not the
                     placeholder's — and the old string wrapped and clipped
                     at phone width. */
                  placeholder="Type your message…"
                />
                <button className="icon-btn icon-btn--primary" onClick={handleHomeTypeSend} aria-label="Send">
                  <Send size={17} />
                </button>
              </div>
            )}

            {lastAssistantMessage && (
              <div className="home-screen__reply-card">
                <ReplyText text={lastAssistantMessage.text} dialable={lastAssistantMessage.dialable} />
                <VoiceOutStatus voice={voice} language={replyLanguage} />
                <SourceList
                  sources={lastAssistantMessage.sources}
                  staleness={lastAssistantMessage.staleness}
                />
                <button className="home-screen__reply-more" onClick={() => setScreen("conversation")}>
                  {{
                    ta: "முழு உரையாடலைக் காண",
                    hi: "पूरी बातचीत देखें",
                    te: "పూర్తి సంభాషణ చూడండి",
                    kn: "ಪೂರ್ಣ ಸಂಭಾಷಣೆ ನೋಡಿ",
                  }[uiLang] || "View full conversation"}
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            <ChatWindow
              messages={messages}
              isThinking={isThinking}
              onSpeak={handleSpeak}
              voiceState={voice.state}
              speakingId={speakingId}
            />
            <VoiceOutStatus voice={voice} className="voice-status--bar" />
            <InputBar onSend={handleSend} disabled={isThinking} speech={speech} />
          </>
        )}
      </div>
    </div>
  );
}
