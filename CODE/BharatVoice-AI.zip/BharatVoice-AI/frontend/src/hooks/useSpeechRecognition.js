import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Wraps the browser's SpeechRecognition API (webkitSpeechRecognition in
 * Chrome/Edge) for voice input, with every failure path surfaced instead of
 * swallowed.
 *
 * Why this was rewritten
 * -----------------------
 * The previous version reported "the orb does nothing when I speak", and it
 * had four separate ways to fail in silence:
 *
 *   1. `recognition.start()` was called outside a try/catch. It throws
 *      synchronously (InvalidStateError) if a session is already running,
 *      which left `isListening` stuck true and the orb dead until reload.
 *   2. `isListening` was set to true optimistically, before the browser
 *      confirmed anything. If the mic never opened, the UI said "Listening…"
 *      forever over a session that did not exist.
 *   3. `onerror` wrote to `error`, but the home screen never rendered it.
 *      `not-allowed` (permission blocked), `network` (the Web Speech service
 *      is a *cloud* service and needs a connection) and `audio-capture` (no
 *      microphone) all produced exactly nothing on screen.
 *   4. `getUserMedia` was called for the volume meter at the same moment
 *      recognition opened the mic. Its rejection was caught and discarded,
 *      so a permission prompt the user dismissed looked identical to
 *      working.
 *
 * What this version guarantees: the UI always knows which of
 * unsupported / idle / starting / listening it is in, every terminal state
 * has a message a non-technical person can act on, and the volume meter is
 * strictly decorative — it can never prevent or break recognition.
 *
 * `lang` is a BCP-47 locale. The Web Speech API takes exactly one per
 * session and cannot auto-detect, which is why the header language toggle
 * exists; `languageLabel` is only used to name that language in an error.
 */

// `continuous: false` is deliberate. With it true, Chrome keeps the session
// open long after the user stops talking, so a question spoken into the orb
// sat there with nothing being sent — the exact "not responding" symptom.
// False gives natural turn-taking: speak, it finalises, the caller sends.
const CONTINUOUS = false;

/**
 * Turn a SpeechRecognition error code into something a user can act on.
 *
 * These strings are English-only on purpose for now: they describe browser
 * and operating-system state ("allow the microphone in the address bar"),
 * and a machine-translated instruction about a browser UI the user sees in
 * their own locale would be worse than an accurate English one. Translating
 * them properly is listed in the README as outstanding work.
 */
function describeError(code, languageLabel) {
  switch (code) {
    case "not-allowed":
      return {
        code,
        message:
          "Microphone access is blocked. Tap the padlock or camera icon in your browser's address bar, allow the microphone for this site, then try again.",
        recoverable: true,
      };
    case "service-not-allowed":
      return {
        code,
        message:
          "Your browser blocked the speech service. This usually means the page isn't on a secure (https) address, or speech is turned off in browser settings.",
        recoverable: false,
      };
    case "audio-capture":
      return {
        code,
        message:
          "No microphone was found. Check that one is connected and not in use by another app, then try again.",
        recoverable: true,
      };
    case "network":
      return {
        code,
        message:
          "Speech recognition runs on the browser's own servers and couldn't reach them. Check your internet connection, or type your message instead.",
        recoverable: true,
      };
    case "language-not-supported":
      return {
        code,
        message: `Your browser can't recognise speech in ${
          languageLabel || "this language"
        }. Choose a different language from the header, or type your message instead.`,
        recoverable: false,
      };
    case "no-speech":
      return {
        code,
        message: "I didn't hear anything. Tap the orb and speak close to the microphone.",
        recoverable: true,
      };
    case "aborted":
      // The user pressed stop, or we did. Not a problem to report.
      return null;
    default:
      return {
        code,
        message: `Speech recognition stopped unexpectedly (${code}). You can try again, or type your message.`,
        recoverable: true,
      };
  }
}

export function useSpeechRecognition({ lang = "en-IN", languageLabel = "" } = {}) {
  const [isSupported] = useState(
    () =>
      typeof window !== "undefined" &&
      ("SpeechRecognition" in window || "webkitSpeechRecognition" in window)
  );

  // One explicit state machine instead of a pile of booleans. "starting"
  // is the state the old code had no name for, and it is exactly where the
  // silent failures lived: the gap between asking to listen and the browser
  // confirming it opened the microphone.
  const [status, setStatus] = useState(isSupported ? "idle" : "unsupported");
  const [transcript, setTranscript] = useState("");
  const [interimTranscript, setInterimTranscript] = useState("");
  const [volume, setVolume] = useState(0); // 0..1, drives the waveform
  const [error, setError] = useState(null);

  // Incremented every time a session ends, for any reason. Callers that
  // want to act on "the user finished speaking" watch this rather than a
  // false-edge on isListening: a counter fires even when two sessions end
  // back to back, and it cannot be missed by a batched render.
  const [sessionEnd, setSessionEnd] = useState(0);

  const recognitionRef = useRef(null);
  const audioCtxRef = useRef(null);
  const rafRef = useRef(null);
  const streamRef = useRef(null);
  const startTimerRef = useRef(null);
  // Set when we call stop() ourselves, so `aborted` from a deliberate stop
  // is never reported as a failure.
  const stoppingRef = useRef(false);

  const isListening = status === "listening" || status === "starting";

  const stopVolumeMeter = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    if (audioCtxRef.current) audioCtxRef.current.close().catch(() => {});
    audioCtxRef.current = null;
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setVolume(0);
  }, []);

  /**
   * Best-effort waveform animation.
   *
   * This opens a *second* microphone stream alongside the one
   * SpeechRecognition holds. That is fine in Chrome, but it is decoration:
   * if it fails for any reason the orb simply doesn't pulse, and
   * recognition carries on. It is started only after the browser confirms
   * recognition is running, so it can never be the thing that blocks it.
   */
  const startVolumeMeter = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      const audioCtx = new AudioContext();
      audioCtxRef.current = audioCtx;
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      audioCtx.createMediaStreamSource(stream).connect(analyser);

      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteFrequencyData(data);
        const avg = data.reduce((a, b) => a + b, 0) / data.length;
        setVolume(Math.min(1, avg / 100));
        rafRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch {
      // Decoration only — never surfaced, never fatal. A real permission
      // problem arrives through recognition.onerror as `not-allowed`,
      // which is the message the user actually needs.
      setVolume(0);
    }
  }, []);

  const finishSession = useCallback(() => {
    if (startTimerRef.current) {
      clearTimeout(startTimerRef.current);
      startTimerRef.current = null;
    }
    recognitionRef.current = null;
    stoppingRef.current = false;
    setStatus("idle");
    stopVolumeMeter();
    setSessionEnd((n) => n + 1);
  }, [stopVolumeMeter]);

  const start = useCallback(() => {
    if (!isSupported) {
      setError({
        code: "unsupported",
        message:
          "This browser doesn't support voice input. Chrome or Edge on a computer or Android phone will work — or type your message instead.",
        recoverable: false,
      });
      return;
    }

    // Chrome refuses getUserMedia and SpeechRecognition outside a secure
    // context and reports it only as a generic failure. Saying so up front
    // is the difference between "it's broken" and "open it on localhost".
    if (typeof window !== "undefined" && window.isSecureContext === false) {
      setError({
        code: "insecure-context",
        message:
          "Voice input needs a secure connection. Open this page on https:// or on localhost, then try again.",
        recoverable: false,
      });
      return;
    }

    // Guard against double-start: `recognition.start()` throws
    // InvalidStateError if a session is live, and that exception used to
    // escape and wedge the UI.
    if (recognitionRef.current) return;

    setError(null);
    setTranscript("");
    setInterimTranscript("");

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = lang;
    recognition.continuous = CONTINUOUS;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      // Only now is the microphone genuinely open. This is the authoritative
      // signal; everything before it is "starting".
      if (startTimerRef.current) {
        clearTimeout(startTimerRef.current);
        startTimerRef.current = null;
      }
      setStatus("listening");
      startVolumeMeter();
    };

    recognition.onresult = (event) => {
      let finalText = "";
      let interimText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const chunk = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += chunk;
        else interimText += chunk;
      }
      if (finalText) setTranscript((prev) => (prev + " " + finalText).trim());
      setInterimTranscript(interimText);
    };

    recognition.onerror = (event) => {
      if (stoppingRef.current && event.error === "aborted") return;
      const described = describeError(event.error, languageLabel);
      if (described) setError(described);
    };

    recognition.onend = finishSession;

    recognitionRef.current = recognition;
    setStatus("starting");

    try {
      recognition.start();
    } catch (e) {
      recognitionRef.current = null;
      setStatus("idle");
      setError({
        code: "start-failed",
        message: `Couldn't start the microphone (${e?.name || "unknown error"}). Reload the page and try again, or type your message.`,
        recoverable: true,
      });
      return;
    }

    // If `onstart` never arrives the session does not exist, and without
    // this the orb would sit in "starting" with no explanation. Chrome does
    // this when no capture device is present and, on some machines, when
    // another application holds the microphone exclusively.
    startTimerRef.current = setTimeout(() => {
      startTimerRef.current = null;
      setStatus((current) => {
        if (current !== "starting") return current;
        setError({
          code: "no-start",
          message:
            "The microphone didn't open. Another app may be using it, or the browser is still waiting for permission — check the address bar, then try again.",
          recoverable: true,
        });
        try {
          recognitionRef.current?.abort();
        } catch {
          /* already gone */
        }
        recognitionRef.current = null;
        return "idle";
      });
    }, 4000);
  }, [isSupported, lang, languageLabel, startVolumeMeter, finishSession]);

  const stop = useCallback(() => {
    const recognition = recognitionRef.current;
    if (!recognition) {
      // Nothing running, but make sure the UI isn't stuck showing otherwise.
      setStatus((current) => (current === "idle" ? current : "idle"));
      return;
    }
    stoppingRef.current = true;
    try {
      // `stop()` asks for a final result first, which is what makes the
      // last thing the user said survive into the transcript.
      recognition.stop();
    } catch {
      try {
        recognition.abort();
      } catch {
        /* nothing more to do */
      }
      finishSession();
    }
  }, [finishSession]);

  const reset = useCallback(() => {
    setTranscript("");
    setInterimTranscript("");
  }, []);

  const clearError = useCallback(() => setError(null), []);

  useEffect(
    () => () => {
      if (startTimerRef.current) clearTimeout(startTimerRef.current);
      try {
        recognitionRef.current?.abort();
      } catch {
        /* unmounting anyway */
      }
      stopVolumeMeter();
    },
    [stopVolumeMeter]
  );

  return {
    isSupported,
    status,
    isListening,
    isStarting: status === "starting",
    transcript,
    interimTranscript,
    volume,
    error,
    sessionEnd,
    start,
    stop,
    reset,
    clearError,
  };
}
