import { useCallback, useEffect, useRef, useState } from "react";
import { getSpeechCapabilities, synthesizeSpeech } from "../services/api";
import { toSpeech } from "../utils/replyFormat";

/**
 * Everything that decides whether, how and in what language a reply is read
 * aloud. This is deliberately the ONLY place that decision is made.
 *
 * It used to be made in three places — App.jsx's reply handler, App.jsx's
 * replay handler, and this hook — each with its own idea of what to do when
 * there was no voice. The reply handler's version was
 * `new Audio(url).play().catch(() => {})`, which swallowed autoplay blocks
 * whole: the browser refused to play, nothing appeared on screen, and the
 * app looked broken in exactly the way a user cannot diagnose.
 *
 * THE CHAIN, in order:
 *
 *   1. A voice installed on this device for this language. Instant, free,
 *      offline. Almost always the right answer when it exists.
 *   2. Server synthesis (POST /api/speech/synthesize -> Bhashini). Covers
 *      the case this whole chain exists for: the measured demo machine has
 *      five voices, all English, zero Indic, so every Tamil, Telugu and
 *      Kannada reply was silent.
 *   3. Neither. Say so, in words, and keep the text on screen. An
 *      explanation is a worse outcome than audio but a far better one than
 *      silence, and it is the honest end of the chain rather than a failure
 *      of it.
 *
 * WHAT IT NEVER DOES: speak a reply in a language other than the one it was
 * written in. Reading a Tamil answer with an English voice produces
 * confident nonsense the user cannot tell from a real answer, so a missing
 * voice always resolves to case 3, never to a substitution.
 *
 * States, all of which the UI shows:
 *   idle        nothing playing
 *   loading     waiting on server synthesis (seconds, so it needs to show)
 *   speaking    audio is actually playing
 *   blocked     the browser refused to autoplay; the user must tap once
 *   unavailable no voice anywhere for this language; `notice` says so
 */

// Our internal codes to the BCP-47 locales the browser understands.
// Code-mixed markers ("ta-en") resolve to the base language's voice: there
// is no mixed-register voice, and an Indic voice handles the Indic words
// far better than an English voice handles either.
const LOCALES = {
  ta: "ta-IN",
  hi: "hi-IN",
  te: "te-IN",
  kn: "kn-IN",
  en: "en-IN",
};

const LANGUAGE_NAMES = {
  ta: "தமிழ்",
  hi: "हिंदी",
  te: "తెలుగు",
  kn: "ಕನ್ನಡ",
  en: "English",
};

export function baseLanguage(language) {
  return (language || "en").split("-")[0].toLowerCase();
}

export function localeFor(language) {
  return LOCALES[baseLanguage(language)] || "en-IN";
}

export function languageName(language) {
  return LANGUAGE_NAMES[baseLanguage(language)] || language;
}

// How long to wait for `onstart` before concluding the utterance will never
// be spoken. Chrome can accept an utterance and silently never start it —
// most reliably when the requested voice is absent, which is precisely our
// case. Without this the UI sits on "speaking" forever for a reply that
// makes no sound.
const SPEAK_START_TIMEOUT_MS = 2000;

export function useSpeechSynthesis() {
  const isSupported = typeof window !== "undefined" && "speechSynthesis" in window;

  const [state, setState] = useState("idle");
  const [notice, setNotice] = useState(null);
  const [voices, setVoices] = useState([]);
  // null until the capability call answers. Distinguishing "not asked yet"
  // from "server has nothing" matters: the first must not produce a
  // "no voice available" message that a moment later becomes wrong.
  const [serverVoices, setServerVoices] = useState(null);

  const audioRef = useRef(null);
  const startTimerRef = useRef(null);
  // Audio the browser refused to autoplay, kept so one tap can play it
  // rather than re-synthesizing.
  const pendingRef = useRef(null);

  // Chrome populates the voice list asynchronously and fires
  // `voiceschanged` when it does, so a check made at mount would find an
  // empty list and wrongly report every language as unsupported.
  useEffect(() => {
    if (!isSupported) return undefined;
    const load = () => setVoices(window.speechSynthesis.getVoices() || []);
    load();
    window.speechSynthesis.addEventListener?.("voiceschanged", load);
    return () => window.speechSynthesis.removeEventListener?.("voiceschanged", load);
  }, [isSupported]);

  // What the server can speak. Asked once; a failure here is not worth
  // surfacing, it just means the chain has one fewer link.
  useEffect(() => {
    let cancelled = false;
    getSpeechCapabilities()
      .then((data) => {
        if (!cancelled) setServerVoices(data?.languages || {});
      })
      .catch(() => {
        if (!cancelled) setServerVoices({});
      });
    return () => {
      cancelled = true;
    };
  }, []);

  /**
   * The installed voice for a language, or null.
   *
   * Matches on the language subtag rather than the full locale: a device
   * with `ta-LK` or a generic `ta` voice can still read Tamil, and
   * rejecting it for not being exactly `ta-IN` would be a false negative.
   */
  const voiceFor = useCallback(
    (language) => {
      const locale = localeFor(language);
      const base = locale.split("-")[0];
      return (
        voices.find((v) => v.lang?.replace("_", "-") === locale) ||
        voices.find((v) => v.lang?.replace("_", "-").split("-")[0] === base) ||
        null
      );
    },
    [voices]
  );

  /**
   * Where a reply in this language would be spoken from, before trying.
   *
   * `via` is "device", "server", null (nothing available) or "unknown"
   * (the voice list or the capability call hasn't answered yet). "unknown"
   * exists so the UI stays quiet instead of briefly claiming a language
   * cannot be spoken and then contradicting itself.
   */
  const availability = useCallback(
    (language) => {
      const base = baseLanguage(language);
      if (!isSupported && serverVoices === null) return { via: "unknown" };
      if (isSupported && voices.length === 0 && serverVoices === null) {
        return { via: "unknown" };
      }
      if (isSupported && voiceFor(language)) {
        return { via: "device", name: voiceFor(language).name };
      }
      if (serverVoices === null) return { via: "unknown" };
      if (serverVoices[base]) return { via: "server", engine: serverVoices[base] };
      return { via: null };
    },
    [isSupported, voices.length, voiceFor, serverVoices]
  );

  const clearTimer = () => {
    if (startTimerRef.current) {
      clearTimeout(startTimerRef.current);
      startTimerRef.current = null;
    }
  };

  const stop = useCallback(() => {
    clearTimer();
    if (isSupported) window.speechSynthesis.cancel();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    pendingRef.current = null;
    setState("idle");
  }, [isSupported]);

  /** Play a server-produced audio URL, handling an autoplay refusal. */
  const playUrl = useCallback((url) => {
    const audio = new Audio(url);
    audioRef.current = audio;
    audio.onended = () => setState("idle");
    audio.onerror = () => {
      setState("unavailable");
      setNotice({
        kind: "error",
        message: "The audio for this reply could not be played. The full answer is shown above.",
      });
    };
    return audio
      .play()
      .then(() => {
        setState("speaking");
        pendingRef.current = null;
      })
      .catch(() => {
        // Autoplay policy: a browser will refuse audio that isn't tied to a
        // user gesture. This is not an error to hide — it is a thing the
        // user can fix with one tap, so keep the audio and say so.
        pendingRef.current = url;
        setState("blocked");
        setNotice({
          kind: "blocked",
          message: "Your browser blocked automatic audio. Tap play to hear this reply.",
        });
      });
  }, []);

  /** Speak with a device voice. Resolves false if it never actually starts. */
  const speakWithDevice = useCallback(
    (spoken, language, voice) =>
      new Promise((resolve) => {
        const utterance = new SpeechSynthesisUtterance(spoken);
        utterance.lang = localeFor(language);
        // Setting the voice explicitly matters: left to `lang` alone, Chrome
        // on Windows often falls back to the default English voice and reads
        // Tamil text with English phonetics, which is unintelligible.
        utterance.voice = voice;
        utterance.rate = 1;
        utterance.pitch = 1;

        let started = false;
        utterance.onstart = () => {
          started = true;
          clearTimer();
          setState("speaking");
          resolve(true);
        };
        utterance.onend = () => {
          clearTimer();
          setState((current) => (current === "speaking" ? "idle" : current));
        };
        utterance.onerror = () => {
          clearTimer();
          if (!started) resolve(false);
        };

        startTimerRef.current = setTimeout(() => {
          if (!started) {
            window.speechSynthesis.cancel();
            resolve(false);
          }
        }, SPEAK_START_TIMEOUT_MS);

        window.speechSynthesis.speak(utterance);
      }),
    []
  );

  /**
   * Read a reply aloud, walking the chain until something works or nothing
   * does. Always resolves — callers never need to catch.
   */
  const speak = useCallback(
    async (text, language = "en") => {
      const spoken = toSpeech(text);
      if (!spoken) return "idle";

      stop();
      setNotice(null);

      const base = baseLanguage(language);
      const name = languageName(base);

      // 1. A device voice.
      const voice = isSupported ? voiceFor(language) : null;
      if (voice) {
        setState("speaking");
        const ok = await speakWithDevice(spoken, language, voice);
        if (ok) return "speaking";
        // Accepted but never spoken. Fall through to the server rather than
        // leaving the user with a UI that claims to be speaking.
      }

      // 2. Server synthesis.
      const serverEngine = serverVoices?.[base];
      if (serverEngine) {
        setState("loading");
        try {
          const result = await synthesizeSpeech({ text: spoken, language: base });
          if (result?.audio_url) {
            await playUrl(result.audio_url);
            return "speaking";
          }
        } catch {
          // Fall through to the honest ending below.
        }
      }

      // 3. Nothing. Say which language, and why, and leave the text up.
      setState("unavailable");
      setNotice({
        kind: "unavailable",
        message: serverVoices && Object.keys(serverVoices).length > 0 && !serverEngine
          ? `This device has no ${name} voice, and the server has no ${name} voice configured either. The full answer is shown above.`
          : `This device has no ${name} voice installed, so the answer can't be read aloud here. The full answer is shown above.`,
      });
      return "unavailable";
    },
    [isSupported, voiceFor, speakWithDevice, serverVoices, playUrl, stop]
  );

  /** Play audio the browser refused to autoplay. Requires a user gesture. */
  const playPending = useCallback(() => {
    const url = pendingRef.current;
    if (!url) return;
    setNotice(null);
    playUrl(url);
  }, [playUrl]);

  const clearNotice = useCallback(() => setNotice(null), []);

  return {
    speak,
    stop,
    playPending,
    hasPending: () => Boolean(pendingRef.current),
    availability,
    state,
    notice,
    clearNotice,
    isSpeaking: state === "speaking",
    isLoadingAudio: state === "loading",
    isSupported,
    // The raw capability map, for anything that wants to report on all five
    // languages at once rather than the current one.
    serverVoices,
  };
}
