import js from "@eslint/js";
import globals from "globals";
import react from "eslint-plugin-react";
import reactHooks from "eslint-plugin-react-hooks";

// Deliberately close to the recommended sets, in the same spirit as
// backend/ruff.toml: catch real mistakes (undefined names, unused
// imports, broken hook rules) without starting a style argument.
export default [
  { ignores: ["dist/**", "node_modules/**"] },

  js.configs.recommended,

  {
    files: ["src/**/*.{js,jsx}"],
    plugins: { react, "react-hooks": reactHooks },
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: globals.browser,
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    settings: { react: { version: "detect" } },
    rules: {
      ...react.configs.recommended.rules,
      ...react.configs["jsx-runtime"].rules,
      "react-hooks/rules-of-hooks": "error",
      "react-hooks/exhaustive-deps": "warn",
      // This project has no PropTypes and no TypeScript; turning the rule
      // on would be several hundred warnings and no caught bugs.
      "react/prop-types": "off",
      // Copy is written with real apostrophes and quotes throughout.
      "react/no-unescaped-entities": "off",
      // `inert` is a real HTML attribute that this React version does not
      // know yet; the drawers rely on it (see HistoryDrawer.jsx).
      "react/no-unknown-property": ["error", { ignore: ["inert"] }],
      "no-unused-vars": ["error", { argsIgnorePattern: "^_", caughtErrors: "none" }],
    },
  },

  {
    // The service worker runs in its own global scope, not the page's.
    files: ["public/sw.js"],
    languageOptions: { globals: globals.serviceworker },
  },

  {
    files: ["src/**/*.test.{js,jsx}", "src/test/**"],
    languageOptions: { globals: { ...globals.browser, ...globals.node } },
  },

  {
    files: ["*.config.js"],
    languageOptions: { globals: globals.node },
  },
];
