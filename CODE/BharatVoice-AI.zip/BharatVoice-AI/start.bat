@echo off
echo ========================================================
echo   Starting BharatVoice AI (Backend + Frontend)
echo ========================================================

echo Stopping any existing instances on ports 8000 and 5173...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000 ^| findstr LISTENING') do taskkill /f /pid %%a 2>nul
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5173 ^| findstr LISTENING') do taskkill /f /pid %%a 2>nul

set PYTHON_EXE=C:\Users\Keerthana.R\AppData\Local\Programs\Python\Python312\python.exe
if not exist "%PYTHON_EXE%" (
    set PYTHON_EXE=python
)

echo Starting Backend on http://localhost:8000 ...
start "BharatVoice Backend" cmd /k "cd /d "%~dp0backend" && "%PYTHON_EXE%" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload"

ping -n 3 127.0.0.1 >nul

echo Starting Frontend on http://localhost:5173 ...
start "BharatVoice Frontend" cmd /k "cd /d "%~dp0frontend" && npm.cmd run dev"

ping -n 4 127.0.0.1 >nul

echo Opening browser at http://localhost:5173 ...
start http://localhost:5173

echo ========================================================
echo   BharatVoice AI is now running!
echo   Frontend: http://localhost:5173
echo   Backend:  http://localhost:8000
echo ========================================================
