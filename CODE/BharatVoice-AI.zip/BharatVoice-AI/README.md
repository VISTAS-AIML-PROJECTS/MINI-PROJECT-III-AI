# BharatVoice AI — A Multilingual Intelligent Assistant for Indian Languages

BharatVoice AI is a voice- and text-driven AI assistant built for Indian
languages. It currently understands and replies in **Tamil, Hindi, Telugu,
Kannada and English**, including code-mixed speech ("Tanglish", "Hinglish"),
with a clean architecture designed to expand into healthcare, agriculture,
education, banking, and government services.

## Language support — what is actually verified

Being precise about this matters more than the headline count:

| Language | Identification | Understanding | Replies | Native-speaker review |
|---|---|---|---|---|
| English  | ✅ | ✅ | ✅ | n/a |
| Tamil    | ✅ | ✅ | ✅ | ⚠️ pending |
| Hindi    | ✅ | ✅ | ✅ | ⚠️ pending |
| Telugu   | ✅ | ✅ | ✅ (best-effort wording) | ❌ **required** |
| Kannada  | ✅ | ✅ | ✅ (best-effort wording) | ❌ **required** |

Language identification is exact for native script (the four scripts sit in
disjoint Unicode blocks) and heuristic for romanized/code-mixed input.

All five languages have full content coverage — conversational replies, all
nine emergency helpline labels, and all six government-document
explanations. Nothing falls back to English any more, and three tests
enforce that (`test_every_helpline_label_is_translated`,
`test_every_government_document_is_translated`,
`test_government_document_reply_differs_by_language`).

Strings marked `# NEEDS REVIEW` — the Hindi, Telugu and Kannada ones — have
not been read by a native speaker. The document explanations are
deliberately conservative: they say what the document is and which portal
issues it, and nothing about eligibility, fees or timelines, because those
are the claims where a translation error does real harm. Every such reply
also carries a note, in the user's own language, pointing at the official
portal.

Speech in/out currently uses the browser's Web Speech API, which accepts one
recognition locale at a time — so users should select their language from
the header toggle. Server-side ASR (Bhashini or Whisper) removes that
limitation and is the main planned upgrade.

`app/services/about.py` holds the single source of truth for per-language
status (`LANGUAGE_SUPPORT`). The assistant's own answer to "which languages
do you support" is generated from that table rather than written out, and
`GET /api/language/support` serves it to the UI, so the claim on screen and
the review status in the source cannot drift apart.

## What's in this version

A Siri/Alexa-style voice-first redesign, built for everyday citizen needs
rather than a generic chatbot:

- **Voice-first home screen** — a large pulsing orb as the primary way to
  interact, with quick-tap suggestions for common requests, instead of a
  chat window as the default view.
- **Real citizen-useful skills**, not demo text: live time/date, a safe
  arithmetic calculator, unit conversion (length/weight/temperature),
  verified emergency helpline numbers, general guidance on Aadhaar/PAN/
  Voter ID/Ration Card/Passport/Driving License, cited answers across seven
  further domains (scholarships, bank accounts, online fraud and scams,
  trains and buses, government schemes, jobs, finding a hospital), and
  reminders that actually persist to the database and fire on time.
- **Conversation history and reminders** live in slide-out drawers, kept
  out of the way until you need them.

```
User speaks/types → Speech-to-Text → Language Detection → Intent Detection
→ Entity Extraction → Action Execution → Response Generation
→ Text-to-Speech → Voice-first UI
```

## Tech stack

| Layer            | Technology                                              |
|-------------------|----------------------------------------------------------|
| Frontend           | React (Vite)                                              |
| Backend             | FastAPI (Python)                                          |
| Database             | SQLite (via SQLAlchemy)                                   |
| Speech-to-Text       | OpenAI Whisper *(backend, optional)* / Web Speech API *(browser, default)* |
| NLP (intent/NER)      | MuRIL / IndicBERT *(pluggable)* / rule-based fallback     |
| Translation            | AI4Bharat IndicTrans2 *(pluggable)* / dictionary fallback |
| Text-to-Speech          | Coqui TTS *(backend, optional)* / SpeechSynthesis API *(browser, default)* |
| Reply wording            | Google Gemini *(optional, with `GEMINI_API_KEY`)* / rule-based replies *(default)* |

## Why it runs immediately, with no GPU or model downloads

The four heaviest ML components — Whisper, MuRIL/IndicBERT, IndicTrans2, and
Coqui TTS — are all **large, optional dependencies**. Rather than requiring
them just to try the app, every backend service in `backend/app/services/`
is written with a layered fallback: it uses the real model automatically if
installed, and otherwise falls back to a fast, honest, rule-based
implementation (documented in `backend/README.md`). Voice input/output uses
the browser's built-in Web Speech APIs by default, so the full voice
experience works out of the box in Chrome/Edge with zero backend ML setup.
This keeps the foundation demoable today while giving you a clear,
documented path to swap in production-grade models later.

## Getting started

**Option A — Docker (recommended, one command)**

```bash
docker compose up --build
```

Then open `http://localhost:3000`. This builds and runs both the backend
(port 8000, internal) and frontend (port 3000) with the SQLite DB and any
generated TTS audio persisted in named volumes across restarts. See
`docker-compose.yml`, `backend/Dockerfile`, and `frontend/Dockerfile`.

**Option B — Run each service manually**

**1. Backend**

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

**2. Frontend** (in a separate terminal)

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`, click the mic (or type), and talk to
BharatVoice in Tamil, English, or a mix of both. Full setup details are in
`backend/README.md` and `frontend/README.md`.

### Turning on live mandi prices

Wholesale crop prices come from AGMARKNET's daily feed, published through
data.gov.in. That endpoint needs **your own free key** — the sample key in
data.gov.in's own examples is shared by every tutorial online and is
permanently rate-limited, so it is not usable as a default.

**1. Generate a key** (about a minute, free)

1. Register at <https://data.gov.in> and confirm your email.
2. Sign in, open your profile, and choose **Generate API key** (some pages
   label it "My API key" or "APIs → Get API key").
3. Copy the long alphanumeric string. Treat it as a password — it is tied
   to your account and rate-limited per key.

**2. Give it to the app.** There are two `.env` files and they are *not*
interchangeable — which one you need depends on how you run the backend:

| How you run it | File to edit | Read by |
| --- | --- | --- |
| `docker compose up` | `.env` in the repository root, beside `docker-compose.yml` | Docker Compose, which passes it into the backend container |
| `uvicorn` / `start.bat` | `backend/.env` | the backend's own pydantic settings loader |

For Docker:

```bash
cp .env.example .env
```

Then edit `.env` and put your key after the `=`:

```
DATA_GOV_API_KEY=your-key-here
```

Restart the backend so it picks the value up. A rebuild is not needed —
this is an environment variable, not baked into the image:

```bash
docker compose up -d --force-recreate backend
```

For a directly-run backend, `cp backend/.env.example backend/.env`, add the
same line, and restart `uvicorn` (`--reload` does not pick up `.env`
changes; stop and start it).

Either way, both `.env` files are git-ignored, so your key stays on your
machine. Only the `.env.example` placeholders are committed. Never paste a
real key into `docker-compose.yml`, into an example file, or into a commit.

**3. Check it worked.** Ask the assistant "tomato mandi price". You should
get a short list of markets with a price range, a modal price, an
AGMARKNET source link and the dataset's arrival date. If you instead see
"live mandi prices aren't switched on", the key did not reach the
container — confirm it with:

```bash
docker compose exec backend printenv DATA_GOV_API_KEY
```

With no key, or when the upstream fails, the assistant says it could not
fetch today's price and links to agmarknet.gov.in. It never invents a
price and never reuses a cached one past its hour-long TTL. That is the
intended behaviour, not a bug to work around.

### Letting Gemini answer

With a Gemini API key, Google's Gemini answers every chat message and is
the **only** outside service a message reaches. Get a key at
<https://aistudio.google.com/apikey>, add it to the same `.env` file as
above (root `.env` for Docker, `backend/.env` for a directly-run backend)
and restart the backend:

```
GEMINI_API_KEY=your-key-here
```

What changes and what doesn't:

- **Weather, mandi prices, hospitals and every other question** go
  straight to Gemini. Open-Meteo, data.gov.in and the hospital directory
  are not called, so Gemini has no live data: it says it can't check
  today's weather or prices and points to where to look. These replies
  carry **no source links**: they are a model's text and can be wrong.
- **Reminders, the time and date, arithmetic, unit conversion and the
  helpline list** are still worked out on this machine (no API). A reminder
  is still saved so it fires. Gemini only rewords these answers, and they
  keep their tap-to-call numbers.
- **If Gemini fails** on a message, the reply says Gemini couldn't be
  reached. It does not fall back to another service.
- **No key** and the app works as before, with its rule-based replies and
  live lookups.

`GEMINI_MODEL` picks the model (default `gemini-3.5-flash`). The key is
sent in a request header, never in the URL. Typed and spoken questions are
sent to Google when a key is set.

## Feature checklist

- [x] Modern, responsive UI with light/dark themes
- [x] Voice-first home screen (orb) that keeps you there and shows the reply
- [x] Voice input (browser mic) with live waveform visualization
- [x] Text chat input
- [x] Speech-to-text (Whisper-ready backend + working browser fallback)
- [x] Language identification across 5 languages incl. code-mixed
- [x] Intent detection in all 5 languages
- [x] Entity extraction (person, place, date incl. numeric, time)
- [x] Response generation per intent, per language
- [x] Text-to-speech playback, per-language voice
- [x] Live weather from Open-Meteo, cited and timestamped, in all 5 languages
- [x] Mandi (crop) prices from AGMARKNET, cached and cited — needs a free
      data.gov.in key, and refuses honestly without one
- [x] Curated, cited FAQ across seven domains — education, banking, scam
      awareness, travel, schemes, jobs, health facilities
- [x] Reminders that actually fire — parsed `due_at`, in-app alert + spoken
- [x] Tappable `tel:` helpline numbers
- [x] Source citations on fact-bearing answers (`sources` on every reply)
- [x] Explicit refusals instead of invented data
- [x] Conversation history + reminders, persisted in SQLite
- [x] App-level FAQ: what BharatVoice is, which languages, how it detects
      them, whether it works offline, what happens to your data, where its
      information comes from — in all 5 languages
- [x] Optional accounts: every browser has its own private history as a
      guest, and signing in carries it across devices
- [x] Reminders delivered as notifications when the page is closed (web push)
- [x] Helpline numbers tappable inside sentences, marked by the backend
- [x] Hospital lookup from the National Hospital Directory — needs the same
      free data.gov.in key as mandi prices
- [x] IMD severe-weather warnings on weather answers — needs IMD API access
- [x] Database migrations (Alembic), applied automatically on startup
- [x] Fine-tuned MuRIL intent and language models, trained on about 300
      generated questions per intent and used only behind guards — on
      hand-written test questions the app goes from 67% to 89% on intent
      and from 60% to 95% on language (see `backend/README.md` for what
      those numbers do and do not show)
- [x] Automated test suites: 752 backend tests (`cd backend && pytest`) and
      45 frontend tests (`cd frontend && npm test`), plus `ruff` and `eslint`
- [x] One-command Docker setup (`docker compose up --build`)

## Domain coverage, and how each one is answered

Not every domain can be answered the same way, and the difference is the
interesting part of the design:

| Domain | How it's answered | Live? |
|---|---|---|
| Weather | Open-Meteo adapter | ✅ live, timestamped |
| Mandi prices | AGMARKNET via data.gov.in | ✅ live *with a free API key*, else refuses |
| Emergency | Curated helplines, `tel:` links | static, cited |
| Documents | Curated (Aadhaar/PAN/Voter ID/Ration/Passport/DL) | static, cited |
| Education | Curated FAQ → NSP, state dept, DIKSHA | static, cited |
| Banking | Curated FAQ → PMJDY, RBI, RBI Ombudsman | static, cited |
| Scam awareness | Curated FAQ → cybercrime.gov.in, 1930 | static, cited |
| Travel | Curated FAQ → IRCTC, NTES, state RTCs | static, cited |
| Schemes | Curated FAQ → myScheme, PM-KISAN, PM-JAY | static, deep-linked |
| Jobs | Curated FAQ → National Career Service | static, deep-linked |
| Health facilities | Curated FAQ → ABDM Health Facility Registry | static, deep-linked |
| The app itself | `services/about.py` — what it is, languages, privacy, sources | static, uncited *(no external portal to cite)* |

**Why curated rather than scraped.** None of those portals has a free,
documented, public API — and scraping them would mean a paraphrase of a
government rule that goes stale in a UI nobody controls. So each entry says
what the thing is and where the authoritative answer lives, and stops. Three
rules are enforced by tests rather than by review: no entry may quote a
rupee amount or a percentage (those are the figures that drift), no entry
may deliver an eligibility verdict, and every entry must carry a source and
be translated into all five languages.

Adding a live adapter later doesn't disturb any of this — the citation
contract and the refusal path are already what the curated answers use.

### Known gaps (deliberate, not hidden)

- **Mandi prices need your own data.gov.in key.** Set `DATA_GOV_API_KEY`
  in the root `.env` for Docker or `backend/.env` when running uvicorn
  directly — see "Turning on live mandi prices" above (free, one minute to
  register). The shared demo key in
  data.gov.in's own documentation returns `{"error": "Rate limit
  exceeded"}` — measured 2026-09-27 — because every tutorial uses it. The
  same endpoint was measured returning a 45s timeout, a 504 and a 502 on
  2026-09-26, which is why the adapter caches, times out at 6s and treats
  an `{"error": ...}` body inside an HTTP 200 as a failure. **The field
  mapping has not been confirmed against a live 200 response**, since no
  successful call was possible without a key — verify that first.
- **Jobs and scheme data are deep links, not lookups.** NCS search sits
  behind a session and myScheme has no documented public API, so neither
  can be searched lawfully. Each is answered with cited guidance that says
  plainly that the assistant cannot search it. Changing that needs API
  access granted by those portals.
- **Hospital lookup is built but unproven.** "Hospitals in Madurai" is
  answered from the National Hospital Directory on data.gov.in when
  `DATA_GOV_API_KEY` is set. No successful call has been made — there was
  no key, and data.gov.in returned HTTP 503 on 2026-10-06 — so the dataset
  id (`HOSPITAL_RESOURCE_ID`) and the field names in
  `services/hospitals.py` are unverified. Without a key, or on any
  failure, the curated answer is used.
- **IMD warnings are built but need access, and are unproven.** A weather
  answer gains an IMD district warning line when `IMD_WARNINGS_URL` is
  set. IMD grants API access per organisation and IP address, on request;
  none was available, so the response shape in `services/imd.py` comes
  from IMD's published note, not an observed response. Open-Meteo remains
  the source of the reading itself.
- **Accounts have no password reset and no sign-in rate limit.** Both need
  infrastructure this project lacks (a mail provider, a shared counter).
  Do not expose the app to the open internet without them.
- **Notifications need the backend running and the browser open.** A
  closed tab is fine; a fully closed desktop browser usually is not. Push
  delivery has been tested up to the signed request, not through a real
  browser's push service.
- **Hindi/Telugu/Kannada wording is unreviewed.** Content coverage is
  complete; native-speaker review is not. See the language table above.
- **Emergency numbers carry `checked_on = None`** because nobody has
  re-verified them against the official portals as part of this work. Set
  the date in `skills.EMERGENCY_SOURCES` once a human has; a test enforces
  that it stays `None` until then.
- **Voice failure messages are English-only.** `useSpeechRecognition`
  explains every failure it can hit — blocked microphone, no capture
  device, unreachable speech service, unsupported recognition language,
  a session that never started — but those strings describe browser and
  operating-system UI ("tap the padlock in the address bar"), which a
  machine translation would describe wrongly. They need a native speaker,
  not a translation pass.
- **Spoken replies depend on the device's installed voices.** The browser
  ships no Indic voices by default on most desktops. The app now checks
  `speechSynthesis.getVoices()` at runtime and says "this device has no
  Tamil voice installed" instead of going silently quiet, but installing
  the voice is something only the user can do (Windows: Settings → Time &
  Language → Speech). Server-side TTS removes this.
- **Voice input has not been exercised with a real microphone here.** Every
  failure path was tested (a blocked mic produces the message above), but
  end-to-end recognition in each of the five languages needs a human with
  a microphone in Chrome or Edge — see "What still needs a human" below.

### What still needs a human

Five things cannot be verified by code or by the test suite, and none of
them should be described as done until someone has actually done them:

1. **Microphone test, per language.** Open the app in Chrome or Edge, pick
   each language from the header toggle, tap the orb and speak. Check that
   the orb enters "listening", the words appear under it as you talk, the
   question is sent when you stop, and the answer is both shown and read
   aloud. Recognition quality for `ta-IN`, `hi-IN`, `te-IN` and `kn-IN` is
   the browser vendor's, not this project's, and has not been measured.
2. **Native-speaker review** of every string marked `# NEEDS REVIEW` —
   Hindi, Telugu and Kannada, in `services/knowledge.py`,
   `services/about.py`, `services/skills.py` and
   `services/response_generator.py`. Until that happens
   `about.LANGUAGE_SUPPORT` records those three as
   `needs-native-review`, and the assistant says so when asked which
   languages it supports.
3. **Verify the nine helpline numbers** against the official portals, then
   set `checked_on` in `skills.EMERGENCY_SOURCES`. A test keeps it `None`
   until you do.
4. **A free data.gov.in key** if mandi prices are to be demonstrated live
   — root `.env` for Docker, `backend/.env` for a direct run; see "Turning
   on live mandi prices". The passthrough and the honest fallbacks are
   tested, but **no successful live call has ever been made**, so the first
   real lookup is also the first confirmation that the field names in
   `services/mandi.py` (`market`, `commodity`, `arrival_date`,
   `min_price`, `max_price`, `modal_price`) match the response. If prices
   come back empty with a valid key, that mapping is where to look.
5. **An independent accuracy check for the MuRIL models.** Their test
   questions were written by the same author as their training data, so
   the reported 89% and 95% are probably optimistic. Have a few people
   write thirty or so questions each, in their own words and languages,
   save them as `backend/scripts/data/team_test.csv` (columns `text,label`),
   and run `python scripts/evaluate_muril.py --intent-test team_test.csv`. The Hindi, Telugu and Kannada
   training rows (marked `needs-review`) need a native speaker too.

### Accounts, notifications and migrations

- **Accounts are optional.** Open the person icon in the top bar to create
  one. Without it, history and reminders are private to that browser.
  Conversations saved before accounts existed have no owner and are not
  shown in the app; they are still in the database.
- **Reminder notifications.** Open the reminders panel and choose "Turn on
  notifications". The signing key is created on first run as
  `backend/vapid_keys.json` (git-ignored; treat it as a secret).
- **Database changes.** After editing `backend/app/models.py`, run
  `alembic revision --autogenerate -m "what changed"` in `backend/`. The
  app applies pending migrations on startup, and a test fails if the
  models and the migrations disagree.

## Architecture principles

- **Separation of concerns** — frontend and backend are fully independent
  services communicating over a documented REST API; the backend's NLU
  pipeline (`app/services/nlu_pipeline.py`) is a single, explicit
  orchestration point, so the flow (language → intent → entities) is easy
  to trace and extend.
- **Pluggable ML** — every model integration has a real, working
  implementation in `app/services/` (not a placeholder) that activates
  automatically once its package is installed; IndicNER and IndicTrans2
  use off-the-shelf checkpoints, while the two MuRIL-based models (intent,
  language-ID) ship with fine-tuning scripts + starter datasets under
  `backend/scripts/` since they need a quick fine-tune first. Upgrading
  never touches routers, schemas, or the frontend.
- **Domain-extensible response layer** — `app/services/response_generator.py`
  is where intents map to actions. New verticals (healthcare, agriculture,
  education, banking, government services) are added here as new intents +
  response branches, without touching speech, language, or entity logic.

## Roadmap beyond Phase 1

- Expand language coverage to more Indic languages (Hindi, Telugu, Kannada,
  Malayalam, Bengali, etc.) using the same MuRIL/IndicTrans2 pipeline.
- Replace the generated MuRIL training questions with real logged ones,
  and check the models against questions written by people who did not
  write the training bank. The pipeline, the guards and a first pair of
  checkpoints exist (`backend/README.md`, "MuRIL: what was trained and
  how it scored"); independent data is the main lever now.
- Domain modules: healthcare (symptom triage, appointment booking),
  agriculture (crop advisory, mandi prices), education (tutoring, exam
  prep), banking (balance/transaction queries), government services (scheme
  eligibility, form assistance).
