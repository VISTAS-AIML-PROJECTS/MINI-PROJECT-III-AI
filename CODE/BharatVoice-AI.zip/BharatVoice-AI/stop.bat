@echo off
echo ========================================================
echo   Stopping BharatVoice AI Services
echo ========================================================

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000 ^| findstr LISTENING') do (
    echo Stopping Backend PID %%a...
    taskkill /f /pid %%a 2>nul
)

for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5173 ^| findstr LISTENING') do (
    echo Stopping Frontend PID %%a...
    taskkill /f /pid %%a 2>nul
)

echo.
echo All BharatVoice services have been stopped.
