# BharatVoice AI — Backend

FastAPI service providing language identification, intent detection,
entity extraction, citizen skills, live weather, translation, speech
endpoints, reminders and chat history for the BharatVoice AI assistant.

Languages: Tamil, Hindi, Telugu, Kannada and English, plus code-mixed
variants. See the root README for what is verified versus pending review.

## Quick start

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

The API will be live at `http://localhost:8000`, with interactive docs at
`http://localhost:8000/docs`. A `bharatvoice.db` SQLite file is created
automatically on first run — no separate database setup needed.

## How it runs without GPUs or large model downloads

Every ML-heavy service (`app/services/*.py`) is written as a **layered
fallback**: it tries a real model first, and if the optional package isn't
installed, it transparently falls back to a lightweight rule-based /
heuristic implementation so the whole app is usable immediately:

| Capability          | Production model (optional)      | Built-in fallback                          |
|----------------------|-----------------------------------|---------------------------------------------|
| Speech-to-text       | OpenAI Whisper                    | Browser Web Speech API (frontend-side)      |
| Language detection    | MuRIL (fine-tuned)               | Unicode-script heuristic + `langdetect`     |
| Intent detection      | MuRIL (fine-tuned)               | Regex/keyword classifier                    |
| Entity extraction     | AI4Bharat IndicNER                | Regex + curated Indian-places gazetteer     |
| Translation            | AI4Bharat IndicTrans2             | Curated Tamil↔English phrase dictionary     |
| Text-to-speech         | Coqui TTS (XTTS-v2)               | Browser SpeechSynthesis API (frontend-side) |

All five production integrations are **fully implemented**, not just
stubbed — `app/services/*.py` contains real inference code for each. What
still varies is how much is needed to actually turn one on:

- **Whisper, IndicNER, IndicTrans2, Coqui TTS** — off-the-shelf checkpoints.
  Install the package (below), and the first request downloads the
  weights and just works. No training required.
- **MuRIL (intent + language-ID)** — these two tasks have no public
  checkpoint fine-tuned on *our* label set, so MuRIL itself (a base
  encoder) needs a short fine-tune first. Two scripts under `scripts/`
  handle this — see below.

## Upgrading to full ML models

1. Uncomment the ML section in `requirements.txt` and `pip install` it
   (requires internet access and, ideally, a GPU for Whisper/Coqui TTS/
   IndicTrans2).
2. That's it for Whisper / IndicNER / IndicTrans2 / Coqui — each service
   auto-detects the installed package at import time and switches from
   fallback to real inference immediately, no code or config changes.
3. For MuRIL intent detection and language-ID, install the training
   stack (`pip install torch transformers datasets scikit-learn pandas
   accelerate`, about 1.5 GB) and run, from `backend/`:
   ```bash
   python scripts/build_training_data.py   # only after editing the template bank
   python scripts/train_muril_intent.py --epochs 3 --max-length 32 --freeze-layers 6 --learning-rate 5e-5
   python scripts/train_muril_langid.py --epochs 4 --max-length 32 --freeze-layers 6 --learning-rate 5e-5
   python scripts/evaluate_muril.py        # compare with the rules before trusting it
   ```
   The flags are for training on a laptop CPU (about 25 minutes per
   model); with a GPU, drop `--freeze-layers` and `--max-length`. Each
   run fine-tunes `google/muril-base-cased`, calibrates its confidence,
   and saves to `app/services/models/muril_intent/` or `muril_langid/`
   (git-ignored, about 900 MB each). The services pick a checkpoint up on
   the next backend restart; `ENABLE_MURIL=false` switches both off.

   See **MuRIL: what was trained and how it scored** below before relying
   on it.
4. `app/config.py` centralizes every model name/path/device choice
   (`whisper_model_size`, `indictrans2_en_indic_model`,
   `muril_intent_model_path`, `ml_device`, etc.) if you want to point at
   different checkpoints or force CPU-only inference.
5. No router or schema changes are needed anywhere in this process — the
   fallback/production split lives entirely inside `app/services/`.

## MuRIL: what was trained and how it scored

**The data.** `scripts/build_training_data.py` generates the training sets
from a bank of sentence patterns filled with places, crops, tasks and
times: 6,458 intent rows (about 300 for each of the 19 intents, 926 for
"everything else") and 3,712 language rows, across English, Tamil, Hindi,
Telugu and Kannada in native script and romanized/code-mixed form. The
60 + 45 original hand-written rows are kept as `intent_seed.csv` and
`langid_seed.csv` and are included.

**The test sets** were written by hand, separately, and a test in
`tests/test_training_data.py` fails if any test sentence also appears in
the training data:

| File | Rows | What it checks |
| --- | --- | --- |
| `intent_test_data.csv` | 190 | ten unseen questions per intent |
| `langid_test_data.csv` | 92 | everyday sentences, about ten per language |
| `intent_outofscope_test.csv` | 50 | questions the app has no skill for |
| `intent_outofscope_fresh_test.csv` | 40 | the same, written after the bank was final |

**Results** (`python scripts/evaluate_muril.py`, checkpoints trained
2026-10-09 on a CPU with the flags above):

| | Rules only | App with MuRIL |
| --- | --- | --- |
| Intent, 190 unseen questions | 127 (67%) | 170 (89%) |
| Out-of-scope questions correctly left alone, of 90 | 88 | 87 |
| Language, 92 unseen sentences | 55 (60%) | 87 (95%) |

The models on their own score higher (intent 96%, language 99%). The app
scores lower than the model because of the guards below, on purpose.

**How the model is allowed to affect the app.** Each rule exists because
of a specific wrong answer seen during this work:

- *Rules first* (`MURIL_INTENT_MODE=fallback`, the default). The intent
  model is asked only when the rules find nothing, so it can add coverage
  ("should I carry an umbrella in Mangaluru today") but can never override
  a rule that matched. Emergencies never reach it at all.
- *Calibrated confidence* (`app/services/calibration.py`). A freshly
  trained model picked the right intent 181 times in 190 and was under
  0.75 sure every time, so the floor discarded all of it. Temperature
  scaling on validation rows fixes the scores without changing answers.
- *The handler must be able to act.* A model answer is dropped if the
  skill could do nothing with it: a price question with no crop, a sum
  that does not parse, a reminder with no time. The first checkpoint
  answered "sugar level 180, is it normal" with crop prices and saved a
  reminder for "is it good to drink milk at night".
- *Language: English is protected.* The language model is not asked about
  text shorter than three words or text `langdetect` is confident is
  English, and needs 0.95 confidence. Mistaking English for Kannada is far
  worse than the reverse: it replies in a script the user cannot read.

**What these numbers do not show — read before quoting them.**

- The training bank and all four test sets have the same author. The test
  sentences are not copies of training rows, but they share that author's
  habits of phrasing, so real-world accuracy is probably lower than 89%
  and 95%. The out-of-scope file marked "used while developing" also
  shaped the training bank and is not an independent check.
- The test sets are small. A difference of three or four rows is noise.
- Nothing here has been checked against real users. The local database
  held 34 distinct stored questions, mostly demo and test phrases; on
  those the models changed one answer, wrongly ("tell me in tamil" was
  taken as a translation request). **The honest next check is a few dozen
  questions written by people who did not write the bank**: save them as
  `scripts/data/team_test.csv` (columns `text,label`) and run
  `python scripts/evaluate_muril.py --intent-test team_test.csv`. Any file
  named `*_test.csv` there is automatically kept out of the training data.
- Hindi, Telugu and Kannada rows were written without a native speaker and
  are marked `needs-review` in the CSVs' `review` column.
- Known remaining mistakes: romanized Tamil is occasionally taken for
  romanized Telugu; paraphrased questions about the app itself and
  romanized reminders whose time the parser cannot read still get the
  general reply; and the calculator cannot parse a sum wrapped in Hindi or
  Tamil words even when the model recognises it as one.

**Improving it.** Real logged questions are better training data than
generated ones. To add data, edit the template bank in
`scripts/build_training_data.py`, rebuild, retrain, and rerun
`evaluate_muril.py`. The first thing to add is short keyword-style English
("tomato mandi price") and English with Indian loanwords to the `en`
class, which is what the language guards currently compensate for.

### A note on Tamil TTS

XTTS-v2 (Coqui's default multilingual checkpoint) does not currently ship
a Tamil voice. `text_to_speech.py` accounts for this: Tamil replies still
route to the browser's `SpeechSynthesis` API (which does have Tamil voices
on most platforms) even when Coqui is installed, while English/code-mixed
replies use the real Coqui voice. Swap in a dedicated Tamil TTS checkpoint
(e.g. an AI4Bharat or community Tamil VITS/FastPitch model) and add a
branch in `synthesize_speech()` to get real Tamil audio server-side.

## Project structure

```
backend/
├── app/
│   ├── main.py              # FastAPI app, CORS, router registration
│   ├── config.py            # Settings (env-driven)
│   ├── database.py          # SQLAlchemy engine/session
│   ├── models.py            # Conversation, Message, Reminder ORM models
│   ├── schemas.py           # Pydantic request/response models
│   ├── routers/
│   │   ├── chat.py          # POST /api/chat — the core conversation loop
│   │   ├── reminders.py     # /api/reminders — list, complete, delete
│   │   ├── speech.py        # /api/speech/transcribe, /synthesize
│   │   ├── language.py      # /api/language/detect
│   │   ├── intent.py        # /api/intent/detect
│   │   ├── translate.py     # /api/translate
│   │   └── history.py       # /api/history/conversations
│   └── services/
│       ├── answers.py            # DomainAnswer + Source: the citation contract
│       ├── skills.py             # Calculator, units, helplines, gov documents
│       ├── weather.py            # Live weather (Open-Meteo), cached + timestamped
│       ├── nlu_pipeline.py       # Orchestrates language→intent→entities
│       ├── language_detection.py
│       ├── intent_detection.py
│       ├── entity_extraction.py
│       ├── translation.py
│       ├── speech_to_text.py
│       ├── text_to_speech.py
│       ├── response_generator.py # Intent → action → natural-language reply
│       └── device.py             # Shared CPU/CUDA device resolution for ML services
├── scripts/
│   ├── build_training_data.py    # Generates the training CSVs from a template bank
│   ├── train_text_classifier.py  # Generic MuRIL fine-tuning loop (+ calibration)
│   ├── train_muril_intent.py     # Thin wrapper: fine-tune the intent classifier
│   ├── train_muril_langid.py     # Thin wrapper: fine-tune the language-ID classifier
│   ├── calibrate_muril.py        # Calibrate an existing checkpoint without retraining
│   ├── evaluate_muril.py         # Score checkpoints against the rules
│   └── data/                     # Training CSVs, seed rows and hand-written test sets
├── tests/
│   └── test_core.py              # 100 tests; network-free
├── pytest.ini
├── ruff.toml
├── requirements.txt              # light, CPU-only
└── requirements-dev.txt          # pytest, httpx, ruff
```

## Tests

```bash
pip install -r requirements.txt -r requirements-dev.txt
pytest        # 100 passed
ruff check app tests
```

The suite is network-free — the weather service is stubbed via monkeypatch,
so it passes offline and in CI.

## API overview

- `POST /api/chat` — main endpoint. Send `{ text, conversation_id? }`, get
  back the assistant's reply plus the full NLU trace (language, intent,
  entities) and an optional audio URL.
- `POST /api/speech/transcribe` — upload audio for server-side Whisper
  transcription (501 if Whisper isn't installed — frontend already has a
  working fallback).
- `POST /api/speech/synthesize` — generate speech audio for text.
- `POST /api/language/detect`, `POST /api/intent/detect`, `POST /api/translate`
  — standalone versions of the pipeline steps, useful for testing/demoing
  each capability independently.
- `GET /api/history/conversations`, `GET /api/history/conversations/{id}`,
  `DELETE /api/history/conversations/{id}` — chat history.
- `GET /api/reminders`, `PATCH /api/reminders/{id}/done`,
  `DELETE /api/reminders/{id}` — saved reminders.
- `GET /api/health` — liveness probe, used by the Docker healthcheck.

Every `/api/chat` reply carries `sources` (provenance, possibly empty),
`is_refusal` (the assistant declined rather than guessed) and `staleness`
(freshness note for live data).

## Extending to new domains (healthcare, agriculture, education, banking, government)

Add new intents to `app/services/intent_detection.py`'s pattern list (or
retrain the MuRIL classifier), then add a matching branch in
`app/services/response_generator.py` that calls out to the relevant
domain API/database. The STT → language detection → intent → entities →
TTS pipeline stays untouched — new domains are purely additive at the
response-generation layer.
