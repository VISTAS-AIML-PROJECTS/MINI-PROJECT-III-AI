"""
Pydantic request/response schemas for the BharatVoice AI API.
"""
from datetime import date, datetime
from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from app.config import settings

# ---------------------------------------------------------------------------
# Shared / NLU building blocks
# ---------------------------------------------------------------------------

class Entity(BaseModel):
    type: str  # PERSON | PLACE | DATE | TIME | ORG | MISC
    value: str


class SourceOut(BaseModel):
    """Where a fact-bearing answer came from, and when it was last checked."""

    title: str
    url: Optional[str] = None
    checked_on: Optional[date] = None


class NluResult(BaseModel):
    language: str
    language_confidence: float
    intent: str
    intent_confidence: float
    entities: List[Entity]


# ---------------------------------------------------------------------------
# Chat
# ---------------------------------------------------------------------------

class ChatRequest(BaseModel):
    # Bounded because /api/chat is unauthenticated: an unbounded string is
    # both a memory risk and, via the arithmetic parser, a CPU one.
    text: str = Field(..., min_length=1, max_length=settings.max_input_chars)
    conversation_id: Optional[str] = None
    # If the client already knows the language (e.g. selected manually),
    # it can be passed to skip auto-detection.
    language_hint: Optional[str] = None


class ChatResponse(BaseModel):
    conversation_id: str
    message_id: str
    reply_text: str
    reply_language: str
    nlu: NluResult
    audio_url: Optional[str] = None
    # Provenance for the reply. Empty for chit-chat and local computation;
    # populated for anything the assistant asserts about the world.
    sources: List[SourceOut] = []
    # True when the assistant declined rather than guessed. Tracked
    # separately because a correct refusal is a success, not a failure.
    is_refusal: bool = False
    # Human-readable freshness note for live data, e.g.
    # "as of 26 September 2026, 04:15 PM IST". None for timeless answers.
    staleness: Optional[str] = None
    # Helpline numbers in `reply_text` the UI may render as tel: links.
    dialable: List[str] = []


# ---------------------------------------------------------------------------
# Speech
# ---------------------------------------------------------------------------

class SpeechToTextResponse(BaseModel):
    text: str
    language: str
    confidence: float
    engine: str  # "whisper" | "fallback"


class TextToSpeechRequest(BaseModel):
    # Bounded for the same reason as ChatRequest.text: this endpoint is
    # open, and every call can write an audio file to disk.
    text: str = Field(..., min_length=1, max_length=settings.max_input_chars)
    language: str = "en"


# ---------------------------------------------------------------------------
# Language / Intent / Translation (standalone endpoints)
# ---------------------------------------------------------------------------

class LanguageDetectRequest(BaseModel):
    text: str


class LanguageDetectResponse(BaseModel):
    language: str
    confidence: float
    engine: str


class IntentDetectRequest(BaseModel):
    text: str
    language: Optional[str] = "en"


class IntentDetectResponse(BaseModel):
    intent: str
    confidence: float
    entities: List[Entity]
    engine: str


class TranslateRequest(BaseModel):
    text: str
    source_lang: str
    target_lang: str


class TranslateResponse(BaseModel):
    translated_text: str
    source_lang: str
    target_lang: str
    engine: str


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------

class MessageOut(BaseModel):
    id: str
    role: str
    text: str
    language: Optional[str] = None
    intent: Optional[str] = None
    entities: Optional[Any] = None
    translated_text: Optional[str] = None
    sources: Optional[Any] = None
    dialable: Optional[Any] = None
    audio_url: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ConversationOut(BaseModel):
    id: str
    title: str
    created_at: datetime
    messages: List[MessageOut] = []

    model_config = ConfigDict(from_attributes=True)


class ConversationSummary(BaseModel):
    id: str
    title: str
    created_at: datetime
    message_count: int


# ---------------------------------------------------------------------------
# Reminders
# ---------------------------------------------------------------------------

class ReminderOut(BaseModel):
    id: str
    text: str
    when_label: Optional[str] = None
    due_at: Optional[datetime] = None
    notified_at: Optional[datetime] = None
    person: Optional[str] = None
    language: Optional[str] = None
    is_done: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------------------
# Accounts
# ---------------------------------------------------------------------------

class Credentials(BaseModel):
    username: str = Field(..., min_length=3, max_length=32)
    password: str = Field(..., min_length=8, max_length=128)


class UserOut(BaseModel):
    id: str
    username: str

    model_config = ConfigDict(from_attributes=True)


class AuthResponse(BaseModel):
    token: str
    user: UserOut


# ---------------------------------------------------------------------------
# Push notifications
# ---------------------------------------------------------------------------

class PushKeys(BaseModel):
    p256dh: str = Field(..., min_length=1, max_length=256)
    auth: str = Field(..., min_length=1, max_length=256)


class PushSubscriptionIn(BaseModel):
    """The shape `PushSubscription.toJSON()` produces in the browser."""

    endpoint: str = Field(..., min_length=1, max_length=2048)
    keys: PushKeys


class PushUnsubscribeIn(BaseModel):
    endpoint: str = Field(..., min_length=1, max_length=2048)
