"""
BharatVoice AI - Backend Entrypoint
=====================================
Run with:
    uvicorn app.main:app --reload --port 8000

Interactive API docs available at http://localhost:8000/docs
"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import SessionLocal, init_db
from app.routers import auth, chat, history, intent, language, push, reminders, speech, translate
from app.services.push import ReminderPusher


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """
    Startup/shutdown hook. Replaces `@app.on_event("startup")`, which is
    deprecated in FastAPI 0.115.
    """
    init_db()
    # Sends due reminders as system notifications, so they arrive with the
    # tab closed. Stopped on shutdown so a reload does not leave two loops.
    pusher = ReminderPusher(SessionLocal, settings.reminder_push_interval_seconds)
    pusher.start()
    try:
        yield
    finally:
        pusher.stop()


app = FastAPI(
    title=settings.app_name,
    description="A Multilingual Intelligent Assistant for Indian Languages",
    version="1.1.0",
    debug=settings.debug,
    lifespan=lifespan,
)

# --- CORS: allow the React dev server to talk to this API ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Static files (server-generated TTS audio, when Coqui is enabled) ---
static_dir = Path(__file__).resolve().parent.parent / "static"
static_dir.mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

# --- Routers ---
app.include_router(auth.router, prefix=settings.api_prefix)
app.include_router(chat.router, prefix=settings.api_prefix)
app.include_router(speech.router, prefix=settings.api_prefix)
app.include_router(language.router, prefix=settings.api_prefix)
app.include_router(intent.router, prefix=settings.api_prefix)
app.include_router(translate.router, prefix=settings.api_prefix)
app.include_router(history.router, prefix=settings.api_prefix)
app.include_router(reminders.router, prefix=settings.api_prefix)
app.include_router(push.router, prefix=settings.api_prefix)


@app.get("/")
def root():
    return {
        "app": settings.app_name,
        "status": "running",
        "docs": "/docs",
        "languages": settings.supported_languages,
    }


@app.get("/api/health")
def health_check():
    return {"status": "ok"}
