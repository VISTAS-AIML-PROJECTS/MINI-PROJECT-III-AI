"""
SQLAlchemy ORM models for BharatVoice AI.

Phase 1 keeps the schema intentionally small: conversations group messages,
and each message stores the full NLU trace (language, intent, entities) so
the chat history view can display rich metadata and later phases (analytics,
personalization) can mine this data.
"""
import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Column, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import relationship

from app.database import Base


def gen_uuid() -> str:
    return str(uuid.uuid4())


def utcnow() -> datetime:
    """
    Current UTC time as a naive datetime.

    `datetime.utcnow()` is deprecated from Python 3.12, and SQLite has no
    timezone-aware storage, so the convention here is: always UTC, always
    naive in the database, converted on the way out (see schemas.py). The
    tzinfo is stripped deliberately rather than by accident.
    """
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(String, primary_key=True, default=gen_uuid)
    # "user:<id>", "guest:<id>" or NULL — see services/auth.py.
    owner_id = Column(String, nullable=True, index=True)
    title = Column(String, default="New Conversation")
    created_at = Column(DateTime, default=utcnow)

    messages = relationship(
        "Message", back_populates="conversation", cascade="all, delete-orphan"
    )


class Message(Base):
    __tablename__ = "messages"

    id = Column(String, primary_key=True, default=gen_uuid)
    conversation_id = Column(String, ForeignKey("conversations.id"))

    role = Column(String)  # "user" | "assistant"
    text = Column(Text)  # transcribed / typed text (user) or reply (assistant)

    language = Column(String, nullable=True)  # detected language code e.g. "ta", "en"
    intent = Column(String, nullable=True)  # e.g. "get_weather", "set_reminder"
    entities = Column(JSON, nullable=True)  # list[{type, value}]
    translated_text = Column(Text, nullable=True)  # English pivot translation, if any

    # Provenance for fact-bearing replies: list[{title, url, checked_on}].
    # Empty for chit-chat and local computation. Stored so an answer can be
    # audited after the fact — "where did the assistant get this?" is the
    # first question anyone asks about a wrong government or health reply.
    sources = Column(JSON, nullable=True)

    # Helpline numbers in `text` that may be shown as tap-to-call links,
    # stored so a reply reopened from history is as tappable as it was live.
    dialable = Column(JSON, nullable=True)

    audio_url = Column(String, nullable=True)  # path to generated/uploaded audio, if any
    created_at = Column(DateTime, default=utcnow)

    conversation = relationship("Conversation", back_populates="messages")


class Reminder(Base):
    """A user-created reminder, saved from a `set_reminder` chat intent so
    it survives beyond a single conversation and can be listed back on
    request (see `list_reminders` in the NLU pipeline)."""

    __tablename__ = "reminders"

    id = Column(String, primary_key=True, default=gen_uuid)
    owner_id = Column(String, nullable=True, index=True)  # see services/auth.py
    text = Column(Text)  # the original request text, for context
    when_label = Column(String, nullable=True)  # human-readable date/time, e.g. "tomorrow 5pm"
    # The actual fire time, UTC-naive (see `utcnow`). `when_label` is for
    # display; this is what the system compares against the clock. Nullable
    # because a request whose time we couldn't parse is still worth saving —
    # the user gets told we didn't understand the timing, and the reminder
    # is listed but never fires.
    due_at = Column(DateTime, nullable=True)
    notified_at = Column(DateTime, nullable=True)  # set once surfaced to the user
    person = Column(String, nullable=True)  # who the reminder is about, if extracted
    language = Column(String, nullable=True)
    is_done = Column(String, default="pending")  # "pending" | "done" — simple string flag, no migrations needed
    created_at = Column(DateTime, default=utcnow)


class User(Base):
    """An account. Optional: the app works for guests too (services/auth.py)."""

    __tablename__ = "users"

    id = Column(String, primary_key=True, default=gen_uuid)
    username = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=utcnow)


class AuthSession(Base):
    """A sign-in. Keyed by the SHA-256 of the bearer token, never the token."""

    __tablename__ = "auth_sessions"

    token_hash = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime, nullable=False)


class PushSubscription(Base):
    """One browser that asked for reminder notifications (services/push.py)."""

    __tablename__ = "push_subscriptions"

    id = Column(String, primary_key=True, default=gen_uuid)
    owner_id = Column(String, nullable=True, index=True)
    # The push service URL for this browser. Unique: one row per browser.
    endpoint = Column(String, nullable=False, unique=True, index=True)
    p256dh = Column(String, nullable=False)
    auth = Column(String, nullable=False)
    created_at = Column(DateTime, default=utcnow)


# Every model with an `owner_id`, so signing in can move a guest's rows to
# the account in one loop (auth.claim_guest_rows).
OWNED_MODELS = [Conversation, Reminder, PushSubscription]
