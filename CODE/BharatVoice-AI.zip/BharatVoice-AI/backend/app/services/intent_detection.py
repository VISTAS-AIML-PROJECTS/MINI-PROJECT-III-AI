"""
Intent Detection Service
==========================
Classifies user text into an actionable intent.

Fallback implementation: keyword/pattern-based classifier covering the
Phase 1 intent set below. This is fast, explainable, and needs no GPU —
ideal for a foundation that later gets replaced by a fine-tuned MuRIL/
IndicBERT sequence-classification head (see `_transformer_intent`).

Phase 1 intents:
  - greeting            "vanakkam", "hi", "hello"
  - thanks              "thanks", "nandri"
  - how_are_you         "how are you", "epdi irukeenga"
  - capabilities        "what can you do", "help topics"
  - get_weather         "chennai la weather epdi irukku"
  - get_time            "what time is it"
  - get_date            "what's the date today"
  - set_reminder        "remind me to call amma at 5pm"
  - list_reminders       "show my reminders"
  - calculate           "what is 45 plus 67", "20 percent of 500"
  - convert_unit         "convert 5 km to miles"
  - emergency_help       "police number", "ambulance", "emergency"
  - gov_document_help    "how to apply for aadhaar", "pan card"
  - mandi_price          "tomato mandi price", "प्याज मंडी भाव"
  - about_app           questions about BharatVoice itself: what it is,
                         which languages, how it detects them, whether it
                         works offline, what it does with your data, where
                         its information comes from. Probed from
                         `about.match_about` and resolved BEFORE the
                         keyword patterns — see `_rule_based_intent`.
  - knowledge_help       curated FAQ: scholarships, bank accounts, scams,
                         trains/buses, schemes, jobs, hospitals. Matched by
                         probing `knowledge.match_faq` rather than by its own
                         keyword list, so the entry and the routing cannot
                         drift apart.
  - translate_request    "how do you say water in tamil"
  - general_query        fallback / small talk / open-domain question
"""
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

from app.config import settings
from app.services import about, knowledge, mandi, skills, timeparse
from app.services.calibration import load_temperature, top_label
from app.services.device import resolve_device

try:
    from transformers import pipeline
    _HAS_TRANSFORMERS = True
except ImportError:
    _HAS_TRANSFORMERS = False

_intent_pipeline = None  # lazy-loaded singleton
_intent_temperature = 1.0  # set when the checkpoint loads; see calibration.py
_CHECKPOINT_DIR = Path(settings.muril_intent_model_path)

logger = logging.getLogger(__name__)


def _muril_enabled() -> bool:
    """
    True when a real MuRIL classifier should be attempted: the library is
    importable *and* the operator hasn't force-disabled it via
    `ENABLE_MURIL=false`. The config flag exists so a bad checkpoint can be
    switched off without uninstalling `transformers`.
    """
    return _HAS_TRANSFORMERS and settings.enable_muril


@dataclass
class IntentResult:
    intent: str
    confidence: float
    engine: str


# Ordered list of (intent, [regex patterns]). First match wins.
# Patterns are grouped English / Tamil / Hindi / Telugu / Kannada per
# intent. Romanized forms matter as much as native script — a large share
# of typed input from these speakers is Latin-script ("vanakkam",
# "namaskara", "reminder vaikka").
_INTENT_PATTERNS: List[Tuple[str, List[str]]] = [
    ("emergency_help", [
        r"\bemergency\b", r"\bpolice (number|helpline)\b", r"\bambulance\b",
        r"\bfire brigade\b", r"\burgent help\b", r"\bhelpline\b",
        r"\bஅவசர\b", r"\bகாவல்\s*(எண்|நம்பர்)\b", r"\bஆம்புலன்ஸ்\b",
        r"\bआपातकाल\b", r"\bएम्बुलेंस\b", r"\bपुलिस नंबर\b",
        r"\bఅత్యవసర\b", r"\bఅంబులెన్స్\b",
        r"\bತುರ್ತು\b", r"\bಆಂಬ್ಯುಲೆನ್ಸ್\b",
    ]),
    ("greeting", [
        r"\b(hi|hello|hey|vanakkam|namaste|namaskar|namaskaram|namaskara)\b",
        r"\bவணக்கம்\b", r"\bनमस्ते\b", r"\bनमस्कार\b", r"\bనమస్కారం\b", r"\bನಮಸ್ಕಾರ\b",
    ]),
    ("goodbye", [
        r"\b(bye|goodbye|see you)\b", r"\bபோய் வர்றேன்\b", r"\bபை\b",
        r"\bअलविदा\b", r"\bफिर मिलेंगे\b", r"\bవీడ್కోలు\b", r"\bವಿದಾಯ\b",
    ]),
    ("thanks", [
        r"\b(thanks|thank you|nandri|dhanyavad|shukriya|dhanyavadalu|dhanyavada)\b",
        r"\bநன்றி\b", r"\bधन्यवाद\b", r"\bशुक्रिया\b", r"\bధన్యవాదాలు\b", r"\bಧನ್ಯವಾದ\b",
    ]),
    ("how_are_you", [
        r"\bhow are you\b", r"\bepdi irukeenga\b", r"\bkaise ha(i|in)\b",
        r"\bela unnaru\b", r"\bhegiddir[ae]\b",
        r"\bஎப்படி இருக்கீங்க\b", r"\bकैसे ह(ैं|ो)\b", r"\bఎలా ఉన్నారు\b", r"\bಹೇಗಿದ್ದೀರಿ\b",
    ]),
    ("capabilities", [
        r"\bwhat can you do\b", r"\byour capabilities\b", r"\bhelp topics\b",
        r"\bஉன்னால் என்ன செய்ய முடியும்\b", r"\bஎன்ன செய்ய முடியும்\b",
        r"\bक्या कर सकते ह(ो|ैं)\b", r"\bఏమి చేయగలరు\b", r"\bಏನು ಮಾಡಬಹುದು\b",
    ]),
    ("list_reminders", [
        r"\b(show|list) (my )?reminders?\b", r"\bmy reminders?\b",
        r"\bஎன் நினைவூட்டல்கள்\b", r"\bநினைவூட்டல்களை காட்டு\b",
        r"\bमेरे रिमाइंडर\b", r"\bरिमाइंडर दिखा\b",
        r"\bనా రిమైండర్\b", r"\bನನ್ನ ಜ್ಞಾಪನೆ\b",
    ]),
    ("set_reminder", [
        r"\bremind(er)?\b", r"\balarm\b",
        r"\bநினைவூட்டு\b", r"\bஎச்சரிக்கை\b",
        r"\bयाद दिला\b", r"\bरिमाइंडर\b",
        r"\bగుర్తు చేయ\b", r"\bరిమైండర్\b",
        r"\bನೆನಪಿಸ\b", r"\bಜ್ಞಾಪನೆ\b",
    ]),
    ("get_weather", [
        r"\bweather\b", r"\btemperature\b", r"\brain(ing)?\b", r"\bforecast\b",
        r"\bவானிலை\b", r"\bமழை\b",
        r"\bमौसम\b", r"\bबारिश\b",
        r"\bవాతావరణ\b", r"\bవర్ష\b",
        r"\bಹವಾಮಾನ\b", r"\bಮಳೆ\b",
    ]),
    ("get_time", [
        r"\bwhat('s| is) the time\b", r"\bwhat time (is it|it is)\b", r"\bcurrent time\b",
        r"\bமணி என்ன\b", r"\bநேரம் என்ன\b",
        r"\bसमय क्या\b", r"\bकितने बजे\b",
        r"\bసమయం ఎంత\b", r"\bಸಮಯ ಎಷ್ಟು\b",
    ]),
    ("get_date", [
        r"\bwhat('s| is) (the |today'?s )?date\b", r"\bwhat day is it\b",
        r"\bஇன்று என்ன தேதி\b", r"\bதேதி என்ன\b",
        r"\bआज क्या तारीख\b", r"\bतारीख क्या\b",
        r"\bఈరోజు తేదీ\b", r"\bಇಂದಿನ ದಿನಾಂಕ\b",
    ]),
    ("gov_document_help", [
        r"\baadhaar\b", r"\baadhar\b", r"\bpan card\b", r"\bvoter id\b", r"\bvoter card\b",
        r"\bration card\b", r"\bpassport\b", r"\bdriving licen[sc]e\b",
        r"\bஆதார்\b", r"\bரேஷன் கார்டு\b", r"\bபாஸ்போர்ட்\b",
        r"\bआधार\b", r"\bराशन कार्ड\b", r"\bपासपोर्ट\b", r"\bवोटर आईडी\b",
        r"\bఆధార్\b", r"\bరేషన్ కార్డు\b", r"\bపాస్‌పోర్ట్\b",
        r"\bಆಧಾರ್\b", r"\bಪಡಿತರ ಚೀಟಿ\b", r"\bಪಾಸ್‌ಪೋರ್ಟ್\b",
    ]),
    ("mandi_price", [
        r"\bmandi\b", r"\bmarket (price|rate)\b", r"\bmarket-price\b",
        r"\bசந்தை விலை\b", r"\bமண்டி\b",
        r"\bमंडी\b", r"\bबाज़ार भाव\b", r"\bबाजार भाव\b", r"\bमंडी भाव\b",
        r"\bమార్కెట్ ధర\b", r"\bమార్కెట్ రేటు\b",
        r"\bಮಾರುಕಟ್ಟೆ ದರ\b", r"\bಮಾರುಕಟ್ಟೆ ಬೆಲೆ\b",
    ]),
    ("translate_request", [
        r"\btranslate\b", r"\bhow (do|to) (you )?say\b", r"\bmeaning of\b",
        r"\bமொழிபெயர்\b", r"\bஎன்று சொல்வது\b",
        r"\bअनुवाद\b", r"\bकैसे कहते\b",
        r"\bఅనువాద\b", r"\bఎలా చెప్పాలి\b",
        r"\bಅನುವಾದ\b", r"\bಹೇಗೆ ಹೇಳ\b",
    ]),
]


# The full intent vocabulary the response layer can act on. A fine-tuned
# checkpoint that cannot produce all of these will silently lose the
# missing skills, so `_transformer_intent` checks its label set against
# this tuple on load and warns.
INTENTS = tuple(intent for intent, _ in _INTENT_PATTERNS) + (
    "calculate",
    "convert_unit",
    "about_app",
    "knowledge_help",
    "general_query",
)

# Intents where a miss is materially harmful. These are resolved by rule
# before any model runs: a person asking for an ambulance must not depend
# on a classifier's softmax.
_SAFETY_INTENTS = ("emergency_help",)


def compile_pattern(pattern: str) -> "re.Pattern":
    """
    Compile an intent pattern, dropping `\\b` from non-ASCII ones.

    Python's `\\b` is defined in terms of `\\w`, which covers Unicode letters
    but NOT combining marks — and Indic scripts end words in them
    constantly (virama, vowel signs). So `r"\\bவணக்கம்\\b"` never matches
    "வணக்கம்": the string ends in U+0BCD (a combining mark, not a word
    character), and the position after a non-word character at end-of-string
    is not a word boundary.

    Latin patterns keep `\\b`, where it does real work — it is what stops the
    "dl" alias matching inside "handle". Indic patterns don't need it: these
    scripts are not prone to the same short-substring collisions.
    """
    if not pattern.isascii():
        pattern = pattern.replace(r"\b", "")
    return re.compile(pattern)


# Precompiled at import: one pass instead of recompiling on every request.
_COMPILED_PATTERNS: List[Tuple[str, List["re.Pattern"]]] = [
    (intent, [compile_pattern(p) for p in patterns]) for intent, patterns in _INTENT_PATTERNS
]


def _match_patterns(text: str, only: tuple = None):
    lowered = text.lower()
    for intent, patterns in _COMPILED_PATTERNS:
        if only is not None and intent not in only:
            continue
        for pattern in patterns:
            if pattern.search(lowered) or pattern.search(text):
                return intent
    return None


def _rule_based_intent(text: str) -> IntentResult:
    """Questions about the app, then keyword patterns, then parse-driven skills."""
    # The app's own FAQ is probed FIRST — ahead of the keyword patterns —
    # and that ordering is deliberate. "Where do you get weather
    # information from?" is a question about this program, but it contains
    # the word "weather", so letting `_match_patterns` go first would send
    # it to the live weather lookup and answer with a temperature.
    #
    # Running it first is only safe because its keywords are self-
    # referential multi-word phrases ("where do you get", "which
    # languages", "work offline") rather than single nouns. "What is the
    # weather in Madurai" does not contain any of them, which the tests
    # in tests/test_about.py pin down for every ordinary query shape.
    #
    # `emergency_help` still wins over this, because `detect_intent`
    # resolves safety intents before calling here at all. That is the
    # right way round: someone typing "emergency" gets the helpline list,
    # not an explanation of what the app can and cannot do.
    if about.match_about(text) is not None:
        return IntentResult(intent="about_app", confidence=0.85, engine="rule-based")

    # Keyword patterns run *before* the calculator and unit converter. The
    # parse-driven checks below are greedy by nature — they answer "can I
    # read an expression out of this?" — so letting them go first meant
    # "remind me on 3/4/2026 to renew my passport" was classified as
    # `calculate` and the reminder was silently dropped.
    matched = _match_patterns(text)
    if matched:
        return IntentResult(intent=matched, confidence=0.85, engine="rule-based")

    # Calculator and unit conversion are detected by "can we actually parse
    # this?" rather than keywords — far more reliable than trying to write
    # a regex for every phrasing of "45 plus 67" or "convert 5 km to miles".
    if skills.convert_units(text) is not None:
        return IntentResult(intent="convert_unit", confidence=0.9, engine="rule-based")
    if skills.safe_calculate(text) is not None:
        return IntentResult(intent="calculate", confidence=0.9, engine="rule-based")

    # The curated FAQ is probed last among the matchers but still ahead of
    # the general fallback: it covers education, banking, scam awareness,
    # travel, schemes, jobs and health facilities, where the alternative is
    # "I don't know" rather than a wrong answer from another skill. Running
    # it after the keyword patterns is what keeps "aadhaar" on
    # `gov_document_help`, which has its own curated text.
    if knowledge.match_faq(text) is not None:
        return IntentResult(intent="knowledge_help", confidence=0.8, engine="rule-based")

    return IntentResult(intent="general_query", confidence=0.55, engine="rule-based-fallback")


def detect_intent(text: str, language: str = "en") -> IntentResult:
    """Main entry point used across the app."""
    # Safety-critical intents bypass the model entirely.
    safety_match = _match_patterns(text, only=_SAFETY_INTENTS)
    if safety_match:
        return IntentResult(intent=safety_match, confidence=0.95, engine="rule-based-safety")

    if not _muril_enabled():
        return _rule_based_intent(text)

    if settings.muril_intent_mode == "primary":
        return _model_intent(text, language) or _rule_based_intent(text)

    # "fallback": the rules answer whenever they recognise the request. The
    # model is consulted only for what they could not place, so it widens
    # what the assistant understands ("should I carry an umbrella in
    # Salem") without being able to break something that already worked.
    ruled = _rule_based_intent(text)
    if ruled.intent != "general_query":
        return ruled
    return _model_intent(text, language) or ruled


def _model_intent(text: str, language: str):
    """
    The model's answer if it should be trusted, else None.

    Three checks, each of which exists because a wrong answer here is worse
    than no answer:
      - a confidence floor: softmax over a partial label set is confidently
        wrong rather than uncertain;
      - the label must be one the response layer knows;
      - the response layer must be able to act on it. "calculate" for a
        sentence the calculator cannot parse produces "I couldn't work
        that out", which is worse than the general reply the rules give.
    """
    try:
        result = _transformer_intent(text, language)
    except NotImplementedError:
        return None  # no checkpoint yet
    except Exception:
        logger.warning("MuRIL intent inference failed; falling back", exc_info=True)
        return None

    if result.confidence < settings.intent_confidence_threshold:
        return None
    if result.intent not in INTENTS or not _actionable(result.intent, text):
        return None
    return result


def _actionable(intent: str, text: str) -> bool:
    """Whether the handler for `intent` can produce a real answer to `text`."""
    if intent == "calculate":
        return skills.safe_calculate(text) is not None
    if intent == "convert_unit":
        return skills.convert_units(text) is not None
    if intent == "about_app":
        return about.match_about(text) is not None
    if intent == "knowledge_help":
        return knowledge.match_faq(text) is not None
    if intent == "gov_document_help":
        return skills.match_gov_doc(text) is not None
    if intent == "set_reminder":
        # The one intent with a side effect: it writes a reminder. With no
        # reminder keyword and no time the app can parse, the result would
        # be a saved reminder that can never fire — for what may not have
        # been a reminder request at all ("is it good to drink milk at
        # night" was one, on the first checkpoint).
        return timeparse.parse_due_at(text) is not None
    if intent == "mandi_price":
        # Reached only when no mandi keyword matched, so the model is going
        # on the general shape of a price question. Without a crop it has
        # nothing to look up — and "what is the price of gold" or "sugar
        # level 180" is exactly what that shape also fits.
        return mandi.commodity_in_text(text) is not None
    return True


def _transformer_intent(text: str, language: str) -> IntentResult:  # pragma: no cover
    """
    Real MuRIL intent-classification inference.

    Unlike IndicNER/IndicTrans2, there's no public checkpoint already
    fine-tuned on *this* intent set (greeting/get_weather/set_reminder/
    translate_request/goodbye/general_query) — MuRIL is a base encoder
    that needs a short fine-tune on your own labeled examples first. Run
    `backend/scripts/train_muril_intent.py` against a CSV of (text, intent)
    pairs to produce that checkpoint at `settings.muril_intent_model_path`.

    Until that checkpoint exists on disk, this raises NotImplementedError
    so `detect_intent` cleanly falls back to the rule-based classifier —
    exactly the same graceful-degradation pattern used everywhere else.
    """
    if not (_CHECKPOINT_DIR / "config.json").exists():
        raise NotImplementedError(
            f"No fine-tuned MuRIL intent checkpoint found at '{_CHECKPOINT_DIR}'. "
            "Run backend/scripts/train_muril_intent.py to produce one."
        )

    global _intent_pipeline, _intent_temperature
    if _intent_pipeline is None:
        device = 0 if resolve_device() == "cuda" else -1
        _intent_pipeline = pipeline(
            "text-classification", model=str(_CHECKPOINT_DIR), device=device
        )
        _intent_temperature = load_temperature(_CHECKPOINT_DIR)
        _warn_on_missing_labels(_intent_pipeline)

    # Raw scores for every label, turned into a calibrated probability
    # here rather than by the pipeline's own softmax — see calibration.py
    # for why the uncalibrated number could not be compared to a floor.
    scores = _intent_pipeline(text, top_k=None, function_to_apply="none")
    label, confidence = top_label(scores, _intent_temperature)
    return IntentResult(intent=label, confidence=round(confidence, 2), engine="muril")


def _warn_on_missing_labels(text_classifier) -> None:  # pragma: no cover
    """
    Compare the checkpoint's label set against `INTENTS` and warn loudly
    about anything it cannot predict.

    This exists because the starter training CSV originally covered only 6
    of the 15 intents, so training a checkpoint and restarting the backend
    silently removed nine working skills — emergency helplines and
    government-document guidance among them. A checkpoint with partial
    coverage is still usable (the confidence threshold in `detect_intent`
    sends unsure cases back to the rules), but the operator needs to know.
    """
    try:
        trained = set((text_classifier.model.config.id2label or {}).values())
    except AttributeError:
        return
    missing = sorted(set(INTENTS) - trained)
    if missing:
        logger.warning(
            "MuRIL intent checkpoint at %s cannot predict %d of %d intents: %s. "
            "These fall back to the rule-based classifier. Add labelled rows for "
            "them to scripts/data/intent_training_data.csv and retrain.",
            _CHECKPOINT_DIR,
            len(missing),
            len(INTENTS),
            ", ".join(missing),
        )
