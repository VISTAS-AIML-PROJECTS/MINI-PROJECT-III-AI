"""
About BharatVoice — the app's own FAQ, and the language-support matrix
=======================================================================
Everything the assistant is allowed to say *about itself* lives here, in
one table, so a claim can be reviewed and corrected in one place instead
of being scattered through reply templates.

Why a separate module from `knowledge.py`
------------------------------------------
`knowledge.py` answers questions about the outside world and therefore
cites an external portal for every entry. These answers cite nothing
external, because the subject is this program. The two have different
rules about what a body may contain, so they get different modules and
different tests.

The honesty rules these bodies follow — enforced by `tests/test_about.py`:

  - No claim of superiority. This assistant is not described as more
    accurate, more private, faster, safer or better than any other
    assistant. Where a comparison is unavoidable (the "why not ChatGPT"
    question), it states what is *different* — narrow scope, citations,
    refusals — and says plainly that it is not more capable in general.
  - No offline claim. It needs a network for everything except the
    device's own text-to-speech voices.
  - No privacy claim beyond what the code actually does. Conversations
    are written to a local SQLite file with no user accounts and no
    authentication; browser speech recognition uploads audio to the
    browser vendor; weather lookups send a place name to Open-Meteo. All
    three are stated rather than glossed.
  - No language is described as fully supported. `LANGUAGE_SUPPORT`
    below is the single source of truth, and the "which languages"
    answer is generated from it, so the claim cannot drift away from the
    review status recorded here.

TRANSLATION STATUS: English and Tamil are written with reasonable
confidence. Hindi, Telugu and Kannada are best-effort and marked
`# NEEDS REVIEW`. Bodies are kept short so review stays tractable.

MARKUP: bodies may use three inline markers, which the frontend's
`ReplyText` renders as structure and strips before speaking aloud:

    ### Heading        a section heading
    - item             a bullet
    1. item            a numbered step

Nothing else is markup. Plain paragraphs stay plain.
"""
import re
from dataclasses import dataclass
from typing import Dict, List, Optional

LANGUAGES = ("en", "ta", "hi", "te", "kn")


# ---------------------------------------------------------------------------
# Language support matrix — the single source of truth
# ---------------------------------------------------------------------------
# One row per language, one honest status per part of the experience. The
# "which languages do you support" answer is *generated* from this table,
# so a language cannot be advertised as working better than this file says.
#
# Field meanings:
#   script_id  — how the backend identifies the language from written text.
#                "exact-script" means the language has its own Unicode
#                block and identification is a histogram, not a model.
#   asr        — browser speech recognition. The Web Speech API is
#                Chrome/Edge only and accepts one locale per session; the
#                quality of each locale is the browser vendor's, and we
#                have not measured it.
#   tts        — spoken replies. The browser uses whatever voices the
#                device has installed, which differs per device, so the
#                frontend checks at runtime and says when one is missing.
#   replies    — the state of the written reply text in this language.
#   review     — whether a native speaker has read that text.
LANGUAGE_SUPPORT: Dict[str, dict] = {
    "en": {
        "name": "English",
        "native": "English",
        "script_id": "by-elimination",
        "asr": "browser-supported",
        "tts": "device-dependent",
        "replies": "written",
        "review": "author-written",
    },
    "ta": {
        "name": "Tamil",
        "native": "தமிழ்",
        "script_id": "exact-script",
        "asr": "browser-supported",
        "tts": "device-dependent",
        "replies": "written",
        "review": "author-written",
    },
    "hi": {
        "name": "Hindi",
        "native": "हिंदी",
        "script_id": "exact-script",
        "asr": "browser-supported",
        "tts": "device-dependent",
        "replies": "written",
        "review": "needs-native-review",
    },
    "te": {
        "name": "Telugu",
        "native": "తెలుగు",
        "script_id": "exact-script",
        "asr": "browser-supported",
        "tts": "device-dependent",
        "replies": "written",
        "review": "needs-native-review",
    },
    "kn": {
        "name": "Kannada",
        "native": "ಕನ್ನಡ",
        "script_id": "exact-script",
        "asr": "browser-supported",
        "tts": "device-dependent",
        "replies": "written",
        "review": "needs-native-review",
    },
}

#: Languages whose wording no native speaker has signed off on yet.
UNREVIEWED = tuple(
    code for code, row in LANGUAGE_SUPPORT.items() if row["review"] == "needs-native-review"
)


def _language_list() -> str:
    """The supported languages as a readable list: native name + English name."""
    return ", ".join(
        f"{row['native']} ({row['name']})" for row in LANGUAGE_SUPPORT.values()
    )


def _unreviewed_names() -> str:
    return ", ".join(LANGUAGE_SUPPORT[code]["name"] for code in UNREVIEWED)


# ---------------------------------------------------------------------------
# The FAQ itself
# ---------------------------------------------------------------------------
# `{languages}` and `{unreviewed}` are substituted from the matrix above at
# format time, so the language claim and its source of truth cannot drift
# apart.

_ABOUT: Dict[str, dict] = {
    # ------------------------------------------------------------------
    "what_is": {
        "keywords": [
            "what is bharatvoice", "what's bharatvoice", "who are you",
            "about bharatvoice", "about this app", "tell me about yourself",
            "what are you",
            "பாரத்வாய்ஸ் என்றால் என்ன", "நீங்கள் யார்", "இந்த செயலி பற்றி",
            "भारतवॉयस क्या है", "आप कौन ह", "इस ऐप के बारे में",
            "భారత్‌వాయిస్ అంటే ఏమిటి", "మీరు ఎవరు", "ఈ యాప్ గురించి",
            "ಭಾರತ್‌ವಾಯ್ಸ್ ಎಂದರೇನು", "ನೀವು ಯಾರು", "ಈ ಆ್ಯಪ್ ಬಗ್ಗೆ",
        ],
        "en": (
            "BharatVoice AI is a voice and text assistant built around Indian "
            "languages and Indian public services. You can speak or type in "
            "Tamil, Hindi, Telugu, Kannada or English, and it answers in the "
            "same language.\n"
            "It is a student project, not a government service. Every answer "
            "that states a fact about the outside world carries the official "
            "portal it came from, and when it cannot check something reliably "
            "it says so instead of guessing."
        ),
        "ta": (
            "BharatVoice AI என்பது இந்திய மொழிகளையும் இந்திய அரசு சேவைகளையும் "
            "மையமாகக் கொண்ட குரல் மற்றும் உரை உதவியாளர். தமிழ், இந்தி, தெலுங்கு, "
            "கன்னடம், ஆங்கிலம் — எதிலும் பேசலாம் அல்லது தட்டச்சு செய்யலாம்; அதே "
            "மொழியில் பதில் வரும்.\n"
            "இது ஒரு மாணவர் திட்டம், அரசு சேவை அல்ல. வெளி உலகம் குறித்த ஒவ்வொரு "
            "தகவலுக்கும் அது எந்த அதிகாரப்பூர்வ தளத்திலிருந்து வந்தது என்பது "
            "காட்டப்படும்; உறுதியாகச் சரிபார்க்க முடியாதபோது ஊகிக்காமல், "
            "தெரியவில்லை என்றே சொல்லும்."
        ),
        "hi": (  # NEEDS REVIEW
            "BharatVoice AI भारतीय भाषाओं और भारतीय सार्वजनिक सेवाओं के लिए बनाया गया "
            "आवाज़ और टेक्स्ट सहायक है। आप तमिल, हिंदी, तेलुगु, कन्नड़ या अंग्रेज़ी में "
            "बोल या लिख सकते हैं, और उत्तर उसी भाषा में मिलता है।\n"
            "यह एक छात्र परियोजना है, सरकारी सेवा नहीं। बाहरी दुनिया के बारे में दिए गए "
            "हर तथ्य के साथ वह आधिकारिक पोर्टल दिखाया जाता है जहाँ से वह आया है, और जो "
            "भरोसे से जाँचा न जा सके उसका अंदाज़ा लगाने के बजाय यह साफ़ कह देता है।"
        ),
        "te": (  # NEEDS REVIEW
            "BharatVoice AI అనేది భారతీయ భాషలు మరియు భారతీయ ప్రజా సేవల కోసం రూపొందించిన "
            "వాయిస్ మరియు టెక్స్ట్ సహాయకం. మీరు తమిళం, హిందీ, తెలుగు, కన్నడ లేదా "
            "ఇంగ్లీష్‌లో మాట్లాడవచ్చు లేదా టైప్ చేయవచ్చు; అదే భాషలో సమాధానం వస్తుంది.\n"
            "ఇది ఒక విద్యార్థి ప్రాజెక్ట్, ప్రభుత్వ సేవ కాదు. బయటి ప్రపంచం గురించి "
            "చెప్పే ప్రతి విషయంతో పాటు అది ఏ అధికారిక పోర్టల్ నుండి వచ్చిందో "
            "చూపిస్తుంది; నమ్మకంగా తనిఖీ చేయలేనప్పుడు ఊహించకుండా తెలియదని చెబుతుంది."
        ),
        "kn": (  # NEEDS REVIEW
            "BharatVoice AI ಎಂಬುದು ಭಾರತೀಯ ಭಾಷೆಗಳು ಮತ್ತು ಭಾರತೀಯ ಸಾರ್ವಜನಿಕ ಸೇವೆಗಳನ್ನು "
            "ಕೇಂದ್ರವಾಗಿಟ್ಟುಕೊಂಡ ಧ್ವನಿ ಮತ್ತು ಪಠ್ಯ ಸಹಾಯಕ. ನೀವು ತಮಿಳು, ಹಿಂದಿ, ತೆಲುಗು, "
            "ಕನ್ನಡ ಅಥವಾ ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ ಮಾತನಾಡಬಹುದು ಅಥವಾ ಟೈಪ್ ಮಾಡಬಹುದು; ಅದೇ ಭಾಷೆಯಲ್ಲಿ "
            "ಉತ್ತರ ಬರುತ್ತದೆ.\n"
            "ಇದು ವಿದ್ಯಾರ್ಥಿ ಯೋಜನೆ, ಸರ್ಕಾರಿ ಸೇವೆ ಅಲ್ಲ. ಹೊರಜಗತ್ತಿನ ಬಗ್ಗೆ ಹೇಳುವ ಪ್ರತಿ "
            "ಸಂಗತಿಯ ಜೊತೆಗೆ ಅದು ಯಾವ ಅಧಿಕೃತ ಪೋರ್ಟಲ್‌ನಿಂದ ಬಂದಿದೆ ಎಂದು ತೋರಿಸುತ್ತದೆ; "
            "ಖಚಿತವಾಗಿ ಪರಿಶೀಲಿಸಲಾಗದಿದ್ದಾಗ ಊಹಿಸದೆ ಗೊತ್ತಿಲ್ಲ ಎಂದೇ ಹೇಳುತ್ತದೆ."
        ),
    },
    # ------------------------------------------------------------------
    "why_not_general": {
        "keywords": [
            "instead of chatgpt", "instead of gemini", "why not chatgpt",
            "why not gemini", "better than chatgpt", "better than gemini",
            "compared to chatgpt", "compared to gemini", "why use bharatvoice",
            "why should i use", "difference from chatgpt",
            "சாட்ஜிபிடிக்கு பதிலாக", "ஏன் இதை பயன்படுத்த",
            "चैटजीपीटी के बजाय", "इसे क्यों इस्तेमाल",
            "చాట్‌జీపీటీ బదులు", "దీన్ని ఎందుకు వాడాలి",
            "ಚಾಟ್‌ಜಿಪಿಟಿ ಬದಲು", "ಇದನ್ನು ಏಕೆ ಬಳಸಬೇಕು",
        ],
        "en": (
            "It is not more capable than a general assistant like ChatGPT or "
            "Gemini — those are far larger models and will beat this one at "
            "open-ended questions. What is different here is the scope and the "
            "rules:\n"
            "- It is built for Indian languages and Indian services first, not "
            "as an afterthought.\n"
            "- Factual answers carry the official Indian portal they came from, "
            "so you can check them yourself.\n"
            "- It refuses rather than guesses on health, eligibility and money "
            "questions, and it never tells you whether you qualify for a scheme.\n"
            "For general knowledge, writing or coding, a general assistant is "
            "the better tool. Use whichever fits the question."
        ),
        "ta": (
            "ChatGPT அல்லது Gemini போன்ற பொது உதவியாளர்களை விட இது திறன் மிக்கது "
            "அல்ல — அவை மிகப் பெரிய மாதிரிகள், திறந்த கேள்விகளில் இதை விட சிறப்பாகச் "
            "செயல்படும். இங்கு வேறுபாடு நோக்கத்திலும் விதிகளிலும் உள்ளது:\n"
            "- இந்திய மொழிகளுக்கும் இந்திய சேவைகளுக்கும் முதன்மையாக "
            "வடிவமைக்கப்பட்டது.\n"
            "- தகவல் சார்ந்த பதில்களுடன் அவை வந்த அதிகாரப்பூர்வ இந்திய தளம் "
            "காட்டப்படும்; நீங்களே சரிபார்க்கலாம்.\n"
            "- உடல்நலம், தகுதி, பணம் சார்ந்த கேள்விகளில் ஊகிக்காமல் மறுக்கும்; ஒரு "
            "திட்டத்திற்கு நீங்கள் தகுதியானவரா என்பதை ஒருபோதும் சொல்லாது.\n"
            "பொது அறிவு, எழுத்து, நிரலாக்கம் போன்றவற்றுக்கு பொது உதவியாளரே சிறந்தது. "
            "கேள்விக்கு எது பொருந்துகிறதோ அதைப் பயன்படுத்துங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "यह ChatGPT या Gemini जैसे सामान्य सहायकों से ज़्यादा सक्षम नहीं है — वे बहुत "
            "बड़े मॉडल हैं और खुले सवालों में इससे बेहतर रहेंगे। यहाँ फ़र्क़ दायरे और "
            "नियमों का है:\n"
            "- यह पहले भारतीय भाषाओं और भारतीय सेवाओं के लिए बना है, बाद में जोड़ी गई "
            "सुविधा के रूप में नहीं।\n"
            "- तथ्य वाले उत्तरों के साथ वह आधिकारिक भारतीय पोर्टल दिखता है जहाँ से वे "
            "आए, ताकि आप ख़ुद जाँच सकें।\n"
            "- स्वास्थ्य, पात्रता और पैसे के सवालों पर यह अंदाज़ा लगाने के बजाय मना कर "
            "देता है, और कभी नहीं बताता कि आप किसी योजना के पात्र हैं या नहीं।\n"
            "सामान्य ज्ञान, लेखन या कोडिंग के लिए सामान्य सहायक बेहतर है। सवाल के "
            "हिसाब से चुनिए।"
        ),
        "te": (  # NEEDS REVIEW
            "ఇది ChatGPT లేదా Gemini వంటి సాధారణ సహాయకాల కంటే ఎక్కువ సామర్థ్యం కలది "
            "కాదు — అవి చాలా పెద్ద మోడళ్లు, విస్తృత ప్రశ్నల్లో దీని కంటే మెరుగ్గా "
            "ఉంటాయి. ఇక్కడ తేడా పరిధిలోనూ నియమాల్లోనూ ఉంది:\n"
            "- ఇది మొదట భారతీయ భాషలు, భారతీయ సేవల కోసం రూపొందింది.\n"
            "- వాస్తవ సమాచారంతో పాటు అది వచ్చిన అధికారిక భారతీయ పోర్టల్ చూపిస్తుంది, "
            "మీరే తనిఖీ చేసుకోవచ్చు.\n"
            "- ఆరోగ్యం, అర్హత, డబ్బు ప్రశ్నలలో ఊహించకుండా నిరాకరిస్తుంది; ఒక పథకానికి "
            "మీరు అర్హులా కాదా అని ఎప్పుడూ చెప్పదు.\n"
            "సాధారణ జ్ఞానం, రచన లేదా కోడింగ్ కోసం సాధారణ సహాయకమే మేలు. ప్రశ్నకు "
            "సరిపోయేది వాడండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಇದು ChatGPT ಅಥವಾ Gemini ನಂತಹ ಸಾಮಾನ್ಯ ಸಹಾಯಕಗಳಿಗಿಂತ ಹೆಚ್ಚು ಸಮರ್ಥವಲ್ಲ — ಅವು "
            "ಬಹಳ ದೊಡ್ಡ ಮಾದರಿಗಳು, ಮುಕ್ತ ಪ್ರಶ್ನೆಗಳಲ್ಲಿ ಇದಕ್ಕಿಂತ ಉತ್ತಮವಾಗಿರುತ್ತವೆ. ಇಲ್ಲಿನ "
            "ವ್ಯತ್ಯಾಸ ವ್ಯಾಪ್ತಿ ಮತ್ತು ನಿಯಮಗಳಲ್ಲಿದೆ:\n"
            "- ಇದು ಮೊದಲು ಭಾರತೀಯ ಭಾಷೆಗಳು ಮತ್ತು ಭಾರತೀಯ ಸೇವೆಗಳಿಗಾಗಿ ನಿರ್ಮಿಸಲಾಗಿದೆ.\n"
            "- ಸಂಗತಿ ಹೇಳುವ ಉತ್ತರಗಳ ಜೊತೆಗೆ ಅವು ಬಂದ ಅಧಿಕೃತ ಭಾರತೀಯ ಪೋರ್ಟಲ್ ತೋರಿಸುತ್ತದೆ, "
            "ನೀವೇ ಪರಿಶೀಲಿಸಬಹುದು.\n"
            "- ಆರೋಗ್ಯ, ಅರ್ಹತೆ ಮತ್ತು ಹಣದ ಪ್ರಶ್ನೆಗಳಲ್ಲಿ ಊಹಿಸದೆ ನಿರಾಕರಿಸುತ್ತದೆ; ಯೋಜನೆಗೆ "
            "ನೀವು ಅರ್ಹರೇ ಎಂದು ಎಂದಿಗೂ ಹೇಳುವುದಿಲ್ಲ.\n"
            "ಸಾಮಾನ್ಯ ಜ್ಞಾನ, ಬರವಣಿಗೆ ಅಥವಾ ಕೋಡಿಂಗ್‌ಗೆ ಸಾಮಾನ್ಯ ಸಹಾಯಕವೇ ಉತ್ತಮ. ಪ್ರಶ್ನೆಗೆ "
            "ಹೊಂದುವುದನ್ನು ಬಳಸಿ."
        ),
    },
    # ------------------------------------------------------------------
    "what_can_it_do": {
        "keywords": [
            "what can bharatvoice help", "what can you help with",
            "what can this app do", "what do you help with",
            "what topics", "what can i ask",
            "எதில் உதவ முடியும்", "என்ன கேட்கலாம்",
            "किन चीज़ों में मदद", "क्या पूछ सकते ह",
            "దేనిలో సహాయం", "ఏమి అడగవచ్చు",
            "ಯಾವುದರಲ್ಲಿ ಸಹಾಯ", "ಏನು ಕೇಳಬಹುದು",
        ],
        "en": (
            "### What I can help with\n"
            "- Live weather for an Indian place, with the time of the reading.\n"
            "- Mandi (market) prices from AGMARKNET, if a data.gov.in key is "
            "configured.\n"
            "- Emergency helpline numbers, as rows you can tap to dial.\n"
            "- Reminders that actually go off while the tab is open.\n"
            "- Government documents: Aadhaar, PAN, Voter ID, Ration Card, "
            "Passport, Driving Licence.\n"
            "- Cited guidance on scholarships, bank accounts, online fraud and "
            "scams, trains and buses, schemes, jobs and finding a hospital.\n"
            "- Time, date, arithmetic and unit conversion.\n"
            "Scheme search, job search and hospital search are links to the "
            "official portal, not searches I run myself — those portals have no "
            "open API."
        ),
        "ta": (
            "### நான் உதவக்கூடியவை\n"
            "- இந்திய ஊர்களின் நேரடி வானிலை, அளவீடு எடுக்கப்பட்ட நேரத்துடன்.\n"
            "- AGMARKNET மண்டி விலைகள் — data.gov.in சாவி அமைக்கப்பட்டிருந்தால்.\n"
            "- அவசர உதவி எண்கள், தட்டி அழைக்கும் வரிசைகளாக.\n"
            "- தாவல் திறந்திருக்கும்போது உண்மையாக ஒலிக்கும் நினைவூட்டல்கள்.\n"
            "- அரசு ஆவணங்கள்: ஆதார், PAN, வாக்காளர் அட்டை, ரேஷன் கார்டு, பாஸ்போர்ட், "
            "ஓட்டுநர் உரிமம்.\n"
            "- உதவித்தொகை, வங்கிக் கணக்கு, இணைய மோசடி, ரயில்/பஸ், அரசுத் திட்டங்கள், "
            "வேலை, மருத்துவமனை — ஆதாரத்துடன் கூடிய வழிகாட்டுதல்.\n"
            "- நேரம், தேதி, கணக்கு, அலகு மாற்றம்.\n"
            "திட்டம், வேலை, மருத்துவமனை தேடல்கள் அதிகாரப்பூர்வ தளத்திற்கான இணைப்புகள் "
            "மட்டுமே — அந்தத் தளங்களுக்கு திறந்த API இல்லை."
        ),
        "hi": (  # NEEDS REVIEW
            "### मैं किन चीज़ों में मदद कर सकता हूँ\n"
            "- भारतीय जगहों का लाइव मौसम, माप के समय के साथ।\n"
            "- AGMARKNET मंडी भाव — अगर data.gov.in की कुंजी सेट हो।\n"
            "- आपातकालीन हेल्पलाइन नंबर, टैप करके कॉल करने लायक पंक्तियों में।\n"
            "- रिमाइंडर, जो टैब खुला रहने पर सचमुच बजते हैं।\n"
            "- सरकारी दस्तावेज़: आधार, PAN, वोटर आईडी, राशन कार्ड, पासपोर्ट, ड्राइविंग "
            "लाइसेंस।\n"
            "- छात्रवृत्ति, बैंक खाता, ऑनलाइन ठगी, ट्रेन-बस, योजनाएँ, नौकरी और अस्पताल "
            "खोजने पर स्रोत-सहित जानकारी।\n"
            "- समय, तारीख, गणना और इकाई बदलना।\n"
            "योजना, नौकरी और अस्पताल की खोज आधिकारिक पोर्टल के लिंक हैं, मेरी अपनी "
            "खोज नहीं — उन पोर्टलों का कोई खुला API नहीं है।"
        ),
        "te": (  # NEEDS REVIEW
            "### నేను దేనిలో సహాయపడగలను\n"
            "- భారతీయ ప్రాంతాల ప్రత్యక్ష వాతావరణం, కొలిచిన సమయంతో సహా.\n"
            "- AGMARKNET మండీ ధరలు — data.gov.in కీ అమర్చి ఉంటే.\n"
            "- అత్యవసర హెల్ప్‌లైన్ నంబర్లు, నొక్కి కాల్ చేసే వరుసలుగా.\n"
            "- ట్యాబ్ తెరిచి ఉన్నప్పుడు నిజంగా మోగే రిమైండర్లు.\n"
            "- ప్రభుత్వ పత్రాలు: ఆధార్, PAN, ఓటర్ ఐడీ, రేషన్ కార్డు, పాస్‌పోర్ట్, "
            "డ్రైవింగ్ లైసెన్స్.\n"
            "- ఉపకార వేతనం, బ్యాంకు ఖాతా, ఆన్‌లైన్ మోసాలు, రైలు-బస్సు, పథకాలు, "
            "ఉద్యోగాలు, ఆసుపత్రి — ఆధారాలతో మార్గదర్శనం.\n"
            "- సమయం, తేదీ, లెక్కలు, యూనిట్ మార్పిడి.\n"
            "పథకం, ఉద్యోగం, ఆసుపత్రి వెతుకులాట అధికారిక పోర్టల్ లింకులు మాత్రమే, నేను "
            "చేసే శోధన కాదు — ఆ పోర్టళ్లకు తెరిచిన API లేదు."
        ),
        "kn": (  # NEEDS REVIEW
            "### ನಾನು ಯಾವುದರಲ್ಲಿ ಸಹಾಯ ಮಾಡಬಲ್ಲೆ\n"
            "- ಭಾರತೀಯ ಸ್ಥಳಗಳ ನೇರ ಹವಾಮಾನ, ಅಳತೆಯ ಸಮಯದೊಂದಿಗೆ.\n"
            "- AGMARKNET ಮಾರುಕಟ್ಟೆ ದರಗಳು — data.gov.in ಕೀ ಹೊಂದಿಸಿದ್ದರೆ.\n"
            "- ತುರ್ತು ಸಹಾಯವಾಣಿ ಸಂಖ್ಯೆಗಳು, ಒತ್ತಿ ಕರೆ ಮಾಡುವ ಸಾಲುಗಳಾಗಿ.\n"
            "- ಟ್ಯಾಬ್ ತೆರೆದಿರುವಾಗ ನಿಜವಾಗಿ ಮೊಳಗುವ ಜ್ಞಾಪನೆಗಳು.\n"
            "- ಸರ್ಕಾರಿ ದಾಖಲೆಗಳು: ಆಧಾರ್, PAN, ಮತದಾರ ಗುರುತಿನ ಚೀಟಿ, ಪಡಿತರ ಚೀಟಿ, "
            "ಪಾಸ್‌ಪೋರ್ಟ್, ಚಾಲನಾ ಪರವಾನಗಿ.\n"
            "- ವಿದ್ಯಾರ್ಥಿವೇತನ, ಬ್ಯಾಂಕ್ ಖಾತೆ, ಆನ್‌ಲೈನ್ ವಂಚನೆ, ರೈಲು-ಬಸ್, ಯೋಜನೆಗಳು, "
            "ಉದ್ಯೋಗ, ಆಸ್ಪತ್ರೆ — ಆಧಾರ ಸಹಿತ ಮಾರ್ಗದರ್ಶನ.\n"
            "- ಸಮಯ, ದಿನಾಂಕ, ಲೆಕ್ಕ ಮತ್ತು ಅಳತೆ ಪರಿವರ್ತನೆ.\n"
            "ಯೋಜನೆ, ಉದ್ಯೋಗ ಮತ್ತು ಆಸ್ಪತ್ರೆ ಹುಡುಕಾಟ ಅಧಿಕೃತ ಪೋರ್ಟಲ್‌ನ ಕೊಂಡಿಗಳು ಮಾತ್ರ, "
            "ನಾನೇ ನಡೆಸುವ ಹುಡುಕಾಟ ಅಲ್ಲ — ಆ ಪೋರ್ಟಲ್‌ಗಳಿಗೆ ಮುಕ್ತ API ಇಲ್ಲ."
        ),
    },
    # ------------------------------------------------------------------
    "languages": {
        "keywords": [
            "which languages", "what languages", "languages do you support",
            "languages supported", "how many languages", "do you speak tamil",
            "எந்த மொழிகள்", "எத்தனை மொழி",
            "कौन सी भाषा", "कितनी भाषा",
            "ఏ భాషలు", "ఎన్ని భాషలు",
            "ಯಾವ ಭಾಷೆ", "ಎಷ್ಟು ಭಾಷೆ",
        ],
        "en": (
            "Five: {languages}.\n"
            "All five are handled end to end in writing — the language is "
            "identified, the request is understood, and the reply is written in "
            "that language.\n"
            "Two honest limits. The {unreviewed} wording has not yet been read "
            "by a native speaker, so expect awkward phrasing there. And spoken "
            "input and spoken replies depend on your browser and device: "
            "speech recognition needs Chrome or Edge, and a reply is only read "
            "aloud if your device has a voice installed for that language. "
            "Where a voice is missing the app says so and shows the answer as "
            "text instead."
        ),
        "ta": (
            "ஐந்து: {languages}.\n"
            "ஐந்தும் எழுத்தில் முழுமையாகக் கையாளப்படுகின்றன — மொழி கண்டறியப்படும், "
            "கேள்வி புரிந்துகொள்ளப்படும், பதில் அதே மொழியில் எழுதப்படும்.\n"
            "இரண்டு நேர்மையான வரம்புகள். {unreviewed} மொழிகளின் வார்த்தைகளை இதுவரை "
            "ஒரு தாய்மொழிப் பேச்சாளர் படித்துச் சரிபார்க்கவில்லை, எனவே அங்கு சில "
            "இடங்களில் மொழிநடை செம்மையாக இருக்காது. மேலும் பேச்சு உள்ளீடும் பேசும் "
            "பதிலும் உங்கள் உலாவியையும் சாதனத்தையும் சார்ந்தவை: பேச்சு அறிதலுக்கு "
            "Chrome அல்லது Edge தேவை, அந்த மொழிக்கான குரல் சாதனத்தில் "
            "நிறுவப்பட்டிருந்தால் மட்டுமே பதில் ஒலிக்கும். குரல் இல்லாதபோது அதைச் "
            "சொல்லிவிட்டு பதிலை உரையாகக் காட்டும்."
        ),
        "hi": (  # NEEDS REVIEW
            "पाँच: {languages}।\n"
            "पाँचों को लिखित रूप में पूरी तरह संभाला जाता है — भाषा पहचानी जाती है, "
            "सवाल समझा जाता है, और उत्तर उसी भाषा में लिखा जाता है।\n"
            "दो ईमानदार सीमाएँ। {unreviewed} की भाषा को अभी तक किसी मातृभाषी ने नहीं "
            "पढ़ा है, इसलिए वहाँ शब्द कहीं-कहीं अटपटे लग सकते हैं। और बोलकर पूछना तथा "
            "बोलकर उत्तर सुनना आपके ब्राउज़र और डिवाइस पर निर्भर है: वाक्-पहचान के लिए "
            "Chrome या Edge चाहिए, और उत्तर तभी बोला जाएगा जब आपके डिवाइस में उस भाषा "
            "की आवाज़ मौजूद हो। आवाज़ न होने पर ऐप यह बता देता है और उत्तर टेक्स्ट में "
            "दिखाता है।"
        ),
        "te": (  # NEEDS REVIEW
            "ఐదు: {languages}.\n"
            "ఐదింటినీ రాతలో పూర్తిగా నిర్వహిస్తుంది — భాష గుర్తించబడుతుంది, ప్రశ్న "
            "అర్థమవుతుంది, సమాధానం అదే భాషలో వ్రాయబడుతుంది.\n"
            "రెండు నిజాయితీ పరిమితులు. {unreviewed} పదజాలాన్ని ఇంతవరకు మాతృభాషీయులు "
            "చదవలేదు, కాబట్టి అక్కడ కొన్ని చోట్ల భాష సహజంగా ఉండకపోవచ్చు. అలాగే "
            "మాట్లాడి అడగడం, మాట్లాడే సమాధానం మీ బ్రౌజర్ మరియు పరికరంపై ఆధారపడి "
            "ఉంటాయి: వాక్ గుర్తింపునకు Chrome లేదా Edge కావాలి, ఆ భాషకు మీ పరికరంలో "
            "వాయిస్ ఉంటేనే సమాధానం వినిపిస్తుంది. వాయిస్ లేనప్పుడు యాప్ అది చెప్పి "
            "సమాధానాన్ని టెక్స్ట్‌గా చూపుతుంది."
        ),
        "kn": (  # NEEDS REVIEW
            "ಐದು: {languages}.\n"
            "ಐದನ್ನೂ ಬರವಣಿಗೆಯಲ್ಲಿ ಪೂರ್ಣವಾಗಿ ನಿಭಾಯಿಸಲಾಗುತ್ತದೆ — ಭಾಷೆ ಗುರುತಿಸಲಾಗುತ್ತದೆ, "
            "ಪ್ರಶ್ನೆ ಅರ್ಥವಾಗುತ್ತದೆ, ಉತ್ತರ ಅದೇ ಭಾಷೆಯಲ್ಲಿ ಬರೆಯಲಾಗುತ್ತದೆ.\n"
            "ಎರಡು ಪ್ರಾಮಾಣಿಕ ಮಿತಿಗಳು. {unreviewed} ಪದಪ್ರಯೋಗವನ್ನು ಇದುವರೆಗೆ ಸ್ಥಳೀಯ "
            "ಭಾಷಿಕರು ಓದಿಲ್ಲ, ಆದ್ದರಿಂದ ಅಲ್ಲಿ ಕೆಲವೆಡೆ ಭಾಷೆ ಸಹಜವಾಗಿ ಇರದಿರಬಹುದು. ಹಾಗೆಯೇ "
            "ಮಾತನಾಡಿ ಕೇಳುವುದು ಮತ್ತು ಮಾತಿನ ಉತ್ತರ ನಿಮ್ಮ ಬ್ರೌಸರ್ ಮತ್ತು ಸಾಧನವನ್ನು "
            "ಅವಲಂಬಿಸಿವೆ: ಧ್ವನಿ ಗುರುತಿಸುವಿಕೆಗೆ Chrome ಅಥವಾ Edge ಬೇಕು, ಆ ಭಾಷೆಯ ಧ್ವನಿ "
            "ನಿಮ್ಮ ಸಾಧನದಲ್ಲಿ ಇದ್ದರೆ ಮಾತ್ರ ಉತ್ತರ ಕೇಳಿಸುತ್ತದೆ. ಧ್ವನಿ ಇಲ್ಲದಿದ್ದಾಗ ಆ್ಯಪ್ "
            "ಅದನ್ನು ತಿಳಿಸಿ ಉತ್ತರವನ್ನು ಪಠ್ಯವಾಗಿ ತೋರಿಸುತ್ತದೆ."
        ),
    },
    # ------------------------------------------------------------------
    "language_detection": {
        "keywords": [
            "how do you identify the language", "how do you detect the language",
            "how do you know which language", "identify my language",
            "detect my language", "language detection",
            "மொழியை எப்படி கண்டுபிடி", "மொழி அடையாளம்",
            "भाषा कैसे पहचान", "भाषा की पहचान",
            "భాషను ఎలా గుర్తి", "భాష గుర్తింపు",
            "ಭಾಷೆಯನ್ನು ಹೇಗೆ ಗುರುತಿ", "ಭಾಷೆ ಗುರುತಿಸುವಿಕೆ",
        ],
        "en": (
            "From the script you write in. Tamil, Devanagari, Telugu and "
            "Kannada each occupy their own block of Unicode, so counting the "
            "characters identifies the script exactly — no model, no download, "
            "no delay.\n"
            "Two things follow from that. Devanagari is shared with Marathi and "
            "other languages, so the script tells me the script, not the "
            "language with certainty. And romanized typing (\"vanakkam, epdi "
            "irukeenga\") carries no script signal at all, so that is matched "
            "against a list of common cue words instead — less reliable, and it "
            "can be wrong.\n"
            "For speech there is no detection at all: the browser has to be "
            "told one language before it starts listening, which is what the "
            "language button in the header does."
        ),
        "ta": (
            "நீங்கள் எழுதும் எழுத்துருவிலிருந்து. தமிழ், தேவநாகரி, தெலுங்கு, கன்னடம் "
            "ஒவ்வொன்றுக்கும் யூனிகோடில் தனித்தனி தொகுதி உள்ளது, எனவே எழுத்துகளை "
            "எண்ணுவதன் மூலம் எழுத்துரு துல்லியமாகக் கண்டறியப்படும் — மாதிரி இல்லை, "
            "பதிவிறக்கம் இல்லை, தாமதம் இல்லை.\n"
            "இதிலிருந்து இரண்டு விஷயங்கள். தேவநாகரி மராத்தி உள்ளிட்ட மொழிகளுடன் "
            "பகிரப்படுகிறது, எனவே எழுத்துரு தெரியுமே தவிர மொழி உறுதியாகத் தெரியாது. "
            "ஆங்கில எழுத்தில் தமிழ் எழுதினால் (\"vanakkam, epdi irukeenga\") எழுத்துரு "
            "குறிப்பே இல்லை; அதற்கு பொதுவான சொற்களின் பட்டியல் பயன்படுத்தப்படுகிறது — "
            "அது குறைவாகவே நம்பகமானது, தவறாகவும் போகலாம்.\n"
            "பேச்சுக்கு கண்டறிதலே இல்லை: உலாவிக்கு கேட்கத் தொடங்கும் முன்பே ஒரு மொழி "
            "சொல்லப்பட வேண்டும் — அதைத்தான் மேல் பட்டியில் உள்ள மொழி பொத்தான் செய்கிறது."
        ),
        "hi": (  # NEEDS REVIEW
            "आपकी लिपि से। तमिल, देवनागरी, तेलुगु और कन्नड़ में से हर एक का यूनिकोड में "
            "अपना अलग खंड है, इसलिए अक्षर गिनकर लिपि ठीक-ठीक पहचानी जा सकती है — कोई "
            "मॉडल नहीं, कोई डाउनलोड नहीं, कोई देरी नहीं।\n"
            "इससे दो बातें निकलती हैं। देवनागरी मराठी और अन्य भाषाओं के साथ साझा है, "
            "इसलिए लिपि पता चलती है, भाषा निश्चित रूप से नहीं। और रोमन अक्षरों में लिखने "
            "पर (\"vanakkam, epdi irukeenga\") लिपि का कोई संकेत ही नहीं होता, तो उसके "
            "लिए आम शब्दों की सूची से मिलान होता है — जो कम भरोसेमंद है और ग़लत भी हो "
            "सकता है।\n"
            "बोली गई बात के लिए पहचान होती ही नहीं: ब्राउज़र को सुनना शुरू करने से पहले "
            "एक भाषा बतानी पड़ती है, यही काम ऊपर का भाषा बटन करता है।"
        ),
        "te": (  # NEEDS REVIEW
            "మీరు రాసే లిపి నుండి. తమిళం, దేవనాగరి, తెలుగు, కన్నడ — ప్రతి దానికీ "
            "యూనికోడ్‌లో సొంత విభాగం ఉంది, కాబట్టి అక్షరాలను లెక్కించడం ద్వారా లిపిని "
            "కచ్చితంగా గుర్తించవచ్చు — మోడల్ అవసరం లేదు, డౌన్‌లోడ్ లేదు, ఆలస్యం లేదు.\n"
            "దీని నుండి రెండు విషయాలు. దేవనాగరిని మరాఠీ తదితర భాషలు కూడా వాడతాయి, "
            "కాబట్టి లిపి తెలుస్తుంది, భాష కచ్చితంగా కాదు. ఇంగ్లీష్ అక్షరాలలో రాస్తే "
            "(\"vanakkam, epdi irukeenga\") లిపి సూచనే ఉండదు, అందుకు సాధారణ పదాల "
            "జాబితాతో సరిపోల్చుతాం — అది తక్కువ నమ్మదగినది, తప్పు కూడా కావచ్చు.\n"
            "మాటకు గుర్తింపే లేదు: వినడం మొదలుపెట్టే ముందు బ్రౌజర్‌కు ఒక భాష "
            "చెప్పాల్సిందే — పై భాగంలోని భాష బటన్ చేసేది అదే."
        ),
        "kn": (  # NEEDS REVIEW
            "ನೀವು ಬರೆಯುವ ಲಿಪಿಯಿಂದ. ತಮಿಳು, ದೇವನಾಗರಿ, ತೆಲುಗು ಮತ್ತು ಕನ್ನಡ — ಪ್ರತಿಯೊಂದಕ್ಕೂ "
            "ಯೂನಿಕೋಡ್‌ನಲ್ಲಿ ತನ್ನದೇ ವಿಭಾಗವಿದೆ, ಆದ್ದರಿಂದ ಅಕ್ಷರಗಳನ್ನು ಎಣಿಸಿ ಲಿಪಿಯನ್ನು "
            "ನಿಖರವಾಗಿ ಗುರುತಿಸಬಹುದು — ಮಾದರಿ ಬೇಡ, ಡೌನ್‌ಲೋಡ್ ಬೇಡ, ವಿಳಂಬ ಇಲ್ಲ.\n"
            "ಇದರಿಂದ ಎರಡು ಸಂಗತಿಗಳು. ದೇವನಾಗರಿಯನ್ನು ಮರಾಠಿ ಮೊದಲಾದ ಭಾಷೆಗಳೂ ಬಳಸುತ್ತವೆ, "
            "ಆದ್ದರಿಂದ ಲಿಪಿ ತಿಳಿಯುತ್ತದೆ, ಭಾಷೆ ಖಚಿತವಾಗಿ ಅಲ್ಲ. ಇಂಗ್ಲಿಷ್ ಅಕ್ಷರಗಳಲ್ಲಿ "
            "ಬರೆದರೆ (\"vanakkam, epdi irukeenga\") ಲಿಪಿಯ ಸೂಚನೆಯೇ ಇಲ್ಲ, ಅದಕ್ಕಾಗಿ "
            "ಸಾಮಾನ್ಯ ಪದಗಳ ಪಟ್ಟಿಯೊಂದಿಗೆ ಹೋಲಿಸಲಾಗುತ್ತದೆ — ಅದು ಕಡಿಮೆ ವಿಶ್ವಾಸಾರ್ಹ, "
            "ತಪ್ಪೂ ಆಗಬಹುದು.\n"
            "ಮಾತಿಗೆ ಗುರುತಿಸುವಿಕೆಯೇ ಇಲ್ಲ: ಕೇಳಲು ಆರಂಭಿಸುವ ಮೊದಲು ಬ್ರೌಸರ್‌ಗೆ ಒಂದು ಭಾಷೆ "
            "ಹೇಳಬೇಕು — ಮೇಲಿನ ಭಾಷಾ ಗುಂಡಿ ಮಾಡುವುದು ಅದನ್ನೇ."
        ),
    },
    # ------------------------------------------------------------------
    "offline": {
        "keywords": [
            "work offline", "works offline", "without internet",
            "without an internet", "no internet", "need internet",
            "internet connection", "offline mode",
            "இணையம் இல்லாமல்", "ஆஃப்லைன்",
            "बिना इंटरनेट", "ऑफ़लाइन", "ऑफलाइन",
            "ఇంటర్నెట్ లేకుండా", "ఆఫ్‌లైన్",
            "ಇಂಟರ್ನೆಟ್ ಇಲ್ಲದೆ", "ಆಫ್‌ಲೈನ್",
        ],
        "en": (
            "No. It needs an internet connection.\n"
            "The page talks to a server for every answer, weather and mandi "
            "prices come from live APIs, and browser speech recognition uploads "
            "your audio to the browser vendor's servers to transcribe it. The "
            "only part that may work offline is your device reading a reply "
            "aloud, because those voices are installed locally.\n"
            "Language identification does run without any downloaded model, but "
            "it happens on the server, so it still needs the connection."
        ),
        "ta": (
            "இல்லை. இணைய இணைப்பு தேவை.\n"
            "ஒவ்வொரு பதிலுக்கும் இந்தப் பக்கம் ஒரு சேவையகத்துடன் பேசுகிறது; வானிலையும் "
            "மண்டி விலையும் நேரடி API-களிலிருந்து வருகின்றன; உலாவியின் பேச்சு அறிதல் "
            "உங்கள் ஒலியை உலாவி நிறுவனத்தின் சேவையகங்களுக்கு அனுப்பி எழுத்தாக "
            "மாற்றுகிறது. இணையம் இல்லாமல் வேலை செய்யக்கூடியது ஒன்றே — உங்கள் சாதனம் "
            "பதிலை வாசித்துக் காட்டுவது, ஏனெனில் அந்தக் குரல்கள் சாதனத்திலேயே "
            "நிறுவப்பட்டவை.\n"
            "மொழி கண்டறிதலுக்கு எந்த மாதிரியும் பதிவிறக்கப்படுவதில்லை, ஆனால் அதுவும் "
            "சேவையகத்தில் நடப்பதால் இணைப்பு தேவைப்படுகிறது."
        ),
        "hi": (  # NEEDS REVIEW
            "नहीं। इसके लिए इंटरनेट कनेक्शन चाहिए।\n"
            "हर उत्तर के लिए यह पेज एक सर्वर से बात करता है, मौसम और मंडी भाव लाइव API से "
            "आते हैं, और ब्राउज़र की वाक्-पहचान आपकी आवाज़ को लिखने के लिए ब्राउज़र "
            "कंपनी के सर्वर पर भेजती है। बिना इंटरनेट केवल एक चीज़ चल सकती है — आपके "
            "डिवाइस का उत्तर बोलकर सुनाना, क्योंकि वे आवाज़ें डिवाइस में ही होती हैं।\n"
            "भाषा की पहचान के लिए कोई मॉडल डाउनलोड नहीं होता, पर वह भी सर्वर पर होती है, "
            "इसलिए कनेक्शन फिर भी ज़रूरी है।"
        ),
        "te": (  # NEEDS REVIEW
            "లేదు. దీనికి ఇంటర్నెట్ కనెక్షన్ అవసరం.\n"
            "ప్రతి సమాధానానికీ ఈ పేజీ ఒక సర్వర్‌తో మాట్లాడుతుంది, వాతావరణం మరియు మండీ "
            "ధరలు ప్రత్యక్ష API ల నుండి వస్తాయి, బ్రౌజర్ వాక్ గుర్తింపు మీ ఆడియోను "
            "లిప్యంతరీకరణ కోసం బ్రౌజర్ సంస్థ సర్వర్లకు పంపుతుంది. ఇంటర్నెట్ లేకుండా "
            "పనిచేసేది ఒక్కటే — మీ పరికరం సమాధానాన్ని చదివి వినిపించడం, ఎందుకంటే ఆ "
            "వాయిస్‌లు పరికరంలోనే ఉంటాయి.\n"
            "భాష గుర్తింపునకు ఏ మోడల్‌నూ డౌన్‌లోడ్ చేయరు, కానీ అది కూడా సర్వర్‌లో "
            "జరుగుతుంది కాబట్టి కనెక్షన్ అవసరమే."
        ),
        "kn": (  # NEEDS REVIEW
            "ಇಲ್ಲ. ಇದಕ್ಕೆ ಇಂಟರ್ನೆಟ್ ಸಂಪರ್ಕ ಬೇಕು.\n"
            "ಪ್ರತಿ ಉತ್ತರಕ್ಕೂ ಈ ಪುಟ ಸರ್ವರ್‌ನೊಂದಿಗೆ ಮಾತನಾಡುತ್ತದೆ, ಹವಾಮಾನ ಮತ್ತು ಮಾರುಕಟ್ಟೆ "
            "ದರಗಳು ನೇರ API ಗಳಿಂದ ಬರುತ್ತವೆ, ಬ್ರೌಸರ್ ಧ್ವನಿ ಗುರುತಿಸುವಿಕೆ ನಿಮ್ಮ ಆಡಿಯೊವನ್ನು "
            "ಲಿಪ್ಯಂತರಕ್ಕಾಗಿ ಬ್ರೌಸರ್ ಕಂಪನಿಯ ಸರ್ವರ್‌ಗಳಿಗೆ ಕಳುಹಿಸುತ್ತದೆ. ಇಂಟರ್ನೆಟ್ ಇಲ್ಲದೆ "
            "ನಡೆಯಬಹುದಾದದ್ದು ಒಂದೇ — ನಿಮ್ಮ ಸಾಧನ ಉತ್ತರವನ್ನು ಓದಿ ಹೇಳುವುದು, ಏಕೆಂದರೆ ಆ "
            "ಧ್ವನಿಗಳು ಸಾಧನದಲ್ಲೇ ಇರುತ್ತವೆ.\n"
            "ಭಾಷೆ ಗುರುತಿಸಲು ಯಾವ ಮಾದರಿಯನ್ನೂ ಡೌನ್‌ಲೋಡ್ ಮಾಡುವುದಿಲ್ಲ, ಆದರೆ ಅದೂ ಸರ್ವರ್‌ನಲ್ಲಿ "
            "ನಡೆಯುವುದರಿಂದ ಸಂಪರ್ಕ ಬೇಕೇ ಬೇಕು."
        ),
    },
    # ------------------------------------------------------------------
    "privacy": {
        "keywords": [
            "my data", "my privacy", "is it private", "personal information",
            "store my conversations", "save my conversations", "data privacy",
            "who can see my", "is my data safe",
            "என் தரவு", "தனியுரிமை", "என் உரையாடல்கள்",
            "मेरा डेटा", "निजता", "मेरी बातचीत", "गोपनीयता",
            "నా డేటా", "గోప్యత", "నా సంభాషణ",
            "ನನ್ನ ಡೇಟಾ", "ಗೌಪ್ಯತೆ", "ನನ್ನ ಸಂಭಾಷಣೆ",
        ],
        "en": (
            "Here is exactly what happens, so you can decide what to type:\n"
            "- Every message and reply is saved in a database file on the "
            "server that runs this app. There are no user accounts and no "
            "login, so anyone who can reach that server can read every "
            "conversation, including yours.\n"
            "- When you speak, your browser sends the audio to its own vendor "
            "(Google, for Chrome) to turn into text. That is the browser's "
            "service, not this app's.\n"
            "- Weather questions send the place name to Open-Meteo. Mandi "
            "questions send the crop name to data.gov.in.\n"
            "Please do not type Aadhaar numbers, bank account or card numbers, "
            "OTPs or passwords here. Nothing in this app needs them, and I will "
            "never ask you for them."
        ),
        "ta": (
            "என்ன நடக்கிறது என்பதை அப்படியே சொல்கிறேன், நீங்கள் முடிவு செய்யலாம்:\n"
            "- ஒவ்வொரு செய்தியும் பதிலும் இந்தச் செயலியை இயக்கும் சேவையகத்தில் உள்ள "
            "தரவுத்தள கோப்பில் சேமிக்கப்படுகிறது. பயனர் கணக்குகளோ உள்நுழைவோ இல்லை, "
            "எனவே அந்தச் சேவையகத்தை அணுகக்கூடிய யாரும் உங்களுடையது உட்பட எல்லா "
            "உரையாடல்களையும் படிக்க முடியும்.\n"
            "- நீங்கள் பேசும்போது, உங்கள் உலாவி ஒலியை எழுத்தாக மாற்ற அதன் சொந்த "
            "நிறுவனத்திற்கு (Chrome என்றால் Google) அனுப்புகிறது. அது உலாவியின் சேவை, "
            "இந்தச் செயலியுடையது அல்ல.\n"
            "- வானிலைக் கேள்விகள் ஊரின் பெயரை Open-Meteo-விற்கும், மண்டி கேள்விகள் "
            "பயிரின் பெயரை data.gov.in-க்கும் அனுப்புகின்றன.\n"
            "ஆதார் எண், வங்கிக் கணக்கு அல்லது அட்டை எண், OTP, கடவுச்சொல் — இவற்றை "
            "இங்கே தட்டச்சு செய்யாதீர்கள். இந்தச் செயலிக்கு அவை எதுவும் தேவையில்லை, "
            "நான் ஒருபோதும் கேட்கவும் மாட்டேன்."
        ),
        "hi": (  # NEEDS REVIEW
            "ठीक-ठीक यही होता है, ताकि आप तय कर सकें कि क्या लिखना है:\n"
            "- हर संदेश और उत्तर उस सर्वर की डेटाबेस फ़ाइल में सहेजा जाता है जिस पर यह ऐप "
            "चलता है। कोई उपयोगकर्ता खाता या लॉगिन नहीं है, इसलिए जो भी उस सर्वर तक "
            "पहुँच सकता है, वह आपकी सहित सभी बातचीत पढ़ सकता है।\n"
            "- जब आप बोलते हैं, आपका ब्राउज़र ऑडियो को टेक्स्ट में बदलने के लिए अपनी ही "
            "कंपनी (Chrome के लिए Google) को भेजता है। वह ब्राउज़र की सेवा है, इस ऐप की "
            "नहीं।\n"
            "- मौसम के सवाल जगह का नाम Open-Meteo को भेजते हैं; मंडी के सवाल फ़सल का नाम "
            "data.gov.in को।\n"
            "कृपया आधार नंबर, बैंक खाता या कार्ड नंबर, OTP या पासवर्ड यहाँ न लिखें। इस ऐप "
            "को इनमें से कुछ नहीं चाहिए, और मैं कभी माँगूँगा भी नहीं।"
        ),
        "te": (  # NEEDS REVIEW
            "సరిగ్గా ఏమి జరుగుతుందో ఇదే, మీరు ఏమి టైప్ చేయాలో నిర్ణయించుకోవచ్చు:\n"
            "- ప్రతి సందేశం మరియు సమాధానం ఈ యాప్ నడిచే సర్వర్‌లోని డేటాబేస్ ఫైల్‌లో "
            "సేవ్ అవుతుంది. వినియోగదారు ఖాతాలు, లాగిన్ లేవు, కాబట్టి ఆ సర్వర్‌ను "
            "చేరుకోగలిగిన ఎవరైనా మీదితో సహా అన్ని సంభాషణలను చదవగలరు.\n"
            "- మీరు మాట్లాడినప్పుడు, మీ బ్రౌజర్ ఆడియోను టెక్స్ట్‌గా మార్చడానికి తన "
            "సొంత సంస్థకు (Chrome అయితే Google) పంపుతుంది. అది బ్రౌజర్ సేవ, ఈ యాప్‌ది "
            "కాదు.\n"
            "- వాతావరణ ప్రశ్నలు ప్రాంతం పేరును Open-Meteo కు, మండీ ప్రశ్నలు పంట పేరును "
            "data.gov.in కు పంపుతాయి.\n"
            "దయచేసి ఆధార్ నంబర్, బ్యాంకు ఖాతా లేదా కార్డు నంబర్, OTP లేదా పాస్‌వర్డ్ "
            "ఇక్కడ టైప్ చేయవద్దు. ఈ యాప్‌కు అవి ఏవీ అవసరం లేదు, నేను ఎప్పుడూ అడగను."
        ),
        "kn": (  # NEEDS REVIEW
            "ನಿಖರವಾಗಿ ಏನಾಗುತ್ತದೆ ಎಂಬುದು ಇದು, ನೀವು ಏನು ಟೈಪ್ ಮಾಡಬೇಕೆಂದು "
            "ನಿರ್ಧರಿಸಬಹುದು:\n"
            "- ಪ್ರತಿ ಸಂದೇಶ ಮತ್ತು ಉತ್ತರವೂ ಈ ಆ್ಯಪ್ ಚಲಿಸುವ ಸರ್ವರ್‌ನ ಡೇಟಾಬೇಸ್ ಕಡತದಲ್ಲಿ "
            "ಉಳಿಯುತ್ತದೆ. ಬಳಕೆದಾರ ಖಾತೆಗಳಾಗಲಿ ಲಾಗಿನ್ ಆಗಲಿ ಇಲ್ಲ, ಆದ್ದರಿಂದ ಆ ಸರ್ವರ್ "
            "ತಲುಪಬಲ್ಲ ಯಾರಾದರೂ ನಿಮ್ಮದೂ ಸೇರಿ ಎಲ್ಲ ಸಂಭಾಷಣೆಗಳನ್ನು ಓದಬಹುದು.\n"
            "- ನೀವು ಮಾತನಾಡಿದಾಗ, ನಿಮ್ಮ ಬ್ರೌಸರ್ ಆಡಿಯೊವನ್ನು ಪಠ್ಯವಾಗಿಸಲು ತನ್ನದೇ ಕಂಪನಿಗೆ "
            "(Chrome ಆದರೆ Google) ಕಳುಹಿಸುತ್ತದೆ. ಅದು ಬ್ರೌಸರ್‌ನ ಸೇವೆ, ಈ ಆ್ಯಪ್‌ನದ್ದಲ್ಲ.\n"
            "- ಹವಾಮಾನ ಪ್ರಶ್ನೆಗಳು ಸ್ಥಳದ ಹೆಸರನ್ನು Open-Meteo ಗೆ, ಮಾರುಕಟ್ಟೆ ಪ್ರಶ್ನೆಗಳು "
            "ಬೆಳೆಯ ಹೆಸರನ್ನು data.gov.in ಗೆ ಕಳುಹಿಸುತ್ತವೆ.\n"
            "ದಯವಿಟ್ಟು ಆಧಾರ್ ಸಂಖ್ಯೆ, ಬ್ಯಾಂಕ್ ಖಾತೆ ಅಥವಾ ಕಾರ್ಡ್ ಸಂಖ್ಯೆ, OTP ಅಥವಾ "
            "ಪಾಸ್‌ವರ್ಡ್ ಇಲ್ಲಿ ಟೈಪ್ ಮಾಡಬೇಡಿ. ಈ ಆ್ಯಪ್‌ಗೆ ಅವು ಯಾವುವೂ ಬೇಕಿಲ್ಲ, ನಾನು "
            "ಎಂದಿಗೂ ಕೇಳುವುದಿಲ್ಲ."
        ),
    },
    # ------------------------------------------------------------------
    "data_sources": {
        "keywords": [
            "where do you get", "where does the information come from",
            "where does your information", "your sources", "how do you know",
            "information come from", "where is this information from",
            "எங்கிருந்து தகவல்", "உங்கள் ஆதாரம்", "தகவல் எங்கிருந்து",
            "जानकारी कहाँ से", "आपका स्रोत", "सूचना कहाँ से",
            "సమాచారం ఎక్కడి నుండి", "మీ ఆధారం",
            "ಮಾಹಿತಿ ಎಲ್ಲಿಂದ", "ನಿಮ್ಮ ಆಧಾರ",
        ],
        "en": (
            "### Where each kind of answer comes from\n"
            "- Weather: Open-Meteo, a free live API. Every reading shows the "
            "time it was taken.\n"
            "- Mandi prices: AGMARKNET, published through data.gov.in. Needs a "
            "free key; without one I say prices are switched off rather than "
            "invent them.\n"
            "- Schemes, jobs and hospitals: these have no free public API, so I "
            "link you to myScheme, the National Career Service and the Health "
            "Facility Registry rather than searching them myself.\n"
            "- Documents, scholarships, banking, scams and travel: short "
            "curated summaries written by hand, each citing the official portal "
            "to confirm on. They deliberately contain no rupee amounts, no "
            "percentages and no eligibility rules, because those are exactly "
            "the details that go stale.\n"
            "- Health: no medical advice at all. Only helpline numbers and "
            "links to official health portals.\n"
            "Nothing here is scraped, and no answer is generated by a language "
            "model making something up."
        ),
        "ta": (
            "### எந்த வகைப் பதில் எங்கிருந்து வருகிறது\n"
            "- வானிலை: Open-Meteo என்ற இலவச நேரடி API. ஒவ்வொரு அளவீடும் எப்போது "
            "எடுக்கப்பட்டது என்பதைக் காட்டும்.\n"
            "- மண்டி விலைகள்: data.gov.in வழியாக வெளியிடப்படும் AGMARKNET. இலவச சாவி "
            "தேவை; இல்லாதபோது விலைகளை உருவாக்காமல், அவை இயக்கப்படவில்லை என்றே "
            "சொல்வேன்.\n"
            "- திட்டங்கள், வேலைகள், மருத்துவமனைகள்: இவற்றுக்கு இலவச பொது API இல்லை, "
            "எனவே நானே தேடாமல் myScheme, National Career Service, Health Facility "
            "Registry தளங்களுக்கு இணைப்பு தருவேன்.\n"
            "- ஆவணங்கள், உதவித்தொகை, வங்கி, மோசடி, பயணம்: கையால் எழுதப்பட்ட சுருக்கமான "
            "தொகுப்புகள், ஒவ்வொன்றும் சரிபார்க்க வேண்டிய அதிகாரப்பூர்வ தளத்தைக் "
            "குறிப்பிடும். அவற்றில் ரூபாய் தொகைகள், சதவீதங்கள், தகுதி விதிகள் "
            "வேண்டுமென்றே இல்லை — அவைதான் விரைவில் பழையதாகிவிடும் விவரங்கள்.\n"
            "- உடல்நலம்: மருத்துவ ஆலோசனை எதுவும் இல்லை. உதவி எண்களும் அதிகாரப்பூர்வ "
            "சுகாதாரத் தளங்களுக்கான இணைப்புகளும் மட்டுமே.\n"
            "இங்கு எதுவும் திருடி எடுக்கப்படவில்லை, எந்தப் பதிலும் மொழி மாதிரி ஒன்று "
            "கற்பனையாக உருவாக்கியது அல்ல."
        ),
        "hi": (  # NEEDS REVIEW
            "### किस तरह का उत्तर कहाँ से आता है\n"
            "- मौसम: Open-Meteo, एक मुफ़्त लाइव API। हर माप के साथ उसका समय दिखता है।\n"
            "- मंडी भाव: AGMARKNET, data.gov.in के ज़रिए। इसके लिए मुफ़्त कुंजी चाहिए; न "
            "हो तो मैं भाव गढ़ने के बजाय कह देता हूँ कि यह सुविधा चालू नहीं है।\n"
            "- योजनाएँ, नौकरियाँ और अस्पताल: इनका कोई मुफ़्त सार्वजनिक API नहीं है, "
            "इसलिए मैं ख़ुद खोजने के बजाय myScheme, National Career Service और Health "
            "Facility Registry के लिंक देता हूँ।\n"
            "- दस्तावेज़, छात्रवृत्ति, बैंकिंग, ठगी और यात्रा: हाथ से लिखे छोटे सारांश, "
            "हर एक के साथ जाँचने योग्य आधिकारिक पोर्टल। इनमें जान-बूझकर कोई रुपया राशि, "
            "प्रतिशत या पात्रता नियम नहीं हैं, क्योंकि यही ब्योरे सबसे जल्दी पुराने पड़ते "
            "हैं।\n"
            "- स्वास्थ्य: कोई चिकित्सा सलाह नहीं। केवल हेल्पलाइन नंबर और आधिकारिक "
            "स्वास्थ्य पोर्टल के लिंक।\n"
            "यहाँ कुछ भी स्क्रैप नहीं किया गया, और कोई उत्तर किसी भाषा मॉडल की गढ़ी हुई "
            "बात नहीं है।"
        ),
        "te": (  # NEEDS REVIEW
            "### ఏ రకమైన సమాధానం ఎక్కడి నుండి వస్తుంది\n"
            "- వాతావరణం: Open-Meteo అనే ఉచిత ప్రత్యక్ష API. ప్రతి కొలతతో పాటు అది "
            "తీసుకున్న సమయం కనిపిస్తుంది.\n"
            "- మండీ ధరలు: data.gov.in ద్వారా ప్రచురించే AGMARKNET. ఉచిత కీ అవసరం; "
            "లేకపోతే ధరలు కల్పించకుండా, ఈ సదుపాయం ఆన్‌లో లేదని చెబుతాను.\n"
            "- పథకాలు, ఉద్యోగాలు, ఆసుపత్రులు: వీటికి ఉచిత పబ్లిక్ API లేదు, కాబట్టి "
            "నేనే వెతకకుండా myScheme, National Career Service, Health Facility "
            "Registry లింకులు ఇస్తాను.\n"
            "- పత్రాలు, ఉపకార వేతనం, బ్యాంకింగ్, మోసాలు, ప్రయాణం: చేతితో రాసిన చిన్న "
            "సారాంశాలు, ప్రతి దానితో నిర్ధారించుకోవాల్సిన అధికారిక పోర్టల్. వాటిలో "
            "ఉద్దేశపూర్వకంగా రూపాయి మొత్తాలు, శాతాలు, అర్హత నియమాలు లేవు — అవే త్వరగా "
            "పాతబడే వివరాలు.\n"
            "- ఆరోగ్యం: వైద్య సలహా అస్సలు లేదు. హెల్ప్‌లైన్ నంబర్లు, అధికారిక ఆరోగ్య "
            "పోర్టల్ లింకులు మాత్రమే.\n"
            "ఇక్కడ ఏదీ స్క్రాప్ చేయలేదు, ఏ సమాధానమూ భాషా మోడల్ కల్పించినది కాదు."
        ),
        "kn": (  # NEEDS REVIEW
            "### ಯಾವ ಬಗೆಯ ಉತ್ತರ ಎಲ್ಲಿಂದ ಬರುತ್ತದೆ\n"
            "- ಹವಾಮಾನ: Open-Meteo ಎಂಬ ಉಚಿತ ನೇರ API. ಪ್ರತಿ ಅಳತೆಯೊಂದಿಗೆ ಅದನ್ನು ತೆಗೆದ "
            "ಸಮಯ ಕಾಣುತ್ತದೆ.\n"
            "- ಮಾರುಕಟ್ಟೆ ದರಗಳು: data.gov.in ಮೂಲಕ ಪ್ರಕಟವಾಗುವ AGMARKNET. ಉಚಿತ ಕೀ ಬೇಕು; "
            "ಇಲ್ಲದಿದ್ದರೆ ದರಗಳನ್ನು ಸೃಷ್ಟಿಸದೆ, ಈ ಸೌಲಭ್ಯ ಆನ್ ಆಗಿಲ್ಲ ಎಂದು ಹೇಳುತ್ತೇನೆ.\n"
            "- ಯೋಜನೆಗಳು, ಉದ್ಯೋಗಗಳು, ಆಸ್ಪತ್ರೆಗಳು: ಇವಕ್ಕೆ ಉಚಿತ ಸಾರ್ವಜನಿಕ API ಇಲ್ಲ, "
            "ಆದ್ದರಿಂದ ನಾನೇ ಹುಡುಕದೆ myScheme, National Career Service ಮತ್ತು Health "
            "Facility Registry ಕೊಂಡಿಗಳನ್ನು ಕೊಡುತ್ತೇನೆ.\n"
            "- ದಾಖಲೆಗಳು, ವಿದ್ಯಾರ್ಥಿವೇತನ, ಬ್ಯಾಂಕಿಂಗ್, ವಂಚನೆ, ಪ್ರಯಾಣ: ಕೈಯಿಂದ ಬರೆದ "
            "ಸಣ್ಣ ಸಾರಾಂಶಗಳು, ಪ್ರತಿಯೊಂದರ ಜೊತೆ ಪರಿಶೀಲಿಸಬೇಕಾದ ಅಧಿಕೃತ ಪೋರ್ಟಲ್. ಅವುಗಳಲ್ಲಿ "
            "ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ರೂಪಾಯಿ ಮೊತ್ತ, ಶೇಕಡಾವಾರು, ಅರ್ಹತಾ ನಿಯಮಗಳು ಇಲ್ಲ — ಅವೇ "
            "ಬೇಗ ಹಳತಾಗುವ ವಿವರಗಳು.\n"
            "- ಆರೋಗ್ಯ: ವೈದ್ಯಕೀಯ ಸಲಹೆ ಸಂಪೂರ್ಣ ಇಲ್ಲ. ಸಹಾಯವಾಣಿ ಸಂಖ್ಯೆಗಳು ಮತ್ತು ಅಧಿಕೃತ "
            "ಆರೋಗ್ಯ ಪೋರ್ಟಲ್ ಕೊಂಡಿಗಳು ಮಾತ್ರ.\n"
            "ಇಲ್ಲಿ ಯಾವುದನ್ನೂ ಸ್ಕ್ರೇಪ್ ಮಾಡಿಲ್ಲ, ಯಾವ ಉತ್ತರವೂ ಭಾಷಾ ಮಾದರಿ ಕಲ್ಪಿಸಿದ್ದಲ್ಲ."
        ),
    },
    # ------------------------------------------------------------------
    "not_understood": {
        "keywords": [
            "you don't understand", "you didn't understand",
            "if you don't understand", "not understanding me",
            "doesn't understand me", "didn't get what i said",
            "you are not understanding",
            "புரியவில்லை என்றால்", "நீ புரிந்துகொள்ளவில்லை",
            "समझ नहीं आ", "अगर समझ न", "समझ नहीं पा",
            "అర్థం కాకపోతే", "మీకు అర్థం కాలేదు",
            "ಅರ್ಥವಾಗದಿದ್ದರೆ", "ನಿಮಗೆ ಅರ್ಥವಾಗಲಿಲ್ಲ",
        ],
        "en": (
            "When I don't understand, I say so rather than guessing — so a "
            "vague reply means the question genuinely didn't land. Things that "
            "usually fix it:\n"
            "1. Pick your language from the button at the top before speaking. "
            "The browser has to be told one language before it starts "
            "listening; it cannot detect it.\n"
            "2. Type it instead. Typed text is identified by script and is much "
            "more reliable than speech.\n"
            "3. Name the place or the thing. \"Weather in Madurai\" works; "
            "\"the weather\" makes me ask which place, on purpose.\n"
            "4. Ask one thing at a time, in short words.\n"
            "If it still fails, that is a real gap and not your fault — this "
            "understands a fixed list of topics, not everything."
        ),
        "ta": (
            "புரியாதபோது ஊகிக்காமல், புரியவில்லை என்றே சொல்வேன் — எனவே தெளிவற்ற பதில் "
            "வந்தால் கேள்வி உண்மையிலேயே சேரவில்லை என்று அர்த்தம். வழக்கமாக "
            "சரிசெய்வது:\n"
            "1. பேசுவதற்கு முன் மேலே உள்ள பொத்தானில் உங்கள் மொழியைத் தேர்ந்தெடுங்கள். "
            "கேட்கத் தொடங்கும் முன் உலாவிக்கு ஒரு மொழி சொல்லப்பட வேண்டும்; அதனால் "
            "தானாகக் கண்டறிய முடியாது.\n"
            "2. தட்டச்சு செய்து பாருங்கள். தட்டச்சு செய்த உரை எழுத்துருவால் "
            "கண்டறியப்படுகிறது, பேச்சை விட மிகவும் நம்பகமானது.\n"
            "3. ஊரையோ பொருளையோ பெயர் சொல்லுங்கள். \"மதுரை வானிலை\" வேலை செய்யும்; "
            "\"வானிலை\" என்றால் எந்த ஊர் என்று வேண்டுமென்றே திரும்பக் கேட்பேன்.\n"
            "4. ஒரு நேரத்தில் ஒரு விஷயம், சுருக்கமான சொற்களில்.\n"
            "அப்படியும் தோற்றால் அது உண்மையான குறை, உங்கள் தவறு அல்ல — இது ஒரு நிலையான "
            "பட்டியல் தலைப்புகளை மட்டுமே புரிந்துகொள்ளும், எல்லாவற்றையும் அல்ல."
        ),
        "hi": (  # NEEDS REVIEW
            "जब मुझे समझ नहीं आता, तो मैं अंदाज़ा लगाने के बजाय साफ़ कह देता हूँ — यानी "
            "गोल-मोल उत्तर का मतलब है कि सवाल सचमुच नहीं पहुँचा। आमतौर पर ये काम आते "
            "हैं:\n"
            "1. बोलने से पहले ऊपर के बटन से अपनी भाषा चुनें। सुनना शुरू करने से पहले "
            "ब्राउज़र को एक भाषा बतानी पड़ती है; वह ख़ुद नहीं पहचान सकता।\n"
            "2. लिखकर पूछें। लिखा हुआ पाठ लिपि से पहचाना जाता है और बोली से कहीं "
            "ज़्यादा भरोसेमंद है।\n"
            "3. जगह या चीज़ का नाम लें। \"मदुरै का मौसम\" चलेगा; सिर्फ़ \"मौसम\" पर मैं "
            "जान-बूझकर पूछूँगा कि कौन सी जगह।\n"
            "4. एक बार में एक ही बात, छोटे शब्दों में।\n"
            "फिर भी न हो तो यह असली कमी है, आपकी ग़लती नहीं — यह विषयों की एक तय सूची "
            "समझता है, सब कुछ नहीं।"
        ),
        "te": (  # NEEDS REVIEW
            "అర్థం కానప్పుడు ఊహించకుండా, అర్థం కాలేదని చెబుతాను — కాబట్టి అస్పష్టమైన "
            "సమాధానం అంటే ప్రశ్న నిజంగా చేరలేదని అర్థం. సాధారణంగా పనిచేసేవి:\n"
            "1. మాట్లాడే ముందు పైన ఉన్న బటన్‌తో మీ భాషను ఎంచుకోండి. వినడం "
            "మొదలుపెట్టే ముందు బ్రౌజర్‌కు ఒక భాష చెప్పాలి; అది దానంతట గుర్తించలేదు.\n"
            "2. టైప్ చేసి అడగండి. టైప్ చేసిన పాఠ్యం లిపి ద్వారా గుర్తించబడుతుంది, మాట "
            "కంటే చాలా నమ్మదగినది.\n"
            "3. ప్రాంతం లేదా వస్తువు పేరు చెప్పండి. \"మదురై వాతావరణం\" పనిచేస్తుంది; "
            "కేవలం \"వాతావరణం\" అంటే ఏ ప్రాంతమని ఉద్దేశపూర్వకంగా తిరిగి అడుగుతాను.\n"
            "4. ఒకసారి ఒకే విషయం, చిన్న మాటల్లో.\n"
            "అప్పటికీ కాకపోతే అది నిజమైన లోపం, మీ తప్పు కాదు — ఇది నిర్ణీత అంశాల "
            "జాబితానే అర్థం చేసుకుంటుంది, అన్నింటినీ కాదు."
        ),
        "kn": (  # NEEDS REVIEW
            "ಅರ್ಥವಾಗದಿದ್ದಾಗ ಊಹಿಸದೆ, ಅರ್ಥವಾಗಲಿಲ್ಲ ಎಂದೇ ಹೇಳುತ್ತೇನೆ — ಅಂದರೆ ಅಸ್ಪಷ್ಟ ಉತ್ತರ "
            "ಬಂದರೆ ಪ್ರಶ್ನೆ ನಿಜವಾಗಿಯೂ ತಲುಪಿಲ್ಲ ಎಂದರ್ಥ. ಸಾಮಾನ್ಯವಾಗಿ ಸರಿಪಡಿಸುವವು:\n"
            "1. ಮಾತನಾಡುವ ಮೊದಲು ಮೇಲಿನ ಗುಂಡಿಯಿಂದ ನಿಮ್ಮ ಭಾಷೆ ಆಯ್ಕೆಮಾಡಿ. ಕೇಳಲು "
            "ಆರಂಭಿಸುವ ಮೊದಲು ಬ್ರೌಸರ್‌ಗೆ ಒಂದು ಭಾಷೆ ಹೇಳಬೇಕು; ಅದು ತಾನಾಗಿ "
            "ಗುರುತಿಸಲಾರದು.\n"
            "2. ಟೈಪ್ ಮಾಡಿ ಕೇಳಿ. ಟೈಪ್ ಮಾಡಿದ ಪಠ್ಯ ಲಿಪಿಯಿಂದ ಗುರುತಿಸಲ್ಪಡುತ್ತದೆ, ಮಾತಿಗಿಂತ "
            "ಬಹಳ ವಿಶ್ವಾಸಾರ್ಹ.\n"
            "3. ಸ್ಥಳ ಅಥವಾ ವಸ್ತುವಿನ ಹೆಸರು ಹೇಳಿ. \"ಮಧುರೈ ಹವಾಮಾನ\" ಕೆಲಸ ಮಾಡುತ್ತದೆ; "
            "ಕೇವಲ \"ಹವಾಮಾನ\" ಎಂದರೆ ಯಾವ ಸ್ಥಳ ಎಂದು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ ಮರಳಿ ಕೇಳುತ್ತೇನೆ.\n"
            "4. ಒಮ್ಮೆಗೆ ಒಂದೇ ವಿಷಯ, ಚಿಕ್ಕ ಪದಗಳಲ್ಲಿ.\n"
            "ಆಗಲೂ ಆಗದಿದ್ದರೆ ಅದು ನಿಜವಾದ ಕೊರತೆ, ನಿಮ್ಮ ತಪ್ಪಲ್ಲ — ಇದು ನಿಗದಿತ ವಿಷಯಗಳ "
            "ಪಟ್ಟಿಯನ್ನಷ್ಟೇ ಅರ್ಥಮಾಡಿಕೊಳ್ಳುತ್ತದೆ, ಎಲ್ಲವನ್ನೂ ಅಲ್ಲ."
        ),
    },
    # ------------------------------------------------------------------
    "emergency_capability": {
        # NOTE: most phrasings of this question contain the word "emergency"
        # or "ambulance", and `intent_detection` routes those straight to the
        # real helpline list before anything else runs. That is left alone
        # deliberately — someone who types "emergency" should get numbers,
        # not an essay. This entry covers the phrasings that don't trip that
        # rule, and backs the /api/about listing.
        "keywords": [
            "can you call", "can you call an ambulance", "do you call for help",
            "can you contact the police", "will you call",
            "நீங்கள் அழைக்க முடியுமா", "நீ போன் செய்வாயா",
            "क्या आप कॉल कर", "क्या आप फ़ोन कर",
            "మీరు కాల్ చేయగలరా", "మీరు ఫోన్ చేస్తారా",
            "ನೀವು ಕರೆ ಮಾಡಬಹುದೇ", "ನೀವು ಫೋನ್ ಮಾಡುವಿರಾ",
        ],
        "en": (
            "I cannot call anyone for you, and I cannot send help. There is no "
            "connection between this app and any emergency service.\n"
            "What I can do is show you the right number as a row you can tap to "
            "dial — 112 for any emergency, 108 for an ambulance, 1930 for "
            "financial fraud, 1098 for a child in danger, and the rest of the "
            "national helplines. Say or type \"emergency numbers\" to see the "
            "full list in your language.\n"
            "In a real emergency, dial 112 directly rather than going through "
            "this app."
        ),
        "ta": (
            "உங்களுக்காக நான் யாரையும் அழைக்க முடியாது, உதவியை அனுப்பவும் முடியாது. "
            "இந்தச் செயலிக்கும் எந்த அவசர சேவைக்கும் தொடர்பே இல்லை.\n"
            "நான் செய்யக்கூடியது — சரியான எண்ணை நீங்கள் தட்டி அழைக்கும் வரிசையாகக் "
            "காட்டுவது: எந்த அவசரத்துக்கும் 112, ஆம்புலன்ஸுக்கு 108, நிதி மோசடிக்கு "
            "1930, ஆபத்தில் உள்ள குழந்தைக்கு 1098, மற்ற தேசிய உதவி எண்களும். முழு "
            "பட்டியலை உங்கள் மொழியில் பார்க்க \"அவசர எண்கள்\" என்று சொல்லுங்கள் அல்லது "
            "தட்டச்சு செய்யுங்கள்.\n"
            "உண்மையான அவசரத்தில் இந்தச் செயலி வழியாகச் செல்லாமல் நேரடியாக 112-ஐ "
            "அழையுங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "मैं आपके लिए किसी को कॉल नहीं कर सकता, न ही मदद भेज सकता हूँ। इस ऐप का किसी "
            "आपातकालीन सेवा से कोई जुड़ाव नहीं है।\n"
            "मैं इतना कर सकता हूँ कि सही नंबर ऐसी पंक्ति में दिखा दूँ जिसे दबाकर आप कॉल "
            "कर सकें — किसी भी आपात स्थिति के लिए 112, एम्बुलेंस के लिए 108, वित्तीय ठगी "
            "के लिए 1930, ख़तरे में बच्चे के लिए 1098, और बाक़ी राष्ट्रीय हेल्पलाइन। पूरी "
            "सूची अपनी भाषा में देखने के लिए \"आपातकालीन नंबर\" कहें या लिखें।\n"
            "असली आपात स्थिति में इस ऐप के रास्ते जाने के बजाय सीधे 112 डायल करें।"
        ),
        "te": (  # NEEDS REVIEW
            "నేను మీ కోసం ఎవరికీ కాల్ చేయలేను, సహాయాన్ని పంపలేను. ఈ యాప్‌కు ఏ అత్యవసర "
            "సేవతోనూ సంబంధం లేదు.\n"
            "నేను చేయగలిగేది — సరైన నంబర్‌ను మీరు నొక్కి కాల్ చేసే వరుసగా చూపడం: ఏ "
            "అత్యవసరానికైనా 112, అంబులెన్స్‌కు 108, ఆర్థిక మోసానికి 1930, ప్రమాదంలో "
            "ఉన్న పిల్లలకు 1098, మిగతా జాతీయ హెల్ప్‌లైన్లు. పూర్తి జాబితాను మీ భాషలో "
            "చూడటానికి \"అత్యవసర నంబర్లు\" అని చెప్పండి లేదా టైప్ చేయండి.\n"
            "నిజమైన అత్యవసర పరిస్థితిలో ఈ యాప్ ద్వారా కాకుండా నేరుగా 112 డయల్ చేయండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ನಾನು ನಿಮಗಾಗಿ ಯಾರಿಗೂ ಕರೆ ಮಾಡಲಾರೆ, ಸಹಾಯವನ್ನೂ ಕಳುಹಿಸಲಾರೆ. ಈ ಆ್ಯಪ್‌ಗೆ ಯಾವ "
            "ತುರ್ತು ಸೇವೆಯೊಂದಿಗೂ ಸಂಪರ್ಕವಿಲ್ಲ.\n"
            "ನಾನು ಮಾಡಬಹುದಾದದ್ದು — ಸರಿಯಾದ ಸಂಖ್ಯೆಯನ್ನು ನೀವು ಒತ್ತಿ ಕರೆ ಮಾಡುವ ಸಾಲಾಗಿ "
            "ತೋರಿಸುವುದು: ಯಾವುದೇ ತುರ್ತಿಗೆ 112, ಆಂಬ್ಯುಲೆನ್ಸ್‌ಗೆ 108, ಹಣಕಾಸು ವಂಚನೆಗೆ "
            "1930, ಅಪಾಯದಲ್ಲಿರುವ ಮಗುವಿಗೆ 1098, ಮತ್ತು ಉಳಿದ ರಾಷ್ಟ್ರೀಯ ಸಹಾಯವಾಣಿಗಳು. ಪೂರ್ಣ "
            "ಪಟ್ಟಿಯನ್ನು ನಿಮ್ಮ ಭಾಷೆಯಲ್ಲಿ ನೋಡಲು \"ತುರ್ತು ಸಂಖ್ಯೆಗಳು\" ಎಂದು ಹೇಳಿ ಅಥವಾ ಟೈಪ್ "
            "ಮಾಡಿ.\n"
            "ನಿಜವಾದ ತುರ್ತಿನಲ್ಲಿ ಈ ಆ್ಯಪ್ ಮೂಲಕ ಹೋಗದೆ ನೇರವಾಗಿ 112 ಡಯಲ್ ಮಾಡಿ."
        ),
    },
}


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AboutMatch:
    key: str
    text: Dict[str, str]

    def body(self, language: str) -> str:
        base = (language or "en").split("-", 1)[0]
        return self.text.get(base) or self.text["en"]


def _keyword_pattern(keyword: str) -> "re.Pattern":
    """
    Same rule as `knowledge._keyword_pattern`, for the same reason: Python's
    `\\b` is defined via `\\w`, which excludes the combining marks Indic
    words end in, so a non-ASCII pattern with `\\b` would never match.
    """
    escaped = re.escape(keyword)
    return re.compile(rf"\b{escaped}\b" if keyword.isascii() else escaped)


# Longest phrase first. These keywords are mostly multi-word phrases rather
# than single nouns, and that is what keeps this table from hijacking
# ordinary questions: "where do you get" appears in "where do you get
# weather information from" and not in "what is the weather in Madurai".
_COMPILED: List[tuple] = sorted(
    (
        (len(keyword), key, _keyword_pattern(keyword))
        for key, entry in _ABOUT.items()
        for keyword in entry["keywords"]
    ),
    key=lambda row: -row[0],
)


def match_about(text: str) -> Optional[AboutMatch]:
    """Find the app-FAQ entry a question is about, or None."""
    if not text:
        return None
    lowered = text.lower()
    for _, key, pattern in _COMPILED:
        if pattern.search(lowered) or pattern.search(text):
            entry = _ABOUT[key]
            return AboutMatch(
                key=key,
                text={lang: value for lang, value in entry.items() if lang != "keywords"},
            )
    return None


def format_about_reply(match: AboutMatch, language: str) -> str:
    """
    The body in the user's language, with the language matrix substituted.

    No "confirm on the official portal" note here, unlike `knowledge`:
    there is no external portal to confirm against. This app is the source
    for statements about this app.
    """
    return match.body(language).format(
        languages=_language_list(),
        unreviewed=_unreviewed_names(),
    )


def entry_keys() -> tuple:
    return tuple(_ABOUT.keys())


def entries() -> Dict[str, dict]:
    """Read-only-ish view of the raw table, for tests and /api/about."""
    return _ABOUT
