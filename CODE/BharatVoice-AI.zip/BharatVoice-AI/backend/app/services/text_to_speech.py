"""
Text-to-Speech Service
=========================
Synthesizes speech audio from assistant reply text, when — and only when —
the user's device cannot do it itself.

THE CHAIN, in order of preference:

  1. The browser's own `speechSynthesis`, handled entirely in the frontend
     (`frontend/src/hooks/useSpeechSynthesis.js`). Instant, free, offline,
     and the right answer whenever the device has a voice for the language.
     Nothing in this module runs in that case.
  2. Bhashini (`tts_bhashini.py`) — covers en, hi, ta, te, kn. Needs ULCA
     credentials. This is the only provider here that can speak Tamil,
     Telugu or Kannada.
  3. Coqui XTTS-v2, if the (large, GPU-hungry) package is installed. Kept
     because it works offline once downloaded, but see the language note
     below: for this project's purposes it covers English and Hindi only.
  4. Nothing. `audio_url=None`, and the frontend says plainly that the
     reply cannot be read aloud on this device while keeping the text
     visible. That sentence is the feature, not the failure.

WHY THE ORDER PUTS BHASHINI FIRST: it is the only one whose language
coverage matches what this app claims to support. XTTS-v2's language set
has Hindi but no Tamil, Telugu or Kannada, so promoting it would mean the
three languages most likely to need a server voice are the three it cannot
provide.

THE RULE THAT OVERRIDES ALL OF IT: never synthesize a reply in a language
other than the one it was written in. A Tamil answer read by a Hindi voice
is not a degraded success, it is a silent wrong answer — the user cannot
hear that a substitution happened. Every provider gate below is a language
check first and a capability check second.
"""
import logging
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from app.config import settings
from app.services import tts_bhashini
from app.services.device import resolve_device

logger = logging.getLogger(__name__)

try:
    from TTS.api import TTS  # coqui-tts
    _HAS_COQUI = True
except ImportError:
    _HAS_COQUI = False

_tts_model = None  # lazy-loaded singleton

# XTTS-v2's own language set. Tamil, Telugu and Kannada are absent — that
# is a fact about the checkpoint, not an oversight here, and it is why
# Bhashini exists in this chain. An earlier version of this file
# substituted "the closest supported language" for Tamil; that produced a
# Tamil answer spoken in English phonetics, which is unintelligible and
# indistinguishable from a bug. It does not do that any more.
_XTTS_SUPPORTED_LANGS = {
    "en", "es", "fr", "de", "it", "pt", "pl", "tr", "ru", "nl", "cs", "ar",
    "zh-cn", "ja", "hu", "ko", "hi",
}

# The languages this app supports, for the capability report.
_APP_LANGUAGES = ("en", "ta", "hi", "te", "kn")

AUDIO_OUTPUT_DIR = Path(__file__).resolve().parent.parent.parent / "static" / "audio"
AUDIO_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


@dataclass
class SynthesisResult:
    audio_url: Optional[str]
    engine: str


def _base(language: str) -> str:
    """
    The base language subtag.

    Code-mixed input ("ta-en") is spoken by the Indic voice, not the
    English one: it reads the Indic words correctly and the Latin-script
    words passably, where an English voice mangles the Indic words beyond
    recognition.
    """
    return (language or "en").split("-", 1)[0].lower()


def _coqui_available_for(language: str) -> bool:
    return (
        _HAS_COQUI
        and settings.enable_coqui_tts
        and _base(language) in _XTTS_SUPPORTED_LANGS
    )


def synthesize_speech(text: str, language: str = "en") -> SynthesisResult:
    """
    Server-side audio for a reply, or an explicit "nothing available".

    `audio_url=None` with `engine="browser-fallback"` is a normal, expected
    outcome — it means the frontend should use a device voice or explain
    that it cannot. It is not an error and must not be logged as one.
    """
    base = _base(language)

    if tts_bhashini.is_configured() and tts_bhashini.supports(base):
        # `synthesize` is written to return None on every failure it knows
        # about, so this guard is for the ones it doesn't: an unexpected
        # raise anywhere in the provider must degrade to "no audio", not
        # become a 500 on a reply whose text was already generated fine.
        try:
            url = tts_bhashini.synthesize(text, base)
        except Exception:
            logger.warning("Bhashini synthesis raised; falling back", exc_info=True)
            url = None
        if url:
            return SynthesisResult(audio_url=url, engine=tts_bhashini.PROVIDER)
        # Fall through rather than return: Coqui may still cover English or
        # Hindi, and a device voice may still exist. Bhashini has already
        # logged why it failed.

    if _coqui_available_for(base):
        try:
            return _coqui_synthesize(text, base)
        except Exception:
            logger.warning("Coqui synthesis failed; using browser fallback", exc_info=True)

    return SynthesisResult(audio_url=None, engine="browser-fallback")


def capabilities() -> dict:
    """
    What the server can speak, per language, for the frontend to reason
    about *before* it tries.

    This is what lets the UI say "this device has no Tamil voice and the
    server has none either — here is the answer as text" in one breath,
    instead of attempting playback and producing silence.

    `provider` is the engine that would handle each language, or None.
    `configured` distinguishes "no credentials" from "credentials present
    but the service is unreachable" — the first is a setup step the user
    can act on, the second is not.
    """
    languages = {}
    for code in _APP_LANGUAGES:
        if tts_bhashini.is_configured() and tts_bhashini.supports(code):
            provider = tts_bhashini.PROVIDER
        elif _coqui_available_for(code):
            provider = "coqui-tts"
        else:
            provider = None
        languages[code] = provider

    return {
        "languages": languages,
        "bhashini_configured": tts_bhashini.is_configured(),
        "coqui_installed": _HAS_COQUI,
        # True when at least one language can be synthesized server-side.
        # The frontend uses this to decide whether asking is worth a round
        # trip at all.
        "any": any(value is not None for value in languages.values()),
    }


def _coqui_synthesize(text: str, language: str) -> SynthesisResult:  # pragma: no cover
    """Real Coqui TTS inference — used automatically once the package is installed."""
    global _tts_model
    if _tts_model is None:
        _tts_model = TTS(model_name=settings.coqui_tts_model, progress_bar=False)
        if resolve_device() == "cuda":
            _tts_model = _tts_model.to("cuda")

    filename = f"{uuid.uuid4()}.wav"
    output_path = AUDIO_OUTPUT_DIR / filename
    _tts_model.tts_to_file(text=text, language=language, file_path=str(output_path))

    return SynthesisResult(audio_url=f"/static/audio/{filename}", engine="coqui-tts")
