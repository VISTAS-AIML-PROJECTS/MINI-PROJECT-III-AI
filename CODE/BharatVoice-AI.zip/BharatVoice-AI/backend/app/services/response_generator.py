"""
Response Generator
=====================
Given the NLU result (intent + entities + language), executes the
corresponding action and produces a reply in the user's detected language:
Tamil, Hindi, Telugu, Kannada, or English, plus code-mixed Tanglish.

Every branch returns a `DomainAnswer` (see services/answers.py), not a
string. The reason is the `sources` field: this assistant answers questions
about government documents, emergencies and money, where an uncited
authoritative-sounding claim is a liability rather than a feature. Making
citations part of the return type means a reviewer can see, in the diff,
whether a new answer carries provenance.

TRANSLATION STATUS — read before demoing:
  - English, Tamil and Hindi strings are written with reasonable
    confidence.
  - Telugu and Kannada strings are best-effort and have NOT been reviewed
    by a native speaker. They are marked with `# NEEDS REVIEW` where the
    wording is most likely to be clumsy. Get a native speaker to read the
    `te` and `kn` entries before this is shown to real users or submitted
    as "fully supported" for those languages.
  - Missing translations degrade to the base language and then to English
    via `_t()`, so an untranslated string is never a crash — it is a
    silently English reply, which the evaluation harness should flag.
"""
import random
import re
from datetime import datetime
from typing import List, Optional

from zoneinfo import ZoneInfo

from app.services import about, hospitals, imd, knowledge, mandi, skills, weather
from app.services.answers import DomainAnswer, Source, plain, refusal
from app.services.entity_extraction import ExtractedEntity
from app.services.language_detection import base_language

IST = ZoneInfo("Asia/Kolkata")


def _t(table: dict, language: str):
    """
    Pick a language's entry from a translation table.

    Resolution order: exact code ("ta-en") -> base language ("ta") ->
    English. This is what lets a code-mixed utterance reuse the base
    language's templates when no dedicated mixed-register wording exists.
    """
    if language in table:
        return table[language]
    base = base_language(language)
    if base in table:
        return table[base]
    return table["en"]


def _pick(table: dict, language: str) -> str:
    options = _t(table, language)
    return random.choice(options) if isinstance(options, (list, tuple)) else options


_GREETING_REPLIES = {
    "en": ["Hello! How can I help you today?", "Hi there! What can I do for you?"],
    "ta": ["வணக்கம்! நான் உங்களுக்கு எப்படி உதவலாம்?", "வணக்கம்! என்ன வேணும் சொல்லுங்க."],
    "hi": ["नमस्ते! मैं आपकी कैसे मदद कर सकता हूँ?", "नमस्कार! बताइए, क्या चाहिए?"],
    "te": ["నమస్కారం! నేను మీకు ఎలా సహాయం చేయగలను?"],  # NEEDS REVIEW
    "kn": ["ನಮಸ್ಕಾರ! ನಾನು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?"],  # NEEDS REVIEW
    "ta-en": ["Vanakkam! Enna venum sollunga?", "Hi! Epdi help panna mudiyum?"],
}

_GOODBYE_REPLIES = {
    "en": ["Goodbye! Have a great day.", "See you soon!"],
    "ta": ["போய் வருகிறேன்! நல்ல நாள் ஆகட்டும்.", "பிறகு பேசலாம்!"],
    "hi": ["नमस्ते! आपका दिन शुभ हो।", "फिर मिलेंगे!"],
    "te": ["వీడ్కోలు! మీ రోజు శుభంగా ఉండాలి."],  # NEEDS REVIEW
    "kn": ["ನಮಸ್ಕಾರ! ನಿಮ್ಮ ದಿನ ಶುಭವಾಗಿರಲಿ."],  # NEEDS REVIEW
    "ta-en": ["Bye bye! Nalla naa aagattum.", "Pesalam pinnadi!"],
}

_THANKS_REPLIES = {
    "en": ["You're welcome!", "Happy to help!", "Anytime!"],
    "ta": ["பரவாயில்லை!", "சந்தோஷம், உதவ முடிந்ததில்!"],
    "hi": ["कोई बात नहीं!", "मदद कर के खुशी हुई!"],
    "te": ["ఏమీ ఫరవాలేదు!"],  # NEEDS REVIEW
    "kn": ["ಪರವಾಗಿಲ್ಲ!"],  # NEEDS REVIEW
    "ta-en": ["Paravaayilla!", "Santhosham, help panna mudinjadhu!"],
}

_HOW_ARE_YOU_REPLIES = {
    "en": ["I'm doing great, thanks for asking! How can I help you?"],
    "ta": ["நான் நல்லா இருக்கேன், கேட்டதுக்கு நன்றி! உங்களுக்கு என்ன உதவி வேண்டும்?"],
    "hi": ["मैं ठीक हूँ, पूछने के लिए धन्यवाद! आपको क्या मदद चाहिए?"],
    "te": ["నేను బాగున్నాను, అడిగినందుకు ధన్యవాదాలు! మీకు ఏమి సహాయం కావాలి?"],  # NEEDS REVIEW
    "kn": ["ನಾನು ಚೆನ್ನಾಗಿದ್ದೇನೆ, ಕೇಳಿದ್ದಕ್ಕೆ ಧನ್ಯವಾದ! ನಿಮಗೆ ಏನು ಸಹಾಯ ಬೇಕು?"],  # NEEDS REVIEW
    "ta-en": ["Naan nalla irukken! Ungalukku enna help venum?"],
}

_CAPABILITIES_REPLY = {
    "en": (
        "I can help with: live weather, mandi prices, the time and date, "
        "calculations, unit conversion, emergency helpline numbers, reminders "
        "that actually go off, documents like Aadhaar/PAN/Voter ID/Ration "
        "Card/Passport/Driving Licence, and cited guidance on scholarships, "
        "bank accounts, online fraud and scams, trains and buses, government "
        "schemes, jobs and finding a hospital. Ask naturally in Tamil, Hindi, "
        "Telugu, Kannada, English, or a mix. When I can't check something "
        "reliably, I say so instead of guessing."
    ),
    "ta": (
        "நான் இவற்றில் உதவ முடியும்: நேரடி வானிலை, மண்டி விலை, நேரம் & தேதி, "
        "கணக்கீடுகள், அலகு மாற்றம், அவசர உதவி எண்கள், உண்மையாக ஒலிக்கும் "
        "நினைவூட்டல்கள், ஆதார்/PAN/வாக்காளர் அட்டை/ரேஷன் கார்டு/பாஸ்போர்ட்/ஓட்டுநர் "
        "உரிமம், மேலும் உதவித்தொகை, வங்கிக் கணக்கு, இணைய மோசடி, ரயில்/பஸ், அரசுத் "
        "திட்டங்கள், வேலை வாய்ப்பு, மருத்துவமனை தேடல் பற்றிய ஆதாரம் காட்டப்பட்ட தகவல். "
        "தமிழ், இந்தி, தெலுங்கு, கன்னடம், ஆங்கிலம் — எதிலும் கேளுங்கள். உறுதியாகத் "
        "தெரியாதபோது ஊகிக்காமல், தெரியவில்லை என்றே சொல்வேன்."
    ),
    "hi": (  # NEEDS REVIEW
        "मैं इनमें मदद कर सकता हूँ: लाइव मौसम, मंडी भाव, समय और तारीख, गणना, इकाई "
        "बदलना, आपातकालीन हेल्पलाइन नंबर, सचमुच बजने वाले रिमाइंडर, आधार/PAN/वोटर "
        "आईडी/राशन कार्ड/पासपोर्ट/ड्राइविंग लाइसेंस, और छात्रवृत्ति, बैंक खाता, "
        "ऑनलाइन ठगी, ट्रेन-बस, सरकारी योजनाएँ, नौकरी तथा अस्पताल खोजने पर स्रोत-सहित "
        "जानकारी। तमिल, हिंदी, तेलुगु, कन्नड़ या अंग्रेज़ी में पूछिए। जो भरोसे से पता "
        "न हो, उसका अंदाज़ा लगाने के बजाय मैं साफ़ कह देता हूँ।"
    ),
    "te": (  # NEEDS REVIEW
        "నేను ఇవి చేయగలను: ప్రత్యక్ష వాతావరణం, మండీ ధరలు, సమయం మరియు తేదీ, లెక్కలు, "
        "యూనిట్ మార్పిడి, అత్యవసర హెల్ప్‌లైన్ నంబర్లు, నిజంగా మోగే రిమైండర్లు, "
        "ఆధార్/PAN/ఓటర్ ఐడీ/రేషన్ కార్డు/పాస్‌పోర్ట్/డ్రైవింగ్ లైసెన్స్, అలాగే ఉపకార "
        "వేతనం, బ్యాంకు ఖాతా, ఆన్‌లైన్ మోసాలు, రైలు-బస్సు, ప్రభుత్వ పథకాలు, ఉద్యోగాలు, "
        "ఆసుపత్రి వెతకడం గురించి ఆధారాలతో సమాచారం. నమ్మకంగా తెలియనప్పుడు ఊహించకుండా "
        "తెలియదని చెప్తాను."
    ),
    "kn": (  # NEEDS REVIEW
        "ನಾನು ಇವುಗಳಲ್ಲಿ ಸಹಾಯ ಮಾಡಬಲ್ಲೆ: ನೇರ ಹವಾಮಾನ, ಮಂಡಿ ದರಗಳು, ಸಮಯ ಮತ್ತು ದಿನಾಂಕ, "
        "ಲೆಕ್ಕಾಚಾರ, ಯೂನಿಟ್ ಪರಿವರ್ತನೆ, ತುರ್ತು ಸಹಾಯವಾಣಿ ಸಂಖ್ಯೆಗಳು, ನಿಜವಾಗಿಯೂ ಸದ್ದು "
        "ಮಾಡುವ ಜ್ಞಾಪನೆಗಳು, ಆಧಾರ್/PAN/ಮತದಾರ ಗುರುತಿನ ಚೀಟಿ/ಪಡಿತರ ಚೀಟಿ/ಪಾಸ್‌ಪೋರ್ಟ್/ಚಾಲನಾ "
        "ಪರವಾನಗಿ, ಹಾಗೂ ವಿದ್ಯಾರ್ಥಿವೇತನ, ಬ್ಯಾಂಕ್ ಖಾತೆ, ಆನ್‌ಲೈನ್ ವಂಚನೆ, ರೈಲು-ಬಸ್, ಸರ್ಕಾರಿ "
        "ಯೋಜನೆಗಳು, ಉದ್ಯೋಗ, ಆಸ್ಪತ್ರೆ ಹುಡುಕುವ ಬಗ್ಗೆ ಮೂಲ ಸಹಿತ ಮಾಹಿತಿ. ಖಚಿತವಾಗಿ ತಿಳಿಯದಿದ್ದಾಗ "
        "ಊಹಿಸದೆ ಗೊತ್ತಿಲ್ಲ ಎಂದೇ ಹೇಳುತ್ತೇನೆ."
    ),
    "ta-en": (
        "Naan live weather, mandi price, time & date, calculation, unit "
        "conversion, emergency numbers, reminders, Aadhaar/PAN/Voter ID/Ration "
        "Card/Passport/Driving Licence, scholarship, bank account, online "
        "fraud, train/bus, government scheme, job, hospital — ellame source "
        "kaatti help panna mudiyum. Theriyaadha podhu guess panna maaten."
    ),
}

# Six buckets, chosen so each translates cleanly. See
# `weather._condition_for_code` for why the WMO codes are collapsed.
_WEATHER_CONDITIONS = {
    "clear": {
        "en": "clear", "ta": "தெளிவான வானிலை", "hi": "साफ़ मौसम",
        "te": "నిర్మలంగా", "kn": "ಸ್ಪಷ್ಟ ಹವಾಮಾನ",
    },
    "cloudy": {
        "en": "cloudy", "ta": "மேகமூட்டம்", "hi": "बादल छाए हुए",
        "te": "మబ్బులు", "kn": "ಮೋಡ ಕವಿದಿದೆ",
    },
    "fog": {
        "en": "foggy", "ta": "மூடுபனி", "hi": "कोहरा",
        "te": "పొగమంచు", "kn": "ಮಂಜು",
    },
    "rain": {
        "en": "raining", "ta": "மழை", "hi": "बारिश",
        "te": "వర్షం", "kn": "ಮಳೆ",
    },
    "snow": {
        "en": "snowing", "ta": "பனிப்பொழிவு", "hi": "बर्फ़बारी",
        "te": "మంచు", "kn": "ಹಿಮಪಾತ",
    },
    "thunderstorm": {
        "en": "thunderstorms", "ta": "இடியுடன் கூடிய மழை", "hi": "आंधी-तूफ़ान",
        "te": "ఉరుములతో వర్షం", "kn": "ಗುಡುಗು ಸಹಿತ ಮಳೆ",
    },
    "unknown": {
        "en": "mixed conditions", "ta": "கலவையான வானிலை", "hi": "मिला-जुला मौसम",
        "te": "మిశ్రమ వాతావరణం", "kn": "ಮಿಶ್ರ ಹವಾಮಾನ",
    },
}

_WEATHER_NOW = {
    "en": "Right now in {place}: {temp}°C, {condition}.",
    "ta": "{place} இல் இப்போது: {temp}°C, {condition}.",
    "hi": "{place} में अभी: {temp}°C, {condition}।",
    "te": "{place} లో ఇప్పుడు: {temp}°C, {condition}.",  # NEEDS REVIEW
    "kn": "{place} ನಲ್ಲಿ ಈಗ: {temp}°C, {condition}.",  # NEEDS REVIEW
    "ta-en": "{place} la ippo: {temp}°C, {condition}.",
}

_WEATHER_FEELS_LIKE = {
    "en": " Feels like {temp}°C.",
    "ta": " உணரப்படும் வெப்பம் {temp}°C.",
    "hi": " महसूस {temp}°C जैसा होता है।",
    "te": " అనిపించేది {temp}°C.",  # NEEDS REVIEW
    "kn": " ಅನಿಸುವುದು {temp}°C.",  # NEEDS REVIEW
    "ta-en": " Feels like {temp}°C.",
}

# Shown when the place resolved but the upstream was unreachable. Distinct
# from "not connected" below: this one means we tried and failed, which the
# user should know so they can retry rather than assume the feature is off.
_WEATHER_LOOKUP_FAILED = {
    "en": "I couldn't reach the weather service just now, so I won't guess. Please try again in a moment.",
    "ta": "இப்போது வானிலை சேவையை அணுக முடியவில்லை, அதனால் ஊகிக்க விரும்பவில்லை. சிறிது நேரம் கழித்து முயற்சிக்கவும்.",
    "hi": "अभी मौसम सेवा से संपर्क नहीं हो पाया, इसलिए मैं अंदाज़ा नहीं लगाऊँगा। थोड़ी देर बाद फिर कोशिश कीजिए।",
    "te": "ప్రస్తుతం వాతావరణ సేవను చేరుకోలేకపోయాను, కాబట్టి ఊహించను. కొద్దిసేపటి తర్వాత ప్రయత్నించండి.",  # NEEDS REVIEW
    "kn": "ಸದ್ಯಕ್ಕೆ ಹವಾಮಾನ ಸೇವೆಯನ್ನು ತಲುಪಲಾಗಲಿಲ್ಲ, ಆದ್ದರಿಂದ ಊಹಿಸುವುದಿಲ್ಲ. ಸ್ವಲ್ಪ ಸಮಯದ ನಂತರ ಪ್ರಯತ್ನಿಸಿ.",  # NEEDS REVIEW
    "ta-en": "Weather service-ai ippo reach panna mudiyala, so guess panna maaten. Konjam neram kazhichu try pannunga.",
}

# Asking beats guessing. The old code defaulted to Chennai when no place
# was mentioned, which quietly gave a Coimbatore user Chennai's weather.
_WEATHER_NEEDS_PLACE = {
    "en": "Which place would you like the weather for?",
    "ta": "எந்த ஊருக்கான வானிலை வேண்டும்?",
    "hi": "किस जगह का मौसम जानना है?",
    "te": "ఏ ప్రాంతం వాతావరణం కావాలి?",  # NEEDS REVIEW
    "kn": "ಯಾವ ಸ್ಥಳದ ಹವಾಮಾನ ಬೇಕು?",  # NEEDS REVIEW
    "ta-en": "Edhu oor weather venum?",
}


_GENERAL_FALLBACK = {
    "en": 'I\'m still learning, but I heard: "{text}". Could you tell me a bit more?',
    "ta": 'நான் இன்னும் கற்றுக்கொண்டிருக்கிறேன், நீங்கள் சொன்னது: "{text}". இன்னும் கொஞ்சம் விளக்கமா சொல்ல முடியுமா?',
    "hi": 'मैं अभी सीख रहा हूँ, मैंने सुना: "{text}"। थोड़ा और बताइए?',
    "te": 'నేను ఇంకా నేర్చుకుంటున్నాను, నేను విన్నది: "{text}". కొంచెం ఎక్కువ చెప్పగలరా?',  # NEEDS REVIEW
    "kn": 'ನಾನು ಇನ್ನೂ ಕಲಿಯುತ್ತಿದ್ದೇನೆ, ನಾನು ಕೇಳಿದ್ದು: "{text}". ಸ್ವಲ್ಪ ಹೆಚ್ಚು ಹೇಳಬಹುದೇ?',  # NEEDS REVIEW
    "ta-en": 'Naan innum kathukittu irukken — neenga sonnadhu: "{text}". Konjam explain pannunga?',
}

_TIME_TEMPLATE = {
    "en": "It's currently {value} IST.",
    "ta": "இப்போது நேரம் {value} (IST).",
    "hi": "अभी समय {value} (IST) है।",
    "te": "ఇప్పుడు సమయం {value} (IST).",  # NEEDS REVIEW
    "kn": "ಈಗ ಸಮಯ {value} (IST).",  # NEEDS REVIEW
    "ta-en": "Ippo time {value} (IST).",
}

_DATE_TEMPLATE = {
    "en": "Today is {value}.",
    "ta": "இன்றைய தேதி {value}.",
    "hi": "आज {value} है।",
    "te": "ఈరోజు {value}.",  # NEEDS REVIEW
    "kn": "ಇಂದು {value}.",  # NEEDS REVIEW
    "ta-en": "Today date {value}.",
}

_REMINDER_SET = {
    "en": 'Got it — I\'ve set a reminder for {when}{who}. Say "show my reminders" anytime to see it.',
    "ta": "சரி, {when} க்கு நினைவூட்டல் வைத்துவிட்டேன்{who}. 'என் நினைவூட்டல்களை காட்டு' என்று எப்போது வேண்டுமானாலும் கேட்கலாம்.",
    "hi": "ठीक है — {when} के लिए रिमाइंडर लगा दिया{who}। 'मेरे रिमाइंडर दिखाओ' कहकर कभी भी देख सकते हैं।",
    "te": "సరే — {when} కి రిమైండర్ పెట్టాను{who}.",  # NEEDS REVIEW
    "kn": "ಸರಿ — {when} ಗೆ ಜ್ಞಾಪನೆ ಇಟ್ಟಿದ್ದೇನೆ{who}.",  # NEEDS REVIEW
    "ta-en": "Okay, {when} ku reminder vecha achu{who}. 'Show my reminders' nu eppo venaalum kekalaam.",
}

_REMINDER_WHO = {
    "en": " about {person}",
    "ta": " ({person})",
    "hi": " ({person})",
    "te": " ({person})",
    "kn": " ({person})",
    "ta-en": " about {person}",
}

_REMINDER_WHEN_UNKNOWN = {
    "en": "the requested time",
    "ta": "நீங்கள் கேட்ட நேரம்",
    "hi": "आपके बताए समय",
    "te": "మీరు చెప్పిన సమయం",  # NEEDS REVIEW
    "kn": "ನೀವು ಹೇಳಿದ ಸಮಯ",  # NEEDS REVIEW
    "ta-en": "neenga sonna time",
}

_REMINDER_NO_TIME = {
    "en": "I've saved that, but I couldn't work out when to remind you — try \"tomorrow at 6pm\" or \"in 30 minutes\".",
    "ta": "சேமித்துவிட்டேன், ஆனால் எப்போது நினைவூட்ட வேண்டும் என்று புரியவில்லை — \"நாளை 6 மணிக்கு\" என்று சொல்லிப் பாருங்கள்.",
    "hi": "सहेज लिया, लेकिन कब याद दिलाना है यह समझ नहीं आया — \"कल 6 बजे\" जैसा बताइए।",
    "te": "సేవ్ చేశాను, కానీ ఎప్పుడు గుర్తు చేయాలో అర్థం కాలేదు — \"రేపు 6 గంటలకు\" అని చెప్పండి.",  # NEEDS REVIEW
    "kn": "ಉಳಿಸಿದೆ, ಆದರೆ ಯಾವಾಗ ನೆನಪಿಸಬೇಕೆಂದು ಅರ್ಥವಾಗಲಿಲ್ಲ — \"ನಾಳೆ 6 ಗಂಟೆಗೆ\" ಎಂದು ಹೇಳಿ.",  # NEEDS REVIEW
    "ta-en": "Save panniten, aana eppo remind pannanum nu puriyala — \"naalai 6 maniku\" madhiri sollunga.",
}

_REMINDERS_EMPTY = {
    "en": "You don't have any reminders saved yet.",
    "ta": "இதுவரை நீங்கள் எந்த நினைவூட்டலும் சேமிக்கவில்லை.",
    "hi": "अभी आपका कोई रिमाइंडर सेव नहीं है।",
    "te": "ఇప్పటివరకు మీకు రిమైండర్లు లేవు.",  # NEEDS REVIEW
    "kn": "ಇದುವರೆಗೆ ನಿಮಗೆ ಯಾವ ಜ್ಞಾಪನೆಯೂ ಇಲ್ಲ.",  # NEEDS REVIEW
    "ta-en": "Innum enda reminder-um save pannala.",
}

_REMINDERS_HEADER = {
    "en": "Here are your reminders:",
    "ta": "உங்கள் நினைவூட்டல்கள்:",
    "hi": "आपके रिमाइंडर:",
    "te": "మీ రిమైండర్లు:",  # NEEDS REVIEW
    "kn": "ನಿಮ್ಮ ಜ್ಞಾಪನೆಗಳು:",  # NEEDS REVIEW
    "ta-en": "Unga reminders:",
}

_CALC_RESULT = {
    "en": "That's {value}.",
    "ta": "பதில்: {value}",
    "hi": "उत्तर: {value}",
    "te": "సమాధానం: {value}",  # NEEDS REVIEW
    "kn": "ಉತ್ತರ: {value}",  # NEEDS REVIEW
    "ta-en": "Answer: {value}",
}

_CALC_FAILED = {
    "en": 'I couldn\'t work that out — try something like "45 plus 67" or "20% of 500".',
    "ta": 'அந்த கணக்கை புரிந்துகொள்ள முடியவில்லை — "45 plus 67" போன்று சொல்லி பாருங்கள்.',
    "hi": 'वह गणना समझ नहीं आई — "45 plus 67" जैसा कुछ बोलकर देखिए।',
    "te": '"45 plus 67" లాంటిది ప్రయత్నించండి.',  # NEEDS REVIEW
    "kn": '"45 plus 67" ರೀತಿ ಪ್ರಯತ್ನಿಸಿ.',  # NEEDS REVIEW
    "ta-en": 'Andha calculation puriyala — "45 plus 67" madhiri try pannunga.',
}

_CONVERT_RESULT = {
    "en": "{value} {from_unit} is {result} {to_unit}.",
    "ta": "{value} {from_unit} = {result} {to_unit}.",
    "hi": "{value} {from_unit} = {result} {to_unit}.",
    "te": "{value} {from_unit} = {result} {to_unit}.",
    "kn": "{value} {from_unit} = {result} {to_unit}.",
    "ta-en": "{value} {from_unit} = {result} {to_unit} thaan.",
}

_CONVERT_FAILED = {
    "en": 'I couldn\'t parse that conversion — try "5 km to miles" or "98 fahrenheit to celsius".',
    "ta": 'அந்த மாற்றத்தை புரிந்துகொள்ள முடியவில்லை — "5 km to miles" போன்று சொல்லுங்கள்.',
    "hi": 'वह रूपांतरण समझ नहीं आया — "5 km to miles" जैसा बोलिए।',
    "te": '"5 km to miles" లాంటిది ప్రయత్నించండి.',  # NEEDS REVIEW
    "kn": '"5 km to miles" ರೀತಿ ಪ್ರಯತ್ನಿಸಿ.',  # NEEDS REVIEW
    "ta-en": 'Andha conversion puriyala — "5 km to miles" madhiri sollunga.',
}

_GOV_DOC_MISS = {
    "en": "I have basic information on Aadhaar, PAN, Voter ID, Ration Card, Passport and Driving Licence — which one do you need?",
    "ta": "ஆதார், PAN, வாக்காளர் அட்டை, ரேஷன் கார்டு, பாஸ்போர்ட், ஓட்டுநர் உரிமம் பற்றிய அடிப்படை தகவல் உள்ளது — எது வேண்டும்?",
    "hi": "मेरे पास आधार, PAN, वोटर आईडी, राशन कार्ड, पासपोर्ट और ड्राइविंग लाइसेंस की बुनियादी जानकारी है — कौन सी चाहिए?",
    "te": "ఆధార్, PAN, ఓటర్ ఐడీ, రేషన్ కార్డు, పాస్‌పోర్ట్, డ్రైవింగ్ లైసెన్స్ గురించి సమాచారం ఉంది — ఏది కావాలి?",  # NEEDS REVIEW
    "kn": "ಆಧಾರ್, PAN, ಮತದಾರ ಗುರುತಿನ ಚೀಟಿ, ಪಡಿತರ ಚೀಟಿ, ಪಾಸ್‌ಪೋರ್ಟ್, ಚಾಲನಾ ಪರವಾನಗಿ ಬಗ್ಗೆ ಮಾಹಿತಿ ಇದೆ — ಯಾವುದು ಬೇಕು?",  # NEEDS REVIEW
    "ta-en": "Aadhaar, PAN, Voter ID, Ration Card, Passport, Driving Licence pathi basic info irukku — edhu venum?",
}

# --- Mandi prices ---------------------------------------------------------
# Three distinct outcomes, same discipline as weather: which crop?, live
# lookup unavailable, and a real answer with a timestamp. The "unavailable"
# strings deep link to AGMARKNET so the user still gets somewhere.

_MANDI_NEEDS_COMMODITY = {
    "en": "Which crop's market price do you want? I can look up tomato, onion, potato, rice, paddy, wheat, banana, coconut, sugarcane, cotton, turmeric, chilli, brinjal or groundnut.",
    "ta": "எந்தப் பயிரின் சந்தை விலை வேண்டும்? தக்காளி, வெங்காயம், உருளைக்கிழங்கு, அரிசி, நெல், கோதுமை, வாழை, தேங்காய், கரும்பு, பருத்தி, மஞ்சள், மிளகாய், கத்தரிக்காய், நிலக்கடலை — இவற்றைப் பார்க்க முடியும்.",
    "hi": "किस फ़सल का मंडी भाव चाहिए? टमाटर, प्याज, आलू, चावल, धान, गेहूं, केला, नारियल, गन्ना, कपास, हल्दी, मिर्च, बैंगन या मूंगफली देख सकता हूँ।",  # NEEDS REVIEW
    "te": "ఏ పంట మార్కెట్ ధర కావాలి? టమాటా, ఉల్లి, బంగాళాదుంప, బియ్యం, వరి, గోధుమ, అరటి, కొబ్బరి, చెరకు, పత్తి, పసుపు, మిర్చి, వంకాయ, వేరుశనగ చూడగలను.",  # NEEDS REVIEW
    "kn": "ಯಾವ ಬೆಳೆಯ ಮಾರುಕಟ್ಟೆ ದರ ಬೇಕು? ಟೊಮೇಟೊ, ಈರುಳ್ಳಿ, ಆಲೂಗಡ್ಡೆ, ಅಕ್ಕಿ, ಭತ್ತ, ಗೋಧಿ, ಬಾಳೆ, ತೆಂಗಿನಕಾಯಿ, ಕಬ್ಬು, ಹತ್ತಿ, ಅರಿಶಿನ, ಮೆಣಸಿನಕಾಯಿ, ಬದನೆ, ಶೇಂಗಾ ನೋಡಬಲ್ಲೆ.",  # NEEDS REVIEW
    "ta-en": "Endha crop-oda market price venum? Tomato, onion, potato, rice, paddy, wheat, banana, coconut, sugarcane, cotton, turmeric, chilli, brinjal, groundnut check panna mudiyum.",
}

_MANDI_NOT_CONFIGURED = {
    "en": "Live mandi prices aren't switched on in this build — they need a free data.gov.in API key. Today's rates for every market are on agmarknet.gov.in.",
    "ta": "இந்தப் பதிப்பில் நேரடி மண்டி விலைகள் இயக்கப்படவில்லை — அதற்கு data.gov.in-ன் இலவச API key தேவை. இன்றைய விலைகள் agmarknet.gov.in-ல் உள்ளன.",
    "hi": "इस बिल्ड में लाइव मंडी भाव चालू नहीं हैं — इसके लिए data.gov.in की निःशुल्क API key चाहिए। आज के भाव agmarknet.gov.in पर हैं।",  # NEEDS REVIEW
    "te": "ఈ బిల్డ్‌లో ప్రత్యక్ష మండీ ధరలు ఆన్ చేయలేదు — దానికి data.gov.in ఉచిత API key కావాలి. నేటి ధరలు agmarknet.gov.in లో ఉన్నాయి.",  # NEEDS REVIEW
    "kn": "ಈ ಬಿಲ್ಡ್‌ನಲ್ಲಿ ನೇರ ಮಂಡಿ ದರಗಳು ಚಾಲನೆಯಲ್ಲಿಲ್ಲ — ಅದಕ್ಕೆ data.gov.in ನ ಉಚಿತ API key ಬೇಕು. ಇಂದಿನ ದರಗಳು agmarknet.gov.in ನಲ್ಲಿವೆ.",  # NEEDS REVIEW
    "ta-en": "Indha build-la live mandi price on aagala — data.gov.in free API key venum. Innaiya rate ellam agmarknet.gov.in-la irukku.",
}

_MANDI_UNAVAILABLE = {
    "en": "I couldn't get today's mandi price for {commodity} just now — the AGMARKNET service didn't respond, or it has no rows for that crop today. Check agmarknet.gov.in directly; I won't guess a price.",
    "ta": "{commodity}-க்கான இன்றைய மண்டி விலையை இப்போது பெற முடியவில்லை — AGMARKNET சேவை பதிலளிக்கவில்லை, அல்லது இன்று அந்தப் பயிருக்குத் தரவு இல்லை. agmarknet.gov.in-ல் நேரடியாகப் பாருங்கள்; நான் விலையை ஊகிக்க மாட்டேன்.",
    "hi": "{commodity} का आज का मंडी भाव अभी नहीं मिल सका — AGMARKNET सेवा ने जवाब नहीं दिया, या आज उस फ़सल का डेटा नहीं है। agmarknet.gov.in सीधे देखें; मैं भाव का अंदाज़ा नहीं लगाऊँगा।",  # NEEDS REVIEW
    "te": "{commodity} నేటి మండీ ధర ఇప్పుడు రాలేదు — AGMARKNET సేవ స్పందించలేదు, లేదా ఈ రోజు ఆ పంటకు డేటా లేదు. agmarknet.gov.in నేరుగా చూడండి; నేను ధరను ఊహించను.",  # NEEDS REVIEW
    "kn": "{commodity} ಇಂದಿನ ಮಂಡಿ ದರ ಈಗ ಸಿಗಲಿಲ್ಲ — AGMARKNET ಸೇವೆ ಸ್ಪಂದಿಸಲಿಲ್ಲ, ಅಥವಾ ಇಂದು ಆ ಬೆಳೆಗೆ ದಾಖಲೆ ಇಲ್ಲ. agmarknet.gov.in ನೇರವಾಗಿ ನೋಡಿ; ನಾನು ದರವನ್ನು ಊಹಿಸುವುದಿಲ್ಲ.",  # NEEDS REVIEW
    "ta-en": "{commodity} innaiya mandi price kidaikala — AGMARKNET respond pannala, illa indha crop-ku innaiku data illa. agmarknet.gov.in-la paarunga; naan price guess panna maaten.",
}

_MANDI_HEADER = {
    "en": "Today's mandi prices for {commodity}, cheapest market first:",
    "ta": "{commodity}-க்கான இன்றைய மண்டி விலைகள் (குறைந்த விலை முதலில்):",
    "hi": "{commodity} के आज के मंडी भाव (सबसे कम पहले):",  # NEEDS REVIEW
    "te": "{commodity} నేటి మండీ ధరలు (తక్కువ ధర ముందు):",  # NEEDS REVIEW
    "kn": "{commodity} ಇಂದಿನ ಮಂಡಿ ದರಗಳು (ಕಡಿಮೆ ದರ ಮೊದಲು):",  # NEEDS REVIEW
    "ta-en": "{commodity} innaiya mandi price (kammi price mundhi):",
}

_MANDI_UNIT = {
    "en": "quintal", "ta": "குவிண்டால்", "hi": "क्विंटल",
    "te": "క్వింటాల్", "kn": "ಕ್ವಿಂಟಾಲ್", "ta-en": "quintal",
}

_TRANSLATE_PROMPT = {
    "en": "Sure — tell me the word or phrase and the target language, and I'll translate it.",
    "ta": "சரி — எந்த வார்த்தை/வாக்கியம், எந்த மொழிக்கு மாற்ற வேண்டும் என்று சொல்லுங்கள்.",
    "hi": "ज़रूर — शब्द या वाक्य और कौन सी भाषा में चाहिए, यह बताइए।",
    "te": "సరే — ఏ పదం, ఏ భాషలోకి కావాలో చెప్పండి.",  # NEEDS REVIEW
    "kn": "ಸರಿ — ಯಾವ ಪದ, ಯಾವ ಭಾಷೆಗೆ ಬೇಕು ಎಂದು ಹೇಳಿ.",  # NEEDS REVIEW
    "ta-en": "Sure, enna word translate pannanum, edhu language ku sollunga.",
}


# IMD district warnings (services/imd.py). Hindi, Telugu and Kannada are
# unreviewed like the rest of this file; the hazard names are IMD's own
# categories, kept short so a mistranslation has little room to mislead.
_IMD_WARNING = {
    "en": "IMD {colour} warning for {district} today: {hazards}.",
    "ta": "இன்று {district}-க்கு IMD {colour} எச்சரிக்கை: {hazards}.",
    "hi": "आज {district} के लिए IMD की {colour} चेतावनी: {hazards}।",  # NEEDS REVIEW
    "te": "ఈ రోజు {district} కు IMD {colour} హెచ్చరిక: {hazards}.",  # NEEDS REVIEW
    "kn": "ಇಂದು {district} ಗೆ IMD {colour} ಎಚ್ಚರಿಕೆ: {hazards}.",  # NEEDS REVIEW
    "ta-en": "Innaiku {district}-ku IMD {colour} warning: {hazards}.",
}

_IMD_COLOURS = {
    "yellow": {"en": "yellow", "ta": "மஞ்சள்", "hi": "पीली", "te": "పసుపు", "kn": "ಹಳದಿ"},
    "orange": {"en": "orange", "ta": "ஆரஞ்சு", "hi": "नारंगी", "te": "నారింజ", "kn": "ಕಿತ್ತಳೆ"},
    "red": {"en": "red", "ta": "சிவப்பு", "hi": "लाल", "te": "ఎరుపు", "kn": "ಕೆಂಪು"},
}

_IMD_HAZARDS = {  # hi / te / kn: NEEDS REVIEW
    "heavy_rain": {"en": "heavy rain", "ta": "கனமழை", "hi": "भारी बारिश", "te": "భారీ వర్షం", "kn": "ಭಾರೀ ಮಳೆ"},
    "heavy_snow": {"en": "heavy snow", "ta": "கடும் பனிப்பொழிவு", "hi": "भारी बर्फ़बारी", "te": "భారీ హిమపాతం", "kn": "ಭಾರೀ ಹಿಮಪಾತ"},
    "thunderstorm": {"en": "thunderstorm and lightning", "ta": "இடி மின்னல்", "hi": "आंधी और बिजली", "te": "ఉరుములు మెరుపులు", "kn": "ಗುಡುಗು ಮಿಂಚು"},
    "hailstorm": {"en": "hailstorm", "ta": "ஆலங்கட்டி மழை", "hi": "ओलावृष्टि", "te": "వడగళ్ల వాన", "kn": "ಆಲಿಕಲ್ಲು ಮಳೆ"},
    "dust_storm": {"en": "dust storm", "ta": "புழுதிப் புயல்", "hi": "धूल भरी आंधी", "te": "దుమ్ము తుఫాను", "kn": "ಧೂಳಿನ ಬಿರುಗಾಳಿ"},
    "dust_raising_winds": {"en": "dust-raising winds", "ta": "புழுதிக் காற்று", "hi": "धूल उड़ाने वाली हवा", "te": "దుమ్ము రేపే గాలులు", "kn": "ಧೂಳೆಬ್ಬಿಸುವ ಗಾಳಿ"},
    "strong_winds": {"en": "strong winds", "ta": "பலத்த காற்று", "hi": "तेज़ हवा", "te": "బలమైన గాలులు", "kn": "ಬಲವಾದ ಗಾಳಿ"},
    "heat_wave": {"en": "heat wave", "ta": "வெப்ப அலை", "hi": "लू", "te": "వడగాలులు", "kn": "ಬಿಸಿಗಾಳಿ"},
    "hot_day": {"en": "hot day", "ta": "கடும் வெப்ப நாள்", "hi": "गर्म दिन", "te": "వేడి రోజు", "kn": "ಬಿಸಿ ದಿನ"},
    "warm_night": {"en": "warm night", "ta": "வெப்பமான இரவு", "hi": "गर्म रात", "te": "వెచ్చని రాత్రి", "kn": "ಬೆಚ್ಚಗಿನ ರಾತ್ರಿ"},
    "cold_wave": {"en": "cold wave", "ta": "குளிர் அலை", "hi": "शीत लहर", "te": "చలిగాలులు", "kn": "ಶೀತಗಾಳಿ"},
    "cold_day": {"en": "cold day", "ta": "குளிர் நாள்", "hi": "ठंडा दिन", "te": "చల్లని రోజు", "kn": "ಚಳಿ ದಿನ"},
    "ground_frost": {"en": "ground frost", "ta": "உறைபனி", "hi": "पाला", "te": "నేల మంచు", "kn": "ನೆಲದ ಹಿಮ"},
    "fog": {"en": "fog", "ta": "மூடுபனி", "hi": "कोहरा", "te": "పొగమంచు", "kn": "ಮಂಜು"},
}


def _place_entity(entities: List[ExtractedEntity]) -> Optional[str]:
    for entity in entities:
        if entity.type == "PLACE":
            return entity.value
    return None


def _reminder_when_and_who(entities: List[ExtractedEntity], language: str):
    time_val = next((e.value for e in entities if e.type == "TIME"), None)
    date_val = next((e.value for e in entities if e.type == "DATE"), None)
    person_val = next((e.value for e in entities if e.type == "PERSON"), None)
    when = " ".join(filter(None, [date_val, time_val])) or _t(_REMINDER_WHEN_UNKNOWN, language)
    who = _t(_REMINDER_WHO, language).format(person=person_val) if person_val else ""
    return when, who


def _number_str(value) -> str:
    return f"{value:g}" if isinstance(value, float) else str(value)


# The PLACE gazetteer only knows a few dozen cities, but Open-Meteo can
# geocode anywhere. So when the extractor finds nothing, fall back to the
# preposition pattern — "weather in Kanchipuram" should work even though
# Kanchipuram isn't in the list.
_PLACE_AFTER_PREPOSITION = re.compile(
    r"\b(?:in|at|for)\s+([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+)?)"
)


def _place_from_text(text: str) -> Optional[str]:
    match = _PLACE_AFTER_PREPOSITION.search(text)
    return match.group(1) if match else None


def _weather_answer(text: str, entities: List[ExtractedEntity], language: str) -> DomainAnswer:
    """
    Live weather for the place mentioned, or an honest failure.

    Three distinct outcomes, kept distinct on purpose:
      - no place mentioned      -> ask, don't assume a city
      - place known, call fails -> "couldn't reach it, try again"
      - success                 -> the reading, cited and timestamped

    The old implementation collapsed all three into one invented sentence
    ("sunny, around 32°C"). A farmer deciding whether to irrigate, or
    someone deciding whether to travel, cannot use a number we made up —
    and cannot tell an invented one from a real one unless we say so.
    """
    place = _place_entity(entities) or _place_from_text(text)
    if not place:
        return plain(_t(_WEATHER_NEEDS_PLACE, language), language, confidence=0.5)

    reading = weather.get_weather(place)
    if reading is None:
        return refusal(_t(_WEATHER_LOOKUP_FAILED, language), language)

    condition = _t(_WEATHER_CONDITIONS.get(reading.condition, _WEATHER_CONDITIONS["unknown"]), language)
    text = _t(_WEATHER_NOW, language).format(
        place=reading.place,
        temp=_number_str(reading.temperature_c),
        condition=condition,
    )
    if reading.feels_like_c is not None:
        text += _t(_WEATHER_FEELS_LIKE, language).format(
            temp=_number_str(reading.feels_like_c)
        )

    observed_ist = reading.observed_at.astimezone(IST)
    sources = [
        Source(
            title=reading.source_title,
            url=reading.source_url,
            checked_on=observed_ist.date(),
        )
    ]

    # An IMD warning, if one is in force and IMD access is configured. When
    # there is none to report, nothing is added — including no "no
    # warnings" line, because a failed lookup looks the same from here and
    # must not be reported as an all-clear (see services/imd.py).
    warning = imd.get_warning(reading.district, reading.place, place)
    if warning is not None:
        hazards = ", ".join(_t(_IMD_HAZARDS[hazard], language) for hazard in warning.hazards)
        text += "\n" + _t(_IMD_WARNING, language).format(
            colour=_t(_IMD_COLOURS[warning.colour], language),
            district=warning.district,
            hazards=hazards,
        )
        sources.append(
            Source(title=imd.SOURCE_TITLE, url=imd.SOURCE_URL, checked_on=observed_ist.date())
        )

    return DomainAnswer(
        text=text,
        language=language,
        sources=sources,
        staleness=observed_ist.strftime("as of %d %B %Y, %I:%M %p IST"),
    )


_HOSPITAL_HEADER = {
    "en": "Hospitals listed for {place} in the National Hospital Directory:",
    "ta": "தேசிய மருத்துவமனை பட்டியலில் {place}-க்கு உள்ள மருத்துவமனைகள்:",
    "hi": "राष्ट्रीय अस्पताल निर्देशिका में {place} के अस्पताल:",  # NEEDS REVIEW
    "te": "జాతీయ ఆసుపత్రుల జాబితాలో {place} ఆసుపత్రులు:",  # NEEDS REVIEW
    "kn": "ರಾಷ್ಟ್ರೀಯ ಆಸ್ಪತ್ರೆ ಪಟ್ಟಿಯಲ್ಲಿ {place} ಆಸ್ಪತ್ರೆಗಳು:",  # NEEDS REVIEW
    "ta-en": "National Hospital Directory-la {place}-ku irukkura hospitals:",
}

# The caveat is the important sentence, so it is never dropped: a registry
# entry is not a promise that the hospital is open or can treat someone.
_HOSPITAL_CAVEAT = {
    "en": "This is a registry and may be out of date — call before you travel. In an emergency, call 108.",
    "ta": "இது ஒரு பதிவேடு; தகவல் பழையதாக இருக்கலாம் — செல்வதற்கு முன் அழைத்து உறுதி செய்யுங்கள். அவசரத்தில் 108 அழையுங்கள்.",
    "hi": "यह एक रजिस्टर है और पुराना हो सकता है — जाने से पहले फ़ोन कर लें। आपात स्थिति में 108 पर कॉल करें।",  # NEEDS REVIEW
    "te": "ఇది ఒక రిజిస్టర్; సమాచారం పాతది కావచ్చు — వెళ్ళే ముందు ఫోన్ చేయండి. అత్యవసరంలో 108 కు కాల్ చేయండి.",  # NEEDS REVIEW
    "kn": "ಇದು ಒಂದು ದಾಖಲೆ ಪಟ್ಟಿ; ಮಾಹಿತಿ ಹಳೆಯದಾಗಿರಬಹುದು — ಹೋಗುವ ಮೊದಲು ಕರೆ ಮಾಡಿ. ತುರ್ತು ಸಂದರ್ಭದಲ್ಲಿ 108 ಗೆ ಕರೆ ಮಾಡಿ.",  # NEEDS REVIEW
    "ta-en": "Idhu oru registry, pazhaiya thagaval-a irukkalaam — pogum munnadi call panni confirm pannunga. Emergency-na 108 call pannunga.",
}


def _hospital_answer(
    text: str, entities: List[ExtractedEntity], language: str
) -> Optional[DomainAnswer]:
    """
    A live list of hospitals for the place named, or None.

    None hands the question back to the curated answer, which is right in
    every case this cannot handle: no place named, lookup not configured,
    upstream down, or no rows. The user then gets the same cited guidance
    as before rather than an error.
    """
    place = _place_entity(entities) or _place_from_text(text)
    if not place:
        return None
    found = hospitals.find_hospitals(place)
    if not found:
        return None

    # "- " is the frontend's bullet marker; each row starts with a name, so
    # none can be mistaken for a helpline row (which starts with digits).
    lines = [
        "- " + " — ".join(part for part in (row.name, row.address or row.district, row.phone) if part)
        for row in found
    ]
    caveat = _t(_HOSPITAL_CAVEAT, language)
    return DomainAnswer(
        text="\n".join([_t(_HOSPITAL_HEADER, language).format(place=place), *lines, "", caveat]),
        language=language,
        sources=[
            Source(
                title=hospitals.SOURCE_TITLE,
                url=hospitals.SOURCE_URL,
                checked_on=hospitals.checked_on(),
            )
        ],
        # Only the verified helpline in the caveat. The hospitals' own
        # numbers come from an unverified registry and stay plain text.
        dialable=skills.dialable_numbers(caveat),
    )


def _mandi_answer(text: str, language: str) -> DomainAnswer:
    """
    Live mandi prices, or an honest account of why not.

    Four outcomes, kept deliberately distinct — collapsing them is how "we
    never configured a key" gets reported to a farmer as "prices have
    crashed":
      1. No crop named        -> ask which one.
      2. No API key           -> say the feature isn't switched on, link the portal.
      3. Upstream failed/empty-> say so, link the portal, refuse to guess.
      4. Rows returned        -> the prices, with market, range and date.
    """
    commodity = mandi.commodity_in_text(text)
    if not commodity:
        return plain(_t(_MANDI_NEEDS_COMMODITY, language), language, confidence=0.5)

    # Echo the crop back in the user's own language. The dict key is
    # AGMARKNET's internal spelling ("Paddy(Dhan)(Common)"), which no farmer
    # should have to read.
    crop = mandi.localized_name(commodity, language)

    if not mandi.api_key_configured():
        return refusal(_t(_MANDI_NOT_CONFIGURED, language), language)

    prices = mandi.get_prices(commodity)
    if not prices:
        return refusal(
            _t(_MANDI_UNAVAILABLE, language).format(commodity=crop), language
        )

    unit = _t(_MANDI_UNIT, language)
    # "- " is the frontend's bullet marker (frontend/src/utils/replyFormat.js):
    # rendered as a real list item, and stripped again before the text is
    # spoken. Four markets without it is one run-on paragraph.
    #
    # Safe against the helpline rule, which only claims a line that *starts*
    # with 3–5 digits: these rows start with a market name.
    lines = [
        "- {market}{district} — ₹{low:g}–₹{high:g} (₹{modal:g}) / {unit}".format(
            market=price.market,
            district=f" ({price.district})" if price.district else "",
            low=price.min_price,
            high=price.max_price,
            modal=price.modal_price,
            unit=unit,
        )
        for price in prices
    ]
    # The arrival date is the dataset's own idea of freshness, which is what
    # a user needs — "today" from a once-a-day feed can mean yesterday's
    # trading if the upload is late.
    arrival = next((price.arrival_date for price in prices if price.arrival_date), None)
    header = _t(_MANDI_HEADER, language).format(commodity=crop)
    return DomainAnswer(
        text=header + "\n" + "\n".join(lines),
        language=language,
        sources=[
            Source(
                title=mandi.SOURCE_TITLE,
                url=mandi.SOURCE_URL,
                checked_on=mandi.checked_on(),
            )
        ],
        staleness=f"arrival date {arrival}" if arrival else None,
    )


def generate_response(
    text: str,
    language: str,
    intent: str,
    entities: List[ExtractedEntity],
    context: Optional[dict] = None,
) -> DomainAnswer:
    """
    Main entry point. Dispatches on intent and returns a `DomainAnswer`.

    `context` carries data the router already fetched from the database
    (e.g. the saved reminder list for `list_reminders`) so response
    generation itself stays DB-agnostic.
    """
    context = context or {}

    if intent == "greeting":
        return plain(_pick(_GREETING_REPLIES, language), language)

    if intent == "goodbye":
        return plain(_pick(_GOODBYE_REPLIES, language), language)

    if intent == "thanks":
        return plain(_pick(_THANKS_REPLIES, language), language)

    if intent == "how_are_you":
        return plain(_pick(_HOW_ARE_YOU_REPLIES, language), language)

    if intent == "capabilities":
        return plain(_t(_CAPABILITIES_REPLY, language), language)

    if intent == "get_weather":
        return _weather_answer(text, entities, language)

    if intent == "get_time":
        now = datetime.now(IST).strftime("%I:%M %p")
        return plain(_t(_TIME_TEMPLATE, language).format(value=now), language)

    if intent == "get_date":
        now = datetime.now(IST).strftime("%A, %d %B %Y")
        return plain(_t(_DATE_TEMPLATE, language).format(value=now), language)

    if intent == "set_reminder":
        _, who = _reminder_when_and_who(entities, language)
        # If the time couldn't be parsed the reminder is saved but will never
        # fire, and the user has to be told that. Confirming "I've set a
        # reminder" for something that cannot go off is the same class of
        # mistake as inventing a temperature.
        if context.get("reminder_scheduled") is False:
            return plain(_t(_REMINDER_NO_TIME, language), language, confidence=0.4)
        when = context.get("reminder_when") or _t(_REMINDER_WHEN_UNKNOWN, language)
        return plain(_t(_REMINDER_SET, language).format(when=when, who=who), language)

    if intent == "list_reminders":
        reminders = context.get("reminders", [])
        if not reminders:
            return plain(_t(_REMINDERS_EMPTY, language), language)
        lines = "\n".join(f"• {reminder}" for reminder in reminders)
        return plain(f"{_t(_REMINDERS_HEADER, language)}\n{lines}", language)

    if intent == "calculate":
        result = skills.safe_calculate(text)
        if result is None:
            return plain(_t(_CALC_FAILED, language), language, confidence=0.3)
        return plain(
            _t(_CALC_RESULT, language).format(value=_number_str(result)), language
        )

    if intent == "convert_unit":
        conversion = skills.convert_units(text)
        if conversion is None:
            return plain(_t(_CONVERT_FAILED, language), language, confidence=0.3)
        return plain(
            _t(_CONVERT_RESULT, language).format(
                value=_number_str(conversion["value"]),
                from_unit=conversion["from_unit"],
                result=_number_str(conversion["result"]),
                to_unit=conversion["to_unit"],
            ),
            language,
        )

    if intent == "emergency_help":
        reply = skills.format_emergency_reply(language)
        return DomainAnswer(
            text=reply,
            language=language,
            sources=list(skills.EMERGENCY_SOURCES),
            dialable=skills.dialable_numbers(reply),
        )

    if intent == "gov_document_help":
        match = skills.match_gov_doc(text)
        if match is None:
            return plain(_t(_GOV_DOC_MISS, language), language, confidence=0.5)
        return DomainAnswer(
            text=skills.format_gov_doc_reply(match, language),
            language=language,
            sources=[Source(title=f"Official portal: {match.url}", url=f"https://{match.url}")],
        )

    if intent == "mandi_price":
        return _mandi_answer(text, language)

    if intent == "about_app":
        match = about.match_about(text)
        # Defensive, same as `knowledge_help` below: the intent exists only
        # because a match was found, but a stale classifier checkpoint can
        # also emit the label, and inventing a description of the app is as
        # bad as inventing a temperature.
        if match is None:
            return plain(_t(_CAPABILITIES_REPLY, language), language, confidence=0.5)
        # No `sources` — the subject is this program, and there is no
        # external portal to cite for a statement about it. Pretending
        # otherwise would make the citation contract meaningless.
        return DomainAnswer(
            text=about.format_about_reply(match, language),
            language=language,
        )

    if intent == "knowledge_help":
        match = knowledge.match_faq(text)
        # The intent is only assigned *because* a match was found, so this
        # is defensive rather than expected — but a stale classifier
        # checkpoint could also produce the label, and inventing content for
        # an unmatched question is the one thing this module must not do.
        if match is None:
            return plain(_t(_GENERAL_FALLBACK, language).format(text=text),
                         language, confidence=0.4)
        if match.key == "find_hospital":
            live = _hospital_answer(text, entities, language)
            if live is not None:
                return live
        reply = knowledge.format_faq_reply(match, language)
        return DomainAnswer(
            text=reply,
            language=language,
            sources=[match.source],
            # Curated text, so a helpline number in it is a helpline number
            # ("call 1930 as soon as you notice it") and can be tapped.
            dialable=skills.dialable_numbers(reply),
        )

    if intent == "translate_request":
        return plain(_t(_TRANSLATE_PROMPT, language), language)

    # general_query fallback
    return plain(
        _t(_GENERAL_FALLBACK, language).format(text=text), language, confidence=0.4
    )
