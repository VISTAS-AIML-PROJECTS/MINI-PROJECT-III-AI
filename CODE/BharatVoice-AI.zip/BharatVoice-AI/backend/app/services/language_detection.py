"""
Language Detection Service
===========================
Identifies which of BharatVoice's supported languages a piece of text is
in: Tamil, Hindi, Telugu, Kannada, or English — including code-mixed
utterances ("Tanglish", "Hinglish") which are how a very large number of
Indian users actually speak.

Strategy, cheapest first:
  1. **Script histogram.** The four target Indic scripts occupy disjoint,
     contiguous Unicode blocks, so counting which block a string's letters
     fall into identifies native-script text essentially perfectly, with no
     model, no download, and no latency. This resolves most real traffic.
  2. **Romanized cue words.** Latin-script input is the genuinely hard
     case — "epdi irukeenga" and "kya haal hai" are Tamil and Hindi
     written in Latin letters, which no script test can see. A small
     curated cue list catches common greetings and question frames.
  3. **langdetect** as a general signal for longer Latin-script text.
  4. **MuRIL / IndicLID**, when a checkpoint is present, for the rest.

IMPORTANT LIMITATION, recorded here because it will bite on expansion:
script identification cannot separate languages that *share* a script.
Hindi, Marathi, Sanskrit, Konkani and Nepali are all written in Devanagari,
so step 1 reports any Devanagari text as Hindi. That is correct for the
current language set (Hindi is the only Devanagari language supported) and
becomes wrong the moment Marathi is added — at which point step 4 stops
being optional.
"""
import logging
import re
from dataclasses import dataclass
from pathlib import Path

from app.config import settings
from app.services.calibration import load_temperature, top_label
from app.services.device import resolve_device

try:
    from langdetect import DetectorFactory, detect_langs
    _HAS_LANGDETECT = True
    # langdetect samples randomly and can give a different answer to the
    # same short sentence on each call. A fixed seed makes it repeatable,
    # which matters now that its verdict gates the fine-tuned model below.
    DetectorFactory.seed = 0
except ImportError:  # pragma: no cover
    _HAS_LANGDETECT = False

try:
    from transformers import pipeline
    _HAS_TRANSFORMERS = True
except ImportError:
    _HAS_TRANSFORMERS = False

_langid_pipeline = None  # lazy-loaded singleton
_langid_temperature = 1.0  # set when the checkpoint loads; see calibration.py
_CHECKPOINT_DIR = Path(settings.muril_langid_model_path)

logger = logging.getLogger(__name__)


def _muril_enabled() -> bool:
    """Real language-ID model available *and* not force-disabled in config."""
    return _HAS_TRANSFORMERS and settings.enable_muril


# --- Unicode blocks for the supported Indic scripts -----------------------
# Disjoint and contiguous, which is what makes the histogram work.
_SCRIPT_BLOCKS: dict = {
    "hi": (0x0900, 0x097F),  # Devanagari - Hindi (also Marathi, Sanskrit)
    "ta": (0x0B80, 0x0BFF),  # Tamil
    "te": (0x0C00, 0x0C7F),  # Telugu
    "kn": (0x0C80, 0x0CFF),  # Kannada
}

# Above this share of letters, the text is treated as native-script.
_DOMINANT_SCRIPT_RATIO = 0.6
# Between this and the above, the utterance is treated as code-mixed.
_MIXED_SCRIPT_RATIO = 0.15

# --- Romanized cue words --------------------------------------------------
# Deliberately small and high-precision: words a speaker of *this* language
# uses constantly, which are unlikely to appear in plain English. Recall is
# not the goal - langdetect and the optional model handle the long tail.
# These exist so the single most common real input, a short romanized
# greeting or question, is routed correctly.
_ROMANIZED_CUES: dict = {
    "ta": (
        "vanakkam", "epdi", "eppadi", "irukeenga", "irukku", "venum",
        "sollunga", "panunga", "pannunga", "nandri", "romba", "thanni",
        "saapadu", "seri", "ungalukku", "naan", "epo", "yaaru",
    ),
    "hi": (
        "namaste", "namaskar", "kaise", "kaisa", "kya", "hain", "haal",
        "aap", "mujhe", "kijiye", "chahiye", "dhanyavad", "shukriya",
        "nahi", "bahut", "paani", "khana", "batao", "bataiye", "kitna",
    ),
    "te": (
        "namaskaram", "unnaru", "kavali", "cheppu", "cheppandi", "enti",
        "dhanyavadalu", "avunu", "chala", "neeru", "bhojanam", "bagunna",
        "meeru", "nenu", "ela", "ekkada",
    ),
    "kn": (
        "namaskara", "hegiddira", "hegiddeera", "beku", "heli", "helidru",
        "dhanyavada", "howdu", "tumba", "oota", "chennagi", "neevu",
        "nanu", "yenu", "elli", "yaake",
    ),
}

_WORD_RE = re.compile(r"[a-z]+")


@dataclass
class LanguageResult:
    language: str  # "ta" | "hi" | "te" | "kn" | "en" | "<lang>-en"
    confidence: float
    engine: str


def _script_histogram(text: str):
    """
    Count letters per supported Indic script.

    Returns (counts_by_language, latin_letter_count, total_letter_count).
    """
    counts = {lang: 0 for lang in _SCRIPT_BLOCKS}
    latin = 0

    for char in text:
        code = ord(char)
        for lang, (low, high) in _SCRIPT_BLOCKS.items():
            if low <= code <= high:
                # Counted whether or not `isalpha()` is true. Indic vowel
                # signs and the virama are combining marks (Unicode Mn/Mc),
                # which `isalpha()` rejects — so filtering on it undercounts
                # Indic text badly. "வானிலை" is 6 characters but only 3
                # "letters", which was enough to push a genuinely code-mixed
                # sentence below the mixed-language threshold. Every
                # character in these blocks belongs to that script, so
                # counting them all is both simpler and more accurate.
                counts[lang] += 1
                break
        else:
            if char.isascii() and char.isalpha():
                latin += 1

    return counts, latin, sum(counts.values()) + latin


def _romanized_language(text: str):
    """
    Guess an Indic language from Latin-script text using cue words.

    Returns (language, confidence) or None when nothing matches.
    Confidence scales with how many distinct cues hit, capped low: this is
    a heuristic and should never outrank a real model.
    """
    words = set(_WORD_RE.findall(text.lower()))
    if not words:
        return None

    scores = {lang: len(words & set(cues)) for lang, cues in _ROMANIZED_CUES.items()}
    best_lang = max(scores, key=scores.get)
    hits = scores[best_lang]
    if hits == 0:
        return None

    # A tie means the cues weren't distinctive; don't guess.
    if sorted(scores.values())[-2] == hits:
        return None

    return best_lang, min(round(0.55 + 0.1 * hits, 2), 0.85)


def detect_language(text: str) -> LanguageResult:
    """
    Main entry point used across the app.

    Returns a supported language code ("ta", "hi", "te", "kn", "en") or a
    code-mixed marker ("ta-en", "hi-en", "te-en", "kn-en").
    """
    text = text.strip()
    if not text:
        return LanguageResult(language="en", confidence=0.0, engine="empty-input")

    # --- Step 1: script histogram (native script) ---
    counts, latin, total = _script_histogram(text)
    if total:
        indic_total = sum(counts.values())
        dominant = max(counts, key=counts.get)
        dominant_ratio = counts[dominant] / total

        if dominant_ratio > _DOMINANT_SCRIPT_RATIO:
            return LanguageResult(
                language=dominant,
                confidence=round(0.7 + dominant_ratio * 0.3, 2),
                engine="script-histogram",
            )

        # Native script and Latin in one utterance - genuinely code-mixed.
        if latin and _MIXED_SCRIPT_RATIO <= indic_total / total <= _DOMINANT_SCRIPT_RATIO:
            return LanguageResult(
                language=f"{dominant}-en",
                confidence=0.75,
                engine="script-histogram",
            )

    # --- Step 2: romanized cue words (Tanglish / Hinglish and friends) ---
    romanized = _romanized_language(text)
    if romanized:
        lang, confidence = romanized
        # Cue words inside otherwise-English text is code-mixing, which is
        # the normal register for these speakers, so report it as such.
        return LanguageResult(
            language=f"{lang}-en", confidence=confidence, engine="romanized-cues"
        )

    # --- Step 3: langdetect's opinion of pure Latin-script text ---
    # Asked before the model, because it is good at exactly the thing the
    # model is bad at: recognising ordinary English. (It is useless on
    # romanized Indic text, which it calls Somali, Finnish or Italian —
    # that is the model's job.)
    guess = _langdetect_top(text)

    # --- Step 4: the fine-tuned model, if there is one and it may answer ---
    if _muril_enabled() and _model_may_answer(text, guess):
        try:
            result = _muril_detect(text)
            # Same floor as intent detection, for the same reason: a model
            # fine-tuned on a few labels is confidently wrong, not unsure.
            # Measured on the first checkpoint trained from the 45 seed
            # rows: with no floor it labelled "what is the weather in
            # Chennai" as Tamil, and plain English replies came back in
            # Tamil. Below the floor, fall through to langdetect.
            if result.confidence >= settings.langid_confidence_threshold:
                return result
        except NotImplementedError:
            pass  # no checkpoint yet - fall through to langdetect
        except Exception:
            logger.warning("MuRIL language-ID inference failed; falling back", exc_info=True)

    # --- Step 5: langdetect for pure Latin-script text ---
    if guess is not None:
        lang = guess[0] if guess[0] in settings.supported_languages else "en"
        return LanguageResult(language=lang, confidence=round(guess[1], 2), engine="langdetect")

    # --- Step 6: fallback - assume English for pure Latin script ---
    return LanguageResult(language="en", confidence=0.6, engine="fallback-default")


def _langdetect_top(text: str):
    """langdetect's best guess as (language, probability), or None."""
    if not _HAS_LANGDETECT:
        return None
    try:
        top = detect_langs(text)[0]
    except Exception:
        return None
    return top.lang, top.prob


# Below this many words there is too little to go on. The first properly
# trained checkpoint called the single word "hi" Kannada.
_MIN_WORDS_FOR_MODEL = 3

# How sure langdetect must be that a sentence is English for the model not
# to be asked at all.
_ENGLISH_VETO = 0.8


def _model_may_answer(text: str, guess) -> bool:
    """
    Whether the fine-tuned model should be consulted for this text.

    The two mistakes a language model can make are not equally bad. Taking
    romanized Tamil for English costs a reply in English to someone who
    typed in Latin letters — roughly what the app did before there was a
    model. Taking English for Kannada costs a reply in Kannada script to
    someone who cannot read it, and switches the microphone to Kannada for
    their next sentence. So the model is kept away from the cases where it
    has been measured making the second mistake:

      - very short text ("hi", "cricket score"), and
      - text langdetect is confident is English ("how to cook biryani" was
        labelled Hinglish because of one loanword).

    Both rules cost some correct answers on romanized text, which then
    falls back to English as before. That is the trade being made.
    """
    if len(_WORD_RE.findall(text.lower())) < _MIN_WORDS_FOR_MODEL:
        return False
    if guess is not None and guess[0] == "en" and guess[1] >= _ENGLISH_VETO:
        return False
    return True


def _muril_detect(text: str) -> LanguageResult:  # pragma: no cover
    """
    Real MuRIL language-ID inference.

    MuRIL is a base encoder with no off-the-shelf checkpoint for this task;
    it needs a short fine-tune first. Run
    `backend/scripts/train_muril_langid.py` against a CSV of (text,
    language) pairs to produce a checkpoint at
    `settings.muril_langid_model_path`.

    For romanized and code-mixed input specifically, AI4Bharat's IndicLID
    is a better choice than a MuRIL fine-tune and runs on CPU: it is the
    only published LID covering romanized Indic text. Point this function
    at it when you wire it up.

    Until a checkpoint exists on disk this raises NotImplementedError so
    `detect_language` cleanly falls through.
    """
    if not (_CHECKPOINT_DIR / "config.json").exists():
        raise NotImplementedError(
            f"No fine-tuned language-ID checkpoint found at '{_CHECKPOINT_DIR}'. "
            "Run backend/scripts/train_muril_langid.py to produce one."
        )

    global _langid_pipeline, _langid_temperature
    if _langid_pipeline is None:
        device = 0 if resolve_device() == "cuda" else -1
        _langid_pipeline = pipeline(
            "text-classification", model=str(_CHECKPOINT_DIR), device=device
        )
        _langid_temperature = load_temperature(_CHECKPOINT_DIR)

    scores = _langid_pipeline(text, top_k=None, function_to_apply="none")
    label, confidence = top_label(scores, _langid_temperature)
    return LanguageResult(language=label, confidence=round(confidence, 2), engine="muril")


def base_language(language: str) -> str:
    """
    Strip a code-mixed marker: "ta-en" -> "ta", "en" -> "en".

    Used by the response and speech layers, which need a single language to
    pick templates and voices with.
    """
    if not language:
        return "en"
    return language.split("-", 1)[0]
