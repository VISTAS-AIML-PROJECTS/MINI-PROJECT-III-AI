"""
Translation Service
======================
Translates between Tamil and English.

Production path: AI4Bharat's IndicTrans2 (see `_indictrans2_translate`) —
a high-quality NMT model covering 22 Indic languages.

Fallback (used here so the app runs without a GPU / large model download):
a small curated Tamil<->English phrase/word dictionary covering common
assistant phrases, plus a clear "not available" message for anything else.
This keeps the `/api/translate` endpoint honest about its limitations while
the real model isn't wired up yet.
"""
import logging
from dataclasses import dataclass

from app.config import settings
from app.services.device import resolve_device

logger = logging.getLogger(__name__)

try:
    import torch
    from IndicTransToolkit.processor import IndicProcessor
    from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
    _HAS_INDICTRANS2 = True
except ImportError:
    _HAS_INDICTRANS2 = False


@dataclass
class TranslationResult:
    translated_text: str
    engine: str


# Our internal 2-letter codes -> IndicTrans2's FLORES-style language tags.
# Phase 1 only needs these two; extend this map alongside
# `settings.supported_languages` as more Indic languages are added.
_LANG_TAG = {
    "en": "eng_Latn",
    "ta": "tam_Taml",
}

# Lazily-loaded singletons, one per translation direction (IndicTrans2
# ships separate checkpoints for en->indic vs indic->en; there's no single
# bidirectional model). Keyed by (source_lang, target_lang).
_models: dict = {}
_tokenizers: dict = {}
_ip: "IndicProcessor | None" = None


_TA_EN_DICT = {
    "வணக்கம்": "hello",
    "நன்றி": "thank you",
    "தண்ணீர்": "water",
    "சாப்பாடு": "food",
    "எப்படி இருக்கீங்க": "how are you",
    "நல்லா இருக்கேன்": "I am fine",
    "காலை வணக்கம்": "good morning",
    "இரவு வணக்கம்": "good night",
}
_EN_TA_DICT = {v: k for k, v in _TA_EN_DICT.items()}


def translate(text: str, source_lang: str, target_lang: str) -> TranslationResult:
    """Main entry point used across the app."""
    if source_lang == target_lang:
        return TranslationResult(translated_text=text, engine="noop-same-language")

    if _HAS_INDICTRANS2 and settings.enable_indictrans2:
        try:
            return _indictrans2_translate(text, source_lang, target_lang)
        except NotImplementedError:
            pass  # unsupported direction — fall through to the dictionary
        except Exception:
            logger.warning("IndicTrans2 inference failed; falling back", exc_info=True)

    # --- Dictionary fallback ---
    lowered = text.strip().lower()
    if source_lang == "ta" and target_lang == "en":
        if text.strip() in _TA_EN_DICT:
            return TranslationResult(translated_text=_TA_EN_DICT[text.strip()], engine="dictionary-fallback")
    elif source_lang == "en" and target_lang == "ta":
        if lowered in _EN_TA_DICT:
            return TranslationResult(translated_text=_EN_TA_DICT[lowered], engine="dictionary-fallback")

    return TranslationResult(
        translated_text=(
            f"[Translation to '{target_lang}' not available in demo mode — "
            f"install IndicTrans2 for full coverage. Original: {text}]"
        ),
        engine="dictionary-fallback-miss",
    )


def _indictrans2_translate(text: str, source_lang: str, target_lang: str) -> TranslationResult:  # pragma: no cover
    """
    Real IndicTrans2 inference, used automatically once `torch`,
    `transformers`, and `IndicTransToolkit` are installed (see
    requirements.txt's optional ML section).

    Loads the correct direction-specific checkpoint on first use (en->indic
    or indic->en — IndicTrans2 does not ship a single bidirectional model),
    caches it, then runs IndicProcessor's pre/post-processing around a
    standard HF `generate()` call.
    """
    if source_lang not in _LANG_TAG or target_lang not in _LANG_TAG:
        raise NotImplementedError(
            f"IndicTrans2 wiring only maps {list(_LANG_TAG)} — "
            f"add '{source_lang}'/'{target_lang}' to _LANG_TAG to support them."
        )

    checkpoint = _checkpoint_for_direction(source_lang, target_lang)
    model, tokenizer = _load_direction(checkpoint, source_lang, target_lang)
    processor = _get_processor()

    src_tag, tgt_tag = _LANG_TAG[source_lang], _LANG_TAG[target_lang]
    batch = processor.preprocess_batch([text], src_lang=src_tag, tgt_lang=tgt_tag)

    device = resolve_device()
    inputs = tokenizer(
        batch, truncation=True, padding="longest", return_tensors="pt"
    ).to(device)

    with torch.no_grad():
        generated_tokens = model.generate(
            **inputs,
            use_cache=True,
            min_length=0,
            max_length=256,
            num_beams=5,
            num_return_sequences=1,
        )

    decoded = tokenizer.batch_decode(
        generated_tokens, skip_special_tokens=True, clean_up_tokenization_spaces=True
    )
    translated = processor.postprocess_batch(decoded, lang=tgt_tag)[0]

    return TranslationResult(translated_text=translated, engine="indictrans2")


def _checkpoint_for_direction(source_lang: str, target_lang: str) -> str:
    if source_lang == "en":
        return settings.indictrans2_en_indic_model
    if target_lang == "en":
        return settings.indictrans2_indic_en_model
    raise NotImplementedError(
        "Indic-to-Indic translation needs the indictrans2-indic-indic "
        "checkpoint — not wired up in Phase 1 (only ta<->en is in scope)."
    )


def _load_direction(checkpoint: str, source_lang: str, target_lang: str):
    """Lazily load + cache the model/tokenizer for one translation direction."""
    key = (source_lang, target_lang)
    if key not in _models:
        tokenizer = AutoTokenizer.from_pretrained(checkpoint, trust_remote_code=True)
        model = AutoModelForSeq2SeqLM.from_pretrained(
            checkpoint,
            trust_remote_code=True,
            torch_dtype=torch.float16 if resolve_device() == "cuda" else torch.float32,
        )
        model = model.to(resolve_device()).eval()
        _tokenizers[key] = tokenizer
        _models[key] = model
    return _models[key], _tokenizers[key]


def _get_processor() -> "IndicProcessor":
    global _ip
    if _ip is None:
        _ip = IndicProcessor(inference=True)
    return _ip
