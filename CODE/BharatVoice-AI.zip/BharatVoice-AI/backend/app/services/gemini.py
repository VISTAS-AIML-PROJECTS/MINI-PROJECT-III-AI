"""
Gemini Reply Layer
====================
When `GEMINI_API_KEY` is set, Gemini is the only outside service a chat
message reaches:

  - A few intents are handled on this machine with no API at all: a
    reminder is saved so it can fire, the clock, arithmetic, unit
    conversion and the verified helpline list. The app's answer is handed
    to Gemini as the facts to phrase, and Gemini is told not to add to
    them. The answer keeps its tap-to-call numbers, because the facts in it
    are still the app's.
  - Everything else, weather and mandi prices included, goes straight to
    Gemini; the weather, data.gov.in and hospital lookups are not called.
    These answers carry no sources: they are a model's text, not a cited
    record, and labelling them otherwise would be the one thing the answer
    contract forbids.

A network error, a block or an empty reply returns None. The caller then
says Gemini couldn't be reached (see `unavailable`) rather than falling
back to another service.

Only the standard library is used, like the other live-data services.
"""
import json
import logging
import urllib.request
from dataclasses import replace
from typing import Optional

from app.config import settings
from app.services.answers import DomainAnswer

logger = logging.getLogger(__name__)

_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

_LANGUAGE_NAMES = {
    "ta": "Tamil",
    "hi": "Hindi",
    "te": "Telugu",
    "kn": "Kannada",
    "en": "English",
}

# Intents answered on this machine, with no API: a database write, the
# clock, exact arithmetic or the verified helpline list. Gemini may reword
# these, never change them.
LOCAL_INTENTS = frozenset(
    {
        "set_reminder",
        "list_reminders",
        "get_time",
        "get_date",
        "calculate",
        "convert_unit",
        "emergency_help",
    }
)

_SYSTEM_PROMPT = (
    "You are BharatVoice AI, a voice assistant for people in India. Replies "
    "are read aloud, so keep them short (one to four sentences), plain and "
    "spoken: no markdown, no bullet points, no emoji. Always reply in "
    "{language_name}; for a code-mixed question, answer in the language the "
    "person mostly used. You cannot browse the web, set alarms or see the "
    "person's phone, and you have no live data: for today's weather or "
    "market prices, say you can't check them live and suggest where to look "
    "(the IMD or a weather app; agmarknet.gov.in for mandi prices). For health, money, legal or government-scheme questions, "
    "give general guidance and point to the official source or a professional; "
    "never invent a number, price, date, phone number or scheme rule. In an "
    "emergency, tell the person to call 112."
)

_GROUNDED_INSTRUCTION = (
    "The app has already handled this request and produced the answer below. "
    "Rephrase it naturally for speech in {language_name}. Keep every fact, "
    "number, time, place, price and phone number exactly as given, add no new "
    "facts, and do not leave anything out.\n\nApp answer:\n{draft}"
)


# Said when Gemini can't be reached. hi / te / kn: NEEDS REVIEW
_UNAVAILABLE = {
    "en": "Sorry, I couldn't reach Gemini just now. Please try again in a moment.",
    "ta": "மன்னிக்கவும், இப்போது Gemini-ஐ அணுக முடியவில்லை. சிறிது நேரம் கழித்து மீண்டும் முயற்சிக்கவும்.",
    "hi": "माफ़ कीजिए, अभी Gemini से संपर्क नहीं हो पाया। थोड़ी देर बाद फिर कोशिश करें।",
    "te": "క్షమించండి, ఇప్పుడు Gemini ని చేరుకోలేకపోయాను. కాసేపటి తర్వాత మళ్ళీ ప్రయత్నించండి.",
    "kn": "ಕ್ಷಮಿಸಿ, ಈಗ Gemini ಅನ್ನು ತಲುಪಲು ಆಗಲಿಲ್ಲ. ಸ್ವಲ್ಪ ಸಮಯದ ನಂತರ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.",
}


def unavailable(language: str) -> DomainAnswer:
    """The reply when Gemini fails, in the question's language."""
    text = _UNAVAILABLE.get(language.split("-")[0], _UNAVAILABLE["en"])
    return DomainAnswer(text=text, language=language, confidence=0.0, is_refusal=True)


def is_enabled() -> bool:
    return bool(settings.gemini_api_key)


def _call(system: str, contents: list[dict]) -> Optional[str]:
    """POST one generateContent request; the reply text, or None on any failure."""
    body = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": contents,
        "generationConfig": {
            "temperature": settings.gemini_temperature,
            "maxOutputTokens": settings.gemini_max_output_tokens,
            "thinkingConfig": {"thinkingLevel": settings.gemini_thinking_level},
        },
    }
    request = urllib.request.Request(
        _API_URL.format(model=settings.gemini_model),
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            # Header, not `?key=`: a key in the URL ends up in proxy and
            # error logs.
            "x-goog-api-key": settings.gemini_api_key,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=settings.gemini_timeout_seconds) as response:
            data = json.loads(response.read().decode("utf-8"))
    except Exception:
        logger.warning("Gemini request failed", exc_info=True)
        return None

    # A safety block comes back as HTTP 200 with no candidate text.
    candidates = data.get("candidates") or []
    if not candidates:
        logger.warning("Gemini returned no candidates: %s", data.get("promptFeedback"))
        return None
    if candidates[0].get("finishReason") == "MAX_TOKENS":
        # Better to say "couldn't reach" than to speak half a sentence.
        logger.warning("Gemini reply hit the token limit: %s", data.get("usageMetadata"))
        return None
    parts = (candidates[0].get("content") or {}).get("parts") or []
    text = "".join(part.get("text", "") for part in parts).strip()
    return text or None


def gemini_reply(
    text: str,
    language: str,
    intent: str,
    draft: Optional[DomainAnswer] = None,
    history: Optional[list[tuple[str, str]]] = None,
) -> Optional[DomainAnswer]:
    """
    Gemini's reply to `text`, or None if Gemini failed.

    `draft` is the app's own answer for a LOCAL_INTENTS question, to be
    reworded; leave it None for everything else.

    `history` is the conversation so far as (role, text) pairs, oldest
    first, with role "user" or "assistant". It lets follow-ups like "and
    tomorrow?" make sense.
    """
    if not is_enabled():
        return None

    language_name = _LANGUAGE_NAMES.get(language.split("-")[0], "English")
    contents = [
        {"role": "model" if role == "assistant" else "user", "parts": [{"text": said}]}
        for role, said in (history or [])
        if said
    ]

    grounded = draft is not None and intent in LOCAL_INTENTS
    prompt = text
    if grounded:
        prompt = f"{text}\n\n" + _GROUNDED_INSTRUCTION.format(
            language_name=language_name, draft=draft.text
        )
    contents.append({"role": "user", "parts": [{"text": prompt}]})

    reply = _call(_SYSTEM_PROMPT.format(language_name=language_name), contents)
    if reply is None:
        return None

    if grounded:
        return replace(draft, text=reply)
    return DomainAnswer(text=reply, language=language, confidence=0.7)
