"""
Confidence Calibration for Fine-Tuned Classifiers
===================================================
Makes a model's confidence score mean something, so the confidence floors
in intent and language detection can do their job.

THE PROBLEM THIS SOLVES, as measured on the first properly trained intent
checkpoint: it picked the right intent for 181 of 190 unseen test
questions, and reported less than 0.75 confidence on every single one.
The floor that exists to keep a weak model from overriding the rules was
therefore discarding a good model's every answer. The cause is ordinary —
a short fine-tune leaves the output layer's scores small, so the softmax
is flat even when the ranking is right.

THE FIX is temperature scaling (Guo et al., 2017): divide the model's raw
scores by one number, T, before the softmax. It cannot change which label
wins, only how sure the model claims to be. T is chosen once, after
training, as the value that makes the model's stated confidence match how
often it is actually right on validation rows it did not train on, and is
saved beside the checkpoint as `calibration.json`.

WHAT IT DOES NOT FIX. T is fitted on validation rows that come from the
same template bank as the training data. On text unlike anything in that
bank the model will still be more sure of itself than it should be — that
is true of every classifier, calibrated or not. The floors, the rules-
first mode and the "can the handler act on this" check in
intent_detection.py are still what stand between a wrong guess and the
user. Calibration makes the floor usable; it does not make it sufficient.

No calibration file means T = 1, which is exactly the uncalibrated
behaviour, so an old checkpoint keeps working unchanged.

Pure Python on purpose: this module is imported by the app at startup and
must not pull in numpy or torch.
"""
import json
import math
from pathlib import Path
from typing import List, Sequence, Tuple

CALIBRATION_FILE = "calibration.json"

# T is searched as an inverse temperature between these bounds. The upper
# bound matters when validation accuracy is 100%: the best fit is then
# "infinitely sure", which is a statement about a small validation set, not
# about the model, so sharpening is capped.
_MIN_INVERSE, _MAX_INVERSE = 0.05, 20.0


def load_temperature(checkpoint_dir: Path) -> float:
    """The saved temperature for a checkpoint, or 1.0 if there is none."""
    try:
        data = json.loads((Path(checkpoint_dir) / CALIBRATION_FILE).read_text(encoding="utf-8"))
        temperature = float(data["temperature"])
    except (OSError, ValueError, KeyError, TypeError):
        return 1.0
    return temperature if temperature > 0 and math.isfinite(temperature) else 1.0


def _log_softmax(logits: Sequence[float], inverse_temperature: float) -> List[float]:
    scaled = [value * inverse_temperature for value in logits]
    peak = max(scaled)
    log_total = peak + math.log(sum(math.exp(value - peak) for value in scaled))
    return [value - log_total for value in scaled]


def top_label(scores: Sequence[dict], temperature: float = 1.0) -> Tuple[str, float]:
    """
    The winning label and its calibrated probability.

    `scores` is what a transformers text-classification pipeline returns
    with `top_k=None, function_to_apply="none"`: one {"label", "score"}
    per label, where score is the raw logit.
    """
    labels = [item["label"] for item in scores]
    log_probs = _log_softmax([float(item["score"]) for item in scores], 1.0 / temperature)
    best = max(range(len(labels)), key=log_probs.__getitem__)
    return labels[best], math.exp(log_probs[best])


def negative_log_likelihood(
    logits: Sequence[Sequence[float]], labels: Sequence[int], temperature: float
) -> float:
    inverse = 1.0 / temperature
    total = 0.0
    for row, label in zip(logits, labels):
        total -= _log_softmax(row, inverse)[label]
    return total / max(len(labels), 1)


def fit_temperature(logits: Sequence[Sequence[float]], labels: Sequence[int]) -> float:
    """
    The temperature that minimises negative log-likelihood on held-out rows.

    The loss is convex in the inverse temperature, so a golden-section
    search finds the minimum without a learning rate to tune.
    """
    if not labels:
        return 1.0

    def loss(inverse: float) -> float:
        return negative_log_likelihood(logits, labels, 1.0 / inverse)

    ratio = (math.sqrt(5) - 1) / 2
    low, high = math.log(_MIN_INVERSE), math.log(_MAX_INVERSE)
    left = high - ratio * (high - low)
    right = low + ratio * (high - low)
    loss_left, loss_right = loss(math.exp(left)), loss(math.exp(right))
    for _ in range(60):
        if loss_left < loss_right:
            high, right, loss_right = right, left, loss_left
            left = high - ratio * (high - low)
            loss_left = loss(math.exp(left))
        else:
            low, left, loss_left = left, right, loss_right
            right = low + ratio * (high - low)
            loss_right = loss(math.exp(right))
    return 1.0 / math.exp((low + high) / 2)


def save_calibration(checkpoint_dir: Path, logits, labels) -> dict:
    """Fit a temperature on held-out rows and write it beside the checkpoint."""
    temperature = fit_temperature(logits, labels)
    correct = sum(
        max(range(len(row)), key=row.__getitem__) == label for row, label in zip(logits, labels)
    )
    report = {
        "temperature": round(temperature, 4),
        "rows": len(labels),
        "accuracy": round(correct / max(len(labels), 1), 4),
        "nll_before": round(negative_log_likelihood(logits, labels, 1.0), 4),
        "nll_after": round(negative_log_likelihood(logits, labels, temperature), 4),
    }
    (Path(checkpoint_dir) / CALIBRATION_FILE).write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    return report
