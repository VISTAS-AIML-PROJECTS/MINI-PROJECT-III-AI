"""
Citizen Skills
================
Self-contained "skills" that don't need ML models at all — just correct,
deterministic logic. This is where BharatVoice's day-to-day usefulness for
an ordinary citizen lives: arithmetic, unit conversion, emergency helpline
numbers, and short factual guidance on common government documents.

Each function returns `None` when the input doesn't match its pattern, so
`response_generator.py` can try a skill and cleanly fall through if it
doesn't apply.
"""
import ast
import operator
import re
from dataclasses import dataclass
from typing import Optional

from app.services.answers import Source

# ---------------------------------------------------------------------------
# Calculator
# ---------------------------------------------------------------------------

_WORD_OPS = [
    (r"\bplus\b", "+"),
    (r"\bminus\b", "-"),
    (r"\bmultiplied by\b", "*"),
    (r"\btimes\b", "*"),
    (r"\binto\b", "*"),
    (r"\bdivided by\b", "/"),
    (r"\bover\b", "/"),
    (r"\bmod\b", "%"),
]

# NOTE: `ast.Pow` is deliberately absent. Exponentiation is the one
# arithmetic operator whose cost is unbounded in the *size* of its operands
# rather than their count: "9**9**9**9" parses in microseconds and then
# occupies a CPU and all available memory computing a number with hundreds
# of millions of digits. Since /api/chat is unauthenticated, allowing it
# hands anyone a one-request denial of service. Users who genuinely want
# powers can multiply.
_ALLOWED_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
}
_ALLOWED_UNARY_OPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}

# Ceiling on intermediate and final values. Chosen well above anything a
# citizen-facing calculator needs (a trillion trillion) and well below the
# point where big-integer arithmetic gets slow.
_MAX_MAGNITUDE = 1e24

# Longest expression we will hand to `ast.parse`, and the most digits any
# single number may have. The digit cap doubles as a phone/Aadhaar/account
# number guard: those are long runs of digits, never arithmetic.
_MAX_EXPR_CHARS = 120
_MAX_DIGITS_PER_NUMBER = 15


def _guard_magnitude(value):
    if isinstance(value, (int, float)) and abs(value) > _MAX_MAGNITUDE:
        raise ValueError("Result out of supported range")
    return value


def _safe_eval(node):
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return _guard_magnitude(node.value)
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BIN_OPS:
        left, right = _safe_eval(node.left), _safe_eval(node.right)
        return _guard_magnitude(_ALLOWED_BIN_OPS[type(node.op)](left, right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARY_OPS:
        return _guard_magnitude(_ALLOWED_UNARY_OPS[type(node.op)](_safe_eval(node.operand)))
    raise ValueError("Unsupported expression")


# A calculation has to be *asked for*. Without this requirement the
# extractor below happily reads an expression out of any sentence that
# contains digits and punctuation, so "remind me on 3/4/2026 to renew my
# passport" was answered with "That's 0.000371" and the reminder was never
# saved. A cue is an explicit arithmetic word, a percent sign, or a
# question frame ("what is ...").
_CALC_CUE = re.compile(
    r"\b(calculate|calculation|compute|sum of|total of|add|subtract|multiply|"
    r"multiplied|divide|divided|product of|percent|square of)\b"
    r"|\bwhat(?:'s| is|s)\b|\bhow much\b|%|="
    r"|கணக்கு|கூட்டு|கழி|பெருக்கு|வகு|எவ்வளவு|மொத்தம்"
)

# Things that look like arithmetic but aren't. Dates and long digit groups
# (phone numbers, account numbers, order IDs, Aadhaar) are the two that
# actually show up in assistant traffic.
_DATE_LIKE = re.compile(r"\b\d{1,2}\s*[/-]\s*\d{1,2}\s*[/-]\s*\d{2,4}\b")
_DIGIT_GROUPS = re.compile(r"\b\d{3,}(?:[\s-]\d{3,})+\b")


def _looks_like_identifier(text: str) -> bool:
    """True for dates and long grouped digit runs — never calculations."""
    if _DATE_LIKE.search(text):
        return True
    for match in _DIGIT_GROUPS.finditer(text):
        if sum(c.isdigit() for c in match.group(0)) >= 7:
            return True
    return False


def safe_calculate(text: str) -> Optional[float]:
    """
    Extracts and safely evaluates an arithmetic expression from free text.
    Handles both symbolic ("12 * 8", "45 + 67") and spelled-out
    ("45 plus 67", "20 percent of 500") forms. Returns None if nothing
    calculable is found — never raises, never uses eval().

    A result is only returned when the user plausibly asked for a
    calculation: either the text carries an arithmetic cue (see
    `_CALC_CUE`), a spelled-out operator was substituted, or the whole
    input *is* an expression ("12*8"). Everything else returns None so the
    intent classifier can route the message to the skill that actually
    matches it.
    """
    if len(text) > _MAX_EXPR_CHARS * 4 or _looks_like_identifier(text):
        return None

    lowered = text.lower()

    # "X percent of Y" is a special case (not a simple infix expression),
    # and "percent"/"%" is itself an unambiguous cue.
    pct_match = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:%|percent)\s*of\s*(-?\d+(?:\.\d+)?)", lowered)
    if pct_match:
        pct, base = float(pct_match.group(1)), float(pct_match.group(2))
        return round((pct / 100.0) * base, 4)

    normalized = lowered
    word_op_applied = False
    for pattern, symbol in _WORD_OPS:
        normalized, substitutions = re.subn(pattern, f" {symbol} ", normalized)
        if substitutions:
            word_op_applied = True

    # Either the sentence asked for arithmetic, or the sentence is nothing
    # but arithmetic. A bare expression typed on its own is unambiguous.
    is_bare_expression = bool(re.fullmatch(r"[-+/*%().\d\s]+", normalized.strip()))
    if not (word_op_applied or is_bare_expression or _CALC_CUE.search(lowered)):
        return None

    # Keep only characters a numeric expression could contain.
    expr_match = re.search(r"[-+/*%().\d\s]{3,}", normalized)
    if not expr_match:
        return None

    expr = expr_match.group(0).strip()
    # Require at least one operator and one digit — avoids treating a bare
    # number or stray punctuation as a "calculation".
    if not re.search(r"\d", expr) or not re.search(r"[-+*/%]", expr):
        return None
    if len(expr) > _MAX_EXPR_CHARS:
        return None
    if any(len(number) > _MAX_DIGITS_PER_NUMBER for number in re.findall(r"\d+", expr)):
        return None

    try:
        tree = ast.parse(expr, mode="eval")
        result = _safe_eval(tree)
        return round(result, 6) if isinstance(result, float) else result
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Unit conversion
# ---------------------------------------------------------------------------

_UNIT_ALIASES = {
    "km": "km", "kilometer": "km", "kilometers": "km", "kilometre": "km", "kilometres": "km",
    "m": "m", "meter": "m", "meters": "m", "metre": "m", "metres": "m",
    "cm": "cm", "centimeter": "cm", "centimeters": "cm",
    "mi": "mi", "mile": "mi", "miles": "mi",
    "ft": "ft", "feet": "ft", "foot": "ft",
    "in": "in", "inch": "in", "inches": "in",
    "kg": "kg", "kilogram": "kg", "kilograms": "kg",
    "g": "g", "gram": "g", "grams": "g",
    "lb": "lb", "lbs": "lb", "pound": "lb", "pounds": "lb",
    "l": "l", "liter": "l", "liters": "l", "litre": "l", "litres": "l",
    "ml": "ml", "milliliter": "ml", "milliliters": "ml",
    "gal": "gal", "gallon": "gal", "gallons": "gal",
    "c": "c", "celsius": "c", "centigrade": "c",
    "f": "f", "fahrenheit": "f",
}

# (from, to) -> multiplicative factor, for everything except temperature.
_LINEAR_FACTORS = {
    ("km", "mi"): 0.621371, ("mi", "km"): 1.60934,
    ("km", "m"): 1000, ("m", "km"): 0.001,
    ("m", "ft"): 3.28084, ("ft", "m"): 0.3048,
    ("m", "cm"): 100, ("cm", "m"): 0.01,
    ("ft", "in"): 12, ("in", "ft"): 1 / 12,
    ("mi", "m"): 1609.34, ("m", "mi"): 1 / 1609.34,
    ("kg", "lb"): 2.20462, ("lb", "kg"): 0.453592,
    ("kg", "g"): 1000, ("g", "kg"): 0.001,
    ("l", "ml"): 1000, ("ml", "l"): 0.001,
    ("l", "gal"): 0.264172, ("gal", "l"): 3.78541,
}


def _convert_temp(value: float, from_u: str, to_u: str) -> Optional[float]:
    if from_u == to_u:
        return value
    if from_u == "c" and to_u == "f":
        return value * 9 / 5 + 32
    if from_u == "f" and to_u == "c":
        return (value - 32) * 5 / 9
    return None


def convert_units(text: str) -> Optional[dict]:
    """
    Parses patterns like "5 km to miles", "convert 98 fahrenheit to celsius",
    "10 kg in pounds". Returns {value, from_unit, to_unit, result} or None.
    """
    match = re.search(
        r"(-?\d+(?:\.\d+)?)\s*([a-zA-Zµ°]+)\s+(?:to|in|into)\s+([a-zA-Zµ°]+)",
        text.lower(),
    )
    if not match:
        return None

    value = float(match.group(1))
    from_raw, to_raw = match.group(2).strip("."), match.group(3).strip(".")
    from_u = _UNIT_ALIASES.get(from_raw)
    to_u = _UNIT_ALIASES.get(to_raw)
    if not from_u or not to_u:
        return None

    if from_u in ("c", "f") or to_u in ("c", "f"):
        result = _convert_temp(value, from_u, to_u)
    elif from_u == to_u:
        result = value
    else:
        factor = _LINEAR_FACTORS.get((from_u, to_u))
        result = value * factor if factor is not None else None

    if result is None:
        return None

    return {
        "value": value,
        "from_unit": from_raw,
        "to_unit": to_raw,
        "result": round(result, 4),
    }


# ---------------------------------------------------------------------------
# Emergency helpline numbers
# ---------------------------------------------------------------------------
# Verified against the Emergency Response Support System (112.gov.in) and
# the National Portal of India helpline directory. 112 is the single
# unified number (police/fire/ambulance/disaster) under ERSS; the legacy
# individual numbers below still work everywhere and are kept for
# familiarity.

EMERGENCY_NUMBERS = [
    ("112", {
        "en": "All-in-one national emergency (police/fire/ambulance)",
        "ta": "அனைத்து அவசர சேவைகளும் (காவல்/தீ/ஆம்புலன்ஸ்)",
        "hi": "एकीकृत राष्ट्रीय आपातकालीन नंबर (पुलिस/अग्निशमन/एम्बुलेंस)",
        "te": "అన్ని అత్యవసర సేవలు (పోలీస్/అగ్నిమాపక/అంబులెన్స్)",  # NEEDS REVIEW
        "kn": "ಎಲ್ಲಾ ತುರ್ತು ಸೇವೆಗಳು (ಪೊಲೀಸ್/ಅಗ್ನಿಶಾಮಕ/ಆಂಬ್ಯುಲೆನ್ಸ್)",  # NEEDS REVIEW
    }),
    ("100", {
        "en": "Police",
        "ta": "காவல் துறை",
        "hi": "पुलिस",
        "te": "పోలీస్",  # NEEDS REVIEW
        "kn": "ಪೊಲೀಸ್",  # NEEDS REVIEW
    }),
    ("101", {
        "en": "Fire",
        "ta": "தீயணைப்பு படை",
        "hi": "अग्निशमन",
        "te": "అగ్నిమాపక దళం",  # NEEDS REVIEW
        "kn": "ಅಗ್ನಿಶಾಮಕ ದಳ",  # NEEDS REVIEW
    }),
    ("108", {
        "en": "Ambulance",
        "ta": "ஆம்புலன்ஸ்",
        "hi": "एम्बुलेंस",
        "te": "అంబులెన్స్",  # NEEDS REVIEW
        "kn": "ಆಂಬ್ಯುಲೆನ್ಸ್",  # NEEDS REVIEW
    }),
    ("1091", {
        "en": "Women's helpline",
        "ta": "பெண்கள் உதவி எண்",
        "hi": "महिला हेल्पलाइन",
        "te": "మహిళల సహాయ నంబర్",  # NEEDS REVIEW
        "kn": "ಮಹಿಳಾ ಸಹಾಯವಾಣಿ",  # NEEDS REVIEW
    }),
    ("1098", {
        "en": "Child helpline",
        "ta": "குழந்தைகள் உதவி எண்",
        "hi": "चाइल्ड हेल्पलाइन",
        "te": "పిల్లల సహాయ నంబర్",  # NEEDS REVIEW
        "kn": "ಮಕ್ಕಳ ಸಹಾಯವಾಣಿ",  # NEEDS REVIEW
    }),
    ("14567", {
        "en": "Senior citizen helpline (Elder Line)",
        "ta": "மூத்த குடிமக்கள் உதவி எண்",
        "hi": "वरिष्ठ नागरिक हेल्पलाइन (एल्डर लाइन)",
        "te": "వృద్ధుల సహాయ నంబర్ (ఎల్డర్ లైన్)",  # NEEDS REVIEW
        "kn": "ಹಿರಿಯ ನಾಗರಿಕರ ಸಹಾಯವಾಣಿ (ಎಲ್ಡರ್ ಲೈನ್)",  # NEEDS REVIEW
    }),
    ("1930", {
        "en": "Cyber crime / financial fraud helpline",
        "ta": "சைபர் மோசடி உதவி எண்",
        "hi": "साइबर अपराध / वित्तीय धोखाधड़ी हेल्पलाइन",
        "te": "సైబర్ నేరాలు / ఆర్థిక మోసం సహాయ నంబర్",  # NEEDS REVIEW
        "kn": "ಸೈಬರ್ ಅಪರಾಧ / ಹಣಕಾಸು ವಂಚನೆ ಸಹಾಯವಾಣಿ",  # NEEDS REVIEW
    }),
    ("104", {
        "en": "Health / medical advice helpline",
        "ta": "சுகாதார ஆலோசனை உதவி எண்",
        "hi": "स्वास्थ्य सलाह हेल्पलाइन",
        "te": "ఆరోగ్య సలహా సహాయ నంబర్",  # NEEDS REVIEW
        "kn": "ಆರೋಗ್ಯ ಸಲಹಾ ಸಹಾಯವಾಣಿ",  # NEEDS REVIEW
    }),
]

# Provenance for the numbers above. `checked_on` is deliberately None:
# nobody has re-verified this list against the official portals as part of
# this change, and stamping a date we didn't actually check would make the
# citation worse than useless. Set it to the review date once a human has
# confirmed the list against 112.gov.in and the National Portal helpline
# directory — and re-confirm periodically, since helpline numbers do change.
EMERGENCY_SOURCES = (
    Source(title="Emergency Response Support System (ERSS)", url="https://112.gov.in", checked_on=None),
    Source(title="National Portal of India — helpline directory", url="https://www.india.gov.in", checked_on=None),
)

# Header per language. Telugu and Kannada headers are best-effort and need
# native review; the numbers themselves are language-independent, which is
# why an unreviewed header is an acceptable risk here and would not be for
# medical or eligibility wording.
_EMERGENCY_HEADERS = {
    "en": "Here are the key emergency numbers in India:",
    "ta": "அவசர காலத்தில் இந்த எண்களை அழைக்கவும்:",
    "hi": "भारत के मुख्य आपातकालीन नंबर:",
    "te": "భారతదేశంలో ప్రధాన అత్యవసర నంబర్లు:",  # NEEDS REVIEW
    "kn": "ಭಾರತದ ಪ್ರಮುಖ ತುರ್ತು ಸಂಖ್ಯೆಗಳು:",  # NEEDS REVIEW
    "ta-en": "Emergency-la indha numbers-ai dial pannunga:",
}


_DIALABLE = tuple(number for number, _ in EMERGENCY_NUMBERS)


def dialable_numbers(text: str) -> list:
    """
    The verified helpline numbers that appear in `text`, in list order.

    Only call this on curated, helpline-bearing answers (the emergency list
    and the FAQ). It matches by digits, so on a mandi price or a sum it
    would mark ₹1930 or "100" as a phone number — the caller choosing which
    answers to mark is what makes the match safe.
    """
    return [
        number
        for number in _DIALABLE
        if re.search(rf"(?<!\d){number}(?!\d)", text or "")
    ]


def _label_language(language: str) -> str:
    """Which label set to use. Falls back to English where none exists."""
    base = (language or "en").split("-", 1)[0]
    return base if base in ("ta", "hi", "te", "kn") else "en"


def format_emergency_reply(language: str) -> str:
    label_lang = _label_language(language)
    header = _EMERGENCY_HEADERS.get(
        language, _EMERGENCY_HEADERS.get((language or "en").split("-", 1)[0], _EMERGENCY_HEADERS["en"])
    )
    lines = [
        f"{number} — {labels.get(label_lang, labels['en'])}"
        for number, labels in EMERGENCY_NUMBERS
    ]
    return header + "\n" + "\n".join(lines)


# ---------------------------------------------------------------------------
# Government document guidance (general public information only)
# ---------------------------------------------------------------------------

_GOV_DOCS = {
    "aadhaar": {
        "keywords": ["aadhaar", "aadhar", "ஆதார்", "आधार", "ఆధార్", "ಆಧಾರ್"],
        "en": "Aadhaar is your 12-digit unique identity number issued by UIDAI. To enroll or update details, visit your nearest Aadhaar Seva Kendra or the official site.",
        "ta": "ஆதார் என்பது UIDAI வழங்கும் 12 இலக்க தனிப்பட்ட அடையாள எண். புதிதாக பதிவு செய்யவோ, விவரங்களை புதுப்பிக்கவோ அருகிலுள்ள ஆதார் சேவை மையத்தை அணுகவும்.",
        "hi": "आधार UIDAI द्वारा जारी 12 अंकों की विशिष्ट पहचान संख्या है। नया पंजीकरण कराने या विवरण अपडेट करने के लिए अपने नज़दीकी आधार सेवा केंद्र या आधिकारिक वेबसाइट पर जाएँ।",  # NEEDS REVIEW
        "te": "ఆధార్ అనేది UIDAI జారీ చేసే 12 అంకెల ప్రత్యేక గుర్తింపు సంఖ్య. కొత్తగా నమోదు చేసుకోవడానికి లేదా వివరాలు మార్చడానికి సమీప ఆధార్ సేవా కేంద్రాన్ని లేదా అధికారిక వెబ్‌సైట్‌ను సంప్రదించండి.",  # NEEDS REVIEW
        "kn": "ಆಧಾರ್ ಎಂದರೆ UIDAI ನೀಡುವ 12 ಅಂಕಿಯ ವಿಶಿಷ್ಟ ಗುರುತಿನ ಸಂಖ್ಯೆ. ಹೊಸದಾಗಿ ನೋಂದಣಿ ಮಾಡಲು ಅಥವಾ ವಿವರಗಳನ್ನು ನವೀಕರಿಸಲು ಹತ್ತಿರದ ಆಧಾರ್ ಸೇವಾ ಕೇಂದ್ರ ಅಥವಾ ಅಧಿಕೃತ ಜಾಲತಾಣವನ್ನು ಸಂಪರ್ಕಿಸಿ.",  # NEEDS REVIEW
        "url": "uidai.gov.in",
    },
    "pan": {
        "keywords": [
            "pan card", "pan number", "\u0baa\u0bbe\u0ba9\u0bcd \u0b95\u0bbe\u0bb0\u0bcd\u0b9f\u0bcd",
            "\u092a\u0948\u0928 \u0915\u093e\u0930\u094d\u0921", "\u0c2a\u0c3e\u0c28\u0c4d \u0c15\u0c3e\u0c30\u0c4d\u0c21\u0c41", "\u0caa\u0ccd\u0caf\u0cbe\u0ca8\u0ccd \u0c95\u0cbe\u0cb0\u0ccd\u0ca1\u0ccd",
        ],
        "en": "PAN (Permanent Account Number) is a 10-character ID needed for tax and most financial transactions. You can apply online via the official Income Tax / NSDL-Protean or UTIITSL portals.",
        "ta": "PAN (நிரந்தர கணக்கு எண்) என்பது வரி மற்றும் நிதி பரிவர்த்தனைகளுக்கு தேவையான 10-எழுத்து அடையாள எண். Income Tax / NSDL / UTIITSL இணையதளத்தில் விண்ணப்பிக்கலாம்.",
        "hi": "PAN (स्थायी खाता संख्या) कर और अधिकांश वित्तीय लेन-देन के लिए ज़रूरी 10 अक्षरों की पहचान संख्या है। आयकर विभाग / NSDL-Protean या UTIITSL पोर्टल पर ऑनलाइन आवेदन कर सकते हैं।",  # NEEDS REVIEW
        "te": "PAN (శాశ్వత ఖాతా సంఖ్య) అనేది పన్ను మరియు చాలా ఆర్థిక లావాదేవీలకు అవసరమైన 10 అక్షరాల గుర్తింపు సంఖ్య. ఆదాయపు పన్ను / NSDL-Protean లేదా UTIITSL పోర్టల్‌లో ఆన్‌లైన్‌లో దరఖాస్తు చేయవచ్చు.",  # NEEDS REVIEW
        "kn": "PAN (ಶಾಶ್ವತ ಖಾತೆ ಸಂಖ್ಯೆ) ತೆರಿಗೆ ಮತ್ತು ಹೆಚ್ಚಿನ ಹಣಕಾಸು ವ್ಯವಹಾರಗಳಿಗೆ ಅಗತ್ಯವಿರುವ 10 ಅಕ್ಷರಗಳ ಗುರುತಿನ ಸಂಖ್ಯೆ. ಆದಾಯ ತೆರಿಗೆ / NSDL-Protean ಅಥವಾ UTIITSL ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಆನ್‌ಲೈನ್ ಅರ್ಜಿ ಸಲ್ಲಿಸಬಹುದು.",  # NEEDS REVIEW
        "url": "incometax.gov.in",
    },
    "voter_id": {
        "keywords": [
            "voter id", "voter card", "epic card", "வாக்காளர்",
            "वोटर आईडी", "मतदाता", "ఓటరు", "ಮತದಾರ",
        ],
        "en": "Voter ID (EPIC) lets you vote and serves as identity proof. Apply or check status on the National Voters' Service Portal.",
        "ta": "வாக்காளர் அடையாள அட்டை (EPIC) வாக்களிக்கவும், அடையாள சான்றாகவும் பயன்படும். தேசிய வாக்காளர் சேவை போர்ட்டலில் விண்ணப்பிக்கலாம்.",
        "hi": "वोटर आईडी (EPIC) से आप मतदान कर सकते हैं और यह पहचान प्रमाण के रूप में भी काम आता है। राष्ट्रीय मतदाता सेवा पोर्टल पर आवेदन करें या स्थिति देखें।",  # NEEDS REVIEW
        "te": "ఓటరు గుర్తింపు కార్డు (EPIC) ఓటు వేయడానికి ఉపయోగపడుతుంది మరియు గుర్తింపు రుజువుగా కూడా పనిచేస్తుంది. జాతీయ ఓటరు సేవా పోర్టల్‌లో దరఖాస్తు చేయవచ్చు లేదా స్థితిని చూడవచ్చు.",  # NEEDS REVIEW
        "kn": "ಮತದಾರ ಗುರುತಿನ ಚೀಟಿ (EPIC) ಮತ ಚಲಾಯಿಸಲು ಮತ್ತು ಗುರುತಿನ ಪುರಾವೆಯಾಗಿ ಬಳಕೆಯಾಗುತ್ತದೆ. ರಾಷ್ಟ್ರೀಯ ಮತದಾರ ಸೇವಾ ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಅರ್ಜಿ ಸಲ್ಲಿಸಿ ಅಥವಾ ಸ್ಥಿತಿ ಪರಿಶೀಲಿಸಿ.",  # NEEDS REVIEW
        "url": "nvsp.in",
    },
    "ration_card": {
        "keywords": [
            "ration card", "ரேஷன் கார்டு",
            "राशन कार्ड", "రేషన్ కార్డు", "ಪಡಿತರ ಚೀಟಿ",
        ],
        "en": "A ration card lets you buy subsidized food grains from the Public Distribution System and also serves as address proof. Apply through your state's civil supplies department portal.",
        "ta": "ரேஷன் கார்டு மூலம் மானிய விலையில் உணவு தானியங்கள் வாங்கலாம், மேலும் இது முகவரி சான்றாகவும் பயன்படும். உங்கள் மாநில உணவுத் துறை போர்ட்டல் மூலம் விண்ணப்பிக்கவும்.",
        "hi": "राशन कार्ड से आप सार्वजनिक वितरण प्रणाली के तहत रियायती दर पर अनाज ले सकते हैं, और यह पते के प्रमाण के रूप में भी काम आता है। अपने राज्य के खाद्य एवं नागरिक आपूर्ति विभाग के पोर्टल से आवेदन करें।",  # NEEDS REVIEW
        "te": "రేషన్ కార్డుతో ప్రజా పంపిణీ వ్యవస్థ ద్వారా రాయితీ ధరలకు ఆహార ధాన్యాలు పొందవచ్చు, ఇది చిరునామా రుజువుగా కూడా ఉపయోగపడుతుంది. మీ రాష్ట్ర పౌర సరఫరాల శాఖ పోర్టల్ ద్వారా దరఖాస్తు చేయండి.",  # NEEDS REVIEW
        "kn": "ಪಡಿತರ ಚೀಟಿಯಿಂದ ಸಾರ್ವಜನಿಕ ವಿತರಣಾ ವ್ಯವಸ್ಥೆಯ ಮೂಲಕ ರಿಯಾಯಿತಿ ದರದಲ್ಲಿ ಆಹಾರ ಧಾನ್ಯ ಪಡೆಯಬಹುದು, ಇದು ವಿಳಾಸ ಪುರಾವೆಯಾಗಿಯೂ ಬಳಕೆಯಾಗುತ್ತದೆ. ನಿಮ್ಮ ರಾಜ್ಯದ ಆಹಾರ ಮತ್ತು ನಾಗರಿಕ ಸರಬರಾಜು ಇಲಾಖೆ ಪೋರ್ಟಲ್ ಮೂಲಕ ಅರ್ಜಿ ಸಲ್ಲಿಸಿ.",  # NEEDS REVIEW
        "url": "your state's civil supplies / e-Sevai portal",
    },
    "passport": {
        "keywords": [
            "passport", "பாஸ்போர்ட்",
            "पासपोर्ट", "పాస్‌పోర్ట్", "ಪಾಸ್‌ಪೋರ್ಟ್",
        ],
        "en": "Passports are issued by the Ministry of External Affairs. Apply online and book an appointment at your nearest Passport Seva Kendra.",
        "ta": "பாஸ்போர்ட் வெளியுறவு அமைச்சகத்தால் வழங்கப்படுகிறது. ஆன்லைனில் விண்ணப்பித்து அருகிலுள்ள Passport Seva Kendra-வில் appointment எடுக்கலாம்.",
        "hi": "पासपोर्ट विदेश मंत्रालय द्वारा जारी किया जाता है। ऑनलाइन आवेदन करें और अपने नज़दीकी पासपोर्ट सेवा केंद्र पर अपॉइंटमेंट बुक करें।",  # NEEDS REVIEW
        "te": "పాస్‌పోర్ట్‌ను విదేశీ వ్యవహారాల మంత్రిత్వ శాఖ జారీ చేస్తుంది. ఆన్‌లైన్‌లో దరఖాస్తు చేసి సమీప పాస్‌పోర్ట్ సేవా కేంద్రంలో అపాయింట్‌మెంట్ బుక్ చేసుకోండి.",  # NEEDS REVIEW
        "kn": "ಪಾಸ್‌ಪೋರ್ಟ್ ಅನ್ನು ವಿದೇಶಾಂಗ ವ್ಯವಹಾರಗಳ ಸಚಿವಾಲಯ ನೀಡುತ್ತದೆ. ಆನ್‌ಲೈನ್‌ನಲ್ಲಿ ಅರ್ಜಿ ಸಲ್ಲಿಸಿ ಹತ್ತಿರದ ಪಾಸ್‌ಪೋರ್ಟ್ ಸೇವಾ ಕೇಂದ್ರದಲ್ಲಿ ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಕಾಯ್ದಿರಿಸಿ.",  # NEEDS REVIEW
        "url": "passportindia.gov.in",
    },
    "driving_license": {
        "keywords": [
            "driving license", "driving licence", "dl", "ஓட்டுநர் உரிமம்",
            "ड्राइविंग लाइसेंस", "డ్రైవింగ్ లైసెన్స్", "ಚಾಲನಾ ಪರವಾನಗಿ",
        ],
        "en": "A driving license is issued by your state's Regional Transport Office (RTO). You can apply for a learner's license and book your driving test online via the Parivahan portal.",
        "ta": "ஓட்டுநர் உரிமம் உங்கள் மாநில RTO-வால் வழங்கப்படுகிறது. Parivahan போர்ட்டலில் learner's license விண்ணப்பம் மற்றும் driving test appointment ஆன்லைனில் பதிவு செய்யலாம்.",
        "hi": "ड्राइविंग लाइसेंस आपके राज्य के क्षेत्रीय परिवहन कार्यालय (RTO) द्वारा जारी किया जाता है। परिवहन पोर्टल पर लर्नर लाइसेंस के लिए आवेदन और ड्राइविंग टेस्ट की बुकिंग ऑनलाइन कर सकते हैं।",  # NEEDS REVIEW
        "te": "డ్రైవింగ్ లైసెన్స్‌ను మీ రాష్ట్ర ప్రాంతీయ రవాణా కార్యాలయం (RTO) జారీ చేస్తుంది. పరివాహన్ పోర్టల్‌లో లెర్నర్ లైసెన్స్ దరఖాస్తు మరియు డ్రైవింగ్ టెస్ట్ బుకింగ్ ఆన్‌లైన్‌లో చేయవచ్చు.",  # NEEDS REVIEW
        "kn": "ಚಾಲನಾ ಪರವಾನಗಿಯನ್ನು ನಿಮ್ಮ ರಾಜ್ಯದ ಪ್ರಾದೇಶಿಕ ಸಾರಿಗೆ ಕಚೇರಿ (RTO) ನೀಡುತ್ತದೆ. ಪರಿವಾಹನ್ ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಕಲಿಕಾ ಪರವಾನಗಿ ಅರ್ಜಿ ಮತ್ತು ಚಾಲನಾ ಪರೀಕ್ಷೆ ಬುಕಿಂಗ್ ಆನ್‌ಲೈನ್‌ನಲ್ಲಿ ಮಾಡಬಹುದು.",  # NEEDS REVIEW
        "url": "parivahan.gov.in",
    },
}


@dataclass
class GovDocMatch:
    key: str
    # Body text keyed by language code. Always contains "en"; other
    # languages are filled in as they are written and reviewed.
    text: dict
    url: str

    def body(self, language: str) -> str:
        """Body in the requested language, falling back to English."""
        base = (language or "en").split("-", 1)[0]
        return self.text.get(base) or self.text["en"]


# ASCII keywords are matched on word boundaries, not as substrings: the
# short aliases make this essential, since a plain `"dl" in text` matched
# "handle", "middle" and "badly".
#
# Non-ASCII keywords are matched as substrings instead, because Python's
# `\b` relies on `\w`, which excludes the combining marks that Indic words
# routinely end in — `\bஆதார்\b` would never match "ஆதார்". Indic keywords
# don't need the guard anyway; the collision risk is a Latin-alias problem.
def _keyword_pattern(keyword: str) -> "re.Pattern":
    escaped = re.escape(keyword)
    return re.compile(rf"\b{escaped}\b" if keyword.isascii() else escaped)


_GOV_DOC_PATTERNS = {
    key: [_keyword_pattern(kw) for kw in info["keywords"]]
    for key, info in _GOV_DOCS.items()
}


def match_gov_doc(text: str) -> Optional[GovDocMatch]:
    lowered = text.lower()
    for key, patterns in _GOV_DOC_PATTERNS.items():
        info = _GOV_DOCS[key]
        for pattern in patterns:
            if pattern.search(lowered) or pattern.search(text):
                return GovDocMatch(
                    key=key,
                    text={
                        lang: value
                        for lang, value in info.items()
                        if lang not in ("keywords", "url")
                    },
                    url=info["url"],
                )
    return None


# The "confirm this yourself" note is attached to every government-document
# answer in the user's own language, because the body text is a static
# summary that can drift out of date while the official portal cannot.
_GOV_DOC_NOTES = {
    "en": " (This is general information — always confirm the latest process on {url}.)",
    "ta": " (இது பொது தகவல் மட்டுமே — சமீபத்திய நடைமுறையை {url} இல் சரிபார்க்கவும்.)",
    "hi": " (यह सामान्य जानकारी है — नवीनतम प्रक्रिया {url} पर ज़रूर देखें।)",
    "te": " (ఇది సాధారణ సమాచారం — తాజా విధానాన్ని {url} లో నిర్ధారించుకోండి.)",  # NEEDS REVIEW
    "kn": " (ಇದು ಸಾಮಾನ್ಯ ಮಾಹಿತಿ — ಇತ್ತೀಚಿನ ಪ್ರಕ್ರಿಯೆಯನ್ನು {url} ನಲ್ಲಿ ಪರಿಶೀಲಿಸಿ.)",  # NEEDS REVIEW
}


def format_gov_doc_reply(match: GovDocMatch, language: str) -> str:
    """
    Body text plus a localized "verify on the official portal" note.

    All five languages now have bodies. The Hindi, Telugu and Kannada ones
    are marked `# NEEDS REVIEW` in `_GOV_DOCS` and are deliberately
    conservative — they state what the document is and which portal issues
    it, and nothing about eligibility, fees or timelines. Procedural
    government guidance is the category where a translation error does real
    harm, so the note pointing at the official portal is attached to every
    reply regardless of language.
    """
    base = (language or "en").split("-", 1)[0]
    note = _GOV_DOC_NOTES.get(base, _GOV_DOC_NOTES["en"]).format(url=match.url)
    return match.body(language) + note
