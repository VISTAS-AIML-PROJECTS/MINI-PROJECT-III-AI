"""
Answer Contract
=================
Every reply the assistant produces travels as a `DomainAnswer`, not a bare
string. The point is the `sources` field: BharatVoice answers questions
about government schemes, health, and money, where an uncited claim is a
liability. Making citations part of the type means a new domain *cannot*
quietly ship an authoritative-sounding fact with no provenance — the
reviewer sees an empty `sources` list in the diff.

Conventions:
  - Chit-chat and deterministic local computation (greetings, arithmetic,
    unit conversion, the clock) carry no sources. They aren't claims about
    the world that could go stale.
  - Anything sourced from a portal, dataset, or API carries at least one
    `Source` with a `checked_on` date.
  - `is_refusal=True` marks "I don't have a reliable answer for this",
    which is a valid, *desirable* outcome — see `refusal()`. It is tracked
    separately so the evaluation harness can measure how often the
    assistant correctly declines instead of guessing.
"""
from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional


@dataclass(frozen=True)
class Source:
    """Provenance for one factual claim in an answer."""

    title: str
    url: Optional[str] = None
    # The day this information was last confirmed against the source. For
    # curated records this is the review date; for live API responses it is
    # the day the call was made.
    checked_on: Optional[date] = None


@dataclass
class DomainAnswer:
    text: str
    language: str
    sources: List[Source] = field(default_factory=list)
    # How much the assistant trusts this specific answer (distinct from
    # NLU intent confidence, which is about understanding the question).
    confidence: float = 1.0
    # Human-readable freshness note shown alongside live data, e.g.
    # "as of 26 September 2026". None for timeless answers.
    staleness: Optional[str] = None
    is_refusal: bool = False
    # Helpline numbers in `text` that are safe to render as a tap-to-call
    # link. Decided here, on the backend, from the verified list — never
    # guessed by the frontend from the digits, which is how a calculator
    # result of 100 once became a link to the police.
    dialable: List[str] = field(default_factory=list)

    @property
    def is_cited(self) -> bool:
        return bool(self.sources)


def plain(text: str, language: str, confidence: float = 1.0) -> DomainAnswer:
    """An answer that makes no citable claim about the world."""
    return DomainAnswer(text=text, language=language, confidence=confidence)


def refusal(text: str, language: str) -> DomainAnswer:
    """
    An explicit "I can't answer this reliably".

    Phase 2 routes health/scheme/finance misses here rather than letting
    them fall through to a generative guess.
    """
    return DomainAnswer(text=text, language=language, confidence=0.0, is_refusal=True)
