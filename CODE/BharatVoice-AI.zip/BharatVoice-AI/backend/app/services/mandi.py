"""
Mandi Price Service (AGMARKNET via data.gov.in)
=================================================
Daily wholesale market prices for agricultural commodities — the one live
number a farmer actually asks for.

MEASURED STATE OF THIS UPSTREAM, so nobody has to rediscover it:
  - 2026-09-26: `api.data.gov.in` took 45s and then returned 504, then 502,
    on three consecutive attempts.
  - 2026-09-27: reachable in under a second, but the *shared demo key*
    published in data.gov.in's own documentation returns
    `{"error": "Rate limit exceeded"}` (HTTP 429) — everyone's examples use
    it, so it is permanently exhausted.

Both of those are why this module looks the way it does:

  1. It needs your own free data.gov.in API key (`DATA_GOV_API_KEY`).
     Registration takes a minute and the key is free. With no key the
     service reports that it cannot check, and the response generator deep
     links to agmarknet.gov.in — it never invents a price.

     The key lives in one of two files depending on how the backend runs:
     the repository-root `.env` (read by Docker Compose, which forwards the
     variable into the container) or `backend/.env` (read by pydantic
     settings directly). Both are git-ignored. See the README section
     "Turning on live mandi prices". `tests/test_knowledge.py` pins the
     Compose passthrough, because the variable being declared here and in
     `config.py` while Compose dropped it on the floor is a bug that
     already happened once and produced no error anywhere.
  2. Every result is cached, because mandi prices are published once a day
     and the upstream is the slowest dependency in the app.
  3. Every failure mode collapses to None. No key, timeout, 429, 502,
     malformed payload, commodity not traded today — the caller says "I
     couldn't check" in the user's language. A made-up crop price is the
     single most harmful thing this assistant could say to a farmer about
     to load a truck.

HONEST LIMITATION: the field names below are the resource's published
schema (`state`, `district`, `market`, `commodity`, `variety`,
`arrival_date`, `min_price`, `max_price`, `modal_price`). They have NOT
been confirmed against a live 200 response, because no successful call was
possible without a key. The parser is therefore written defensively — any
record missing a price or a market is skipped rather than guessed at — and
the first thing to verify after adding a key is that `get_prices` returns
rows rather than None.

Prices from this dataset are per quintal (100 kg), which is how Indian
mandis quote them.
"""
import json
import logging
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date, datetime
from typing import List, Optional

from app.config import settings

logger = logging.getLogger(__name__)

# "Current Daily Price of Various Commodities from Various Markets (Mandi)"
_RESOURCE_ID = "9ef84268-d588-465a-a308-a864a43d0070"
_API_URL = f"https://api.data.gov.in/resource/{_RESOURCE_ID}"

SOURCE_TITLE = "AGMARKNET (Directorate of Marketing & Inspection) via data.gov.in"
SOURCE_URL = "https://agmarknet.gov.in"
PORTAL = "agmarknet.gov.in"

# Prices are published once a day, so an hour of cache costs nothing in
# freshness and saves every repeat question in a demo or a classroom.
_TTL_SECONDS = 60 * 60
_cache: dict = {}

# Rows to show. More than a handful is unreadable when spoken aloud.
_MAX_ROWS = 4


@dataclass
class MandiPrice:
    commodity: str
    market: str
    district: str
    state: str
    min_price: float
    max_price: float
    modal_price: float
    arrival_date: Optional[str] = None  # as published, dd/mm/yyyy
    unit: str = "quintal"


# Crops the assistant can look up. The dict key is the name AGMARKNET
# indexes (which is sometimes not a name anyone would say —
# "Paddy(Dhan)(Common)"), and the per-language values are both the surfaces
# to match on *and* the name to display back. Displaying the key would put
# the dataset's internal spelling in front of a farmer.
#
# Deliberately short: the crops that dominate south and north Indian mandi
# queries. An unlisted crop returns None from `commodity_in_text`, and the
# response generator asks which crop rather than guessing one.
_COMMODITIES = {
    "tomato": {"en": "tomato", "ta": "தக்காளி", "hi": "टमाटर", "te": "టమాటా", "kn": "ಟೊಮೇಟೊ"},
    "onion": {"en": "onion", "ta": "வெங்காயம்", "hi": "प्याज", "te": "ఉల్లి", "kn": "ಈರುಳ್ಳಿ"},
    "potato": {"en": "potato", "ta": "உருளைக்கிழங்கு", "hi": "आलू",
               "te": "బంగాళాదుంప", "kn": "ಆಲೂಗಡ್ಡೆ"},
    "rice": {"en": "rice", "ta": "அரிசி", "hi": "चावल", "te": "బియ్యం", "kn": "ಅಕ್ಕಿ"},
    "paddy(dhan)(common)": {"en": "paddy", "ta": "நெல்", "hi": "धान",
                            "te": "వరి", "kn": "ಭತ್ತ"},
    "wheat": {"en": "wheat", "ta": "கோதுமை", "hi": "गेहूं", "te": "గోధుమ", "kn": "ಗೋಧಿ"},
    "banana": {"en": "banana", "ta": "வாழை", "hi": "केला", "te": "అరటి", "kn": "ಬಾಳೆ"},
    "coconut": {"en": "coconut", "ta": "தேங்காய்", "hi": "नारियल",
                "te": "కొబ్బరి", "kn": "ತೆಂಗಿನಕಾಯಿ"},
    "sugarcane": {"en": "sugarcane", "ta": "கரும்பு", "hi": "गन्ना",
                  "te": "చెరకు", "kn": "ಕಬ್ಬು"},
    "cotton": {"en": "cotton", "ta": "பருத்தி", "hi": "कपास", "te": "పత్తి", "kn": "ಹತ್ತಿ"},
    "turmeric": {"en": "turmeric", "ta": "மஞ்சள்", "hi": "हल्दी",
                 "te": "పసుపు", "kn": "ಅರಿಶಿನ"},
    "green chilli": {"en": "green chilli", "ta": "மிளகாய்", "hi": "मिर्च",
                     "te": "మిర్చి", "kn": "ಮೆಣಸಿನಕಾಯಿ",
                     "aliases": ["chilli", "chili"]},
    "brinjal": {"en": "brinjal", "ta": "கத்தரிக்காய்", "hi": "बैंगन",
                "te": "వంకాయ", "kn": "ಬದನೆ"},
    "groundnut": {"en": "groundnut", "ta": "நிலக்கடலை", "hi": "मूंगफली",
                  "te": "వేరుశనగ", "kn": "ಶೇಂಗಾ"},
}


def localized_name(commodity: str, language: str) -> str:
    """
    The crop's name in the user's language, for echoing back in a reply.

    Falls back to English, then to the commodity string itself — so an
    unlisted crop still reads sensibly rather than raising.
    """
    names = _COMMODITIES.get(commodity)
    if not names:
        return commodity
    base = (language or "en").split("-", 1)[0]
    return names.get(base) or names["en"]

# ASCII surfaces are matched on word boundaries, not as substrings. This is
# not theoretical: "rice" is inside "price", so a bare containment check
# read "what's the mandi price" as a query about rice and answered a
# question the user hadn't asked. Non-ASCII surfaces stay substring matches
# for the usual reason — Python's `\b` is defined via `\w`, which excludes
# the combining marks Indic words end in.
#
# Longest surface first so "green chilli" is not shadowed by "chilli".
def _surface_pattern(surface: str) -> "re.Pattern":
    escaped = re.escape(surface)
    return re.compile(rf"\b{escaped}\b" if surface.isascii() else escaped)


def _surfaces_of(names: dict) -> List[str]:
    return [value for key, value in names.items() if key != "aliases"] + list(
        names.get("aliases", [])
    )


_COMMODITY_SURFACES = sorted(
    ((surface.lower(), canonical, _surface_pattern(surface.lower()))
     for canonical, names in _COMMODITIES.items()
     for surface in _surfaces_of(names)),
    key=lambda row: -len(row[0]),
)


def api_key_configured() -> bool:
    """
    Whether a usable key is present.

    Kept public so the response generator can distinguish "not configured"
    from "upstream failed" — the two need different replies, and conflating
    them is how a setup problem gets misreported as an outage.
    """
    return bool((settings.data_gov_api_key or "").strip())


def commodity_in_text(text: str) -> Optional[str]:
    """The AGMARKNET commodity name mentioned in the text, or None."""
    if not text:
        return None
    lowered = text.lower()
    for surface, canonical, pattern in _COMMODITY_SURFACES:
        if pattern.search(lowered) or pattern.search(text):
            return canonical
        # Indic agglutination: "தக்காளி விலை" matches directly, but a
        # case-marked form ("ಟೊಮೇಟೊದ") needs the stem. Same fallback the
        # place matcher uses.
        if not surface.isascii() and len(surface) > 4 and surface[:-1] in text:
            return canonical
    return None


def _fetch_json(params: dict) -> Optional[dict]:
    full_url = f"{_API_URL}?{urllib.parse.urlencode(params)}"
    try:
        request = urllib.request.Request(
            full_url, headers={"User-Agent": "BharatVoice-AI/1.0"}
        )
        with urllib.request.urlopen(request, timeout=settings.http_timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # Measured 2026-09-27: data.gov.in answers a key it doesn't recognise
        # with HTTP 403, and an exhausted one with HTTP 200 carrying
        # {"error": "Rate limit exceeded"} (handled below). The reply to the
        # user is the same honest refusal either way, but the log has to tell
        # the two apart — otherwise "I typed my key in wrong" and "the portal
        # is down" look identical to whoever is setting this up, and the
        # first one is the far more likely of the two.
        if exc.code in (401, 403):
            logger.error(
                "data.gov.in rejected DATA_GOV_API_KEY (HTTP %s). Check the key: "
                "root .env under Docker Compose, backend/.env for a direct run.",
                exc.code,
            )
        else:
            logger.warning("Mandi price lookup failed: HTTP %s from data.gov.in",
                           exc.code)
        return None
    except Exception:
        logger.warning("Mandi price lookup failed", exc_info=True)
        return None

    # data.gov.in answers rate limiting and bad keys with HTTP 200 and an
    # {"error": ...} body, so a successful request is not a successful
    # lookup. Treating this as data would surface "Rate limit exceeded" to
    # a farmer as if it were a price.
    if not isinstance(payload, dict) or payload.get("error"):
        logger.warning("Mandi price upstream returned an error: %s",
                       (payload or {}).get("error") if isinstance(payload, dict) else payload)
        return None
    return payload


def _to_float(value) -> Optional[float]:
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    # The dataset uses 0 and negative values as "not reported". A zero
    # modal price rendered as "₹0 per quintal" reads as a crash in prices.
    return number if number > 0 else None


def _parse_records(records: list, commodity: str) -> List[MandiPrice]:
    prices: List[MandiPrice] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        modal = _to_float(record.get("modal_price"))
        low = _to_float(record.get("min_price"))
        high = _to_float(record.get("max_price"))
        market = (record.get("market") or "").strip()
        if modal is None or not market:
            continue
        prices.append(
            MandiPrice(
                commodity=(record.get("commodity") or commodity).strip(),
                market=market,
                district=(record.get("district") or "").strip(),
                state=(record.get("state") or "").strip(),
                min_price=low if low is not None else modal,
                max_price=high if high is not None else modal,
                modal_price=modal,
                arrival_date=(record.get("arrival_date") or "").strip() or None,
            )
        )
    return prices


def get_prices(commodity: str, state: Optional[str] = None) -> Optional[List[MandiPrice]]:
    """
    Today's mandi prices for a commodity, or None if they can't be obtained.

    None covers every failure: no API key, timeout, rate limit, upstream
    5xx, unparseable payload, and "the dataset has no rows for this
    commodity today" (common for crops out of season). Callers must say so
    rather than substituting yesterday's figure or a national average.
    """
    if not commodity:
        return None
    if not api_key_configured():
        logger.info("Mandi price lookup skipped: DATA_GOV_API_KEY is not set")
        return None

    cache_key = (commodity.lower(), (state or "").lower())
    cached = _cache.get(cache_key)
    if cached and time.time() - cached[0] < _TTL_SECONDS:
        return cached[1]

    params = {
        "api-key": settings.data_gov_api_key,
        "format": "json",
        "limit": 50,
        "filters[commodity]": commodity.title() if commodity.isascii() else commodity,
    }
    if state:
        params["filters[state]"] = state

    payload = _fetch_json(params)
    records = (payload or {}).get("records")
    if not isinstance(records, list) or not records:
        return None

    prices = _parse_records(records, commodity)
    if not prices:
        return None

    # Cheapest modal price first: the useful ordering for someone deciding
    # where to sell is by price, not by the dataset's own row order.
    prices.sort(key=lambda row: row.modal_price)
    prices = prices[:_MAX_ROWS]
    _cache[cache_key] = (time.time(), prices)
    return prices


def checked_on() -> date:
    """The date to stamp on the citation — today, since this is a live call."""
    return datetime.now().date()


def clear_caches() -> None:
    _cache.clear()
