"""
Hospital Lookup (National Hospital Directory via data.gov.in)
===============================================================
"Hospitals in Madurai" answered with a short list of names and phone
numbers, instead of a link and an apology.

Of the three lookups that used to be links only — jobs, health facilities
and schemes — this is the one with a lawful, documented public source: the
National Hospital Directory is published as an open dataset on data.gov.in
and is served by the same API, and the same free key, as mandi prices.
The other two still have no public API (see README, "Known gaps").

>>> STATUS: IMPLEMENTED BUT NEVER EXECUTED AGAINST THE REAL SERVICE. <<<

Exactly as with services/mandi.py, no successful call has been made:
there was no API key, and on the day this was written (2026-10-06)
`api.data.gov.in` answered every request with HTTP 503. So two things are
unverified and both are isolated:

  - the resource id, `HOSPITAL_RESOURCE_ID` in settings. If data.gov.in
    has re-published the directory under a new id, change the setting.
  - the field names. `_FIELDS` lists the spellings to try for each value;
    a record with no recognisable name is skipped, never guessed at.

WHAT THIS IS NOT. The directory is a registry, updated irregularly. It
says a hospital exists and gives a number someone once supplied. It does
not say the hospital is open now, has a bed, or treats a given condition.
Every reply built from it says so and points at 108 for emergencies, and
the curated answer (knowledge.py) remains the fallback whenever this
returns None.

Same failure rule as every live adapter here: no key, timeout, HTTP error,
an `{"error": ...}` body, unknown fields, no rows — all None.
"""
import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date, datetime
from typing import List, Optional

from app.config import settings

logger = logging.getLogger(__name__)

SOURCE_TITLE = "National Hospital Directory via data.gov.in"
SOURCE_URL = "https://data.gov.in"

# A registry changes slowly; a day of cache is invisible to the user.
_TTL_SECONDS = 24 * 60 * 60
_cache: dict = {}

# Enough to be useful, few enough to be read aloud.
_MAX_ROWS = 5

# Candidate spellings per value, tried in order, compared case-insensitively
# with underscores and spaces ignored. Unverified — see the module docstring.
_FIELDS = {
    "name": ("hospital_name", "hospitalname", "name", "facility_name"),
    "district": ("district", "district_name"),
    "state": ("state", "state_name"),
    "address": ("_address_original_first_line", "address_original_first_line", "address", "location"),
    "phone": ("telephone", "mobile_number", "emergency_num", "phone", "contact"),
    "category": ("hospital_category", "category", "hospital_care_type"),
}


@dataclass(frozen=True)
class Hospital:
    name: str
    district: str = ""
    address: str = ""
    phone: str = ""
    category: str = ""


def is_configured() -> bool:
    return bool((settings.data_gov_api_key or "").strip()) and bool(
        (settings.hospital_resource_id or "").strip()
    )


def _squash(key: str) -> str:
    return "".join(ch for ch in str(key).lower() if ch.isalnum())


def _value(record: dict, field: str) -> str:
    squashed = {_squash(key): value for key, value in record.items()}
    for candidate in _FIELDS[field]:
        value = squashed.get(_squash(candidate))
        if value is None:
            continue
        text = str(value).strip()
        # The dataset writes missing values as "NA", "0" or "-".
        if text and text.upper() not in ("NA", "N/A", "NULL", "NONE", "0", "-"):
            return text
    return ""


def _parse_records(records: list) -> List[Hospital]:
    hospitals: List[Hospital] = []
    seen = set()
    for record in records:
        if not isinstance(record, dict):
            continue
        name = _value(record, "name")
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        hospitals.append(
            Hospital(
                name=name,
                district=_value(record, "district"),
                address=_value(record, "address"),
                # Several numbers are often packed into one field; the first
                # is enough to call, and keeps the line readable.
                phone=_value(record, "phone").split(",")[0].strip(),
                category=_value(record, "category"),
            )
        )
    return hospitals


def _fetch(filters: dict) -> Optional[list]:
    params = {"api-key": settings.data_gov_api_key, "format": "json", "limit": 25}
    params.update({f"filters[{field}]": value for field, value in filters.items()})
    url = (
        f"https://api.data.gov.in/resource/{settings.hospital_resource_id.strip()}"
        f"?{urllib.parse.urlencode(params)}"
    )
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "BharatVoice-AI/1.0"})
        with urllib.request.urlopen(request, timeout=settings.http_timeout_seconds) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # Never log the URL: the API key is in its query string.
        logger.warning("Hospital lookup failed: HTTP %s from data.gov.in", exc.code)
        return None
    except Exception as exc:
        logger.warning("Hospital lookup failed: %s", type(exc).__name__)
        return None

    # data.gov.in reports a bad or exhausted key as HTTP 200 with an error
    # body (see services/mandi.py), so a 200 is not yet a result.
    if not isinstance(payload, dict) or payload.get("error"):
        logger.warning("Hospital lookup: upstream returned an error body")
        return None
    records = payload.get("records")
    return records if isinstance(records, list) else None


def find_hospitals(place: str) -> Optional[List[Hospital]]:
    """
    Hospitals the directory lists for a district, or None.

    None is every kind of "no usable answer", including a place the
    directory has no rows for. The caller falls back to the curated answer.
    """
    if not place or not place.strip() or not is_configured():
        return None

    key = place.strip().lower()
    cached = _cache.get(key)
    if cached and time.time() - cached[0] < _TTL_SECONDS:
        return cached[1]

    records = _fetch({"district": place.strip().title()})
    hospitals = _parse_records(records or [])[:_MAX_ROWS]
    if not hospitals:
        return None

    _cache[key] = (time.time(), hospitals)
    return hospitals


def checked_on() -> date:
    return datetime.now().date()


def clear_caches() -> None:
    _cache.clear()
