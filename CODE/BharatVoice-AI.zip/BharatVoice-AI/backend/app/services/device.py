"""
Shared device-resolution helper for local ML inference (Whisper, MuRIL,
IndicTrans2, Coqui). Centralized so every service picks CUDA consistently
when available, without duplicating the same `torch.cuda.is_available()`
check five times.
"""
from app.config import settings


def resolve_device() -> str:
    """
    Returns "cuda" or "cpu" based on `settings.ml_device`:
      - "auto" (default): CUDA if available, else CPU
      - "cuda" / "cpu": forced explicitly (useful for testing/debugging)
    """
    if settings.ml_device in ("cuda", "cpu"):
        return settings.ml_device

    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"
