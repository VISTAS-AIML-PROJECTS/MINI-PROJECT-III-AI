"""
Weather Service
=================
Live weather from Open-Meteo, which needs no API key and permits
non-commercial use — the two properties that matter for a project that has
to run on a marker's machine without credentials.

Why not IMD: the India Meteorological Department is the authoritative
source for Indian forecasts and warnings, and it should be added for
cyclone/heat/nowcast alerts. But `api.imd.gov.in` returns
`401 {"error": "API key missing"}` without registration, so it cannot be
the default in a project anyone should be able to clone and run.

Design rules, which exist because this is the first genuinely *changing*
fact the assistant reports:
  - Every answer carries the source and the time it was fetched. A
    temperature with no timestamp is indistinguishable from a stale one.
  - A failed lookup is reported as a failure, never filled in with a
    plausible number. The previous implementation returned an invented
    "sunny, around 32°C", which is precisely the behaviour this service
    exists to remove.
  - Responses are cached, because a farmer asking twice in five minutes
    should not cost two API calls, and because the upstream can be slow.
  - Only the standard library is used, so no new dependency is introduced.
"""
import json
import logging
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from app.config import settings

logger = logging.getLogger(__name__)

_GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

SOURCE_TITLE = "Open-Meteo"
SOURCE_URL = "https://open-meteo.com"

# Cheap in-process caches. A real deployment would use Redis; for a single
# backend process a dict with timestamps is the right amount of machinery.
_geocode_cache: dict = {}
_forecast_cache: dict = {}

# Place names change essentially never; weather changes slowly enough that
# half an hour of staleness is invisible to a user and saves most calls.
_GEOCODE_TTL_SECONDS = 24 * 60 * 60
_FORECAST_TTL_SECONDS = 30 * 60


@dataclass
class WeatherResult:
    place: str
    temperature_c: float
    feels_like_c: Optional[float]
    condition: str  # key into the localized condition table
    observed_at: datetime  # UTC
    # The district the place sits in, when the geocoder says. IMD publishes
    # warnings by district, not by town (services/imd.py).
    district: Optional[str] = None
    source_title: str = SOURCE_TITLE
    source_url: str = SOURCE_URL


# WMO weather interpretation codes, collapsed to a handful of buckets we
# can translate well. Precision beyond this ("light drizzle" vs "moderate
# drizzle") is not worth five translations of each variant.
def _condition_for_code(code: int) -> str:
    if code == 0:
        return "clear"
    if code in (1, 2, 3):
        return "cloudy"
    if code in (45, 48):
        return "fog"
    if code in (51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82):
        return "rain"
    if code in (71, 73, 75, 77, 85, 86):
        return "snow"
    if code in (95, 96, 99):
        return "thunderstorm"
    return "unknown"


def _fetch_json(url: str, params: dict) -> Optional[dict]:
    """GET returning parsed JSON, or None on any failure."""
    full_url = f"{url}?{urllib.parse.urlencode(params)}"
    try:
        request = urllib.request.Request(
            full_url, headers={"User-Agent": "BharatVoice-AI/1.0"}
        )
        with urllib.request.urlopen(request, timeout=settings.http_timeout_seconds) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception:
        # Network down, upstream 5xx, timeout, malformed JSON — all handled
        # identically by the caller, which reports "couldn't check".
        logger.warning("Weather lookup failed for %s", url, exc_info=True)
        return None


def geocode(place: str) -> Optional[dict]:
    """Resolve a place name to {name, latitude, longitude}, or None."""
    key = place.strip().lower()
    cached = _geocode_cache.get(key)
    if cached and time.time() - cached[0] < _GEOCODE_TTL_SECONDS:
        return cached[1]

    data = _fetch_json(
        _GEOCODE_URL,
        {"name": place, "count": 1, "language": "en", "format": "json", "country": "IN"},
    )
    results = (data or {}).get("results") or []
    if not results:
        return None

    top = results[0]
    resolved = {
        "name": top.get("name") or place,
        "latitude": top["latitude"],
        "longitude": top["longitude"],
        "district": top.get("admin2"),
    }
    _geocode_cache[key] = (time.time(), resolved)
    return resolved


def get_weather(place: str) -> Optional[WeatherResult]:
    """
    Current conditions for a named place, or None if it can't be determined.

    None is a normal outcome — unknown place, network down, upstream
    unavailable — and callers must render it as "I couldn't check", never
    as a guess.
    """
    if not place or not place.strip():
        return None

    key = place.strip().lower()
    cached = _forecast_cache.get(key)
    if cached and time.time() - cached[0] < _FORECAST_TTL_SECONDS:
        return cached[1]

    location = geocode(place)
    if location is None:
        return None

    data = _fetch_json(
        _FORECAST_URL,
        {
            "latitude": location["latitude"],
            "longitude": location["longitude"],
            "current": "temperature_2m,apparent_temperature,weather_code",
            "timezone": "Asia/Kolkata",
        },
    )
    current = (data or {}).get("current") or {}
    if "temperature_2m" not in current:
        return None

    result = WeatherResult(
        place=location["name"],
        temperature_c=round(float(current["temperature_2m"]), 1),
        feels_like_c=(
            round(float(current["apparent_temperature"]), 1)
            if current.get("apparent_temperature") is not None
            else None
        ),
        condition=_condition_for_code(int(current.get("weather_code", -1))),
        observed_at=datetime.now(timezone.utc),
        district=location.get("district"),
    )
    _forecast_cache[key] = (time.time(), result)
    return result


def clear_caches() -> None:
    """Used by tests; also handy from a REPL when debugging staleness."""
    _geocode_cache.clear()
    _forecast_cache.clear()
