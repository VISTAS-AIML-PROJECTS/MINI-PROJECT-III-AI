"""
NLU Pipeline Orchestrator
============================
Runs the full understanding pipeline on a piece of user text:
  language detection -> intent detection -> entity extraction

Used by the /api/chat endpoint so routers stay thin and the pipeline order
is defined in exactly one place.
"""
from dataclasses import dataclass
from typing import List

from app.services.entity_extraction import ExtractedEntity, extract_entities
from app.services.intent_detection import detect_intent
from app.services.language_detection import detect_language


@dataclass
class NluOutput:
    language: str
    language_confidence: float
    intent: str
    intent_confidence: float
    entities: List[ExtractedEntity]


def run_nlu(text: str, language_hint: str | None = None) -> NluOutput:
    lang_result = detect_language(text)
    language = language_hint or lang_result.language

    intent_result = detect_intent(text, language=language)
    entities = extract_entities(text, language=language)

    return NluOutput(
        language=language,
        language_confidence=lang_result.confidence,
        intent=intent_result.intent,
        intent_confidence=intent_result.confidence,
        entities=entities,
    )
