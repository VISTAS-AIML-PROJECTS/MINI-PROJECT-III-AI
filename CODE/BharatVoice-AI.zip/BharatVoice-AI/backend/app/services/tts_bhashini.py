"""
Bhashini Text-to-Speech Provider
==================================
Server-side speech synthesis for all five supported languages, used when
the user's device has no voice installed for the reply language.

WHY THIS EXISTS
---------------
The browser's own `speechSynthesis` is the fast path and stays the first
choice: it is instant, free and needs no network. But Indic voices are not
installed by default on most desktops. The demo machine for this project
was measured carrying five voices, all English, zero Indic — so a Tamil
reply was silent with no explanation. Coqui XTTS-v2, the other provider in
`text_to_speech.py`, cannot fix that either: its language set contains
Hindi but no Tamil, Telugu or Kannada.

Bhashini (MeitY's national speech stack) covers en, hi, ta, te and kn,
which is exactly the set this app claims to support.

>>> STATUS: IMPLEMENTED BUT NEVER EXECUTED AGAINST THE REAL SERVICE. <<<

No ULCA credentials were available when this was written, so every line
below is written from Bhashini's published two-step protocol and NOT from
an observed response. Treat the field names as unverified:

    pipelineInferenceAPIEndPoint.callbackUrl
    pipelineInferenceAPIEndPoint.inferenceApiKey.{name,value}
    pipelineResponseConfig[0].config[0].serviceId
    pipelineResponse[0].audio[0].audioContent   (base64)

If synthesis returns None with credentials set, log level DEBUG on this
module prints the payload shape actually received — that is the first
place to look, and `_extract_audio` is deliberately the only place these
names appear so a schema correction is a one-function change.

THE PROTOCOL, in two calls:

  1. POST `bhashini_auth_url` with the ULCA headers, asking for a `tts`
     pipeline in the target language. The answer contains the inference
     endpoint, a short-lived inference key, and the service id to use.
  2. POST that endpoint with the service id and the text. The answer
     contains base64 WAV audio.

Step 1 is cached per language, because it is pure configuration and
repeating it would double the latency of every spoken reply.

DESIGN RULES, same discipline as the mandi adapter:

  - Every failure returns None. No credentials, timeout, HTTP error,
    rejected key, unparseable payload, empty audio. The caller then falls
    back to the browser voice, or tells the user plainly that the reply
    cannot be read aloud here. Silence with no explanation is the one
    outcome this whole module exists to prevent.
  - It never substitutes a different language. Speaking a Tamil answer
    with a Hindi voice is worse than not speaking it, because the user
    cannot tell it happened.
  - The credentials are never logged, never returned, and never included
    in an error message surfaced to a user.
"""
import base64
import json
import logging
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Optional

from app.config import settings

logger = logging.getLogger(__name__)

# The languages Bhashini's TTS covers that this app also supports. Kept
# explicit rather than "everything": a language absent here must fail the
# capability check up front, so the UI can say "no voice available" instead
# of firing a request that will fail.
SUPPORTED_LANGUAGES = ("en", "hi", "ta", "te", "kn")

PROVIDER = "bhashini"
SERVICE_TITLE = "Bhashini (MeitY, Government of India)"
SERVICE_URL = "https://bhashini.gov.in"

AUDIO_OUTPUT_DIR = Path(__file__).resolve().parent.parent.parent / "static" / "audio"

# Step-1 results, keyed by language. Cleared by `clear_caches()` in tests.
_pipeline_cache: dict = {}


def is_configured() -> bool:
    """
    Whether both ULCA credentials are present.

    Public so the capability endpoint can distinguish "no key" from "the
    service failed" — the two need different words in the UI, and
    conflating them turns a setup step into an apparent outage.
    """
    return bool(
        (settings.bhashini_user_id or "").strip()
        and (settings.bhashini_api_key or "").strip()
    )


def supports(language: str) -> bool:
    return _base(language) in SUPPORTED_LANGUAGES


def _base(language: str) -> str:
    """
    The language subtag Bhashini expects.

    Code-mixed markers ("ta-en") carry a base language, and that is the
    right voice for them: an Indic voice reads the Indic words correctly
    and the English words passably, where an English voice mangles both.
    """
    return (language or "en").split("-", 1)[0].lower()


def _post_json(url: str, payload: dict, headers: dict) -> Optional[dict]:
    """POST JSON, return the parsed body, or None on any failure."""
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json", **headers},
        method="POST",
    )
    try:
        with urllib.request.urlopen(
            request, timeout=settings.bhashini_timeout_seconds
        ) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # 401/403 is the overwhelmingly likely failure for a fresh account:
        # a mistyped key, or one whose ULCA registration is still pending.
        # Say which, without echoing the credentials.
        if exc.code in (401, 403):
            logger.error(
                "Bhashini rejected the ULCA credentials (HTTP %s). Check "
                "BHASHINI_USER_ID and BHASHINI_API_KEY, and that the account "
                "is approved for the TTS pipeline.",
                exc.code,
            )
        else:
            logger.warning("Bhashini returned HTTP %s for %s", exc.code, url)
        return None
    except Exception:
        logger.warning("Bhashini request failed", exc_info=True)
        return None


def _resolve_pipeline(language: str) -> Optional[dict]:
    """
    Step 1: exchange the ULCA credentials for an inference endpoint, a
    short-lived key and a service id for this language.

    Cached per language — it is configuration, not data, and paying for it
    on every reply would double the latency the user hears.
    """
    cached = _pipeline_cache.get(language)
    if cached:
        return cached

    payload = {
        "pipelineTasks": [
            {"taskType": "tts", "config": {"language": {"sourceLanguage": language}}}
        ],
        "pipelineRequestConfig": {"pipelineId": settings.bhashini_pipeline_id},
    }
    headers = {
        "userID": settings.bhashini_user_id,
        "ulcaApiKey": settings.bhashini_api_key,
    }

    body = _post_json(settings.bhashini_auth_url, payload, headers)
    if not isinstance(body, dict):
        return None

    try:
        endpoint = body["pipelineInferenceAPIEndPoint"]
        inference_key = endpoint["inferenceApiKey"]
        resolved = {
            "url": endpoint["callbackUrl"],
            "header_name": inference_key["name"],
            "header_value": inference_key["value"],
            "service_id": body["pipelineResponseConfig"][0]["config"][0]["serviceId"],
        }
    except (KeyError, IndexError, TypeError):
        # Schema drift, or an error body shaped nothing like a pipeline.
        # Log the *keys* only: the response carries an inference key, and
        # dumping the whole body would put a credential in the log file.
        logger.warning(
            "Bhashini pipeline response was not in the expected shape; top-level keys: %s",
            sorted(body.keys()) if isinstance(body, dict) else type(body).__name__,
        )
        return None

    _pipeline_cache[language] = resolved
    return resolved


def _extract_audio(body: dict) -> Optional[bytes]:
    """
    Pull the base64 WAV out of a compute response.

    The single place Bhashini's response field names appear, because they
    are unverified against a live call — a schema correction should be a
    change to this function and nothing else.
    """
    try:
        encoded = body["pipelineResponse"][0]["audio"][0]["audioContent"]
    except (KeyError, IndexError, TypeError):
        logger.warning(
            "Bhashini synthesis response had no audioContent; top-level keys: %s",
            sorted(body.keys()) if isinstance(body, dict) else type(body).__name__,
        )
        return None

    if not encoded:
        return None
    try:
        return base64.b64decode(encoded)
    except Exception:
        logger.warning("Bhashini audioContent was not valid base64", exc_info=True)
        return None


def synthesize(text: str, language: str) -> Optional[str]:
    """
    Synthesize `text` and return a URL under /static/audio, or None.

    None means "could not synthesize" for every reason — no credentials,
    unsupported language, either HTTP call failing, junk payload, empty
    audio. The caller must then use a device voice or say plainly that the
    reply cannot be spoken here. It must never fall back to a different
    language.
    """
    if not text or not text.strip():
        return None
    if not is_configured():
        logger.debug("Bhashini synthesis skipped: no ULCA credentials configured")
        return None

    base = _base(language)
    if base not in SUPPORTED_LANGUAGES:
        logger.info("Bhashini has no TTS for %r; not substituting another language", base)
        return None

    pipeline = _resolve_pipeline(base)
    if pipeline is None:
        return None

    payload = {
        "pipelineTasks": [
            {
                "taskType": "tts",
                "config": {
                    "language": {"sourceLanguage": base},
                    "serviceId": pipeline["service_id"],
                    "gender": settings.bhashini_voice_gender,
                    "samplingRate": 22050,
                },
            }
        ],
        "inputData": {"input": [{"source": text}]},
    }

    body = _post_json(
        pipeline["url"], payload, {pipeline["header_name"]: pipeline["header_value"]}
    )
    if not isinstance(body, dict):
        # The cached pipeline may have expired — the inference key is
        # short-lived. Drop it so the next attempt re-authenticates rather
        # than reusing a dead key forever.
        _pipeline_cache.pop(base, None)
        return None

    audio = _extract_audio(body)
    if not audio:
        return None

    AUDIO_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"{uuid.uuid4()}.wav"
    try:
        (AUDIO_OUTPUT_DIR / filename).write_bytes(audio)
    except OSError:
        logger.warning("Could not write synthesized audio to disk", exc_info=True)
        return None

    return f"/static/audio/{filename}"


def clear_caches() -> None:
    _pipeline_cache.clear()
