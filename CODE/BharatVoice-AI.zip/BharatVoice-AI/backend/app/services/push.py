"""
Web Push for Reminders
========================
Delivers a due reminder as a system notification, so it arrives when the
BharatVoice tab is closed — which is when a reminder is most needed.

HOW IT FITS TOGETHER

  1. The browser registers a service worker (frontend/public/sw.js) and
     asks the user for notification permission. It then sends its push
     subscription to POST /api/push/subscribe.
  2. A background thread here wakes every few seconds, finds reminders that
     are due and whose owner has a subscription, and sends each one through
     the browser vendor's push service.
  3. The service worker receives it and shows the notification — or, if the
     app is open and visible, hands it to the page so the existing in-app
     alert and spoken reminder are used instead.

The in-page poll (GET /api/reminders/due) is unchanged and still covers
anyone who has not enabled notifications. A reminder is marked notified by
whichever path reaches it first, so it fires once.

WHAT THIS DOES NOT DO, so nobody is surprised:

  - It needs the backend to be running at the due time, and the device to
    be online. A laptop that is asleep gets the notification when it wakes.
  - On desktop the browser itself must be running (a closed tab is fine, a
    closed browser usually is not, unless it is set to run in background).
  - Browsers only allow push from https:// or http://localhost.

KEYS. Push messages are signed with a VAPID key pair. If none is supplied
through settings, one is generated on first use and saved to
`vapid_keys_path`, so a fresh clone works without a setup step. The file is
git-ignored: the private key in it is a credential.

SAFETY. A subscription's `endpoint` is a URL the client supplies and this
server later POSTs to, so it is restricted to the real push services. An
arbitrary URL there would let anyone make the backend send requests to
hosts of their choosing.
"""
import base64
import json
import logging
import threading
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

from app import models
from app.config import settings
from app.models import utcnow

logger = logging.getLogger(__name__)

try:
    from pywebpush import WebPushException, webpush
    _HAS_WEBPUSH = True
except ImportError:  # pragma: no cover - exercised only without the package
    _HAS_WEBPUSH = False

# The push services browsers actually use: Chrome/Edge/Android (FCM),
# Firefox (Mozilla autopush), Windows (WNS) and Safari (Apple).
_ALLOWED_PUSH_HOSTS = (
    "fcm.googleapis.com",
    ".push.services.mozilla.com",
    ".notify.windows.com",
    ".push.apple.com",
)

_keys_lock = threading.Lock()
_keys: Optional[dict] = None


def is_allowed_endpoint(endpoint: str) -> bool:
    try:
        parsed = urlparse(endpoint or "")
    except ValueError:
        return False
    if parsed.scheme != "https" or not parsed.hostname:
        return False
    host = parsed.hostname.lower()
    return any(
        host == allowed.lstrip(".") or (allowed.startswith(".") and host.endswith(allowed))
        for allowed in _ALLOWED_PUSH_HOSTS
    )


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def generate_keys() -> dict:
    """A new VAPID pair in the two encodings the web-push protocol uses:
    the raw private scalar and the uncompressed public point, base64url."""
    private_key = ec.generate_private_key(ec.SECP256R1())
    private_raw = private_key.private_numbers().private_value.to_bytes(32, "big")
    public_raw = private_key.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint
    )
    return {"private": _b64url(private_raw), "public": _b64url(public_raw)}


def get_keys() -> Optional[dict]:
    """
    The VAPID keys: from settings, else from the key file, else freshly
    generated and saved. None if push cannot work in this install.
    """
    global _keys
    if not _HAS_WEBPUSH:
        return None

    with _keys_lock:
        if _keys is not None:
            return _keys

        if settings.vapid_private_key.strip() and settings.vapid_public_key.strip():
            _keys = {
                "private": settings.vapid_private_key.strip(),
                "public": settings.vapid_public_key.strip(),
            }
            return _keys

        path = Path(settings.vapid_keys_path)
        try:
            if path.exists():
                loaded = json.loads(path.read_text(encoding="utf-8"))
                if loaded.get("private") and loaded.get("public"):
                    _keys = {"private": loaded["private"], "public": loaded["public"]}
                    return _keys
            generated = generate_keys()
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(generated), encoding="utf-8")
            _keys = generated
            return _keys
        except (OSError, ValueError):
            # An unwritable directory must not take the whole app down; it
            # just means reminders stay in-page only.
            logger.warning("Could not load or save VAPID keys at %s", path, exc_info=True)
            return None


def reset_keys_cache() -> None:
    global _keys
    with _keys_lock:
        _keys = None


def is_enabled() -> bool:
    return get_keys() is not None


def public_key() -> Optional[str]:
    keys = get_keys()
    return keys["public"] if keys else None


def _send(subscription: models.PushSubscription, payload: dict) -> str:
    """
    Send one push. Returns "sent", "gone" (the browser dropped this
    subscription and it should be deleted) or "failed" (try again later).
    """
    keys = get_keys()
    if keys is None:
        return "failed"
    try:
        webpush(
            subscription_info={
                "endpoint": subscription.endpoint,
                "keys": {"p256dh": subscription.p256dh, "auth": subscription.auth},
            },
            data=json.dumps(payload, ensure_ascii=False),
            vapid_private_key=keys["private"],
            vapid_claims={"sub": settings.vapid_subject},
            timeout=settings.http_timeout_seconds,
            # How long the push service holds the message for an offline
            # device. A day: a reminder a day late is still worth seeing,
            # one a week late is noise.
            ttl=24 * 60 * 60,
        )
        return "sent"
    except WebPushException as exc:
        status = getattr(getattr(exc, "response", None), "status_code", None)
        if status in (404, 410):
            return "gone"
        logger.warning("Push delivery failed (HTTP %s)", status)
        return "failed"
    except Exception:
        logger.warning("Push delivery failed", exc_info=True)
        return "failed"


def reminder_payload(reminder: models.Reminder) -> dict:
    return {
        "type": "reminder",
        "id": reminder.id,
        "text": reminder.text,
        "when_label": reminder.when_label,
        "language": reminder.language or "en",
    }


def deliver_due_reminders(db) -> int:
    """
    Push every due, un-notified reminder whose owner has a subscription.
    Returns how many reminders were delivered.

    A reminder is marked notified only once at least one device accepted
    it. If every send fails it is left alone, so the next pass — or the
    in-page poll — still gets a chance. Reminders whose owner has no
    subscription are not touched at all: they belong to the poll.
    """
    if not is_enabled():
        return 0

    now = utcnow()
    due = (
        db.query(models.Reminder)
        .filter(
            models.Reminder.due_at.isnot(None),
            models.Reminder.due_at <= now,
            models.Reminder.notified_at.is_(None),
            models.Reminder.is_done == "pending",
            models.Reminder.owner_id.isnot(None),
        )
        .order_by(models.Reminder.due_at.asc())
        .all()
    )

    delivered = 0
    for reminder in due:
        subscriptions = (
            db.query(models.PushSubscription)
            .filter(models.PushSubscription.owner_id == reminder.owner_id)
            .all()
        )
        if not subscriptions:
            continue

        accepted = False
        for subscription in subscriptions:
            outcome = _send(subscription, reminder_payload(reminder))
            if outcome == "sent":
                accepted = True
            elif outcome == "gone":
                db.delete(subscription)

        if accepted:
            reminder.notified_at = now
            delivered += 1
        db.commit()

    return delivered


class ReminderPusher:
    """The background loop. One per process, started from the app lifespan."""

    def __init__(self, session_factory, interval_seconds: float):
        self._session_factory = session_factory
        self._interval = interval_seconds
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._interval <= 0 or not _HAS_WEBPUSH or self._thread is not None:
            return
        self._thread = threading.Thread(target=self._run, name="reminder-push", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None

    def _run(self) -> None:
        # Wait first: on startup there is nothing that was not already due
        # before the restart, and the first pass should not race migrations.
        while not self._stop.wait(self._interval):
            db = self._session_factory()
            try:
                deliver_due_reminders(db)
            except Exception:
                # The loop must outlive any single bad pass.
                logger.warning("Reminder push pass failed", exc_info=True)
            finally:
                db.close()
