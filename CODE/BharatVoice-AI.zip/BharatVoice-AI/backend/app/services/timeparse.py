"""
Time Expression Parsing
=========================
Turns "remind me tomorrow at 6pm" into an actual datetime.

This exists because a reminder that cannot be scheduled is not a reminder.
The original implementation stored `when_label`, a free-text string like
"tomorrow 5pm", which reads fine in a list and can never fire: nothing can
compare a string to the clock. `when_label` is kept for display, but
`due_at` is what the system acts on.

Scope is deliberately small and explicit rather than a general natural
language date library: relative offsets, today/tomorrow, clock times, and
numeric dates, in all five supported languages. Anything it can't parse
returns None, and the caller says so instead of inventing a time.

All times are Asia/Kolkata. The assistant's users are in India, and a
reminder set in the wrong timezone is worse than no reminder.
"""
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional

from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

# When a date is given with no time, fire in the morning rather than at
# midnight — "remind me on the 3rd" means during that day, not as it starts.
_DEFAULT_HOUR = 9

# --- Day offsets, per language ------------------------------------------
_DAY_WORDS = {
    0: ("today", "இன்று", "आज", "ఈరోజు", "ಇಂದು"),
    1: ("tomorrow", "நாளை", "कल", "रेपु", "రేపు", "ನಾಳೆ"),
    2: ("day after tomorrow", "நாளை மறுநாள்", "परसों", "ఎల్లుండి", "ನಾಡಿದ್ದು"),
}

# --- "in N <unit>" ------------------------------------------------------
_RELATIVE = re.compile(
    r"\bin\s+(\d+)\s*(minute|minutes|min|mins|hour|hours|hr|hrs|day|days|week|weeks)\b",
    re.IGNORECASE,
)
_UNIT_DELTAS = {
    "minute": "minutes", "minutes": "minutes", "min": "minutes", "mins": "minutes",
    "hour": "hours", "hours": "hours", "hr": "hours", "hrs": "hours",
    "day": "days", "days": "days",
    "week": "weeks", "weeks": "weeks",
}

# --- Clock times --------------------------------------------------------
# "5pm", "5:30 pm", "17:00", "5 மணி", "5 बजे", "5 గంటలకు", "5 ಗಂಟೆಗೆ"
_TIME_12H = re.compile(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b", re.IGNORECASE)
_TIME_24H = re.compile(r"\b(\d{1,2}):(\d{2})\b")
_TIME_INDIC = re.compile(r"\b(\d{1,2})\s*(?:மணி|बजे|గంటల|ಗಂಟೆ)")

# --- Numeric and written dates ------------------------------------------
_NUMERIC_DATE = re.compile(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b")
_MONTHS = (
    "january february march april may june july "
    "august september october november december"
).split()
_WRITTEN_DATE = re.compile(
    r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(" + "|".join(_MONTHS) + r")\b", re.IGNORECASE
)


@dataclass
class ParsedTime:
    due_at: datetime  # timezone-aware, Asia/Kolkata
    label: str  # human-readable echo of what was understood


def _apply_time(base: datetime, hour: int, minute: int) -> datetime:
    return base.replace(hour=hour, minute=minute, second=0, microsecond=0)


def _find_clock_time(text: str):
    """Return (hour, minute) in 24h, or None."""
    match = _TIME_12H.search(text)
    if match:
        hour = int(match.group(1)) % 12
        minute = int(match.group(2) or 0)
        if match.group(3).lower() == "pm":
            hour += 12
        return hour, minute

    match = _TIME_24H.search(text)
    if match:
        hour, minute = int(match.group(1)), int(match.group(2))
        if 0 <= hour <= 23 and 0 <= minute <= 59:
            return hour, minute

    match = _TIME_INDIC.search(text)
    if match:
        hour = int(match.group(1))
        # "5 மணி" is almost always 5pm in an assistant context — nobody sets
        # a 5am reminder without saying so. Bias to the afternoon for the
        # ambiguous 1-11 range, which matches how people actually speak.
        if 1 <= hour <= 11:
            hour += 12
        return hour % 24, 0

    return None


def _find_explicit_date(text: str, now: datetime):
    """Return a date-anchored datetime at midnight, or None."""
    match = _NUMERIC_DATE.search(text)
    if match:
        day, month, year = (int(g) for g in match.groups())
        if year < 100:
            year += 2000
        try:
            # Day-first: the Indian convention, and what the entity
            # extractor captures from "3/4/2026".
            return now.replace(year=year, month=month, day=day, hour=0, minute=0,
                               second=0, microsecond=0)
        except ValueError:
            return None

    match = _WRITTEN_DATE.search(text)
    if match:
        day = int(match.group(1))
        month = _MONTHS.index(match.group(2).lower()) + 1
        try:
            candidate = now.replace(month=month, day=day, hour=0, minute=0,
                                    second=0, microsecond=0)
        except ValueError:
            return None
        # A date already past this year means next year.
        if candidate.date() < now.date():
            candidate = candidate.replace(year=candidate.year + 1)
        return candidate

    return None


def parse_due_at(text: str, now: Optional[datetime] = None) -> Optional[ParsedTime]:
    """
    Extract a fire time from a reminder request, or None if there isn't one.

    None is a normal outcome and callers must handle it by saying they
    couldn't work out the time — never by silently picking one.
    """
    if not text:
        return None
    now = now or datetime.now(IST)
    lowered = text.lower()

    # --- "in 30 minutes" ---
    match = _RELATIVE.search(lowered)
    if match:
        amount = int(match.group(1))
        unit = _UNIT_DELTAS[match.group(2).lower()]
        due = (now + timedelta(**{unit: amount})).replace(second=0, microsecond=0)
        noun = unit if amount != 1 else unit.rstrip("s")
        return ParsedTime(due_at=due, label=f"in {amount} {noun}")

    clock = _find_clock_time(text)

    # --- explicit date ---
    explicit = _find_explicit_date(text, now)
    if explicit is not None:
        hour, minute = clock if clock else (_DEFAULT_HOUR, 0)
        due = _apply_time(explicit, hour, minute)
        return ParsedTime(due_at=due, label=due.strftime("%d %B %Y, %I:%M %p"))

    # --- today / tomorrow / day after ---
    for offset, words in _DAY_WORDS.items():
        if any(word in lowered or word in text for word in words):
            base = now + timedelta(days=offset)
            hour, minute = clock if clock else (_DEFAULT_HOUR, 0)
            due = _apply_time(base, hour, minute)
            # "today at 8am" when it is already 9am means they misspoke or
            # mean tomorrow; pushing it forward is friendlier than firing
            # immediately.
            if offset == 0 and due <= now:
                due += timedelta(days=1)
            return ParsedTime(due_at=due, label=due.strftime("%d %B %Y, %I:%M %p"))

    # --- bare clock time: today if still ahead, else tomorrow ---
    if clock:
        due = _apply_time(now, clock[0], clock[1])
        if due <= now:
            due += timedelta(days=1)
        return ParsedTime(due_at=due, label=due.strftime("%d %B %Y, %I:%M %p"))

    return None
