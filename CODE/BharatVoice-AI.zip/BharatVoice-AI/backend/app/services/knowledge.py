"""
Curated Knowledge Base (the "essential FAQ")
==============================================
Short, cited answers to the questions citizens actually ask, in the four
domains that have no usable live API: education, banking, scam awareness
and travel — plus deep links for schemes, jobs and health facilities.

Why this is curated text and not an API call
---------------------------------------------
Each of these domains has an official portal and no public, documented,
free API behind it:

  - myScheme (schemes)         — no documented public API. Deep-link only,
                                 and deliberately no paraphrased
                                 eligibility rules; see `find_scheme`.
  - NCS (jobs)                 — vacancy search is behind a logged-in
                                 session, not an open endpoint.
  - Health Facility Registry   — requires ABDM onboarding and credentials.
  - Scholarships / RTE / DIKSHA / IRCTC / RBI — web portals, no open API.

Scraping them would be the wrong answer: the markup changes without
notice, the terms of use are either restrictive or absent, and a
paraphrase of a government eligibility rule that goes stale does real harm
to someone who acts on it. So each entry here states what the thing *is*
and where the authoritative answer lives, and stops there.

What every entry is allowed to say
------------------------------------
  - What the scheme/document/portal is, in one or two sentences.
  - Which official body runs it, and the portal to check.
  - Safety rules that do not change (nobody legitimate asks for your OTP).

What no entry may contain — enforced by tests:
  - Rupee amounts, percentages or income limits. These are exactly the
    numbers that drift, and a stale figure is worse than no figure.
  - An eligibility verdict. The assistant never tells someone they do or
    do not qualify for anything; it points them at the portal that can.
  - Payment instructions of any kind.

TRANSLATION STATUS: English and Tamil are written with reasonable
confidence. Hindi, Telugu and Kannada are best-effort and marked
`# NEEDS REVIEW` — a native speaker must read them before these languages
are claimed as fully supported. Bodies are deliberately short partly to
keep that review tractable.

PROVENANCE: every portal URL below was checked for reachability on
2026-09-27 (`pmjay.gov.in` did not resolve, so PM-JAY cites the National
Health Authority instead). Reachability is not content review, so
`checked_on` stays None on these sources — same discipline as
`skills.EMERGENCY_SOURCES`. Set it per entry once a human has read the
body against the portal.
"""
import re
from dataclasses import dataclass
from typing import Dict, List, Optional

from app.services.answers import Source

# Domains this module covers. Used by tests and by the coverage report in
# the README, so adding an entry in a new domain is a visible change.
DOMAINS = (
    "education",
    "banking",
    "scam_awareness",
    "travel",
    "schemes",
    "jobs",
    "health_facilities",
)

# Helpline numbers referenced in bodies below. Both are also in
# `skills.EMERGENCY_NUMBERS`, which carries the same caveat: nobody has
# re-verified them against the official portal as part of this work, which
# is why the sources here carry no `checked_on` date either.
#   1930 — cyber / financial fraud
#    139 — Indian Railways enquiry
#    104 — state health advice

_FAQ: Dict[str, dict] = {
    # ---------------- Education ----------------
    "scholarship": {
        "domain": "education",
        "keywords": [
            "scholarship", "scholarships", "nsp portal",
            "உதவித்தொகை", "ஸ்காலர்ஷிப்",
            "छात्रवृत्ति", "स्कॉलरशिप",
            "ఉపకార వేతనం", "స్కాలర్‌షిప్",
            "ವಿದ್ಯಾರ್ಥಿವೇತನ",
        ],
        "source": Source(title="National Scholarship Portal", url="https://scholarships.gov.in"),
        "portal": "scholarships.gov.in",
        "en": (
            "Central and many state scholarships are applied for on the National "
            "Scholarship Portal, using your Aadhaar-linked bank account and your "
            "institute's details. Applications open and close on fixed dates each "
            "academic year, so check the portal for the window that is open now."
        ),
        "ta": (
            "மத்திய மற்றும் பல மாநில உதவித்தொகைகளுக்கு National Scholarship Portal "
            "மூலம் விண்ணப்பிக்க வேண்டும். ஆதாருடன் இணைந்த வங்கிக் கணக்கு மற்றும் "
            "கல்வி நிறுவனத் தகவல்கள் தேவை. விண்ணப்பிக்கும் காலம் ஆண்டுக்கு ஒருமுறை "
            "மட்டுமே திறக்கும், எனவே தற்போதைய தேதிகளை போர்ட்டலில் பாருங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "केंद्र और कई राज्य छात्रवृत्तियों के लिए आवेदन राष्ट्रीय छात्रवृत्ति पोर्टल "
            "(National Scholarship Portal) पर होता है — इसके लिए आधार से जुड़ा बैंक खाता "
            "और संस्थान की जानकारी चाहिए। आवेदन की अवधि हर साल तय तारीखों पर खुलती और "
            "बंद होती है, इसलिए वर्तमान तारीखें पोर्टल पर देखें।"
        ),
        "te": (  # NEEDS REVIEW
            "కేంద్ర మరియు చాలా రాష్ట్ర ఉపకార వేతనాలకు National Scholarship Portal "
            "ద్వారా దరఖాస్తు చేయాలి. ఆధార్‌తో అనుసంధానమైన బ్యాంకు ఖాతా, విద్యా సంస్థ "
            "వివరాలు అవసరం. దరఖాస్తు గడువు ఏటా నిర్ణీత తేదీలలో మాత్రమే ఉంటుంది, "
            "కాబట్టి ప్రస్తుత తేదీలను పోర్టల్‌లో చూడండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಕೇಂದ್ರ ಮತ್ತು ಹಲವು ರಾಜ್ಯ ವಿದ್ಯಾರ್ಥಿವೇತನಗಳಿಗೆ National Scholarship Portal "
            "ಮೂಲಕ ಅರ್ಜಿ ಸಲ್ಲಿಸಬೇಕು. ಆಧಾರ್ ಜೋಡಣೆಯಾದ ಬ್ಯಾಂಕ್ ಖಾತೆ ಮತ್ತು ಶಿಕ್ಷಣ ಸಂಸ್ಥೆಯ "
            "ವಿವರಗಳು ಬೇಕು. ಅರ್ಜಿ ಸಲ್ಲಿಸುವ ಅವಧಿ ವರ್ಷಕ್ಕೊಮ್ಮೆ ನಿಗದಿತ ದಿನಾಂಕಗಳಲ್ಲಿ "
            "ತೆರೆಯುತ್ತದೆ, ಆದ್ದರಿಂದ ಈಗಿನ ದಿನಾಂಕಗಳನ್ನು ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ನೋಡಿ."
        ),
    },
    "school_admission": {
        "domain": "education",
        "keywords": [
            "school admission", "rte admission", "right to education",
            "பள்ளி சேர்க்கை",
            "स्कूल में दाखिला", "स्कूल एडमिशन",
            "పాఠశాల ప్రవేశం",
            "ಶಾಲಾ ಪ್ರವೇಶ",
        ],
        "source": Source(title="Ministry of Education", url="https://education.gov.in"),
        "portal": "your state's school education department portal",
        "en": (
            "School admissions, including the free seats reserved under the Right to "
            "Education Act, are run by your state's school education department rather "
            "than by the central government. Your district education office or the "
            "state portal can tell you the current process and dates."
        ),
        "ta": (
            "பள்ளி சேர்க்கை — கல்வி உரிமைச் சட்டத்தின் கீழ் வரும் இலவச இடங்கள் உட்பட — "
            "மத்திய அரசால் அல்ல, உங்கள் மாநில பள்ளிக் கல்வித் துறையால் நடத்தப்படுகிறது. "
            "தற்போதைய நடைமுறையையும் தேதிகளையும் உங்கள் மாவட்டக் கல்வி அலுவலகத்திலோ "
            "மாநில போர்ட்டலிலோ கேட்டுத் தெரிந்து கொள்ளுங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "स्कूल में दाखिला — शिक्षा का अधिकार अधिनियम के तहत आरक्षित निःशुल्क सीटें "
            "भी — केंद्र सरकार नहीं, आपके राज्य का स्कूल शिक्षा विभाग कराता है। "
            "वर्तमान प्रक्रिया और तारीखें अपने जिला शिक्षा कार्यालय या राज्य पोर्टल "
            "से पता करें।"
        ),
        "te": (  # NEEDS REVIEW
            "పాఠశాల ప్రవేశాలు — విద్యా హక్కు చట్టం కింద కేటాయించిన ఉచిత సీట్లతో సహా — "
            "కేంద్ర ప్రభుత్వం కాదు, మీ రాష్ట్ర పాఠశాల విద్యా శాఖ నిర్వహిస్తుంది. "
            "ప్రస్తుత విధానం, తేదీల గురించి మీ జిల్లా విద్యా కార్యాలయం లేదా రాష్ట్ర "
            "పోర్టల్‌ను సంప్రదించండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಶಾಲಾ ಪ್ರವೇಶ — ಶಿಕ್ಷಣ ಹಕ್ಕು ಕಾಯ್ದೆಯಡಿ ಮೀಸಲಾದ ಉಚಿತ ಸೀಟುಗಳೂ ಸೇರಿ — "
            "ಕೇಂದ್ರ ಸರ್ಕಾರವಲ್ಲ, ನಿಮ್ಮ ರಾಜ್ಯದ ಶಾಲಾ ಶಿಕ್ಷಣ ಇಲಾಖೆ ನಡೆಸುತ್ತದೆ. ಈಗಿನ "
            "ಪ್ರಕ್ರಿಯೆ ಮತ್ತು ದಿನಾಂಕಗಳನ್ನು ನಿಮ್ಮ ಜಿಲ್ಲಾ ಶಿಕ್ಷಣ ಕಚೇರಿ ಅಥವಾ ರಾಜ್ಯ "
            "ಪೋರ್ಟಲ್‌ನಿಂದ ತಿಳಿದುಕೊಳ್ಳಿ."
        ),
    },
    "free_learning": {
        "domain": "education",
        "keywords": [
            "diksha", "study material", "ncert book", "online lessons",
            "டிக்ஷா", "பாடநூல்",
            "दीक्षा", "पाठ्यपुस्तक",
            "పాఠ్యపుస్తక",
            "ಪಠ್ಯಪುಸ್ತಕ",
        ],
        "source": Source(title="DIKSHA — national digital learning platform",
                         url="https://diksha.gov.in"),
        "portal": "diksha.gov.in",
        "en": (
            "DIKSHA carries free textbooks, lessons and practice questions for school "
            "classes in many Indian languages, on the web and as an app. Scanning the "
            "QR code printed in a government textbook opens the matching chapter."
        ),
        "ta": (
            "DIKSHA போர்ட்டலில் பள்ளி வகுப்புகளுக்கான பாடநூல்கள், பாடங்கள், பயிற்சி "
            "வினாக்கள் பல இந்திய மொழிகளில் இலவசமாக கிடைக்கும் — இணையதளத்திலும் "
            "செயலியிலும். அரசு பாடநூலில் உள்ள QR குறியீட்டை ஸ்கேன் செய்தால் அந்தப் "
            "பாடம் நேரடியாக திறக்கும்."
        ),
        "hi": (  # NEEDS REVIEW
            "दीक्षा (DIKSHA) पर स्कूली कक्षाओं के लिए पाठ्यपुस्तकें, पाठ और अभ्यास "
            "प्रश्न कई भारतीय भाषाओं में निःशुल्क उपलब्ध हैं — वेबसाइट और ऐप दोनों पर। "
            "सरकारी पाठ्यपुस्तक में छपे QR कोड को स्कैन करने पर वही अध्याय खुल जाता है।"
        ),
        "te": (  # NEEDS REVIEW
            "DIKSHA లో పాఠశాల తరగతులకు పాఠ్యపుస్తకాలు, పాఠాలు, అభ్యాస ప్రశ్నలు అనేక "
            "భారతీయ భాషల్లో ఉచితంగా లభిస్తాయి — వెబ్‌సైట్‌లో మరియు యాప్‌లో. ప్రభుత్వ "
            "పాఠ్యపుస్తకంలో ఉన్న QR కోడ్‌ను స్కాన్ చేస్తే ఆ పాఠం నేరుగా తెరుచుకుంటుంది."
        ),
        "kn": (  # NEEDS REVIEW
            "DIKSHA ನಲ್ಲಿ ಶಾಲಾ ತರಗತಿಗಳಿಗೆ ಪಠ್ಯಪುಸ್ತಕಗಳು, ಪಾಠಗಳು ಮತ್ತು ಅಭ್ಯಾಸ "
            "ಪ್ರಶ್ನೆಗಳು ಹಲವು ಭಾರತೀಯ ಭಾಷೆಗಳಲ್ಲಿ ಉಚಿತವಾಗಿ ಸಿಗುತ್ತವೆ — ಜಾಲತಾಣ ಮತ್ತು "
            "ಆಪ್ ಎರಡರಲ್ಲೂ. ಸರ್ಕಾರಿ ಪಠ್ಯಪುಸ್ತಕದಲ್ಲಿರುವ QR ಕೋಡ್ ಸ್ಕ್ಯಾನ್ ಮಾಡಿದರೆ ಅದೇ "
            "ಅಧ್ಯಾಯ ತೆರೆಯುತ್ತದೆ."
        ),
    },
    # ---------------- Banking ----------------
    "bank_account": {
        "domain": "banking",
        "keywords": [
            "open a bank account", "open bank account", "jan dhan", "zero balance account",
            "வங்கி கணக்கு தொடங்க", "ஜன் தன்",
            "बैंक खाता खोल", "जन धन",
            "బ్యాంకు ఖాతా తెరవ", "జన్ ధన్",
            "ಬ್ಯಾಂಕ್ ಖಾತೆ ತೆರೆ", "ಜನ್ ಧನ್",
        ],
        "source": Source(title="Pradhan Mantri Jan Dhan Yojana", url="https://pmjdy.gov.in"),
        "portal": "pmjdy.gov.in",
        "en": (
            "Any bank branch or bank correspondent can open a basic savings account "
            "under Pradhan Mantri Jan Dhan Yojana, which needs no minimum balance. "
            "Take an identity document such as Aadhaar; the branch will tell you what "
            "else it needs and issue a RuPay debit card with the account."
        ),
        "ta": (
            "பிரதான் மந்திரி ஜன் தன் திட்டத்தின் கீழ் எந்த வங்கிக் கிளையிலும், வங்கி "
            "பிரதிநிதியிடமும் அடிப்படை சேமிப்புக் கணக்கு தொடங்கலாம் — குறைந்தபட்ச "
            "இருப்புத் தொகை தேவையில்லை. ஆதார் போன்ற அடையாளச் சான்றை எடுத்துச் "
            "செல்லுங்கள்; கணக்குடன் RuPay அட்டையும் வழங்கப்படும்."
        ),
        "hi": (  # NEEDS REVIEW
            "प्रधानमंत्री जन धन योजना के तहत कोई भी बैंक शाखा या बैंक मित्र एक बुनियादी "
            "बचत खाता खोल सकता है, जिसमें न्यूनतम राशि रखने की ज़रूरत नहीं होती। आधार "
            "जैसा पहचान दस्तावेज़ साथ ले जाएँ; खाते के साथ RuPay डेबिट कार्ड भी मिलता है।"
        ),
        "te": (  # NEEDS REVIEW
            "ప్రధాన మంత్రి జన్ ధన్ యోజన కింద ఏ బ్యాంకు శాఖలోనైనా లేదా బ్యాంకు "
            "ప్రతినిధి వద్దనైనా ప్రాథమిక పొదుపు ఖాతా తెరవవచ్చు — కనీస నిల్వ అవసరం లేదు. "
            "ఆధార్ వంటి గుర్తింపు పత్రం తీసుకెళ్లండి; ఖాతాతో పాటు RuPay కార్డు కూడా "
            "ఇస్తారు."
        ),
        "kn": (  # NEEDS REVIEW
            "ಪ್ರಧಾನ ಮಂತ್ರಿ ಜನ್ ಧನ್ ಯೋಜನೆಯಡಿ ಯಾವುದೇ ಬ್ಯಾಂಕ್ ಶಾಖೆ ಅಥವಾ ಬ್ಯಾಂಕ್ "
            "ಪ್ರತಿನಿಧಿಯ ಬಳಿ ಮೂಲ ಉಳಿತಾಯ ಖಾತೆ ತೆರೆಯಬಹುದು — ಕನಿಷ್ಠ ಶಿಲ್ಕು ಅಗತ್ಯವಿಲ್ಲ. "
            "ಆಧಾರ್‌ನಂತಹ ಗುರುತಿನ ದಾಖಲೆ ಒಯ್ಯಿರಿ; ಖಾತೆಯೊಂದಿಗೆ RuPay ಕಾರ್ಡ್ ಸಹ ಸಿಗುತ್ತದೆ."
        ),
    },
    "upi_safety": {
        "domain": "banking",
        "keywords": [
            "upi pin", "upi safe", "upi fraud", "gpay fraud", "phonepe fraud",
            "யுபிஐ",
            "यूपीआई",
            "యూపీఐ",
            "ಯುಪಿಐ",
        ],
        "source": Source(title="Reserve Bank of India — customer awareness",
                         url="https://rbi.org.in"),
        "portal": "rbi.org.in",
        "en": (
            "A UPI PIN is needed only to send money, never to receive it. If anyone "
            "asks you to enter your PIN, scan a QR code or approve a 'collect request' "
            "in order to receive money, it is a fraud attempt — stop and end the call."
        ),
        "ta": (
            "UPI PIN பணம் அனுப்பும்போது மட்டுமே தேவை; பணம் பெறுவதற்கு ஒருபோதும் "
            "தேவையில்லை. பணம் வர வேண்டுமென்று சொல்லி PIN போடச் சொன்னாலும், QR "
            "குறியீட்டை ஸ்கேன் செய்யச் சொன்னாலும், 'collect request' ஏற்கச் சொன்னாலும் "
            "அது மோசடி — உடனே அழைப்பை நிறுத்துங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "यूपीआई पिन सिर्फ़ पैसे भेजने के लिए चाहिए, पैसे लेने के लिए कभी नहीं। अगर "
            "कोई पैसे भेजने के नाम पर आपसे पिन डालने, QR कोड स्कैन करने या 'collect "
            "request' मंज़ूर करने को कहे, तो यह धोखाधड़ी है — कॉल तुरंत काट दें।"
        ),
        "te": (  # NEEDS REVIEW
            "యూపీఐ పిన్ డబ్బు పంపడానికి మాత్రమే అవసరం, డబ్బు స్వీకరించడానికి ఎప్పుడూ "
            "కాదు. డబ్బు వస్తుందని చెప్పి పిన్ నమోదు చేయమని, QR కోడ్ స్కాన్ చేయమని లేదా "
            "'collect request' ఆమోదించమని ఎవరైనా అడిగితే అది మోసం — వెంటనే కాల్ ఆపండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಯುಪಿಐ ಪಿನ್ ಹಣ ಕಳುಹಿಸಲು ಮಾತ್ರ ಬೇಕು, ಹಣ ಪಡೆಯಲು ಎಂದಿಗೂ ಬೇಡ. ಹಣ ಬರುತ್ತದೆ "
            "ಎಂದು ಹೇಳಿ ಪಿನ್ ಹಾಕಲು, QR ಕೋಡ್ ಸ್ಕ್ಯಾನ್ ಮಾಡಲು ಅಥವಾ 'collect request' "
            "ಒಪ್ಪಲು ಯಾರಾದರೂ ಕೇಳಿದರೆ ಅದು ವಂಚನೆ — ಕೂಡಲೇ ಕರೆ ಕಡಿತಗೊಳಿಸಿ."
        ),
    },
    "bank_complaint": {
        "domain": "banking",
        "keywords": [
            "bank complaint", "complaint against bank", "ombudsman",
            "வங்கி புகார்",
            "बैंक शिकायत", "बैंक की शिकायत",
            "బ్యాంకు ఫిర్యాదు",
            "ಬ್ಯಾಂಕ್ ದೂರು",
        ],
        "source": Source(title="RBI Complaint Management System", url="https://cms.rbi.org.in"),
        "portal": "cms.rbi.org.in",
        "en": (
            "Complain to your own bank first and keep the complaint reference number. "
            "If the bank does not resolve it, you can escalate free of charge to the "
            "RBI Ombudsman through the RBI's complaint management portal."
        ),
        "ta": (
            "முதலில் உங்கள் வங்கியிலேயே புகார் அளித்து, புகார் எண்ணை பத்திரமாக "
            "வைத்துக் கொள்ளுங்கள். வங்கி தீர்வு தராவிட்டால், RBI-யின் புகார் மேலாண்மை "
            "போர்ட்டல் வழியாக RBI Ombudsman-க்கு இலவசமாக மேல்முறையீடு செய்யலாம்."
        ),
        "hi": (  # NEEDS REVIEW
            "पहले अपने बैंक में ही शिकायत दर्ज कराएँ और शिकायत संख्या सुरक्षित रखें। "
            "अगर बैंक समाधान न करे, तो आरबीआई के शिकायत पोर्टल के ज़रिये आरबीआई "
            "लोकपाल तक निःशुल्क शिकायत भेज सकते हैं।"
        ),
        "te": (  # NEEDS REVIEW
            "మొదట మీ బ్యాంకులోనే ఫిర్యాదు చేసి, ఫిర్యాదు సంఖ్యను జాగ్రత్తగా ఉంచుకోండి. "
            "బ్యాంకు పరిష్కరించకపోతే, ఆర్‌బీఐ ఫిర్యాదు పోర్టల్ ద్వారా ఆర్‌బీఐ "
            "అంబుడ్స్‌మన్‌కు ఉచితంగా ఫిర్యాదు చేయవచ్చు."
        ),
        "kn": (  # NEEDS REVIEW
            "ಮೊದಲು ನಿಮ್ಮ ಬ್ಯಾಂಕಿನಲ್ಲೇ ದೂರು ನೀಡಿ, ದೂರು ಸಂಖ್ಯೆಯನ್ನು ಜೋಪಾನವಾಗಿ ಇಟ್ಟುಕೊಳ್ಳಿ. "
            "ಬ್ಯಾಂಕ್ ಪರಿಹಾರ ನೀಡದಿದ್ದರೆ, ಆರ್‌ಬಿಐ ದೂರು ಪೋರ್ಟಲ್ ಮೂಲಕ ಆರ್‌ಬಿಐ "
            "ಅಂಬುಡ್ಸ್‌ಮನ್‌ಗೆ ಉಚಿತವಾಗಿ ದೂರು ಸಲ್ಲಿಸಬಹುದು."
        ),
    },
    # ---------------- Scam awareness ----------------
    "otp_scam": {
        "domain": "scam_awareness",
        "keywords": [
            "otp", "share my pin", "cvv", "screen sharing app",
            "ஓடிபி",
            "ओटीपी",
            "ఓటీపీ",
            "ಒಟಿಪಿ",
        ],
        "source": Source(title="National Cyber Crime Reporting Portal",
                         url="https://cybercrime.gov.in"),
        "portal": "cybercrime.gov.in",
        "en": (
            "No bank, government office or delivery agent will ever ask for your OTP, "
            "PIN, CVV or full card number — anyone who does is trying to rob you. "
            "Never read an OTP out on a call, and never install a screen-sharing or "
            "remote-access app because a caller told you to."
        ),
        "ta": (
            "எந்த வங்கியும், அரசு அலுவலகமும், டெலிவரி ஊழியரும் உங்கள் OTP, PIN, CVV "
            "அல்லது முழு அட்டை எண்ணைக் கேட்க மாட்டார்கள் — கேட்பவர் திருடத் "
            "தான் முயற்சிக்கிறார். அழைப்பில் OTP-யை படித்துச் சொல்ல வேண்டாம்; "
            "யாரோ சொன்னதற்காக screen-sharing செயலியை நிறுவ வேண்டாம்."
        ),
        "hi": (  # NEEDS REVIEW
            "कोई भी बैंक, सरकारी दफ़्तर या डिलीवरी एजेंट आपका ओटीपी, पिन, सीवीवी या "
            "पूरा कार्ड नंबर कभी नहीं पूछता — जो पूछे, वह ठगी कर रहा है। कॉल पर ओटीपी "
            "कभी न बताएँ, और किसी के कहने पर स्क्रीन शेयरिंग या रिमोट ऐक्सेस ऐप "
            "बिल्कुल इंस्टॉल न करें।"
        ),
        "te": (  # NEEDS REVIEW
            "ఏ బ్యాంకు, ప్రభుత్వ కార్యాలయం లేదా డెలివరీ సిబ్బంది మీ ఓటీపీ, పిన్, "
            "సీవీవీ లేదా పూర్తి కార్డు నంబరు అడగరు — అడిగే వారు దోచుకోవడానికే "
            "ప్రయత్నిస్తున్నారు. కాల్‌లో ఓటీపీ చెప్పకండి; ఎవరో చెప్పారని స్క్రీన్ "
            "షేరింగ్ యాప్ ఇన్‌స్టాల్ చేయకండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಯಾವುದೇ ಬ್ಯಾಂಕ್, ಸರ್ಕಾರಿ ಕಚೇರಿ ಅಥವಾ ಡೆಲಿವರಿ ಸಿಬ್ಬಂದಿ ನಿಮ್ಮ ಒಟಿಪಿ, ಪಿನ್, "
            "ಸಿವಿವಿ ಅಥವಾ ಪೂರ್ಣ ಕಾರ್ಡ್ ಸಂಖ್ಯೆ ಕೇಳುವುದಿಲ್ಲ — ಕೇಳುವವರು ಕದಿಯಲು "
            "ಪ್ರಯತ್ನಿಸುತ್ತಿದ್ದಾರೆ. ಕರೆಯಲ್ಲಿ ಒಟಿಪಿ ಹೇಳಬೇಡಿ; ಯಾರೋ ಹೇಳಿದರೆಂದು ಸ್ಕ್ರೀನ್ "
            "ಶೇರಿಂಗ್ ಆಪ್ ಅಳವಡಿಸಬೇಡಿ."
        ),
    },
    "report_cyber_fraud": {
        "domain": "scam_awareness",
        "keywords": [
            "cyber crime", "cyber fraud", "online fraud", "money debited",
            "lost money", "bank fraud",
            "இணைய மோசடி", "மோசடி புகார்",
            "साइबर अपराध", "ऑनलाइन धोखाधड़ी",
            "సైబర్ నేరం", "ఆన్‌లైన్ మోసం",
            "ಸೈಬರ್ ಅಪರಾಧ", "ಆನ್‌ಲೈನ್ ವಂಚನೆ",
        ],
        "source": Source(title="National Cyber Crime Reporting Portal",
                         url="https://cybercrime.gov.in"),
        "portal": "cybercrime.gov.in",
        "en": (
            "Report online financial fraud on the National Cyber Crime Reporting Portal "
            "or by calling 1930 as soon as you notice it — the earlier the report, the "
            "better the chance the money is frozen before it moves on. Tell your bank "
            "in the same hour and ask them to block the account and card."
        ),
        "ta": (
            "ஆன்லைன் பண மோசடியை கவனித்த உடனே National Cyber Crime Reporting Portal-ல் "
            "பதிவு செய்யுங்கள், அல்லது 1930 என்ற எண்ணை அழையுங்கள் — எவ்வளவு சீக்கிரம் "
            "புகார் அளிக்கிறீர்களோ, அந்தப் பணத்தை முடக்குவதற்கான வாய்ப்பு அதிகம். "
            "அதே மணி நேரத்தில் வங்கிக்குத் தெரிவித்து கணக்கையும் அட்டையையும் "
            "முடக்கச் சொல்லுங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "ऑनलाइन वित्तीय धोखाधड़ी का पता चलते ही राष्ट्रीय साइबर अपराध रिपोर्टिंग "
            "पोर्टल पर शिकायत करें या 1930 पर कॉल करें — जितनी जल्दी शिकायत, पैसा "
            "रुकवाने की संभावना उतनी ज़्यादा। उसी घंटे अपने बैंक को बताएँ और खाता "
            "तथा कार्ड ब्लॉक कराएँ।"
        ),
        "te": (  # NEEDS REVIEW
            "ఆన్‌లైన్ ఆర్థిక మోసం గుర్తించిన వెంటనే National Cyber Crime Reporting "
            "Portal లో ఫిర్యాదు చేయండి లేదా 1930 కు కాల్ చేయండి — ఎంత త్వరగా "
            "ఫిర్యాదు చేస్తే, డబ్బు ఆపే అవకాశం అంత ఎక్కువ. అదే గంటలో మీ బ్యాంకుకు "
            "తెలిపి ఖాతా, కార్డు బ్లాక్ చేయించండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಆನ್‌ಲೈನ್ ಹಣಕಾಸು ವಂಚನೆ ಗಮನಕ್ಕೆ ಬಂದ ಕೂಡಲೇ National Cyber Crime Reporting "
            "Portal ನಲ್ಲಿ ದೂರು ನೀಡಿ ಅಥವಾ 1930 ಗೆ ಕರೆ ಮಾಡಿ — ಎಷ್ಟು ಬೇಗ ದೂರು ನೀಡಿದರೆ "
            "ಹಣ ತಡೆಹಿಡಿಯುವ ಸಾಧ್ಯತೆ ಅಷ್ಟು ಹೆಚ್ಚು. ಅದೇ ಗಂಟೆಯಲ್ಲಿ ನಿಮ್ಮ ಬ್ಯಾಂಕಿಗೆ "
            "ತಿಳಿಸಿ ಖಾತೆ ಮತ್ತು ಕಾರ್ಡ್ ಬ್ಲಾಕ್ ಮಾಡಿಸಿ."
        ),
    },
    "fake_job_scam": {
        "domain": "scam_awareness",
        "keywords": [
            "job scam", "fake job", "job fee", "work from home offer",
            "வேலை மோசடி",
            "नौकरी घोटाला", "फर्जी नौकरी",
            "ఉద్యోగం మోసం", "నకిలీ ఉద్యోగం",
            "ಉದ್ಯೋಗ ವಂಚನೆ", "ನಕಲಿ ಉದ್ಯೋಗ",
        ],
        "source": Source(title="National Career Service", url="https://ncs.gov.in"),
        "portal": "ncs.gov.in",
        "en": (
            "Genuine government recruitment never asks for money paid to a personal "
            "UPI ID or bank account, and never guarantees a job in advance. Check any "
            "vacancy on the recruiting body's own website before paying anything or "
            "handing over your documents."
        ),
        "ta": (
            "உண்மையான அரசு வேலை நியமனத்தில் தனிநபர் UPI ஐடிக்கோ வங்கிக் கணக்கிற்கோ "
            "பணம் கேட்பதில்லை, வேலை உறுதி என்று முன்பே சொல்வதுமில்லை. பணம் "
            "கொடுப்பதற்கு முன், ஆவணங்களை அளிப்பதற்கு முன், அந்த அறிவிப்பை "
            "நியமன அமைப்பின் அதிகாரப்பூர்வ இணையதளத்தில் சரிபாருங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "असली सरकारी भर्ती में किसी निजी यूपीआई आईडी या बैंक खाते में पैसे नहीं "
            "मांगे जाते, और नौकरी की गारंटी पहले से नहीं दी जाती। पैसे देने या "
            "दस्तावेज़ सौंपने से पहले वह भर्ती सूचना भर्ती करने वाली संस्था की "
            "आधिकारिक वेबसाइट पर जाँच लें।"
        ),
        "te": (  # NEEDS REVIEW
            "నిజమైన ప్రభుత్వ నియామకంలో వ్యక్తిగత యూపీఐ ఐడీ లేదా బ్యాంకు ఖాతాకు డబ్బు "
            "అడగరు, ఉద్యోగం ఖాయం అని ముందే చెప్పరు. డబ్బు చెల్లించే ముందు, పత్రాలు "
            "ఇచ్చే ముందు ఆ ప్రకటనను నియామక సంస్థ అధికారిక వెబ్‌సైట్‌లో సరిచూసుకోండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ನಿಜವಾದ ಸರ್ಕಾರಿ ನೇಮಕಾತಿಯಲ್ಲಿ ವೈಯಕ್ತಿಕ ಯುಪಿಐ ಐಡಿ ಅಥವಾ ಬ್ಯಾಂಕ್ ಖಾತೆಗೆ ಹಣ "
            "ಕೇಳುವುದಿಲ್ಲ, ಉದ್ಯೋಗ ಖಚಿತ ಎಂದು ಮೊದಲೇ ಹೇಳುವುದಿಲ್ಲ. ಹಣ ಕೊಡುವ ಮೊದಲು, "
            "ದಾಖಲೆ ನೀಡುವ ಮೊದಲು ಆ ಪ್ರಕಟಣೆಯನ್ನು ನೇಮಕ ಸಂಸ್ಥೆಯ ಅಧಿಕೃತ ಜಾಲತಾಣದಲ್ಲಿ "
            "ಪರಿಶೀಲಿಸಿ."
        ),
    },
    "digital_arrest_scam": {
        "domain": "scam_awareness",
        "keywords": [
            "digital arrest", "police video call", "cbi call",
            "டிஜிட்டல் அரெஸ்ட்",
            "डिजिटल अरेस्ट", "डिजिटल गिरफ्तारी",
            "డిజిటల్ అరెస్ట్",
            "ಡಿಜಿಟಲ್ ಅರೆಸ್ಟ್",
        ],
        "source": Source(title="National Cyber Crime Reporting Portal",
                         url="https://cybercrime.gov.in"),
        "portal": "cybercrime.gov.in",
        "en": (
            "Police, CBI, customs and courts do not arrest anyone over a video call, "
            "and no real officer demands money to settle a case. Cut the call, transfer "
            "nothing, keep the screenshots, and report it on the cyber crime portal or "
            "on 1930."
        ),
        "ta": (
            "காவல் துறை, CBI, சுங்கத் துறை, நீதிமன்றம் — யாரும் வீடியோ அழைப்பில் "
            "கைது செய்வதில்லை; உண்மையான அதிகாரி வழக்கை 'முடித்துக் கொள்ள' பணம் "
            "கேட்பதுமில்லை. அழைப்பை வெட்டுங்கள், பணம் அனுப்ப வேண்டாம், திரைப்படங்களை "
            "(screenshot) சேமித்து cyber crime போர்ட்டலில் அல்லது 1930-ல் புகார் அளியுங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "पुलिस, सीबीआई, कस्टम या अदालत किसी को वीडियो कॉल पर गिरफ़्तार नहीं करती, "
            "और कोई असली अधिकारी मामला 'निपटाने' के लिए पैसे नहीं मांगता। कॉल काट दें, "
            "पैसे न भेजें, स्क्रीनशॉट रखें और साइबर क्राइम पोर्टल या 1930 पर शिकायत करें।"
        ),
        "te": (  # NEEDS REVIEW
            "పోలీసులు, సీబీఐ, కస్టమ్స్, కోర్టులు ఎవరినీ వీడియో కాల్‌లో అరెస్టు "
            "చేయవు; నిజమైన అధికారి కేసు 'పరిష్కరించడానికి' డబ్బు అడగరు. కాల్ కట్ "
            "చేయండి, డబ్బు పంపకండి, స్క్రీన్‌షాట్లు ఉంచుకోండి, సైబర్ క్రైమ్ "
            "పోర్టల్‌లో లేదా 1930 కు ఫిర్యాదు చేయండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಪೊಲೀಸ್, ಸಿಬಿಐ, ಕಸ್ಟಮ್ಸ್, ನ್ಯಾಯಾಲಯ ಯಾರನ್ನೂ ವಿಡಿಯೋ ಕರೆಯಲ್ಲಿ ಬಂಧಿಸುವುದಿಲ್ಲ; "
            "ನಿಜವಾದ ಅಧಿಕಾರಿ ಪ್ರಕರಣ 'ಮುಗಿಸಲು' ಹಣ ಕೇಳುವುದಿಲ್ಲ. ಕರೆ ಕಡಿತಗೊಳಿಸಿ, ಹಣ "
            "ಕಳುಹಿಸಬೇಡಿ, ಸ್ಕ್ರೀನ್‌ಶಾಟ್ ಇಟ್ಟುಕೊಳ್ಳಿ, ಸೈಬರ್ ಕ್ರೈಂ ಪೋರ್ಟಲ್ ಅಥವಾ 1930 "
            "ನಲ್ಲಿ ದೂರು ನೀಡಿ."
        ),
    },
    # ---------------- Travel ----------------
    "train_booking": {
        "domain": "travel",
        "keywords": [
            "train ticket", "book a train", "irctc", "tatkal",
            "ரயில் டிக்கெட்",
            "ट्रेन टिकट", "रेल टिकट",
            "రైలు టికెట్",
            "ರೈಲು ಟಿಕೆಟ್",
        ],
        "source": Source(title="IRCTC — Indian Railways ticketing",
                         url="https://www.irctc.co.in"),
        "portal": "irctc.co.in",
        "en": (
            "Train tickets are booked on IRCTC, on the website or the Rail Connect app, "
            "after a one-time free registration. The Tatkal quota for most trains opens "
            "one day before the journey date, and reservation counters at the station "
            "sell the same tickets."
        ),
        "ta": (
            "ரயில் டிக்கெட்டுகளை IRCTC இணையதளத்திலோ Rail Connect செயலியிலோ "
            "பதிவு செய்யலாம் — ஒருமுறை இலவசமாக பதிவு செய்ய வேண்டும். பெரும்பாலான "
            "ரயில்களுக்கு Tatkal ஒதுக்கீடு பயணத்திற்கு ஒரு நாள் முன்பே திறக்கும். "
            "நிலையத்தில் உள்ள முன்பதிவு கவுண்டரிலும் அதே டிக்கெட் கிடைக்கும்."
        ),
        "hi": (  # NEEDS REVIEW
            "ट्रेन टिकट IRCTC की वेबसाइट या Rail Connect ऐप पर बुक होते हैं — एक बार "
            "निःशुल्क पंजीकरण करना पड़ता है। ज़्यादातर ट्रेनों में तत्काल कोटा यात्रा "
            "से एक दिन पहले खुलता है, और स्टेशन के आरक्षण काउंटर पर भी वही टिकट मिलते हैं।"
        ),
        "te": (  # NEEDS REVIEW
            "రైలు టికెట్లను IRCTC వెబ్‌సైట్‌లో లేదా Rail Connect యాప్‌లో బుక్ "
            "చేసుకోవచ్చు — ఒకసారి ఉచితంగా నమోదు చేసుకోవాలి. చాలా రైళ్లకు తత్కాల్ కోటా "
            "ప్రయాణానికి ఒక రోజు ముందు తెరుచుకుంటుంది; స్టేషన్ రిజర్వేషన్ కౌంటర్‌లోనూ "
            "అదే టికెట్లు లభిస్తాయి."
        ),
        "kn": (  # NEEDS REVIEW
            "ರೈಲು ಟಿಕೆಟ್‌ಗಳನ್ನು IRCTC ಜಾಲತಾಣದಲ್ಲಿ ಅಥವಾ Rail Connect ಆಪ್‌ನಲ್ಲಿ ಬುಕ್ "
            "ಮಾಡಬಹುದು — ಒಮ್ಮೆ ಉಚಿತವಾಗಿ ನೋಂದಣಿ ಮಾಡಬೇಕು. ಬಹುತೇಕ ರೈಲುಗಳಿಗೆ ತತ್ಕಾಲ್ ಕೋಟಾ "
            "ಪ್ರಯಾಣದ ಒಂದು ದಿನ ಮೊದಲು ತೆರೆಯುತ್ತದೆ; ನಿಲ್ದಾಣದ ಮೀಸಲು ಕೌಂಟರ್‌ನಲ್ಲೂ ಅದೇ "
            "ಟಿಕೆಟ್ ಸಿಗುತ್ತದೆ."
        ),
    },
    "train_status": {
        "domain": "travel",
        "keywords": [
            "pnr", "train status", "running status", "seat availability",
            "ரயில் நிலை",
            "ट्रेन का स्टेटस", "ट्रेन कहां",
            "రైలు స్థితి",
            "ರೈಲು ಸ್ಥಿತಿ",
        ],
        "source": Source(title="National Train Enquiry System",
                         url="https://enquiry.indianrail.gov.in"),
        "portal": "enquiry.indianrail.gov.in",
        "en": (
            "Live running status, PNR status and seat availability are on the National "
            "Train Enquiry System, and the same information is available by calling 139. "
            "Keep your ten-digit PNR or the train number ready. I cannot look this up "
            "for you — there is no open API for it."
        ),
        "ta": (
            "ரயில் எங்கே இருக்கிறது, PNR நிலை, இட வசதி — இவை National Train Enquiry "
            "System-ல் உள்ளன; 139 என்ற எண்ணை அழைத்தும் அதே தகவலைப் பெறலாம். உங்கள் "
            "பத்து இலக்க PNR அல்லது ரயில் எண்ணை தயாராக வைத்துக் கொள்ளுங்கள். இதை நான் "
            "நேரடியாகப் பார்க்க முடியாது — அதற்கு திறந்த API இல்லை."
        ),
        "hi": (  # NEEDS REVIEW
            "ट्रेन की लाइव स्थिति, पीएनआर स्टेटस और सीट उपलब्धता राष्ट्रीय ट्रेन "
            "पूछताछ प्रणाली पर मिलती है; 139 पर कॉल करके भी वही जानकारी ले सकते हैं। "
            "अपना दस अंकों का पीएनआर या ट्रेन नंबर तैयार रखें। मैं यह खुद नहीं देख "
            "सकता — इसके लिए कोई खुला API नहीं है।"
        ),
        "te": (  # NEEDS REVIEW
            "రైలు ప్రస్తుత స్థితి, పీఎన్‌ఆర్ స్థితి, సీట్ల లభ్యత National Train "
            "Enquiry System లో ఉంటాయి; 139 కు కాల్ చేసినా అదే సమాచారం వస్తుంది. మీ "
            "పది అంకెల పీఎన్‌ఆర్ లేదా రైలు నంబరు సిద్ధంగా ఉంచుకోండి. నేను దీన్ని "
            "నేరుగా చూడలేను — దానికి బహిరంగ API లేదు."
        ),
        "kn": (  # NEEDS REVIEW
            "ರೈಲಿನ ಈಗಿನ ಸ್ಥಿತಿ, ಪಿಎನ್‌ಆರ್ ಸ್ಥಿತಿ, ಸೀಟು ಲಭ್ಯತೆ National Train Enquiry "
            "System ನಲ್ಲಿ ಇರುತ್ತದೆ; 139 ಗೆ ಕರೆ ಮಾಡಿದರೂ ಅದೇ ಮಾಹಿತಿ ಸಿಗುತ್ತದೆ. ನಿಮ್ಮ "
            "ಹತ್ತು ಅಂಕಿಯ ಪಿಎನ್‌ಆರ್ ಅಥವಾ ರೈಲು ಸಂಖ್ಯೆ ಸಿದ್ಧವಾಗಿಟ್ಟುಕೊಳ್ಳಿ. ನಾನು ಇದನ್ನು "
            "ನೇರವಾಗಿ ನೋಡಲಾರೆ — ಅದಕ್ಕೆ ಮುಕ್ತ API ಇಲ್ಲ."
        ),
    },
    "bus_booking": {
        "domain": "travel",
        "keywords": [
            "bus ticket", "book a bus", "tnstc", "ksrtc", "apsrtc", "tsrtc",
            "பஸ் டிக்கெட்",
            "बस टिकट",
            "బస్సు టికెట్",
            "ಬಸ್ ಟಿಕೆಟ್",
        ],
        "source": Source(title="State road transport corporations"),
        "portal": "your state road transport corporation's own portal",
        "en": (
            "State road transport corporations sell their own bus tickets online — "
            "TNSTC, KSRTC, TSRTC, APSRTC and others each run their own booking site. "
            "Search for your state corporation by name rather than trusting a "
            "lookalike site or an ad, because fake booking pages are common."
        ),
        "ta": (
            "மாநில போக்குவரத்துக் கழகங்கள் தங்கள் பஸ் டிக்கெட்டுகளை தங்கள் சொந்த "
            "இணையதளத்தில் விற்கின்றன — TNSTC, KSRTC, TSRTC, APSRTC என ஒவ்வொன்றுக்கும் "
            "தனி தளம் உள்ளது. விளம்பரத்தையோ போலி தளத்தையோ நம்பாமல், உங்கள் மாநில "
            "கழகத்தின் பெயரை வைத்துத் தேடுங்கள் — போலி முன்பதிவு தளங்கள் அதிகம்."
        ),
        "hi": (  # NEEDS REVIEW
            "राज्य परिवहन निगम अपनी बस टिकटें अपनी ही वेबसाइट पर बेचते हैं — TNSTC, "
            "KSRTC, TSRTC, APSRTC सबकी अलग साइट है। किसी विज्ञापन या नकली साइट पर "
            "भरोसा करने के बजाय अपने राज्य के निगम का नाम लिखकर खोजें, क्योंकि फ़र्ज़ी "
            "बुकिंग पेज बहुत हैं।"
        ),
        "te": (  # NEEDS REVIEW
            "రాష్ట్ర రోడ్డు రవాణా సంస్థలు తమ బస్సు టికెట్లను తమ సొంత వెబ్‌సైట్‌లోనే "
            "అమ్ముతాయి — TNSTC, KSRTC, TSRTC, APSRTC అన్నింటికీ వేరువేరు సైట్లు "
            "ఉన్నాయి. ప్రకటనలను లేదా నకిలీ సైట్లను నమ్మకుండా మీ రాష్ట్ర సంస్థ పేరుతో "
            "వెతకండి — నకిలీ బుకింగ్ పేజీలు ఎక్కువ."
        ),
        "kn": (  # NEEDS REVIEW
            "ರಾಜ್ಯ ರಸ್ತೆ ಸಾರಿಗೆ ಸಂಸ್ಥೆಗಳು ತಮ್ಮ ಬಸ್ ಟಿಕೆಟ್‌ಗಳನ್ನು ತಮ್ಮದೇ ಜಾಲತಾಣದಲ್ಲಿ "
            "ಮಾರುತ್ತವೆ — TNSTC, KSRTC, TSRTC, APSRTC ಎಲ್ಲಕ್ಕೂ ಪ್ರತ್ಯೇಕ ತಾಣಗಳಿವೆ. "
            "ಜಾಹೀರಾತು ಅಥವಾ ನಕಲಿ ತಾಣ ನಂಬದೆ ನಿಮ್ಮ ರಾಜ್ಯದ ಸಂಸ್ಥೆಯ ಹೆಸರಿನಿಂದ ಹುಡುಕಿ — "
            "ನಕಲಿ ಬುಕಿಂಗ್ ಪುಟಗಳು ಹೆಚ್ಚು."
        ),
    },
    # ---------------- Schemes ----------------
    "find_scheme": {
        "domain": "schemes",
        "keywords": [
            "government scheme", "govt scheme", "myscheme", "sarkari yojana",
            "what schemes", "welfare scheme",
            "அரசு திட்டம்", "அரசுத் திட்டங்கள்",
            "सरकारी योजना", "सरकारी योजनाएं",
            "ప్రభుత్వ పథకం", "ప్రభుత్వ పథకాలు",
            "ಸರ್ಕಾರಿ ಯೋಜನೆ", "ಸರ್ಕಾರಿ ಯೋಜನೆಗಳು",
        ],
        "source": Source(title="myScheme — national scheme discovery portal",
                         url="https://myscheme.gov.in"),
        "portal": "myscheme.gov.in",
        "en": (
            "myScheme lists central and state government schemes and can filter them "
            "by your age, occupation, state and category. I deliberately do not repeat "
            "eligibility rules here: they change, and a wrong one costs you an "
            "application — so read them on the portal itself, or at a Common Service "
            "Centre."
        ),
        "ta": (
            "myScheme போர்ட்டலில் மத்திய மற்றும் மாநில அரசுத் திட்டங்கள் பட்டியலிடப்பட்டு, "
            "வயது, தொழில், மாநிலம், பிரிவு அடிப்படையில் வடிகட்டிப் பார்க்கலாம். "
            "தகுதி விதிகளை நான் இங்கே திரும்பச் சொல்வதில்லை — அவை மாறும், தவறான "
            "தகவல் ஒரு விண்ணப்பத்தையே இழக்க வைக்கும். போர்ட்டலிலோ பொது சேவை "
            "மையத்திலோ படித்துத் தெரிந்து கொள்ளுங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "myScheme पर केंद्र और राज्य की सरकारी योजनाएँ सूचीबद्ध हैं और इन्हें आयु, "
            "व्यवसाय, राज्य और श्रेणी के हिसाब से छाना जा सकता है। पात्रता के नियम मैं "
            "जानबूझकर यहाँ नहीं दोहराता — वे बदलते हैं और गलत जानकारी से आवेदन ही हाथ "
            "से निकल जाता है। इन्हें पोर्टल पर या किसी कॉमन सर्विस सेंटर पर पढ़ें।"
        ),
        "te": (  # NEEDS REVIEW
            "myScheme లో కేంద్ర, రాష్ట్ర ప్రభుత్వ పథకాలు ఉన్నాయి; వయసు, వృత్తి, "
            "రాష్ట్రం, వర్గం ఆధారంగా వడపోయవచ్చు. అర్హత నియమాలను నేను ఉద్దేశపూర్వకంగా "
            "ఇక్కడ చెప్పను — అవి మారుతూ ఉంటాయి, తప్పు సమాచారం వల్ల దరఖాస్తు "
            "పోతుంది. వాటిని పోర్టల్‌లో లేదా కామన్ సర్వీస్ సెంటర్‌లో చదవండి."
        ),
        "kn": (  # NEEDS REVIEW
            "myScheme ನಲ್ಲಿ ಕೇಂದ್ರ ಮತ್ತು ರಾಜ್ಯ ಸರ್ಕಾರಿ ಯೋಜನೆಗಳಿವೆ; ವಯಸ್ಸು, ವೃತ್ತಿ, "
            "ರಾಜ್ಯ, ವರ್ಗದ ಆಧಾರದಲ್ಲಿ ಸೋಸಬಹುದು. ಅರ್ಹತಾ ನಿಯಮಗಳನ್ನು ನಾನು ಉದ್ದೇಶಪೂರ್ವಕವಾಗಿ "
            "ಇಲ್ಲಿ ಪುನರಾವರ್ತಿಸುವುದಿಲ್ಲ — ಅವು ಬದಲಾಗುತ್ತವೆ, ತಪ್ಪು ಮಾಹಿತಿಯಿಂದ ಅರ್ಜಿಯೇ "
            "ಕೈತಪ್ಪುತ್ತದೆ. ಅವುಗಳನ್ನು ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಅಥವಾ ಕಾಮನ್ ಸರ್ವಿಸ್ ಸೆಂಟರ್‌ನಲ್ಲಿ ಓದಿ."
        ),
    },
    "pm_kisan": {
        "domain": "schemes",
        "keywords": [
            "pm kisan", "pm-kisan", "kisan samman",
            "பிஎம் கிசான்",
            "पीएम किसान", "किसान सम्मान",
            "పీఎం కిసాన్",
            "ಪಿಎಂ ಕಿಸಾನ್",
        ],
        "source": Source(title="PM-KISAN portal", url="https://pmkisan.gov.in"),
        "portal": "pmkisan.gov.in",
        "en": (
            "PM-KISAN is a central income-support scheme for landholding farmer "
            "families, paid straight into a bank account. Beneficiary status, "
            "land-record linking and eKYC are all checked on the PM-KISAN portal with "
            "your Aadhaar or registration number — I cannot check your status for you."
        ),
        "ta": (
            "PM-KISAN என்பது நிலம் வைத்திருக்கும் விவசாயக் குடும்பங்களுக்கு மத்திய "
            "அரசு அளிக்கும் வருவாய் உதவித் திட்டம்; தொகை நேரடியாக வங்கிக் கணக்கில் "
            "வரும். பயனாளி நிலை, நில ஆவண இணைப்பு, eKYC ஆகியவற்றை ஆதார் அல்லது பதிவு "
            "எண்ணைப் பயன்படுத்தி PM-KISAN போர்ட்டலில் பார்க்கலாம் — உங்கள் நிலையை "
            "நான் பார்க்க முடியாது."
        ),
        "hi": (  # NEEDS REVIEW
            "पीएम-किसान भूमिधारक किसान परिवारों के लिए केंद्र की आय सहायता योजना है, "
            "जिसका पैसा सीधे बैंक खाते में आता है। लाभार्थी स्थिति, भूमि रिकॉर्ड "
            "जोड़ना और eKYC — सब पीएम-किसान पोर्टल पर आधार या पंजीकरण संख्या से देखे "
            "जाते हैं। मैं आपकी स्थिति खुद नहीं देख सकता।"
        ),
        "te": (  # NEEDS REVIEW
            "పీఎం-కిసాన్ అనేది భూమి ఉన్న రైతు కుటుంబాలకు కేంద్రం ఇచ్చే ఆదాయ సహాయ "
            "పథకం; డబ్బు నేరుగా బ్యాంకు ఖాతాలో జమ అవుతుంది. లబ్ధిదారు స్థితి, భూ "
            "రికార్డు అనుసంధానం, eKYC అన్నీ ఆధార్ లేదా నమోదు సంఖ్యతో పీఎం-కిసాన్ "
            "పోర్టల్‌లో చూడవచ్చు — మీ స్థితిని నేను చూడలేను."
        ),
        "kn": (  # NEEDS REVIEW
            "ಪಿಎಂ-ಕಿಸಾನ್ ಎಂಬುದು ಭೂಮಿ ಹೊಂದಿರುವ ರೈತ ಕುಟುಂಬಗಳಿಗೆ ಕೇಂದ್ರ ನೀಡುವ ಆದಾಯ ಬೆಂಬಲ "
            "ಯೋಜನೆ; ಹಣ ನೇರವಾಗಿ ಬ್ಯಾಂಕ್ ಖಾತೆಗೆ ಬರುತ್ತದೆ. ಫಲಾನುಭವಿ ಸ್ಥಿತಿ, ಭೂ ದಾಖಲೆ "
            "ಜೋಡಣೆ, eKYC ಎಲ್ಲವನ್ನೂ ಆಧಾರ್ ಅಥವಾ ನೋಂದಣಿ ಸಂಖ್ಯೆಯಿಂದ ಪಿಎಂ-ಕಿಸಾನ್ "
            "ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ನೋಡಬಹುದು — ನಿಮ್ಮ ಸ್ಥಿತಿಯನ್ನು ನಾನು ನೋಡಲಾರೆ."
        ),
    },
    "ayushman_bharat": {
        "domain": "schemes",
        "keywords": [
            "ayushman", "pmjay", "pm jay", "health insurance card",
            "ஆயுஷ்மான்",
            "आयुष्मान",
            "ఆయుష్మాన్",
            "ಆಯುಷ್ಮಾನ್",
        ],
        "source": Source(title="National Health Authority (PM-JAY)", url="https://nha.gov.in"),
        "portal": "beneficiary.nha.gov.in",
        "en": (
            "Ayushman Bharat PM-JAY pays for hospital treatment of eligible families at "
            "empanelled hospitals, using an Ayushman card. Whether your household is on "
            "the list can only be confirmed on the beneficiary portal or at a hospital's "
            "Ayushman help desk — I cannot check eligibility, and nobody should charge "
            "you to check it."
        ),
        "ta": (
            "ஆயுஷ்மான் பாரத் PM-JAY திட்டம், தகுதியுள்ள குடும்பங்களுக்கு பட்டியலிடப்பட்ட "
            "மருத்துவமனைகளில் சிகிச்சைச் செலவை ஆயுஷ்மான் அட்டை மூலம் ஏற்கிறது. உங்கள் "
            "குடும்பம் பட்டியலில் உள்ளதா என்பதை beneficiary போர்ட்டலிலோ மருத்துவமனையின் "
            "ஆயுஷ்மான் உதவி மேசையிலோ மட்டுமே உறுதி செய்ய முடியும் — நான் தகுதியைச் "
            "சரிபார்க்க முடியாது, அதைச் சரிபார்க்க யாரும் உங்களிடம் பணம் வாங்கக் கூடாது."
        ),
        "hi": (  # NEEDS REVIEW
            "आयुष्मान भारत पीएम-जय पात्र परिवारों का अस्पताल में इलाज का खर्च "
            "सूचीबद्ध अस्पतालों में आयुष्मान कार्ड से उठाता है। आपका परिवार सूची में है "
            "या नहीं, यह केवल लाभार्थी पोर्टल पर या अस्पताल के आयुष्मान हेल्प डेस्क पर "
            "पक्का होता है — मैं पात्रता नहीं जाँच सकता, और जाँचने के बदले किसी को पैसे "
            "न दें।"
        ),
        "te": (  # NEEDS REVIEW
            "ఆయుష్మాన్ భారత్ పీఎం-జేఏవై అర్హులైన కుటుంబాల ఆసుపత్రి చికిత్స ఖర్చును "
            "జాబితాలోని ఆసుపత్రులలో ఆయుష్మాన్ కార్డు ద్వారా భరిస్తుంది. మీ కుటుంబం "
            "జాబితాలో ఉందో లేదో బెనిఫిషియరీ పోర్టల్‌లో లేదా ఆసుపత్రి ఆయుష్మాన్ హెల్ప్ "
            "డెస్క్‌లో మాత్రమే నిర్ధారణ అవుతుంది — నేను అర్హత చూడలేను, చూడటానికి "
            "ఎవరికీ డబ్బు ఇవ్వకండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ಆಯುಷ್ಮಾನ್ ಭಾರತ್ ಪಿಎಂ-ಜೆಎವೈ ಅರ್ಹ ಕುಟುಂಬಗಳ ಆಸ್ಪತ್ರೆ ಚಿಕಿತ್ಸೆ ವೆಚ್ಚವನ್ನು "
            "ಪಟ್ಟಿಯಲ್ಲಿರುವ ಆಸ್ಪತ್ರೆಗಳಲ್ಲಿ ಆಯುಷ್ಮಾನ್ ಕಾರ್ಡ್ ಮೂಲಕ ಭರಿಸುತ್ತದೆ. ನಿಮ್ಮ ಕುಟುಂಬ "
            "ಪಟ್ಟಿಯಲ್ಲಿದೆಯೇ ಎಂಬುದು ಬೆನಿಫಿಷಿಯರಿ ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಅಥವಾ ಆಸ್ಪತ್ರೆಯ ಆಯುಷ್ಮಾನ್ "
            "ಸಹಾಯ ಕೇಂದ್ರದಲ್ಲಿ ಮಾತ್ರ ಖಚಿತವಾಗುತ್ತದೆ — ನಾನು ಅರ್ಹತೆ ಪರಿಶೀಲಿಸಲಾರೆ, "
            "ಪರಿಶೀಲಿಸಲು ಯಾರಿಗೂ ಹಣ ಕೊಡಬೇಡಿ."
        ),
    },
    # ---------------- Health facilities ----------------
    "find_hospital": {
        "domain": "health_facilities",
        "keywords": [
            "nearest hospital", "find a hospital", "hospital near",
            "government hospital", "primary health centre",
            # The phrasings that name a place, which is what the live
            # lookup (services/hospitals.py) needs: "hospitals in Madurai".
            "hospitals in", "hospital in", "hospitals near", "hospitals at",
            "அருகில் மருத்துவமனை", "அரசு மருத்துவமனை",
            "नज़दीकी अस्पताल", "सरकारी अस्पताल",
            "దగ్గరి ఆసుపత్రి", "ప్రభుత్వ ఆసుపత్రి",
            "ಹತ್ತಿರದ ಆಸ್ಪತ್ರೆ", "ಸರ್ಕಾರಿ ಆಸ್ಪತ್ರೆ",
        ],
        "source": Source(title="Health Facility Registry (ABDM)",
                         url="https://facility.abdm.gov.in"),
        "portal": "facility.abdm.gov.in",
        "en": (
            "The Health Facility Registry lists registered hospitals, clinics and labs "
            "across India and can be searched by state and district. I cannot search it "
            "for you: it needs ABDM onboarding credentials, which this project does not "
            "have. For urgent medical help call 108, and for state health advice 104."
        ),
        "ta": (
            "Health Facility Registry-ல் இந்தியா முழுவதும் பதிவு செய்யப்பட்ட "
            "மருத்துவமனைகள், கிளினிக்குகள், ஆய்வகங்கள் பட்டியலிடப்பட்டுள்ளன; மாநிலம், "
            "மாவட்டம் வாரியாகத் தேடலாம். நான் அதை உங்களுக்காகத் தேட முடியாது — அதற்கு "
            "ABDM அனுமதி தேவை, இந்தத் திட்டத்திற்கு அது இல்லை. அவசர மருத்துவ உதவிக்கு "
            "108, மாநில சுகாதார ஆலோசனைக்கு 104."
        ),
        "hi": (  # NEEDS REVIEW
            "हेल्थ फैसिलिटी रजिस्ट्री में पूरे भारत के पंजीकृत अस्पताल, क्लिनिक और लैब "
            "सूचीबद्ध हैं, जिन्हें राज्य और ज़िले से खोजा जा सकता है। मैं यह खोज नहीं "
            "सकता — इसके लिए ABDM की अनुमति चाहिए, जो इस प्रोजेक्ट के पास नहीं है। "
            "तुरंत चिकित्सा सहायता के लिए 108, राज्य स्वास्थ्य सलाह के लिए 104।"
        ),
        "te": (  # NEEDS REVIEW
            "హెల్త్ ఫెసిలిటీ రిజిస్ట్రీలో దేశవ్యాప్తంగా నమోదైన ఆసుపత్రులు, క్లినిక్‌లు, "
            "ల్యాబ్‌లు ఉన్నాయి; రాష్ట్రం, జిల్లా ఆధారంగా వెతకవచ్చు. నేను దాన్ని "
            "వెతకలేను — దానికి ABDM అనుమతి కావాలి, ఈ ప్రాజెక్టుకు అది లేదు. అత్యవసర "
            "వైద్య సహాయానికి 108, రాష్ట్ర ఆరోగ్య సలహాకు 104."
        ),
        "kn": (  # NEEDS REVIEW
            "ಹೆಲ್ತ್ ಫೆಸಿಲಿಟಿ ರಿಜಿಸ್ಟ್ರಿಯಲ್ಲಿ ದೇಶದ ನೋಂದಾಯಿತ ಆಸ್ಪತ್ರೆಗಳು, ಕ್ಲಿನಿಕ್‌ಗಳು, "
            "ಲ್ಯಾಬ್‌ಗಳ ಪಟ್ಟಿ ಇದೆ; ರಾಜ್ಯ ಮತ್ತು ಜಿಲ್ಲೆಯಿಂದ ಹುಡುಕಬಹುದು. ನಾನು ಅದನ್ನು "
            "ಹುಡುಕಲಾರೆ — ಅದಕ್ಕೆ ABDM ಅನುಮತಿ ಬೇಕು, ಈ ಯೋಜನೆಗೆ ಅದು ಇಲ್ಲ. ತುರ್ತು ವೈದ್ಯ "
            "ಸಹಾಯಕ್ಕೆ 108, ರಾಜ್ಯ ಆರೋಗ್ಯ ಸಲಹೆಗೆ 104."
        ),
    },
    # ---------------- Jobs ----------------
    "find_job": {
        "domain": "jobs",
        "keywords": [
            "government job", "sarkari naukri", "job vacancy", "find a job",
            "ncs portal", "employment exchange",
            "வேலை வாய்ப்பு", "அரசு வேலை",
            "सरकारी नौकरी", "नौकरी की जानकारी",
            "ప్రభుత్వ ఉద్యోగం", "ఉద్యోగ ఖాళీ",
            "ಸರ್ಕಾರಿ ಉದ್ಯೋಗ", "ಉದ್ಯೋಗ ಖಾಲಿ",
        ],
        "source": Source(title="National Career Service", url="https://ncs.gov.in"),
        "portal": "ncs.gov.in",
        "en": (
            "The National Career Service portal lists government and private vacancies "
            "and free skill-training courses, searchable after a free registration; your "
            "district employment exchange does the same offline. I cannot search live "
            "vacancies — NCS has no open search API — so use the portal directly."
        ),
        "ta": (
            "National Career Service போர்ட்டலில் அரசு மற்றும் தனியார் வேலை வாய்ப்புகள், "
            "இலவச திறன் பயிற்சி வகுப்புகள் உள்ளன; இலவசமாகப் பதிவு செய்தால் தேடலாம். "
            "உங்கள் மாவட்ட வேலைவாய்ப்பு அலுவலகமும் இதையே செய்யும். நேரடி வேலை "
            "வாய்ப்புகளை நான் தேட முடியாது — NCS-க்கு திறந்த தேடல் API இல்லை — எனவே "
            "போர்ட்டலையே பயன்படுத்துங்கள்."
        ),
        "hi": (  # NEEDS REVIEW
            "नैशनल करियर सर्विस पोर्टल पर सरकारी और निजी रिक्तियाँ तथा निःशुल्क कौशल "
            "प्रशिक्षण पाठ्यक्रम हैं, जिन्हें मुफ़्त पंजीकरण के बाद खोजा जा सकता है; "
            "आपका ज़िला रोज़गार कार्यालय भी यही करता है। मैं लाइव रिक्तियाँ नहीं खोज "
            "सकता — NCS का कोई खुला सर्च API नहीं है — इसलिए पोर्टल सीधे देखें।"
        ),
        "te": (  # NEEDS REVIEW
            "నేషనల్ కెరీర్ సర్వీస్ పోర్టల్‌లో ప్రభుత్వ, ప్రైవేటు ఉద్యోగ ఖాళీలు, ఉచిత "
            "నైపుణ్య శిక్షణ కోర్సులు ఉన్నాయి; ఉచిత నమోదు తర్వాత వెతకవచ్చు. మీ జిల్లా "
            "ఉపాధి కార్యాలయం కూడా ఇదే చేస్తుంది. ప్రత్యక్ష ఖాళీలను నేను వెతకలేను — "
            "NCS కు బహిరంగ సెర్చ్ API లేదు — కాబట్టి పోర్టల్‌ను నేరుగా చూడండి."
        ),
        "kn": (  # NEEDS REVIEW
            "ನ್ಯಾಷನಲ್ ಕರಿಯರ್ ಸರ್ವಿಸ್ ಪೋರ್ಟಲ್‌ನಲ್ಲಿ ಸರ್ಕಾರಿ ಮತ್ತು ಖಾಸಗಿ ಉದ್ಯೋಗ ಖಾಲಿಗಳು, "
            "ಉಚಿತ ಕೌಶಲ ತರಬೇತಿ ಕೋರ್ಸ್‌ಗಳಿವೆ; ಉಚಿತ ನೋಂದಣಿ ನಂತರ ಹುಡುಕಬಹುದು. ನಿಮ್ಮ ಜಿಲ್ಲಾ "
            "ಉದ್ಯೋಗ ವಿನಿಮಯ ಕಚೇರಿಯೂ ಇದನ್ನೇ ಮಾಡುತ್ತದೆ. ನೇರ ಖಾಲಿಗಳನ್ನು ನಾನು ಹುಡುಕಲಾರೆ — "
            "NCS ಗೆ ಮುಕ್ತ ಸರ್ಚ್ API ಇಲ್ಲ — ಆದ್ದರಿಂದ ಪೋರ್ಟಲ್ ನೇರವಾಗಿ ನೋಡಿ."
        ),
    },
}


@dataclass(frozen=True)
class FaqMatch:
    key: str
    domain: str
    portal: str
    source: Source
    # Body text keyed by language code; always contains "en".
    text: Dict[str, str]

    def body(self, language: str) -> str:
        base = (language or "en").split("-", 1)[0]
        return self.text.get(base) or self.text["en"]


def _keyword_pattern(keyword: str) -> "re.Pattern":
    """
    Same rule as `skills._keyword_pattern`, and for the same reason.

    ASCII keywords get `\\b` so short ones don't match inside longer words
    ("otp" would otherwise match nothing harmful, but "pnr" and "cvv" would
    match inside identifiers). Non-ASCII keywords are matched as substrings,
    because Python's `\\b` is defined via `\\w`, which excludes the combining
    marks Indic words end in — `\\bஓடிபி\\b` would never match.
    """
    escaped = re.escape(keyword)
    return re.compile(rf"\b{escaped}\b" if keyword.isascii() else escaped)


# Longest keyword first, globally. This is what makes "job scam" win over
# "government job" and "fake job" over "नौकरी" — the scam entries have to
# beat the domain entries or a victim gets a careers portal instead of a
# warning. Length ordering handles the cases that matter; it is a heuristic,
# not a parser, and a sentence containing both ("fake job vacancy") can
# still pick the longer of the two keywords.
_COMPILED: List[tuple] = sorted(
    (
        (len(keyword), key, _keyword_pattern(keyword))
        for key, entry in _FAQ.items()
        for keyword in entry["keywords"]
    ),
    key=lambda row: -row[0],
)


def match_faq(text: str) -> Optional[FaqMatch]:
    """
    Find the curated entry a question is about, or None.

    None is the common case and the caller must treat it as "I don't know",
    not as an invitation to generate something.
    """
    if not text:
        return None
    lowered = text.lower()
    for _, key, pattern in _COMPILED:
        if pattern.search(lowered) or pattern.search(text):
            entry = _FAQ[key]
            return FaqMatch(
                key=key,
                domain=entry["domain"],
                portal=entry["portal"],
                source=entry["source"],
                text={
                    lang: value
                    for lang, value in entry.items()
                    if lang not in ("keywords", "domain", "portal", "source")
                },
            )
    return None


# Same wording as `skills._GOV_DOC_NOTES`, kept separate rather than
# imported across a private name. Every curated answer carries it: the body
# is a static summary and the portal is the thing that cannot go stale.
_PORTAL_NOTES = {
    "en": " (General information — confirm the current details on {portal}.)",
    "ta": " (இது பொது தகவல் — தற்போதைய விவரங்களை {portal} இல் சரிபார்க்கவும்.)",
    "hi": " (यह सामान्य जानकारी है — वर्तमान विवरण {portal} पर देख लें।)",  # NEEDS REVIEW
    "te": " (ఇది సాధారణ సమాచారం — ప్రస్తుత వివరాలను {portal} లో నిర్ధారించుకోండి.)",  # NEEDS REVIEW
    "kn": " (ಇದು ಸಾಮಾನ್ಯ ಮಾಹಿತಿ — ಈಗಿನ ವಿವರಗಳನ್ನು {portal} ನಲ್ಲಿ ಪರಿಶೀಲಿಸಿ.)",  # NEEDS REVIEW
}


def format_faq_reply(match: FaqMatch, language: str) -> str:
    """Body in the user's language plus the localized "check the portal" note."""
    base = (language or "en").split("-", 1)[0]
    note = _PORTAL_NOTES.get(base, _PORTAL_NOTES["en"]).format(portal=match.portal)
    return match.body(language) + note


def coverage() -> Dict[str, int]:
    """Entries per domain. Used by the tests and worth quoting in the README."""
    counts: Dict[str, int] = {domain: 0 for domain in DOMAINS}
    for entry in _FAQ.values():
        counts[entry["domain"]] += 1
    return counts


def entry_keys() -> tuple:
    return tuple(_FAQ.keys())


def entries() -> Dict[str, dict]:
    """Read-only-ish view of the raw table, for tests."""
    return _FAQ
