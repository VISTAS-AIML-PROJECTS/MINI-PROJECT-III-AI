"""
Speech-to-Text Service
=========================
Transcribes uploaded audio to text.

Production path: OpenAI Whisper (see `_whisper_transcribe`), which natively
supports Tamil and English and handles code-mixed speech well at the
"small"/"medium" model sizes.

Fallback: this sandbox has no internet/GPU to download Whisper weights, so
when Whisper isn't available the endpoint returns a clear, structured error
telling the frontend to use the browser's built-in Web Speech API instead
(see frontend/src/hooks/useSpeechRecognition.js) — which is how the shipped
demo achieves fully working voice input without any backend ML dependency.
"""
from dataclasses import dataclass
from pathlib import Path

from app.config import settings
from app.services.device import resolve_device

try:
    import whisper  # openai-whisper
    _HAS_WHISPER = True
except ImportError:
    _HAS_WHISPER = False

_whisper_model = None  # lazy-loaded singleton


@dataclass
class TranscriptionResult:
    text: str
    language: str
    confidence: float
    engine: str


def transcribe_audio(file_path: str) -> TranscriptionResult:
    """
    Main entry point used by the /api/speech/transcribe endpoint.

    Raises RuntimeError with a descriptive message when no STT engine is
    available, so the router can return a helpful 501-style response
    instructing the client to fall back to browser-based recognition.
    """
    if _HAS_WHISPER and settings.enable_whisper:
        return _whisper_transcribe(file_path)

    raise RuntimeError(
        "Whisper is not installed in this environment. "
        "Install it via `pip install openai-whisper torch` (see backend/requirements.txt) "
        "to enable server-side transcription, or use the browser's built-in "
        "SpeechRecognition API on the frontend (already wired up as the default)."
    )


def _whisper_transcribe(file_path: str) -> TranscriptionResult:  # pragma: no cover
    """Real Whisper inference — used automatically once the package is installed."""
    global _whisper_model
    if _whisper_model is None:
        # settings.whisper_model_size defaults to "small", a good
        # Tamil/English accuracy-vs-speed tradeoff; bump to "medium" or
        # "large-v3" for higher accuracy if you have the VRAM/time budget.
        _whisper_model = whisper.load_model(
            settings.whisper_model_size, device=resolve_device()
        )

    result = _whisper_model.transcribe(str(Path(file_path)), task="transcribe")
    detected_lang = result.get("language", "en")
    # Whisper uses ISO 639-1 codes already ("ta", "en"), matching our schema.
    # Anything outside our Phase 1 language set collapses to "en" so the
    # rest of the pipeline (which only knows "ta" / "en" / "ta-en") doesn't
    # choke on an unsupported code.
    if detected_lang not in settings.supported_languages:
        detected_lang = "en"

    # Per-segment average log-prob is a reasonable proxy for confidence;
    # Whisper doesn't expose a single top-level confidence score.
    segments = result.get("segments") or []
    if segments:
        avg_logprob = sum(s.get("avg_logprob", -0.5) for s in segments) / len(segments)
        confidence = round(max(0.0, min(1.0, 1.0 + avg_logprob)), 2)
    else:
        confidence = 0.9

    return TranscriptionResult(
        text=result.get("text", "").strip(),
        language=detected_lang,
        confidence=confidence,
        engine="whisper",
    )
