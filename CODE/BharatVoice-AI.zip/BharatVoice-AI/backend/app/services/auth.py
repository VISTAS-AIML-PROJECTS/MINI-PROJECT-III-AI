"""
Accounts, sessions and ownership
===================================
Who a request belongs to, so that conversation history and reminders stop
being one shared pool.

THREE KINDS OF CALLER, and one column that covers all of them:

  1. Signed in. `Authorization: Bearer <token>` resolves to a user, and the
     owner is "user:<id>". History follows the account across devices.
  2. Guest. No account, but the browser sends an `X-Guest-Id` it generated
     once and kept in localStorage. The owner is "guest:<id>". History is
     private to that browser without asking anyone to sign up — which
     matters for an assistant whose first screen is a microphone, not a
     form.
  3. Neither header. The owner is None, and the caller sees only rows that
     have no owner. This is the pre-accounts behaviour, kept so that an
     existing database, a curl command and the API docs page all still work.

Signing in or registering with a guest id present moves that guest's rows
to the account (`claim_guest_rows`), so nobody loses what they did before
deciding to create one.

WHAT IS DELIBERATELY SIMPLE:

  - Passwords are hashed with scrypt from the standard library. No extra
    dependency, and a memory-hard KDF rather than a bare SHA.
  - Session tokens are opaque random strings; only their SHA-256 is stored,
    so a copy of the database is not a set of working logins.
  - There is no email, no password reset and no rate limiting on sign-in.
    Those need a mail provider and a shared counter, neither of which this
    project has. Do not put this on the open internet without them.
"""
import hashlib
import hmac
import re
import secrets
from datetime import timedelta
from typing import Optional

from fastapi import Depends, Header, HTTPException
from sqlalchemy.orm import Session

from app import models
from app.config import settings
from app.database import get_db
from app.models import utcnow

_SCRYPT_N = 2**14
_SCRYPT_R = 8
_SCRYPT_P = 1

# A guest id is client-chosen, so it is constrained to something that can
# only ever be an identifier: no separators that could collide with the
# "user:" namespace, and long enough not to be guessable.
_GUEST_ID = re.compile(r"^[A-Za-z0-9_-]{16,64}$")
_USERNAME = re.compile(r"^[a-z0-9_.-]{3,32}$")


def normalize_username(username: str) -> str:
    return (username or "").strip().lower()


def is_valid_username(username: str) -> bool:
    return bool(_USERNAME.match(username))


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P
    )
    return f"scrypt${_SCRYPT_N}${_SCRYPT_R}${_SCRYPT_P}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt_hex, digest_hex = stored.split("$")
        if scheme != "scrypt":
            return False
        digest = hashlib.scrypt(
            password.encode("utf-8"),
            salt=bytes.fromhex(salt_hex),
            n=int(n),
            r=int(r),
            p=int(p),
        )
    except (ValueError, AttributeError):
        return False
    return hmac.compare_digest(digest.hex(), digest_hex)


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_session(db: Session, user: models.User) -> str:
    """Issue a new token for `user`. The plain token is returned once and
    never stored."""
    token = secrets.token_urlsafe(32)
    db.add(
        models.AuthSession(
            token_hash=_token_hash(token),
            user_id=user.id,
            expires_at=utcnow() + timedelta(days=settings.session_days),
        )
    )
    db.commit()
    return token


def delete_session(db: Session, token: str) -> None:
    db.query(models.AuthSession).filter(
        models.AuthSession.token_hash == _token_hash(token)
    ).delete()
    db.commit()


def _bearer(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        return None
    return token.strip()


def get_current_user(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
) -> Optional[models.User]:
    """
    The signed-in user, or None for a guest.

    A token that is present but wrong is a 401, not a silent downgrade to
    guest: otherwise an expired session would quietly show an empty history
    and the user would conclude their conversations had been deleted.
    """
    token = _bearer(authorization)
    if token is None:
        return None

    session = db.get(models.AuthSession, _token_hash(token))
    if session is None or session.expires_at <= utcnow():
        if session is not None:
            db.delete(session)
            db.commit()
        raise HTTPException(status_code=401, detail="Your session has expired. Please sign in again.")
    return db.get(models.User, session.user_id)


def require_user(user: Optional[models.User] = Depends(get_current_user)) -> models.User:
    if user is None:
        raise HTTPException(status_code=401, detail="Sign in first.")
    return user


def guest_owner(guest_id: Optional[str]) -> Optional[str]:
    if guest_id and _GUEST_ID.match(guest_id):
        return f"guest:{guest_id}"
    return None


def get_owner(
    user: Optional[models.User] = Depends(get_current_user),
    x_guest_id: Optional[str] = Header(default=None),
) -> Optional[str]:
    """The owner key every history and reminder query filters on."""
    if user is not None:
        return f"user:{user.id}"
    return guest_owner(x_guest_id)


def owned(query, model, owner: Optional[str]):
    """Restrict `query` to rows belonging to `owner` (None = unowned rows)."""
    if owner is None:
        return query.filter(model.owner_id.is_(None))
    return query.filter(model.owner_id == owner)


def claim_guest_rows(db: Session, guest_id: Optional[str], user: models.User) -> None:
    """Move a guest's conversations, reminders and push subscriptions to
    the account they just signed in to."""
    source = guest_owner(guest_id)
    if source is None:
        return
    target = f"user:{user.id}"
    for model in models.OWNED_MODELS:
        db.query(model).filter(model.owner_id == source).update(
            {model.owner_id: target}, synchronize_session=False
        )
    db.commit()
