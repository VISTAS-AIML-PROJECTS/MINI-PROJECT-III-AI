"""
Entity Extraction Service
==========================
Extracts PERSON, PLACE, DATE, and TIME entities from user text.

Fallback implementation: regex + curated gazetteers (Indian cities/states,
common Tamil/English time & date expressions). This requires zero heavy
dependencies and covers the majority of assistant-style queries
("weather in Chennai tomorrow", "நாளை மாலை 5 மணிக்கு நினைவூட்டு").

Upgrade path: swap in a MuRIL/IndicNER token-classification pipeline (see
`_transformer_ner`) for open-domain, higher-recall entity extraction.
"""
import logging
import re
from dataclasses import dataclass
from typing import List

from app.config import settings
from app.services.device import resolve_device

try:
    from transformers import pipeline
    _HAS_TRANSFORMERS = True
except ImportError:
    _HAS_TRANSFORMERS = False

_ner_pipeline = None  # lazy-loaded singleton

logger = logging.getLogger(__name__)


def _indicner_enabled() -> bool:
    """Real NER available *and* not force-disabled via `ENABLE_INDICNER=false`."""
    return _HAS_TRANSFORMERS and settings.enable_indicner

# IndicNER's label set (from the Naamapadam dataset) uses these group
# names after aggregation_strategy="simple"; map them onto our schema.
_NER_LABEL_MAP = {
    "PER": "PERSON",
    "PERSON": "PERSON",
    "LOC": "PLACE",
    "LOCATION": "PLACE",
    "ORG": "ORG",
    "ORGANIZATION": "ORG",
}


@dataclass
class ExtractedEntity:
    type: str
    value: str


# A small but practical gazetteer of Indian places (English + Tamil forms).
# Extend freely — this is data, not logic, so it's cheap to grow.
# Surface form -> canonical English name.
#
# The canonical form matters: downstream consumers geocode this value, and
# geocoding services index Indian cities under their English spellings. A
# Tamil speaker asking about "கோயம்புத்தூர்" got no weather at all until
# this map existed, because the name was passed through verbatim and did
# not resolve. Emitting the canonical name keeps one spelling flowing
# through the whole pipeline regardless of which script the user typed.
_PLACE_ALIASES = {
    # --- English / romanized ---
    "chennai": "Chennai", "madras": "Chennai",
    "coimbatore": "Coimbatore", "kovai": "Coimbatore",
    "madurai": "Madurai", "trichy": "Tiruchirappalli",
    "tiruchirappalli": "Tiruchirappalli", "salem": "Salem",
    "tirunelveli": "Tirunelveli", "vellore": "Vellore", "erode": "Erode",
    "thanjavur": "Thanjavur", "tamil nadu": "Tamil Nadu",
    "bangalore": "Bengaluru", "bengaluru": "Bengaluru", "mysore": "Mysuru",
    "mysuru": "Mysuru", "mangalore": "Mangaluru", "hubli": "Hubli",
    "mumbai": "Mumbai", "delhi": "Delhi", "new delhi": "Delhi",
    "hyderabad": "Hyderabad", "kolkata": "Kolkata", "pune": "Pune",
    "kerala": "Kerala", "karnataka": "Karnataka", "telangana": "Telangana",
    "vijayawada": "Vijayawada", "visakhapatnam": "Visakhapatnam",
    "vizag": "Visakhapatnam", "tirupati": "Tirupati", "warangal": "Warangal",
    "lucknow": "Lucknow", "jaipur": "Jaipur", "patna": "Patna",
    "bhopal": "Bhopal", "ahmedabad": "Ahmedabad", "chandigarh": "Chandigarh",
    # --- Tamil ---
    "சென்னை": "Chennai", "கோயம்புத்தூர்": "Coimbatore", "மதுரை": "Madurai",
    "திருச்சி": "Tiruchirappalli", "சேலம்": "Salem", "தமிழ்நாடு": "Tamil Nadu",
    "பெங்களூரு": "Bengaluru", "டெல்லி": "Delhi", "மும்பை": "Mumbai",
    # --- Hindi (Devanagari) ---
    "दिल्ली": "Delhi", "नई दिल्ली": "Delhi", "मुंबई": "Mumbai",
    "चेन्नई": "Chennai", "बेंगलुरु": "Bengaluru", "हैदराबाद": "Hyderabad",
    "कोलकाता": "Kolkata", "पुणे": "Pune", "लखनऊ": "Lucknow",
    "जयपुर": "Jaipur", "पटना": "Patna", "भोपाल": "Bhopal",
    # --- Telugu ---
    "హైదరాబాద్": "Hyderabad", "విజయవాడ": "Vijayawada",
    "విశాఖపట్నం": "Visakhapatnam", "తిరుపతి": "Tirupati",
    "వరంగల్": "Warangal", "చెన్నై": "Chennai", "ఢిల్లీ": "Delhi",
    # --- Kannada ---
    "ಬೆಂಗಳೂರು": "Bengaluru", "ಮೈಸೂರು": "Mysuru", "ಮಂಗಳೂರು": "Mangaluru",
    "ಹುಬ್ಬಳ್ಳಿ": "Hubli", "ಚೆನ್ನೈ": "Chennai", "ದೆಹಲಿ": "Delhi",
}

# Longest surface forms first, so "tamil nadu" wins over "tamil" and
# "new delhi" over "delhi".
_PLACE_SURFACES = sorted(_PLACE_ALIASES, key=len, reverse=True)

# Canonical names, used to stop the PERSON heuristic below from tagging a
# city as a human being.
_PLACE_LOOKUP = {name.lower() for name in _PLACE_ALIASES.values()} | set(_PLACE_ALIASES)

_DATE_WORDS = {
    "today": "today", "tomorrow": "tomorrow", "yesterday": "yesterday",
    "இன்று": "today", "நாளை": "tomorrow", "நேற்று": "yesterday",
}

_TIME_PATTERN = re.compile(
    r"\b(\d{1,2}(:\d{2})?\s?(am|pm|AM|PM))\b|\b(\d{1,2}\s?(மணி|o'?clock))\b"
)

_DATE_PATTERN = re.compile(
    r"\b(\d{1,2}(st|nd|rd|th)?\s(January|February|March|April|May|June|July|"
    r"August|September|October|November|December))\b",
    re.IGNORECASE,
)

# Numeric dates: 3/4/2026, 03-04-26. Common in reminders and exactly the
# shape the arithmetic parser used to misread as a division, so it is worth
# capturing explicitly rather than leaving as an unlabelled number.
_NUMERIC_DATE_PATTERN = re.compile(r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})\b")

# Very light heuristic for PERSON: capitalized word(s) following common
# trigger words. A real NER model does this far better — see upgrade path.
#
# A bare `to` used to be one of the triggers, which made every destination
# a person: "Remind me to go to Chennai tomorrow" produced both
# PERSON: Chennai and PLACE: Chennai. Triggers are now verbs that take a
# human object, and gazetteer places are filtered out regardless.
_PERSON_TRIGGER = re.compile(
    r"\b(?:call|remind|tell|message|ask|inform|text)\s+([A-Z][a-zA-Z]+(?:\s[A-Z][a-zA-Z]+)?)"
)


def extract_entities(text: str, language: str = "en") -> List[ExtractedEntity]:
    """
    Main entry point. Returns a de-duplicated list of extracted entities.

    PERSON/PLACE/ORG come from IndicNER when `transformers` is installed,
    falling back to the gazetteer + heuristic below otherwise. DATE/TIME
    always come from the regex layer regardless — general-purpose NER
    models (IndicNER included) aren't trained to tag date/time expressions,
    so there's no accuracy to gain by routing those through the model.
    """
    entities: List[ExtractedEntity] = []

    if _indicner_enabled():
        try:
            entities.extend(_transformer_ner(text))
        except NotImplementedError:
            entities.extend(_rule_based_place_person(text))
        except Exception:
            # A model that fails at runtime (weights not cached and no
            # network, out of memory, corrupt checkpoint) must degrade to
            # the gazetteer rather than 500 the chat endpoint. Extraction is
            # an enrichment step; losing it should cost recall, not the reply.
            logger.warning("IndicNER inference failed; using rule-based extraction", exc_info=True)
            entities.extend(_rule_based_place_person(text))
    else:
        entities.extend(_rule_based_place_person(text))

    entities.extend(_rule_based_date_time(text))

    # De-duplicate while preserving order
    seen = set()
    unique = []
    for e in entities:
        key = (e.type, e.value.lower())
        if key not in seen:
            seen.add(key)
            unique.append(e)
    return unique


def _rule_based_place_person(text: str) -> List[ExtractedEntity]:
    """Gazetteer + heuristic fallback for PLACE and PERSON only."""
    entities: List[ExtractedEntity] = []
    lowered = text.lower()

    matched_spans = []
    for surface in _PLACE_SURFACES:
        haystack = lowered if surface.isascii() else text
        index = haystack.find(surface)

        # Indic languages attach case endings directly to the noun, so the
        # dictionary form often isn't what appears in the sentence:
        # "ಬೆಂಗಳೂರು" (Bengaluru) shows up as "ಬೆಂಗಳೂರಿನ" (of Bengaluru), and
        # "கோயம்புத்தூர்" as "கோயம்புத்தூரில்" (in Coimbatore). Dropping the
        # final character yields a stem that survives the suffix. Crude
        # compared to a real morphological analyser, but these names are
        # distinctive enough that a stem match is safe, and without it a
        # Kannada speaker simply gets no answer.
        if index == -1 and not surface.isascii() and len(surface) > 3:
            index = haystack.find(surface[:-1])

        if index == -1:
            continue
        # Skip a shorter name sitting inside one already matched, so
        # "New Delhi" doesn't also yield "Delhi".
        if any(start <= index < end for start, end in matched_spans):
            continue
        matched_spans.append((index, index + len(surface)))
        entities.append(ExtractedEntity(type="PLACE", value=_PLACE_ALIASES[surface]))

    for match in _PERSON_TRIGGER.finditer(text):
        candidate = match.group(1)
        if candidate.lower() in _PLACE_LOOKUP:
            continue  # a city is not a person
        entities.append(ExtractedEntity(type="PERSON", value=candidate))

    return entities


def _rule_based_date_time(text: str) -> List[ExtractedEntity]:
    """Regex layer for DATE and TIME — used unconditionally, see docstring above."""
    entities: List[ExtractedEntity] = []
    lowered = text.lower()

    for word, normalized in _DATE_WORDS.items():
        if word in lowered or word in text:
            entities.append(ExtractedEntity(type="DATE", value=normalized))

    for match in _DATE_PATTERN.finditer(text):
        entities.append(ExtractedEntity(type="DATE", value=match.group(1)))

    for match in _NUMERIC_DATE_PATTERN.finditer(text):
        entities.append(ExtractedEntity(type="DATE", value=match.group(1)))

    for match in _TIME_PATTERN.finditer(text):
        val = match.group(1) or match.group(4)
        if val:
            entities.append(ExtractedEntity(type="TIME", value=val.strip()))

    return entities


def _transformer_ner(text: str) -> List[ExtractedEntity]:  # pragma: no cover
    """
    Real IndicNER inference — used automatically once `transformers` (and
    a backend, e.g. `torch`) are installed. ai4bharat/IndicNER is an
    off-the-shelf checkpoint (fine-tuned on the Naamapadam dataset), so
    unlike the intent/language-ID models this needs no training of your
    own — it downloads and works immediately given internet access.
    """
    global _ner_pipeline
    if _ner_pipeline is None:
        device = 0 if resolve_device() == "cuda" else -1
        _ner_pipeline = pipeline(
            "ner",
            model=settings.indicner_model,
            aggregation_strategy="simple",
            device=device,
        )

    raw = _ner_pipeline(text)
    entities: List[ExtractedEntity] = []
    for item in raw:
        mapped_type = _NER_LABEL_MAP.get(item.get("entity_group", "").upper())
        if mapped_type:
            entities.append(ExtractedEntity(type=mapped_type, value=item["word"].strip()))
    return entities
