"""
IMD District Warnings
=======================
Severe-weather warnings from the India Meteorological Department, added to
a weather answer when — and only when — IMD has one in force for the place
asked about.

Open-Meteo (services/weather.py) gives the reading. It does not give
warnings, and for a heat wave or a cyclone the warning is the part that
matters. IMD is the authority for those in India.

>>> STATUS: IMPLEMENTED BUT NEVER EXECUTED AGAINST THE REAL SERVICE. <<<

IMD's API is not open. Access is granted per organisation, on request to
IMD, and is tied to the caller's IP address; `api.imd.gov.in` answers
`401 API key missing` without it. No access was available when this was
written, so the response shape below is taken from IMD's published API
note for the district-warning feed and has NOT been observed:

    [{"Date": "...", "District": "CHENNAI",
      "Day_1": "2,4", "Day1_Color": "3", ...}, ...]

where `Day_1` is a comma-separated list of warning codes for today and
`Day1_Color` is 1 green, 2 yellow, 3 orange, 4 red. `_parse_row` is the
only place those names appear, so a correction is a one-function change.

TO SWITCH IT ON: get access from IMD, then set `IMD_WARNINGS_URL` (the
district-warning endpoint you were given) and, if you were issued one,
`IMD_API_KEY`. Empty URL means dormant: no request is made and weather
answers are exactly what they were.

DESIGN RULES, the same as every other live adapter here:

  - Every failure returns None — no access, timeout, HTTP error, a body in
    an unexpected shape, an unknown district. None means "nothing to add",
    and the weather answer is given without a warning line.
  - That is NOT the same as "no warning in force", and the reply never
    says so. Absence of a warning line makes no claim; an assistant that
    said "no warnings" because a request timed out would be telling someone
    it is safe on no evidence.
  - Green ("no warning") is not reported. Only yellow and above.
  - An unknown warning code is dropped rather than described: a made-up
    label on a hazard warning is worse than a missing one.
"""
import json
import logging
import time
import urllib.request
from dataclasses import dataclass
from typing import List, Optional

from app.config import settings

logger = logging.getLogger(__name__)

SOURCE_TITLE = "India Meteorological Department — district warnings"
SOURCE_URL = "https://mausam.imd.gov.in"

# IMD's published warning codes. 1 is "no warning" and is never surfaced.
WARNING_CODES = {
    2: "heavy_rain",
    3: "heavy_snow",
    4: "thunderstorm",
    5: "hailstorm",
    6: "dust_storm",
    7: "dust_raising_winds",
    8: "strong_winds",
    9: "heat_wave",
    10: "hot_day",
    11: "warm_night",
    12: "cold_wave",
    13: "cold_day",
    14: "ground_frost",
    15: "fog",
}

COLOURS = {2: "yellow", 3: "orange", 4: "red"}

_CACHE_TTL_SECONDS = 30 * 60
_cache: dict = {"at": 0.0, "rows": None}


@dataclass(frozen=True)
class Warning:
    district: str
    hazards: tuple  # keys from WARNING_CODES.values(), in IMD's order
    colour: str  # "yellow" | "orange" | "red"


def is_configured() -> bool:
    return bool((settings.imd_warnings_url or "").strip())


def _normalize(name: str) -> str:
    return "".join(ch for ch in (name or "").lower() if ch.isalnum())


def _fetch_rows() -> Optional[list]:
    """The whole district feed, cached. None on any failure."""
    if _cache["rows"] is not None and time.time() - _cache["at"] < _CACHE_TTL_SECONDS:
        return _cache["rows"]

    headers = {"User-Agent": "BharatVoice-AI/1.0"}
    if (settings.imd_api_key or "").strip():
        headers["x-api-key"] = settings.imd_api_key.strip()
    try:
        request = urllib.request.Request(settings.imd_warnings_url.strip(), headers=headers)
        with urllib.request.urlopen(request, timeout=settings.http_timeout_seconds) as response:
            body = json.loads(response.read().decode("utf-8"))
    except Exception:
        logger.warning("IMD warning lookup failed", exc_info=True)
        return None

    if not isinstance(body, list):
        logger.warning(
            "IMD warning feed was not a list; got %s",
            sorted(body.keys()) if isinstance(body, dict) else type(body).__name__,
        )
        return None

    _cache["at"] = time.time()
    _cache["rows"] = body
    return body


def _parse_row(row: dict) -> Optional[Warning]:
    """One feed row to a `Warning`, or None if there is nothing to report."""
    try:
        colour = COLOURS.get(int(str(row["Day1_Color"]).strip()))
        codes = [int(part) for part in str(row["Day_1"]).split(",") if part.strip()]
        district = str(row["District"]).strip()
    except (KeyError, ValueError, TypeError):
        return None

    hazards = tuple(WARNING_CODES[code] for code in codes if code in WARNING_CODES)
    if colour is None or not hazards or not district:
        return None
    return Warning(district=district.title(), hazards=hazards, colour=colour)


def get_warning(*place_names: Optional[str]) -> Optional[Warning]:
    """
    Today's IMD warning for the first of `place_names` that matches a
    district, or None.

    Several names are accepted because a geocoder returns both a town and
    the district it sits in, and IMD publishes by district.
    """
    if not is_configured():
        return None

    wanted: List[str] = [_normalize(name) for name in place_names if name]
    if not wanted:
        return None

    rows = _fetch_rows()
    if not rows:
        return None

    by_district = {}
    for row in rows:
        if isinstance(row, dict) and row.get("District"):
            by_district.setdefault(_normalize(str(row["District"])), row)

    for name in wanted:
        row = by_district.get(name)
        if row is not None:
            return _parse_row(row)
    return None


def clear_caches() -> None:
    _cache["at"] = 0.0
    _cache["rows"] = None
