"""
Translate Router
===================
Standalone Tamil<->English translation endpoint.
"""
from fastapi import APIRouter

from app import schemas
from app.services.translation import translate

router = APIRouter(prefix="/translate", tags=["Translate"])


@router.post("", response_model=schemas.TranslateResponse)
def translate_text(payload: schemas.TranslateRequest):
    result = translate(payload.text, payload.source_lang, payload.target_lang)
    return schemas.TranslateResponse(
        translated_text=result.translated_text,
        source_lang=payload.source_lang,
        target_lang=payload.target_lang,
        engine=result.engine,
    )
