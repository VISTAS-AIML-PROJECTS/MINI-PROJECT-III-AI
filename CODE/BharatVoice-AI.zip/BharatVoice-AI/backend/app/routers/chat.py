"""
Chat Router
=============
Core conversational endpoint: takes user text (already transcribed if it
came from voice), runs the full NLU pipeline, executes the matched action,
generates a reply, and persists everything — including the reply's sources,
so any answer can be audited later.

Speech synthesis is NOT done here; see step 6. The frontend requests audio
separately, only when the device has no voice for the reply language, so a
text reply is never held up by a TTS round trip.
"""
import uuid
from datetime import timezone

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.services import gemini
from app.services.answers import DomainAnswer
from app.services.auth import get_owner, owned
from app.services.nlu_pipeline import run_nlu
from app.services.response_generator import generate_response
from app.services.timeparse import parse_due_at

router = APIRouter(prefix="/chat", tags=["Chat"])

# Previous messages sent to Gemini with each request (user and assistant
# both count): three exchanges.
GEMINI_HISTORY_MESSAGES = 6


def _serialize_sources(answer: DomainAnswer) -> list[dict]:
    """Flatten `Source` dataclasses for JSON storage and API output."""
    return [
        {
            "title": source.title,
            "url": source.url,
            "checked_on": source.checked_on.isoformat() if source.checked_on else None,
        }
        for source in answer.sources
    ]


@router.post("", response_model=schemas.ChatResponse)
def chat(
    payload: schemas.ChatRequest,
    db: Session = Depends(get_db),
    owner: str | None = Depends(get_owner),
):
    # --- 1. Ensure a conversation exists ---
    conversation = None
    if payload.conversation_id:
        conversation = db.get(models.Conversation, payload.conversation_id)
        # A conversation id belonging to someone else starts a fresh
        # conversation rather than appending to theirs.
        if conversation is not None and conversation.owner_id != owner:
            conversation = None
    if conversation is None:
        conversation = models.Conversation(
            id=str(uuid.uuid4()),
            owner_id=owner,
            title=payload.text[:40] or "New Conversation",
        )
        db.add(conversation)
        db.commit()
        db.refresh(conversation)

    # Earlier turns, oldest first, so Gemini can follow up on them. Read
    # before this message is added, and capped: a long chat shouldn't make
    # every request bigger and slower.
    history: list[tuple[str, str]] = []
    if gemini.is_enabled():
        recent = (
            db.query(models.Message)
            .filter(models.Message.conversation_id == conversation.id)
            # A question and its reply can share a timestamp on Windows'
            # coarse clock; the reply ("assistant") is the later of the two.
            .order_by(models.Message.created_at.desc(), models.Message.role.asc())
            .limit(GEMINI_HISTORY_MESSAGES)
            .all()
        )
        history = [(m.role, m.text) for m in reversed(recent)]

    # --- 2. Run NLU pipeline (language -> intent -> entities) ---
    nlu = run_nlu(payload.text, language_hint=payload.language_hint)

    # --- 3. Persist the user's message ---
    user_message = models.Message(
        id=str(uuid.uuid4()),
        conversation_id=conversation.id,
        role="user",
        text=payload.text,
        language=nlu.language,
        intent=nlu.intent,
        entities=[{"type": e.type, "value": e.value} for e in nlu.entities],
    )
    db.add(user_message)

    # --- 4. Handle intents that need DB access before/alongside the reply ---
    context: dict = {}

    if nlu.intent == "set_reminder":
        time_val = next((e.value for e in nlu.entities if e.type == "TIME"), None)
        date_val = next((e.value for e in nlu.entities if e.type == "DATE"), None)
        person_val = next((e.value for e in nlu.entities if e.type == "PERSON"), None)

        # Parse an actual fire time. `when_label` remains what we show; the
        # parsed `due_at` is what lets the reminder ever go off.
        parsed = parse_due_at(payload.text)
        when_label = (
            parsed.label if parsed else (" ".join(filter(None, [date_val, time_val])) or None)
        )
        reminder = models.Reminder(
            id=str(uuid.uuid4()),
            owner_id=owner,
            text=payload.text,
            when_label=when_label,
            # Stored UTC-naive to match the rest of the schema.
            due_at=parsed.due_at.astimezone(timezone.utc).replace(tzinfo=None) if parsed else None,
            person=person_val,
            language=nlu.language,
        )
        db.add(reminder)
        # Tell the response layer whether we actually understood the timing,
        # so it can say "I couldn't work out when" instead of implying the
        # reminder will fire when it won't.
        context["reminder_scheduled"] = parsed is not None
        context["reminder_when"] = when_label

    elif nlu.intent == "list_reminders":
        pending = (
            owned(db.query(models.Reminder), models.Reminder, owner)
            .filter(models.Reminder.is_done == "pending")
            .order_by(models.Reminder.created_at.desc())
            .all()
        )
        context["reminders"] = [
            " — ".join(
                filter(
                    None,
                    [r.when_label, r.person, r.text if not r.when_label else None],
                )
            )
            for r in pending
        ]

    # --- 5. Generate the assistant's reply (action execution + NLG) ---
    if gemini.is_enabled() and nlu.intent not in gemini.LOCAL_INTENTS:
        # Gemini is the only outside service: the weather, mandi and
        # hospital lookups in generate_response are never reached.
        answer = gemini.gemini_reply(
            text=payload.text,
            language=nlu.language,
            intent=nlu.intent,
            history=history,
        ) or gemini.unavailable(nlu.language)
    else:
        answer = generate_response(
            text=payload.text,
            language=nlu.language,
            intent=nlu.intent,
            entities=nlu.entities,
            context=context,
        )
        # A local answer (reminder, clock, maths, helplines) is reworded by
        # Gemini when it's on; if Gemini fails, the local answer stands.
        if gemini.is_enabled():
            answer = gemini.gemini_reply(
                text=payload.text,
                language=nlu.language,
                intent=nlu.intent,
                draft=answer,
                history=history,
            ) or answer
    serialized_sources = _serialize_sources(answer)

    # --- 6. Text-to-speech: deliberately NOT done here ---
    # This used to call synthesize_speech() inline, which was free only for
    # as long as no server TTS engine was configured. The moment one is, it
    # puts a full synthesis — a network round trip to Bhashini, seconds of
    # it — in front of every reply, including typed ones the user may never
    # play, and including the ones where their device has a perfectly good
    # voice and the audio would be discarded unheard.
    #
    # The frontend now asks for audio from POST /api/speech/synthesize only
    # when it actually needs it: when the device has no voice for the reply
    # language, or when the user presses replay. The text reply is never
    # delayed by speech.
    #
    # `audio_url` stays in the schema and on the persisted message so a
    # replay can be cached against it later; it is simply None at this
    # point, which is what it has always been in practice.
    audio_url = None

    # --- 7. Persist the assistant's message ---
    assistant_message = models.Message(
        id=str(uuid.uuid4()),
        conversation_id=conversation.id,
        role="assistant",
        text=answer.text,
        language=answer.language,
        sources=serialized_sources or None,
        dialable=answer.dialable or None,
        audio_url=audio_url,
    )
    db.add(assistant_message)
    db.commit()
    db.refresh(assistant_message)

    return schemas.ChatResponse(
        conversation_id=conversation.id,
        message_id=assistant_message.id,
        reply_text=answer.text,
        reply_language=answer.language,
        nlu=schemas.NluResult(
            language=nlu.language,
            language_confidence=nlu.language_confidence,
            intent=nlu.intent,
            intent_confidence=nlu.intent_confidence,
            entities=[schemas.Entity(type=e.type, value=e.value) for e in nlu.entities],
        ),
        audio_url=audio_url,
        sources=[schemas.SourceOut(**source) for source in serialized_sources],
        is_refusal=answer.is_refusal,
        staleness=answer.staleness,
        dialable=answer.dialable,
    )
