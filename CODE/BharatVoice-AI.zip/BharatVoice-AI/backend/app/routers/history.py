"""
History Router
=================
Retrieve past conversations and messages for the chat history view.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.services.auth import get_owner, owned

router = APIRouter(prefix="/history", tags=["History"])


@router.get("/conversations", response_model=list[schemas.ConversationSummary])
def list_conversations(db: Session = Depends(get_db), owner: str | None = Depends(get_owner)):
    conversations = (
        owned(db.query(models.Conversation), models.Conversation, owner)
        .order_by(models.Conversation.created_at.desc())
        .all()
    )
    return [
        schemas.ConversationSummary(
            id=c.id,
            title=c.title,
            created_at=c.created_at,
            message_count=db.query(func.count(models.Message.id))
            .filter(models.Message.conversation_id == c.id)
            .scalar(),
        )
        for c in conversations
    ]


@router.get("/conversations/{conversation_id}", response_model=schemas.ConversationOut)
def get_conversation(
    conversation_id: str, db: Session = Depends(get_db), owner: str | None = Depends(get_owner)
):
    conversation = db.get(models.Conversation, conversation_id)
    # Another owner's conversation is "not found", so ids cannot be probed.
    if not conversation or conversation.owner_id != owner:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conversation


@router.delete("/conversations/{conversation_id}")
def delete_conversation(
    conversation_id: str, db: Session = Depends(get_db), owner: str | None = Depends(get_owner)
):
    conversation = db.get(models.Conversation, conversation_id)
    # Another owner's conversation is "not found", so ids cannot be probed.
    if not conversation or conversation.owner_id != owner:
        raise HTTPException(status_code=404, detail="Conversation not found")
    db.delete(conversation)
    db.commit()
    return {"status": "deleted", "id": conversation_id}
