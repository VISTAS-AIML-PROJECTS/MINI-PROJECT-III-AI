"""
Intent Router
===============
Standalone intent-detection + entity-extraction endpoint (also used
internally by /api/chat).
"""
from fastapi import APIRouter

from app import schemas
from app.services.entity_extraction import extract_entities
from app.services.intent_detection import detect_intent

router = APIRouter(prefix="/intent", tags=["Intent"])


@router.post("/detect", response_model=schemas.IntentDetectResponse)
def detect(payload: schemas.IntentDetectRequest):
    intent_result = detect_intent(payload.text, language=payload.language or "en")
    entities = extract_entities(payload.text, language=payload.language or "en")

    return schemas.IntentDetectResponse(
        intent=intent_result.intent,
        confidence=intent_result.confidence,
        entities=[schemas.Entity(type=e.type, value=e.value) for e in entities],
        engine=intent_result.engine,
    )
