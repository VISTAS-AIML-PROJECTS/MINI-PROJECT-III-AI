"""
Speech Router
===============
Endpoints for speech-to-text (audio upload -> transcript) and
text-to-speech (text -> audio file URL).

Both gracefully degrade: if the heavy ML engines (Whisper / Coqui TTS)
aren't installed, they respond with a structured payload telling the
frontend to use the browser's native Web Speech APIs instead — which is
how voice works out-of-the-box in this project.

NOTE ON CONCURRENCY: the transcription endpoints are deliberately plain
`def`, not `async def`. Reading the upload and running a speech model are
both blocking, CPU-bound operations; inside a coroutine they would occupy
the event loop for the entire transcription and stall every other request,
including the container's health check. FastAPI runs sync endpoints in a
threadpool, which is what we want here.
"""
import tempfile
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile

from app import schemas
from app.config import settings
from app.services.language_detection import detect_language
from app.services.speech_to_text import transcribe_audio
from app.services.text_to_speech import capabilities as tts_capabilities
from app.services.text_to_speech import synthesize_speech

router = APIRouter(prefix="/speech", tags=["Speech"])


def _save_upload(file: UploadFile) -> str:
    """
    Stream an upload to a temp file, refusing anything over the configured
    size limit.

    The cap matters because these endpoints are unauthenticated: without it
    a single request can fill the container's disk. Streaming in chunks
    rather than `copyfileobj` means an oversized upload is rejected partway
    instead of after it has all been written.
    """
    suffix = Path(file.filename or "audio.webm").suffix or ".webm"
    limit = settings.max_upload_bytes
    written = 0

    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp_path = tmp.name
        while chunk := file.file.read(1024 * 1024):
            written += len(chunk)
            if written > limit:
                tmp.close()
                Path(tmp_path).unlink(missing_ok=True)
                raise HTTPException(
                    status_code=413,
                    detail=f"Audio upload exceeds the {limit // (1024 * 1024)} MB limit.",
                )
            tmp.write(chunk)
    return tmp_path


@router.post("/transcribe", response_model=schemas.SpeechToTextResponse)
def transcribe(file: UploadFile = File(...)):
    """
    Accepts an audio file (webm/wav/mp3) and returns its transcript.
    Requires `openai-whisper` to be installed — otherwise returns 501 with
    guidance to use the browser fallback (already the default in the UI).
    """
    tmp_path = _save_upload(file)
    try:
        result = transcribe_audio(tmp_path)
    except RuntimeError as e:
        raise HTTPException(status_code=501, detail=str(e))
    finally:
        Path(tmp_path).unlink(missing_ok=True)

    return schemas.SpeechToTextResponse(
        text=result.text,
        language=result.language,
        confidence=result.confidence,
        engine=result.engine,
    )


@router.post("/synthesize")
def synthesize(payload: schemas.TextToSpeechRequest):
    """
    Synthesizes speech for the given text.

    The frontend calls this only when it needs to: when the device has no
    voice for the reply language, or when the user presses replay on a
    reply that had none. A device with a voice never comes here at all.

    `audio_url=None` with `engine="browser-fallback"` is a normal answer,
    not an error — it means no server engine could speak this language, and
    the UI should say so while keeping the text visible. Returning 200 is
    deliberate: a 5xx would make an expected, explainable state look like a
    crash in the network tab and in the frontend's error handling.
    """
    result = synthesize_speech(payload.text, language=payload.language)
    return {"audio_url": result.audio_url, "engine": result.engine}


@router.get("/capabilities")
def capabilities():
    """
    What the server can speak, per language — asked once at startup.

    This exists so the UI can tell a user "no Tamil voice on this device and
    none on the server either, here is the answer as text" *before*
    attempting playback, instead of producing silence and then explaining
    it. Combined with the browser's own voice list, it is everything the
    frontend needs to describe the real state of speech for each language.
    """
    return tts_capabilities()


@router.post("/detect-language-from-audio")
def detect_language_from_audio(file: UploadFile = File(...)):
    """Convenience endpoint: transcribe then detect language in one call."""
    tmp_path = _save_upload(file)
    try:
        transcription = transcribe_audio(tmp_path)
    except RuntimeError as e:
        raise HTTPException(status_code=501, detail=str(e))
    finally:
        Path(tmp_path).unlink(missing_ok=True)

    lang = detect_language(transcription.text)
    return {
        "text": transcription.text,
        "language": lang.language,
        "confidence": lang.confidence,
    }
