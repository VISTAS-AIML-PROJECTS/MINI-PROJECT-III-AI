"""
Language Router
==================
Standalone language-detection endpoint (also used internally by /api/chat),
plus the support matrix the UI uses to be honest about each language.
"""
from fastapi import APIRouter

from app import schemas
from app.services import about
from app.services.language_detection import detect_language

router = APIRouter(prefix="/language", tags=["Language"])


@router.get("/support")
def support():
    """
    Per-language status, straight from `about.LANGUAGE_SUPPORT`.

    The frontend shows a "translation not yet reviewed" note against the
    languages whose wording no native speaker has read. That fact lives in
    exactly one place — this table — so the UI badge and the assistant's
    own answer about which languages it supports cannot disagree. The
    frontend degrades to showing no badge if this call fails.
    """
    return {
        "languages": [
            {"code": code, **row} for code, row in about.LANGUAGE_SUPPORT.items()
        ],
        "unreviewed": list(about.UNREVIEWED),
    }


@router.post("/detect", response_model=schemas.LanguageDetectResponse)
def detect(payload: schemas.LanguageDetectRequest):
    result = detect_language(payload.text)
    return schemas.LanguageDetectResponse(
        language=result.language,
        confidence=result.confidence,
        engine=result.engine,
    )
