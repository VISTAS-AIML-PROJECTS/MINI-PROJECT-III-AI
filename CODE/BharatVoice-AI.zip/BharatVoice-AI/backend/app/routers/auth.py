"""
Auth Router
=============
Register, sign in, sign out, and "who am I".

Accounts are optional. A browser that never signs in is a guest with its
own private history (see services/auth.py); these endpoints exist so that
history can follow a person from one device to another.
"""
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.services import auth

router = APIRouter(prefix="/auth", tags=["Auth"])

# One message for both "no such user" and "wrong password", so the endpoint
# cannot be used to find out which usernames exist.
_BAD_LOGIN = "That username and password don't match."


@router.post("/register", response_model=schemas.AuthResponse, status_code=201)
def register(
    payload: schemas.Credentials,
    db: Session = Depends(get_db),
    x_guest_id: Optional[str] = Header(default=None),
):
    username = auth.normalize_username(payload.username)
    if not auth.is_valid_username(username):
        raise HTTPException(
            status_code=422,
            detail="Usernames are 3 to 32 characters: letters, digits, dot, dash or underscore.",
        )
    if db.query(models.User).filter(models.User.username == username).first():
        raise HTTPException(status_code=409, detail="That username is already taken.")

    user = models.User(username=username, password_hash=auth.hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)

    auth.claim_guest_rows(db, x_guest_id, user)
    return schemas.AuthResponse(token=auth.create_session(db, user), user=user)


@router.post("/login", response_model=schemas.AuthResponse)
def login(
    payload: schemas.Credentials,
    db: Session = Depends(get_db),
    x_guest_id: Optional[str] = Header(default=None),
):
    username = auth.normalize_username(payload.username)
    user = db.query(models.User).filter(models.User.username == username).first()
    if user is None or not auth.verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail=_BAD_LOGIN)

    auth.claim_guest_rows(db, x_guest_id, user)
    return schemas.AuthResponse(token=auth.create_session(db, user), user=user)


@router.post("/logout")
def logout(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """Ends this sign-in only. Idempotent: an unknown token is still a 200,
    because the caller's goal — not being signed in — is already met."""
    token = auth._bearer(authorization)
    if token:
        auth.delete_session(db, token)
    return {"status": "signed-out"}


@router.get("/me", response_model=schemas.UserOut)
def me(user: models.User = Depends(auth.require_user)):
    return user
