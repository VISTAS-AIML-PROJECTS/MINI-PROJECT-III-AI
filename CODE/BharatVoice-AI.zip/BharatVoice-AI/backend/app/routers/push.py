"""
Push Router
=============
Lets a browser register for reminder notifications that arrive when the
app is closed. See services/push.py for the whole picture.
"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.services import push
from app.services.auth import get_owner

router = APIRouter(prefix="/push", tags=["Push"])


@router.get("/public-key")
def public_key():
    """The key the browser needs to subscribe. `enabled: false` means this
    server cannot send push, and the UI should not offer it."""
    key = push.public_key()
    return {"enabled": key is not None, "key": key}


@router.post("/subscribe")
def subscribe(
    payload: schemas.PushSubscriptionIn,
    db: Session = Depends(get_db),
    owner: Optional[str] = Depends(get_owner),
):
    if owner is None:
        # Without an owner there is no way to know whose reminders this
        # device should hear about.
        raise HTTPException(status_code=400, detail="Notifications need a guest id or a sign-in.")
    if not push.is_enabled():
        raise HTTPException(status_code=503, detail="Notifications are not available on this server.")
    if not push.is_allowed_endpoint(payload.endpoint):
        raise HTTPException(status_code=422, detail="That is not a recognised push service.")

    # One row per browser. Re-subscribing — after signing in or out, or
    # when the browser rotates its keys — moves the existing row to the
    # current owner instead of leaving the old owner's reminders arriving
    # on a device that is no longer theirs.
    subscription = (
        db.query(models.PushSubscription)
        .filter(models.PushSubscription.endpoint == payload.endpoint)
        .first()
    )
    if subscription is None:
        subscription = models.PushSubscription(endpoint=payload.endpoint)
        db.add(subscription)
    subscription.owner_id = owner
    subscription.p256dh = payload.keys.p256dh
    subscription.auth = payload.keys.auth
    db.commit()
    return {"status": "subscribed"}


@router.post("/unsubscribe")
def unsubscribe(payload: schemas.PushUnsubscribeIn, db: Session = Depends(get_db)):
    """Keyed by endpoint alone: the endpoint is an unguessable capability
    URL only that browser holds, and a browser must be able to turn
    notifications off even after its session has expired."""
    db.query(models.PushSubscription).filter(
        models.PushSubscription.endpoint == payload.endpoint
    ).delete()
    db.commit()
    return {"status": "unsubscribed"}
