"""
Reminders Router
===================
Lets the frontend show a "My Reminders" panel independent of chat —
reminders are created via the `set_reminder` chat intent (see
routers/chat.py) but read/managed here as their own resource.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.models import utcnow
from app.services.auth import get_owner, owned

router = APIRouter(prefix="/reminders", tags=["Reminders"])


@router.get("", response_model=list[schemas.ReminderOut])
def list_reminders(db: Session = Depends(get_db), owner: str | None = Depends(get_owner)):
    return (
        owned(db.query(models.Reminder), models.Reminder, owner)
        .order_by(models.Reminder.created_at.desc())
        .all()
    )


@router.get("/due", response_model=list[schemas.ReminderOut])
def list_due(db: Session = Depends(get_db), owner: str | None = Depends(get_owner)):
    """
    Reminders whose time has arrived and which haven't been shown yet.

    This is what makes a reminder a reminder. The frontend polls this and
    surfaces anything it returns, marking each as notified so it fires once
    rather than on every poll.

    Polling is the right amount of machinery here: there is no auth and no
    push infrastructure, the client is a single browser tab, and a 30-second
    granularity is invisible for "remind me at 6pm". A background scheduler
    with web-push is the upgrade, and it needs user accounts first.
    """
    now = utcnow()
    due = (
        owned(db.query(models.Reminder), models.Reminder, owner)
        .filter(
            models.Reminder.due_at.isnot(None),
            models.Reminder.due_at <= now,
            models.Reminder.notified_at.is_(None),
            models.Reminder.is_done == "pending",
        )
        .order_by(models.Reminder.due_at.asc())
        .all()
    )

    for reminder in due:
        reminder.notified_at = now
    db.commit()

    return due


@router.patch("/{reminder_id}/done", response_model=schemas.ReminderOut)
def mark_done(
    reminder_id: str, db: Session = Depends(get_db), owner: str | None = Depends(get_owner)
):
    reminder = db.get(models.Reminder, reminder_id)
    # Someone else's reminder is reported as missing, not forbidden: a 403
    # would confirm the id exists.
    if not reminder or reminder.owner_id != owner:
        raise HTTPException(status_code=404, detail="Reminder not found")
    reminder.is_done = "done"
    db.commit()
    db.refresh(reminder)
    return reminder


@router.delete("/{reminder_id}")
def delete_reminder(
    reminder_id: str, db: Session = Depends(get_db), owner: str | None = Depends(get_owner)
):
    reminder = db.get(models.Reminder, reminder_id)
    # Someone else's reminder is reported as missing, not forbidden: a 403
    # would confirm the id exists.
    if not reminder or reminder.owner_id != owner:
        raise HTTPException(status_code=404, detail="Reminder not found")
    db.delete(reminder)
    db.commit()
    return {"status": "deleted", "id": reminder_id}
