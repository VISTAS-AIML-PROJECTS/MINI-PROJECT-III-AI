"""
SQLite database setup via SQLAlchemy.

Provides a session factory and a FastAPI dependency (`get_db`) used across
routers to access the database.
"""
from pathlib import Path
from typing import Optional

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import settings

# `check_same_thread` is required for SQLite when used with FastAPI's
# threaded request handling.
engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI dependency that yields a DB session and closes it afterwards."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


MIGRATIONS_DIR = Path(__file__).resolve().parent.parent / "migrations"


def run_migrations(database_url: Optional[str] = None) -> None:
    """
    Bring a database up to the latest schema with Alembic.

    Works on a brand-new database, on one created before migrations existed
    (the baseline revision is written to adopt those — see
    migrations/versions/0001_baseline.py), and on one that is already
    current, where it does nothing.

    The script location is an absolute path so this behaves the same from
    `uvicorn`, from pytest and from inside the Docker image, whatever the
    working directory is.
    """
    from alembic import command
    from alembic.config import Config

    config = Config()
    config.set_main_option("script_location", str(MIGRATIONS_DIR))
    # "%" is configparser's interpolation character; a URL containing one
    # (an escaped password, say) has to have it doubled.
    config.set_main_option("sqlalchemy.url", (database_url or settings.database_url).replace("%", "%%"))
    config.attributes["embedded"] = True
    command.upgrade(config, "head")


def init_db():
    """Apply pending migrations. Called once on application startup."""
    run_migrations()
