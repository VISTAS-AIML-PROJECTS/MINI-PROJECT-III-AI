"""
Centralized application configuration.

Values are read from environment variables (see .env.example) with sane
defaults so the app runs immediately in a dev environment.

Every flag here is *read by something*. If you add one, wire it up in the
same change — a setting that silently does nothing is worse than no
setting, because it documents behaviour the code doesn't have.
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # `extra="ignore"` matters: pydantic-settings reads *every* key out of
    # a .env file, not just declared ones, and the default behaviour is to
    # reject unknown keys. Without this, a leftover line in someone's local
    # .env stops the whole app from booting.
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- General ---
    app_name: str = "BharatVoice AI"
    api_prefix: str = "/api"
    # Passed to FastAPI. Keep false in anything internet-facing: it turns
    # on tracebacks in HTTP responses.
    debug: bool = False

    # --- Database ---
    database_url: str = "sqlite:///./bharatvoice.db"

    # --- CORS ---
    allowed_origins: list[str] = [
        "http://localhost:5173",  # Vite dev server
        "http://127.0.0.1:5173",
        "http://localhost:3000",  # nginx container (docker compose)
    ]

    # --- Outbound HTTP (live data sources) --------------------------------
    # Kept short: a citizen waiting on a voice reply would rather be told
    # "couldn't check" than sit through a 30-second upstream stall. The
    # AGMARKNET endpoint on data.gov.in has been observed returning 502/504
    # after 45+ seconds, so this ceiling is load-bearing, not theoretical.
    http_timeout_seconds: float = 6.0

    # Your own free key from https://data.gov.in (register, then "Generate
    # API key"). Required for mandi prices: the shared demo key printed in
    # data.gov.in's own examples is permanently rate-limited, so it is not
    # a usable default. Empty means the mandi service reports that it
    # cannot check and deep links to agmarknet.gov.in — it never guesses a
    # price. See services/mandi.py.
    data_gov_api_key: str = ""

    # National Hospital Directory on data.gov.in (services/hospitals.py).
    # Uses `data_gov_api_key` above. The id is unverified against a live
    # response; if data.gov.in re-publishes the dataset, change it here.
    # Empty disables the lookup and hospital questions get the curated
    # answer only.
    hospital_resource_id: str = "98fa254e-c5f8-4910-a19b-4828939b477d"

    # --- IMD district warnings (services/imd.py) --------------------------
    # IMD grants API access per organisation and per IP address, on request.
    # Set the URL to the district-warning endpoint you were given, and the
    # key if you were issued one. Empty URL means dormant: no request is
    # made and weather answers carry no warning line.
    imd_warnings_url: str = ""
    imd_api_key: str = ""

    # --- Bhashini (server-side TTS for languages the device has no voice
    #     for) -----------------------------------------------------------
    # Bhashini is MeitY's national speech stack. It is the only provider
    # wired here that covers all five languages this app supports: Coqui
    # XTTS-v2, the other option, has no Tamil, Telugu or Kannada at all, so
    # it cannot answer the "device has no Indic voice" case that this
    # setting exists for.
    #
    # Both values come from an ULCA account at https://bhashini.gov.in
    # (Sign up -> profile -> "User ID" and "ULCA API key"). Free tier is
    # proof-of-concept use only under their terms — do not point a
    # production deployment at it.
    #
    # Empty means the provider stays dormant: TTS falls through to the
    # browser's own voices, and the UI says plainly when a language has no
    # voice rather than going silent. Nothing breaks without a key.
    bhashini_user_id: str = ""
    bhashini_api_key: str = ""
    # MeitY's public pipeline. Overridable because ULCA accounts can be
    # granted their own pipeline ids.
    bhashini_pipeline_id: str = "64392f96daac500b55c543cd"
    bhashini_auth_url: str = (
        "https://meity-auth.ulcacontrib.org/ulca/apis/v0/model/getModelsPipeline"
    )
    # "female" or "male". Bhashini rejects anything else.
    bhashini_voice_gender: str = "female"
    # Synthesis is slower than a text reply and is only ever needed when the
    # device lacks a voice, so it gets its own, longer ceiling rather than
    # borrowing http_timeout_seconds.
    bhashini_timeout_seconds: float = 20.0

    # --- Gemini (services/gemini.py) --------------------------------------
    # Set a key and Gemini answers every chat message, and is the only
    # outside service a message reaches: weather, mandi prices and hospital
    # questions go to Gemini, not to Open-Meteo or data.gov.in. Reminders,
    # the clock, arithmetic and helplines are still worked out locally (no
    # API involved), and Gemini only rewords those.
    # Get a key at https://aistudio.google.com/apikey.
    #
    # Empty means off: replies come from the rule-based pipeline and its
    # live lookups, as they did before. If Gemini fails on a message the
    # reply says so; it doesn't quietly switch to another service.
    gemini_api_key: str = ""
    # Any model id that supports generateContent. Flash is the fast, cheap
    # tier, which suits short spoken replies.
    gemini_model: str = "gemini-3.5-flash"
    gemini_temperature: float = 0.4
    # Gemini 3 models "think" before answering, and those thinking tokens
    # come out of this same limit: at 400, a Tamil greeting used 449 on
    # thinking and was cut off after 14 tokens of reply. The prompt keeps
    # replies short; this only has to leave room for the thinking.
    gemini_max_output_tokens: int = 2048
    # How much the model thinks first: "minimal", "low", "medium" or "high".
    # Low keeps a short spoken reply to a few seconds.
    gemini_thinking_level: str = "low"
    # Measured 2–7 s for gemini-3.5-flash on this connection; 30 leaves
    # room for a slow network without leaving someone waiting forever.
    gemini_timeout_seconds: float = 30.0

    # --- Accounts ---------------------------------------------------------
    # How long a sign-in lasts. Long, because the alternative on a shared
    # family phone is retyping a password to ask for the weather.
    session_days: int = 30

    # --- Reminder notifications (services/push.py) ------------------------
    # VAPID keys sign web-push messages. Leave both empty and a pair is
    # generated on first use and saved to `vapid_keys_path`; set them only
    # if you need the same keys across several machines.
    vapid_private_key: str = ""
    vapid_public_key: str = ""
    vapid_keys_path: str = "vapid_keys.json"
    # Push services want a contact for the sender. Use a real mailto: or
    # https: address before running this anywhere public.
    vapid_subject: str = "mailto:admin@example.com"
    # How often the background pass looks for due reminders. 0 disables it,
    # leaving reminders to the in-page poll only.
    reminder_push_interval_seconds: float = 20.0

    # --- Request limits ---------------------------------------------------
    # /api/chat is unauthenticated, so every input needs a ceiling. The
    # character cap also bounds the arithmetic parser in services/skills.py.
    max_input_chars: int = 2000
    # 10 MB is generous for ~2 minutes of compressed speech and small
    # enough that a malicious upload can't fill the container's disk.
    max_upload_bytes: int = 10 * 1024 * 1024

    # --- Feature flags for swapping fallback <-> real ML models ---
    # Each is checked alongside the library-import probe in the matching
    # service, so a model can be switched off without uninstalling its
    # package (useful when a checkpoint turns out to be bad).
    enable_whisper: bool = True
    enable_muril: bool = True
    # Off by default: ai4bharat/IndicNER is a gated Hugging Face repo, so
    # without an approved, logged-in account every message tries the
    # download, gets a 401 and falls back to the rules anyway.
    enable_indicner: bool = False
    enable_indictrans2: bool = True
    enable_coqui_tts: bool = True

    # Below this score, a fine-tuned classifier's answer is discarded in
    # favour of the rule-based one. A model trained on a partial label set
    # is confidently wrong rather than uncertain, so this is a floor on
    # *trust*, not a measure of difficulty.
    intent_confidence_threshold: float = 0.75
    # How a fine-tuned intent model is combined with the rules.
    #   "fallback": rules first; the model is asked only when the rules find
    #               nothing ("general_query"). It can add coverage but can
    #               never override a rule that matched.
    #   "primary":  the model first, rules below the confidence floor.
    # Choose with `python scripts/evaluate_muril.py`, which scores both.
    muril_intent_mode: str = "fallback"

    # The floor for the fine-tuned language-ID model, and deliberately
    # higher than the intent one. A wrong intent gets an off-topic answer; a
    # wrong language gets an answer in a script the person may not be able
    # to read, and moves the microphone to that language for their next
    # sentence. Measured on the checkpoint trained 2026-10-09: at 0.75 it
    # answered "tomato mandi price" in Kannada (0.88 sure); at 0.95 that
    # and most Tamil/Telugu/Kannada mix-ups fall back to English, for the
    # loss of one correct answer in 92 test sentences.
    langid_confidence_threshold: float = 0.95

    # --- Supported languages ---
    # Tamil, Hindi, Telugu, Kannada + English. Language detection also
    # returns code-mixed markers ("ta-en", "hi-en", …) which are not listed
    # here because they are derived, not independently supported.
    supported_languages: list[str] = ["ta", "hi", "te", "kn", "en"]

    # --- Device selection for all local model inference (Whisper, MuRIL,
    #     IndicTrans2, Coqui). "auto" picks CUDA if available, else CPU. ---
    ml_device: str = "auto"

    # --- Whisper (speech-to-text) ---
    # One of tiny/base/small/medium/large-v3. "small" is a good
    # accuracy/speed tradeoff for Tamil + English on a single GPU.
    whisper_model_size: str = "small"

    # --- IndicTrans2 (translation) ---
    # Distilled 200M checkpoints keep latency reasonable on a single GPU;
    # swap for the 1B checkpoints (ai4bharat/indictrans2-en-indic-1B /
    # indictrans2-indic-en-1B) for higher quality if you have the VRAM.
    indictrans2_en_indic_model: str = "ai4bharat/indictrans2-en-indic-dist-200M"
    indictrans2_indic_en_model: str = "ai4bharat/indictrans2-indic-en-dist-200M"

    # --- IndicNER (entity extraction) ---
    indicner_model: str = "ai4bharat/IndicNER"

    # --- MuRIL fine-tuned heads (intent + language-ID) ---
    # There is no off-the-shelf checkpoint for these two tasks — they need
    # a short fine-tune on your own labeled data (see
    # backend/scripts/train_muril_intent.py and train_muril_langid.py).
    # Point these at the resulting output directory once trained; until
    # then, the paths simply won't exist and the app cleanly falls back to
    # the rule-based classifiers. The base encoder to fine-tune *from* is
    # the training scripts' own --base-model flag, not a setting here.
    muril_intent_model_path: str = "app/services/models/muril_intent"
    muril_langid_model_path: str = "app/services/models/muril_langid"

    # --- Coqui TTS ---
    coqui_tts_model: str = "tts_models/multilingual/multi-dataset/xtts_v2"


settings = Settings()
