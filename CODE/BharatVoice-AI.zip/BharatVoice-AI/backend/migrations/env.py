"""
Alembic environment.

Two callers reach this file: the `alembic` command line (via alembic.ini)
and the app itself on startup (app/database.py -> run_migrations). Both get
the database URL from the same place, in this order:

  1. `sqlalchemy.url` set on the config object by the caller — which is how
     the app and the tests point a migration at a specific database;
  2. the app's own settings (DATABASE_URL / backend/.env).
"""
from logging.config import fileConfig

from alembic import context
from sqlalchemy import create_engine

from app import models  # noqa: F401  (registers every table on Base.metadata)
from app.config import settings
from app.database import Base

config = context.config

# Only the command line gets Alembic's logging setup. When the app runs
# migrations at startup it has its own logging, and fileConfig would
# silently replace it.
if config.config_file_name is not None and not config.attributes.get("embedded"):
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def _url() -> str:
    return config.get_main_option("sqlalchemy.url") or settings.database_url


def run_migrations_offline() -> None:
    """Emit SQL to stdout instead of running it (`alembic upgrade --sql`)."""
    context.configure(
        url=_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        render_as_batch=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    url = _url()
    connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
    engine = create_engine(url, connect_args=connect_args)
    with engine.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            # SQLite cannot ALTER most things in place. Batch mode makes
            # Alembic rebuild the table instead, so a future "drop column"
            # or "change type" migration works here as it would on Postgres.
            render_as_batch=True,
        )
        with context.begin_transaction():
            context.run_migrations()
    engine.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
