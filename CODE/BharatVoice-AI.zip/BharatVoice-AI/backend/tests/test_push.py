"""
Reminder notifications over web push.

No test here talks to a real push service: `push._send` or `push.webpush`
is replaced each time. What is tested is everything around the send — who
gets which reminder, that one fires once, and that a failure loses nothing.
"""
import json
import tempfile
from datetime import datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import models
from app.config import settings
from app.database import Base, get_db
from app.main import app
from app.services import push

GUEST_A = {"X-Guest-Id": "guest-aaaaaaaaaaaaaaaa"}
GUEST_B = {"X-Guest-Id": "guest-bbbbbbbbbbbbbbbb"}
ENDPOINT_A = "https://fcm.googleapis.com/fcm/send/device-a"
ENDPOINT_B = "https://updates.push.services.mozilla.com/wpush/v2/device-b"
KEYS = {"p256dh": "BPublicKeyFromTheBrowser", "auth": "authsecret"}


@pytest.fixture(autouse=True)
def isolated_keys(monkeypatch):
    """Each test gets its own key file, so nothing is written into the
    working directory and no test depends on another's keys."""
    monkeypatch.setattr(settings, "vapid_private_key", "")
    monkeypatch.setattr(settings, "vapid_public_key", "")
    monkeypatch.setattr(settings, "vapid_keys_path", str(Path(tempfile.mkdtemp()) / "vapid.json"))
    push.reset_keys_cache()
    yield
    push.reset_keys_cache()


@pytest.fixture()
def client():
    tmp_dir = tempfile.mkdtemp()
    engine = create_engine(
        f"sqlite:///{Path(tmp_dir) / 'test.db'}", connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(bind=engine)
    TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        test_client.session_factory = TestingSession
        yield test_client
    app.dependency_overrides.clear()


def _subscribe(client, endpoint, headers):
    return client.post("/api/push/subscribe", json={"endpoint": endpoint, "keys": KEYS}, headers=headers)


def _due_reminder(client, headers, text="remind me in 1 minute to take tablets"):
    client.post("/api/chat", json={"text": text}, headers=headers)
    db = client.session_factory()
    try:
        db.query(models.Reminder).update({models.Reminder.due_at: datetime(2020, 1, 1)})
        db.commit()
    finally:
        db.close()


def _deliver(client):
    db = client.session_factory()
    try:
        return push.deliver_due_reminders(db)
    finally:
        db.close()


# --- Keys ------------------------------------------------------------------

def test_keys_are_generated_once_and_reused():
    first = push.get_keys()
    assert Path(settings.vapid_keys_path).exists()
    push.reset_keys_cache()
    assert push.get_keys() == first  # read back from the file, not regenerated


def test_generated_keys_are_a_valid_p256_pair():
    keys = push.generate_keys()
    import base64

    public = base64.urlsafe_b64decode(keys["public"] + "==")
    private = base64.urlsafe_b64decode(keys["private"] + "==")
    assert len(public) == 65 and public[0] == 4  # uncompressed point
    assert len(private) == 32


def test_keys_from_settings_win_over_the_file(monkeypatch):
    monkeypatch.setattr(settings, "vapid_private_key", "private-from-env")
    monkeypatch.setattr(settings, "vapid_public_key", "public-from-env")
    assert push.public_key() == "public-from-env"
    assert not Path(settings.vapid_keys_path).exists()


def test_an_unwritable_key_path_disables_push_instead_of_crashing(monkeypatch):
    blocker = Path(tempfile.mkdtemp()) / "a-file"
    blocker.write_text("x")
    monkeypatch.setattr(settings, "vapid_keys_path", str(blocker / "vapid.json"))
    assert push.get_keys() is None
    assert push.is_enabled() is False


def test_the_library_accepts_the_generated_private_key(monkeypatch):
    """A real signing pass through pywebpush, with only the network call
    replaced — so a key in the wrong encoding fails here, not in a browser."""
    sent = {}

    class FakeResponse:
        status_code = 201
        text = ""
        headers = {}

    class FakeSession:
        def post(self, url, data=None, headers=None, timeout=None):
            sent["url"], sent["headers"] = url, headers
            return FakeResponse()

    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec

    browser_key = ec.generate_private_key(ec.SECP256R1()).public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint
    )
    real_webpush = push.webpush
    monkeypatch.setattr(
        push, "webpush", lambda **kwargs: real_webpush(requests_session=FakeSession(), **kwargs)
    )
    subscription = models.PushSubscription(
        endpoint=ENDPOINT_A, p256dh=push._b64url(browser_key), auth=push._b64url(b"0123456789abcdef")
    )
    assert push._send(subscription, {"type": "reminder", "text": "மருந்து"}) == "sent"
    assert sent["url"] == ENDPOINT_A
    assert "vapid" in sent["headers"]["authorization"].lower()


# --- Subscribing -----------------------------------------------------------

def test_public_key_endpoint(client):
    body = client.get("/api/push/public-key").json()
    assert body["enabled"] is True and body["key"] == push.public_key()


@pytest.mark.parametrize(
    "endpoint",
    [
        "http://fcm.googleapis.com/fcm/send/x",       # not https
        "https://localhost:8000/internal",            # this server
        "https://169.254.169.254/latest/meta-data",   # cloud metadata
        "https://fcm.googleapis.com.evil.example/x",  # look-alike suffix
        "https://evil.example/push.services.mozilla.com",
        "not a url",
    ],
)
def test_only_real_push_services_are_accepted(client, endpoint):
    """The server later POSTs to this URL, so an arbitrary one is a way to
    make it send requests wherever a caller likes."""
    assert push.is_allowed_endpoint(endpoint) is False
    assert _subscribe(client, endpoint, GUEST_A).status_code == 422


@pytest.mark.parametrize(
    "endpoint",
    [ENDPOINT_A, ENDPOINT_B, "https://wns2-pn1p.notify.windows.com/w/?token=x", "https://web.push.apple.com/abc"],
)
def test_the_real_push_services_are_accepted(endpoint):
    assert push.is_allowed_endpoint(endpoint) is True


def test_subscribing_needs_an_owner(client):
    assert _subscribe(client, ENDPOINT_A, {}).status_code == 400


def test_resubscribing_moves_the_browser_to_the_new_owner(client):
    """Signing out on a shared phone must stop the previous person's
    reminders arriving there."""
    _subscribe(client, ENDPOINT_A, GUEST_A)
    _subscribe(client, ENDPOINT_A, GUEST_B)
    db = client.session_factory()
    try:
        rows = db.query(models.PushSubscription).all()
        assert len(rows) == 1 and rows[0].owner_id == "guest:guest-bbbbbbbbbbbbbbbb"
    finally:
        db.close()


def test_unsubscribe_removes_the_row(client):
    _subscribe(client, ENDPOINT_A, GUEST_A)
    assert client.post("/api/push/unsubscribe", json={"endpoint": ENDPOINT_A}).status_code == 200
    db = client.session_factory()
    try:
        assert db.query(models.PushSubscription).count() == 0
    finally:
        db.close()


def test_registering_carries_the_guests_subscription_to_the_account(client):
    _subscribe(client, ENDPOINT_A, GUEST_A)
    response = client.post(
        "/api/auth/register",
        json={"username": "kavya", "password": "correct horse battery"},
        headers=GUEST_A,
    )
    user_id = response.json()["user"]["id"]
    db = client.session_factory()
    try:
        assert db.query(models.PushSubscription).one().owner_id == f"user:{user_id}"
    finally:
        db.close()


# --- Delivery --------------------------------------------------------------

def test_a_due_reminder_is_pushed_to_its_owner_only(client, monkeypatch):
    sent = []
    monkeypatch.setattr(push, "_send", lambda sub, payload: sent.append((sub.endpoint, payload)) or "sent")
    _subscribe(client, ENDPOINT_A, GUEST_A)
    _subscribe(client, ENDPOINT_B, GUEST_B)
    _due_reminder(client, GUEST_A)

    assert _deliver(client) == 1
    assert [endpoint for endpoint, _ in sent] == [ENDPOINT_A]
    assert "tablets" in sent[0][1]["text"]
    json.dumps(sent[0][1])  # the payload must be serialisable as sent


def test_a_pushed_reminder_fires_once_across_both_paths(client, monkeypatch):
    monkeypatch.setattr(push, "_send", lambda sub, payload: "sent")
    _subscribe(client, ENDPOINT_A, GUEST_A)
    _due_reminder(client, GUEST_A)

    assert _deliver(client) == 1
    assert _deliver(client) == 0
    # And the in-page poll does not show it a second time.
    assert client.get("/api/reminders/due", headers=GUEST_A).json() == []


def test_a_failed_push_leaves_the_reminder_for_the_next_attempt(client, monkeypatch):
    monkeypatch.setattr(push, "_send", lambda sub, payload: "failed")
    _subscribe(client, ENDPOINT_A, GUEST_A)
    _due_reminder(client, GUEST_A)

    assert _deliver(client) == 0
    # Not lost: the open page can still pick it up.
    assert len(client.get("/api/reminders/due", headers=GUEST_A).json()) == 1


def test_a_dead_subscription_is_removed_and_the_reminder_kept(client, monkeypatch):
    monkeypatch.setattr(push, "_send", lambda sub, payload: "gone")
    _subscribe(client, ENDPOINT_A, GUEST_A)
    _due_reminder(client, GUEST_A)

    assert _deliver(client) == 0
    db = client.session_factory()
    try:
        assert db.query(models.PushSubscription).count() == 0
        assert db.query(models.Reminder).one().notified_at is None
    finally:
        db.close()


def test_one_working_device_is_enough(client, monkeypatch):
    monkeypatch.setattr(
        push, "_send", lambda sub, payload: "sent" if sub.endpoint == ENDPOINT_B else "failed"
    )
    _subscribe(client, ENDPOINT_A, GUEST_A)
    _subscribe(client, ENDPOINT_B, GUEST_A)
    _due_reminder(client, GUEST_A)
    assert _deliver(client) == 1


def test_reminders_without_a_subscription_are_left_to_the_poll(client, monkeypatch):
    def explode(sub, payload):
        raise AssertionError("nothing should be sent")

    monkeypatch.setattr(push, "_send", explode)
    _due_reminder(client, GUEST_A)
    assert _deliver(client) == 0
    assert len(client.get("/api/reminders/due", headers=GUEST_A).json()) == 1


def test_a_reminder_not_yet_due_is_not_pushed(client, monkeypatch):
    sent = []
    monkeypatch.setattr(push, "_send", lambda sub, payload: sent.append(1) or "sent")
    _subscribe(client, ENDPOINT_A, GUEST_A)
    client.post("/api/chat", json={"text": "remind me in 5 minutes to take tablets"}, headers=GUEST_A)
    assert _deliver(client) == 0 and sent == []


def test_the_background_loop_starts_and_stops_cleanly():
    pusher = push.ReminderPusher(lambda: None, interval_seconds=60)
    pusher.start()
    assert pusher._thread.is_alive()
    pusher.stop()
    assert pusher._thread is None


def test_a_zero_interval_disables_the_loop():
    pusher = push.ReminderPusher(lambda: None, interval_seconds=0)
    pusher.start()
    assert pusher._thread is None
