"""
Tests for the app's own FAQ (`app.services.about`).

These are mostly *restraint* tests. The risk with a FAQ an assistant reads
out about itself is not that it crashes — it is that it quietly starts
claiming to be more private, more accurate or available offline than it
is. Those claims are cheap to write and expensive to retract, so they are
checked here rather than left to review.

Network-free, like the rest of the suite.
"""
import re

import pytest

from app.services import about
from app.services.intent_detection import INTENTS, detect_intent
from app.services.response_generator import generate_response

LANGUAGES = ("en", "ta", "hi", "te", "kn")

# The ten questions the FAQ was asked to answer. Keeping the list here
# rather than deriving it from the module is the point: if someone deletes
# an entry, this fails.
REQUIRED_KEYS = (
    "what_is",
    "why_not_general",
    "what_can_it_do",
    "languages",
    "language_detection",
    "offline",
    "privacy",
    "data_sources",
    "not_understood",
    "emergency_capability",
)


# ---------------------------------------------------------------------------
# Coverage and translation
# ---------------------------------------------------------------------------


def test_every_required_question_has_an_entry():
    assert set(about.entry_keys()) == set(REQUIRED_KEYS)


@pytest.mark.parametrize("key", REQUIRED_KEYS)
@pytest.mark.parametrize("language", LANGUAGES)
def test_every_entry_is_written_in_every_language(key, language):
    body = about.entries()[key][language]
    assert body.strip(), f"{key}/{language} is empty"


@pytest.mark.parametrize("key", REQUIRED_KEYS)
@pytest.mark.parametrize("language", ("ta", "hi", "te", "kn"))
def test_indic_bodies_are_not_copies_of_the_english_one(key, language):
    entry = about.entries()[key]
    assert entry[language] != entry["en"]


@pytest.mark.parametrize("key", REQUIRED_KEYS)
@pytest.mark.parametrize("language", LANGUAGES)
def test_formatting_leaves_no_unsubstituted_placeholder(key, language):
    match = about.AboutMatch(key=key, text=about.entries()[key])
    reply = about.format_about_reply(match, language)
    assert "{" not in reply and "}" not in reply


# ---------------------------------------------------------------------------
# Honesty
# ---------------------------------------------------------------------------

# Comparative and absolute claims this FAQ is not allowed to make about
# itself. Every one of them would be unverifiable: nobody has benchmarked
# this against another assistant, and the privacy story is a local SQLite
# file with no authentication.
_FORBIDDEN = (
    r"more accurate",
    r"most accurate",
    r"more private",
    r"most private",
    r"more secure",
    r"completely private",
    r"fully private",
    r"100% ?(private|secure|accurate)",
    r"better than",
    r"safer than",
    r"faster than",
    r"smarter than",
    r"best assistant",
    r"fully supported",
    r"always accurate",
    r"never wrong",
)


@pytest.mark.parametrize("pattern", _FORBIDDEN)
def test_no_english_body_claims_superiority(pattern):
    compiled = re.compile(pattern, re.I)
    for key, entry in about.entries().items():
        assert not compiled.search(entry["en"]), f"{key} claims '{pattern}'"


def test_the_comparison_answer_concedes_the_comparison():
    """
    The "why not ChatGPT" answer is the one place a comparison is
    unavoidable. It must concede that the general assistants are more
    capable, not dodge it — otherwise the honest framing collapses into
    marketing.
    """
    body = about.entries()["why_not_general"]["en"].lower()
    assert "not more capable" in body


def test_the_offline_answer_says_no():
    """
    "Works offline" is the single most tempting false claim in a project
    like this, because the *language identification* genuinely runs with no
    downloaded model. That happens on the server, so the app as a whole
    does not work offline, and the answer has to lead with that.
    """
    body = about.entries()["offline"]["en"]
    assert body.lstrip().lower().startswith("no")
    assert "needs an internet connection" in body.lower()


def test_the_privacy_answer_discloses_all_three_ways_data_leaves_the_user():
    """
    Conversations land in an unauthenticated database, spoken audio goes to
    the browser vendor, and place/crop names go to third-party APIs. An
    answer that mentions only one of the three reads as reassurance rather
    than disclosure.
    """
    body = about.entries()["privacy"]["en"].lower()
    assert "no user accounts" in body and "no login" in body
    assert "browser sends the audio" in body
    assert "open-meteo" in body and "data.gov.in" in body


def test_the_privacy_answer_warns_against_typing_secrets():
    body = about.entries()["privacy"]["en"].lower()
    for secret in ("aadhaar", "otp", "password"):
        assert secret in body


def test_the_emergency_answer_does_not_promise_to_summon_help():
    body = about.entries()["emergency_capability"]["en"].lower()
    assert "cannot call anyone for you" in body
    assert "112" in body


# ---------------------------------------------------------------------------
# The language matrix is the single source of truth
# ---------------------------------------------------------------------------


def test_unreviewed_is_derived_from_the_matrix_not_hardcoded():
    expected = tuple(
        code
        for code, row in about.LANGUAGE_SUPPORT.items()
        if row["review"] == "needs-native-review"
    )
    assert about.UNREVIEWED == expected


def test_matrix_covers_exactly_the_five_target_languages():
    assert tuple(about.LANGUAGE_SUPPORT) == about.LANGUAGES == LANGUAGES


@pytest.mark.parametrize("language", LANGUAGES)
def test_the_languages_answer_names_every_language_and_every_caveat(language):
    """
    Generated from `LANGUAGE_SUPPORT`, so it cannot claim a language is in
    better shape than the matrix records. Checked in all five reply
    languages: an untranslated caveat is how an over-claim sneaks back in.
    """
    match = about.match_about("which languages do you support")
    reply = about.format_about_reply(match, language)
    for row in about.LANGUAGE_SUPPORT.values():
        assert row["native"] in reply
    for code in about.UNREVIEWED:
        assert about.LANGUAGE_SUPPORT[code]["name"] in reply


def test_the_languages_answer_states_the_browser_and_voice_limits():
    reply = about.format_about_reply(about.match_about("which languages"), "en")
    lowered = reply.lower()
    assert "chrome or edge" in lowered
    assert "voice installed" in lowered


# ---------------------------------------------------------------------------
# Markup contract
# ---------------------------------------------------------------------------

_HEADING = re.compile(r"^### \S")
_BULLET = re.compile(r"^- \S")
_NUMBERED = re.compile(r"^\d+\. \S")


@pytest.mark.parametrize("key", REQUIRED_KEYS)
@pytest.mark.parametrize("language", LANGUAGES)
def test_bodies_use_only_the_three_documented_markers(key, language):
    """
    `ReplyText` on the frontend renders exactly three markers and strips
    them before text-to-speech. Anything else — bold, tables, links —
    would be read out character by character.
    """
    body = about.entries()[key][language]
    assert "**" not in body
    assert "__" not in body
    assert "|" not in body
    for line in body.split("\n"):
        stripped = line.strip()
        if stripped.startswith("#"):
            assert _HEADING.match(stripped), f"{key}/{language}: bad heading {line!r}"
        if stripped.startswith("-"):
            assert _BULLET.match(stripped), f"{key}/{language}: bad bullet {line!r}"


def test_a_heading_is_never_the_only_thing_in_a_body():
    for key, entry in about.entries().items():
        lines = [line for line in entry["en"].split("\n") if line.strip()]
        assert len(lines) > 1, key


# ---------------------------------------------------------------------------
# Matching and routing
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "question,expected",
    [
        ("what is bharatvoice ai", "what_is"),
        ("who are you", "what_is"),
        ("why not chatgpt", "why_not_general"),
        ("why should i use this instead of gemini", "why_not_general"),
        ("what can you help with", "what_can_it_do"),
        ("which languages do you support", "languages"),
        ("how many languages", "languages"),
        ("how do you identify the language i speak", "language_detection"),
        ("does it work offline", "offline"),
        ("do i need internet", "offline"),
        ("is my data safe", "privacy"),
        ("do you store my conversations", "privacy"),
        ("where do you get scheme information", "data_sources"),
        ("what are your sources", "data_sources"),
        ("what if you don't understand me", "not_understood"),
        ("can you call an ambulance for me", "emergency_capability"),
    ],
)
def test_questions_reach_the_right_entry(question, expected):
    match = about.match_about(question)
    assert match is not None, question
    assert match.key == expected


@pytest.mark.parametrize(
    "question",
    [
        # These are the reason the about-FAQ is probed before the keyword
        # patterns rather than after: each one contains a word the FAQ also
        # talks about, and none of them is a question about the app.
        "what is the weather in Madurai",
        "தக்காளி சந்தை விலை என்ன",
        "remind me at 6pm to take my tablets",
        "how do I apply for a scholarship",
        "someone is asking for my otp",
        "what is 45 plus 67",
        "convert 5 km to miles",
        "how to apply for aadhaar",
        "what time is it",
        "emergency numbers",
        "nearest hospital",
        "vanakkam",
    ],
)
def test_ordinary_questions_are_not_captured_by_the_about_faq(question):
    assert about.match_about(question) is None


def test_about_app_is_a_declared_intent():
    assert "about_app" in INTENTS


@pytest.mark.parametrize(
    "question",
    [
        "what is bharatvoice ai",
        "which languages do you support",
        "does it work offline",
        "where do you get your information",
    ],
)
def test_app_questions_are_classified_as_about_app(question):
    assert detect_intent(question).intent == "about_app"


@pytest.mark.parametrize(
    "question,expected",
    [
        ("what is the weather in Madurai", "get_weather"),
        ("emergency numbers", "emergency_help"),
        ("ambulance number", "emergency_help"),
        ("remind me at 6pm to call amma", "set_reminder"),
    ],
)
def test_the_about_probe_does_not_steal_existing_intents(question, expected):
    assert detect_intent(question).intent == expected


# ---------------------------------------------------------------------------
# End-to-end through the response generator
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("language", LANGUAGES)
def test_an_about_answer_comes_back_in_the_users_language(language):
    answer = generate_response(
        "which languages do you support", language, "about_app", entities=[]
    )
    assert answer.language == language
    assert answer.text == about.format_about_reply(
        about.match_about("which languages do you support"), language
    )


def test_an_about_answer_carries_no_external_source():
    """
    Every other fact-bearing answer cites a portal. These describe this
    program, so there is nothing external to cite — and attaching a
    government portal to a claim about the app would devalue the citation
    everywhere else.
    """
    answer = generate_response("what is bharatvoice ai", "en", "about_app", entities=[])
    assert answer.sources == []
    assert answer.is_refusal is False


def test_an_unmatched_about_label_falls_back_instead_of_inventing():
    """A stale classifier can emit the label for text that matches nothing."""
    answer = generate_response("qwertyuiop", "en", "about_app", entities=[])
    assert answer.text
    assert "qwertyuiop" not in answer.text
