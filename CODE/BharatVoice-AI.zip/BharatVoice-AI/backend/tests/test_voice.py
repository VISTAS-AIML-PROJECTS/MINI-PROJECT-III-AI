"""
Tests for the server-side voice chain.

The subject here is not "does audio come out" — no ULCA credentials existed
when this was written, so nothing in this suite reaches Bhashini. What is
tested is the set of promises the chain makes regardless of which provider
is live:

  1. It never speaks a reply in a language other than the one it was
     written in. A Tamil answer read by a Hindi or English voice is a
     silent wrong answer: the user cannot hear that it happened. An earlier
     version of text_to_speech.py did exactly this on purpose ("synthesize
     the closest supported language"), which is why it is pinned here.
  2. Every failure is a clean "no audio", never an exception reaching the
     caller and never a substituted language.
  3. Credentials never appear in a log record or a response body.
  4. The capability report tells the frontend the truth, including the
     difference between "no credentials" and "credentials but no coverage".

Bhashini's response schema is UNVERIFIED against a live call. The happy-path
test below therefore proves the parser handles the *documented* shape; it is
not evidence that the shape is right. `_extract_audio` is the single place
those field names live, so a correction is one function wide.
"""
import base64
import logging
import urllib.error

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services import text_to_speech, tts_bhashini

client = TestClient(app)

APP_LANGUAGES = ("en", "ta", "hi", "te", "kn")
INDIC_WITHOUT_XTTS = ("ta", "te", "kn")

_FAKE_USER = "ulca-user-id-for-tests"
_FAKE_KEY = "ulca-api-key-for-tests"


@pytest.fixture(autouse=True)
def _clean_voice_state(monkeypatch):
    """Start every test with no credentials and no cached pipeline."""
    tts_bhashini.clear_caches()
    monkeypatch.setattr(tts_bhashini.settings, "bhashini_user_id", "", raising=False)
    monkeypatch.setattr(tts_bhashini.settings, "bhashini_api_key", "", raising=False)
    yield
    tts_bhashini.clear_caches()


def _configure(monkeypatch):
    monkeypatch.setattr(tts_bhashini.settings, "bhashini_user_id", _FAKE_USER,
                        raising=False)
    monkeypatch.setattr(tts_bhashini.settings, "bhashini_api_key", _FAKE_KEY,
                        raising=False)


# A response shaped the way Bhashini's documentation describes. Simulated,
# not observed — see the module docstring.
_PIPELINE_BODY = {
    "pipelineInferenceAPIEndPoint": {
        "callbackUrl": "https://example.invalid/inference/compute",
        "inferenceApiKey": {"name": "Authorization", "value": "inference-token"},
    },
    "pipelineResponseConfig": [{"config": [{"serviceId": "svc/tts/indic"}]}],
}


def _compute_body(audio: bytes = b"RIFF....WAVEfake"):
    return {
        "pipelineResponse": [
            {"audio": [{"audioContent": base64.b64encode(audio).decode("ascii")}]}
        ]
    }


# ---------------------------------------------------------------------------
# The rule that matters most: no language substitution, ever
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("language", INDIC_WITHOUT_XTTS)
def test_coqui_is_never_used_for_a_language_it_cannot_speak(monkeypatch, language):
    """
    XTTS-v2 has no Tamil, Telugu or Kannada. With Coqui "installed" and a
    Tamil reply, the chain must decline rather than speak it in English.

    This is the regression the old docstring promised to *cause*: it said it
    would "synthesize the closest supported language and flag the
    substitution", which in practice read Tamil aloud with English
    phonetics.
    """
    calls = []
    monkeypatch.setattr(text_to_speech, "_HAS_COQUI", True)
    monkeypatch.setattr(text_to_speech.settings, "enable_coqui_tts", True, raising=False)
    monkeypatch.setattr(
        text_to_speech,
        "_coqui_synthesize",
        lambda text, lang: calls.append(lang) or text_to_speech.SynthesisResult("/x.wav", "coqui-tts"),
    )

    result = text_to_speech.synthesize_speech("ஒரு பதில்", language=language)
    assert calls == [], f"Coqui was asked to speak {language}"
    assert result.audio_url is None
    assert result.engine == "browser-fallback"


def test_coqui_is_used_for_a_language_it_can_speak(monkeypatch):
    """The other side of the gate, so it isn't just disabled outright."""
    monkeypatch.setattr(text_to_speech, "_HAS_COQUI", True)
    monkeypatch.setattr(text_to_speech.settings, "enable_coqui_tts", True, raising=False)
    monkeypatch.setattr(
        text_to_speech,
        "_coqui_synthesize",
        lambda text, lang: text_to_speech.SynthesisResult(f"/static/audio/{lang}.wav",
                                                         "coqui-tts"),
    )
    result = text_to_speech.synthesize_speech("an answer", language="en")
    assert result.engine == "coqui-tts"
    assert result.audio_url == "/static/audio/en.wav"


def test_code_mixed_is_spoken_by_the_indic_voice_not_the_english_one(monkeypatch):
    """
    "ta-en" is romanized Tamil. The Tamil voice reads it far better than an
    English voice reads the Tamil words, so it resolves to "ta" — and
    crucially not to "en", which would be a substitution.
    """
    assert text_to_speech._base("ta-en") == "ta"
    assert tts_bhashini._base("ta-en") == "ta"

    seen = []
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "synthesize",
                        lambda text, lang: seen.append(lang) or None)
    text_to_speech.synthesize_speech("vanakkam eppadi irukeenga", language="ta-en")
    assert seen == ["ta"]


# ---------------------------------------------------------------------------
# Failing cleanly
# ---------------------------------------------------------------------------

def test_with_nothing_installed_there_is_no_audio_and_no_error():
    """The default state of this project: browser voices do all the work."""
    result = text_to_speech.synthesize_speech("an answer", language="ta")
    assert result.audio_url is None
    assert result.engine == "browser-fallback"


def test_bhashini_does_nothing_without_credentials():
    assert tts_bhashini.is_configured() is False
    assert tts_bhashini.synthesize("ஒரு பதில்", "ta") is None


@pytest.mark.parametrize("language", ("fr", "bn", "zz"))
def test_bhashini_refuses_an_unsupported_language_rather_than_substituting(
    monkeypatch, language
):
    _configure(monkeypatch)
    called = []
    monkeypatch.setattr(tts_bhashini, "_post_json",
                        lambda *a, **k: called.append(a) or None)
    assert tts_bhashini.synthesize("some text", language) is None
    assert called == [], "an unsupported language must not reach the network"


@pytest.mark.parametrize("body", [
    None,                                              # timeout / HTTP error
    {},                                                # nothing useful
    {"pipelineInferenceAPIEndPoint": {}},              # no callbackUrl
    {"pipelineResponseConfig": []},                    # no service id
    {"pipelineInferenceAPIEndPoint": {"callbackUrl": "u",
                                      "inferenceApiKey": {"name": "a"}}},  # no value
])
def test_a_malformed_pipeline_response_yields_no_audio(monkeypatch, body):
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "_post_json", lambda *a, **k: body)
    assert tts_bhashini.synthesize("ஒரு பதில்", "ta") is None


@pytest.mark.parametrize("compute", [
    None,
    {},
    {"pipelineResponse": []},
    {"pipelineResponse": [{"audio": []}]},
    {"pipelineResponse": [{"audio": [{"audioContent": ""}]}]},
    {"pipelineResponse": [{"audio": [{"audioContent": "not!valid!base64!"}]}]},
])
def test_a_malformed_synthesis_response_yields_no_audio(monkeypatch, compute):
    _configure(monkeypatch)

    def fake_post(url, payload, headers):
        return _PIPELINE_BODY if "getModelsPipeline" in url or "auth" in url else compute

    monkeypatch.setattr(tts_bhashini.settings, "bhashini_auth_url",
                        "https://example.invalid/auth/getModelsPipeline", raising=False)
    monkeypatch.setattr(tts_bhashini, "_post_json", fake_post)
    assert tts_bhashini.synthesize("ஒரு பதில்", "ta") is None


def test_a_provider_that_raises_degrades_to_no_audio(monkeypatch):
    """
    A provider failure must never reach the caller as an exception. The
    reply text was already generated successfully; turning a speech problem
    into a 500 would throw away a perfectly good answer.
    """
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "synthesize",
                        lambda text, lang: (_ for _ in ()).throw(RuntimeError("boom")))
    result = text_to_speech.synthesize_speech("ஒரு பதில்", language="ta")
    assert result.audio_url is None
    assert result.engine == "browser-fallback"


def test_the_synthesize_endpoint_survives_a_provider_that_raises(monkeypatch):
    """The same guarantee through HTTP: 200 with no audio, never a 500."""
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "synthesize",
                        lambda text, lang: (_ for _ in ()).throw(RuntimeError("boom")))
    response = client.post(
        "/api/speech/synthesize", json={"text": "ஒரு பதில்", "language": "ta"}
    )
    assert response.status_code == 200
    assert response.json()["audio_url"] is None


# ---------------------------------------------------------------------------
# Credentials must not leak
# ---------------------------------------------------------------------------

def test_rejected_credentials_are_reported_without_echoing_them(monkeypatch, caplog):
    _configure(monkeypatch)

    def rejecting_urlopen(request, timeout=None):
        raise urllib.error.HTTPError(request.full_url, 403, "Forbidden", {}, None)

    monkeypatch.setattr(tts_bhashini.urllib.request, "urlopen", rejecting_urlopen)

    with caplog.at_level(logging.DEBUG, logger=tts_bhashini.logger.name):
        assert tts_bhashini.synthesize("ஒரு பதில்", "ta") is None

    assert "BHASHINI_USER_ID" in caplog.text, "say which setting to check"
    assert "403" in caplog.text
    assert _FAKE_KEY not in caplog.text, "the API key must never be logged"
    assert _FAKE_USER not in caplog.text, "the user id must never be logged"


def test_a_junk_pipeline_body_is_logged_by_key_not_by_value(monkeypatch, caplog):
    """
    The pipeline response contains a short-lived inference token. Dumping
    the body to diagnose schema drift would write that token to the log, so
    only the key names are logged.
    """
    _configure(monkeypatch)
    monkeypatch.setattr(
        tts_bhashini, "_post_json",
        lambda *a, **k: {"unexpected": "shape", "secretish": "inference-token"},
    )
    with caplog.at_level(logging.DEBUG, logger=tts_bhashini.logger.name):
        assert tts_bhashini.synthesize("ஒரு பதில்", "ta") is None
    assert "unexpected" in caplog.text, "key names are useful for diagnosis"
    assert "inference-token" not in caplog.text, "values must not be logged"


# ---------------------------------------------------------------------------
# The documented happy path (simulated schema — see module docstring)
# ---------------------------------------------------------------------------

def test_the_documented_response_shape_produces_a_playable_url(monkeypatch, tmp_path):
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "AUDIO_OUTPUT_DIR", tmp_path)

    posts = []

    def fake_post(url, payload, headers):
        posts.append((url, payload, headers))
        if "getModelsPipeline" in url:
            return _PIPELINE_BODY
        return _compute_body(b"RIFFfakeWAVE")

    monkeypatch.setattr(tts_bhashini, "_post_json", fake_post)

    url = tts_bhashini.synthesize("ஒரு பதில்", "ta")
    assert url and url.startswith("/static/audio/") and url.endswith(".wav")
    assert (tmp_path / url.rsplit("/", 1)[1]).read_bytes() == b"RIFFfakeWAVE"

    # Step 1 carries the ULCA credentials; step 2 carries the inference key
    # the first call handed back, and the right service id and language.
    auth_url, auth_payload, auth_headers = posts[0]
    assert auth_headers["userID"] == _FAKE_USER
    assert auth_headers["ulcaApiKey"] == _FAKE_KEY
    assert auth_payload["pipelineTasks"][0]["taskType"] == "tts"

    compute_url, compute_payload, compute_headers = posts[1]
    assert compute_url == "https://example.invalid/inference/compute"
    assert compute_headers == {"Authorization": "inference-token"}
    config = compute_payload["pipelineTasks"][0]["config"]
    assert config["serviceId"] == "svc/tts/indic"
    assert config["language"]["sourceLanguage"] == "ta"
    assert compute_payload["inputData"]["input"][0]["source"] == "ஒரு பதில்"


def test_the_pipeline_is_resolved_once_per_language(monkeypatch, tmp_path):
    """Re-authenticating on every reply would double the latency heard."""
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "AUDIO_OUTPUT_DIR", tmp_path)
    auth_calls = []

    def fake_post(url, payload, headers):
        if "getModelsPipeline" in url:
            auth_calls.append(url)
            return _PIPELINE_BODY
        return _compute_body()

    monkeypatch.setattr(tts_bhashini, "_post_json", fake_post)
    tts_bhashini.synthesize("ஒன்று", "ta")
    tts_bhashini.synthesize("இரண்டு", "ta")
    assert len(auth_calls) == 1


def test_a_failed_compute_drops_the_cached_pipeline(monkeypatch, tmp_path):
    """
    The inference key is short-lived. If compute fails, the cached pipeline
    may be the reason, so it must not be reused forever.
    """
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "AUDIO_OUTPUT_DIR", tmp_path)

    def failing_compute(url, payload, headers):
        return _PIPELINE_BODY if "getModelsPipeline" in url else None

    monkeypatch.setattr(tts_bhashini, "_post_json", failing_compute)
    assert tts_bhashini.synthesize("ஒன்று", "ta") is None
    assert "ta" not in tts_bhashini._pipeline_cache


# ---------------------------------------------------------------------------
# The capability report the frontend reasons about
# ---------------------------------------------------------------------------

def test_capabilities_reports_nothing_speakable_by_default():
    report = text_to_speech.capabilities()
    assert report["bhashini_configured"] is False
    assert report["any"] is False
    assert set(report["languages"]) == set(APP_LANGUAGES)
    assert all(value is None for value in report["languages"].values())


def test_capabilities_reports_every_language_once_bhashini_is_configured(monkeypatch):
    _configure(monkeypatch)
    report = text_to_speech.capabilities()
    assert report["bhashini_configured"] is True
    assert report["any"] is True
    assert all(report["languages"][code] == "bhashini" for code in APP_LANGUAGES), (
        "Bhashini covers exactly the five languages this app supports"
    )


def test_capabilities_does_not_claim_indic_coverage_from_coqui_alone(monkeypatch):
    """
    The trap this guards: "a TTS engine is installed" is not "this language
    can be spoken". With only Coqui present, Tamil/Telugu/Kannada must still
    report no provider, or the UI would promise audio it cannot deliver.
    """
    monkeypatch.setattr(text_to_speech, "_HAS_COQUI", True)
    monkeypatch.setattr(text_to_speech.settings, "enable_coqui_tts", True, raising=False)
    report = text_to_speech.capabilities()
    assert report["coqui_installed"] is True
    assert report["languages"]["en"] == "coqui-tts"
    assert report["languages"]["hi"] == "coqui-tts"
    for language in INDIC_WITHOUT_XTTS:
        assert report["languages"][language] is None, language


def test_the_capabilities_endpoint_serves_that_report():
    response = client.get("/api/speech/capabilities")
    assert response.status_code == 200
    body = response.json()
    assert set(body["languages"]) == set(APP_LANGUAGES)
    assert body["any"] is False
    assert "bhashini_configured" in body


def test_synthesize_endpoint_answers_200_with_no_audio_rather_than_failing():
    """
    "No engine for this language" is an expected state the UI explains, not
    an error. A 5xx here would make it look like a crash.
    """
    response = client.post(
        "/api/speech/synthesize", json={"text": "ஒரு பதில்", "language": "ta"}
    )
    assert response.status_code == 200
    assert response.json() == {"audio_url": None, "engine": "browser-fallback"}


# ---------------------------------------------------------------------------
# Chat must not pay for speech it may never play
# ---------------------------------------------------------------------------

def test_chat_does_not_synthesize_inline(monkeypatch):
    """
    Synthesis used to run inside POST /api/chat, which would put a Bhashini
    round trip in front of every typed reply once credentials exist — and
    discard the audio whenever the device had its own voice.
    """
    calls = []
    monkeypatch.setattr(
        text_to_speech, "synthesize_speech",
        lambda text, language="en": calls.append(language) or text_to_speech.SynthesisResult(None, "x"),
    )
    response = client.post("/api/chat", json={"text": "what is the time", "language": "en"})
    assert response.status_code == 200
    assert response.json()["audio_url"] is None
    assert calls == [], "POST /api/chat must not synthesize speech"


def test_the_reply_language_is_what_gets_spoken(monkeypatch):
    """
    End to end for the bug in the brief: a Tamil question must produce a
    Tamil reply, and the synthesis request must carry that same language.
    Nothing may quietly switch it to English between the two.
    """
    response = client.post(
        "/api/chat",
        json={"text": "உதவித்தொகைக்கு எப்படி விண்ணப்பிக்க வேண்டும்", "language": None},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["reply_language"].startswith("ta"), body["reply_language"]

    seen = []
    monkeypatch.setattr(tts_bhashini, "supports", lambda lang: True)
    _configure(monkeypatch)
    monkeypatch.setattr(tts_bhashini, "synthesize",
                        lambda text, lang: seen.append(lang) or None)
    text_to_speech.synthesize_speech(body["reply_text"], language=body["reply_language"])
    assert seen == ["ta"]
