"""
The training and test data for the fine-tuned models.

No model is loaded here. These tests guard the properties that make the
numbers printed by scripts/evaluate_muril.py worth believing: the test
questions are never trained on, every intent the app handles is covered in
every language, and the committed files are exactly what the generator
produces.
"""
import csv
import importlib.util
from collections import Counter, defaultdict
from pathlib import Path

import pytest

from app.services.intent_detection import INTENTS

SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
DATA = SCRIPTS / "data"

LANGUAGES = ("en", "ta", "hi", "te", "kn", "ta-en", "hi-en", "te-en", "kn-en")
TEST_FILES = (
    "intent_test_data.csv",
    "langid_test_data.csv",
    "intent_outofscope_test.csv",
    "intent_outofscope_fresh_test.csv",
)


def _rows(name):
    with (DATA / name).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


@pytest.fixture(scope="module")
def builder():
    spec = importlib.util.spec_from_file_location("build_training_data", SCRIPTS / "build_training_data.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def intent_rows():
    return _rows("intent_training_data.csv")


@pytest.fixture(scope="module")
def langid_rows():
    return _rows("langid_training_data.csv")


# --- The test sets stay separate ------------------------------------------

def test_no_test_question_is_also_a_training_question(builder, intent_rows, langid_rows):
    """The whole value of the test sets. A leaked row inflates every score
    that scripts/evaluate_muril.py prints."""
    held_out = {builder._normalise(row["text"]) for name in TEST_FILES for row in _rows(name)}
    for rows in (intent_rows, langid_rows):
        leaked = [row["text"] for row in rows if builder._normalise(row["text"]) in held_out]
        assert leaked == []


def test_the_generator_finds_every_test_file(builder):
    """A test file the leak guard does not know about is not protected."""
    expected = {builder._normalise(row["text"]) for name in TEST_FILES for row in _rows(name)}
    assert builder._test_rows() == expected


@pytest.mark.parametrize("name", TEST_FILES)
def test_test_files_use_only_real_labels(name):
    valid = set(LANGUAGES) if name.startswith("langid") else set(INTENTS)
    assert {row["label"] for row in _rows(name)} <= valid


def test_the_intent_test_set_covers_every_intent_equally():
    counts = Counter(row["label"] for row in _rows("intent_test_data.csv"))
    assert set(counts) == set(INTENTS)
    assert len(set(counts.values())) == 1


def test_out_of_scope_sets_are_all_general_query():
    for name in ("intent_outofscope_test.csv", "intent_outofscope_fresh_test.csv"):
        assert {row["label"] for row in _rows(name)} == {"general_query"}


# --- Coverage --------------------------------------------------------------

def test_every_intent_has_a_few_hundred_examples(intent_rows):
    counts = Counter(row["label"] for row in intent_rows)
    assert set(counts) == set(INTENTS), "a checkpoint cannot predict an intent it never saw"
    assert min(counts.values()) >= 250


def test_every_intent_is_covered_in_every_language(intent_rows):
    seen = defaultdict(Counter)
    for row in intent_rows:
        seen[row["label"]][row["lang"]] += 1
    for intent in INTENTS:
        thin = [lang for lang in LANGUAGES if seen[intent][lang] < 25]
        assert thin == [], f"{intent} is thin in {thin}"


def test_everything_else_is_the_largest_class(intent_rows):
    """Under-representing it is what makes a model answer every question as
    if it were one of the skills."""
    counts = Counter(row["label"] for row in intent_rows)
    others = max(count for label, count in counts.items() if label != "general_query")
    assert counts["general_query"] >= 2 * others


def test_every_language_has_a_few_hundred_examples(langid_rows):
    counts = Counter(row["label"] for row in langid_rows)
    assert set(counts) == set(LANGUAGES)
    assert min(counts.values()) >= 250


def test_native_script_rows_are_in_their_own_script(langid_rows):
    """A Telugu row filed under Kannada would teach exactly the wrong thing."""
    blocks = {"ta": (0x0B80, 0x0BFF), "hi": (0x0900, 0x097F), "te": (0x0C00, 0x0C7F), "kn": (0x0C80, 0x0CFF)}
    for row in langid_rows:
        if row["label"] not in blocks:
            continue
        low, high = blocks[row["label"]]
        other = [
            ch for ch in row["text"]
            if any(lo <= ord(ch) <= hi for lang, (lo, hi) in blocks.items() if lang != row["label"])
        ]
        assert not other, row["text"]
        assert any(low <= ord(ch) <= high for ch in row["text"]), row["text"]


def test_romanized_rows_are_latin_script(langid_rows):
    for row in langid_rows:
        if row["label"].endswith("-en") or row["label"] == "en":
            # One legacy seed row is deliberately mixed-script.
            indic = [ch for ch in row["text"] if 0x0900 <= ord(ch) <= 0x0CFF]
            assert len(indic) <= 4, row["text"]


# --- Review status ---------------------------------------------------------

def test_unreviewed_languages_are_marked(intent_rows, langid_rows):
    """Hindi, Telugu and Kannada were written without a native speaker."""
    needs_review = {"hi", "te", "kn", "hi-en", "te-en", "kn-en"}
    for row in intent_rows:
        if row["lang"] in needs_review:
            assert row["review"] == "needs-review"
    for row in langid_rows:
        if row["label"] in needs_review:
            assert row["review"] == "needs-review"


# --- Reproducibility -------------------------------------------------------

def test_the_committed_files_are_what_the_generator_produces(builder, intent_rows, langid_rows, tmp_path, monkeypatch):
    """If this fails, someone edited a CSV by hand or changed the template
    bank without rebuilding: run `python scripts/build_training_data.py`."""
    for name in ("intent_seed.csv", "langid_seed.csv", *TEST_FILES):
        (tmp_path / name).write_bytes((DATA / name).read_bytes())
    monkeypatch.setattr(builder, "DATA", tmp_path)
    builder.build()

    for name, committed in (("intent_training_data.csv", intent_rows), ("langid_training_data.csv", langid_rows)):
        with (tmp_path / name).open(encoding="utf-8", newline="") as handle:
            assert list(csv.DictReader(handle)) == committed
