"""
Tappable helpline numbers, and IMD district warnings.

Both features have one way to go badly wrong, and most of this file is
about that way: a number that is not a phone number becoming a dial link,
and a failed warning lookup being reported as "no warnings".
"""
from datetime import datetime, timezone

import pytest

from app.config import settings
from app.services import imd, skills, weather
from app.services.intent_detection import detect_intent
from app.services.response_generator import generate_response

SUPPORTED = ("en", "ta", "hi", "te", "kn")


def _answer(text, language="en"):
    return generate_response(
        text=text, language=language, intent=detect_intent(text).intent, entities=[]
    )


# --- Dialable numbers ------------------------------------------------------

def test_dialable_numbers_finds_only_verified_helplines():
    assert skills.dialable_numbers("Report it by calling 1930 right away.") == ["1930"]
    assert skills.dialable_numbers("Call 999 or 12345") == []


@pytest.mark.parametrize("text", ["11234", "19301", "21120", "₹11930"])
def test_a_helpline_inside_a_longer_number_is_not_matched(text):
    assert skills.dialable_numbers(text) == []


def test_indic_digits_count_as_digit_boundaries():
    # A Devanagari digit beside "112" makes it part of a longer number.
    assert skills.dialable_numbers("११२112") == []


@pytest.mark.parametrize("language", SUPPORTED)
def test_the_fraud_faq_marks_1930_as_dialable(language):
    answer = _answer("how to report cyber crime", language)
    assert "1930" in answer.text
    assert "1930" in answer.dialable


def test_the_emergency_list_marks_every_number():
    answer = generate_response(text="emergency", language="en", intent="emergency_help", entities=[])
    assert answer.dialable == [number for number, _ in skills.EMERGENCY_NUMBERS]


@pytest.mark.parametrize(
    "text",
    ["what is 50 plus 50", "what is 1900 plus 30", "what is 56 times 2"],
)
def test_a_calculator_result_is_never_dialable(text):
    """The regression this design exists for: "That's 100." became a link
    to the police, and 1930 a link to the fraud helpline."""
    answer = _answer(text)
    assert any(number in answer.text for number in ("100", "1930", "112"))
    assert answer.dialable == []


def test_a_weather_answer_is_never_dialable(monkeypatch):
    fake = weather.WeatherResult(
        place="Chennai", temperature_c=108.0, feels_like_c=112.0, condition="clear",
        observed_at=datetime(2026, 9, 26, 10, 0, tzinfo=timezone.utc),
    )
    monkeypatch.setattr(weather, "get_weather", lambda place: fake)
    answer = generate_response(
        text="weather in Chennai", language="en", intent="get_weather", entities=[]
    )
    assert "108" in answer.text and answer.dialable == []


# --- IMD warnings ----------------------------------------------------------

FEED = [
    {"Date": "2026-10-06", "District": "CHENNAI", "Day_1": "2,4", "Day1_Color": "3"},
    {"Date": "2026-10-06", "District": "MADURAI", "Day_1": "1", "Day1_Color": "1"},
    {"Date": "2026-10-06", "District": "SALEM", "Day_1": "99", "Day1_Color": "2"},
]


@pytest.fixture()
def imd_on(monkeypatch):
    imd.clear_caches()
    monkeypatch.setattr(settings, "imd_warnings_url", "https://imd.invalid/warnings")
    monkeypatch.setattr(imd, "_fetch_rows", lambda: FEED)
    yield
    imd.clear_caches()


def test_imd_is_dormant_without_a_url(monkeypatch):
    monkeypatch.setattr(settings, "imd_warnings_url", "")

    def explode():
        raise AssertionError("no request may be made when IMD is not configured")

    monkeypatch.setattr(imd, "_fetch_rows", explode)
    assert imd.get_warning("Chennai") is None


def test_a_warning_is_parsed(imd_on):
    warning = imd.get_warning("Chennai")
    assert warning.colour == "orange"
    assert warning.hazards == ("heavy_rain", "thunderstorm")
    assert warning.district == "Chennai"


def test_the_district_is_tried_when_the_town_does_not_match(imd_on):
    assert imd.get_warning(None, "Tambaram", "chennai").colour == "orange"


def test_green_is_not_reported(imd_on):
    assert imd.get_warning("Madurai") is None


def test_an_unknown_warning_code_is_dropped_not_described(imd_on):
    assert imd.get_warning("Salem") is None


def test_an_unknown_district_is_none(imd_on):
    assert imd.get_warning("Atlantis") is None


@pytest.mark.parametrize("rows", [None, [], [{"unexpected": True}], ["not a dict"]])
def test_a_failed_or_malformed_feed_is_none(monkeypatch, rows):
    monkeypatch.setattr(settings, "imd_warnings_url", "https://imd.invalid/warnings")
    monkeypatch.setattr(imd, "_fetch_rows", lambda: rows)
    assert imd.get_warning("Chennai") is None


def _weather(monkeypatch):
    fake = weather.WeatherResult(
        place="Chennai", temperature_c=31.0, feels_like_c=None, condition="rain",
        observed_at=datetime(2026, 10, 6, 10, 0, tzinfo=timezone.utc), district="Chennai",
    )
    monkeypatch.setattr(weather, "get_weather", lambda place: fake)


@pytest.mark.parametrize("language", SUPPORTED)
def test_a_weather_answer_carries_the_warning_and_cites_imd(imd_on, monkeypatch, language):
    _weather(monkeypatch)
    answer = generate_response(
        text="weather in Chennai", language=language, intent="get_weather", entities=[]
    )
    assert "IMD" in answer.text
    assert any(source.title == imd.SOURCE_TITLE for source in answer.sources)


def test_a_failed_lookup_adds_nothing_and_claims_no_all_clear(monkeypatch):
    """A timeout must not be reported as "no warnings"."""
    monkeypatch.setattr(settings, "imd_warnings_url", "https://imd.invalid/warnings")
    monkeypatch.setattr(imd, "_fetch_rows", lambda: None)
    _weather(monkeypatch)
    answer = generate_response(
        text="weather in Chennai", language="en", intent="get_weather", entities=[]
    )
    assert "IMD" not in answer.text
    assert "warning" not in answer.text.lower()
    assert len(answer.sources) == 1


def test_every_hazard_and_colour_is_translated():
    from app.services import response_generator as rg

    assert set(rg._IMD_HAZARDS) == set(imd.WARNING_CODES.values())
    assert set(rg._IMD_COLOURS) == set(imd.COLOURS.values())
    for table in list(rg._IMD_HAZARDS.values()) + list(rg._IMD_COLOURS.values()):
        assert set(SUPPORTED) <= set(table)
