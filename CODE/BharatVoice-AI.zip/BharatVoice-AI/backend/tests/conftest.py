"""
Suite-wide test setup.

The fine-tuned MuRIL checkpoints are optional, large, git-ignored files
that exist on some machines and not others. Without this fixture the same
test could pass on a laptop that has trained models and fail in CI, or the
reverse, because `detect_intent` and `detect_language` quietly consult a
checkpoint whenever one is on disk.

So the suite runs with the models switched off: every test exercises the
rule-based path, on every machine, and in a fraction of the time (loading
two 900 MB checkpoints took the suite from 20 seconds to 3 minutes).

Tests about how a model is *allowed* to affect the app live in
test_model_floor.py and stand in for the checkpoint with a stub. How good
a real checkpoint is gets measured by scripts/evaluate_muril.py, which is
not part of this suite — that is a measurement, not a pass/fail check.

Set BHARATVOICE_TEST_WITH_MODELS=1 to run the suite against the real
checkpoints on this machine, as a one-off regression probe.
"""
import os

import pytest

from app.config import settings


@pytest.fixture(autouse=True, scope="session")
def _rules_only():
    if os.environ.get("BHARATVOICE_TEST_WITH_MODELS") == "1":
        yield
        return
    original = settings.enable_muril
    settings.enable_muril = False
    yield
    settings.enable_muril = original


@pytest.fixture(autouse=True)
def _no_gemini():
    """A Gemini key in someone's backend/.env must not send test traffic to Google."""
    original = settings.gemini_api_key
    settings.gemini_api_key = ""
    yield
    settings.gemini_api_key = original
