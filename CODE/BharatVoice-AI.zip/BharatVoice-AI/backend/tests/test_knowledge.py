"""
Tests for the curated knowledge base and the mandi price adapter.

Two different jobs here:

  - `knowledge.py` holds static text, so the tests are about *coverage and
    restraint*: every entry translated into every language, every entry
    cited, and no entry containing the kinds of claim that go stale or that
    the assistant has no business making (rupee amounts, percentages,
    eligibility verdicts).

  - `mandi.py` talks to a network service that was measured returning 504,
    502 and 429, so the tests are about *failing honestly*: no key, error
    body, empty payload and junk records must all produce a refusal, never
    a number.

Nothing here touches the network. `mandi._fetch_json` is stubbed in every
test that exercises the live path.
"""
import json
import logging
import pathlib
import re
import urllib.error

import pytest

from app.services import knowledge, mandi
from app.services.intent_detection import detect_intent
from app.services.response_generator import generate_response

SUPPORTED = ("en", "ta", "hi", "te", "kn")

ALL_KEYS = knowledge.entry_keys()


# ---------------------------------------------------------------------------
# Coverage: an entry that exists in English only is a silently English reply
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("key", ALL_KEYS)
def test_every_entry_is_translated_into_every_language(key):
    entry = knowledge.entries()[key]
    for language in SUPPORTED:
        assert entry.get(language), f"{key} has no {language} body"
        assert len(entry[language]) > 40, f"{key}/{language} looks like a stub"


@pytest.mark.parametrize("key", ALL_KEYS)
def test_every_entry_is_cited(key):
    """
    The whole point of the answer contract. An uncited curated claim about a
    government scheme is exactly what this module exists to prevent.
    """
    entry = knowledge.entries()[key]
    assert entry["source"].title, f"{key} has no source title"
    assert entry["portal"], f"{key} has no portal to point at"


@pytest.mark.parametrize("key", ALL_KEYS)
def test_bodies_differ_by_language(key):
    """
    Guards against a copy-paste that leaves English text under a `ta`/`hi`
    key — which would pass the coverage test above and still be wrong.
    """
    entry = knowledge.entries()[key]
    bodies = {entry[language] for language in SUPPORTED}
    assert len(bodies) == len(SUPPORTED), f"{key} has duplicate bodies across languages"


# ---------------------------------------------------------------------------
# Restraint: what curated text is NOT allowed to say
# ---------------------------------------------------------------------------

_MONEY = re.compile(r"[₹]|\bRs\.?\s*\d|\brupees\b", re.IGNORECASE)
_PERCENT = re.compile(r"\d\s*(%|percent)", re.IGNORECASE)


@pytest.mark.parametrize("key", ALL_KEYS)
def test_no_entry_quotes_an_amount_or_a_percentage(key):
    """
    Amounts and percentages are the figures that drift — scheme benefits,
    income ceilings, subsidy rates. A stale one is worse than none, and the
    portal each entry links to always has the current value.
    """
    entry = knowledge.entries()[key]
    for language in SUPPORTED:
        body = entry[language]
        assert not _MONEY.search(body), f"{key}/{language} quotes a money amount"
        assert not _PERCENT.search(body), f"{key}/{language} quotes a percentage"


@pytest.mark.parametrize("key", ALL_KEYS)
def test_no_entry_delivers_an_eligibility_verdict(key):
    """
    The assistant may say where eligibility is decided; it may never say
    whether *this user* qualifies. Phrases that would do that are banned
    outright rather than reviewed case by case.
    """
    forbidden = ("you are eligible", "you qualify", "you will get",
                 "you are entitled", "you will receive")
    body = knowledge.entries()[key]["en"].lower()
    for phrase in forbidden:
        assert phrase not in body, f"{key} states an eligibility verdict: {phrase!r}"


def test_every_domain_has_at_least_one_entry():
    counts = knowledge.coverage()
    missing = [domain for domain, count in counts.items() if count == 0]
    assert not missing, f"domains declared but not covered: {missing}"


# ---------------------------------------------------------------------------
# Matching and routing
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "text,expected_key",
    [
        ("how do I apply for a scholarship", "scholarship"),
        ("உதவித்தொகை எப்படி விண்ணப்பிக்க வேண்டும்", "scholarship"),
        ("मुझे छात्रवृत्ति चाहिए", "scholarship"),
        ("ವಿದ್ಯಾರ್ಥಿವೇತನ ಹೇಗೆ ಪಡೆಯುವುದು", "scholarship"),
        ("I want to open a bank account", "bank_account"),
        ("someone is asking for my otp", "otp_scam"),
        ("ఓటీపీ అడుగుతున్నారు", "otp_scam"),
        ("I lost money in an online fraud", "report_cyber_fraud"),
        ("this is a digital arrest call", "digital_arrest_scam"),
        ("how to book a train ticket", "train_booking"),
        ("check my pnr", "train_status"),
        ("which government scheme can I get", "find_scheme"),
        ("pm kisan status", "pm_kisan"),
        ("ayushman card", "ayushman_bharat"),
        ("nearest hospital", "find_hospital"),
        ("looking for a government job", "find_job"),
    ],
)
def test_questions_reach_the_right_entry(text, expected_key):
    match = knowledge.match_faq(text)
    assert match is not None, f"no match for {text!r}"
    assert match.key == expected_key


def test_scam_warning_beats_the_careers_portal():
    """
    Someone typing "job scam" must get the warning, not a link to a jobs
    site. This is the case the length-ordered keyword scan exists for.
    """
    assert knowledge.match_faq("is this a job scam").key == "fake_job_scam"
    assert knowledge.match_faq("फर्जी नौकरी का मेसेज आया").key == "fake_job_scam"


def test_unrelated_text_matches_nothing():
    for text in ("what is the time", "vanakkam", "12 * 8", "convert 5 km to miles"):
        assert knowledge.match_faq(text) is None, text


def test_government_documents_still_win_over_the_faq():
    """
    `gov_document_help` has its own curated text for Aadhaar/PAN/etc. The
    FAQ probe runs after the keyword patterns precisely so it cannot steal
    those questions.
    """
    for text in ("how to apply for aadhaar", "pan card details", "ration card"):
        assert detect_intent(text).intent == "gov_document_help", text


@pytest.mark.parametrize(
    "text",
    [
        "how do I apply for a scholarship",
        "I want to open a bank account",
        "someone is asking for my otp",
        "how to book a train ticket",
        "which government scheme can I get",
        "looking for a government job",
        "nearest hospital",
    ],
)
def test_faq_questions_route_to_knowledge_help(text):
    assert detect_intent(text).intent == "knowledge_help"


@pytest.mark.parametrize("language", SUPPORTED)
def test_knowledge_answers_are_cited_in_every_language(language):
    answer = generate_response(
        "how do I apply for a scholarship", language, "knowledge_help", [], {}
    )
    assert answer.is_cited
    assert answer.sources[0].url
    # The "confirm on the portal" note is attached in the user's language.
    assert "scholarships.gov.in" in answer.text


def test_knowledge_help_without_a_match_does_not_invent_content():
    """
    The label can only come from a match today, but a retrained classifier
    could produce it for anything. That must degrade to the general
    fallback, not to made-up guidance.
    """
    answer = generate_response("qwertyuiop", "en", "knowledge_help", [], {})
    assert not answer.is_cited
    assert answer.confidence < 0.5


# ---------------------------------------------------------------------------
# Mandi prices: honest failure is the main feature
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _clean_mandi_state(monkeypatch):
    mandi.clear_caches()
    monkeypatch.setattr(mandi.settings, "data_gov_api_key", "", raising=False)
    yield
    mandi.clear_caches()


def _stub(monkeypatch, payload):
    monkeypatch.setattr(mandi.settings, "data_gov_api_key", "test-key", raising=False)
    monkeypatch.setattr(mandi, "_fetch_json", lambda params: payload)


_RECORDS = [
    {"state": "Tamil Nadu", "district": "Coimbatore", "market": "Mettupalayam",
     "commodity": "Tomato", "arrival_date": "27/09/2026",
     "min_price": "1800", "max_price": "2400", "modal_price": "2100"},
    {"state": "Tamil Nadu", "district": "Salem", "market": "Salem",
     "commodity": "Tomato", "arrival_date": "27/09/2026",
     "min_price": "1500", "max_price": "2000", "modal_price": "1700"},
]


@pytest.mark.parametrize(
    "text,expected",
    [
        ("tomato mandi price", "tomato"),
        ("தக்காளி சந்தை விலை என்ன", "tomato"),
        ("प्याज मंडी भाव", "onion"),
        ("ಈರುಳ್ಳಿ ಮಾರುಕಟ್ಟೆ ದರ", "onion"),
        ("paddy market rate", "paddy(dhan)(common)"),
        ("green chilli market price", "green chilli"),
    ],
)
def test_commodity_is_recognised(text, expected):
    assert mandi.commodity_in_text(text) == expected


def test_price_in_the_question_is_not_read_as_rice():
    """
    Regression: "rice" is a substring of "price", so a containment check
    answered "what is the mandi price" with rice prices — a crop the user
    never mentioned. ASCII surfaces are matched on word boundaries.
    """
    assert mandi.commodity_in_text("what is the mandi price today") is None
    assert mandi.commodity_in_text("mandi price") is None
    assert mandi.commodity_in_text("rice market rate") == "rice"


def test_crop_name_is_shown_in_the_users_language():
    """AGMARKNET's key is "Paddy(Dhan)(Common)"; nobody should have to read that."""
    assert mandi.localized_name("paddy(dhan)(common)", "en") == "paddy"
    assert mandi.localized_name("paddy(dhan)(common)", "ta") == "நெல்"
    assert mandi.localized_name("paddy(dhan)(common)", "ta-en") == "நெல்"
    assert mandi.localized_name("unlisted-crop", "en") == "unlisted-crop"


def test_no_api_key_means_no_lookup_and_no_guess():
    assert mandi.get_prices("tomato") is None
    answer = generate_response("tomato mandi price", "en", "mandi_price", [], {})
    assert answer.is_refusal
    assert mandi.PORTAL in answer.text
    assert not re.search(r"\d", answer.text.replace("data.gov.in", "")), (
        "an unavailable lookup must not contain anything that reads as a price"
    )


def test_rate_limit_body_is_treated_as_a_failure(monkeypatch):
    """
    data.gov.in answers rate limiting with HTTP 200 and {"error": ...}.
    Measured on 2026-09-27 with the shared demo key. Surfacing that body as
    data would show "Rate limit exceeded" where a price belongs.
    """
    _stub(monkeypatch, {"error": "Rate limit exceeded"})
    assert mandi.get_prices("tomato") is None
    assert generate_response("tomato mandi price", "en", "mandi_price", [], {}).is_refusal


@pytest.mark.parametrize(
    "payload",
    [
        None,                                   # timeout / 5xx / bad JSON
        {},                                     # no records key
        {"records": []},                        # commodity not traded today
        {"records": [{"market": "Salem"}]},     # no prices in the row
        {"records": [{"market": "", "modal_price": "1700"}]},  # no market name
        {"records": [{"market": "Salem", "modal_price": "0"}]},  # 0 means "not reported"
        {"records": "nonsense"},                # schema drift
    ],
)
def test_every_broken_payload_becomes_a_refusal(monkeypatch, payload):
    _stub(monkeypatch, payload)
    assert mandi.get_prices("tomato") is None
    assert generate_response("tomato mandi price", "en", "mandi_price", [], {}).is_refusal


def test_successful_lookup_is_sorted_cited_and_timestamped(monkeypatch):
    _stub(monkeypatch, {"records": _RECORDS})
    prices = mandi.get_prices("tomato")
    assert [price.market for price in prices] == ["Salem", "Mettupalayam"]

    answer = generate_response("tomato mandi price", "en", "mandi_price", [], {})
    assert not answer.is_refusal
    assert answer.is_cited
    assert answer.sources[0].checked_on is not None, "a live call must stamp its date"
    assert answer.staleness and "27/09/2026" in answer.staleness
    assert "Salem" in answer.text and "1700" in answer.text


@pytest.mark.parametrize("language", SUPPORTED)
def test_live_prices_are_answered_in_every_language(monkeypatch, language):
    _stub(monkeypatch, {"records": _RECORDS})
    mandi.clear_caches()
    answer = generate_response("tomato mandi price", language, "mandi_price", [], {})
    assert not answer.is_refusal
    assert mandi.localized_name("tomato", language) in answer.text


def test_asking_without_naming_a_crop_asks_which_crop():
    answer = generate_response("what is the mandi price", "en", "mandi_price", [], {})
    assert not answer.is_refusal  # it's a clarifying question, not a failure
    assert "?" in answer.text


def test_mandi_intent_is_detected_in_every_language():
    for text in ("tomato mandi price", "onion market rate", "தக்காளி சந்தை விலை",
                 "प्याज मंडी भाव", "టమాటా మార్కెట్ ధర", "ಈರುಳ್ಳಿ ಮಾರುಕಟ್ಟೆ ದರ"):
        assert detect_intent(text).intent == "mandi_price", text


def test_results_are_cached(monkeypatch):
    """One question asked twice must not cost two upstream calls."""
    calls = []
    monkeypatch.setattr(mandi.settings, "data_gov_api_key", "test-key", raising=False)

    def counting_fetch(params):
        calls.append(params)
        return {"records": _RECORDS}

    monkeypatch.setattr(mandi, "_fetch_json", counting_fetch)
    mandi.get_prices("tomato")
    mandi.get_prices("tomato")
    assert len(calls) == 1


# ---------------------------------------------------------------------------
# Configuration wiring: the key has to actually reach the service
# ---------------------------------------------------------------------------
# The bug these exist to close: mandi.py read `DATA_GOV_API_KEY` and the
# backend settings declared it, but docker-compose.yml never passed it into
# the container. Every layer looked correct in isolation and the assistant
# still reported that live prices were unavailable. Nothing in the old suite
# could catch that, because no test looked at the boundary between them.

_ENV_VAR = "DATA_GOV_API_KEY"


def _repo_root() -> pathlib.Path:
    return pathlib.Path(__file__).resolve().parents[2]


def test_the_env_var_name_is_the_one_the_settings_object_reads(monkeypatch):
    """
    Renaming the setting without renaming the environment variable silently
    switches mandi prices off everywhere, with no error anywhere.
    """
    from app.config import Settings

    monkeypatch.setenv(_ENV_VAR, "wiring-test-key")
    assert Settings(_env_file=None).data_gov_api_key == "wiring-test-key"

    monkeypatch.setenv(_ENV_VAR, "")
    assert Settings(_env_file=None).data_gov_api_key == ""


def test_docker_compose_passes_the_key_through_without_containing_one():
    """
    Compose must forward the variable, and must not hold a real key.

    Read as text rather than parsed as YAML so this test needs no PyYAML and
    so the `${...}` interpolation is checked literally — a parsed value would
    hide the difference between a passthrough and a hardcoded string.
    """
    compose = (_repo_root() / "docker-compose.yml").read_text(encoding="utf-8")
    expected = _ENV_VAR + ': "${' + _ENV_VAR + ':-}"'

    assert expected in compose, (
        "docker-compose.yml must forward DATA_GOV_API_KEY from the "
        "environment, with an empty default so an unset key is not an error"
    )
    # A committed key is a leaked key. Anything on that line other than the
    # interpolation is one.
    for line in compose.splitlines():
        stripped = line.strip()
        if stripped.startswith(_ENV_VAR + ":"):
            assert stripped == expected, stripped


def test_the_example_env_files_are_placeholders_only():
    """
    Both example files must name the variable and leave it empty. A real key
    in a committed example is the most common way this kind of secret leaks.
    """
    root = _repo_root()
    for relative in (".env.example", "backend/.env.example"):
        text = (root / relative).read_text(encoding="utf-8")
        assert _ENV_VAR in text, relative + " should document " + _ENV_VAR
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith(_ENV_VAR + "="):
                value = stripped.split("=", 1)[1].strip()
                assert value in ("", "your-key-here"), (
                    relative + " looks like it contains a real key: " + stripped
                )


def test_gitignore_excludes_real_env_files_but_not_the_examples():
    rules = [
        line.strip()
        for line in (_repo_root() / ".gitignore").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    assert ".env" in rules
    assert ".env.*" in rules, "variants like .env.local must be ignored too"
    assert "!.env.example" in rules, "the committed placeholders must stay visible"
    # Order matters in .gitignore: a negation before its pattern does nothing.
    assert rules.index("!.env.example") > rules.index(".env.*")


# ---------------------------------------------------------------------------
# The request itself: the right dataset, the key attached
# ---------------------------------------------------------------------------

def test_the_lookup_calls_the_agmarknet_daily_price_resource(monkeypatch):
    """
    Pins the resource actually queried: "Current Daily Price of Various
    Commodities from Various Markets (Mandi)" — AGMARKNET's daily feed,
    published through data.gov.in. A different resource id would return a
    different schema and every row would be silently dropped by the parser.
    """
    seen = {}

    class _Response:
        def read(self):
            return json.dumps({"records": _RECORDS}).encode("utf-8")

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            return False

    def fake_urlopen(request, timeout=None):
        seen["url"] = request.full_url
        seen["timeout"] = timeout
        return _Response()

    monkeypatch.setattr(mandi.settings, "data_gov_api_key", "wiring-test-key",
                        raising=False)
    monkeypatch.setattr(mandi.urllib.request, "urlopen", fake_urlopen)

    prices = mandi.get_prices("tomato")
    assert prices, "a well-formed 200 must produce rows"

    url = seen["url"]
    assert url.startswith("https://api.data.gov.in/resource/")
    assert mandi._RESOURCE_ID in url
    assert "9ef84268-d588-465a-a308-a864a43d0070" in url  # AGMARKNET daily prices
    assert "api-key=wiring-test-key" in url
    assert "format=json" in url
    assert "filters%5Bcommodity%5D=Tomato" in url
    # The short ceiling is deliberate: this upstream has been measured taking
    # 45s before returning 504.
    assert seen["timeout"] == mandi.settings.http_timeout_seconds


def test_a_live_answer_reports_crop_market_price_and_date(monkeypatch):
    """
    The four things a farmer asked for. The date lives in `staleness` rather
    than the body because it is the dataset's own arrival date, not the time
    of our call — the UI renders it as a freshness chip beside the source.
    """
    _stub(monkeypatch, {"records": _RECORDS})
    answer = generate_response("tomato mandi price", "en", "mandi_price", [], {})

    assert "tomato" in answer.text.lower()                           # crop
    assert "Salem" in answer.text and "Mettupalayam" in answer.text  # markets
    assert "1700" in answer.text and "2100" in answer.text           # modal prices
    assert "quintal" in answer.text                                  # the quoted unit
    assert "27/09/2026" in (answer.staleness or "")                  # dataset's date
    assert answer.sources[0].url == mandi.SOURCE_URL                 # AGMARKNET, linked


def test_price_rows_are_bulleted_so_the_ui_lists_them(monkeypatch):
    """
    The frontend's shared markup contract (frontend/src/utils/replyFormat.js)
    turns "- " lines into a real list and strips the marker before speaking.
    Without the marker a four-market comparison renders as one run-on
    paragraph — the readability problem the reply formatter exists to fix.
    """
    _stub(monkeypatch, {"records": _RECORDS})
    answer = generate_response("tomato mandi price", "en", "mandi_price", [], {})
    rows = [line for line in answer.text.splitlines() if "₹" in line]
    assert rows, "expected at least one price row"
    for row in rows:
        assert row.startswith("- "), row
    # The header is not a bullet — it introduces the list.
    assert not answer.text.splitlines()[0].startswith("- ")


def test_an_unavailable_lookup_still_points_at_agmarknet(monkeypatch):
    """The honest fallback, kept explicit: no number, but somewhere to go."""
    for payload in (None, {"error": "Rate limit exceeded"}, {"records": []}):
        mandi.clear_caches()
        _stub(monkeypatch, payload)
        answer = generate_response("onion mandi price", "en", "mandi_price", [], {})
        assert answer.is_refusal
        assert mandi.PORTAL in answer.text
        assert answer.staleness is None, "nothing stale to date-stamp"


def test_a_rejected_key_refuses_and_says_so_in_the_log(monkeypatch, caplog):
    """
    Measured 2026-09-27: data.gov.in answers a key it doesn't recognise with
    HTTP 403 — not the 200-plus-error-body that an exhausted key returns.

    The user still gets the honest "couldn't fetch it" refusal with no
    number in it. The operator gets a log line naming the setting and the
    two places it can live, because a mistyped key is the most likely reason
    live prices don't appear and the generic "lookup failed" sends people
    hunting for an outage instead.
    """
    def rejecting_urlopen(request, timeout=None):
        raise urllib.error.HTTPError(request.full_url, 403, "Forbidden", {}, None)

    monkeypatch.setattr(mandi.settings, "data_gov_api_key", "wrong-key",
                        raising=False)
    monkeypatch.setattr(mandi.urllib.request, "urlopen", rejecting_urlopen)

    with caplog.at_level(logging.ERROR, logger=mandi.logger.name):
        assert mandi.get_prices("tomato") is None
    assert "DATA_GOV_API_KEY" in caplog.text
    assert "403" in caplog.text

    mandi.clear_caches()
    monkeypatch.setattr(mandi.settings, "data_gov_api_key", "wrong-key",
                        raising=False)
    answer = generate_response("tomato mandi price", "en", "mandi_price", [], {})
    assert answer.is_refusal
    assert mandi.PORTAL in answer.text
    # A rejected key must not leak an HTTP code, the setting name or the key
    # itself into a farmer's reply.
    assert "403" not in answer.text
    assert "DATA_GOV_API_KEY" not in answer.text
    assert "wrong-key" not in answer.text


def test_an_upstream_5xx_is_logged_without_blaming_the_key(monkeypatch, caplog):
    """The other half of the distinction: 502 is the portal, not the key."""
    def failing_urlopen(request, timeout=None):
        raise urllib.error.HTTPError(request.full_url, 502, "Bad Gateway", {}, None)

    monkeypatch.setattr(mandi.settings, "data_gov_api_key", "good-key",
                        raising=False)
    monkeypatch.setattr(mandi.urllib.request, "urlopen", failing_urlopen)

    with caplog.at_level(logging.WARNING, logger=mandi.logger.name):
        assert mandi.get_prices("tomato") is None
    assert "502" in caplog.text
    assert "DATA_GOV_API_KEY" not in caplog.text
