"""
Database migrations.

The one guarantee that matters: whatever state a database is in — new,
created before migrations existed, or already current — `run_migrations`
leaves it with exactly the schema the models describe, and loses nothing.
"""
import tempfile
from pathlib import Path

import pytest
import sqlalchemy as sa
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from alembic.script import ScriptDirectory

from app import models  # noqa: F401
from app.database import MIGRATIONS_DIR, Base, run_migrations


@pytest.fixture()
def db_url():
    return f"sqlite:///{Path(tempfile.mkdtemp()) / 'migrate.db'}"


def _schema_diff(url):
    engine = sa.create_engine(url)
    try:
        with engine.connect() as connection:
            context = MigrationContext.configure(connection, opts={"compare_type": False})
            return compare_metadata(context, Base.metadata)
    finally:
        engine.dispose()


def _execute(url, *statements):
    engine = sa.create_engine(url)
    try:
        with engine.begin() as connection:
            for statement in statements:
                connection.execute(sa.text(statement))
    finally:
        engine.dispose()


def _scalar(url, statement):
    engine = sa.create_engine(url)
    try:
        with engine.connect() as connection:
            return connection.execute(sa.text(statement)).scalar()
    finally:
        engine.dispose()


def test_a_fresh_database_ends_up_matching_the_models(db_url):
    """If this fails, a model changed without a migration: run
    `alembic revision --autogenerate -m "..."` in backend/."""
    run_migrations(db_url)
    assert _schema_diff(db_url) == []


def test_running_twice_is_a_no_op(db_url):
    run_migrations(db_url)
    run_migrations(db_url)
    assert _schema_diff(db_url) == []


def test_a_first_release_database_is_adopted_without_losing_rows(db_url):
    """The schema exactly as the first release created it: no sources, no
    due_at, no owner, no accounts, and no alembic_version table."""
    _execute(
        db_url,
        "CREATE TABLE conversations (id VARCHAR NOT NULL PRIMARY KEY, title VARCHAR, created_at DATETIME)",
        "CREATE TABLE messages (id VARCHAR NOT NULL PRIMARY KEY, conversation_id VARCHAR, role VARCHAR, "
        "text TEXT, language VARCHAR, intent VARCHAR, entities JSON, translated_text TEXT, "
        "audio_url VARCHAR, created_at DATETIME, FOREIGN KEY(conversation_id) REFERENCES conversations (id))",
        "CREATE TABLE reminders (id VARCHAR NOT NULL PRIMARY KEY, text TEXT, when_label VARCHAR, "
        "person VARCHAR, language VARCHAR, is_done VARCHAR, created_at DATETIME)",
        "INSERT INTO conversations (id, title) VALUES ('c1', 'old conversation')",
        "INSERT INTO messages (id, conversation_id, role, text) VALUES ('m1', 'c1', 'user', 'vanakkam')",
        "INSERT INTO reminders (id, text, is_done) VALUES ('r1', 'call amma', 'pending')",
    )

    run_migrations(db_url)

    assert _schema_diff(db_url) == []
    assert _scalar(db_url, "SELECT title FROM conversations WHERE id='c1'") == "old conversation"
    assert _scalar(db_url, "SELECT text FROM messages WHERE id='m1'") == "vanakkam"
    assert _scalar(db_url, "SELECT text FROM reminders WHERE id='r1'") == "call amma"
    # Pre-accounts rows stay unowned rather than being handed to someone.
    assert _scalar(db_url, "SELECT owner_id FROM conversations WHERE id='c1'") is None


def test_a_create_all_database_is_adopted(db_url):
    """What the app built on startup just before migrations were added:
    the five tables of that release, complete, with no alembic_version."""
    engine = sa.create_engine(db_url)
    baseline = ["conversations", "messages", "reminders", "users", "auth_sessions"]
    Base.metadata.create_all(bind=engine, tables=[Base.metadata.tables[name] for name in baseline])
    engine.dispose()

    run_migrations(db_url)
    assert _schema_diff(db_url) == []


def test_the_database_is_stamped_with_the_latest_revision(db_url):
    run_migrations(db_url)
    head = ScriptDirectory(str(MIGRATIONS_DIR)).get_current_head()
    assert _scalar(db_url, "SELECT version_num FROM alembic_version") == head


def test_there_is_a_single_migration_head():
    """Two heads means two people branched the history; `upgrade head`
    would then refuse to run at startup."""
    assert len(ScriptDirectory(str(MIGRATIONS_DIR)).get_heads()) == 1
