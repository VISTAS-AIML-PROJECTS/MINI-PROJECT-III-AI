"""
How a fine-tuned model is allowed to affect the app.

Every test here stands in for a real checkpoint with a stub, so the file
runs without torch installed. The behaviour it pins was measured on real
checkpoints first; each guard exists because of a specific wrong answer:

  - the first language model, unguarded, labelled plain English as Tamil;
  - a well-trained intent model reported under 0.75 confidence on every
    correct answer, so the floor threw all of them away (calibration);
  - the same model answered "sugar level 180, is it normal" with crop
    prices and "is it good to drink milk at night" by saving a reminder.
"""
import json

import pytest

from app.config import settings
from app.services import calibration, intent_detection, language_detection
from app.services.intent_detection import IntentResult
from app.services.language_detection import LanguageResult

PLAIN_ENGLISH = "please book a train ticket to Delhi"
# Tamil in Latin letters with none of the cue words the rules know, so the
# rules call it English. This is the text a language model exists for.
ROMANIZED_TAMIL = "indha kadai eppo thirakkum"


# --- Language model --------------------------------------------------------

def _language_model(monkeypatch, confidence, language="ta-en"):
    asked = []
    monkeypatch.setattr(language_detection, "_muril_enabled", lambda: True)

    def detect(text):
        asked.append(text)
        return LanguageResult(language=language, confidence=confidence, engine="muril")

    monkeypatch.setattr(language_detection, "_muril_detect", detect)
    return asked


def test_the_rules_alone_call_cue_less_romanized_tamil_english(monkeypatch):
    """The gap being filled. If the rules ever learn this sentence, pick
    another one: the tests below need a sentence only a model can place."""
    monkeypatch.setattr(language_detection, "_muril_enabled", lambda: False)
    assert language_detection.detect_language(ROMANIZED_TAMIL).language == "en"


def test_a_confident_language_model_is_used(monkeypatch):
    _language_model(monkeypatch, confidence=0.99)
    result = language_detection.detect_language(ROMANIZED_TAMIL)
    assert (result.language, result.engine) == ("ta-en", "muril")


@pytest.mark.parametrize("confidence", [0.41, 0.88, 0.94])
def test_a_language_model_below_the_floor_is_ignored(monkeypatch, confidence):
    """0.88 is how sure a real checkpoint was that "tomato mandi price" was
    Kannada. The language floor is higher than the intent floor for that."""
    _language_model(monkeypatch, confidence=confidence)
    result = language_detection.detect_language(ROMANIZED_TAMIL)
    assert result.language == "en" and result.engine != "muril"


def test_plain_english_never_reaches_the_language_model(monkeypatch):
    """However sure the model would be. A real checkpoint called "how to
    cook biryani" Hinglish with full confidence because of one loanword."""
    asked = _language_model(monkeypatch, confidence=1.0, language="hi-en")
    for text in (PLAIN_ENGLISH, "how to cook biryani", "what is the weather in Chennai"):
        assert language_detection.detect_language(text).language == "en"
    assert asked == []


@pytest.mark.parametrize("text", ["hi", "cricket score", "ok fine"])
def test_very_short_text_never_reaches_the_language_model(monkeypatch, text):
    """A real checkpoint called the single word "hi" Kannada."""
    asked = _language_model(monkeypatch, confidence=1.0, language="kn-en")
    assert language_detection.detect_language(text).language != "kn-en"
    assert asked == []


def test_native_script_never_reaches_the_language_model(monkeypatch):
    """Script is exact; no model gets a vote on it."""
    asked = _language_model(monkeypatch, confidence=0.99)
    assert language_detection.detect_language("आप कैसे हैं").language == "hi"
    assert asked == []


def test_cue_words_are_decided_by_the_rules_not_the_model(monkeypatch):
    asked = _language_model(monkeypatch, confidence=1.0, language="te-en")
    result = language_detection.detect_language("aap kaise hain, sab theek hai")
    assert (result.language, result.engine) == ("hi-en", "romanized-cues")
    assert asked == []


def test_language_detection_is_repeatable():
    """langdetect is random unless seeded; its verdict now gates the model."""
    answers = {language_detection.detect_language("tomato mandi price").language for _ in range(8)}
    assert len(answers) == 1


# --- Intent model ----------------------------------------------------------

def _intent_model(monkeypatch, intent, confidence=0.99, mode="fallback"):
    monkeypatch.setattr(intent_detection, "_muril_enabled", lambda: True)
    monkeypatch.setattr(settings, "muril_intent_mode", mode)
    monkeypatch.setattr(
        intent_detection,
        "_transformer_intent",
        lambda text, language: IntentResult(intent=intent, confidence=confidence, engine="muril"),
    )


def test_an_unsure_intent_model_is_ignored(monkeypatch):
    _intent_model(monkeypatch, "greeting", confidence=0.3)
    assert intent_detection.detect_intent("what time is it").intent == "get_time"


def test_rules_first_the_model_cannot_override_a_rule_that_matched(monkeypatch):
    """However sure the model is. This is what "fallback" mode promises."""
    _intent_model(monkeypatch, "goodbye", confidence=1.0)
    result = intent_detection.detect_intent("vanakkam boss")
    assert (result.intent, result.engine) == ("greeting", "rule-based")


def test_rules_first_the_model_fills_in_what_the_rules_could_not_place(monkeypatch):
    text = "should I carry an umbrella in Mangaluru today"
    monkeypatch.setattr(intent_detection, "_muril_enabled", lambda: False)
    assert intent_detection.detect_intent(text).intent == "general_query"

    _intent_model(monkeypatch, "get_weather")
    result = intent_detection.detect_intent(text)
    assert (result.intent, result.engine) == ("get_weather", "muril")


def test_model_first_mode_lets_a_confident_model_win(monkeypatch):
    _intent_model(monkeypatch, "goodbye", confidence=1.0, mode="primary")
    assert intent_detection.detect_intent("vanakkam boss").intent == "goodbye"


@pytest.mark.parametrize("mode", ["fallback", "primary"])
def test_emergencies_never_reach_the_model(monkeypatch, mode):
    _intent_model(monkeypatch, "get_weather", confidence=1.0, mode=mode)
    result = intent_detection.detect_intent("I need an ambulance")
    assert (result.intent, result.engine) == ("emergency_help", "rule-based-safety")


def test_a_label_the_app_does_not_know_is_ignored(monkeypatch):
    _intent_model(monkeypatch, "order_pizza")
    assert intent_detection.detect_intent("order a pizza for me").intent == "general_query"


@pytest.mark.parametrize(
    "intent,text",
    [
        # The handler could not act on any of these, so a model answer would
        # replace an honest "I can't help with that yet" with a worse reply.
        ("mandi_price", "what is the price of gold today"),      # no crop to look up
        ("mandi_price", "sugar level 180 is it normal"),
        ("calculate", "how do I work out my loan interest"),     # nothing to compute
        ("convert_unit", "how heavy is an elephant"),
        ("knowledge_help", "my neighbour's dog keeps barking"),  # no curated entry
        ("about_app", "who invented the telephone"),
        ("gov_document_help", "what documents do I need to buy land"),
        ("set_reminder", "is it good to drink milk at night"),   # no time: could never fire
    ],
)
def test_a_model_answer_the_handler_cannot_act_on_is_dropped(monkeypatch, intent, text):
    _intent_model(monkeypatch, intent)
    assert intent_detection.detect_intent(text).intent == "general_query"


def test_a_model_found_reminder_with_a_real_time_is_kept(monkeypatch):
    _intent_model(monkeypatch, "set_reminder")
    result = intent_detection.detect_intent("don't let me forget to call amma at 5 pm")
    assert result.intent == "set_reminder"


def test_a_model_found_mandi_question_with_a_crop_is_kept(monkeypatch):
    _intent_model(monkeypatch, "mandi_price")
    result = intent_detection.detect_intent("how much is tomato in the wholesale yard today")
    assert result.intent == "mandi_price"


# --- Calibration -----------------------------------------------------------

# Three labels. The model ranks the right one first in rows 0-2 and gets
# row 3 wrong, with small score gaps throughout — the "right but unsure"
# shape that made calibration necessary.
LOGITS = [[0.6, 0.1, 0.0], [0.0, 0.7, 0.2], [0.1, 0.0, 0.5], [0.4, 0.3, 0.0]]
LABELS = [0, 1, 2, 1]


def _scores(row):
    return [{"label": name, "score": value} for name, value in zip(("a", "b", "c"), row)]


def test_temperature_never_changes_which_label_wins():
    for row in LOGITS:
        winners = {calibration.top_label(_scores(row), t)[0] for t in (0.05, 0.3, 1.0, 5.0)}
        assert len(winners) == 1


def test_a_low_temperature_sharpens_and_a_high_one_flattens():
    sharp = calibration.top_label(_scores(LOGITS[0]), 0.1)[1]
    plain = calibration.top_label(_scores(LOGITS[0]), 1.0)[1]
    flat = calibration.top_label(_scores(LOGITS[0]), 10.0)[1]
    assert sharp > plain > flat > 1 / 3


def test_fitting_lowers_the_loss_on_the_rows_it_was_fitted_on():
    temperature = calibration.fit_temperature(LOGITS, LABELS)
    before = calibration.negative_log_likelihood(LOGITS, LABELS, 1.0)
    after = calibration.negative_log_likelihood(LOGITS, LABELS, temperature)
    assert temperature < 1.0  # mostly right, under-confident: sharpen
    assert after < before


def test_a_model_that_is_usually_wrong_is_made_less_sure_not_more():
    wrong_labels = [2, 0, 1, 2]
    assert calibration.fit_temperature(LOGITS, wrong_labels) > 1.0


def test_sharpening_is_capped_when_validation_is_perfect():
    """100% on a small validation set would otherwise fit "infinitely sure"."""
    temperature = calibration.fit_temperature(LOGITS[:3], LABELS[:3])
    assert temperature >= 1 / 20 - 1e-6


def test_probabilities_stay_finite_for_extreme_scores():
    label, confidence = calibration.top_label(_scores([900.0, -900.0, 0.0]), 0.05)
    assert label == "a" and confidence == pytest.approx(1.0)


def test_calibration_round_trips_through_the_file(tmp_path):
    report = calibration.save_calibration(tmp_path, LOGITS, LABELS)
    assert report["rows"] == 4 and report["accuracy"] == 0.75
    assert report["nll_after"] <= report["nll_before"]
    assert calibration.load_temperature(tmp_path) == pytest.approx(report["temperature"])


@pytest.mark.parametrize("content", [None, "", "not json", "{}", '{"temperature": 0}', '{"temperature": "x"}'])
def test_a_missing_or_broken_calibration_file_means_no_calibration(tmp_path, content):
    if content is not None:
        (tmp_path / calibration.CALIBRATION_FILE).write_text(content, encoding="utf-8")
    assert calibration.load_temperature(tmp_path) == 1.0


def test_the_calibration_file_is_plain_json(tmp_path):
    calibration.save_calibration(tmp_path, LOGITS, LABELS)
    data = json.loads((tmp_path / calibration.CALIBRATION_FILE).read_text(encoding="utf-8"))
    assert set(data) == {"temperature", "rows", "accuracy", "nll_before", "nll_after"}
