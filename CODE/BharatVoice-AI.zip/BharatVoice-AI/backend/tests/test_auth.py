"""
Accounts and ownership.

The property under test is isolation: what one caller saves, another
caller cannot list, open, change or delete. Each test names the leak it
would otherwise allow.
"""
import tempfile
from datetime import datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import models
from app.database import Base, get_db
from app.main import app
from app.services import auth

GUEST_A = {"X-Guest-Id": "guest-aaaaaaaaaaaaaaaa"}
GUEST_B = {"X-Guest-Id": "guest-bbbbbbbbbbbbbbbb"}
PASSWORD = "correct horse battery"


@pytest.fixture()
def client():
    tmp_dir = tempfile.mkdtemp()
    engine = create_engine(
        f"sqlite:///{Path(tmp_dir) / 'test.db'}", connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(bind=engine)
    TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        test_client.session_factory = TestingSession
        yield test_client
    app.dependency_overrides.clear()


def _register(client, username, headers=None):
    response = client.post(
        "/api/auth/register",
        json={"username": username, "password": PASSWORD},
        headers=headers or {},
    )
    assert response.status_code == 201, response.text
    return {"Authorization": f"Bearer {response.json()['token']}"}


# --- Passwords -------------------------------------------------------------

def test_password_hash_verifies_and_is_not_the_password():
    stored = auth.hash_password(PASSWORD)
    assert PASSWORD not in stored
    assert auth.verify_password(PASSWORD, stored)
    assert not auth.verify_password(PASSWORD + "x", stored)


def test_two_hashes_of_one_password_differ():
    assert auth.hash_password(PASSWORD) != auth.hash_password(PASSWORD)


@pytest.mark.parametrize("stored", ["", "plain", "scrypt$x$y$z$00$00", "md5$1$1$1$00$00"])
def test_malformed_stored_hash_is_a_failed_login_not_a_crash(stored):
    assert auth.verify_password(PASSWORD, stored) is False


# --- Register / login ------------------------------------------------------

def test_register_then_me(client):
    headers = _register(client, "Kavya")
    me = client.get("/api/auth/me", headers=headers).json()
    assert me["username"] == "kavya"  # normalised


def test_duplicate_username_is_rejected_case_insensitively(client):
    _register(client, "kavya")
    response = client.post("/api/auth/register", json={"username": "KAVYA", "password": PASSWORD})
    assert response.status_code == 409


@pytest.mark.parametrize("username", ["ab", "has space", "user:1", "a" * 33])
def test_invalid_usernames_are_rejected(client, username):
    response = client.post("/api/auth/register", json={"username": username, "password": PASSWORD})
    assert response.status_code == 422


def test_short_password_is_rejected(client):
    response = client.post("/api/auth/register", json={"username": "kavya", "password": "short"})
    assert response.status_code == 422


def test_login_with_wrong_password_and_unknown_user_look_the_same(client):
    _register(client, "kavya")
    wrong = client.post("/api/auth/login", json={"username": "kavya", "password": "wrong-password"})
    unknown = client.post("/api/auth/login", json={"username": "nobody", "password": PASSWORD})
    assert wrong.status_code == unknown.status_code == 401
    assert wrong.json() == unknown.json()


def test_the_token_itself_is_not_stored(client):
    headers = _register(client, "kavya")
    token = headers["Authorization"].split()[1]
    db = client.session_factory()
    try:
        stored = [row.token_hash for row in db.query(models.AuthSession).all()]
    finally:
        db.close()
    assert stored and token not in stored


def test_logout_ends_the_session(client):
    headers = _register(client, "kavya")
    assert client.post("/api/auth/logout", headers=headers).status_code == 200
    assert client.get("/api/auth/me", headers=headers).status_code == 401


def test_me_without_a_token_is_401(client):
    assert client.get("/api/auth/me").status_code == 401


def test_a_bad_token_is_401_not_a_silent_guest(client):
    """Otherwise an expired session shows an empty history and looks like
    data loss."""
    response = client.get("/api/history/conversations", headers={"Authorization": "Bearer nope"})
    assert response.status_code == 401


def test_expired_session_is_rejected(client):
    headers = _register(client, "kavya")
    db = client.session_factory()
    try:
        db.query(models.AuthSession).update({models.AuthSession.expires_at: datetime(2020, 1, 1)})
        db.commit()
    finally:
        db.close()
    assert client.get("/api/auth/me", headers=headers).status_code == 401


# --- Isolation -------------------------------------------------------------

def _chat(client, text, headers):
    response = client.post("/api/chat", json={"text": text}, headers=headers)
    assert response.status_code == 200
    return response.json()


def test_users_do_not_see_each_others_conversations(client):
    kavya = _register(client, "kavya")
    arjun = _register(client, "arjun")
    conversation_id = _chat(client, "hello", kavya)["conversation_id"]

    assert len(client.get("/api/history/conversations", headers=kavya).json()) == 1
    assert client.get("/api/history/conversations", headers=arjun).json() == []
    assert client.get(f"/api/history/conversations/{conversation_id}", headers=arjun).status_code == 404
    assert client.delete(f"/api/history/conversations/{conversation_id}", headers=arjun).status_code == 404
    # Still there for its owner.
    assert client.get(f"/api/history/conversations/{conversation_id}", headers=kavya).status_code == 200


def test_another_users_conversation_id_cannot_be_appended_to(client):
    kavya = _register(client, "kavya")
    arjun = _register(client, "arjun")
    conversation_id = _chat(client, "hello", kavya)["conversation_id"]

    reply = client.post(
        "/api/chat", json={"text": "hi", "conversation_id": conversation_id}, headers=arjun
    ).json()
    assert reply["conversation_id"] != conversation_id
    mine = client.get(f"/api/history/conversations/{conversation_id}", headers=kavya).json()
    assert len(mine["messages"]) == 2  # only kavya's own exchange


def test_users_do_not_see_or_touch_each_others_reminders(client):
    kavya = _register(client, "kavya")
    arjun = _register(client, "arjun")
    _chat(client, "remind me in 1 minute to take tablets", kavya)

    reminder_id = client.get("/api/reminders", headers=kavya).json()[0]["id"]
    assert client.get("/api/reminders", headers=arjun).json() == []
    assert client.patch(f"/api/reminders/{reminder_id}/done", headers=arjun).status_code == 404
    assert client.delete(f"/api/reminders/{reminder_id}", headers=arjun).status_code == 404

    listed = _chat(client, "show my reminders", arjun)
    assert "tablets" not in listed["reply_text"]


def test_a_due_reminder_fires_only_for_its_owner(client):
    kavya = _register(client, "kavya")
    arjun = _register(client, "arjun")
    _chat(client, "remind me in 1 minute to take tablets", kavya)
    db = client.session_factory()
    try:
        db.query(models.Reminder).update({models.Reminder.due_at: datetime(2020, 1, 1)})
        db.commit()
    finally:
        db.close()

    # Arjun polling first must not consume Kavya's reminder.
    assert client.get("/api/reminders/due", headers=arjun).json() == []
    assert len(client.get("/api/reminders/due", headers=kavya).json()) == 1


def test_guests_are_isolated_from_each_other_and_from_anonymous(client):
    _chat(client, "hello", GUEST_A)
    assert len(client.get("/api/history/conversations", headers=GUEST_A).json()) == 1
    assert client.get("/api/history/conversations", headers=GUEST_B).json() == []
    assert client.get("/api/history/conversations").json() == []


def test_anonymous_callers_keep_the_old_shared_behaviour(client):
    """No headers at all is what curl, the docs page and a pre-accounts
    database look like; it must keep working."""
    _chat(client, "hello", {})
    assert len(client.get("/api/history/conversations").json()) == 1
    assert client.get("/api/history/conversations", headers=GUEST_A).json() == []


@pytest.mark.parametrize("guest_id", ["short", "user:1234567890abcdef", "a b c d e f g h i j k l"])
def test_a_malformed_guest_id_is_ignored_not_trusted(client, guest_id):
    assert auth.guest_owner(guest_id) is None


def test_registering_keeps_what_the_guest_already_did(client):
    _chat(client, "remind me in 1 minute to take tablets", GUEST_A)
    headers = _register(client, "kavya", headers=GUEST_A)

    assert len(client.get("/api/history/conversations", headers=headers).json()) == 1
    assert len(client.get("/api/reminders", headers=headers).json()) == 1
    # And the guest space is now empty: the rows moved, they were not copied.
    assert client.get("/api/history/conversations", headers=GUEST_A).json() == []


def test_signing_in_on_a_second_device_brings_that_devices_guest_history(client):
    kavya = _register(client, "kavya")
    _chat(client, "hello", kavya)
    _chat(client, "what time is it", GUEST_B)  # a second device, before sign-in

    response = client.post(
        "/api/auth/login", json={"username": "kavya", "password": PASSWORD}, headers=GUEST_B
    )
    second = {"Authorization": f"Bearer {response.json()['token']}"}
    assert len(client.get("/api/history/conversations", headers=second).json()) == 2


def test_synthesize_rejects_oversized_text(client):
    response = client.post("/api/speech/synthesize", json={"text": "a" * 5000, "language": "en"})
    assert response.status_code == 422
