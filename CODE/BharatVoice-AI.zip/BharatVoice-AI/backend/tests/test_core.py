"""
Core regression and behaviour tests for BharatVoice AI.

Run from the backend/ directory:
    pip install -r requirements.txt -r requirements-dev.txt
    pytest

Each test in the "regressions" section corresponds to a bug that was
actually present and is named after the symptom, so a future change that
reintroduces it fails with a readable reason rather than a diff.
"""
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base, get_db
from app.main import app
from app.services import skills, timeparse, weather
from app.services.answers import DomainAnswer
from app.services.entity_extraction import extract_entities
from app.services.intent_detection import INTENTS, detect_intent
from app.services.language_detection import base_language, detect_language
from app.services.response_generator import generate_response

# Every language the assistant claims to support.
SUPPORTED = ("en", "ta", "hi", "te", "kn")

# ---------------------------------------------------------------------------
# Regressions: the calculator used to hijack unrelated requests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "text",
    [
        "remind me on 3/4/2026 to renew my passport",
        "call 1800-123-4567",
        "remind me 5-6 pm to take tablets",
        "order id 123-456",
        "my account number is 1234 5678 9012",
    ],
)
def test_non_calculations_are_not_treated_as_arithmetic(text):
    """
    Any sentence with digits and punctuation used to be read as a sum:
    "remind me on 3/4/2026..." was answered "That's 0.000371" and the
    reminder was silently dropped.
    """
    assert skills.safe_calculate(text) is None


@pytest.mark.parametrize(
    "text,expected",
    [
        ("what is 45 plus 67", 112),
        ("calculate 12 * 8", 96),
        ("20 percent of 500", 100.0),
        ("12*8", 96),
        ("how much is 100 minus 40", 60),
    ],
)
def test_real_calculations_still_work(text, expected):
    assert skills.safe_calculate(text) == expected


def test_reminder_with_a_date_is_classified_as_a_reminder():
    """The end-to-end consequence of the hijack above."""
    assert detect_intent("remind me on 3/4/2026 to renew my passport").intent == "set_reminder"


# ---------------------------------------------------------------------------
# Regressions: exponentiation was an unauthenticated denial of service
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", ["9**9**9**9", "2 ** 999999999", "99**99**99"])
def test_exponentiation_is_rejected_not_computed(text):
    """
    `ast.Pow` used to be allowed, so a single unauthenticated request could
    pin a CPU and exhaust memory. This must return promptly with None.
    """
    assert skills.safe_calculate(text) is None


def test_absurdly_large_results_are_rejected():
    assert skills.safe_calculate("99999999999999 * 99999999999999") is None


# ---------------------------------------------------------------------------
# Regressions: short keywords matched as substrings
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("text", ["please handle this", "the middle one", "badly done"])
def test_dl_alias_does_not_match_inside_other_words(text):
    """`"dl" in text` matched "handle", "middle" and "badly"."""
    assert skills.match_gov_doc(text) is None


def test_driving_licence_still_matches():
    match = skills.match_gov_doc("how do I get a driving licence")
    assert match is not None and match.key == "driving_license"


# ---------------------------------------------------------------------------
# Regressions: places were tagged as people
# ---------------------------------------------------------------------------

def test_a_city_is_not_extracted_as_a_person():
    entities = extract_entities("Remind me to go to Chennai tomorrow")
    people = [e.value for e in entities if e.type == "PERSON"]
    places = [e.value for e in entities if e.type == "PLACE"]
    assert "Chennai" not in people
    assert "Chennai" in places


@pytest.mark.parametrize(
    "text,expected",
    [
        ("கோயம்புத்தூர் வானிலை", "Coimbatore"),          # Tamil, dictionary form
        ("கோயம்புத்தூரில் மழை", "Coimbatore"),            # Tamil, locative suffix
        ("दिल्ली में मौसम", "Delhi"),                      # Hindi
        ("హైదరాబాద్ వాతావరణం", "Hyderabad"),              # Telugu
        ("ಬೆಂಗಳೂರಿನ ಹವಾಮಾನ", "Bengaluru"),                # Kannada, genitive suffix
        ("weather in Chennai", "Chennai"),
        ("Chennai la weather", "Chennai"),                 # romanized code-mixed
    ],
)
def test_places_resolve_to_a_canonical_english_name(text, expected):
    """
    Downstream consumers geocode this value, and geocoding services index
    Indian cities under their English spellings — so whichever script the
    user typed, one canonical name comes out.
    """
    places = [e.value for e in extract_entities(text) if e.type == "PLACE"]
    assert expected in places


def test_longer_place_names_win_over_shorter_ones():
    places = [e.value for e in extract_entities("weather in New Delhi") if e.type == "PLACE"]
    assert places == ["Delhi"]


def test_a_real_person_is_still_extracted():
    entities = extract_entities("Remind me to call Amma at 6pm")
    assert "Amma" in [e.value for e in entities if e.type == "PERSON"]


# ---------------------------------------------------------------------------
# Language identification across the four supported Indic scripts
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "text,expected",
    [
        ("வணக்கம், எப்படி இருக்கீங்க", "ta"),        # Tamil
        ("नमस्ते, आप कैसे हैं", "hi"),                # Hindi (Devanagari)
        ("నమస్కారం, మీరు ఎలా ఉన్నారు", "te"),        # Telugu
        ("ನಮಸ್ಕಾರ, ನೀವು ಹೇಗಿದ್ದೀರಿ", "kn"),          # Kannada
        ("Hello, how are you today?", "en"),
    ],
)
def test_native_script_language_identification(text, expected):
    """
    The four scripts occupy disjoint Unicode blocks, so this should be
    essentially exact with no model involved.
    """
    assert detect_language(text).language == expected


@pytest.mark.parametrize(
    "text,expected_base",
    [
        ("vanakkam, epdi irukeenga", "ta"),
        ("namaste, kya haal hai", "hi"),
        ("namaskaram, ela unnaru", "te"),
        ("namaskara, hegiddira", "kn"),
    ],
)
def test_romanized_input_is_detected_as_code_mixed(text, expected_base):
    """Tanglish/Hinglish typed in Latin script — no script signal to use."""
    result = detect_language(text)
    assert result.language == f"{expected_base}-en"
    assert base_language(result.language) == expected_base


def test_mixed_script_is_reported_as_code_mixed():
    assert detect_language("Chennai la வானிலை epdi irukku").language == "ta-en"


def test_empty_input_does_not_crash():
    assert detect_language("   ").language == "en"


# ---------------------------------------------------------------------------
# Intent detection across languages
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "text",
    ["hello", "வணக்கம்", "नमस्ते", "నమస్కారం", "ನಮಸ್ಕಾರ", "namaskara"],
)
def test_greeting_is_recognised_in_every_language(text):
    assert detect_intent(text).intent == "greeting"


@pytest.mark.parametrize(
    "text",
    ["I need an ambulance", "அவசர உதவி வேண்டும்", "एम्बुलेंस चाहिए", "ambulance"],
)
def test_emergency_is_recognised_and_marked_safety_critical(text):
    result = detect_intent(text)
    assert result.intent == "emergency_help"
    # Emergencies must be resolved by rule, never left to a classifier.
    assert result.engine == "rule-based-safety"


def test_unknown_input_falls_back_to_general_query():
    assert detect_intent("zxcvbn qwerty asdfgh").intent == "general_query"


def test_intent_vocabulary_is_complete():
    """Every intent the response layer handles must be declared."""
    for expected in ("emergency_help", "gov_document_help", "calculate", "convert_unit"):
        assert expected in INTENTS


# ---------------------------------------------------------------------------
# Response generation: the answer contract
# ---------------------------------------------------------------------------

def _answer(intent, language="en", text="", entities=None, context=None):
    return generate_response(
        text=text, language=language, intent=intent, entities=entities or [], context=context
    )


def test_every_answer_is_a_domain_answer():
    answer = _answer("greeting")
    assert isinstance(answer, DomainAnswer)
    assert answer.text


@pytest.mark.parametrize("language", ["en", "ta", "hi", "te", "kn", "ta-en"])
def test_greeting_has_a_translation_for_every_language(language):
    """
    A missing translation silently degrades to English rather than crashing,
    so assert the reply actually differs from the English one where it
    should. This is the check that catches an untranslated string.
    """
    answer = _answer("greeting", language=language)
    assert answer.text
    assert answer.language == language


def test_weather_asks_which_place_rather_than_assuming_one():
    """
    The old code silently defaulted to Chennai, so a Coimbatore user got
    Chennai's weather with no indication anything had been substituted.
    """
    answer = _answer("get_weather", text="what is the weather")
    assert not answer.is_cited
    assert not answer.is_refusal  # asking a question is not a refusal


def test_weather_refuses_when_the_upstream_is_unreachable(monkeypatch):
    """
    A failed lookup must never be filled in with a plausible number. This is
    the behaviour that replaced the fabricated "sunny, around 32°C".
    """
    monkeypatch.setattr(weather, "get_weather", lambda place: None)
    answer = _answer("get_weather", text="weather in Chennai")
    assert answer.is_refusal
    assert not answer.is_cited


def test_weather_success_is_cited_and_timestamped(monkeypatch):
    fake = weather.WeatherResult(
        place="Chennai",
        temperature_c=31.4,
        feels_like_c=36.2,
        condition="cloudy",
        observed_at=datetime(2026, 9, 26, 10, 30, tzinfo=timezone.utc),
    )
    monkeypatch.setattr(weather, "get_weather", lambda place: fake)

    answer = _answer("get_weather", text="weather in Chennai")
    assert "31.4" in answer.text
    assert "Chennai" in answer.text
    assert answer.is_cited
    assert answer.sources[0].checked_on is not None
    # A live number without a timestamp is indistinguishable from a stale one.
    assert answer.staleness and "as of" in answer.staleness


@pytest.mark.parametrize("language", SUPPORTED)
def test_weather_conditions_are_translated(language, monkeypatch):
    fake = weather.WeatherResult(
        place="Chennai", temperature_c=30.0, feels_like_c=None,
        condition="rain", observed_at=datetime(2026, 9, 26, tzinfo=timezone.utc),
    )
    monkeypatch.setattr(weather, "get_weather", lambda place: fake)
    answer = _answer("get_weather", text="weather in Chennai", language=language)
    assert "30" in answer.text


def test_place_is_found_even_when_not_in_the_gazetteer(monkeypatch):
    """
    The PLACE gazetteer knows a few dozen cities; Open-Meteo can geocode
    anywhere, so an unknown town must still reach the lookup.
    """
    seen = {}

    def capture(place):
        seen["place"] = place
        return None

    monkeypatch.setattr(weather, "get_weather", capture)
    _answer("get_weather", text="what is the weather in Kanchipuram")
    assert seen.get("place") == "Kanchipuram"


def test_weather_geocode_failure_returns_none(monkeypatch):
    """Unknown place -> None, never a guessed location."""
    weather.clear_caches()
    monkeypatch.setattr(weather, "_fetch_json", lambda url, params: {"results": []})
    assert weather.get_weather("Zzzzznotaplace") is None


@pytest.mark.parametrize(
    "code,expected",
    [(0, "clear"), (3, "cloudy"), (48, "fog"), (65, "rain"), (75, "snow"), (95, "thunderstorm")],
)
def test_wmo_codes_map_to_translatable_buckets(code, expected):
    assert weather._condition_for_code(code) == expected


def test_emergency_answer_carries_sources():
    answer = _answer("emergency_help")
    assert answer.is_cited
    assert "112" in answer.text


def test_government_document_answer_carries_its_official_portal():
    answer = _answer("gov_document_help", text="how to apply for aadhaar")
    assert answer.is_cited
    assert any("uidai" in (source.url or "") for source in answer.sources)


def test_chit_chat_carries_no_sources():
    """Small talk makes no claim about the world, so it must not cite one."""
    for intent in ("greeting", "thanks", "goodbye", "capabilities"):
        assert not _answer(intent).is_cited



@pytest.mark.parametrize("language", SUPPORTED)
def test_every_helpline_label_is_translated(language):
    """
    Emergency content must never silently fall back to English: someone in
    trouble should not have to read a second language to find the number.
    """
    for number, labels in skills.EMERGENCY_NUMBERS:
        assert language in labels, f"{number} has no {language} label"
        assert labels[language].strip()


@pytest.mark.parametrize("language", SUPPORTED)
def test_every_government_document_is_translated(language):
    for key in ("aadhaar", "pan", "voter_id", "ration_card", "passport", "driving_license"):
        match = skills.match_gov_doc(skills._GOV_DOCS[key]["keywords"][0])
        assert match is not None, f"{key} no longer matches its own first keyword"
        assert language in match.text, f"{key} has no {language} body"


@pytest.mark.parametrize("language", SUPPORTED)
def test_emergency_reply_is_rendered_in_each_language(language):
    reply = skills.format_emergency_reply(language)
    assert "112" in reply
    # Every helpline must appear, whichever language was asked for.
    assert reply.count("—") == len(skills.EMERGENCY_NUMBERS)


def test_government_document_reply_differs_by_language():
    """Guards against a language silently resolving to the English body."""
    match = skills.match_gov_doc("aadhaar")
    rendered = {lang: skills.format_gov_doc_reply(match, lang) for lang in SUPPORTED}
    assert len(set(rendered.values())) == len(SUPPORTED)


# ---------------------------------------------------------------------------
# Reminders that can actually fire
# ---------------------------------------------------------------------------

NOW = datetime(2026, 9, 26, 14, 0, tzinfo=timeparse.IST)  # Sat 2pm IST


@pytest.mark.parametrize(
    "text,expected",
    [
        ("remind me in 30 minutes to call amma", datetime(2026, 9, 26, 14, 30)),
        ("remind me in 2 hours", datetime(2026, 9, 26, 16, 0)),
        ("remind me tomorrow at 6pm", datetime(2026, 9, 27, 18, 0)),
        ("remind me at 5:30 pm", datetime(2026, 9, 26, 17, 30)),
        ("remind me today at 9pm", datetime(2026, 9, 26, 21, 0)),
        ("remind me on 3/10/2026 to renew my passport", datetime(2026, 10, 3, 9, 0)),
        ("remind me on 5 December to pay the bill", datetime(2026, 12, 5, 9, 0)),
    ],
)
def test_parses_a_real_fire_time(text, expected):
    parsed = timeparse.parse_due_at(text, now=NOW)
    assert parsed is not None, f"could not parse: {text}"
    assert parsed.due_at.replace(tzinfo=None) == expected


@pytest.mark.parametrize(
    "text,expected_day",
    [
        ("நாளை 6 மணிக்கு நினைவூட்டு", 27),   # Tamil: tomorrow at 6
        ("कल 6 बजे याद दिलाना", 27),          # Hindi: tomorrow at 6
        ("రేపు గుర్తు చేయి", 27),              # Telugu: tomorrow
        ("ನಾಳೆ ನೆನಪಿಸು", 27),                  # Kannada: tomorrow
    ],
)
def test_parses_time_words_in_indian_languages(text, expected_day):
    parsed = timeparse.parse_due_at(text, now=NOW)
    assert parsed is not None, f"could not parse: {text}"
    assert parsed.due_at.day == expected_day


def test_a_time_already_past_today_rolls_to_tomorrow():
    """"Remind me at 9am" said at 2pm means tomorrow, not eight hours ago."""
    parsed = timeparse.parse_due_at("remind me at 9am", now=NOW)
    assert parsed.due_at.day == 27


def test_relative_labels_are_grammatical():
    assert timeparse.parse_due_at("remind me in 1 minute", now=NOW).label == "in 1 minute"
    assert timeparse.parse_due_at("remind me in 5 minutes", now=NOW).label == "in 5 minutes"
    assert timeparse.parse_due_at("remind me in 1 hour", now=NOW).label == "in 1 hour"


def test_unparseable_timing_returns_none_rather_than_guessing():
    assert timeparse.parse_due_at("remind me about the thing") is None


def test_reminder_without_a_parseable_time_says_so():
    """
    Saving silently and confirming "I've set a reminder" for something that
    can never fire is the same class of error as inventing a temperature.
    """
    answer = _answer(
        "set_reminder",
        text="remind me about the thing",
        context={"reminder_scheduled": False},
    )
    assert "couldn't" in answer.text or "not" in answer.text.lower()


def test_due_endpoint_fires_once_and_only_once(client):
    """A reminder should surface when its time comes, then stop surfacing."""
    client.post("/api/chat", json={"text": "remind me in 1 minute to take tablets"})

    # Not due yet.
    assert client.get("/api/reminders/due").json() == []

    # Move its due time into the past, the way the clock would.
    reminders = client.get("/api/reminders").json()
    assert reminders and reminders[0]["due_at"] is not None

    from app.database import get_db  # the overridden session factory
    session = next(app.dependency_overrides[get_db]())
    try:
        from app import models as m
        row = session.query(m.Reminder).first()
        row.due_at = datetime(2020, 1, 1)
        session.commit()
    finally:
        session.close()

    fired = client.get("/api/reminders/due").json()
    assert len(fired) == 1
    assert "tablets" in fired[0]["text"]

    # Fires once, not on every poll.
    assert client.get("/api/reminders/due").json() == []


def test_emergency_sources_have_no_unverified_date():
    """
    `checked_on` must stay None until a human actually re-verifies the
    helpline list. A fabricated date is worse than no date.
    """
    for source in skills.EMERGENCY_SOURCES:
        assert source.checked_on is None, (
            "Set checked_on only after verifying the numbers against the official portal"
        )


# ---------------------------------------------------------------------------
# API smoke test
# ---------------------------------------------------------------------------

@pytest.fixture()
def client():
    """TestClient backed by a throwaway SQLite file."""
    tmp_dir = tempfile.mkdtemp()
    engine = create_engine(
        f"sqlite:///{Path(tmp_dir) / 'test.db'}", connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(bind=engine)
    TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def test_health_endpoint(client):
    assert client.get("/api/health").json() == {"status": "ok"}


def test_chat_returns_reply_and_nlu_trace(client):
    response = client.post("/api/chat", json={"text": "வணக்கம்"})
    assert response.status_code == 200
    body = response.json()
    assert body["nlu"]["language"] == "ta"
    assert body["nlu"]["intent"] == "greeting"
    assert body["reply_text"]
    assert body["sources"] == []


def test_chat_emergency_returns_sources(client):
    body = client.post("/api/chat", json={"text": "I need an ambulance"}).json()
    assert body["nlu"]["intent"] == "emergency_help"
    assert len(body["sources"]) >= 1


def test_chat_rejects_empty_and_oversized_input(client):
    assert client.post("/api/chat", json={"text": ""}).status_code == 422
    assert client.post("/api/chat", json={"text": "a" * 5000}).status_code == 422


def test_chat_handles_the_exponentiation_payload_quickly(client):
    """End-to-end guard on the denial-of-service path."""
    response = client.post("/api/chat", json={"text": "9**9**9**9"})
    assert response.status_code == 200
