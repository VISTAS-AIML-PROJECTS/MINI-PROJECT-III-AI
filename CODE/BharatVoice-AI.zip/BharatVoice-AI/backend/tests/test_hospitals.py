"""
Hospital lookup.

The adapter has never seen a real response (see services/hospitals.py), so
these tests pin its behaviour around the call rather than the call itself:
it is dormant without a key, it never invents a row, and whenever it has
nothing the curated answer is what the user gets.
"""
import pytest

from app.config import settings
from app.services import hospitals
from app.services.intent_detection import detect_intent
from app.services.response_generator import generate_response

SUPPORTED = ("en", "ta", "hi", "te", "kn")

RECORDS = [
    {"Hospital_Name": "Government Rajaji Hospital", "District": "Madurai",
     "_Address_Original_First_Line": "Panagal Road", "Telephone": "0452-2532535, 0452-2532536",
     "Hospital_Category": "Public"},
    {"Hospital_Name": "Government Rajaji Hospital", "District": "Madurai"},  # duplicate
    {"Hospital_Name": "NA", "District": "Madurai"},                           # no usable name
    {"Hospital_Name": "Meenakshi Mission Hospital", "District": "Madurai", "Telephone": "0"},
    "not a record",
]


@pytest.fixture()
def configured(monkeypatch):
    hospitals.clear_caches()
    monkeypatch.setattr(settings, "data_gov_api_key", "test-key")
    yield
    hospitals.clear_caches()


def _ask(text, language="en"):
    return generate_response(
        text=text, language=language, intent=detect_intent(text).intent, entities=[]
    )


def test_dormant_without_a_key(monkeypatch):
    monkeypatch.setattr(settings, "data_gov_api_key", "")

    def explode(filters):
        raise AssertionError("no request may be made without a key")

    monkeypatch.setattr(hospitals, "_fetch", explode)
    assert hospitals.find_hospitals("Madurai") is None


def test_dormant_when_the_resource_id_is_cleared(configured, monkeypatch):
    monkeypatch.setattr(settings, "hospital_resource_id", "")
    assert hospitals.is_configured() is False


def test_records_are_parsed_defensively(configured, monkeypatch):
    monkeypatch.setattr(hospitals, "_fetch", lambda filters: RECORDS)
    found = hospitals.find_hospitals("madurai")
    assert [h.name for h in found] == ["Government Rajaji Hospital", "Meenakshi Mission Hospital"]
    assert found[0].phone == "0452-2532535"  # first of several
    assert found[0].address == "Panagal Road"
    assert found[1].phone == ""  # "0" is the dataset's "not reported"


def test_the_district_is_what_gets_filtered_on(configured, monkeypatch):
    seen = {}
    monkeypatch.setattr(hospitals, "_fetch", lambda filters: seen.update(filters) or RECORDS)
    hospitals.find_hospitals("  madurai ")
    assert seen == {"district": "Madurai"}


@pytest.mark.parametrize("records", [None, [], [{"unexpected": "shape"}], ["junk"]])
def test_no_usable_rows_is_none(configured, monkeypatch, records):
    monkeypatch.setattr(hospitals, "_fetch", lambda filters: records)
    assert hospitals.find_hospitals("Madurai") is None


def test_results_are_cached(configured, monkeypatch):
    calls = []
    monkeypatch.setattr(hospitals, "_fetch", lambda filters: calls.append(1) or RECORDS)
    hospitals.find_hospitals("Madurai")
    hospitals.find_hospitals("MADURAI")
    assert len(calls) == 1


def test_at_most_five_rows(configured, monkeypatch):
    many = [{"Hospital_Name": f"Hospital {i}", "District": "Madurai"} for i in range(20)]
    monkeypatch.setattr(hospitals, "_fetch", lambda filters: many)
    assert len(hospitals.find_hospitals("Madurai")) == 5


def test_a_hospital_question_routes_to_the_health_entry():
    """The lookup hangs off this entry, so the routing is part of it."""
    assert detect_intent("hospitals in Madurai").intent == "knowledge_help"


@pytest.mark.parametrize("language", SUPPORTED)
def test_a_live_answer_lists_cites_and_carries_the_caveat(configured, monkeypatch, language):
    monkeypatch.setattr(hospitals, "_fetch", lambda filters: RECORDS)
    answer = _ask("hospitals in Madurai", language)
    assert "Government Rajaji Hospital" in answer.text
    assert "108" in answer.text and answer.dialable == ["108"]
    assert answer.sources[0].title == hospitals.SOURCE_TITLE
    assert answer.sources[0].checked_on is not None


def test_a_hospitals_own_number_is_not_made_dialable(configured, monkeypatch):
    """Registry numbers are unverified; only the helpline may be tapped."""
    monkeypatch.setattr(
        hospitals, "_fetch",
        lambda filters: [{"Hospital_Name": "Clinic", "District": "Madurai", "Telephone": "112"}],
    )
    assert _ask("hospitals in Madurai").dialable == ["108"]


def test_a_failed_lookup_falls_back_to_the_curated_answer(configured, monkeypatch):
    monkeypatch.setattr(hospitals, "_fetch", lambda filters: None)
    curated = _ask("hospitals in Madurai")
    monkeypatch.setattr(settings, "data_gov_api_key", "")
    hospitals.clear_caches()
    assert curated.text == _ask("hospitals in Madurai").text
    assert curated.sources[0].title != hospitals.SOURCE_TITLE


def test_no_place_named_falls_back_to_the_curated_answer(configured, monkeypatch):
    def explode(filters):
        raise AssertionError("nothing to look up without a place")

    monkeypatch.setattr(hospitals, "_fetch", explode)
    answer = _ask("where is the nearest hospital")
    assert answer.sources and answer.sources[0].title != hospitals.SOURCE_TITLE
