"""
Gemini reply layer (services/gemini.py).

The network call is stubbed: these check what is sent and what the app does
with the reply, not how good Gemini's wording is.
"""
import json
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.config import settings
from app.database import Base, get_db
from app.main import app
from app.services import gemini
from app.services.answers import DomainAnswer, Source


class _FakeResponse:
    def __init__(self, payload: dict):
        self._body = json.dumps(payload).encode("utf-8")

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


@pytest.fixture()
def gemini_on(monkeypatch):
    """Turn Gemini on with a stubbed HTTP call; yields the list of requests sent."""
    monkeypatch.setattr(settings, "gemini_api_key", "test-key")
    sent = []
    replies = {"text": "Gemini says hello."}

    def fake_urlopen(request, timeout):
        sent.append(
            {
                "url": request.full_url,
                "headers": dict(request.header_items()),
                "body": json.loads(request.data),
            }
        )
        if replies["text"] is None:
            raise OSError("network down")
        return _FakeResponse(
            {"candidates": [{"content": {"parts": [{"text": replies["text"]}]}}]}
        )

    monkeypatch.setattr(gemini.urllib.request, "urlopen", fake_urlopen)
    yield sent, replies


@pytest.fixture()
def client():
    tmp_dir = tempfile.mkdtemp()
    engine = create_engine(
        f"sqlite:///{Path(tmp_dir) / 'test.db'}", connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(bind=engine)
    TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


def _draft(**kwargs) -> DomainAnswer:
    return DomainAnswer(text="Draft answer.", language="en", **kwargs)


def test_off_without_a_key():
    assert not gemini.is_enabled()
    assert gemini.gemini_reply("hi", "en", "greeting", _draft()) is None


def test_open_question_is_answered_by_gemini_without_sources(gemini_on):
    reply = gemini.gemini_reply("what is a mutual fund", "en", "general_query")
    assert reply.text == "Gemini says hello."
    # A model's own words must not be presented as the cited record.
    assert reply.sources == []
    assert not reply.is_refusal


def test_local_intent_keeps_the_apps_facts(gemini_on):
    sent, _ = gemini_on
    draft = _draft(sources=[Source(title="Helplines")], dialable=["112"])
    reply = gemini.gemini_reply("police number", "en", "emergency_help", draft)
    assert reply.text == "Gemini says hello."
    assert reply.sources == draft.sources
    assert reply.dialable == ["112"]
    prompt = sent[0]["body"]["contents"][-1]["parts"][0]["text"]
    assert "Draft answer." in prompt


def test_reply_language_is_requested(gemini_on):
    sent, _ = gemini_on
    gemini.gemini_reply("vanakkam", "ta-en", "greeting", _draft())
    assert "Tamil" in sent[0]["body"]["systemInstruction"]["parts"][0]["text"]


def test_key_goes_in_a_header_not_the_url(gemini_on):
    sent, _ = gemini_on
    gemini.gemini_reply("hi", "en", "greeting", _draft())
    assert "test-key" not in sent[0]["url"]
    assert sent[0]["headers"]["X-goog-api-key"] == "test-key"


def test_failure_keeps_the_pipeline_answer(gemini_on):
    _, replies = gemini_on
    replies["text"] = None
    assert gemini.gemini_reply("hi", "en", "greeting", _draft()) is None


def test_blocked_reply_keeps_the_pipeline_answer(monkeypatch):
    monkeypatch.setattr(settings, "gemini_api_key", "test-key")
    monkeypatch.setattr(
        gemini.urllib.request,
        "urlopen",
        lambda request, timeout: _FakeResponse({"promptFeedback": {"blockReason": "SAFETY"}}),
    )
    assert gemini.gemini_reply("hi", "en", "greeting", _draft()) is None


def test_chat_endpoint_uses_gemini_and_sends_history(client, gemini_on):
    sent, _ = gemini_on
    first = client.post("/api/chat", json={"text": "hello"}).json()
    assert first["reply_text"] == "Gemini says hello."

    client.post(
        "/api/chat", json={"text": "and you?", "conversation_id": first["conversation_id"]}
    )
    roles = [c["role"] for c in sent[1]["body"]["contents"]]
    assert roles == ["user", "model", "user"]


def test_chat_endpoint_says_so_when_gemini_fails(client, gemini_on):
    _, replies = gemini_on
    replies["text"] = None
    body = client.post("/api/chat", json={"text": "hello"}).json()
    assert body["reply_text"] == gemini.unavailable("en").text
    assert body["is_refusal"]


@pytest.mark.parametrize(
    "text, intent",
    [("what is the weather in Chennai", "get_weather"), ("tomato mandi price", "mandi_price")],
)
def test_no_other_api_is_called_with_gemini_on(client, gemini_on, monkeypatch, text, intent):
    from app.services import hospitals, mandi, weather

    def forbidden(*args, **kwargs):
        raise AssertionError("an API other than Gemini was called")

    monkeypatch.setattr(weather, "get_weather", forbidden)
    monkeypatch.setattr(mandi, "get_prices", forbidden)
    monkeypatch.setattr(hospitals, "find_hospitals", forbidden)
    body = client.post("/api/chat", json={"text": text}).json()
    assert body["nlu"]["intent"] == intent
    assert body["reply_text"] == "Gemini says hello."
    assert body["sources"] == []


def test_local_answer_stands_when_gemini_fails(client, gemini_on):
    _, replies = gemini_on
    replies["text"] = None
    body = client.post("/api/chat", json={"text": "what is 12 + 30"}).json()
    assert "42" in body["reply_text"]


def test_reminder_is_still_saved_with_gemini_on(client, gemini_on):
    client.post("/api/chat", json={"text": "remind me to call amma tomorrow at 6 pm"})
    reminders = client.get("/api/reminders").json()
    assert len(reminders) == 1


def test_a_reply_cut_off_by_the_token_limit_is_not_used(monkeypatch):
    monkeypatch.setattr(settings, "gemini_api_key", "test-key")
    monkeypatch.setattr(
        gemini.urllib.request,
        "urlopen",
        lambda request, timeout: _FakeResponse(
            {"candidates": [{"finishReason": "MAX_TOKENS", "content": {"parts": [{"text": "வணக்கம், நான்"}]}}]}
        ),
    )
    assert gemini.gemini_reply("vanakkam", "ta", "greeting") is None
