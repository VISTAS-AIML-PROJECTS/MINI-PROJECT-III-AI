#!/usr/bin/env python3
"""
Build the MuRIL training sets from a bank of question templates.
==================================================================
    cd backend
    python scripts/build_training_data.py

Writes two files under scripts/data/:

    intent_training_data.csv   text,label,lang,review   (label = intent)
    langid_training_data.csv   text,label,review        (label = language)

WHY A GENERATOR. The first checkpoints were trained on 60 hand-written
rows covering 6 of the app's 19 intents, and scored well below the rules.
A model needs a few hundred examples per intent, in every language the app
accepts, including the romanized and code-mixed text most people actually
type. Writing six thousand rows by hand is not realistic; writing a few
hundred sentence patterns and filling them with places, crops, tasks and
times is.

WHAT THAT COSTS, stated plainly:

  - These are synthetic questions. They are the phrasings their author
    thought of, not a sample of what users say, so the model learns this
    bank's idea of each intent. Real logged questions are better training
    data and should replace these as they accumulate.
  - A model can score very well on rows built from the same templates it
    trained on. That number means nothing. The honest measure is
    the hand-written test files in scripts/data/ (`*_test_data.csv`,
    `*_test.csv`). This script never writes to them; it reads them only to
    drop any generated row identical to a test row.
  - Hindi, Telugu and Kannada lines — native script and romanized — were
    written without a native speaker and are marked `needs-review` in the
    `review` column, the same status as `# NEEDS REVIEW` strings elsewhere
    in this project. Tamil and English rows are marked `ok`.

The output is deterministic (fixed seed), so re-running without editing
the bank reproduces the same files and a diff shows exactly what a
template change did.

The 60 + 45 original hand-written rows are kept, in intent_seed.csv and
langid_seed.csv, and are included in the output.
"""
import csv
import random
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data"
SEED = 20261009
PER_INTENT_PER_LANG = 34   # x 9 language keys = about 300 rows per intent
PER_LANGUAGE = 300         # rows per label in the language-ID set
# "Everything else" is far more varied than any single skill, so it gets
# three times the rows. Under-representing it is what makes a model answer
# every question as if it were one of the skills.
GENERAL_QUERY_WEIGHT = 3

LANGS = ("en", "ta", "hi", "te", "kn", "ta-en", "hi-en", "te-en", "kn-en")
NEEDS_REVIEW = {"hi", "te", "kn", "hi-en", "te-en", "kn-en"}

# ---------------------------------------------------------------------------
# Slot values
# ---------------------------------------------------------------------------

_LATIN_PLACES = [
    "Chennai", "Madurai", "Coimbatore", "Salem", "Trichy", "Delhi", "Mumbai",
    "Hyderabad", "Bengaluru", "Mysuru", "Vijayawada", "Lucknow", "Pune",
    "Kochi", "Jaipur", "Patna", "Warangal", "Hubballi", "Tirunelveli", "Nagpur",
]
PLACES = {
    "en": _LATIN_PLACES, "ta-en": _LATIN_PLACES, "hi-en": _LATIN_PLACES,
    "te-en": _LATIN_PLACES, "kn-en": _LATIN_PLACES,
    "ta": ["சென்னை", "மதுரை", "கோயம்புத்தூர்", "சேலம்", "திருச்சி", "டெல்லி", "மும்பை",
           "திருநெல்வேலி", "தஞ்சாவூர்", "ஈரோடு", "வேலூர்", "பெங்களூரு"],
    "hi": ["दिल्ली", "मुंबई", "लखनऊ", "पटना", "जयपुर", "भोपाल", "वाराणसी", "कानपुर",
           "इंदौर", "नागपुर", "चेन्नई", "हैदराबाद"],
    "te": ["హైదరాబాద్", "విజయవాడ", "విశాఖపట్నం", "వరంగల్", "తిరుపతి", "గుంటూరు",
           "కర్నూలు", "నెల్లూరు", "చెన్నై", "బెంగళూరు"],
    "kn": ["ಬೆಂಗಳೂರು", "ಮೈಸೂರು", "ಹುಬ್ಬಳ್ಳಿ", "ಮಂಗಳೂರು", "ಬೆಳಗಾವಿ", "ಶಿವಮೊಗ್ಗ",
           "ತುಮಕೂರು", "ಧಾರವಾಡ", "ಚೆನ್ನೈ", "ಹೈದರಾಬಾದ್"],
}

_LATIN_CROPS = ["tomato", "onion", "potato", "rice", "wheat", "banana", "coconut",
                "cotton", "turmeric", "brinjal", "groundnut", "sugarcane"]
CROPS = {
    "en": _LATIN_CROPS, "ta-en": _LATIN_CROPS + ["thakkali", "vengayam"],
    "hi-en": _LATIN_CROPS + ["tamatar", "pyaaz", "aloo", "gehu"],
    "te-en": _LATIN_CROPS + ["tamata", "ullipaya"], "kn-en": _LATIN_CROPS + ["eerulli"],
    "ta": ["தக்காளி", "வெங்காயம்", "உருளைக்கிழங்கு", "அரிசி", "கோதுமை", "வாழை",
           "தேங்காய்", "பருத்தி", "மஞ்சள்", "கத்தரிக்காய்", "நிலக்கடலை", "கரும்பு"],
    "hi": ["टमाटर", "प्याज", "आलू", "चावल", "गेहूं", "केला", "नारियल", "कपास",
           "हल्दी", "बैंगन", "मूंगफली", "गन्ना"],
    "te": ["టమాటా", "ఉల్లి", "బంగాళాదుంప", "బియ్యం", "గోధుమ", "అరటి", "కొబ్బరి",
           "పత్తి", "పసుపు", "వంకాయ", "వేరుశనగ", "చెరకు"],
    "kn": ["ಟೊಮೇಟೊ", "ಈರುಳ್ಳಿ", "ಆಲೂಗಡ್ಡೆ", "ಅಕ್ಕಿ", "ಗೋಧಿ", "ಬಾಳೆ", "ತೆಂಗಿನಕಾಯಿ",
           "ಹತ್ತಿ", "ಅರಿಶಿನ", "ಬದನೆ", "ಶೇಂಗಾ", "ಕಬ್ಬು"],
}

TASKS = {
    "en": ["call amma", "take my tablets", "pay the electricity bill", "book the gas cylinder",
           "go to the bank", "pick up the kids", "water the plants", "renew my passport",
           "attend the meeting", "buy vegetables", "recharge my phone", "visit the doctor"],
    "ta": ["அம்மாவுக்கு போன் செய்ய", "மாத்திரை சாப்பிட", "மின் கட்டணம் கட்ட", "கேஸ் புக் செய்ய",
           "வங்கிக்கு போக", "குழந்தைகளை அழைத்து வர", "செடிக்கு தண்ணீர் ஊற்ற",
           "டாக்டரை பார்க்க", "காய்கறி வாங்க", "கூட்டத்திற்கு போக"],
    "hi": ["माँ को फ़ोन करना", "दवा लेनी", "बिजली का बिल भरना", "गैस बुक करनी",
           "बैंक जाना", "बच्चों को लेने जाना", "पौधों को पानी देना", "डॉक्टर के पास जाना",
           "सब्ज़ी खरीदनी", "मीटिंग में जाना"],
    "te": ["అమ్మకు ఫోన్ చేయాలని", "మాత్రలు వేసుకోవాలని", "కరెంటు బిల్లు కట్టాలని",
           "గ్యాస్ బుక్ చేయాలని", "బ్యాంకుకు వెళ్లాలని", "పిల్లలను తీసుకురావాలని",
           "డాక్టర్ దగ్గరకు వెళ్లాలని", "కూరగాయలు కొనాలని", "మీటింగ్‌కు వెళ్లాలని"],
    "kn": ["ಅಮ್ಮನಿಗೆ ಫೋನ್ ಮಾಡಲು", "ಮಾತ್ರೆ ತೆಗೆದುಕೊಳ್ಳಲು", "ಕರೆಂಟ್ ಬಿಲ್ ಕಟ್ಟಲು",
           "ಗ್ಯಾಸ್ ಬುಕ್ ಮಾಡಲು", "ಬ್ಯಾಂಕಿಗೆ ಹೋಗಲು", "ಮಕ್ಕಳನ್ನು ಕರೆತರಲು",
           "ಡಾಕ್ಟರ್ ಬಳಿ ಹೋಗಲು", "ತರಕಾರಿ ಕೊಳ್ಳಲು", "ಮೀಟಿಂಗ್‌ಗೆ ಹೋಗಲು"],
    "ta-en": ["amma ku call panna", "tablet saapida", "EB bill katta", "gas book panna",
              "bank ku poga", "pasangala kootitu vara", "doctor ah paaka", "kaikari vaanga",
              "meeting ku poga", "phone recharge panna"],
    "hi-en": ["mummy ko call karna", "dawai leni", "bijli ka bill bharna", "gas book karni",
              "bank jaana", "bachchon ko lene jaana", "doctor ke paas jaana", "sabzi leni",
              "meeting mein jaana", "phone recharge karna"],
    "te-en": ["amma ki call cheyyali", "tablets vesukovali", "current bill kattali",
              "gas book cheyyali", "bank ki vellali", "pillalni teesukuravali",
              "doctor daggaraki vellali", "kuragayalu konali", "meeting ki vellali"],
    "kn-en": ["amma ge call madoke", "tablet togoloke", "current bill kattoke",
              "gas book madoke", "bank ge hogoke", "makkalanna karkond baroke",
              "doctor hatra hogoke", "tarakari togoloke", "meeting ge hogoke"],
}

WHENS = {
    "en": ["at 6 pm", "tomorrow morning", "at 9 am", "in 10 minutes", "in 2 hours",
           "tonight at 8", "tomorrow at 5 pm", "at 7:30 am", "in half an hour", "on Monday"],
    "ta": ["மாலை 6 மணிக்கு", "நாளை காலை", "காலை 9 மணிக்கு", "10 நிமிடத்தில்",
           "2 மணி நேரத்தில்", "இன்று இரவு 8 மணிக்கு", "நாளை மாலை 5 மணிக்கு"],
    "hi": ["शाम 6 बजे", "कल सुबह", "सुबह 9 बजे", "10 मिनट में", "2 घंटे में",
           "आज रात 8 बजे", "कल शाम 5 बजे"],
    "te": ["సాయంత్రం 6 గంటలకు", "రేపు ఉదయం", "ఉదయం 9 గంటలకు", "10 నిమిషాల్లో",
           "2 గంటల్లో", "ఈ రాత్రి 8 గంటలకు", "రేపు సాయంత్రం 5 గంటలకు"],
    "kn": ["ಸಂಜೆ 6 ಗಂಟೆಗೆ", "ನಾಳೆ ಬೆಳಿಗ್ಗೆ", "ಬೆಳಿಗ್ಗೆ 9 ಗಂಟೆಗೆ", "10 ನಿಮಿಷದಲ್ಲಿ",
           "2 ಗಂಟೆಯಲ್ಲಿ", "ಇಂದು ರಾತ್ರಿ 8 ಗಂಟೆಗೆ", "ನಾಳೆ ಸಂಜೆ 5 ಗಂಟೆಗೆ"],
    "ta-en": ["6 mani ku", "naalaiku kaalaila", "kaalaila 9 mani ku", "10 nimishathula",
              "2 mani nerathula", "innaiku night 8 mani ku", "naalaiku 5 pm ku"],
    "hi-en": ["shaam 6 baje", "kal subah", "subah 9 baje", "10 minute mein",
              "2 ghante mein", "aaj raat 8 baje", "kal 5 pm ko"],
    "te-en": ["sayantram 6 gantalaki", "repu poddunna", "poddunna 9 gantalaki",
              "10 nimishallo", "2 gantallo", "ee ratri 8 gantalaki", "repu 5 pm ki"],
    "kn-en": ["sanje 6 gantege", "naale beligge", "beligge 9 gantege", "10 nimishadalli",
              "2 ganteyalli", "ivattu ratri 8 gantege", "naale 5 pm ge"],
}

_LATIN_DOCS = ["aadhaar card", "PAN card", "voter id", "ration card", "passport", "driving licence"]
DOCS = {
    "en": _LATIN_DOCS, "ta-en": _LATIN_DOCS, "hi-en": _LATIN_DOCS,
    "te-en": _LATIN_DOCS, "kn-en": _LATIN_DOCS,
    "ta": ["ஆதார் அட்டை", "பான் கார்டு", "வாக்காளர் அட்டை", "ரேஷன் கார்டு", "பாஸ்போர்ட்", "ஓட்டுநர் உரிமம்"],
    "hi": ["आधार कार्ड", "पैन कार्ड", "वोटर आईडी", "राशन कार्ड", "पासपोर्ट", "ड्राइविंग लाइसेंस"],
    "te": ["ఆధార్ కార్డు", "పాన్ కార్డు", "ఓటర్ ఐడీ", "రేషన్ కార్డు", "పాస్‌పోర్ట్", "డ్రైవింగ్ లైసెన్స్"],
    "kn": ["ಆಧಾರ್ ಕಾರ್ಡ್", "ಪ್ಯಾನ್ ಕಾರ್ಡ್", "ಮತದಾರರ ಚೀಟಿ", "ಪಡಿತರ ಚೀಟಿ", "ಪಾಸ್‌ಪೋರ್ಟ್", "ಚಾಲನಾ ಪರವಾನಗಿ"],
}

WORDS = ["water", "thank you", "good morning", "food", "how much is this", "where is the bus stand",
         "friend", "mother", "I am hungry", "see you tomorrow", "rice", "school", "hospital"]
TARGETS = {
    "en": ["Tamil", "Hindi", "Telugu", "Kannada", "English"],
    "ta": ["தமிழில்", "இந்தியில்", "தெலுங்கில்", "கன்னடத்தில்", "ஆங்கிலத்தில்"],
    "hi": ["तमिल में", "हिंदी में", "तेलुगु में", "कन्नड़ में", "अंग्रेज़ी में"],
    "te": ["తమిళంలో", "హిందీలో", "తెలుగులో", "కన్నడలో", "ఇంగ్లీషులో"],
    "kn": ["ತಮಿಳಿನಲ್ಲಿ", "ಹಿಂದಿಯಲ್ಲಿ", "ತೆಲುಗಿನಲ್ಲಿ", "ಕನ್ನಡದಲ್ಲಿ", "ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ"],
    "ta-en": ["Tamil la", "Hindi la", "Telugu la", "Kannada la", "English la"],
    "hi-en": ["Tamil mein", "Hindi mein", "Telugu mein", "Kannada mein", "English mein"],
    "te-en": ["Tamil lo", "Hindi lo", "Telugu lo", "Kannada lo", "English lo"],
    "kn-en": ["Tamil alli", "Hindi alli", "Telugu alli", "Kannada dalli", "English alli"],
}

_LATIN_STATES = ["Tamil Nadu", "Karnataka", "Kerala", "Andhra Pradesh", "Telangana", "Maharashtra",
                 "Bihar", "Gujarat", "Punjab", "Odisha", "West Bengal", "Rajasthan"]
STATES = {
    "en": _LATIN_STATES, "ta-en": _LATIN_STATES, "hi-en": _LATIN_STATES,
    "te-en": _LATIN_STATES, "kn-en": _LATIN_STATES,
    "ta": ["தமிழ்நாடு", "கர்நாடகா", "கேரளா", "ஆந்திரா", "தெலங்கானா", "மகாராஷ்டிரா", "பீகார்", "குஜராத்"],
    "hi": ["तमिलनाडु", "कर्नाटक", "केरल", "आंध्र प्रदेश", "तेलंगाना", "महाराष्ट्र", "बिहार", "गुजरात"],
    "te": ["తమిళనాడు", "కర్ణాటక", "కేరళ", "ఆంధ్రప్రదేశ్", "తెలంగాణ", "మహారాష్ట్ర", "బీహార్", "గుజరాత్"],
    "kn": ["ತಮಿಳುನಾಡು", "ಕರ್ನಾಟಕ", "ಕೇರಳ", "ಆಂಧ್ರಪ್ರದೇಶ", "ತೆಲಂಗಾಣ", "ಮಹಾರಾಷ್ಟ್ರ", "ಬಿಹಾರ", "ಗುಜರಾತ್"],
}

# Things with a price that are NOT mandi crops. "What is the price of X"
# must not become a mandi question just because it has a price in it.
_LATIN_THINGS = ["gold", "silver", "petrol", "diesel", "a gas cylinder", "a new phone", "a scooter",
                 "cement", "a laptop", "a bus pass", "milk", "a fridge", "school fees", "a train ticket to Delhi"]
THINGS = {
    "en": _LATIN_THINGS, "ta-en": _LATIN_THINGS, "hi-en": _LATIN_THINGS,
    "te-en": _LATIN_THINGS, "kn-en": _LATIN_THINGS,
    "ta": ["தங்கம்", "வெள்ளி", "பெட்ரோல்", "டீசல்", "கேஸ் சிலிண்டர்", "புது போன்", "ஸ்கூட்டர்", "சிமெண்ட்", "பால்"],
    "hi": ["सोना", "चाँदी", "पेट्रोल", "डीज़ल", "गैस सिलेंडर", "नया फ़ोन", "स्कूटर", "सीमेंट", "दूध"],
    "te": ["బంగారం", "వెండి", "పెట్రోల్", "డీజిల్", "గ్యాస్ సిలిండర్", "కొత్త ఫోన్", "స్కూటర్", "సిమెంట్", "పాలు"],
    "kn": ["ಚಿನ್ನ", "ಬೆಳ್ಳಿ", "ಪೆಟ್ರೋಲ್", "ಡೀಸೆಲ್", "ಗ್ಯಾಸ್ ಸಿಲಿಂಡರ್", "ಹೊಸ ಫೋನ್", "ಸ್ಕೂಟರ್", "ಸಿಮೆಂಟ್", "ಹಾಲು"],
}

_LATIN_APPS = ["YouTube", "WhatsApp", "the camera", "Google Maps", "Facebook", "the calculator app",
               "my gallery", "Instagram", "the radio", "the torch"]
APPS = {lang: _LATIN_APPS for lang in ("en", "ta-en", "hi-en", "te-en", "kn-en")}
APPS.update({
    "ta": ["யூடியூப்", "வாட்ஸ்அப்", "கேமரா", "கூகுள் மேப்ஸ்", "ஃபேஸ்புக்", "ரேடியோ", "டார்ச்"],
    "hi": ["यूट्यूब", "व्हाट्सऐप", "कैमरा", "गूगल मैप्स", "फ़ेसबुक", "रेडियो", "टॉर्च"],
    "te": ["యూట్యూబ్", "వాట్సాప్", "కెమెరా", "గూగుల్ మ్యాప్స్", "ఫేస్‌బుక్", "రేడియో", "టార్చ్"],
    "kn": ["ಯೂಟ್ಯೂಬ್", "ವಾಟ್ಸಾಪ್", "ಕ್ಯಾಮೆರಾ", "ಗೂಗಲ್ ಮ್ಯಾಪ್ಸ್", "ಫೇಸ್‌ಬುಕ್", "ರೇಡಿಯೋ", "ಟಾರ್ಚ್"],
})

# Body parts and symptoms. Health questions are out of scope on purpose:
# the assistant has no medical skill, and guessing one is the worst case.
AILMENTS = {
    "en": ["a headache", "a fever", "a stomach ache", "a cough", "back pain", "a toothache",
           "knee pain", "a cold", "chest pain", "a sore throat"],
    "ta": ["தலைவலி", "காய்ச்சல்", "வயிற்று வலி", "இருமல்", "முதுகு வலி", "பல் வலி", "மூட்டு வலி", "சளி"],
    "hi": ["सिर दर्द", "बुखार", "पेट दर्द", "खाँसी", "कमर दर्द", "दाँत दर्द", "घुटने में दर्द", "ज़ुकाम"],
    "te": ["తలనొప్పి", "జ్వరం", "కడుపు నొప్పి", "దగ్గు", "నడుము నొప్పి", "పంటి నొప్పి", "మోకాలి నొప్పి", "జలుబు"],
    "kn": ["ತಲೆನೋವು", "ಜ್ವರ", "ಹೊಟ್ಟೆ ನೋವು", "ಕೆಮ್ಮು", "ಬೆನ್ನು ನೋವು", "ಹಲ್ಲು ನೋವು", "ಮೊಣಕಾಲು ನೋವು", "ನೆಗಡಿ"],
    "ta-en": ["thalai vali", "kaichal", "vayiru vali", "irumal", "mudhugu vali", "pal vali", "sali"],
    "hi-en": ["sir dard", "bukhar", "pet dard", "khansi", "kamar dard", "daant dard", "zukaam"],
    "te-en": ["tala noppi", "jwaram", "kadupu noppi", "daggu", "nadumu noppi", "panti noppi", "jalubu"],
    "kn-en": ["tale novu", "jwara", "hotte novu", "kemmu", "bennu novu", "hallu novu", "negadi"],
}

OPS = ["plus", "minus", "times", "+", "-", "*", "divided by"]
UNIT_PAIRS = [("km", "miles"), ("miles", "km"), ("kg", "pounds"), ("pounds", "kg"),
              ("celsius", "fahrenheit"), ("fahrenheit", "celsius"), ("cm", "inches"),
              ("feet", "meters"), ("grams", "kg"), ("meters", "feet")]

# ---------------------------------------------------------------------------
# Templates: intent -> language key -> sentence patterns
# ---------------------------------------------------------------------------
# Slots: {place} {crop} {task} {when} {doc} {word} {target} {a} {b} {op}
# {u1} {u2}. A pattern with no slot is multiplied by the per-language
# openers and closers below instead.

T = {}

T["greeting"] = {
    "en": ["hello", "hi there", "hey", "good morning", "good evening", "good afternoon",
           "hello BharatVoice", "hi, anyone there", "greetings", "hey there, good day"],
    "ta": ["வணக்கம்", "காலை வணக்கம்", "மாலை வணக்கம்", "ஹலோ", "வணக்கம் நண்பா",
           "இனிய காலை வணக்கம்", "வணக்கம் பாரத்வாய்ஸ்", "ஹாய்"],
    "hi": ["नमस्ते", "नमस्कार", "सुप्रभात", "शुभ संध्या", "हैलो", "प्रणाम", "राम राम", "नमस्ते जी"],
    "te": ["నమస్కారం", "నమస్తే", "శుభోదయం", "శుభ సాయంత్రం", "హలో", "నమస్కారం అండి", "హాయ్"],
    "kn": ["ನಮಸ್ಕಾರ", "ನಮಸ್ತೆ", "ಶುಭೋದಯ", "ಶುಭ ಸಂಜೆ", "ಹಲೋ", "ನಮಸ್ಕಾರ ಸರ್", "ಹಾಯ್"],
    "ta-en": ["vanakkam", "vanakkam nanba", "kaalai vanakkam", "hello nga", "hi da",
              "vanakkam, good morning", "hello, vanakkam sir", "hey machan"],
    "hi-en": ["namaste", "namaskar ji", "namaste bhai", "hello ji", "good morning ji",
              "pranam", "ram ram bhai", "hi, namaste"],
    "te-en": ["namaskaram", "namaste andi", "hello andi", "subhodayam", "hi bro, namaskaram",
              "namaskaram sir", "hello garu"],
    "kn-en": ["namaskara", "namaste sir", "hello guru", "shubhodaya", "hi, namaskara",
              "namaskara saar", "hello anna"],
}

T["goodbye"] = {
    "en": ["bye", "goodbye", "see you later", "good night", "talk to you later", "that's all, bye",
           "see you tomorrow", "I'm leaving now, bye", "catch you later", "take care, bye"],
    "ta": ["போய் வருகிறேன்", "பை", "மீண்டும் சந்திப்போம்", "இரவு வணக்கம்", "பிறகு பேசலாம்",
           "நான் கிளம்புகிறேன்", "சரி, போய் வர்றேன்", "நாளை பார்க்கலாம்"],
    "hi": ["अलविदा", "फिर मिलेंगे", "शुभ रात्रि", "बाद में बात करते हैं", "चलता हूँ",
           "ठीक है, बाय", "कल मिलते हैं", "टाटा"],
    "te": ["వీడ్కోలు", "మళ్ళీ కలుద్దాం", "శుభ రాత్రి", "తర్వాత మాట్లాడదాం", "నేను వెళ్తున్నాను",
           "సరే, బై", "రేపు కలుద్దాం"],
    "kn": ["ವಿದಾಯ", "ಮತ್ತೆ ಸಿಗೋಣ", "ಶುಭ ರಾತ್ರಿ", "ಆಮೇಲೆ ಮಾತಾಡೋಣ", "ನಾನು ಹೊರಡುತ್ತೇನೆ",
           "ಸರಿ, ಬೈ", "ನಾಳೆ ಸಿಗೋಣ"],
    "ta-en": ["poitu varen", "bye da", "apram pesalam", "good night, poitu varen", "seri, bye",
              "naalaiku paakalam", "kelambaren, bye", "ok bye nga"],
    "hi-en": ["chalta hoon, bye", "phir milenge", "good night ji", "baad mein baat karte hain",
              "theek hai, bye", "kal milte hain", "alvida dost", "tata bye"],
    "te-en": ["velthunna, bye", "malli kaluddam", "good night andi", "tarvata matladukundam",
              "sare, bye", "repu kaluddam", "untanu mari"],
    "kn-en": ["hogi barthini", "matte sigona", "good night guru", "amele matadona",
              "sari, bye", "naale sigona", "barthini saar"],
}

T["thanks"] = {
    "en": ["thanks", "thank you", "thanks a lot", "thank you so much", "that helped, thanks",
           "much appreciated", "thanks for the help", "great, thank you", "many thanks", "thanks buddy"],
    "ta": ["நன்றி", "மிக்க நன்றி", "ரொம்ப நன்றி", "உதவிக்கு நன்றி", "நன்றி நண்பா",
           "சரி, நன்றி", "மிகவும் உதவியாக இருந்தது, நன்றி"],
    "hi": ["धन्यवाद", "शुक्रिया", "बहुत धन्यवाद", "मदद के लिए शुक्रिया", "आपका बहुत आभार",
           "ठीक है, धन्यवाद", "थैंक यू"],
    "te": ["ధన్యవాదాలు", "చాలా ధన్యవాదాలు", "సహాయానికి ధన్యవాదాలు", "థాంక్స్", "కృతజ్ఞతలు",
           "సరే, ధన్యవాదాలు"],
    "kn": ["ಧನ್ಯವಾದ", "ತುಂಬಾ ಧನ್ಯವಾದಗಳು", "ಸಹಾಯಕ್ಕೆ ಧನ್ಯವಾದ", "ಥ್ಯಾಂಕ್ಸ್", "ವಂದನೆಗಳು",
           "ಸರಿ, ಧನ್ಯವಾದ"],
    "ta-en": ["nandri", "romba nandri", "thanks nga", "romba thanks da", "help ku nandri",
              "super, nandri", "seri, thanks", "nandri nanba"],
    "hi-en": ["dhanyavad", "shukriya", "bahut shukriya", "thank you ji", "madad ke liye shukriya",
              "bahut dhanyavad bhai", "theek hai, thanks"],
    "te-en": ["dhanyavadalu", "chala thanks", "thanks andi", "help chesinanduku thanks",
              "chala dhanyavadalu", "sare, thanks"],
    "kn-en": ["dhanyavada", "tumba thanks", "thanks guru", "help madiddakke thanks",
              "tumba dhanyavadagalu", "sari, thanks"],
}

T["how_are_you"] = {
    "en": ["how are you", "how are you doing", "how's it going", "are you doing well",
           "how have you been", "how are you today", "hope you are fine", "what's up"],
    "ta": ["எப்படி இருக்கீங்க", "நீங்கள் எப்படி இருக்கிறீர்கள்", "நலமா", "சௌக்கியமா",
           "எப்படி இருக்க", "நல்லா இருக்கீங்களா"],
    "hi": ["आप कैसे हैं", "कैसे हो", "क्या हाल है", "सब ठीक है", "कैसी हो", "आपका क्या हाल है"],
    "te": ["మీరు ఎలా ఉన్నారు", "ఎలా ఉన్నావు", "బాగున్నారా", "క్షేమమా", "అంతా బాగుందా"],
    "kn": ["ನೀವು ಹೇಗಿದ್ದೀರಿ", "ಹೇಗಿದ್ದೀಯ", "ಚೆನ್ನಾಗಿದ್ದೀರಾ", "ಕ್ಷೇಮವೇ", "ಎಲ್ಲಾ ಚೆನ್ನಾಗಿದೆಯಾ"],
    "ta-en": ["epdi irukeenga", "eppadi irukka", "nalla irukeengala", "sowkiyama",
              "epdi iruka da", "enna, nalama"],
    "hi-en": ["aap kaise hain", "kaise ho", "kya haal hai", "sab theek hai kya",
              "kaisi ho", "aur batao, kaise ho"],
    "te-en": ["meeru ela unnaru", "ela unnav", "bagunnara", "antha bagundha", "kshemama"],
    "kn-en": ["neevu hegiddira", "hegiddiya", "chennagiddira", "ella chennagideya", "kshemana"],
}

T["capabilities"] = {
    "en": ["what can you do", "what are your capabilities", "what all can you help me with",
           "tell me what you can do", "what things do you know", "show me help topics",
           "what are you able to do", "what kind of things can I ask you"],
    "ta": ["உன்னால் என்ன செய்ய முடியும்", "நீ என்ன என்ன செய்வாய்", "என்ன உதவி செய்ய முடியும்",
           "உனக்கு என்ன தெரியும்", "எதெல்லாம் கேட்கலாம்"],
    "hi": ["तुम क्या कर सकते हो", "आप क्या क्या कर सकते हैं", "किस काम में मदद कर सकते हो",
           "तुम्हें क्या आता है", "मैं क्या क्या पूछ सकता हूँ"],
    "te": ["మీరు ఏమి చేయగలరు", "నువ్వు ఏం ఏం చేస్తావు", "ఏ సహాయం చేయగలరు",
           "నీకు ఏం తెలుసు", "ఏమేమి అడగవచ్చు"],
    "kn": ["ನೀವು ಏನು ಮಾಡಬಹುದು", "ನೀನು ಏನೇನು ಮಾಡುತ್ತೀಯ", "ಯಾವ ಸಹಾಯ ಮಾಡಬಹುದು",
           "ನಿನಗೆ ಏನು ಗೊತ್ತು", "ಏನೇನು ಕೇಳಬಹುದು"],
    "ta-en": ["unnala enna panna mudiyum", "nee enna ellam pannuva", "enna help panna mudiyum",
              "unaku enna theriyum", "enna ellam kekalam"],
    "hi-en": ["tum kya kar sakte ho", "aap kya kya kar sakte hain", "kis kaam mein help karoge",
              "tumhe kya aata hai", "main kya kya pooch sakta hoon"],
    "te-en": ["meeru emi cheyagalaru", "nuvvu em em chestav", "e help cheyagalaru",
              "neeku em telusu", "emi adagochu"],
    "kn-en": ["neevu enu madabahudu", "neenu enenu madtiya", "yava help madabahudu",
              "ninage enu gottu", "enenu kelabahudu"],
}

T["list_reminders"] = {
    "en": ["show my reminders", "list my reminders", "what reminders do I have",
           "do I have any reminders", "what did I ask you to remind me about",
           "read out my reminders", "which reminders are pending", "my reminders please"],
    "ta": ["என் நினைவூட்டல்கள் காட்டு", "என் நினைவூட்டல்கள் என்ன", "நினைவூட்டல்களை காட்டு",
           "எனக்கு என்ன நினைவூட்டல்கள் உள்ளன", "நிலுவையில் உள்ள நினைவூட்டல்கள்"],
    "hi": ["मेरे रिमाइंडर दिखाओ", "मेरे रिमाइंडर क्या हैं", "रिमाइंडर दिखाइए",
           "मेरे कौन से रिमाइंडर बाकी हैं", "मैंने क्या याद दिलाने को कहा था"],
    "te": ["నా రిమైండర్లు చూపించు", "నా రిమైండర్లు ఏమిటి", "నా రిమైండర్ల జాబితా",
           "ఏ రిమైండర్లు మిగిలి ఉన్నాయి", "నేను ఏమి గుర్తు చేయమన్నాను"],
    "kn": ["ನನ್ನ ಜ್ಞಾಪನೆಗಳನ್ನು ತೋರಿಸು", "ನನ್ನ ಜ್ಞಾಪನೆಗಳು ಯಾವುವು", "ನನ್ನ ಜ್ಞಾಪನೆ ಪಟ್ಟಿ",
           "ಯಾವ ಜ್ಞಾಪನೆಗಳು ಬಾಕಿ ಇವೆ", "ನಾನು ಏನು ನೆನಪಿಸಲು ಹೇಳಿದ್ದೆ"],
    "ta-en": ["en reminders kaatu", "enaku enna reminders irukku", "reminders list kaatunga",
              "pending reminders enna", "naan enna reminder vechen"],
    "hi-en": ["mere reminders dikhao", "mere reminders kya hain", "reminder list batao",
              "kaun se reminders pending hain", "maine kya yaad dilane ko kaha tha"],
    "te-en": ["na reminders chupinchu", "na reminders enti", "reminders list cheppu",
              "e reminders pending unnayi", "nenu em gurthu cheyamannanu"],
    "kn-en": ["nanna reminders torisu", "nanna reminders yavuvu", "reminders list heli",
              "yava reminders pending ide", "nanu enu nenapisoke helidde"],
}

T["set_reminder"] = {
    "en": ["remind me to {task} {when}", "set a reminder to {task} {when}",
           "{when}, remind me to {task}", "don't let me forget to {task} {when}",
           "please set an alarm {when} to {task}", "I need a reminder {when} to {task}"],
    "ta": ["{when} {task} நினைவூட்டு", "{task} {when} நினைவூட்டுங்கள்",
           "{when} {task} மறக்காமல் நினைவூட்டு", "{task} என்று {when} நினைவூட்டல் வை"],
    "hi": ["{when} मुझे {task} याद दिलाना", "{when} {task} है, याद दिला देना",
           "मुझे {when} {task} का रिमाइंडर लगा दो", "{task} है, {when} याद दिलाइए"],
    "te": ["{when} {task} గుర్తు చేయండి", "{task} {when} రిమైండర్ పెట్టు",
           "{when} నాకు {task} గుర్తు చేయి", "{task} మర్చిపోకుండా {when} గుర్తు చేయండి"],
    "kn": ["{when} {task} ನೆನಪಿಸಿ", "{task} {when} ಜ್ಞಾಪನೆ ಇಡು",
           "{when} ನನಗೆ {task} ನೆನಪಿಸು", "{task} ಮರೆಯದಂತೆ {when} ನೆನಪಿಸಿ"],
    "ta-en": ["{when} {task} reminder vai", "{task} nu {when} nyabagam paduthu",
              "{when} enaku {task} remind pannu", "{task} marakkama {when} sollu"],
    "hi-en": ["{when} mujhe {task} yaad dilana", "{when} {task} hai, reminder laga do",
              "mujhe {when} {task} remind karna", "{task} hai, {when} yaad dila dena"],
    "te-en": ["{when} {task} gurthu cheyyi", "{when} naaku {task} ani reminder pettu",
              "{task} ani {when} remind cheyyi", "{when} {task} marchipokunda cheppu"],
    "kn-en": ["{when} {task} nenapisu", "{when} nange {task} reminder idu",
              "{task} antha {when} remind madu", "{when} {task} mareyade helu"],
}

T["get_weather"] = {
    "en": ["what is the weather in {place}", "how hot is it in {place} today",
           "will it rain in {place} tomorrow", "{place} weather today", "is it raining in {place}",
           "what's the temperature in {place} right now", "do I need an umbrella in {place}",
           "weather forecast for {place}"],
    "ta": ["{place} வானிலை எப்படி இருக்கிறது", "{place}-ல் இன்று மழை பெய்யுமா",
           "{place} வெப்பநிலை என்ன", "இன்று {place} வானிலை", "{place}-ல் வெயில் அதிகமா"],
    "hi": ["{place} में मौसम कैसा है", "क्या आज {place} में बारिश होगी",
           "{place} का तापमान क्या है", "आज {place} का मौसम", "{place} में कितनी गर्मी है"],
    "te": ["{place} లో వాతావరణం ఎలా ఉంది", "ఈ రోజు {place} లో వర్షం పడుతుందా",
           "{place} ఉష్ణోగ్రత ఎంత", "ఈ రోజు {place} వాతావరణం", "{place} లో ఎండ ఎక్కువగా ఉందా"],
    "kn": ["{place} ನಲ್ಲಿ ಹವಾಮಾನ ಹೇಗಿದೆ", "ಇಂದು {place} ನಲ್ಲಿ ಮಳೆ ಬರುತ್ತದೆಯೇ",
           "{place} ತಾಪಮಾನ ಎಷ್ಟು", "ಇಂದು {place} ಹವಾಮಾನ", "{place} ನಲ್ಲಿ ಬಿಸಿಲು ಜಾಸ್ತಿ ಇದೆಯಾ"],
    "ta-en": ["{place} la weather epdi irukku", "{place} la innaiku mazhai varuma",
              "{place} temperature enna", "innaiku {place} la veyil adhigama",
              "{place} la kudai venuma"],
    "hi-en": ["{place} mein mausam kaisa hai", "aaj {place} mein baarish hogi kya",
              "{place} ka temperature kya hai", "{place} mein kitni garmi hai",
              "{place} mein chhata chahiye kya"],
    "te-en": ["{place} lo weather ela undi", "ee roju {place} lo varsham padutunda",
              "{place} temperature entha", "{place} lo enda ekkuva unda",
              "{place} lo godugu kavala"],
    "kn-en": ["{place} alli weather hegide", "ivattu {place} alli male barutta",
              "{place} temperature eshtu", "{place} alli bisilu jasti ideya",
              "{place} alli chatri beka"],
}

T["get_time"] = {
    "en": ["what time is it", "what is the time now", "tell me the current time",
           "can you tell me the time", "what's the time", "time please", "do you have the time",
           "what is the time right now"],
    "ta": ["மணி என்ன", "இப்போது நேரம் என்ன", "நேரம் என்ன ஆகிறது", "தற்போதைய நேரம் சொல்",
           "இப்ப மணி என்ன ஆச்சு"],
    "hi": ["समय क्या हुआ है", "अभी कितने बजे हैं", "टाइम क्या हो रहा है", "अभी का समय बताओ",
           "कितना बजा है"],
    "te": ["సమయం ఎంత అయింది", "ఇప్పుడు టైమ్ ఎంత", "ఇప్పుడు ఎన్ని గంటలు", "టైమ్ చెప్పు",
           "ప్రస్తుత సమయం ఎంత"],
    "kn": ["ಸಮಯ ಎಷ್ಟು ಆಯಿತು", "ಈಗ ಟೈಮ್ ಎಷ್ಟು", "ಈಗ ಎಷ್ಟು ಗಂಟೆ", "ಟೈಮ್ ಹೇಳಿ",
           "ಈಗಿನ ಸಮಯ ಎಷ್ಟು"],
    "ta-en": ["mani enna", "ippo time enna", "time enna aachu", "ippo mani enna aaguthu",
              "time sollunga"],
    "hi-en": ["time kya hua hai", "abhi kitne baje hain", "time kya ho raha hai",
              "abhi ka time batao", "kitna baja hai"],
    "te-en": ["time entha ayyindi", "ippudu time entha", "ippudu enni gantalu", "time cheppu",
              "ippudu time enti"],
    "kn-en": ["time eshtu aaytu", "eega time eshtu", "eega eshtu gante", "time heli",
              "eega time enu"],
}

T["get_date"] = {
    "en": ["what is today's date", "what's the date today", "what day is it today",
           "which day of the week is it", "tell me today's date", "what date is it",
           "is today Monday or Tuesday", "today's date please"],
    "ta": ["இன்று என்ன தேதி", "இன்றைய தேதி என்ன", "இன்று என்ன கிழமை", "தேதி என்ன",
           "இன்னைக்கு என்ன நாள்"],
    "hi": ["आज क्या तारीख है", "आज की तारीख बताओ", "आज कौन सा दिन है", "तारीख क्या है",
           "आज कौन सा वार है"],
    "te": ["ఈరోజు తేదీ ఎంత", "ఈ రోజు ఏ తారీఖు", "ఈ రోజు ఏ వారం", "తేదీ చెప్పు",
           "ఈ రోజు ఏ రోజు"],
    "kn": ["ಇಂದಿನ ದಿನಾಂಕ ಏನು", "ಇವತ್ತು ಯಾವ ತಾರೀಖು", "ಇಂದು ಯಾವ ವಾರ", "ದಿನಾಂಕ ಹೇಳಿ",
           "ಇವತ್ತು ಯಾವ ದಿನ"],
    "ta-en": ["innaiku enna date", "innaiku enna kizhamai", "date enna", "innaiku enna naal",
              "today date sollunga"],
    "hi-en": ["aaj kya tareekh hai", "aaj ki date batao", "aaj kaun sa din hai",
              "date kya hai aaj", "aaj kaun sa vaar hai"],
    "te-en": ["ee roju date entha", "ee roju e tareekhu", "ee roju e vaaram", "date cheppu",
              "ivala e roju"],
    "kn-en": ["ivattu date enu", "ivattu yava tareeku", "ivattu yava vaara", "date heli",
              "ivattu yava dina"],
}

T["gov_document_help"] = {
    "en": ["how do I apply for a {doc}", "I lost my {doc}, what should I do",
           "how to update the address on my {doc}", "what is a {doc} used for",
           "where do I get a new {doc}", "how can I correct my name on the {doc}",
           "{doc} application process"],
    "ta": ["{doc} எப்படி விண்ணப்பிப்பது", "என் {doc} தொலைந்துவிட்டது, என்ன செய்வது",
           "{doc}-ல் முகவரி மாற்றுவது எப்படி", "புதிய {doc} எங்கே பெறுவது", "{doc} என்றால் என்ன"],
    "hi": ["{doc} के लिए आवेदन कैसे करें", "मेरा {doc} खो गया है, क्या करूँ",
           "{doc} में पता कैसे बदलें", "नया {doc} कहाँ से बनेगा", "{doc} क्या होता है"],
    "te": ["{doc} కోసం ఎలా దరఖాస్తు చేయాలి", "నా {doc} పోయింది, ఏం చేయాలి",
           "{doc} లో చిరునామా ఎలా మార్చాలి", "కొత్త {doc} ఎక్కడ పొందాలి", "{doc} అంటే ఏమిటి"],
    "kn": ["{doc} ಗೆ ಅರ್ಜಿ ಹಾಕುವುದು ಹೇಗೆ", "ನನ್ನ {doc} ಕಳೆದುಹೋಗಿದೆ, ಏನು ಮಾಡಬೇಕು",
           "{doc} ನಲ್ಲಿ ವಿಳಾಸ ಬದಲಿಸುವುದು ಹೇಗೆ", "ಹೊಸ {doc} ಎಲ್ಲಿ ಸಿಗುತ್ತದೆ", "{doc} ಎಂದರೇನು"],
    "ta-en": ["{doc} epdi apply panradhu", "en {doc} tholanju pochu, enna panradhu",
              "{doc} la address epdi maathradhu", "pudhu {doc} enga vaangradhu",
              "{doc} ku enna documents venum"],
    "hi-en": ["{doc} ke liye apply kaise karein", "mera {doc} kho gaya, kya karoon",
              "{doc} mein address kaise change karein", "naya {doc} kahan se banega",
              "{doc} ke liye kya documents chahiye"],
    "te-en": ["{doc} ki ela apply cheyali", "na {doc} poyindi, em cheyali",
              "{doc} lo address ela marchali", "kotha {doc} ekkada teesukovali",
              "{doc} ki e documents kavali"],
    "kn-en": ["{doc} ge hege apply madodu", "nanna {doc} kaledu hogide, enu madbeku",
              "{doc} alli address hege change madodu", "hosa {doc} elli sigutte",
              "{doc} ge yava documents beku"],
}

T["mandi_price"] = {
    "en": ["{crop} mandi price today", "what is the market price of {crop}",
           "{crop} rate in the mandi", "how much is {crop} selling for in the market today",
           "today's mandi rate for {crop}", "wholesale price of {crop} in {place} mandi"],
    "ta": ["{crop} சந்தை விலை என்ன", "இன்று {crop} மண்டி விலை", "{crop} சந்தை விலை இன்று எவ்வளவு",
           "{place} மண்டியில் {crop} விலை"],
    "hi": ["{crop} का मंडी भाव क्या है", "आज {crop} का बाज़ार भाव", "मंडी में {crop} का भाव बताओ",
           "{place} मंडी में {crop} का भाव"],
    "te": ["{crop} మార్కెట్ ధర ఎంత", "ఈ రోజు {crop} మార్కెట్ రేటు", "మండీలో {crop} ధర చెప్పండి",
           "{place} మార్కెట్ లో {crop} మార్కెట్ ధర"],
    "kn": ["{crop} ಮಾರುಕಟ್ಟೆ ದರ ಎಷ್ಟು", "ಇಂದು {crop} ಮಾರುಕಟ್ಟೆ ಬೆಲೆ", "ಮಂಡಿಯಲ್ಲಿ {crop} ದರ ಹೇಳಿ",
           "{place} ಮಾರುಕಟ್ಟೆಯಲ್ಲಿ {crop} ಮಾರುಕಟ್ಟೆ ದರ"],
    "ta-en": ["{crop} mandi price enna", "innaiku {crop} market rate evlo",
              "mandi la {crop} vilai sollunga", "{place} market la {crop} rate enna"],
    "hi-en": ["{crop} ka mandi bhav kya hai", "aaj {crop} ka market rate kitna hai",
              "mandi mein {crop} ka bhav batao", "{place} mandi mein {crop} ka rate"],
    "te-en": ["{crop} mandi price entha", "ee roju {crop} market rate entha",
              "mandi lo {crop} dhara cheppu", "{place} market lo {crop} rate enti"],
    "kn-en": ["{crop} mandi price eshtu", "ivattu {crop} market rate eshtu",
              "mandi alli {crop} dara heli", "{place} market alli {crop} rate enu"],
}

T["translate_request"] = {
    "en": ["translate '{word}' to {target}", "how do you say '{word}' in {target}",
           "what is the meaning of '{word}' in {target}", "say '{word}' in {target}",
           "what is '{word}' called in {target}"],
    "ta": ["'{word}' {target} மொழிபெயர்", "'{word}' {target} எப்படி சொல்வது",
           "'{word}' {target} என்ன என்று சொல்வது"],
    "hi": ["'{word}' का {target} अनुवाद करो", "'{word}' को {target} कैसे कहते हैं",
           "'{word}' {target} क्या कहलाता है"],
    "te": ["'{word}' ని {target} అనువాదం చేయి", "'{word}' ని {target} ఎలా చెప్పాలి",
           "'{word}' {target} ఏమంటారు"],
    "kn": ["'{word}' ಅನ್ನು {target} ಅನುವಾದ ಮಾಡಿ", "'{word}' ಅನ್ನು {target} ಹೇಗೆ ಹೇಳುವುದು",
           "'{word}' ಗೆ {target} ಏನಂತಾರೆ"],
    "ta-en": ["'{word}' ah {target} translate pannu", "'{word}' {target} epdi solradhu",
              "'{word}' ku {target} enna"],
    "hi-en": ["'{word}' ko {target} translate karo", "'{word}' ko {target} kaise kehte hain",
              "'{word}' ka {target} kya matlab hai"],
    "te-en": ["'{word}' ni {target} translate cheyyi", "'{word}' ni {target} ela cheppali",
              "'{word}' ki {target} emantaru"],
    "kn-en": ["'{word}' na {target} translate madu", "'{word}' na {target} hege helodu",
              "'{word}' ge {target} enantare"],
}

# The calculator and converter only parse English operators and unit names
# (services/skills.py), so every language keeps the expression itself in
# that form and varies the words around it — which is also how people type.
T["calculate"] = {
    "en": ["what is {a} {op} {b}", "calculate {a} {op} {b}", "{a} {op} {b}",
           "how much is {a} {op} {b}", "{a} percent of {b}", "what is {a} percent of {b}"],
    "ta": ["{a} {op} {b} எவ்வளவு", "{a} {op} {b} கணக்கிடு", "{a} percent of {b} எவ்வளவு"],
    "hi": ["{a} {op} {b} कितना होता है", "{a} {op} {b} का हिसाब लगाओ", "{a} percent of {b} कितना है"],
    "te": ["{a} {op} {b} ఎంత", "{a} {op} {b} లెక్క చేయి", "{a} percent of {b} ఎంత"],
    "kn": ["{a} {op} {b} ಎಷ್ಟು", "{a} {op} {b} ಲೆಕ್ಕ ಮಾಡಿ", "{a} percent of {b} ಎಷ್ಟು"],
    "ta-en": ["{a} {op} {b} evlo", "{a} {op} {b} calculate pannu", "{a} percent of {b} evlo varum"],
    "hi-en": ["{a} {op} {b} kitna hota hai", "{a} {op} {b} calculate karo", "{a} percent of {b} kitna hai"],
    "te-en": ["{a} {op} {b} entha", "{a} {op} {b} calculate cheyyi", "{a} percent of {b} entha"],
    "kn-en": ["{a} {op} {b} eshtu", "{a} {op} {b} calculate madu", "{a} percent of {b} eshtu"],
}

T["convert_unit"] = {
    "en": ["convert {a} {u1} to {u2}", "{a} {u1} to {u2}", "how many {u2} is {a} {u1}",
           "{a} {u1} in {u2}", "what is {a} {u1} in {u2}"],
    "ta": ["{a} {u1} to {u2} மாற்று", "{a} {u1} in {u2} எவ்வளவு"],
    "hi": ["{a} {u1} to {u2} बदलो", "{a} {u1} in {u2} कितना होता है"],
    "te": ["{a} {u1} to {u2} మార్చు", "{a} {u1} in {u2} ఎంత"],
    "kn": ["{a} {u1} to {u2} ಬದಲಿಸಿ", "{a} {u1} in {u2} ಎಷ್ಟು"],
    "ta-en": ["{a} {u1} to {u2} convert pannu", "{a} {u1} in {u2} evlo"],
    "hi-en": ["{a} {u1} to {u2} convert karo", "{a} {u1} in {u2} kitna hota hai"],
    "te-en": ["{a} {u1} to {u2} convert cheyyi", "{a} {u1} in {u2} entha"],
    "kn-en": ["{a} {u1} to {u2} convert madu", "{a} {u1} in {u2} eshtu"],
}

T["emergency_help"] = {
    "en": ["emergency numbers", "I need an ambulance", "what is the police helpline",
           "this is an emergency, who do I call", "fire brigade number", "women's helpline number",
           "I need urgent help", "child helpline please", "there has been an accident, ambulance number"],
    "ta": ["அவசர எண்கள்", "ஆம்புலன்ஸ் வேண்டும்", "காவல் எண் என்ன", "அவசர உதவி தேவை",
           "தீயணைப்பு அவசர எண்", "பெண்கள் அவசர உதவி எண்"],
    "hi": ["आपातकाल नंबर", "मुझे एम्बुलेंस चाहिए", "पुलिस नंबर क्या है", "आपातकाल में किसे फ़ोन करूँ",
           "फायर ब्रिगेड का आपातकाल नंबर", "महिला हेल्पलाइन आपातकाल नंबर"],
    "te": ["అత్యవసర నంబర్లు", "నాకు అంబులెన్స్ కావాలి", "అత్యవసర పోలీస్ నంబర్ ఏమిటి",
           "అత్యవసర సహాయం కావాలి", "అగ్నిమాపక అత్యవసర నంబర్"],
    "kn": ["ತುರ್ತು ಸಂಖ್ಯೆಗಳು", "ನನಗೆ ಆಂಬ್ಯುಲೆನ್ಸ್ ಬೇಕು", "ತುರ್ತು ಪೊಲೀಸ್ ಸಂಖ್ಯೆ ಏನು",
           "ತುರ್ತು ಸಹಾಯ ಬೇಕು", "ಅಗ್ನಿಶಾಮಕ ತುರ್ತು ಸಂಖ್ಯೆ"],
    "ta-en": ["emergency number sollunga", "ambulance venum", "police helpline number enna",
              "emergency, yaaruku call pannanum", "fire brigade number enna"],
    "hi-en": ["emergency number batao", "ambulance chahiye", "police helpline number kya hai",
              "emergency hai, kisko call karoon", "fire brigade ka number"],
    "te-en": ["emergency number cheppu", "ambulance kavali", "police helpline number enti",
              "emergency, evariki call cheyali", "fire brigade number enti"],
    "kn-en": ["emergency number heli", "ambulance beku", "police helpline number enu",
              "emergency, yarige call madbeku", "fire brigade number enu"],
}

T["about_app"] = {
    "en": ["what is BharatVoice", "who are you", "which languages do you support",
           "do you work offline", "what happens to my data", "where do you get your information",
           "how do you detect my language", "why should I use this instead of ChatGPT",
           "is it private", "can you call an ambulance for me", "how many languages can you speak",
           "does this app work without internet"],
    "ta": ["பாரத்வாய்ஸ் என்றால் என்ன", "நீ யார்", "எந்த மொழிகள் தெரியும்",
           "இணையம் இல்லாமல் வேலை செய்யுமா", "என் தகவல் பாதுகாப்பானதா",
           "தகவல் எங்கிருந்து வருகிறது", "என் மொழியை எப்படி கண்டுபிடிக்கிறாய்"],
    "hi": ["भारतवॉइस क्या है", "तुम कौन हो", "कौन सी भाषाएँ आती हैं",
           "क्या यह बिना इंटरनेट के चलता है", "मेरे डेटा का क्या होता है",
           "जानकारी कहाँ से आती है", "मेरी भाषा कैसे पहचानते हो"],
    "te": ["భారత్‌వాయిస్ అంటే ఏమిటి", "నువ్వు ఎవరు", "ఏ భాషలు వస్తాయి",
           "ఇంటర్నెట్ లేకుండా పని చేస్తుందా", "నా డేటా ఏమవుతుంది",
           "సమాచారం ఎక్కడి నుండి వస్తుంది", "నా భాషను ఎలా గుర్తిస్తావు"],
    "kn": ["ಭಾರತ್‌ವಾಯ್ಸ್ ಎಂದರೇನು", "ನೀನು ಯಾರು", "ಯಾವ ಭಾಷೆಗಳು ಬರುತ್ತವೆ",
           "ಇಂಟರ್ನೆಟ್ ಇಲ್ಲದೆ ಕೆಲಸ ಮಾಡುತ್ತದೆಯೇ", "ನನ್ನ ಡೇಟಾ ಏನಾಗುತ್ತದೆ",
           "ಮಾಹಿತಿ ಎಲ್ಲಿಂದ ಬರುತ್ತದೆ", "ನನ್ನ ಭಾಷೆಯನ್ನು ಹೇಗೆ ಗುರುತಿಸುತ್ತೀಯ"],
    "ta-en": ["BharatVoice na enna", "nee yaaru", "enna languages theriyum",
              "internet illama work aaguma", "en data safe ah", "information enga irundhu varudhu"],
    "hi-en": ["BharatVoice kya hai", "tum kaun ho", "kaun si languages aati hain",
              "bina internet ke chalta hai kya", "mere data ka kya hota hai",
              "information kahan se aati hai"],
    "te-en": ["BharatVoice ante enti", "nuvvu evaru", "e languages vastayi",
              "internet lekunda pani chestunda", "na data em avutundi",
              "information ekkada nundi vastundi"],
    "kn-en": ["BharatVoice andre enu", "neenu yaru", "yava languages barutte",
              "internet illade kelasa madutta", "nanna data enagutte",
              "information ellinda barutte"],
}

T["knowledge_help"] = {
    "en": ["how do I apply for a scholarship", "how to open a bank account", "someone asked for my OTP",
           "I lost money in an online fraud", "how do I book a train ticket", "how to check PNR status",
           "what government schemes can I get", "how to register for PM Kisan",
           "how do I get an Ayushman card", "hospitals in {place}", "nearest hospital",
           "how to find a government job", "is this work from home offer a fake job",
           "I got a police video call saying digital arrest", "how to complain against my bank",
           "how to book a bus ticket to {place}", "is UPI safe to use", "school admission under RTE",
           "where can I get free study material"],
    "ta": ["உதவித்தொகை எப்படி பெறுவது", "வங்கி கணக்கு தொடங்க என்ன செய்ய வேண்டும்",
           "யாரோ என் ஓடிபி கேட்டார்கள்", "ரயில் டிக்கெட் எப்படி முன்பதிவு செய்வது",
           "அரசு மருத்துவமனை எங்கே", "பிஎம் கிசான் பதிவு எப்படி", "வேலை மோசடி பற்றி சொல்",
           "பள்ளி சேர்க்கை எப்படி", "ஆயுஷ்மான் அட்டை எப்படி பெறுவது", "வங்கி புகார் எங்கே கொடுப்பது"],
    "hi": ["छात्रवृत्ति कैसे मिलेगी", "बैंक खाता कैसे खोलें", "किसी ने मेरा ओटीपी माँगा",
           "ट्रेन टिकट कैसे बुक करें", "सरकारी अस्पताल कहाँ है", "पीएम किसान में पंजीकरण कैसे करें",
           "नौकरी घोटाला क्या होता है", "स्कूल में दाखिला कैसे होगा", "आयुष्मान कार्ड कैसे बनेगा",
           "बैंक की शिकायत कहाँ करें", "डिजिटल अरेस्ट क्या है"],
    "te": ["స్కాలర్‌షిప్ ఎలా పొందాలి", "బ్యాంకు ఖాతా ఎలా తెరవాలి", "ఎవరో నా ఓటీపీ అడిగారు",
           "రైలు టికెట్ ఎలా బుక్ చేయాలి", "ప్రభుత్వ ఆసుపత్రి ఎక్కడ ఉంది",
           "పీఎం కిసాన్ కు ఎలా నమోదు చేయాలి", "ఆయుష్మాన్ కార్డు ఎలా పొందాలి",
           "ప్రభుత్వ ఉద్యోగం ఎలా వెతకాలి"],
    "kn": ["ವಿದ್ಯಾರ್ಥಿವೇತನ ಹೇಗೆ ಪಡೆಯುವುದು", "ಬ್ಯಾಂಕ್ ಖಾತೆ ಹೇಗೆ ತೆರೆಯುವುದು", "ಯಾರೋ ನನ್ನ ಒಟಿಪಿ ಕೇಳಿದರು",
           "ರೈಲು ಟಿಕೆಟ್ ಹೇಗೆ ಬುಕ್ ಮಾಡುವುದು", "ಸರ್ಕಾರಿ ಆಸ್ಪತ್ರೆ ಎಲ್ಲಿದೆ",
           "ಪಿಎಂ ಕಿಸಾನ್ ಗೆ ಹೇಗೆ ನೋಂದಾಯಿಸುವುದು", "ಆಯುಷ್ಮಾನ್ ಕಾರ್ಡ್ ಹೇಗೆ ಪಡೆಯುವುದು",
           "ಸರ್ಕಾರಿ ಕೆಲಸ ಹೇಗೆ ಹುಡುಕುವುದು"],
    "ta-en": ["scholarship epdi apply panradhu", "bank account open panna enna venum",
              "yaaro en OTP kettanga", "train ticket epdi book panradhu", "government hospital enga irukku",
              "PM Kisan ku epdi register panradhu", "idhu fake job ah", "UPI fraud aana enna panradhu",
              "government scheme enna irukku", "bus ticket epdi book panradhu"],
    "hi-en": ["scholarship kaise milegi", "bank account kaise kholein", "kisi ne mera OTP maanga",
              "train ticket kaise book karein", "government hospital kahan hai",
              "PM Kisan mein register kaise karein", "yeh fake job hai kya", "UPI fraud ho gaya, kya karoon",
              "sarkari yojana kaun si hai", "sarkari naukri kaise dhundein"],
    "te-en": ["scholarship ela apply cheyali", "bank account ela open cheyali", "evaro na OTP adigaru",
              "train ticket ela book cheyali", "government hospital ekkada undi",
              "PM Kisan ki ela register cheyali", "idi fake job aa", "government scheme enti undi",
              "government job ela vethakali"],
    "kn-en": ["scholarship hege apply madodu", "bank account hege open madodu", "yaaro nanna OTP kelidru",
              "train ticket hege book madodu", "government hospital elli ide",
              "PM Kisan ge hege register madodu", "idu fake job aa", "government scheme yavudu ide",
              "government job hege hudukodu"],
}

# "Everything else": what the assistant has no skill for. This class is the
# model's most important one to get right, because a miss here is not a
# shrug — it is a confident wrong answer. The first checkpoint trained on a
# smaller version of this list answered "sugar level 180, is it normal"
# with crop prices and "speak in Tamil" with a translation prompt.
#
# So besides trivia and chit-chat it deliberately holds near-misses: prices
# of things that are not crops, requests to speak a language (not translate
# into it), commands for the phone, health and money questions.
T["general_query"] = {
    "en": [
        "tell me a joke", "tell me a story", "sing a song for me", "give me a riddle", "I am bored",
        "who is the chief minister of {state}", "what is the capital of {state}",
        "how big is {state}", "which party rules {state}", "who is the prime minister of India",
        "what is the price of {thing}", "how much does {thing} cost today", "{thing} rate today",
        "where can I buy {thing} cheaply", "is {thing} getting costlier",
        "open {app}", "can you open {app}", "close {app}", "turn on {app}",
        "play some music", "play a devotional song", "call my brother", "send a message to my wife",
        "take a photo", "increase the volume", "book a cab to {place}", "order food for me",
        "I have {ailment}, what should I do", "what medicine should I take for {ailment}",
        "is {ailment} serious", "my child has {ailment}", "my sugar level is {a}, is it normal",
        "my blood pressure is {a} over {b}",
        "speak in Tamil", "can you talk in Hindi", "reply to me in Telugu", "do you speak Kannada",
        "talk to me in English only", "change the language to Tamil",
        "what are you doing", "what are you doing now", "are you a robot", "do you have a family",
        "I am tired", "I am hungry", "I feel sad today", "I can't sleep", "nobody listens to me",
        "I need a loan", "how do I get a home loan", "how to save money", "how do I file income tax",
        "which is the best college in {place}", "when will the exam results come",
        "how far is {place} from here", "what is the bus fare to {place}", "is {place} a good city",
        "who won the cricket match yesterday", "what is the cricket score", "recommend a good movie",
        "how do aeroplanes fly", "what is photosynthesis", "why is the sea salty",
        "how do I learn English fast", "what should I cook for dinner", "how to make dosa",
        "when is Pongal this year", "how many days are there in February",
    ],
    "ta": [
        "ஒரு நகைச்சுவை சொல்", "ஒரு கதை சொல்லு", "ஒரு பாட்டு பாடு", "எனக்கு போர் அடிக்கிறது",
        "{state} முதலமைச்சர் யார்", "{state} தலைநகரம் எது", "இந்தியாவின் பிரதமர் யார்",
        "{thing} விலை என்ன", "இன்று {thing} விலை எவ்வளவு", "{thing} எங்கே மலிவாக கிடைக்கும்",
        "{app} திற", "{app} ஓபன் பண்ணு", "ஒரு பாட்டு போடு", "என் அண்ணனுக்கு போன் பண்ணு",
        "ஒரு போட்டோ எடு", "சத்தத்தை அதிகமாக்கு", "{place} போக கார் புக் பண்ணு",
        "எனக்கு {ailment} இருக்கிறது, என்ன செய்வது", "{ailment}-க்கு என்ன மருந்து", "என் குழந்தைக்கு {ailment}",
        "தமிழில் பேசு", "இந்தியில் பேச முடியுமா", "தெலுங்கில் பதில் சொல்",
        "என்ன பண்ற", "நீ என்ன செய்கிறாய்", "நீ ரோபோவா", "எனக்கு சோர்வாக இருக்கிறது", "எனக்கு பசிக்கிறது",
        "எனக்கு கடன் வேண்டும்", "பணம் எப்படி சேமிப்பது", "தேர்வு முடிவுகள் எப்போது வரும்",
        "{place} இங்கிருந்து எவ்வளவு தூரம்", "{place} போக பஸ் கட்டணம் எவ்வளவு",
        "நேற்று கிரிக்கெட்டில் யார் வென்றார்கள்", "நல்ல படம் ஒன்று சொல்", "இன்று என்ன சமைக்கலாம்",
        "விமானம் எப்படி பறக்கிறது", "இந்த வருடம் பொங்கல் எப்போது",
    ],
    "hi": [
        "एक चुटकुला सुनाओ", "एक कहानी सुनाओ", "एक गाना गाओ", "मुझे बोर हो रहा है",
        "{state} के मुख्यमंत्री कौन हैं", "{state} की राजधानी क्या है", "भारत के प्रधानमंत्री कौन हैं",
        "{thing} का दाम क्या है", "आज {thing} कितने का है", "{thing} सस्ता कहाँ मिलेगा",
        "{app} खोलो", "{app} चालू करो", "कोई गाना बजाओ", "मेरे भाई को फ़ोन लगाओ",
        "एक फ़ोटो खींचो", "आवाज़ तेज़ करो", "{place} के लिए कैब बुक करो",
        "मुझे {ailment} है, क्या करूँ", "{ailment} की कौन सी दवा लूँ", "मेरे बच्चे को {ailment} है",
        "हिंदी में बोलो", "क्या तुम तमिल में बात कर सकते हो", "तेलुगु में जवाब दो",
        "क्या कर रहे हो", "तुम अभी क्या कर रहे हो", "क्या तुम रोबोट हो", "मैं थक गया हूँ", "मुझे भूख लगी है",
        "मुझे लोन चाहिए", "पैसे कैसे बचाएँ", "परीक्षा का रिज़ल्ट कब आएगा",
        "{place} यहाँ से कितनी दूर है", "{place} का बस किराया कितना है",
        "कल क्रिकेट मैच कौन जीता", "कोई अच्छी फ़िल्म बताओ", "आज खाने में क्या बनाऊँ",
        "हवाई जहाज़ कैसे उड़ता है", "इस साल दिवाली कब है",
    ],
    "te": [
        "ఒక జోక్ చెప్పు", "ఒక కథ చెప్పు", "ఒక పాట పాడు", "నాకు బోర్ కొడుతోంది",
        "{state} ముఖ్యమంత్రి ఎవరు", "{state} రాజధాని ఏది", "భారత ప్రధాని ఎవరు",
        "{thing} ధర ఎంత", "ఈ రోజు {thing} ఎంత", "{thing} చౌకగా ఎక్కడ దొరుకుతుంది",
        "{app} తెరువు", "{app} ఓపెన్ చేయి", "ఒక పాట పెట్టు", "మా అన్నకు ఫోన్ చేయి",
        "ఒక ఫోటో తీయి", "సౌండ్ పెంచు", "{place} కి క్యాబ్ బుక్ చేయి",
        "నాకు {ailment} ఉంది, ఏం చేయాలి", "{ailment} కి ఏ మందు వేసుకోవాలి", "మా బాబుకు {ailment}",
        "తెలుగులో మాట్లాడు", "హిందీలో మాట్లాడగలవా", "తమిళంలో జవాబు చెప్పు",
        "ఏం చేస్తున్నావు", "నువ్వు ఇప్పుడు ఏం చేస్తున్నావు", "నువ్వు రోబోవా", "నాకు అలసటగా ఉంది", "నాకు ఆకలిగా ఉంది",
        "నాకు లోన్ కావాలి", "డబ్బు ఎలా ఆదా చేయాలి", "పరీక్ష ఫలితాలు ఎప్పుడు వస్తాయి",
        "{place} ఇక్కడి నుండి ఎంత దూరం", "{place} కి బస్ చార్జీ ఎంత",
        "నిన్న క్రికెట్ మ్యాచ్ ఎవరు గెలిచారు", "మంచి సినిమా ఒకటి చెప్పు", "ఈ రోజు ఏం వండాలి",
        "విమానం ఎలా ఎగురుతుంది", "ఈ సంవత్సరం దసరా ఎప్పుడు",
    ],
    "kn": [
        "ಒಂದು ಜೋಕ್ ಹೇಳು", "ಒಂದು ಕಥೆ ಹೇಳು", "ಒಂದು ಹಾಡು ಹಾಡು", "ನನಗೆ ಬೋರ್ ಆಗುತ್ತಿದೆ",
        "{state} ಮುಖ್ಯಮಂತ್ರಿ ಯಾರು", "{state} ರಾಜಧಾನಿ ಯಾವುದು", "ಭಾರತದ ಪ್ರಧಾನಿ ಯಾರು",
        "{thing} ಬೆಲೆ ಎಷ್ಟು", "ಇಂದು {thing} ಎಷ್ಟು", "{thing} ಅಗ್ಗವಾಗಿ ಎಲ್ಲಿ ಸಿಗುತ್ತದೆ",
        "{app} ತೆರೆ", "{app} ಓಪನ್ ಮಾಡು", "ಒಂದು ಹಾಡು ಹಾಕು", "ನನ್ನ ಅಣ್ಣನಿಗೆ ಫೋನ್ ಮಾಡು",
        "ಒಂದು ಫೋಟೋ ತೆಗೆ", "ಸೌಂಡ್ ಜಾಸ್ತಿ ಮಾಡು", "{place} ಗೆ ಕ್ಯಾಬ್ ಬುಕ್ ಮಾಡು",
        "ನನಗೆ {ailment} ಇದೆ, ಏನು ಮಾಡಬೇಕು", "{ailment} ಗೆ ಯಾವ ಔಷಧಿ", "ನನ್ನ ಮಗುವಿಗೆ {ailment}",
        "ಕನ್ನಡದಲ್ಲಿ ಮಾತಾಡು", "ಹಿಂದಿಯಲ್ಲಿ ಮಾತಾಡಬಹುದಾ", "ತಮಿಳಿನಲ್ಲಿ ಉತ್ತರ ಕೊಡು",
        "ಏನು ಮಾಡುತ್ತಿದ್ದೀಯ", "ನೀನು ಈಗ ಏನು ಮಾಡ್ತಿದ್ದೀಯ", "ನೀನು ರೋಬೋಟಾ", "ನನಗೆ ಸುಸ್ತಾಗಿದೆ", "ನನಗೆ ಹಸಿವಾಗಿದೆ",
        "ನನಗೆ ಸಾಲ ಬೇಕು", "ಹಣ ಉಳಿಸುವುದು ಹೇಗೆ", "ಪರೀಕ್ಷೆ ಫಲಿತಾಂಶ ಯಾವಾಗ ಬರುತ್ತದೆ",
        "{place} ಇಲ್ಲಿಂದ ಎಷ್ಟು ದೂರ", "{place} ಗೆ ಬಸ್ ದರ ಎಷ್ಟು",
        "ನಿನ್ನೆ ಕ್ರಿಕೆಟ್ ಮ್ಯಾಚ್ ಯಾರು ಗೆದ್ದರು", "ಒಳ್ಳೆಯ ಸಿನಿಮಾ ಒಂದು ಹೇಳು", "ಇವತ್ತು ಏನು ಅಡುಗೆ ಮಾಡಲಿ",
        "ವಿಮಾನ ಹೇಗೆ ಹಾರುತ್ತದೆ", "ಈ ವರ್ಷ ದಸರಾ ಯಾವಾಗ",
    ],
    "ta-en": [
        "oru joke sollu", "oru kadhai sollu", "oru paatu paadu", "enaku bore adikudhu",
        "{state} chief minister yaaru", "{state} capital edhu", "India prime minister yaaru",
        "{thing} vilai enna", "innaiku {thing} evlo", "{thing} enga cheap ah kidaikum",
        "{app} open pannu", "{app} thira", "oru paatu podu", "en annan ku call pannu",
        "oru photo edu", "sound jaasthi pannu", "{place} ku cab book pannu",
        "enaku {ailment} irukku, enna panradhu", "{ailment} ku enna marundhu", "en kuzhandhaiku {ailment}",
        "Tamil la pesu", "Hindi la pesa mudiyuma", "Telugu la badhil sollu",
        "enna panra", "nee ippo enna panra", "nee robot ah", "enaku tired ah irukku", "enaku pasikudhu",
        "enaku loan venum", "panam epdi save panradhu", "exam result eppo varum",
        "{place} inga irundhu evlo dhooram", "{place} ku bus ticket evlo",
        "nethu cricket la yaaru jeichanga", "nalla padam onnu sollu", "innaiku enna samaikalam",
        "flight epdi parakudhu", "indha varusham Pongal eppo",
    ],
    "hi-en": [
        "ek joke sunao", "ek kahani sunao", "ek gaana gao", "mujhe bore ho raha hai",
        "{state} ke chief minister kaun hain", "{state} ki capital kya hai", "India ke prime minister kaun hain",
        "{thing} ka daam kya hai", "aaj {thing} kitne ka hai", "{thing} sasta kahan milega",
        "{app} kholo", "{app} chalu karo", "koi gaana bajao", "mere bhai ko call lagao",
        "ek photo kheencho", "awaaz tez karo", "{place} ke liye cab book karo",
        "mujhe {ailment} hai, kya karoon", "{ailment} ki kaun si dawa loon", "mere bachche ko {ailment} hai",
        "Hindi mein bolo", "kya tum Tamil mein baat kar sakte ho", "Telugu mein jawab do",
        "kya kar rahe ho", "tum abhi kya kar rahe ho", "kya tum robot ho", "main thak gaya hoon", "mujhe bhookh lagi hai",
        "mujhe loan chahiye", "paise kaise bachayein", "exam ka result kab aayega",
        "{place} yahan se kitni door hai", "{place} ka bus kiraya kitna hai",
        "kal cricket match kaun jeeta", "koi acchi movie batao", "aaj khane mein kya banaun",
        "hawai jahaz kaise udta hai", "is saal Diwali kab hai",
    ],
    "te-en": [
        "oka joke cheppu", "oka katha cheppu", "oka paata paadu", "naaku bore kodutondi",
        "{state} chief minister evaru", "{state} capital edi", "India prime minister evaru",
        "{thing} dhara entha", "ee roju {thing} entha", "{thing} cheap ga ekkada dorukutundi",
        "{app} open cheyyi", "{app} teruvu", "oka paata pettu", "ma annaki call cheyyi",
        "oka photo teeyi", "sound penchu", "{place} ki cab book cheyyi",
        "naaku {ailment} undi, em cheyali", "{ailment} ki e mandu vesukovali", "ma babuki {ailment}",
        "Telugu lo matladu", "Hindi lo matladagalava", "Tamil lo javabu cheppu",
        "em chestunnav", "nuvvu ippudu em chestunnav", "nuvvu robot aa", "naaku alasata ga undi", "naaku aakali ga undi",
        "naaku loan kavali", "dabbu ela save cheyali", "exam results eppudu vastayi",
        "{place} ikkada nundi entha dooram", "{place} ki bus charge entha",
        "ninna cricket match evaru gelicharu", "manchi cinema okati cheppu", "ee roju em vandali",
        "vimanam ela egurutundi", "ee samvatsaram Dasara eppudu",
    ],
    "kn-en": [
        "ondu joke helu", "ondu kathe helu", "ondu haadu haadu", "nange bore agtide",
        "{state} chief minister yaru", "{state} capital yavudu", "India prime minister yaru",
        "{thing} bele eshtu", "ivattu {thing} eshtu", "{thing} cheap agi elli sigutte",
        "{app} open madu", "{app} tere", "ondu haadu haaku", "nanna annange call madu",
        "ondu photo tege", "sound jasti madu", "{place} ge cab book madu",
        "nange {ailment} ide, enu madbeku", "{ailment} ge yava aushadhi", "nanna maguvige {ailment}",
        "Kannada dalli matadu", "Hindi alli matadabahuda", "Tamil alli uttara kodu",
        "enu madtiddiya", "neenu eega enu madtiddiya", "neenu robot aa", "nange sustagide", "nange hasivagide",
        "nange loan beku", "duddu hege save madodu", "exam result yavaga barutte",
        "{place} illinda eshtu doora", "{place} ge bus charge eshtu",
        "ninne cricket match yaru geddru", "olle cinema ondu helu", "ivattu enu aduge madli",
        "vimana hege haarutte", "ee varsha Dasara yavaga",
    ],
}

# More near-misses for "everything else": sentences that use a skill's own
# vocabulary without asking for the skill. A crop that is not a price
# question, a time or date that is not the clock, a language that is not a
# translation, forgetting that is not a reminder.
_NEAR_MISSES = {
    "en": [
        "which fertilizer is good for {crop}", "when is the right time to plant {crop}",
        "how do I store {crop} for a long time", "my {crop} crop has a pest problem",
        "how much water does {crop} need", "give me a recipe with {crop}",
        "what time does the bank open", "what time does the last bus to {place} leave",
        "at what time does the temple close", "what is the date of the next election",
        "when is my exam", "on which date is the festival",
        "which language is spoken in {state}", "teach me some Hindi", "is Tamil an old language",
        "I forgot my password", "do you remember what I said", "I keep forgetting things",
        "why is it so hot these days", "what causes rain", "what is a cyclone",
    ],
    "ta": [
        "{crop} பயிருக்கு எந்த உரம் போடலாம்", "{crop} எப்போது நடவு செய்யலாம்", "{crop} பயிரில் பூச்சி தாக்கம்",
        "வங்கி எத்தனை மணிக்கு திறக்கும்", "{place} கடைசி பஸ் எத்தனை மணிக்கு", "தேர்தல் எந்த தேதியில்",
        "{state}-ல் என்ன மொழி பேசுகிறார்கள்", "எனக்கு இந்தி கற்றுக்கொடு", "என் பாஸ்வேர்ட் மறந்துவிட்டது",
        "மழை எப்படி உருவாகிறது",
    ],
    "hi": [
        "{crop} में कौन सी खाद डालें", "{crop} कब बोना चाहिए", "{crop} की फ़सल में कीड़े लग गए हैं",
        "बैंक कितने बजे खुलता है", "{place} की आख़िरी बस कितने बजे है", "चुनाव किस तारीख को है",
        "{state} में कौन सी भाषा बोलते हैं", "मुझे तमिल सिखाओ", "मैं अपना पासवर्ड भूल गया",
        "बारिश कैसे होती है",
    ],
    "te": [
        "{crop} పంటకు ఏ ఎరువు వేయాలి", "{crop} ఎప్పుడు నాటాలి", "{crop} పంటకు పురుగు పట్టింది",
        "బ్యాంకు ఎన్ని గంటలకు తెరుస్తారు", "{place} కి చివరి బస్సు ఎన్ని గంటలకు", "ఎన్నికలు ఏ తేదీన",
        "{state} లో ఏ భాష మాట్లాడతారు", "నాకు హిందీ నేర్పించు", "నా పాస్‌వర్డ్ మర్చిపోయాను",
        "వర్షం ఎలా కురుస్తుంది",
    ],
    "kn": [
        "{crop} ಬೆಳೆಗೆ ಯಾವ ಗೊಬ್ಬರ ಹಾಕಬೇಕು", "{crop} ಯಾವಾಗ ನಾಟಿ ಮಾಡಬೇಕು", "{crop} ಬೆಳೆಗೆ ಹುಳು ಬಿದ್ದಿದೆ",
        "ಬ್ಯಾಂಕ್ ಎಷ್ಟು ಗಂಟೆಗೆ ತೆರೆಯುತ್ತದೆ", "{place} ಗೆ ಕೊನೆಯ ಬಸ್ ಎಷ್ಟು ಗಂಟೆಗೆ", "ಚುನಾವಣೆ ಯಾವ ದಿನಾಂಕ",
        "{state} ನಲ್ಲಿ ಯಾವ ಭಾಷೆ ಮಾತಾಡುತ್ತಾರೆ", "ನನಗೆ ಹಿಂದಿ ಕಲಿಸು", "ನನ್ನ ಪಾಸ್‌ವರ್ಡ್ ಮರೆತುಹೋಗಿದೆ",
        "ಮಳೆ ಹೇಗೆ ಬರುತ್ತದೆ",
    ],
    "ta-en": [
        "{crop} ku enna uram podalam", "{crop} eppo nadavu pannalam", "{crop} la poochi vandhirukku",
        "bank eppo thirakkum", "{place} ku last bus eppo", "election endha date la",
        "{state} la enna language pesuvanga", "enaku Hindi kathu kudu", "en password marandhuten",
        "mazhai epdi varudhu",
    ],
    "hi-en": [
        "{crop} mein kaun si khaad daalein", "{crop} kab bona chahiye", "{crop} mein keede lag gaye hain",
        "bank kitne baje khulta hai", "{place} ki last bus kitne baje hai", "election kis date ko hai",
        "{state} mein kaun si bhasha bolte hain", "mujhe Tamil sikhao", "main apna password bhool gaya",
        "baarish kaise hoti hai",
    ],
    "te-en": [
        "{crop} pantaki e eruvu veyali", "{crop} eppudu natali", "{crop} pantaki purugu pattindi",
        "bank enni gantalaki teristaru", "{place} ki last bus enni gantalaki", "elections e date na",
        "{state} lo e bhasha matladataru", "naaku Hindi nerpinchu", "na password marchipoya",
        "varsham ela kurustundi",
    ],
    "kn-en": [
        "{crop} belege yava gobbara haakbeku", "{crop} yavaga naati madbeku", "{crop} belege hulu biddide",
        "bank eshtu gantege teriyutte", "{place} ge last bus eshtu gantege", "election yava date",
        "{state} alli yava bhashe matadtare", "nange Hindi kalisu", "nanna password maretu hogide",
        "male hege barutte",
    ],
}
for _lang, _patterns in _NEAR_MISSES.items():
    T["general_query"][_lang] += _patterns

# Words people put around a question. Applied to every pattern, they are
# what turns a few dozen patterns into a few hundred distinct rows without
# changing what is being asked.
OPENERS = {
    "en": ["", "", "", "hey, ", "please ", "ok, ", "BharatVoice, ", "excuse me, ", "quick question, "],
    "ta": ["", "", "", "தயவுசெய்து ", "சரி, ", "ஐயா, ", "கொஞ்சம் "],
    "hi": ["", "", "", "कृपया ", "अच्छा, ", "भाई, ", "ज़रा "],
    "te": ["", "", "", "దయచేసి ", "సరే, ", "అన్నా, ", "కొంచెం "],
    "kn": ["", "", "", "ದಯವಿಟ್ಟು ", "ಸರಿ, ", "ಅಣ್ಣ, ", "ಸ್ವಲ್ಪ "],
    "ta-en": ["", "", "", "hello, ", "seri, ", "anna, ", "konjam ", "bro, "],
    "hi-en": ["", "", "", "hello, ", "accha, ", "bhai, ", "zara ", "yaar, "],
    "te-en": ["", "", "", "hello, ", "sare, ", "anna, ", "koncham ", "bro, "],
    "kn-en": ["", "", "", "hello, ", "sari, ", "anna, ", "swalpa ", "guru, "],
}
CLOSERS = {
    "en": ["", "", "", "?", " please", " now", " for me", "??"],
    "ta": ["", "", "", "?", " சொல்லுங்கள்", " ப்ளீஸ்"],
    "hi": ["", "", "", "?", " बताइए", " प्लीज़"],
    "te": ["", "", "", "?", " చెప్పండి", " ప్లీజ్"],
    "kn": ["", "", "", "?", " ಹೇಳಿ", " ಪ್ಲೀಸ್"],
    "ta-en": ["", "", "", "?", " sollunga", " please", " da"],
    "hi-en": ["", "", "", "?", " batao", " please", " na"],
    "te-en": ["", "", "", "?", " cheppandi", " please", " ra"],
    "kn-en": ["", "", "", "?", " heli", " please", " guru"],
}

# Everyday sentences that are not questions for an assistant, for the
# language-ID set only. Without them the language model would learn the
# vocabulary of the intent bank ("weather", "reminder", "mandi") rather
# than the language, and the only text that reaches it in the app is
# Latin-script text the cue-word rules could not place.
EVERYDAY = {
    "en": [
        "I am going to the market after lunch", "the train was late again this morning",
        "my sister lives in another city", "we had a power cut for two hours",
        "the children are playing outside", "I forgot my keys at home",
        "this road is always full of traffic", "he works in a hospital near the bus stand",
        "the shop closes at nine in the night", "can you lower the volume a little",
        "I have a headache since yesterday", "the mangoes are very sweet this year",
        "she is learning to drive a car", "our village has a new school",
        "I need to charge my phone", "the water tank is empty",
        "let us eat dinner together tonight", "my father retired last year",
        "the festival is next week", "it was very hot in the afternoon",
        "I cannot find my glasses anywhere", "the doctor asked me to rest for a week",
        "we should leave before it gets dark", "there is a wedding in our family next month",
        "the milk has not come today",
    ],
    "ta-en": [
        "naan saapadu saaptu varen", "avan innum veetuku varala", "enga amma kovil ku poirukanga",
        "indha road la traffic romba jaasthi", "naalaiku leave potralam", "thambi school la irundhu vandhutan",
        "kadaila kootam adhigama irukku", "unga veedu enga irukku", "enaku thookam varudhu",
        "paal innum varala", "avanga kalyanam adutha maasam", "vandi puncture aagiduchu",
        "konjam mella pesunga", "indha vaaram oorla thiruvizha", "en friend Chennai la vela paakuran",
        "thanni tank kaali aagiduchu", "ivlo neram enga pona", "sapadu romba nalla irundhuchu",
        "appa ku udambu sari illa", "naanga ellarum padam paaka porom", "kai kazhuvitu vaa",
        "bus innum varala, late aagum", "andha kadai moodi irukku", "veetuku sikram vandhudu",
        "en phone la charge illa",
    ],
    "hi-en": [
        "main khana khaakar aata hoon", "woh abhi tak ghar nahi aaya", "meri maa mandir gayi hain",
        "is sadak par bahut traffic rehta hai", "kal chhutti le lete hain", "chhota bhai school se aa gaya",
        "dukaan par bahut bheed hai", "tumhara ghar kahan hai", "mujhe neend aa rahi hai",
        "doodh abhi tak nahi aaya", "unki shaadi agle mahine hai", "gaadi puncture ho gayi",
        "thoda dheere bolo", "is hafte gaon mein mela hai", "mera dost Dilli mein kaam karta hai",
        "paani ki tanki khaali ho gayi", "itni der kahan the", "khana bahut accha tha",
        "papa ki tabiyat theek nahi hai", "hum sab film dekhne ja rahe hain", "haath dhokar aao",
        "bus abhi nahi aayi, der hogi", "woh dukaan band hai", "ghar jaldi aa jaana",
        "mere phone mein charge nahi hai",
    ],
    "te-en": [
        "nenu annam tini vastanu", "vaadu inka intiki raledu", "ma amma gudiki vellindi",
        "ee road lo traffic chala ekkuva", "repu selavu teesukundam", "tammudu school nundi vachadu",
        "shop lo chala rush undi", "mee illu ekkada", "naaku nidra vastondi",
        "paalu inka raledu", "valla pelli vache nela", "bandi puncture ayyindi",
        "koncham mellaga matladu", "ee vaaram oorlo jatara", "na friend Hyderabad lo job chestunnadu",
        "neella tank khali ayyindi", "inta sepu ekkadiki vellav", "bhojanam chala bagundi",
        "nanna ki ontlo baledu", "manam andaram cinema ki veltunnam", "chetulu kadukkuni raa",
        "bus inka raledu, late avutundi", "aa shop moosi undi", "intiki twaraga vachey",
        "na phone lo charge ledu",
    ],
    "kn-en": [
        "naanu oota madi bartini", "avanu innu manege bandilla", "namma amma devasthanakke hogidare",
        "ee road alli traffic tumba jasti", "naale raje togolona", "tamma school inda banda",
        "angadiyalli tumba rush ide", "nimma mane elli", "nange nidde bartide",
        "haalu innu bandilla", "avara maduve mundina tingalu", "gaadi puncture aagide",
        "swalpa mellage matadi", "ee vaara oorinalli jatre", "nanna friend Bengaluru alli kelsa madtane",
        "neerina tank khali aagide", "ishtu hottu elli hogidde", "oota tumba chennagittu",
        "appa ge hushar illa", "naavella cinema ge hogtidivi", "kai tolkondu baa",
        "bus innu bandilla, late agutte", "aa angadi mucchide", "manege bega baa",
        "nanna phone alli charge illa",
    ],
}

# The first language model mixed up romanized Telugu, Kannada and Tamil with
# each other, which is the costly kind of mistake (a reply in the wrong
# language), so those get more everyday sentences than the rest.
EVERYDAY["te-en"] += [
    "nenu office ki veltunnanu", "meeru ekkada untaru", "ivala chala vedi ga undi",
    "naaku telugu baga vachu", "aame inka nidrapotondi", "manam repu matladukundam",
    "ee kura chala karam ga undi", "vallu ninna oorininchi vacharu", "nee peru enti",
    "naaku dabbulu kavali", "idi evari pustakam", "nenu ippude vachanu",
    "mee intlo andaru bagunnara", "akkada chala mandi unnaru", "ee pani eppudu avutundi",
    "naaku ardham kaledu", "konchem neellu ivvu", "memu sayantram bayaluderutam",
    "aa abbayi chala manchivadu", "ee dari ekkadiki veltundi",
]
EVERYDAY["kn-en"] += [
    "naanu office ge hogtidini", "neevu elli irtira", "ivattu tumba sekhe ide",
    "nange kannada chennagi barutte", "avalu innu malagiddale", "naavu naale matadona",
    "ee saaru tumba khara ide", "avaru ninne oorinda bandru", "ninna hesaru enu",
    "nange duddu beku", "idu yaara pustaka", "naanu eegashte bande",
    "nimma maneyalli ellaru chennagiddara", "alli tumba jana iddare", "ee kelasa yavaga agutte",
    "nange artha aaglilla", "swalpa neeru kodi", "naavu sanje horadtivi",
    "aa huduga tumba olleyavanu", "ee daari ellige hogutte",
]
EVERYDAY["ta-en"] += [
    "naan office ku poren", "neenga enga irukeenga ippo", "innaiku romba veyil",
    "aval innum thoongitu iruka", "naama naalaiku pesalam", "indha kozhambu romba kaaram",
    "avanga nethu oorla irundhu vandhanga", "un peru enna", "idhu yaaroda book",
    "enaku puriyala",
]
EVERYDAY["hi-en"] += [
    "main office ja raha hoon", "aap kahan rehte hain", "aaj bahut garmi hai",
    "woh abhi so rahi hai", "hum kal baat karenge", "yeh sabzi bahut teekhi hai",
    "woh log kal gaon se aaye", "tumhara naam kya hai", "yeh kiski kitaab hai",
    "mujhe samajh nahi aaya",
]
EVERYDAY["en"] += [
    "I am leaving for the office now", "where do you live these days", "it is very sunny today",
    "she is still sleeping", "we will talk tomorrow", "this curry is too spicy",
    "they came from the village yesterday", "what is your name", "whose book is this",
    "I did not understand that",
]

# Closers that would change the label if appended: "thanks please" is still
# thanks, but a reply-asking closer on a greeting or goodbye is not natural.
PLAIN_CLOSERS = {"greeting", "goodbye", "thanks", "how_are_you"}


def _base(lang: str) -> str:
    return lang.split("-")[0]


def _fill(pattern: str, lang: str, rng: random.Random) -> str:
    a, b = rng.randint(2, 950), rng.randint(2, 500)
    u1, u2 = rng.choice(UNIT_PAIRS)
    return pattern.format(
        place=rng.choice(PLACES[lang]),
        crop=rng.choice(CROPS[lang]),
        task=rng.choice(TASKS[lang]),
        when=rng.choice(WHENS[lang]),
        doc=rng.choice(DOCS[lang]),
        word=rng.choice(WORDS),
        target=rng.choice(TARGETS[lang]),
        a=a, b=b, op=rng.choice(OPS), u1=u1, u2=u2,
        state=rng.choice(STATES[lang]),
        thing=rng.choice(THINGS[lang]),
        app=rng.choice(APPS[lang]),
        ailment=rng.choice(AILMENTS[lang]),
    )


def _rows_for(intent: str, lang: str, rng: random.Random, want: int) -> list:
    """Up to `want` distinct sentences for one intent in one language."""
    patterns = T[intent][lang]
    seen, rows = set(), []
    attempts = 0
    while len(rows) < want and attempts < want * 60:
        attempts += 1
        core = _fill(rng.choice(patterns), lang, rng)
        if intent in PLAIN_CLOSERS:
            # Small talk takes at most an "ok, " in front and punctuation
            # behind; "a little good morning" is not something anyone says.
            opener = rng.choice(["", "", "", OPENERS[lang][4]])
            closer = rng.choice(["", "", "!", "."])
        else:
            opener = rng.choice(OPENERS[lang])
            closer = rng.choice(CLOSERS[lang])
        # Don't say the same word twice: "time please please",
        # "oru joke sollu sollunga".
        lowered = core.lower()
        if closer.strip() and closer.strip().lower()[:4] in lowered:
            closer = ""
        if opener.strip(" ,") and opener.strip(" ,").lower() in lowered:
            opener = ""
        # The calculator reads "?" and stray words fine, but a bare
        # expression ("12 * 8") should sometimes stay bare.
        text = f"{opener}{core}{closer}".strip()
        if rng.random() < 0.25:
            text = text[0].upper() + text[1:]
        if text.lower() not in seen:
            seen.add(text.lower())
            rows.append(text)
    return rows


def _test_rows() -> set:
    """
    Every hand-written test sentence, normalised.

    The only use this script makes of the test files: a generated row that
    happens to equal a test row is dropped, so a test question can never
    also be a training question. Nothing is ever written to them.
    """
    held_out = set()
    for path in DATA.glob("*_test.csv"):
        with path.open(encoding="utf-8", newline="") as handle:
            held_out |= {_normalise(row["text"]) for row in csv.DictReader(handle)}
    for path in DATA.glob("*_test_data.csv"):
        with path.open(encoding="utf-8", newline="") as handle:
            held_out |= {_normalise(row["text"]) for row in csv.DictReader(handle)}
    return held_out


def _normalise(text: str) -> str:
    return " ".join(text.lower().strip(" ?.!,").split())


def _read_seed(name: str) -> list:
    path = DATA / name
    if not path.exists():
        return []
    with path.open(encoding="utf-8", newline="") as handle:
        return [(row["text"], row["label"]) for row in csv.DictReader(handle)]


def build():
    rng = random.Random(SEED)
    pool = []  # (text, intent, lang)
    for intent in T:
        for lang in LANGS:
            want = PER_INTENT_PER_LANG * (GENERAL_QUERY_WEIGHT if intent == "general_query" else 1)
            for text in _rows_for(intent, lang, rng, want):
                pool.append((text, intent, lang))

    intent_rows = [(text, intent, lang, "needs-review" if lang in NEEDS_REVIEW else "ok")
                   for text, intent, lang in pool]
    intent_rows += [(text, label, "seed", "ok") for text, label in _read_seed("intent_seed.csv")]

    by_lang = {lang: [text for text, _, row_lang in pool if row_lang == lang] for lang in LANGS}
    langid_rows = []
    for lang in LANGS:
        chosen = rng.sample(by_lang[lang], min(PER_LANGUAGE, len(by_lang[lang])))
        langid_rows += [(text, lang, "needs-review" if lang in NEEDS_REVIEW else "ok") for text in chosen]
    langid_rows += [(text, label, "ok") for text, label in _read_seed("langid_seed.csv")]
    for lang, sentences in EVERYDAY.items():
        review = "needs-review" if lang in NEEDS_REVIEW else "ok"
        for sentence in sentences:
            # Each sentence as written, plus a few lightly varied copies so
            # this small bank is not drowned out by the 300 template rows.
            variants = {sentence, sentence.capitalize(), sentence + ".",
                        OPENERS[lang][4] + sentence, sentence + "?"}
            langid_rows += [(text, lang, review) for text in sorted(variants)]

    held_out = _test_rows()
    intent_rows = [row for row in intent_rows if _normalise(row[0]) not in held_out]
    langid_rows = [row for row in langid_rows if _normalise(row[0]) not in held_out]

    rng.shuffle(intent_rows)
    rng.shuffle(langid_rows)

    for name, header, rows in (
        ("intent_training_data.csv", ("text", "label", "lang", "review"), intent_rows),
        ("langid_training_data.csv", ("text", "label", "review"), langid_rows),
    ):
        with (DATA / name).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle, quoting=csv.QUOTE_ALL, lineterminator="\n")
            writer.writerow(header)
            writer.writerows(rows)

    return intent_rows, langid_rows


if __name__ == "__main__":
    import sys
    from collections import Counter

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    intents, langs = build()
    print(f"intent_training_data.csv: {len(intents)} rows")
    for label, count in sorted(Counter(row[1] for row in intents).items()):
        print(f"  {label:<20} {count}")
    print(f"langid_training_data.csv: {len(langs)} rows")
    for label, count in sorted(Counter(row[1] for row in langs).items()):
        print(f"  {label:<20} {count}")
