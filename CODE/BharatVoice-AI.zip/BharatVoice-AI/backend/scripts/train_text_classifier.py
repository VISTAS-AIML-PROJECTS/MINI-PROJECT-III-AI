#!/usr/bin/env python3
"""
Generic MuRIL sequence-classification fine-tuner.
=====================================================
Shared by `train_muril_intent.py` and `train_muril_langid.py` — both intent
detection and language-ID are, structurally, the same task: text in,
single label out. Rather than duplicate the training loop twice, both
thin wrapper scripts call into this one with different CSV/output paths.

Requires the optional ML stack: `pip install torch transformers datasets
scikit-learn` (see backend/requirements.txt).

Usage:
    python train_text_classifier.py \\
        --train-csv scripts/data/intent_training_data.csv \\
        --output-dir app/services/models/muril_intent \\
        --base-model google/muril-base-cased \\
        --epochs 8

Input CSV format (no header requirement beyond these two column names):
    text,label
    "vanakkam, epdi irukeenga?",greeting
    "chennai la weather epdi irukku",get_weather
    ...

This is intentionally a small, readable training loop rather than a
config-driven framework — it's meant to be forked and tweaked, not
treated as a black box.
"""
import argparse
import shutil
import sys
from pathlib import Path


def split_rows(train_csv, val_split: float, seed: int):
    """
    Load a training CSV and split it into train and validation rows.

    Shared with calibrate_muril.py, which has to rebuild exactly the
    validation rows a checkpoint was trained against. Returns
    (sorted_labels, train_df, val_df).
    """
    import pandas as pd
    from sklearn.model_selection import train_test_split

    df = pd.read_csv(train_csv)
    if not {"text", "label"}.issubset(df.columns):
        sys.exit("CSV must have 'text' and 'label' columns.")
    df = df.dropna(subset=["text", "label"]).reset_index(drop=True)

    labels = sorted(df["label"].unique().tolist())
    df["label_id"] = df["label"].map({label: i for i, label in enumerate(labels)})
    stratify = df["label_id"] if df["label_id"].value_counts().min() >= 2 else None
    train_df, val_df = train_test_split(df, test_size=val_split, random_state=seed, stratify=stratify)
    return labels, train_df, val_df


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--train-csv", required=True, help="Path to a CSV with 'text' and 'label' columns.")
    parser.add_argument("--output-dir", required=True, help="Where to save the fine-tuned checkpoint.")
    parser.add_argument("--base-model", default="google/muril-base-cased", help="Base encoder to fine-tune.")
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=2e-5)
    parser.add_argument("--val-split", type=float, default=0.15, help="Fraction of rows held out for validation.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max-length", type=int, default=64, help="Tokens per example; shorter is faster.")
    parser.add_argument(
        "--freeze-layers", type=int, default=0,
        help="Freeze the embeddings and this many of the 12 encoder layers. Use 6 or so when "
             "training on a CPU: MuRIL's embedding table alone is 150M parameters, and updating "
             "it every step is most of the cost.",
    )
    args = parser.parse_args()

    try:
        import numpy as np
        import pandas  # noqa: F401  (imported here so a missing package is reported below)
        import torch
        from datasets import Dataset
        from sklearn.metrics import accuracy_score, f1_score
        from transformers import (
            AutoModelForSequenceClassification,
            AutoTokenizer,
            Trainer,
            TrainingArguments,
        )
    except ImportError as e:
        sys.exit(
            "Missing a required package for training: "
            f"{e}\nInstall the optional ML stack first:\n"
            "  pip install torch transformers datasets scikit-learn pandas"
        )

    train_csv = Path(args.train_csv)
    if not train_csv.exists():
        sys.exit(f"Training CSV not found: {train_csv}")

    labels, train_df, val_df = split_rows(train_csv, args.val_split, args.seed)
    label2id = {label: i for i, label in enumerate(labels)}
    id2label = {i: label for label, i in label2id.items()}

    print(f"Loaded {len(train_df) + len(val_df)} examples across {len(labels)} labels: {labels}")
    print(f"Train: {len(train_df)} rows · Val: {len(val_df)} rows")

    tokenizer = AutoTokenizer.from_pretrained(args.base_model)

    def tokenize(batch):
        return tokenizer(batch["text"], truncation=True, padding="max_length", max_length=args.max_length)

    train_ds = Dataset.from_pandas(train_df[["text", "label_id"]].rename(columns={"label_id": "label"}))
    val_ds = Dataset.from_pandas(val_df[["text", "label_id"]].rename(columns={"label_id": "label"}))
    train_ds = train_ds.map(tokenize, batched=True)
    val_ds = val_ds.map(tokenize, batched=True)

    model = AutoModelForSequenceClassification.from_pretrained(
        args.base_model,
        num_labels=len(labels),
        id2label=id2label,
        label2id=label2id,
    )

    if args.freeze_layers > 0:
        encoder = model.base_model
        frozen = list(encoder.embeddings.parameters())
        for layer in encoder.encoder.layer[: args.freeze_layers]:
            frozen += list(layer.parameters())
        for parameter in frozen:
            parameter.requires_grad = False
        trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"Frozen embeddings + {args.freeze_layers} layers; training {trainable / 1e6:.0f}M parameters")

    def compute_metrics(eval_pred):
        logits, refs = eval_pred
        preds = np.argmax(logits, axis=-1)
        return {
            "accuracy": accuracy_score(refs, preds),
            "f1_macro": f1_score(refs, preds, average="macro"),
        }

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    training_args = TrainingArguments(
        output_dir=str(output_dir / "_checkpoints"),
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        eval_strategy="epoch",
        save_strategy="epoch",
        # Each checkpoint is the full model plus optimizer state, close to
        # 3 GB for MuRIL. Unlimited, eight epochs wrote 22 GB; keep only
        # the best one, and remove even that once the final model is saved.
        save_total_limit=1,
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        logging_steps=10,
        report_to=[],
        seed=args.seed,
        fp16=torch.cuda.is_available(),
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        compute_metrics=compute_metrics,
    )

    trainer.train()
    metrics = trainer.evaluate()
    print(f"Final validation metrics: {metrics}")

    # Save the final model + tokenizer directly to output_dir (not the
    # intermediate _checkpoints/ subfolder) — this is the path our
    # services (intent_detection.py / language_detection.py) look at.
    trainer.save_model(str(output_dir))
    tokenizer.save_pretrained(str(output_dir))
    # Calibrate confidence on the validation rows, so the app's confidence
    # floor is comparing against a number that means something. See
    # app/services/calibration.py.
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from app.services.calibration import save_calibration

    predictions = trainer.predict(val_ds)
    report = save_calibration(output_dir, predictions.predictions.tolist(), predictions.label_ids.tolist())
    print(f"Calibration: {report}")

    shutil.rmtree(output_dir / "_checkpoints", ignore_errors=True)
    print(f"Saved fine-tuned model to {output_dir}")


if __name__ == "__main__":
    main()
