#!/usr/bin/env python3
"""
Calibrate an already-trained checkpoint without retraining it.
================================================================
    cd backend
    python scripts/calibrate_muril.py intent
    python scripts/calibrate_muril.py langid

The trainer does this itself at the end of a run. This script exists for a
checkpoint trained before calibration was added, or one whose
calibration.json was lost: it rebuilds the trainer's validation split
(same CSV, same seed, same fraction — so do not regenerate the training
data in between) and fits the temperature on it.

See app/services/calibration.py for what calibration is and is not.
"""
import argparse
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND))
sys.path.insert(0, str(Path(__file__).resolve().parent))

TASKS = {
    "intent": ("scripts/data/intent_training_data.csv", "muril_intent_model_path"),
    "langid": ("scripts/data/langid_training_data.csv", "muril_langid_model_path"),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("task", choices=sorted(TASKS))
    parser.add_argument("--val-split", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max-length", type=int, default=64)
    args = parser.parse_args()

    import torch
    from train_text_classifier import split_rows
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    from app.config import settings
    from app.services.calibration import save_calibration

    csv_name, setting = TASKS[args.task]
    checkpoint = BACKEND / getattr(settings, setting)
    if not (checkpoint / "config.json").exists():
        sys.exit(f"No checkpoint at {checkpoint}. Train it first.")

    _, _, val_df = split_rows(BACKEND / csv_name, args.val_split, args.seed)
    tokenizer = AutoTokenizer.from_pretrained(str(checkpoint))
    model = AutoModelForSequenceClassification.from_pretrained(str(checkpoint)).eval()
    label2id = model.config.label2id

    texts = val_df["text"].tolist()
    labels = [label2id[label] for label in val_df["label"]]
    logits = []
    with torch.no_grad():
        for start in range(0, len(texts), 32):
            batch = tokenizer(
                texts[start:start + 32], truncation=True, padding=True,
                max_length=args.max_length, return_tensors="pt",
            )
            logits += model(**batch).logits.tolist()

    report = save_calibration(checkpoint, logits, labels)
    print(f"{args.task}: {report}")


if __name__ == "__main__":
    main()
