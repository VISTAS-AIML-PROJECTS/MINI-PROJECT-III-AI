#!/usr/bin/env python3
"""
Fine-tune MuRIL for intent classification with BharatVoice's default paths.

    python scripts/train_muril_intent.py
    python scripts/train_muril_intent.py --train-csv path/to/more_data.csv

Once training finishes, `app/services/intent_detection.py` picks up the
checkpoint automatically on the next backend restart — no code changes.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from train_text_classifier import main as train_main  # noqa: E402

DEFAULT_TRAIN_CSV = Path(__file__).resolve().parent / "data" / "intent_training_data.csv"
DEFAULT_OUTPUT_DIR = Path(__file__).resolve().parents[1] / "app" / "services" / "models" / "muril_intent"

if __name__ == "__main__":
    if not any(a.startswith("--train-csv") for a in sys.argv[1:]):
        sys.argv += ["--train-csv", str(DEFAULT_TRAIN_CSV)]
    if not any(a.startswith("--output-dir") for a in sys.argv[1:]):
        sys.argv += ["--output-dir", str(DEFAULT_OUTPUT_DIR)]
    train_main()
