#!/usr/bin/env python3
"""
Compare the fine-tuned MuRIL checkpoints with the rule-based classifiers.
===========================================================================
Run from backend/ after training:

    python scripts/evaluate_muril.py

It answers the only question that matters before switching a model on: is
the app better or worse with it?

THE TEST SETS are scripts/data/intent_test_data.csv and
langid_test_data.csv. They were written by hand, separately from the
template bank that generates the training data, and no script writes to
them. That separation is the whole point: a model scores near-perfectly on
rows built from its own training templates, and that number says nothing.

Read the results with two caveats in mind. The test sets are small (ten
rows per intent, about ten per language), so a difference of a few rows is
noise. And they were written by the same author as the training bank, with
many deliberate paraphrases the keyword rules do not cover — closer to
real use than the bank, but not a sample of real users.

For each task it prints:

  rules only          the app with ENABLE_MURIL=false
  MuRIL alone         the model's top answer, ignoring confidence
  app, <mode>         the app as it would actually run in each mode, with
                      the confidence floor and every other guard applied

Nothing here changes any setting or file on disk; it only prints.
"""
import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

BACKEND = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND))

# The report prints Indic text; a Windows console defaults to cp1252 and
# would raise on the first Tamil row.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

DATA = BACKEND / "scripts" / "data"


def _rows(name: str) -> list:
    with (DATA / name).open(encoding="utf-8", newline="") as handle:
        return [(row["text"], row["label"]) for row in csv.DictReader(handle)]


def _score(rows, predict):
    wrong = [(text, expected, got) for text, expected in rows if (got := predict(text)) != expected]
    return len(rows) - len(wrong), len(rows), wrong


def _line(title, result):
    right, total, _ = result
    print(f"  {title:<34} {right:>3}/{total:<3} ({right / total:.0%})")


def _by_label(rows, results: dict):
    """Per-label right-answer counts for several predictors side by side."""
    labels = sorted({label for _, label in rows})
    names = list(results)
    print(f"\n  {'':<20}" + "".join(f"{name:>16}" for name in names))
    for label in labels:
        subset = [(text, expected) for text, expected in rows if expected == label]
        cells = []
        for name in names:
            wrong_texts = {text for text, expected, _ in results[name][2] if expected == label}
            cells.append(f"{len(subset) - len(wrong_texts)}/{len(subset)}")
        print(f"  {label:<20}" + "".join(f"{cell:>16}" for cell in cells))


def _model(path: Path):
    from transformers import pipeline

    if not (path / "config.json").exists():
        return None  # not trained yet
    classifier = pipeline("text-classification", model=str(path), device=-1)
    return lambda text: classifier(text, top_k=1)[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--errors", action="store_true", help="List every wrong answer.")
    parser.add_argument(
        "--intent-test", default="intent_test_data.csv",
        help="Intent test file in scripts/data/ (text,label). Point this at questions written "
             "by someone other than the training bank's author for an independent check.",
    )
    parser.add_argument(
        "--langid-test", default="langid_test_data.csv",
        help="Language test file in scripts/data/ (text,label).",
    )
    args = parser.parse_args()

    from app.config import settings
    from app.services import intent_detection, language_detection

    original = (settings.enable_muril, settings.muril_intent_mode)

    def intent_with(enabled, mode="primary"):
        def predict(text):
            settings.enable_muril, settings.muril_intent_mode = enabled, mode
            return intent_detection.detect_intent(text).intent
        return predict

    def language_with(enabled):
        def predict(text):
            settings.enable_muril = enabled
            return language_detection.detect_language(text).language
        return predict

    # ---------------- Intent ----------------
    print("\n=== INTENT ===")
    rows = _rows(args.intent_test)
    print(f"  {args.intent_test}, {len(rows)} rows")
    results = {"rules": _score(rows, intent_with(False))}
    _line("rules only", results["rules"])
    model = _model(BACKEND / settings.muril_intent_model_path)
    if model is None:
        print("  no checkpoint — run scripts/train_muril_intent.py first")
    else:
        results["model"] = _score(rows, lambda text: model(text)["label"])
        _line("MuRIL alone", results["model"])
        # Calibrated confidence, as the app sees it (app/services/calibration.py).
        confident = sum(
            intent_detection._transformer_intent(text, "en").confidence
            >= settings.intent_confidence_threshold
            for text, _ in rows
        )
        print(f"      confident (>= {settings.intent_confidence_threshold}) on {confident}/{len(rows)} rows")
        results["primary"] = _score(rows, intent_with(True, "primary"))
        _line("app, MuRIL first", results["primary"])
        results["fallback"] = _score(rows, intent_with(True, "fallback"))
        _line("app, rules first then MuRIL", results["fallback"])
    _by_label(rows, results)
    if args.errors:
        for name, (_, _, wrong) in results.items():
            print(f"\n  wrong answers, {name}:")
            for text, expected, got in wrong:
                print(f"    x {text!r}: expected {expected}, got {got}")

    # ---------------- Out of scope ----------------
    # Questions the assistant has no skill for. The right answer to every
    # one is "general_query" (the honest "I can't help with that yet"), and
    # the rules get nearly all of them right by construction — they only
    # fire on keywords. So this is not a contest the model can win. It
    # measures what the model costs: how often it turns a question it
    # should leave alone into a confident wrong answer.
    print("\n=== OUT OF SCOPE (should stay general_query) ===")
    for name, note in (
        ("intent_outofscope_test.csv", "used while developing the training bank"),
        ("intent_outofscope_fresh_test.csv", "written afterwards, not used to shape it"),
    ):
        rows = _rows(name)
        print(f"  {name} — {note}")
        outcomes = {"rules": _score(rows, intent_with(False))}
        _line("    rules only", outcomes["rules"])
        if model is not None:
            outcomes["primary"] = _score(rows, intent_with(True, "primary"))
            _line("    app, MuRIL first", outcomes["primary"])
            outcomes["fallback"] = _score(rows, intent_with(True, "fallback"))
            _line("    app, rules first then MuRIL", outcomes["fallback"])
        if args.errors:
            for mode, (_, _, wrong) in outcomes.items():
                for text, _, got in wrong:
                    print(f"      x [{mode}] {text!r} -> {got}")

    # ---------------- Language ----------------
    print("\n=== LANGUAGE ID ===")
    rows = _rows(args.langid_test)
    print(f"  {args.langid_test}, {len(rows)} rows")
    results = {"rules": _score(rows, language_with(False))}
    _line("rules only", results["rules"])
    model = _model(BACKEND / settings.muril_langid_model_path)
    if model is None:
        print("  no checkpoint — run scripts/train_muril_langid.py first")
    else:
        results["model"] = _score(rows, lambda text: model(text)["label"])
        _line("MuRIL alone", results["model"])
        results["app"] = _score(rows, language_with(True))
        _line("app with MuRIL", results["app"])
    _by_label(rows, results)
    if args.errors:
        for name, (_, _, wrong) in results.items():
            print(f"\n  wrong answers, {name}:")
            for text, expected, got in wrong:
                print(f"    x {text!r}: expected {expected}, got {got}")

    # Confusions matter more than totals for language: saying "Tamil" to a
    # Hindi speaker is worse than saying "English".
    if model is not None:
        confusions = defaultdict(int)
        for _, expected, got in results["app"][2]:
            confusions[(expected, got)] += 1
        if confusions:
            print("\n  app with MuRIL, what the misses were mistaken for:")
            for (expected, got), count in sorted(confusions.items(), key=lambda item: -item[1]):
                print(f"    {expected} -> {got}: {count}")

    settings.enable_muril, settings.muril_intent_mode = original


if __name__ == "__main__":
    main()
