# BharatVoice AI — project analysis

Analysed on 2026-10-05 from the local folder `Sri Ram MP` (branch `main`).

## What it is

BharatVoice AI is a voice-first assistant for Indian languages. A user speaks or
types in Tamil, Hindi, Telugu, Kannada or English (including code-mixed
"Tanglish"/"Hinglish"), and the app detects the language, works out the intent,
runs a matching skill and replies in the same language, in text and speech.

It is aimed at everyday citizen needs rather than open-ended chat: time and
date, a calculator, unit conversion, emergency helplines, guidance on
government documents (Aadhaar, PAN, Voter ID and so on), live weather, mandi
(crop) prices, reminders that actually fire, and a curated, cited FAQ across
education, banking, scams, travel, schemes, jobs and health facilities.

There is no LLM in it. Every answer comes from rules, curated content or a live
data adapter, and the code refuses openly rather than inventing an answer.

## Tech stack

| Layer | What is used |
|---|---|
| Frontend | React 18 + Vite 5, axios, framer-motion, lucide-react. Plain CSS, no router, no state library. |
| Backend | Python 3.12, FastAPI 0.115, Pydantic 2, SQLAlchemy 2, uvicorn |
| Database | SQLite (`backend/bharatvoice.db`), three tables: conversations, messages, reminders |
| Speech in | Browser Web Speech API by default; Whisper on the server if installed |
| Speech out | Browser `speechSynthesis` first, then Bhashini (new, uncommitted), then Coqui XTTS |
| NLU | Rule-based by default; MuRIL, IndicNER and IndicTrans2 switch on automatically if installed |
| Live data | Open-Meteo (weather), AGMARKNET via data.gov.in (mandi prices, needs a free key) |
| Tooling | pytest, ruff, GitHub Actions CI, Docker Compose, nginx |

## How it is structured

```
Sri Ram MP/
├─ backend/
│  ├─ app/
│  │  ├─ main.py            FastAPI app, CORS, static audio, router wiring
│  │  ├─ config.py          all settings, read from environment / .env
│  │  ├─ database.py        SQLite engine + a small "add missing columns" shim
│  │  ├─ models.py          Conversation, Message, Reminder
│  │  ├─ schemas.py         request/response shapes
│  │  ├─ routers/           chat, speech, language, intent, translate, history, reminders
│  │  └─ services/          the real logic (see below)
│  ├─ scripts/              MuRIL fine-tuning scripts + seed CSV datasets
│  └─ tests/                test_core, test_knowledge, test_about, test_voice
├─ frontend/
│  └─ src/
│     ├─ App.jsx            the whole screen: orb, chat, drawers, reminder polling
│     ├─ components/        orb, mic, chat bubbles, history and reminder drawers
│     ├─ hooks/             useSpeechRecognition, useSpeechSynthesis
│     └─ services/api.js    every backend call
├─ docs/                    literature survey + conference paper (not in git)
├─ docker-compose.yml       backend + nginx-served frontend
├─ start.bat / stop.bat     one-click local run on Windows
└─ README.md, DEMO.md       setup guide and demo script
```

A request flows through one explicit pipeline:

`speech → language detection → intent detection → entity extraction → skill → reply → speech`

The services that carry it:

- `nlu_pipeline.py` orchestrates language, intent and entities in one place.
- `language_detection.py`, `intent_detection.py`, `entity_extraction.py` are
  the rule-based implementations with optional model upgrades.
- `response_generator.py` maps each intent to an action and a reply.
- `skills.py` (time, maths, units, helplines, documents), `knowledge.py`
  (curated FAQ), `about.py` (questions about the app itself), `weather.py`,
  `mandi.py`, `timeparse.py` (reminder times).
- `text_to_speech.py` and `tts_bhashini.py` handle server-side speech.

The largest files are `about.py` (984 lines) and `knowledge.py` (957), which
are mostly translated content rather than logic.

## How to run it

**Windows, simplest:** double-click `start.bat`. It starts the backend on port
8000, the frontend on port 5173 and opens the browser. `stop.bat` shuts both
down.

**Manually, two terminals:**

```bash
cd backend
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --port 8000
```

```bash
cd frontend
npm install
npm run dev
```

Then open http://localhost:5173 in Chrome or Edge (voice needs one of those).

**Docker:** `docker compose up --build`, then open http://localhost:3000.

**Tests:** `cd backend && pytest`.

Optional keys, none needed to start: `DATA_GOV_API_KEY` for mandi prices,
`BHASHINI_USER_ID` and `BHASHINI_API_KEY` for server-side Indic voices. For a
direct run they go in `backend/.env`; for Docker, in a root `.env`.

## What I checked

- Backend tests: **575 passed**, about a second per hundred, no failures.
- `ruff check app tests`: clean.
- `npm run build`: succeeds (348 kB JS, 116 kB gzipped).
- I did not start the app or try the microphone.

## Issues and gaps worth attention

### Do first

1. **A lot of work is not saved to git or GitHub.** Twelve files are modified
   and four are new (the whole Bhashini voice feature, `test_voice.py`,
   `VoiceOutStatus.jsx`, and the `docs/` folder with the conference paper).
   On top of that, six of the seven commits have never been pushed to
   `origin`. Right now OneDrive is the only backup of most of the project.
2. **Bhashini voice does not work under Docker.** `docker-compose.yml` passes
   only `DATA_GOV_API_KEY` into the backend container, so the Bhashini
   credentials never reach it. Neither `.env.example` file mentions them
   either, so nobody reading the setup guide would know they exist.
3. **Two integrations have never run against the real service.** The code says
   so itself: `tts_bhashini.py` was written from the published protocol with
   no credentials, and the field names in `mandi.py` have never been confirmed
   against a successful response. Both could fail on first real use, which
   matters if either is part of a demo.

### Correctness and robustness

4. **Synthesised audio is never deleted.** Every server-spoken reply writes a
   new `.wav` to `backend/static/audio` and nothing cleans it up.
   `/api/speech/synthesize` also has no length limit on its text (the chat
   endpoint caps at 2000 characters; `TextToSpeechRequest` does not), so the
   disk can be filled by anyone who can reach the API.
5. **A reminder can be lost.** `GET /api/reminders/due` marks reminders as
   notified as it returns them. If the response is dropped, the tab is closed
   or a second tab is open, the reminder is recorded as shown but the user
   never saw it. Reminders also only fire while the page is open, since the
   browser polls every 30 seconds.
6. **No users or login.** Conversation history and reminders are global, and
   anyone who can reach the API can read or delete all of them. Fine on one
   laptop, not fine on a shared network. Docker also publishes port 8000 on
   the host although the README describes it as internal.
7. **SQLite inside a OneDrive folder.** OneDrive syncing a live database file
   can cause lock errors or a corrupted copy. Pointing `DATABASE_URL` outside
   the synced folder avoids it.
8. **No real database migrations.** `database.py` patches in missing columns
   by hand; the code names Alembic as the proper fix.

### Content and verification

9. **192 strings are marked `# NEEDS REVIEW`.** Hindi, Telugu and Kannada
   wording has not been read by a native speaker.
10. **The nine helpline numbers are unverified** (`checked_on = None`), and
    voice input has never been tested end to end with a real microphone in
    each language. The README is upfront about both.

### Smaller things

11. **Docs are slightly stale.** README and DEMO.md say 540 tests (it is 575),
    the tech-stack table does not list Bhashini, and the roadmap still lists
    Hindi, Telugu and Kannada as future work.
12. **The frontend has no tests and no linter.** CI only checks that it
    builds. `App.jsx` is 649 lines and holds most of the UI state.
13. **`start.bat` is tied to this machine and is blunt.** It hard-codes a
    Python path under `C:\Users\Keerthana.R` (with a fallback to `python`),
    and the uncommitted change makes it force-kill whatever is listening on
    ports 8000 and 5173, even if that is another program.
14. **History listing runs one extra query per conversation**, and the
    frontend Dockerfile uses `npm install` rather than `npm ci`. Neither
    matters at this scale.

## Overall

This is a well-organised, unusually honest project: the fallbacks are real,
refusals are tested, and the README lists its own gaps accurately. The code
quality is not the risk. The risks are unsaved work, two integrations that
have never been exercised for real, and the human checks (native review,
microphone test, helpline verification) that no test can replace.
