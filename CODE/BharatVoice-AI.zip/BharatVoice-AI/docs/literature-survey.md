# CHAPTER 2 — LITERATURE SURVEY

**Project:** BharatVoice AI — A Multilingual Intelligent Assistant for Indian Languages

---

## 2.0 Purpose and Scope of this Survey

This chapter reviews the research areas and technologies that BharatVoice AI is built upon, and identifies the gap that the project attempts to address. The survey is organised as a chain of reasoning rather than a catalogue of technologies: for each area it describes **what existing work provides**, **what limitations remain**, and **how those limitations shaped a specific design decision in BharatVoice AI**.

Throughout the chapter, a clear distinction is maintained between three categories of statement:

1. **Existing research and technology** — work done by others, described as background.
2. **What BharatVoice AI currently implements** — verifiable from the project source code.
3. **What BharatVoice AI is architecturally designed to support but has not yet enabled** — described explicitly as a pluggable or planned component, never as a completed result.

No accuracy figures, benchmark scores, datasets or experimental results are reported in this chapter, because the project has not yet carried out a quantitative evaluation. Statements that would require such evaluation are marked as *requiring verification*.

---

## 2.1 Multilingual Speech Recognition

Automatic Speech Recognition (ASR) converts a spoken utterance into text so that downstream Natural Language Processing components can operate on it. In a voice-first assistant, ASR is the first stage of the pipeline, and any error introduced here propagates to language detection, intent detection and response generation. ASR quality therefore places an upper bound on the quality of the whole system.

Speech recognition for Indian languages is substantially harder than for English. The difficulty arises from several sources acting together: the number of languages in everyday use, the wide variation in regional accents within a single language, differences in pronunciation between speakers of the same language from different districts, differing speaking rates, and the routine mixing of English words into regional-language speech. In addition, the volume of transcribed speech data available for training is far smaller for most Indian languages than for English, which limits how well data-driven acoustic models can be trained.

Transformer-based multilingual ASR systems, of which OpenAI's **Whisper** is a widely used example, address part of this problem by training a single model across many languages at once, so that languages with less data benefit from shared acoustic and linguistic representations. Whisper is designed to be run as a server-side component and natively supports several Indian languages. **Bhashini**, the Government of India's language-technology initiative, similarly exposes ASR services for Indian languages through web APIs.

**Relation to BharatVoice AI.** The project's backend contains a speech-to-text service (`speech_to_text.py`) in which Whisper is the intended production path. However, running Whisper requires downloading large model weights and, in practice, GPU acceleration for acceptable latency. Because the project must run on ordinary student and demonstration hardware without a large model download, the **shipped implementation performs speech input in the browser using the Web Speech API**, and the backend speech endpoint returns a clear, structured error directing the client to that browser fallback when Whisper is not installed. This is an honest engineering trade-off rather than a limitation hidden from the user.

**Limitations of the current approach.** Browser-based recognition has three consequences that the project explicitly accepts:

- Recognition quality depends on the user's browser and device, and is therefore outside the application's control.
- The Web Speech API accepts **one recognition locale at a time**, so the user must select the input language from the header toggle rather than the system detecting the spoken language automatically.
- Recognition accuracy across the five supported languages **has not been quantitatively evaluated** by the project, and such an evaluation is required before any accuracy claim can be made.

Moving ASR to the server using Whisper or Bhashini would remove the locale restriction and make quality uniform across devices, and is identified in the project documentation as the principal planned upgrade.

---

## 2.2 Natural Language Processing for Indian Languages

Once speech has been converted to text, the system must determine what the user actually wants. This is the domain of Natural Language Processing (NLP). Indian-language NLP differs from conventional English NLP in ways that matter for system design:

- **Script diversity.** Indian languages are written in several distinct scripts, and text processing must handle each correctly.
- **Morphological richness.** Languages such as Tamil, Telugu and Kannada are agglutinative — a single word may carry information that English expresses with several separate words. Simple whitespace tokenisation and exact word matching are therefore weaker signals than in English.
- **Free word order.** Many Indian languages permit greater reordering of sentence constituents than English does, so rules based on fixed word position are fragile.
- **Resource scarcity.** Annotated corpora for tasks such as intent classification are limited compared with English.

Pre-trained multilingual transformer models have become the standard response to these challenges. **MuRIL** (Multilingual Representations for Indian Languages) is trained on Indian-language text together with its transliterated form, which is directly relevant to code-mixed usage. **IndicBERT** is a comparatively compact multilingual encoder trained on a large collection of Indian-language corpora. Both are designed to be fine-tuned for downstream tasks such as classification.

**Relation to BharatVoice AI.** The project defines a fixed NLP pipeline:

```
Speech / Text Input → Language Detection → Intent Detection
→ Entity Extraction → Action Execution → Response Generation
→ Text-to-Speech
```

Each stage is a separate module with a defined interface. MuRIL and IndicBERT appear in the architecture as **pluggable components**: the intent-detection service contains a transformer-backed path that is used when a fine-tuned checkpoint is present and configuration permits it.

It must be stated plainly that **the project has not trained or fine-tuned any of these models.** The intent detection that actually runs in the current implementation is a **keyword and pattern-based classifier** covering a fixed Phase-1 intent set, which includes greetings, weather, time and date, reminders, arithmetic, unit conversion, emergency help, government-document help, mandi prices, translation requests, questions about the application itself, a curated knowledge FAQ, and a general-query fallback.

**Why a rule-based classifier is a defensible choice here.** It is fast, needs no GPU, produces completely explainable decisions, and — importantly for a citizen-service application — fails in predictable ways. Its limitation is equally clear: it generalises poorly to phrasings outside its patterns, and its coverage across the five languages has not been quantitatively measured. The modular pipeline exists precisely so that this stage can later be replaced by a fine-tuned MuRIL or IndicBERT classification head without altering the surrounding system.

---

## 2.3 Indian Language Identification

Language identification (LID) determines which language a piece of input text is written in. In BharatVoice AI it is a prerequisite for almost everything downstream: the system must know the user's language before selecting reply wording, choosing a speech-synthesis voice, or picking the correct labels for emergency and government content.

Existing LID research uses character n-gram statistics, probabilistic classifiers, and neural models trained on multilingual corpora. Libraries such as `langdetect` implement classical statistical approaches; transformer-based identifiers such as MuRIL-derived LID models and **IndicLID** target Indian languages specifically.

**Relation to BharatVoice AI.** The project exploits a structural property of the writing systems it supports: **Tamil, Devanagari, Telugu and Kannada occupy disjoint, contiguous Unicode blocks.** Counting which block a string's characters fall into therefore identifies native-script text reliably, with no model, no download and no inference latency. The implementation applies a cascade, cheapest test first:

1. **Script histogram** — resolves native-script input.
2. **Romanized cue words** — a curated list for common Latin-script phrases.
3. **`langdetect`** — a general statistical signal for longer Latin-script text.
4. **MuRIL / IndicLID** — used only when a checkpoint is present.

**A limitation recorded in the project's own source.** Script identification cannot separate languages that *share* a script. Hindi, Marathi, Sanskrit, Konkani and Nepali are all written in Devanagari, so the script stage reports any Devanagari text as Hindi. This is correct for the current five-language set, in which Hindi is the only Devanagari language, and becomes incorrect the moment a second Devanagari language is added — at which point the model-based stage ceases to be optional. Documenting this boundary is itself a finding of the survey: script-based LID is an efficient technique with a precisely known failure condition, not a general solution.

---

## 2.4 Code-Mixed and Romanized Language Processing

Code-mixing — alternating between two or more languages within a single utterance — is a defining characteristic of everyday digital communication in India. It appears in two forms that matter here:

- **Code-mixing proper:** English words embedded in a regional-language sentence.
- **Romanization / transliteration:** a regional language typed using the Roman alphabet, because the user does not have or does not wish to switch to a native-script keyboard.

Consider the example query used throughout the project:

> **"Chennai la weather epdi irukku?"**

This single short sentence illustrates why the problem is hard:

- *Chennai* — a proper noun, an Indian place name, written in Roman script.
- *la* — a **Tamil locative case marker** ("in"), written in Roman script.
- *weather* — an English content word.
- *epdi irukku* — **Tamil** for "how is it", written in Roman script, and spelled non-standardly: the same phrase is written *epdi*, *eppadi*, *epadi* or *yepdi* by different users, because there is no agreed romanization standard in informal use.

Every character in this sentence belongs to the Latin block, so the script test of Section 2.3 returns no information at all. Statistical identifiers trained on monolingual corpora tend to classify such input as English, because the script and several tokens are English-like — which would cause the assistant to reply in the wrong language. Word-level approaches must additionally cope with the spelling variation, since no fixed dictionary entry matches every user's transliteration.

**Relation to BharatVoice AI.** The project handles this with a **dedicated romanized cue-word and heuristic stage**, separate from script detection, which recognises common greetings and question frames such as `vanakkam`, `epdi irukeenga` and `kya haal hai`. The same design is carried into intent detection, whose patterns include romanized forms alongside English and native-script forms.

**Usability significance.** This is not a cosmetic feature. It removes the requirement that a user install, learn and switch to a native-script keyboard before the assistant becomes usable in their own language — a requirement that would exclude a large share of the intended user base.

**Stated limitation.** The current implementation is **heuristic, not a trained code-mixed language model.** Its behaviour therefore depends on whether the user's vocabulary and sentence structure fall within the curated cue set, and it will degrade on unusual phrasings or unseen spelling variants. Coverage across the five languages **has not been quantitatively measured** and would require a labelled code-mixed test set to evaluate properly. MuRIL, trained on transliterated text, is the natural replacement for this stage.

---

## 2.5 Machine Translation for Indian Languages

Machine translation (MT) is required whenever information held in one language must be communicated in another. For this project it is relevant in two ways: answering explicit translation requests from the user, and potentially rendering English-sourced information into the user's language.

Neural machine translation has largely replaced earlier statistical methods. **AI4Bharat's IndicTrans2** is a prominent open model covering 22 scheduled Indian languages, distributed as separate English→Indic and Indic→English checkpoints rather than a single bidirectional model.

**Relation to BharatVoice AI.** IndicTrans2 is present in the translation service as the intended production path, loaded lazily when the required libraries and checkpoints are available. Because the model requires a large download and benefits substantially from a GPU, the **currently active fallback is a small curated Tamil↔English phrase and word dictionary**, covering common assistant phrases. For anything outside that dictionary the endpoint returns an explicit "not available" message rather than a guess.

Two points must be stated accurately: the fallback covers **Tamil and English only**, not all five supported languages; and **no translation model has been trained by the project.**

**Why translation quality matters especially here.** In a citizen-service context, a mistranslation is not a cosmetic error. If an eligibility condition, a fee, a deadline or a procedural step is rendered incorrectly, a citizen may act on wrong information — submit the wrong form, miss a deadline, or believe themselves ineligible for a benefit they qualify for. This risk directly motivated a design decision described in Section 2.8: for government documents, BharatVoice AI deliberately restricts its replies to what the document is and which portal issues it, and says nothing about eligibility, fees or timelines, because those are precisely the claims where a translation or content error causes real harm. Every such reply also carries a pointer, in the user's own language, to the relevant official portal.

The project further records that Hindi, Telugu and Kannada content strings are marked in the source as requiring native-speaker review, and that this review **has not yet been carried out**. Telugu and Kannada replies are described as best-effort wording. This is a known, documented limitation rather than a claim of verified quality.

---

## 2.6 Voice-Based Conversational Assistants

Commercial voice assistants demonstrate how the components surveyed so far — ASR, NLP, dialogue management, response generation and text-to-speech — can be combined into a single conversational interface. Their general architecture is well established: capture speech, transcribe it, interpret it, execute an action or retrieve information, generate a response, and speak it back.

Two limitations of general-purpose assistants are relevant to this project. First, their coverage of Indian languages, and particularly of code-mixed Indian speech, is uneven. Second, they are built for broad consumer use rather than for citizen services, so information about government documents, schemes and helplines is not a first-class capability. *Comparative claims about the relative accuracy of specific commercial assistants on Indian languages would require systematic testing and are not made here.*

**Relation to BharatVoice AI.** The project follows the same voice-first interaction model but narrows the domain to Indian citizen services. Concrete design consequences:

- The primary interface element is a **large voice-interaction orb**, not a chat window, so that speaking is the default interaction and typing is the alternative — which suits users for whom typing, especially in native script, is the barrier.
- **Text input remains fully available** for situations where voice is impractical: a noisy environment, a device without a working microphone, or a user who prefers not to speak aloud.
- **Every spoken response is also displayed as text**, so the assistant remains usable when no suitable voice is installed on the device.

For speech output, the shipped implementation uses the browser's **SpeechSynthesis API**, and the backend contains a text-to-speech service with an additional Bhashini-based path. The limitation is symmetric to that of browser ASR: available voices and their quality depend on what is installed on the user's operating system and browser, which the application cannot control. Displaying the text response unconditionally is the mitigation.

---

## 2.7 AI-Based Citizen and Government Service Systems

Government services in India are delivered through a large number of separate online portals, each responsible for its own domain — identity documents, welfare schemes, scholarships, employment, transport, health. Each portal has its own navigation, terminology and language coverage. For a citizen, the practical difficulty is often not that information is unavailable but that locating the right portal, and then the right page within it, requires prior knowledge of how services are organised administratively.

This has motivated interest in conversational front-ends to government information, where a citizen can ask a question in ordinary language instead of navigating a hierarchy of websites.

**Relation to BharatVoice AI.** The project offers a single conversational entry point covering: Aadhaar, PAN, Voter ID, Ration Card, Passport and Driving Licence; scholarships; opening a bank account; online fraud and scam awareness; trains and buses; government schemes; government jobs; finding a hospital; and emergency services.

**Curated knowledge rather than open web scraping.** For several of these domains the system serves a curated, source-carrying knowledge base rather than scraping government websites live. This choice has a clear justification and a clear cost:

- *Justification.* Scraped or freely generated government information can be outdated or misattributed, and an outdated procedural answer can cause a citizen to act incorrectly. A curated base with explicit sources is auditable — a reviewer can check what the system will say.
- *Cost.* Curated content must be maintained by hand, and can itself go stale if government procedures change. The project mitigates this by keeping curated answers deliberately general and pointing to the official portal for the specifics, so that the volatile details are read from the authoritative source rather than reproduced.

A supporting design detail worth noting is that the assistant's own answer to "which languages do you support" is **generated from the same table that records per-language review status**, so that the claim shown to the user and the actual state of the project cannot drift apart. Consistency of this kind is an aspect of trustworthiness that is easily overlooked in system design.

---

## 2.8 Source-Grounded and Trustworthy AI

A widely discussed weakness of generative conversational systems is their tendency to produce fluent, confident text that is not supported by any source — commonly termed hallucination. The research response has been to ground responses in retrievable evidence and to make systems capable of declining to answer.

In a general-purpose chatbot, an unsupported answer is an inconvenience. In a citizen-service assistant it is a materially different problem, for three reasons:

1. **The user cannot easily verify the answer.** A citizen consulting an assistant about a government document is, by definition, consulting it because they do not already know the answer.
2. **The answers drive real action.** Eligibility, fee and deadline claims lead to filled forms, paid money and missed windows.
3. **Fluency is mistaken for authority.** A well-formed answer in the user's own language carries an implicit impression of officialness that a generated guess does not deserve.

**Relation to BharatVoice AI.** The project adopts a source-oriented response design, in which fact-bearing responses are expected to carry source information and government-related answers point to the relevant official portal. It deliberately avoids four specific behaviours:

- inventing government information;
- issuing eligibility decisions it cannot support;
- presenting monetary figures that may be outdated;
- implying that live information was retrieved when it was not.

The clearest illustration is the mandi-price feature described in Section 2.9: when live prices cannot be retrieved, the system **states that live prices are unavailable instead of producing an estimate.**

This yields the design principle that runs through the whole project:

> **A controlled refusal is preferable to a confident but incorrect answer when reliable information is unavailable.**

The cost of this principle should be acknowledged rather than glossed over: a system that refuses will sometimes decline a question a more permissive system would have answered correctly, and users may find this less satisfying. The project takes the position that in the citizen-service domain the asymmetry of harm — a wrong answer being worse than no answer — justifies the trade.

---

## 2.9 Live Information and API-Based Services

Not all citizen queries can be answered from stored knowledge. Weather, commodity prices and similar quantities are only meaningful when current, so the assistant must call an external service at query time. This introduces failure modes absent from static content: the service may be slow, may be unreachable, may return incomplete data, or may require credentials that are not configured.

**Relation to BharatVoice AI.** The project integrates two live services:

- **Weather**, via the **Open-Meteo** API. Weather responses include freshness information and source details, so the user can judge how current the data is.
- **Mandi (agricultural market) prices**, designed against the **AGMARKNET / data.gov.in** service. This path operates only when a valid `DATA_GOV_API_KEY` is configured. Without the key, or when the upstream service fails, the system reports that live prices are unavailable and does **not** fabricate a figure.

**Finding from this area.** Treating external API reliability as a first-class design concern — rather than an exception to be handled quietly — is essential for citizen-service applications. The correct behaviour on failure is to make the failure visible to the user, because a silently substituted estimate is indistinguishable to the user from real data.

---

## 2.10 Accessibility and Emergency Assistance

Accessibility determines whether a citizen-service system reaches the people who most need it. Barriers to conventional web-based government services include limited literacy, unfamiliarity with native-script typing, limited experience navigating portal hierarchies, and visual impairment. A voice-first interface addresses several of these directly, since speaking requires neither typing nor navigation.

**Relation to BharatVoice AI.** Several concrete accessibility decisions follow from this:

- **Voice as the primary interaction**, with text as an equal alternative.
- **Emergency helpline information with tappable `tel:` links**, so that on a mobile device a user can move from asking for help to placing the call in one tap, at a moment when navigating a menu is least practical.
- **Explicit feedback on microphone and speech-service failure.** Different failure conditions — permission denied, no microphone present, speech service unavailable — produce different messages, rather than leaving the user facing an interface that appears simply not to respond. Silent failure is particularly damaging in a voice-first interface, where there is no visible control whose absence would explain the problem.
- **Text display of every spoken response**, so the assistant degrades gracefully when no suitable voice is installed.

**Stated limitation.** The project records that **real-device accessibility testing, including screen-reader testing, has not yet been carried out.** No accessibility conformance claim is made in this report, and such testing is identified as required future work.

---

## 2.11 Limitations of Existing Systems

Drawing together the limitations identified in Sections 2.1–2.10:

| # | Limitation | Where identified |
|---|---|---|
| 1 | Script-based language identification cannot handle romanized or code-mixed input, and cannot separate languages sharing a script | 2.3, 2.4 |
| 2 | Speech-recognition quality varies with language, accent, browser and device | 2.1 |
| 3 | Large multilingual models (Whisper, MuRIL, IndicTrans2) need significant compute and large downloads, limiting deployment on ordinary hardware | 2.1, 2.2, 2.5 |
| 4 | Government information is distributed across many separate portals with differing structure and language coverage | 2.7 |
| 5 | Static curated information can become outdated as procedures change | 2.7 |
| 6 | Generative systems can produce fluent but unsupported information, which is especially harmful in citizen services | 2.8 |
| 7 | External live-data APIs fail, and failure must be surfaced rather than concealed | 2.9 |
| 8 | Existing solutions rarely combine voice interaction, Indian-language and code-mixed NLP, and citizen services in one interface | 2.6, 2.7 |
| 9 | Accessibility features require validation on real devices, including screen readers | 2.10 |

Limitations acknowledged in the **present implementation of BharatVoice AI** itself, stated so that this survey is not read as a claim of completeness:

- Speech recognition has **not been quantitatively evaluated** across the five supported languages.
- Intent detection is **rule-based**; no model has been trained or fine-tuned by the project.
- Code-mixed handling is **heuristic**, not a trained code-mixed model.
- The active translation fallback covers **Tamil and English only**.
- Hindi, Telugu and Kannada content **awaits native-speaker review**; Telugu and Kannada replies are best-effort wording.
- Server-side ASR, MuRIL/IndicBERT classification and IndicTrans2 translation are **architecturally supported but not enabled** in the shipped build.
- Accessibility has **not been validated on real devices**.

---

## 2.12 Research Gap

The reviewed work shows that the individual capabilities required by a multilingual citizen assistant are, separately, well developed:

| Area | What it provides | What it does not provide |
|---|---|---|
| Multilingual ASR (Whisper, Bhashini) | Speech → text across Indian languages | Interpretation, service access, or grounding |
| Indian-language NLP (MuRIL, IndicBERT) | Representations for Indian-language understanding | A voice interface or a service layer |
| Machine translation (IndicTrans2) | High-quality Indic↔English translation | Knowledge of what to say, or whether it is true |
| Government portals | Authoritative official information | Conversational or voice access; multilingual reach |
| Voice assistants | Conversational interaction | Depth in Indian code-mixed speech and citizen services |
| Grounding / refusal research | Techniques for source-backed, refusable answers | An integrated Indian-language deployment |

Each addresses one layer. What is comparatively under-explored is their **integration into a single Indian citizen-focused platform** that simultaneously provides:

- multilingual voice interaction in Indian languages;
- handling of romanized and code-mixed input as a first-class case, not an afterthought;
- access to citizen-service information through one conversational entry point;
- source-backed responses with an explicit refusal mechanism when reliable information is unavailable;
- live information where it is needed, with honest failure behaviour;
- emergency and accessibility support in the user's own language.

This is stated as a gap in **integration**, not as a claim of novelty for any individual component, and not as a claim that no comparable system exists. *A systematic comparison against deployed Indian citizen-service assistants has not been performed and would be required to establish any stronger claim.*

---

## 2.13 How BharatVoice AI Addresses the Research Gap

BharatVoice AI responds to this gap with a modular pipeline in which each surveyed capability occupies a defined stage:

```
        Voice / Text Input
                 ↓
     Speech-to-Text  (Web Speech API now; Whisper / Bhashini pluggable)   § 2.1
                 ↓
     Language Detection  (script histogram → romanized cues → langdetect
                          → MuRIL / IndicLID when available)              § 2.3, 2.4
                 ↓
     Intent Detection  (rule-based now; MuRIL / IndicBERT pluggable)      § 2.2
                 ↓
     Entity Extraction                                                    § 2.2
                 ↓
     Action / Service Execution  (skills, curated knowledge,
                                  live APIs, reminders)                   § 2.7, 2.9
                 ↓
     Source-Aware Response Generation  (citations; refusal on
                                        unavailable information)          § 2.8
                 ↓
     Text-to-Speech  (SpeechSynthesis API; Bhashini path present)         § 2.6
                 ↓
     Multilingual Voice-First Interface  (orb-led, text always shown,
                                          tel: emergency links)           § 2.6, 2.10
```

Supporting components: **FastAPI** backend, **React (Vite)** frontend, and **SQLite** (via SQLAlchemy) for persistent conversation history and reminders.

Three properties of this design are worth emphasising, because they are what the survey's findings actually motivated:

1. **Graceful degradation by construction.** Every heavyweight component has a lightweight fallback with an explicit interface — Whisper falls back to browser ASR, IndicTrans2 to a curated dictionary, transformer LID to script analysis, transformer intent detection to patterns. The system therefore runs without a GPU or large downloads, while leaving a defined upgrade path.
2. **Honesty as a design requirement, not a feature.** Refusal on unavailable live data, source pointers on government answers, text display of every spoken reply, distinct microphone-failure messages, and a self-description generated from the project's own review-status table all follow from the same principle set out in Section 2.8.
3. **Code-mixed input treated as a primary case.** Romanized and code-mixed handling is a dedicated stage in language detection and is carried into the intent patterns, rather than being treated as malformed input.

---

## 2.14 Literature Survey Conclusion

The surveyed work shows substantial progress across every capability a multilingual Indian citizen assistant requires. Whisper and Bhashini provide multilingual speech recognition; MuRIL and IndicBERT provide pre-trained representations for Indian-language understanding; IndicTrans2 provides Indic↔English translation; browser speech APIs make voice interaction deployable without specialised infrastructure; and research on grounding and refusal provides techniques for keeping generated answers trustworthy.

Significant challenges nonetheless remain. Romanized and code-mixed input — the way a large number of Indian users actually write — defeats script-based identification and is poorly served by identifiers trained on monolingual text. Speech recognition quality varies with language, accent and device. Large models impose compute requirements that ordinary deployment settings cannot meet. Government information remains distributed across many portals and changes over time. And fluent generated text can carry an unwarranted impression of authority in exactly the domain where being wrong is most costly.

BharatVoice AI does not attempt to advance any one of these component technologies. Its contribution is **integration**: combining multilingual voice interaction, code-mixed language handling, curated and live citizen-service information, source-backed responses with explicit refusal, and emergency and accessibility support within one modular platform, built so that stronger models can be substituted at each stage as resources permit.

The present implementation has clearly defined limits — rule-based intent detection, heuristic code-mixed handling, browser-dependent speech, a narrow translation fallback, pending native-speaker review for three languages, and an absence of quantitative evaluation. Recording those limits explicitly is itself consistent with the project's central principle: that a system serving citizens should be accurate about what it can and cannot do.

---
---

# PPT VERSION — 6 Literature-Survey Slides

## Slide 1 — Multilingual Speech Recognition

- ASR is the first pipeline stage; its errors propagate to every later stage
- Indian-language ASR is hard: many languages, regional accents, code-mixed speech, limited transcribed data
- **Whisper** (multilingual transformer ASR) and **Bhashini** (Govt. of India APIs) are the established server-side options
- Both need large model downloads and, realistically, a GPU
- BharatVoice AI: Whisper path built in, **browser Web Speech API used in the shipped build** — no large download
- Limitation: quality varies by device; one recognition locale at a time, so the user selects the language

> **Takeaway:** Server-side ASR gives the best quality; we ship the browser fallback so the system runs anywhere, and we say so plainly.

---

## Slide 2 — Indian Language NLP & Language Identification

- Indian-language NLP is harder than English: multiple scripts, agglutinative morphology, freer word order, fewer annotated corpora
- **MuRIL** and **IndicBERT** provide pre-trained Indian-language representations for fine-tuning
- Language identification must run **before** reply wording, voice selection and content labels
- BharatVoice AI uses a cheapest-first cascade: **Unicode script histogram → romanized cues → langdetect → MuRIL/IndicLID**
- Tamil, Devanagari, Telugu and Kannada sit in **disjoint Unicode blocks** — native script is identified with no model and no latency
- Known boundary: script cannot separate languages sharing a script (Hindi vs Marathi in Devanagari)

> **Takeaway:** Script gives near-free, exact identification for native text — with one precisely known failure condition we have documented.

---

## Slide 3 — Code-Mixed & Romanized Language Processing

- Tanglish / Hinglish is how a very large share of Indian users actually write
- Example: **"Chennai la weather epdi irukku?"**
  - *Chennai* = Indian place name · *la* = Tamil case marker · *weather* = English · *epdi irukku* = Tamil in Roman script
- Everything is Latin script → the script test returns **zero** information
- Monolingual-trained identifiers tend to label it English → assistant replies in the wrong language
- No standard romanization: *epdi / eppadi / epadi / yepdi* all appear
- BharatVoice AI: a **dedicated romanized cue-word stage**, carried into the intent patterns too

> **Takeaway:** Treating code-mixed input as a first-class case removes the native-keyboard barrier — but our handling is heuristic, not a trained model.

---

## Slide 4 — Machine Translation & Voice Assistants

- **IndicTrans2** (AI4Bharat) covers 22 Indic languages; separate En→Indic and Indic→En checkpoints
- BharatVoice AI: IndicTrans2 is the intended path; active fallback is a curated **Tamil↔English** dictionary — anything else returns an explicit "not available"
- In citizen services, a mistranslated eligibility rule, fee or deadline causes real harm
- Consequence: government replies state **what the document is and which portal issues it** — never eligibility, fees or timelines
- Voice output uses the browser **SpeechSynthesis API**; a Bhashini TTS path exists in the backend
- Voices depend on the user's device — so **every spoken reply is also shown as text**

> **Takeaway:** Where translation quality can't be guaranteed, we narrow what we claim rather than widen what we guess.

---

## Slide 5 — Citizen Services & Trustworthy AI

- Government information is spread across many portals; the difficulty is finding the right one, not that it is missing
- BharatVoice AI gives one conversational entry point: Aadhaar, PAN, Voter ID, Ration Card, Passport, DL, scholarships, banking, scams, transport, schemes, jobs, hospitals, emergency
- **Curated, source-carrying knowledge** instead of open web scraping — auditable, and we point to the official portal for volatile details
- Hallucination matters more here: users can't verify, answers drive real action, fluency reads as authority
- Live data: **Open-Meteo** weather with freshness + source; **AGMARKNET/data.gov.in** mandi prices only with a valid API key
- No key or upstream failure → **"live prices unavailable"**, never an invented figure

> **Takeaway:** A controlled refusal is preferable to a confident but incorrect answer when reliable information is unavailable.

---

## Slide 6 — Research Gap & Our Contribution

- **ASR** solves speech→text · **MuRIL/IndicBERT** solve understanding · **IndicTrans2** solves translation · **portals** hold the facts · **assistants** provide conversation
- Each solves one layer; the **integration** into one Indian citizen-focused platform is comparatively under-explored
- Gap: multilingual voice + code-mixed input + citizen services + source-backed answers + safe refusal, in one system
- BharatVoice AI's answer: a **modular pipeline** where every heavy model has a working lightweight fallback
- Upgrade path is defined: server ASR, fine-tuned intent detection, full IndicTrans2 — no redesign needed
- Stated openly as an **integration** contribution, not a novelty or "first of its kind" claim

> **Takeaway:** The contribution is putting the pieces together honestly for Indian citizens — with every current limitation documented rather than hidden.

---
---

# PRESENTATION SCRIPT (≈2–3 minutes)

*Suggested pacing: ~25 seconds per slide, ~140 words per minute. Pause where marked.*

---

"Good morning. I'll take you through the literature survey for BharatVoice AI. Rather than list AI technologies, I've organised it as a chain: what existing research gives us, where it falls short, and how each shortfall shaped a design decision in our system.

**[Slide 1 — Speech Recognition]**

We start with speech recognition, because it's the first stage and its errors propagate everywhere downstream. Indian-language ASR is genuinely hard — many languages, strong regional accent variation, and far less transcribed training data than English. Whisper and the government's Bhashini initiative are the established options, but both need large model downloads and realistically a GPU. So our backend has the Whisper path built in, while the shipped build does speech input in the browser using the Web Speech API. That's an honest trade-off, and it has a cost: the browser accepts one recognition locale at a time, so the user selects their language. Server-side ASR is our main planned upgrade.

**[Slide 2 — NLP and Language Identification]**

Next, understanding. Indian languages are morphologically rich with freer word order, and annotated data is scarce — which is why MuRIL and IndicBERT exist. In our system they're pluggable, and I want to be clear: **we have not trained or fine-tuned any model.** Our running intent detection is rule-based — fast, explainable, and predictable in how it fails.

For language identification we use a nice structural fact: Tamil, Devanagari, Telugu and Kannada sit in disjoint Unicode blocks. So counting characters identifies native script with no model and no latency. We've also documented exactly where that breaks — it can't separate Hindi from Marathi, since both use Devanagari.

**[Slide 3 — Code-Mixing]** *(pause here — this is the key slide)*

This is the part I'd most like to highlight. Take "Chennai la weather epdi irukku?" — that's an Indian place name, a **Tamil case marker**, an English word, and Tamil written in Roman letters, all in one short sentence. Every character is Latin, so our script test returns nothing at all, and identifiers trained on monolingual text tend to call it English — which would make the assistant reply in the wrong language. There's also no standard spelling: *epdi*, *eppadi*, *epadi*. We handle this with a dedicated romanized cue-word stage. It matters because it means a user doesn't need a native-script keyboard to use the system in their own language. It is, however, heuristic — not a trained code-mixed model.

**[Slide 4 — Translation and Voice]**

IndicTrans2 is our intended translation engine; the active fallback is a curated Tamil–English dictionary, and anything outside it returns an explicit "not available." This connects directly to trust: if we mistranslate an eligibility rule or a fee, a citizen acts on wrong information. So our government replies say what a document is and which portal issues it — and deliberately say nothing about eligibility, fees or timelines.

**[Slide 5 — Citizen Services and Trustworthiness]**

Government information is spread across many portals, so we provide one conversational entry point across fourteen domains, using curated source-carrying content rather than web scraping. Hallucination is a much more serious problem here than in a general chatbot — the user can't verify the answer, and a fluent reply in their own language reads as official. Our clearest example: when mandi prices can't be fetched, we say live prices are unavailable. We don't estimate. The principle is that **a controlled refusal beats a confident wrong answer.**

**[Slide 6 — Research Gap]**

So the gap. Every capability exists separately — recognition, understanding, translation, portals, conversation. What's under-explored is integrating them into one Indian citizen-focused platform that handles code-mixed voice input, cites its sources, and refuses safely. We're presenting this as an **integration** contribution, not a claim of being first.

And I'll be direct about our limits: no quantitative evaluation yet across the five languages, rule-based intent detection, heuristic code-mixing, and Hindi, Telugu and Kannada content still awaiting native-speaker review. We've documented all of that in the report — which is consistent with the project's own principle that a system serving citizens should be accurate about what it can and cannot do.

Thank you. I'm happy to take questions."

---

## Likely panel questions and honest answers

| Question | Answer |
|---|---|
| "Did you train any model?" | No. Intent detection and code-mixed handling are rule- and heuristic-based; MuRIL/IndicBERT/IndicTrans2/Whisper are pluggable paths we built interfaces for but have not fine-tuned. |
| "What is your accuracy?" | We have not run a quantitative evaluation yet. Doing so needs a labelled multilingual and code-mixed test set — that's stated as required future work rather than estimated. |
| "Why not just use ChatGPT / a general LLM?" | Free generation of government details risks confident wrong answers on eligibility, fees and deadlines. We chose curated, source-carrying content plus explicit refusal. |
| "Why rules instead of a model?" | Deployability and explainability on ordinary hardware, and predictable failure. The pipeline is modular so this stage can be swapped for a fine-tuned classifier without touching the rest. |
| "How is this different from Alexa or Siri?" | Domain focus on Indian citizen services, code-mixed input as a first-class case, and source-backed answers with refusal. We have not benchmarked against them, so we make no comparative accuracy claim. |
| "What's the biggest weakness?" | Browser-dependent speech recognition, and that Hindi, Telugu and Kannada content has not yet had native-speaker review. |
