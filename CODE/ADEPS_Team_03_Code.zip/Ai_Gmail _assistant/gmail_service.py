import base64
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.modify",
]


class GmailService:
    """Helper class for authenticating with Gmail API and fetching inbox messages."""

    def __init__(
        self,
        credentials_path: Optional[str] = None,
        token_path: Optional[str] = None,
        user_id: str = "me",
    ):
        base_dir = Path(__file__).resolve().parent
        self.credentials_path = (
            Path(credentials_path)
            if credentials_path is not None
            else base_dir / "credentials" / "token.json"
        )
        self.token_path = (
            Path(token_path)
            if token_path is not None
            else base_dir / "credentials" / "google_token.json"
        )
        self.user_id = user_id

    def _resolve_client_config(self) -> Path:
        candidates = [
            self.credentials_path,
            Path(__file__).resolve().parent / "credentials" / "client_secret.json",
            Path(__file__).resolve().parent / "credentials" / "token.json",
        ]

        for candidate in candidates:
            if candidate.exists():
                return candidate

        raise FileNotFoundError(
            "Google OAuth client configuration not found. Expected a file in credentials/ such as token.json or client_secret.json."
        )

    def _ensure_parent_dir(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)

    def _read_client_config(self) -> Dict[str, Any]:
        config_path = self._resolve_client_config()
        with open(config_path, "r", encoding="utf-8") as file:
            return json.load(file)

    def get_credentials(self) -> Credentials:
        creds: Optional[Credentials] = None

        if self.token_path.exists():
            creds = Credentials.from_authorized_user_file(str(self.token_path), SCOPES)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_config(
                    self._read_client_config(),
                    SCOPES,
                )
                creds = flow.run_local_server(port=0)

            self._ensure_parent_dir(self.token_path)
            with open(self.token_path, "w", encoding="utf-8") as file:
                file.write(creds.to_json())

        return creds

    def get_service(self):
        credentials = self.get_credentials()
        return build("gmail", "v1", credentials=credentials)

    def list_messages(self, query: str = "", max_results: int = 10) -> List[Dict[str, str]]:
        service = self.get_service()
        result = (
            service.users()
            .messages()
            .list(userId=self.user_id, q=query, maxResults=max_results)
            .execute()
        )
        return result.get("messages", [])

    def get_message(self, message_id: str) -> Dict[str, Any]:
        service = self.get_service()
        return (
            service.users()
            .messages()
            .get(userId=self.user_id, id=message_id, format="full")
            .execute()
        )

    def _get_header_value(self, headers: List[Dict[str, str]], name: str) -> str:
        for header in headers:
            if header.get("name", "").lower() == name.lower():
                return header.get("value", "")
        return ""

    def _decode_part_data(self, data: str) -> str:
        if not data:
            return ""
        try:
            padded = data + "=" * (-len(data) % 4)
            return base64.urlsafe_b64decode(padded.encode("utf-8")).decode(
                "utf-8", errors="replace"
            )
        except Exception:
            return ""

    def _extract_body_from_part(self, part: Dict[str, Any]) -> str:
        mime_type = part.get("mimeType", "")
        body = part.get("body", {})
        data = body.get("data")

        if data and (mime_type == "text/plain" or mime_type == "text/html"):
            return self._decode_part_data(data)

        if part.get("parts"):
            for child in part["parts"]:
                text = self._extract_body_from_part(child)
                if text:
                    return text

        return ""

    def get_message_details(self, message_id: str) -> Dict[str, Any]:
        message = self.get_message(message_id)
        payload = message.get("payload", {})
        headers = payload.get("headers", [])

        subject = self._get_header_value(headers, "Subject") or "(No Subject)"
        sender = self._get_header_value(headers, "From") or "Unknown sender"
        to = self._get_header_value(headers, "To") or ""
        date = self._get_header_value(headers, "Date") or ""
        body = self._extract_body_from_part(payload)

        return {
            "id": message.get("id"),
            "thread_id": message.get("threadId"),
            "subject": subject,
            "sender": sender,
            "to": to,
            "date": date,
            "snippet": message.get("snippet", ""),
            "body": body,
        }

    def fetch_recent_messages(self, query: str = "", max_results: int = 5) -> List[Dict[str, Any]]:
        messages = self.list_messages(query=query, max_results=max_results)
        return [self.get_message_details(msg["id"]) for msg in messages]


def main() -> None:
    gmail = GmailService()

    try:
        emails = gmail.fetch_recent_messages(max_results=5)
        for email in emails:
            print(f"From: {email['sender']}")
            print(f"Subject: {email['subject']}")
            print(f"Preview: {email['snippet']}")
            print("-" * 60)
    except FileNotFoundError as exc:
        print(f"Missing client config: {exc}")
    except HttpError as exc:
        print(f"Gmail API error: {exc}")


if __name__ == "__main__":
    main()
