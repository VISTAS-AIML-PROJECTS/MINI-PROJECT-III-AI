document.addEventListener('DOMContentLoaded', () => {
  const button = document.querySelector('.primary-btn');
  if (button) {
    button.addEventListener('click', () => {
      window.location.href = '/dashboard';
    });
  }
});
