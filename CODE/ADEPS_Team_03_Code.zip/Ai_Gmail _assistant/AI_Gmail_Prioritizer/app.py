import json
import os
import threading
import uuid
from typing import Any, Dict, List, Optional

from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for
from google_auth_oauthlib.flow import Flow
from googleapiclient.errors import HttpError

from config import Config
from database import add_or_update_email, get_dashboard_stats, get_email_by_id, get_recent_emails, init_db
from gmail_service import GmailService
from llama_service import LlamaService
from logger import setup_logger

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = Config.SECRET_KEY
logger = setup_logger('app')
analysis_jobs = {}
analysis_jobs_lock = threading.Lock()

init_db()


def load_google_client_config():
    if not Config.CREDENTIALS_PATH.exists():
        raise FileNotFoundError(f'Missing Google OAuth file: {Config.CREDENTIALS_PATH}')

    with open(Config.CREDENTIALS_PATH, 'r', encoding='utf-8') as file:
        config = json.load(file)

    client = config.get('installed', {})
    if not client.get('client_id') or 'YOUR_GOOGLE_CLIENT_ID' in client.get('client_id', ''):
        raise ValueError(
            'Google OAuth is not configured. Add your real client_id and client_secret in .env or credentials/credentials.json.'
        )

    return config


def build_google_flow():
    config = load_google_client_config()
    return Flow.from_client_config(
        config,
        scopes=Config.GMAIL_SCOPES,
        redirect_uri=Config.GOOGLE_REDIRECT_URI,
    )


def normalize_sender(value: str) -> str:
    if not value:
        return 'Unknown sender'
    return value.replace('\n', ' ').strip()


def normalize_priority(value: str) -> str:
    normalized = (value or 'NORMAL').strip().upper()
    valid = {'URGENT', 'IMPORTANT', 'NORMAL', 'SPAM'}
    return normalized if normalized in valid else 'NORMAL'


def get_analysis_job(job_id: Optional[str]) -> Optional[Dict[str, Any]]:
    if not job_id:
        return None
    with analysis_jobs_lock:
        job = analysis_jobs.get(job_id)
        return dict(job) if job else None


def update_analysis_job(job_id: str, **updates: Any) -> None:
    with analysis_jobs_lock:
        if job_id in analysis_jobs:
            analysis_jobs[job_id].update(updates)


def run_inbox_analysis(job_id: str) -> None:
    seen_count = 0
    labeled_count = 0
    failed_count = 0
    saved_unanalyzed_count = 0
    permission_error = False
    message = ''

    try:
        gmail_service = GmailService()
        labels_by_name = gmail_service.ensure_priority_labels()
        llama_service = LlamaService()

        for email in gmail_service.iter_inbox_messages():
            seen_count += 1
            update_analysis_job(
                job_id,
                seen=seen_count,
                current_subject=email.get('subject', 'No subject'),
            )
            message_id = email.get('id')
            try:
                if not message_id:
                    raise ValueError('Gmail message ID is missing.')

                analysis = llama_service.analyze_email(
                    email.get('subject', 'No subject'),
                    email.get('body', ''),
                )
                if not analysis.get('ok', True):
                    failed_count += 1
                    try:
                        process_gmail_email(email, analysis)
                        saved_unanalyzed_count += 1
                    except Exception as exc:
                        logger.error('Could not save unanalyzed Gmail message (%s).', type(exc).__name__)
                    logger.warning(
                        'Saved Gmail message %s without a priority label because Llama analysis failed.',
                        message_id,
                    )
                    update_analysis_job(
                        job_id,
                        failed=failed_count,
                        saved_unanalyzed=saved_unanalyzed_count,
                    )
                    continue

                priority = normalize_priority(analysis.get('priority'))
                label_name = gmail_service.apply_priority_label(
                    message_id,
                    priority,
                    labels_by_name=labels_by_name,
                )
                try:
                    process_gmail_email(email, analysis)
                except Exception as exc:
                    logger.error('Could not save message analysis to local database (%s).', type(exc).__name__)
                labeled_count += 1
                logger.info('Applied Gmail label %s to message %s', label_name, message_id)
                update_analysis_job(job_id, labeled=labeled_count)
            except HttpError as exc:
                failed_count += 1
                status = getattr(exc.resp, 'status', 'unknown')
                logger.error('Gmail API error while processing a message (HTTP %s)', status)
                update_analysis_job(job_id, failed=failed_count)
                if status in (401, 403):
                    permission_error = True
                    break
            except Exception as exc:
                failed_count += 1
                logger.error('Could not process one Gmail message (%s).', type(exc).__name__)
                update_analysis_job(job_id, failed=failed_count)

        if seen_count == 0:
            message = 'No inbox emails were found.'
        elif permission_error:
            message = (
                f'Processing stopped: {labeled_count} labeled, {failed_count} failed. '
                'Check Gmail API and gmail.modify permission, then reconnect.'
            )
        else:
            message = (
                f'Inbox processing finished: {labeled_count} labeled; '
                f'{saved_unanalyzed_count} saved without AI analysis; '
                f'{max(0, failed_count - saved_unanalyzed_count)} processing errors '
                f'out of {seen_count} emails.'
            )
    except HttpError as exc:
        status = getattr(exc.resp, 'status', 'unknown')
        logger.error('Gmail API error during inbox processing (HTTP %s)', status)
        message = f'Gmail API request failed (HTTP {status}). Check Gmail API and account permissions.'
    except Exception as exc:
        logger.error('Could not start inbox processing (%s)', type(exc).__name__)
        message = f'Inbox processing stopped ({type(exc).__name__}). Check the server log.'

    update_analysis_job(
        job_id,
        state='complete',
        seen=seen_count,
        labeled=labeled_count,
        failed=failed_count,
        saved_unanalyzed=saved_unanalyzed_count,
        current_subject='',
        message=message,
    )


def process_gmail_email(email: Dict[str, Any], analysis: Optional[Dict[str, Any]] = None) -> None:
    gmail_id = email.get('id') or email.get('gmail_id')
    if not gmail_id:
        return

    if analysis is None:
        analysis = LlamaService().analyze_email(email.get('subject', 'No subject'), email.get('body', ''))
    add_or_update_email(
        gmail_id=gmail_id,
        sender=normalize_sender(email.get('sender', 'Unknown sender')),
        subject=email.get('subject', 'No subject'),
        body=email.get('body', ''),
        summary=analysis.get('summary', ''),
        priority=normalize_priority(analysis.get('priority', 'NORMAL')),
        reason=analysis.get('reason', ''),
        action_items=analysis.get('action_items', []),
        deadlines=analysis.get('deadlines', []),
        suggested_reply=analysis.get('suggested_reply', ''),
        analysis_status='complete' if analysis.get('ok', True) else 'failed',
        email_date=email.get('date'),
    )


@app.route('/')
def login_page():
    return render_template('login.html', error=None)


@app.route('/login')
def login():
    if os.path.exists(Config.TOKEN_PATH) and request.args.get('reauthorize') != '1':
        session['gmail_authenticated'] = True
        return redirect(url_for('dashboard'))

    try:
        flow = build_google_flow()
        authorization_url, state = flow.authorization_url(
            access_type='offline',
            prompt='consent',
        )
        session['oauth_state'] = state
        return redirect(authorization_url)
    except Exception as exc:
        return render_template('login.html', error=str(exc))


@app.route('/callback')
def callback():
    if request.args.get('error'):
        return render_template('login.html', error=f"Google login was cancelled: {request.args.get('error')}")

    if not session.get('oauth_state'):
        return redirect(url_for('login_page'))

    try:
        flow = build_google_flow()
        flow.fetch_token(authorization_response=request.url)

        credentials = flow.credentials
        Config.TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(Config.TOKEN_PATH, 'w', encoding='utf-8') as file:
            file.write(credentials.to_json())

        session['gmail_authenticated'] = True
        return redirect(url_for('dashboard'))
    except Exception as exc:
        return render_template('login.html', error=f'Authentication failed: {exc}')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))


@app.route('/dashboard')
def dashboard():
    if not session.get('gmail_authenticated'):
        return redirect(url_for('login_page'))

    query = request.args.get('q', '').strip()
    priority_filter = request.args.get('priority', '').strip()
    gmail_service = GmailService()
    try:
        inbox_stats = gmail_service.get_inbox_label_stats()
        inbox_count = inbox_stats['threads_total']
        inbox_message_count = inbox_stats['messages_total']
        unread_count = inbox_stats['messages_unread']
    except Exception as exc:
        logger.warning('Could not retrieve Gmail inbox count (%s)', type(exc).__name__)
        inbox_count = None
        inbox_message_count = None
        unread_count = None
    try:
        inbox_ids = gmail_service.get_inbox_message_ids()
    except Exception as exc:
        logger.warning('Could not retrieve Gmail inbox messages (%s)', type(exc).__name__)
        inbox_ids = []
    try:
        account_email = gmail_service.get_account_email()
    except Exception as exc:
        logger.warning('Could not retrieve connected Gmail address (%s)', type(exc).__name__)
        account_email = None
    emails = get_recent_emails(
        limit=25,
        priority=priority_filter or None,
        search=query,
        gmail_ids=inbox_ids,
    )
    stats = get_dashboard_stats(gmail_ids=inbox_ids)

    return render_template(
        'dashboard.html',
        emails=emails,
        stats=stats,
        inbox_count=inbox_count,
        inbox_message_count=inbox_message_count,
        unread_count=unread_count,
        account_email=account_email,
        selected_priority=priority_filter,
        search_query=query,
        analysis_job=get_analysis_job(session.get('analysis_job_id')),
    )


@app.route('/sync-gmail', methods=['POST'])
def sync_gmail():
    if not session.get('gmail_authenticated'):
        return redirect(url_for('login_page'))

    try:
        service = GmailService()
        messages = service.fetch_recent_messages(max_results=20)
        for message in messages:
            process_gmail_email(message)
        return redirect(url_for('dashboard'))
    except Exception as exc:
        return render_template('login.html', error=f'Gmail sync failed: {exc}')


@app.route('/analyze', methods=['POST'])
def analyze_latest_email():
    if not session.get('gmail_authenticated'):
        return redirect(url_for('login_page'))

    try:
        gmail_service = GmailService()
        messages = gmail_service.fetch_recent_messages(max_results=1)
        if not messages:
            flash('No inbox email was found to analyze.', 'warning')
            return redirect(url_for('dashboard'))

        email = messages[0]
        message_id = email.get('id')
        if not message_id:
            raise ValueError('Gmail returned an email without a message ID.')

        subject = email.get('subject', 'No subject')
        body = email.get('body', '')
        logger.info('Analyzing Gmail email: %s', subject[:120])
        if body.strip():
            analysis = LlamaService().analyze_email(subject, body)
        else:
            analysis = {
                'priority': 'NORMAL',
                'reason': 'No readable email body was available; defaulted to normal priority.',
                'summary': 'This email did not contain a readable body.',
                'ok': False,
            }

        if not analysis.get('ok', True):
            flash('Llama analysis failed; no priority label was applied. Check the server log and provider settings.', 'error')
            return redirect(url_for('dashboard'))

        priority = normalize_priority(analysis.get('priority'))
        label_name = gmail_service.apply_priority_label(message_id, priority)
        process_gmail_email(email, analysis)
        logger.info('Applied Gmail label %s to message %s', label_name, message_id)
        flash(
            f"{priority.title()}: {subject} | {analysis.get('reason', '')} | Gmail label: {label_name}",
            'success',
        )
    except HttpError as exc:
        status = getattr(exc.resp, 'status', 'unknown')
        logger.error('Gmail API error (HTTP %s)', status)
        if status in (401, 403):
            flash(
                'Gmail denied the request. Check that Gmail API is enabled and gmail.modify permission '
                'was granted, then reconnect at /login?reauthorize=1.',
                'error',
            )
        else:
            flash(f'Gmail API request failed (HTTP {status}). Check the server log.', 'error')
    except Exception as exc:
        logger.error('Email analysis failed (%s)', type(exc).__name__)
        flash(f'Could not analyze and label the email ({type(exc).__name__}). Check the server log.', 'error')

    return redirect(url_for('dashboard'))


@app.route('/analyze-all', methods=['POST'])
def analyze_all_inbox():
    if not session.get('gmail_authenticated'):
        return redirect(url_for('login_page'))

    current_job = get_analysis_job(session.get('analysis_job_id'))
    if current_job and current_job.get('state') == 'running':
        flash('Inbox prioritization is already running.', 'warning')
        return redirect(url_for('dashboard'))

    job_id = uuid.uuid4().hex
    with analysis_jobs_lock:
        analysis_jobs[job_id] = {
            'state': 'running',
            'seen': 0,
            'labeled': 0,
            'failed': 0,
            'saved_unanalyzed': 0,
            'current_subject': 'Starting inbox scan',
            'message': '',
        }
    session['analysis_job_id'] = job_id

    try:
        threading.Thread(
            target=run_inbox_analysis,
            args=(job_id,),
            daemon=True,
            name=f'gmail-analysis-{job_id[:8]}',
        ).start()
        flash('Inbox prioritization started. Progress will update here.', 'success')
    except Exception as exc:
        logger.error('Could not start inbox analysis thread (%s)', type(exc).__name__)
        update_analysis_job(job_id, state='complete', message='Inbox prioritization could not start.')
        flash('Inbox prioritization could not start. Check the server log.', 'error')

    return redirect(url_for('dashboard'))


@app.route('/analyze-all/status')
def analyze_all_status():
    if not session.get('gmail_authenticated'):
        return jsonify({'state': 'unauthorized'}), 401

    job = get_analysis_job(session.get('analysis_job_id'))
    return jsonify(job or {'state': 'idle'})


@app.route('/email/<int:email_id>')
def email_detail(email_id):
    if not session.get('gmail_authenticated'):
        return redirect(url_for('login_page'))

    email = get_email_by_id(email_id)
    if not email:
        return render_template('email.html', error='Email not found.', email=None)

    return render_template('email.html', email=email, error=None)


@app.route('/api/health')
def health_check():
    return jsonify({'status': 'ok', 'project': 'AI Gmail Prioritizer'})


if __name__ == '__main__':
    ssl_context = None
    if Config.CERT_PATH.exists() and Config.KEY_PATH.exists():
        ssl_context = (str(Config.CERT_PATH), str(Config.KEY_PATH))
    app.run(
        debug=Config.DEBUG,
        host='0.0.0.0',
        port=int(os.getenv('PORT', 5000)),
        ssl_context=ssl_context,
    )
