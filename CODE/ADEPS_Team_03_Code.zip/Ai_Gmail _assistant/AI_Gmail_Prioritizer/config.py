import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent


class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'change-me-in-production')
    DEBUG = os.getenv('DEBUG', 'True').lower() in ('1', 'true', 'yes')
    GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID', '').strip()
    GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET', '').strip()
    GOOGLE_REDIRECT_URI = os.getenv('GOOGLE_REDIRECT_URI', 'https://localhost:5000/callback')
    CERT_PATH = BASE_DIR / 'certs' / 'localhost.crt'
    KEY_PATH = BASE_DIR / 'certs' / 'localhost.key'
    CREDENTIALS_PATH = BASE_DIR / 'credentials' / 'credentials.json'
    TOKEN_PATH = BASE_DIR / 'credentials' / 'token.json'
    DATABASE_PATH = os.getenv('DATABASE_PATH', str(BASE_DIR / 'database' / 'emails.db'))

    LLAMA_PROVIDER = os.getenv('LLAMA_PROVIDER', 'ollama').strip().lower()
    LLAMA_MODEL = os.getenv(
        'LLAMA_MODEL',
        os.getenv('OPENROUTER_MODEL', 'llama3'),
    ).strip()
    _LLAMA_DEFAULT_URLS = {
        'ollama': os.getenv('OLLAMA_URL', 'http://localhost:11434/api/generate'),
        'groq': os.getenv('GROQ_URL', 'https://api.groq.com/openai/v1/chat/completions'),
        'openrouter': os.getenv('OPENROUTER_URL', 'https://openrouter.ai/api/v1/chat/completions'),
    }
    LLAMA_API_URL = os.getenv(
        'LLAMA_API_URL',
        _LLAMA_DEFAULT_URLS.get(LLAMA_PROVIDER, ''),
    ).strip()
    _LLAMA_LEGACY_API_KEYS = {
        'groq': os.getenv('GROQ_API_KEY', ''),
        'openrouter': os.getenv('OPENROUTER_API_KEY', ''),
    }
    LLAMA_API_KEY = os.getenv(
        'LLAMA_API_KEY',
        _LLAMA_LEGACY_API_KEYS.get(LLAMA_PROVIDER, ''),
    ).strip()
    LLAMA_TIMEOUT_SECONDS = int(os.getenv('LLAMA_TIMEOUT_SECONDS', '120'))

    GMAIL_SCOPES = [
        'https://www.googleapis.com/auth/gmail.readonly',
        'https://www.googleapis.com/auth/gmail.modify',
    ]
