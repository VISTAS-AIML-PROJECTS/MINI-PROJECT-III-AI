def score_email(subject: str, body: str) -> int:
    text = f"{subject} {body}".lower()
    score = 0
    keywords = {
        'urgent': 5,
        'deadline': 4,
        'payment': 4,
        'invoice': 4,
        'interview': 4,
        'security': 5,
        'alert': 5,
        'meeting': 2,
        'follow up': 2,
        'newsletter': -2,
        'update': 1,
    }

    for word, value in keywords.items():
        if word in text:
            score += value
    return max(0, min(score, 10))


def format_priority(score: int) -> str:
    if score >= 7:
        return 'High'
    if score >= 3:
        return 'Medium'
    return 'Low'
