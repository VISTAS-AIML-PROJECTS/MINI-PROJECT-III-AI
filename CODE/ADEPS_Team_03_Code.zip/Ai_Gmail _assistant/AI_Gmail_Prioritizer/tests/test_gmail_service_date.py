import unittest
from unittest.mock import Mock

from gmail_service import GmailService


class GmailServiceDateTests(unittest.TestCase):
    def test_get_inbox_message_ids_count_all_pages(self):
        service = GmailService.__new__(GmailService)
        gmail_api = Mock()
        list_messages = gmail_api.users.return_value.messages.return_value.list
        service.get_service = Mock(return_value=gmail_api)
        responses = [
            {
                'messages': [{'id': f'first-{index}'} for index in range(100)],
                'nextPageToken': 'page-2',
            },
            {
                'messages': [{'id': f'second-{index}'} for index in range(100)],
                'nextPageToken': 'page-3',
            },
            {'messages': [{'id': f'last-{index}'} for index in range(8)]},
        ]
        service._execute_with_backoff = Mock(side_effect=responses)

        message_ids = service.get_inbox_message_ids()

        self.assertEqual(len(message_ids), 208)
        self.assertEqual(service._execute_with_backoff.call_count, 3)
        self.assertEqual(list_messages.call_args_list[0].kwargs, {
            'userId': 'me', 'maxResults': 100, 'labelIds': ['INBOX']
        })
        self.assertEqual(list_messages.call_args_list[1].kwargs, {
            'userId': 'me', 'maxResults': 100, 'labelIds': ['INBOX'], 'pageToken': 'page-2'
        })
        self.assertEqual(list_messages.call_args_list[2].kwargs, {
            'userId': 'me', 'maxResults': 100, 'labelIds': ['INBOX'], 'pageToken': 'page-3'
        })

    def test_get_inbox_label_stats_uses_inbox_label_metadata(self):
        service = GmailService.__new__(GmailService)
        gmail_api = Mock()
        get_label = gmail_api.users.return_value.labels.return_value.get
        service.get_service = Mock(return_value=gmail_api)
        service._execute_with_backoff = Mock(return_value={
            'messagesTotal': 600,
            'threadsTotal': 591,
            'messagesUnread': 208,
            'threadsUnread': 204,
        })

        stats = service.get_inbox_label_stats()

        self.assertEqual(stats, {
            'messages_total': 600,
            'threads_total': 591,
            'messages_unread': 208,
            'threads_unread': 204,
        })
        get_label.assert_called_once_with(userId='me', id='INBOX')

    def test_format_message_includes_date_header(self):
        service = GmailService.__new__(GmailService)
        message = {
            'id': 'abc123',
            'internalDate': '1727786096000',
            'payload': {
                'headers': [
                    {'name': 'From', 'value': 'Test Sender <test@example.com>'},
                    {'name': 'Subject', 'value': 'Important update'},
                    {'name': 'Date', 'value': 'Tue, 01 Oct 2024 12:34:56 +0000'},
                ],
                'body': {'data': ''},
                'parts': [],
            },
        }

        result = service._format_message(message)

        self.assertEqual(result['date'], 'Tue, 01 Oct 2024 12:34:56 +0000')


if __name__ == '__main__':
    unittest.main()
