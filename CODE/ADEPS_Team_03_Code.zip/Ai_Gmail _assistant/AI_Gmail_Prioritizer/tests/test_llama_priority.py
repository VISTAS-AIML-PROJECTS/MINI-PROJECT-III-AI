import uuid

from database import add_or_update_email, email_exists, init_db
from llama_service import LlamaService


def test_safe_json_parser_accepts_markdown_json():
    service = LlamaService()
    parsed = service._safe_parse_json(
        '```json\n{"priority":"Important","reason":"Client follow-up","summary":"Follow up with the client."}\n```'
    )

    assert parsed['priority'] == 'Important'
    assert parsed['reason'] == 'Client follow-up'
    assert parsed['summary'] == 'Follow up with the client.'


def test_invalid_priority_falls_back_to_normal():
    service = LlamaService()

    assert service._normalize_priority('Urgent') == 'URGENT'
    assert service._normalize_priority('random-priority') == 'NORMAL'


def test_database_avoids_duplicate_gmail_ids():
    init_db()
    gmail_id = f'test-{uuid.uuid4()}'

    created_first = add_or_update_email(
        gmail_id=gmail_id,
        sender='Test Sender',
        subject='Interview scheduled',
        body='Your interview is tomorrow at 10 AM.',
        summary='Interview scheduled',
        priority='URGENT',
        reason='Urgent interview reminder',
        action_items=['Confirm interview'],
        deadlines=['Tomorrow at 10 AM'],
        suggested_reply='Thanks',
        analysis_status='complete',
        email_date='Tue, 01 Oct 2024 12:34:56 +0000',
    )
    created_second = add_or_update_email(
        gmail_id=gmail_id,
        sender='Test Sender',
        subject='Interview scheduled',
        body='Your interview is tomorrow at 10 AM.',
        summary='Interview scheduled',
        priority='URGENT',
        reason='Urgent interview reminder',
        action_items=['Confirm interview'],
        deadlines=['Tomorrow at 10 AM'],
        suggested_reply='Thanks',
        analysis_status='complete',
        email_date='Tue, 01 Oct 2024 12:34:56 +0000',
    )

    assert created_first is True
    assert created_second is False
    assert email_exists(gmail_id) is True
