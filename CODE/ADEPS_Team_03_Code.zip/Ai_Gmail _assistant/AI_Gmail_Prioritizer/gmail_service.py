from __future__ import annotations

import base64
import json
import random
import re
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Dict, Optional

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from config import Config
from logger import setup_logger

logger = setup_logger('gmail_service')


class _HTMLTextExtractor(HTMLParser):
    _BLOCK_TAGS = {'br', 'div', 'li', 'p', 'tr', 'h1', 'h2', 'h3', 'h4'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self._parts = []

    def handle_starttag(self, tag, attrs):
        if tag in self._BLOCK_TAGS:
            self._parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self._BLOCK_TAGS:
            self._parts.append('\n')

    def handle_data(self, data):
        self._parts.append(data)

    def get_text(self):
        text = ''.join(self._parts)
        text = re.sub(r'[ \t\f\v]+', ' ', text)
        text = re.sub(r' *\n *', '\n', text)
        return re.sub(r'\n{3,}', '\n\n', text).strip()


class GmailService:
    def __init__(self, credentials_path: Optional[str] = None, token_path: Optional[str] = None):
        self.credentials_path = Path(credentials_path) if credentials_path else Config.CREDENTIALS_PATH
        self.token_path = Path(token_path) if token_path else Config.TOKEN_PATH

    def _read_client_config(self) -> Dict[str, Any]:
        if not self.credentials_path.exists():
            raise FileNotFoundError(f'Missing OAuth credentials file: {self.credentials_path}')
        with open(self.credentials_path, 'r', encoding='utf-8') as file:
            return json.load(file)

    def get_credentials(self) -> Credentials:
        creds: Optional[Credentials] = None
        if self.token_path.exists():
            creds = Credentials.from_authorized_user_file(str(self.token_path), Config.GMAIL_SCOPES)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_config(
                    self._read_client_config(),
                    Config.GMAIL_SCOPES,
                    redirect_uri=Config.GOOGLE_REDIRECT_URI,
                )
                creds = flow.run_local_server(port=0)

            self.token_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.token_path, 'w', encoding='utf-8') as file:
                file.write(creds.to_json())

        return creds

    def get_service(self):
        return build('gmail', 'v1', credentials=self.get_credentials())

    @staticmethod
    def _is_retryable_rate_limit(error: HttpError) -> bool:
        if error.resp.status == 429:
            return True
        if error.resp.status != 403:
            return False

        try:
            payload = json.loads(error.content.decode('utf-8'))
        except (AttributeError, UnicodeDecodeError, ValueError):
            return False

        errors = payload.get('error', {}).get('errors', [])
        reasons = {item.get('reason') for item in errors}
        return bool(reasons & {'rateLimitExceeded', 'userRateLimitExceeded'})

    @classmethod
    def _execute_with_backoff(cls, request, max_retries: int = 5):
        for attempt in range(max_retries + 1):
            try:
                return request.execute()
            except HttpError as error:
                if not cls._is_retryable_rate_limit(error):
                    raise
                if attempt == max_retries:
                    raise RuntimeError(
                        'Gmail API rate limit persisted after retries. Wait about a minute, then try syncing again.'
                    ) from error
                delay = min(2 ** attempt, 16) + random.uniform(0, 0.5)
                time.sleep(delay)

    def fetch_recent_messages(self, max_results: int = 5):
        service = self.get_service()
        logger.info('Fetching up to %s inbox emails', max_results)
        response = self._execute_with_backoff(
            service.users().messages().list(userId='me', maxResults=max_results, q='in:inbox')
        )
        messages = response.get('messages', [])
        results = []

        for message in messages:
            msg = self._execute_with_backoff(
                service.users().messages().get(userId='me', id=message['id'], format='full')
            )
            results.append(self._format_message(msg))
        return results

    def _get_message_ids_by_labels(self, label_ids: List[str]):
        service = self.get_service()
        page_token = None
        message_ids = []
        while True:
            request_args = {
                'userId': 'me',
                'maxResults': 100,
                'labelIds': label_ids,
            }
            if page_token:
                request_args['pageToken'] = page_token
            response = self._execute_with_backoff(
                service.users().messages().list(**request_args)
            )
            message_ids.extend(
                message['id'] for message in response.get('messages', []) if message.get('id')
            )
            page_token = response.get('nextPageToken')
            if not page_token:
                return message_ids

    def get_inbox_message_ids(self):
        return self._get_message_ids_by_labels(['INBOX'])

    def get_inbox_label_stats(self) -> Dict[str, int]:
        service = self.get_service()
        response = self._execute_with_backoff(
            service.users().labels().get(userId='me', id='INBOX')
        )
        return {
            'messages_total': int(response.get('messagesTotal', 0)),
            'threads_total': int(response.get('threadsTotal', 0)),
            'messages_unread': int(response.get('messagesUnread', 0)),
            'threads_unread': int(response.get('threadsUnread', 0)),
        }

    def get_account_email(self) -> str:
        service = self.get_service()
        profile = self._execute_with_backoff(
            service.users().getProfile(userId='me')
        )
        return profile.get('emailAddress', '')

    def iter_inbox_messages(self):
        service = self.get_service()
        page_token = None
        logger.info('Fetching all inbox emails for priority analysis')
        while True:
            request_args = {'userId': 'me', 'maxResults': 100, 'q': 'in:inbox'}
            if page_token:
                request_args['pageToken'] = page_token
            response = self._execute_with_backoff(
                service.users().messages().list(**request_args)
            )

            for message in response.get('messages', []):
                try:
                    full_message = self._execute_with_backoff(
                        service.users().messages().get(
                            userId='me', id=message['id'], format='full'
                        )
                    )
                except HttpError as error:
                    logger.error(
                        'Could not fetch one Gmail email (HTTP %s)',
                        getattr(error.resp, 'status', 'unknown'),
                    )
                    continue
                yield self._format_message(full_message)

            page_token = response.get('nextPageToken')
            if not page_token:
                break

    @staticmethod
    def _get_header_value(headers, name: str) -> str:
        for header in headers:
            if str(header.get('name', '')).lower() == name.lower():
                value = header.get('value', '')
                if value:
                    return value.strip()
        return ''

    def _format_message(self, message):
        payload = message.get('payload', {})
        headers = payload.get('headers', [])
        sender = self._get_header_value(headers, 'From') or 'Unknown sender'
        subject = self._get_header_value(headers, 'Subject') or 'No Subject'
        date_value = self._get_header_value(headers, 'Date')

        if not date_value:
            internal_date = message.get('internalDate')
            if internal_date:
                try:
                    timestamp = int(str(internal_date)) / 1000
                    date_value = datetime.fromtimestamp(timestamp, timezone.utc).strftime('%a, %d %b %Y %H:%M:%S %z')
                except (TypeError, ValueError):
                    date_value = ''

        return {
            'id': message.get('id'),
            'sender': sender,
            'subject': subject,
            'date': date_value,
            'snippet': message.get('snippet', ''),
            'body': self._extract_body(payload),
        }

    def ensure_priority_labels(self):
        service = self.get_service()
        priority_names = ('AI/URGENT', 'AI/IMPORTANT', 'AI/NORMAL', 'AI/SPAM')
        priority_colors = {
            'AI/URGENT': {'textColor': '#ffffff', 'backgroundColor': '#fb4c2f'},
            'AI/IMPORTANT': {'textColor': '#000000', 'backgroundColor': '#ffad47'},
            'AI/NORMAL': {'textColor': '#ffffff', 'backgroundColor': '#4a86e8'},
            'AI/SPAM': {'textColor': '#ffffff', 'backgroundColor': '#666666'},
        }
        response = self._execute_with_backoff(service.users().labels().list(userId='me'))
        labels = {
            label.get('name'): label
            for label in response.get('labels', [])
            if label.get('name') and label.get('id')
        }

        for label_name in priority_names:
            if label_name not in labels:
                try:
                    created = self._execute_with_backoff(
                        service.users().labels().create(
                            userId='me',
                            body={
                                'name': label_name,
                                'labelListVisibility': 'labelShow',
                                'messageListVisibility': 'show',
                                'color': priority_colors[label_name],
                            },
                        )
                    )
                    labels[label_name] = created
                    logger.info('Created Gmail label: %s', label_name)
                except HttpError as error:
                    if error.resp.status != 409:
                        raise
                    refreshed = self._execute_with_backoff(service.users().labels().list(userId='me'))
                    labels = {
                        label.get('name'): label
                        for label in refreshed.get('labels', [])
                        if label.get('name') and label.get('id')
                    }
                    if label_name not in labels:
                        raise

            label = labels[label_name]
            if label.get('color') != priority_colors[label_name]:
                self._execute_with_backoff(
                    service.users().labels().patch(
                        userId='me',
                        id=label['id'],
                        body={'color': priority_colors[label_name]},
                    )
                )

        return {name: label['id'] for name, label in labels.items() if name in priority_names}

    def apply_priority_label(
        self,
        message_id: str,
        priority: str,
        labels_by_name: Optional[Dict[str, str]] = None,
    ) -> str:
        priority_labels = {
            'URGENT': 'AI/URGENT',
            'IMPORTANT': 'AI/IMPORTANT',
            'NORMAL': 'AI/NORMAL',
            'SPAM': 'AI/SPAM',
        }
        label_name = priority_labels.get((priority or '').strip().upper())
        if not label_name:
            raise ValueError('Unsupported AI priority; expected Urgent, Important, Normal, or Spam.')

        labels_by_name = labels_by_name or self.ensure_priority_labels()
        label_id = labels_by_name[label_name]
        service = self.get_service()
        message = self._execute_with_backoff(
            service.users().messages().get(userId='me', id=message_id, format='minimal')
        )
        label_names_by_id = {value: key for key, value in labels_by_name.items()}
        current_label_ids = message.get('labelIds', [])
        remove_label_ids = [
            current_id
            for current_id in current_label_ids
            if label_names_by_id.get(current_id, '').startswith('AI/') and current_id != label_id
        ]
        add_label_ids = [] if label_id in current_label_ids else [label_id]

        if add_label_ids or remove_label_ids:
            logger.info('Applying Gmail label: %s', label_name)
            self._execute_with_backoff(
                service.users().messages().modify(
                    userId='me',
                    id=message_id,
                    body={
                        'addLabelIds': add_label_ids,
                        'removeLabelIds': remove_label_ids,
                    },
                )
            )
        return label_name

    def _extract_body(self, payload):
        plain_parts = []
        html_parts = []
        self._collect_body_parts(payload, plain_parts, html_parts)

        if plain_parts:
            return '\n'.join(plain_parts).strip()
        if html_parts:
            parser = _HTMLTextExtractor()
            parser.feed('\n'.join(html_parts))
            parser.close()
            return parser.get_text()
        return ''

    def _collect_body_parts(self, payload, plain_parts, html_parts):
        mime_type = payload.get('mimeType')
        encoded_body = payload.get('body', {}).get('data')
        if encoded_body:
            decoded_body = base64.urlsafe_b64decode(
                encoded_body + '=' * (-len(encoded_body) % 4)
            ).decode('utf-8', errors='replace')
            if mime_type == 'text/plain':
                plain_parts.append(decoded_body)
            elif mime_type == 'text/html':
                html_parts.append(decoded_body)

        for part in payload.get('parts', []):
            self._collect_body_parts(part, plain_parts, html_parts)


if __name__ == '__main__':
    try:
        service = GmailService()
        emails = service.fetch_recent_messages(3)
        for email in emails:
            print(email['sender'], '-', email['subject'])
    except FileNotFoundError as exc:
        print(f'Configuration missing: {exc}')
    except HttpError as exc:
        print(f'Gmail API error: {exc}')
