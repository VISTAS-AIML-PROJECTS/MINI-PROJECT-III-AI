import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from config import Config

DB_PATH = Path(Config.DATABASE_PATH)
if not DB_PATH.is_absolute():
    DB_PATH = Path(__file__).resolve().parent / DB_PATH


def get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = get_connection()
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            gmail_id TEXT UNIQUE,
            sender TEXT,
            subject TEXT,
            body TEXT,
            summary TEXT,
            priority TEXT,
            reason TEXT,
            action_items TEXT,
            deadlines TEXT,
            suggested_reply TEXT,
            analysis_status TEXT NOT NULL DEFAULT 'complete',
            email_date TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        '''
    )

    existing_columns = {
        row['name'] for row in conn.execute('PRAGMA table_info(emails)').fetchall()
    }
    migrations = {
        'gmail_id': 'TEXT',
        'summary': "TEXT DEFAULT ''",
        'reason': "TEXT DEFAULT ''",
        'action_items': 'TEXT',
        'deadlines': 'TEXT',
        'suggested_reply': "TEXT DEFAULT ''",
        'analysis_status': "TEXT NOT NULL DEFAULT 'complete'",
        'email_date': 'TEXT',
    }
    for column, definition in migrations.items():
        if column not in existing_columns:
            conn.execute(f'ALTER TABLE emails ADD COLUMN {column} {definition}')

    conn.execute(
        'CREATE UNIQUE INDEX IF NOT EXISTS idx_emails_gmail_id ON emails(gmail_id)'
    )
    conn.commit()
    conn.close()


def _serialize_list(values: Optional[List[str]]) -> Optional[str]:
    if values is None:
        return None
    return json.dumps(values, ensure_ascii=False)


def _deserialize_list(value: Optional[str]) -> List[str]:
    if not value:
        return []
    try:
        parsed = json.loads(value)
        if isinstance(parsed, list):
            return parsed
    except (TypeError, ValueError):
        pass
    return [value]


def add_or_update_email(
    gmail_id: str,
    sender: str,
    subject: str,
    body: str,
    summary: str = '',
    priority: str = 'NORMAL',
    reason: str = '',
    action_items: Optional[List[str]] = None,
    deadlines: Optional[List[str]] = None,
    suggested_reply: str = '',
    analysis_status: str = 'complete',
    email_date: Optional[str] = None,
) -> bool:
    conn = get_connection()
    existing = conn.execute('SELECT 1 FROM emails WHERE gmail_id = ?', (gmail_id,)).fetchone()

    if existing:
        conn.execute(
            '''
            UPDATE emails
            SET sender = ?, subject = ?, body = ?, summary = ?, priority = ?, reason = ?,
                action_items = ?, deadlines = ?, suggested_reply = ?, analysis_status = ?, email_date = ?
            WHERE gmail_id = ?
            ''',
            (
                sender,
                subject,
                body,
                summary,
                priority,
                reason,
                _serialize_list(action_items),
                _serialize_list(deadlines),
                suggested_reply,
                analysis_status,
                email_date,
                gmail_id,
            ),
        )
        conn.commit()
        conn.close()
        return False

    conn.execute(
        '''
        INSERT INTO emails (
            gmail_id, sender, subject, body, summary, priority, reason,
            action_items, deadlines, suggested_reply, analysis_status, email_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''',
        (
            gmail_id,
            sender,
            subject,
            body,
            summary,
            priority,
            reason,
            _serialize_list(action_items),
            _serialize_list(deadlines),
            suggested_reply,
            analysis_status,
            email_date,
        ),
    )
    conn.commit()
    conn.close()
    return True


def get_recent_emails(
    limit: int = 10,
    priority: Optional[str] = None,
    search: str = '',
    gmail_ids: Optional[List[str]] = None,
) -> List[Dict[str, Any]]:
    conn = get_connection()
    query = 'SELECT * FROM emails WHERE 1=1'
    params: List[Any] = []

    if gmail_ids is not None:
        if not gmail_ids:
            conn.close()
            return []
        query += f" AND gmail_id IN ({','.join('?' for _ in gmail_ids)})"
        params.extend(gmail_ids)

    if priority:
        query += ' AND priority = ?'
        params.append(priority)

    if search:
        search_term = f'%{search.lower()}%'
        query += ' AND (LOWER(sender) LIKE ? OR LOWER(subject) LIKE ? OR LOWER(body) LIKE ? OR LOWER(summary) LIKE ?)'
        params.extend([search_term, search_term, search_term, search_term])

    query += ' ORDER BY created_at DESC LIMIT ?'
    params.append(limit)

    rows = conn.execute(query, params).fetchall()
    conn.close()

    result = []
    for row in rows:
        item = dict(row)
        item['action_items'] = _deserialize_list(item.get('action_items'))
        item['deadlines'] = _deserialize_list(item.get('deadlines'))
        result.append(item)
    return result


def get_email_by_id(email_id: int) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    row = conn.execute('SELECT * FROM emails WHERE id = ?', (email_id,)).fetchone()
    conn.close()
    if row is None:
        return None
    item = dict(row)
    item['action_items'] = _deserialize_list(item.get('action_items'))
    item['deadlines'] = _deserialize_list(item.get('deadlines'))
    return item


def get_dashboard_stats(gmail_ids: Optional[List[str]] = None) -> Dict[str, int]:
    conn = get_connection()
    query = 'SELECT priority, COUNT(*) AS count FROM emails'
    params: List[Any] = []
    if gmail_ids is not None:
        if not gmail_ids:
            conn.close()
            return {'total': 0, 'URGENT': 0, 'IMPORTANT': 0, 'NORMAL': 0, 'SPAM': 0}
        query += f" WHERE gmail_id IN ({','.join('?' for _ in gmail_ids)})"
        params.extend(gmail_ids)
    query += ' GROUP BY priority'
    rows = conn.execute(
        query, params
    ).fetchall()
    conn.close()

    stats = {'total': 0, 'URGENT': 0, 'IMPORTANT': 0, 'NORMAL': 0, 'SPAM': 0}
    for row in rows:
        priority = row['priority']
        count = row['count']
        stats['total'] += count
        if priority in stats:
            stats[priority] = count
    return stats


def email_exists(gmail_id: str) -> bool:
    conn = get_connection()
    row = conn.execute('SELECT 1 FROM emails WHERE gmail_id = ?', (gmail_id,)).fetchone()
    conn.close()
    return row is not None
