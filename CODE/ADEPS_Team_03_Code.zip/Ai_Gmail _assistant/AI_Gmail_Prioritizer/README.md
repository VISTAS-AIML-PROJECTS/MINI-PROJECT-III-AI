# AI Gmail Prioritizer

A Flask-based application that connects to Gmail, reads important emails, and uses AI to prioritize messages.

## Features
- Gmail OAuth login
- Inbox message retrieval
- Email priority scoring
- AI summary support via Ollama or other LLM endpoints
- SQLite database for saved mail records
- Simple dashboard and detail pages

## Project structure
- `app.py` - Flask entry point
- `config.py` - application configuration
- `gmail_service.py` - Gmail API integration
- `llama_service.py` - AI summary and priority classification
- `database.py` - SQLite helper utilities
- `templates/` - HTML UI templates
- `static/` - CSS and JavaScript
- `credentials/` - OAuth files

## Setup
1. Create a virtual environment.
2. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
3. Fill in your Google OAuth client secret in `credentials/credentials.json`.
4. Update `.env` with your secrets.
5. Run:
   ```bash
   python app.py
   ```

## Notes
This project is intended as a starter structure for a Gmail prioritization app and can be expanded with AI email filtering, user auth, and more advanced dashboard logic.
