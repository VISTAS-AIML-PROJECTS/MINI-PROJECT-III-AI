# AI-Driven Gmail Email Prioritization System Using Llama

An AI-powered web application that connects directly to a user's Gmail account, retrieves emails, analyzes them using a Llama-based Large Language Model, assigns intelligent priority levels, generates useful email insights, and reflects the AI priority back into Gmail using Gmail labels.

---

## 📌 Project Title

**AI-Driven Gmail Email Prioritization System Using Llama for Intelligent Email Management**

### Short Name

**AI Gmail Prioritizer**

---

## 📖 Abstract

Email has become one of the most important communication tools for students, employees, organizations, and businesses. However, users often receive a large number of emails every day, making it difficult to identify urgent and important messages quickly.

The proposed **AI-Driven Gmail Email Prioritization System** provides an intelligent solution by integrating directly with Gmail and using a Llama-based Large Language Model to analyze email content.

The system allows users to securely log in with their Google account using OAuth authentication. After authentication, the application retrieves emails from Gmail through the Gmail API. Each email is analyzed by the AI model and classified into four priority categories: **Urgent, Important, Normal, and Spam**.

In addition to priority classification, the system generates an email summary, identifies action items and deadlines, provides a reason for the assigned priority, and can generate a suggested reply.

The processed information is stored in an SQLite database and displayed through a web-based dashboard. The system also applies AI-generated Gmail labels such as `AI-URGENT`, `AI-IMPORTANT`, `AI-NORMAL`, and `AI-SPAM` to the corresponding Gmail messages.

The goal of the project is to reduce the time required for manually organizing emails and help users focus on the most relevant messages.

---

# 🎯 1. Problem Statement

Users receive many emails every day from different sources such as colleges, companies, clients, organizations, advertisements, newsletters, and personal contacts.

Manually checking every email can be time-consuming and important messages may be missed.

Existing email inboxes provide basic filtering and categorization, but they do not always understand the actual context, urgency, deadlines, or required actions contained within an email.

Therefore, an intelligent system is required to automatically analyze email content, determine its importance, summarize the message, identify required actions, and organize the inbox according to priority.

---

# 🎯 2. Objectives

The main objectives of this project are:

1. To securely connect the application with Gmail.
2. To retrieve emails using the Gmail API.
3. To analyze email content using a Llama-based AI model.
4. To automatically classify emails according to priority.
5. To identify urgent emails containing immediate deadlines or actions.
6. To generate concise summaries of emails.
7. To identify action items from email content.
8. To detect important dates and deadlines.
9. To provide suggested replies.
10. To display analyzed emails in an interactive dashboard.
11. To store email analysis results using SQLite.
12. To apply AI-generated labels directly to Gmail messages.

---

# 🧠 3. AI Priority Categories

The system classifies emails into four main categories.

## 🔴 URGENT

Emails requiring immediate attention.

Examples:

- Interview scheduled within 24 hours
- Assignment deadline today
- Payment due immediately
- Emergency notification
- Immediate approval request
- Important meeting happening soon

---

## 🟠 IMPORTANT

Emails that are important but do not require immediate action.

Examples:

- Office communication
- Client updates
- HR communication
- Project updates
- Assignment notifications
- Important academic information

---

## 🔵 NORMAL

General emails that do not require immediate attention.

Examples:

- Personal communication
- General notifications
- Regular updates
- Informational messages

---

## ⚫ SPAM

Unwanted or low-value messages.

Examples:

- Unwanted advertisements
- Promotional emails
- Marketing messages
- Unnecessary newsletters
- Suspicious or irrelevant messages

---

# 🔄 4. System Workflow

```text
                    USER
                     |
                     v
              WEB APPLICATION
                     |
                     v
              GOOGLE LOGIN
                     |
                     v
              GOOGLE OAUTH
                     |
                     v
                 GMAIL API
                     |
                     v
              FETCH EMAILS
                     |
                     v
              EMAIL PROCESSING
                     |
                     v
               LLAMA AI MODEL
                     |
          +----------+----------+
          |          |          |
          v          v          v
       PRIORITY   SUMMARY    ACTIONS
          |
          v
    DEADLINE DETECTION
          |
          v
      SQLITE DATABASE
          |
          v
      AI DASHBOARD
          |
          v
       GMAIL API
          |
          v
     APPLY AI LABELS
          |
          +-----------------------------+
          |             |               |
          v             v               v
      AI-URGENT   AI-IMPORTANT     AI-NORMAL
                                      |
                                      v
                                   AI-SPAM



14. Llama AI Processing

The Llama service receives email content and returns structured information.

Expected output:

                                   {
  "priority": "Urgent",
  "reason": "The email contains an interview scheduled for tomorrow.",
  "summary": "The company has scheduled an interview for tomorrow.",
  "action_items": [
    "Prepare for the interview",
    "Confirm attendance"
  ],
  "deadlines": [
    "Tomorrow"
  ],
  "suggested_reply": "Thank you for the interview invitation. I confirm my availability."
}