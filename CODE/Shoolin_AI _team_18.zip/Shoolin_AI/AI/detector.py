from ultralytics import YOLO

# Load YOLO model
model = YOLO("yolo11n.pt")

# Detect objects in the student image
results = model("defaulter_no_shoes.jpg", save=True)

print("AI detection completed!")
print("Check the runs/detect folder for the output image.")