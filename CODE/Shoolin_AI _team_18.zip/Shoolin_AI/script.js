// ==========================================
// SCHOOLIN AI - DEMO SCANNER
// ==========================================

function showImage(event) {
    let file = event.target.files[0];
    let preview = document.getElementById("imagePreview");

    if (file) {
        let imageURL = URL.createObjectURL(file);

        preview.innerHTML = `
            <img src="${imageURL}" alt="Student Image">
        `;
    }
}

function scanStudent() {

    let studentId =
        document.getElementById("studentId").value.trim();

    let studentName =
        document.getElementById("studentName").value.trim();

    let image =
        document.getElementById("studentImage").files[0];

    let result =
        document.getElementById("result");

    // Check Student ID
    if (studentId === "") {
        alert("Please enter Student ID");
        return;
    }

    // Check Student Name
    if (studentName === "") {
        alert("Please enter Student Name");
        return;
    }

    // Check Image
    if (!image) {
        alert("Please upload student image");
        return;
    }

    let time = new Date().toLocaleTimeString();

    // Get uploaded file name
    let fileName = image.name.toLowerCase();

    // ==========================================
    // DEMO AI RESULT
    // ==========================================

    if (fileName.includes("defaulter")) {

        result.innerHTML = `
            <h2>🔴 DEFAULTER</h2>

            <p><b>Student:</b> ${studentName}</p>
            <p><b>ID:</b> ${studentId}</p>

            <hr>

            <p>✅ ID Card</p>
            <p>✅ School Uniform</p>
            <p>✅ School Belt</p>
            <p>❌ Shoes Missing</p>

            <hr>

            <p>🕐 <b>Arrival Time:</b> ${time}</p>

            <p>⚠️ Student does not meet all requirements.</p>
        `;

    } else {

        result.innerHTML = `
            <h2>🟢 ALLOWED</h2>

            <p><b>Student:</b> ${studentName}</p>
            <p><b>ID:</b> ${studentId}</p>

            <hr>

            <p>✅ ID Card</p>
            <p>✅ School Uniform</p>
            <p>✅ School Belt</p>
            <p>✅ School Shoes</p>

            <hr>

            <p>🕐 <b>Arrival Time:</b> ${time}</p>

            <p>🎉 Student meets all requirements.</p>
        `;
    }
}