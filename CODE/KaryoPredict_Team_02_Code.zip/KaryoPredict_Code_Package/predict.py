import json, os
import numpy as np
from PIL import Image
import tensorflow as tf
from common import IMG_SIZE, MODEL_PATH
CLASS_FILE = os.path.join("models", "class_names.json")
_model = _classes = None
def load_model():
    global _model, _classes
    if _model is None:
        if not os.path.isfile(MODEL_PATH): raise FileNotFoundError(f"Model missing: {MODEL_PATH}")
        if not os.path.isfile(CLASS_FILE): raise FileNotFoundError(f"Class names missing: {CLASS_FILE}")
        _model = tf.keras.models.load_model(MODEL_PATH)
        with open(CLASS_FILE, encoding="utf-8") as f: _classes = json.load(f)
        if len(_classes) != 6: raise ValueError("class_names.json must contain six classes")
    return _model, _classes
def predict_image(path):
    model, classes = load_model()
    with Image.open(path) as im: arr = np.asarray(im.convert("RGB").resize((IMG_SIZE[1], IMG_SIZE[0])), dtype=np.float32)[None, ...]
    scores = np.asarray(model.predict(arr, verbose=0))[0]
    if scores.size != len(classes) or not np.all(np.isfinite(scores)): raise ValueError("Invalid model output")
    total = float(scores.sum())
    if total > 0: scores = scores / total
    ordered = sorted(zip(classes, scores.tolist()), key=lambda x: x[1], reverse=True)
    return {"predicted_class": ordered[0][0], "top_score": float(ordered[0][1]), "second_score": float(ordered[1][1]), "prediction_margin": float(ordered[0][1]-ordered[1][1]), "scores": dict(zip(classes, scores.tolist()))}
