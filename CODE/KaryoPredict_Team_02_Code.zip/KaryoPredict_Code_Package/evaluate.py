import json, os
import numpy as np
import tensorflow as tf
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix
from common import CLASS_NAMES, MODEL_PATH
def main():
    os.makedirs("results",exist_ok=True)
    ds=tf.keras.utils.image_dataset_from_directory("dataset/test",class_names=CLASS_NAMES,image_size=(160,160),batch_size=16,shuffle=False)
    model=tf.keras.models.load_model(MODEL_PATH); y=np.concatenate([labels.numpy() for _,labels in ds]); pred=np.argmax(model.predict(ds,verbose=1),axis=1)
    rep=classification_report(y,pred,labels=list(range(6)),target_names=CLASS_NAMES,output_dict=True,zero_division=0)
    m={"class_names":CLASS_NAMES,"accuracy":float(accuracy_score(y,pred)),"precision_macro":float(precision_score(y,pred,average="macro",zero_division=0)),"recall_macro":float(recall_score(y,pred,average="macro",zero_division=0)),"f1_macro":float(f1_score(y,pred,average="macro",zero_division=0)),"f1_weighted":float(f1_score(y,pred,average="weighted",zero_division=0)),"per_class":{c:{"precision":rep[c]["precision"],"recall":rep[c]["recall"],"f1":rep[c]["f1-score"],"support":rep[c]["support"]} for c in CLASS_NAMES},"confusion_matrix":confusion_matrix(y,pred,labels=list(range(6))).tolist()}
    with open("results/metrics.json","w",encoding="utf-8") as f: json.dump(m,f,indent=2)
    with open("results/classification_report.txt","w",encoding="utf-8") as f: f.write(classification_report(y,pred,target_names=CLASS_NAMES,zero_division=0))
    print(json.dumps({k:m[k] for k in ["accuracy","precision_macro","recall_macro","f1_macro","f1_weighted"]},indent=2))
if __name__=="__main__": main()
