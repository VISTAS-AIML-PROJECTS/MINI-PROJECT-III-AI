# KaryoPredict code-only package

This small package includes the KaryoPredict Flask structure and `preprocess.py`. It does not include a dataset or trained model, so the ZIP stays well below 25 MB.

## Setup (Windows PowerShell)
Use Python 3.10/3.11 for best TensorFlow compatibility:
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Expected dataset folders
`dataset/train/<class>`, `dataset/val/<class>`, and `dataset/test/<class>` for `Down`, `Edwards`, `Klinefelter`, `Normal`, `Patau`, and `Turner`.

## Preprocess existing images (does not generate images)
```powershell
python preprocess.py --input dataset --output dataset_preprocessed --size 160
```
Check split/class counts before training. Keep the original dataset as a backup.

## Run
```powershell
python train.py
python evaluate.py
python app.py
```
For prediction-only mode, provide a compatible trained model at `models/karyopredict_model.keras` and `models/class_names.json`.

Educational prototype only; not a medical diagnostic tool. Scores are not calibrated clinical probabilities.
