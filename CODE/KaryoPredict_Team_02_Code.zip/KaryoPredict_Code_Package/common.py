import os
import tensorflow as tf
from PIL import Image
CLASS_NAMES = ["Down", "Edwards", "Klinefelter", "Normal", "Patau", "Turner"]
IMG_SIZE = (160, 160)
EXT = (".png", ".jpg", ".jpeg", ".bmp", ".webp")
MODEL_PATH = os.path.join("models", "karyopredict_model.keras")
def list_split(data_dir, split, quiet=False):
    paths, labels = [], []
    for i, cls in enumerate(CLASS_NAMES):
        folder = os.path.join(data_dir, split, cls)
        if not os.path.isdir(folder): raise SystemExit(f"Missing folder: {folder}")
        start = len(paths)
        for name in sorted(os.listdir(folder)):
            if not name.lower().endswith(EXT): continue
            path = os.path.join(folder, name)
            try:
                with Image.open(path) as im: im.verify()
                paths.append(path); labels.append(i)
            except Exception: print("Skipping unreadable image:", path)
        if len(paths) == start: raise SystemExit(f"No valid images in {folder}")
    if not quiet: print(f"{split}: {len(paths)} images")
    return paths, labels
def load_img(path, label):
    image = tf.io.decode_image(tf.io.read_file(path), channels=3, expand_animations=False)
    image.set_shape([None, None, 3])
    return tf.image.resize(image, IMG_SIZE), label
