import os, secrets, json
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort, send_from_directory
from werkzeug.utils import secure_filename
from predict import predict_image
BASE=os.path.dirname(os.path.abspath(__file__)); UPLOAD=os.path.join(BASE,"uploads"); os.makedirs(UPLOAD,exist_ok=True)
app=Flask(__name__); app.secret_key=os.environ.get("KARYOPREDICT_SECRET",secrets.token_hex(32)); app.config["MAX_CONTENT_LENGTH"]=8*1024*1024
ALLOWED={".png",".jpg",".jpeg",".bmp",".webp"}
def read_json(rel):
    try:
        with open(os.path.join(BASE,rel),encoding="utf-8") as f: return json.load(f)
    except (OSError,ValueError): return {}
@app.route("/")
def index(): return render_template("index.html")
@app.route("/dashboard")
def dashboard(): return render_template("dashboard.html")
@app.route("/classify",methods=["POST"])
def classify():
    file=request.files.get("image")
    if not file or not file.filename: flash("Choose an image first.","error"); return redirect(url_for("dashboard"))
    ext=os.path.splitext(secure_filename(file.filename))[1].lower()
    if ext not in ALLOWED: flash("Use PNG, JPG, JPEG, BMP, or WEBP.","error"); return redirect(url_for("dashboard"))
    name=secrets.token_hex(12)+ext; path=os.path.join(UPLOAD,name); file.save(path)
    try: result=predict_image(path)
    except Exception as e:
        os.remove(path); flash(f"Prediction unavailable: {e}","error"); return redirect(url_for("dashboard"))
    session["pending"]={"image_file":name,"result":result}; return redirect(url_for("prediction"))
@app.route("/prediction")
def prediction():
    p=session.get("pending")
    if not p: flash("Upload an image first.","error"); return redirect(url_for("dashboard"))
    return render_template("prediction.html",p=p,r=p["result"],metrics=read_json("results/metrics.json"),history=read_json("results/training_history.json"))
@app.route("/uploads/<name>")
def uploaded(name):
    if os.path.basename(name)!=name: abort(404)
    return send_from_directory(UPLOAD,name)
@app.errorhandler(413)
def too_large(_): flash("Maximum upload size is 8 MB.","error"); return redirect(url_for("dashboard"))
if __name__=="__main__": app.run(debug=True)
