"""Preprocess existing images; this script does not generate or invent images."""
import argparse
from pathlib import Path
from PIL import Image, ImageOps
CLASSES = ["Down", "Edwards", "Klinefelter", "Normal", "Patau", "Turner"]
SPLITS = ["train", "val", "test"]
EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
def main():
    p = argparse.ArgumentParser(description="Validate and resize an existing dataset")
    p.add_argument("--input", default="dataset")
    p.add_argument("--output", default="dataset_preprocessed")
    p.add_argument("--size", type=int, default=160)
    a = p.parse_args()
    if not 32 <= a.size <= 1024: p.error("--size must be between 32 and 1024")
    src_root, out_root = Path(a.input), Path(a.output)
    if not src_root.is_dir(): raise SystemExit(f"Input dataset not found: {src_root}")
    processed = skipped = 0
    for split in SPLITS:
        for cls in CLASSES:
            src_dir = src_root / split / cls
            if not src_dir.is_dir():
                print("Warning: missing folder", src_dir); continue
            dst_dir = out_root / split / cls; dst_dir.mkdir(parents=True, exist_ok=True)
            for src in src_dir.iterdir():
                if not src.is_file() or src.suffix.lower() not in EXTS: continue
                try:
                    with Image.open(src) as im:
                        im = ImageOps.exif_transpose(im).convert("RGB")
                        im = im.resize((a.size, a.size), Image.Resampling.LANCZOS)
                        im.save(dst_dir / (src.stem + ".jpg"), "JPEG", quality=92, optimize=True)
                    processed += 1
                except Exception as e:
                    skipped += 1; print(f"Skipped {src}: {e}")
    print(f"Finished: {processed} images processed; {skipped} skipped. Output: {out_root.resolve()}")
if __name__ == "__main__": main()
