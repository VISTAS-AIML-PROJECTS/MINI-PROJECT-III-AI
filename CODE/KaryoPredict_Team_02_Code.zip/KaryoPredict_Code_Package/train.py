import json, os, time
import tensorflow as tf
from common import CLASS_NAMES, IMG_SIZE
DATASET_DIR="dataset"; BATCH_SIZE=16; EPOCHS=23; SEED=42
def main():
    os.makedirs("models", exist_ok=True); os.makedirs("results", exist_ok=True)
    train = tf.keras.utils.image_dataset_from_directory("dataset/train", class_names=CLASS_NAMES, image_size=IMG_SIZE, batch_size=BATCH_SIZE, seed=SEED)
    val = tf.keras.utils.image_dataset_from_directory("dataset/val", class_names=CLASS_NAMES, image_size=IMG_SIZE, batch_size=BATCH_SIZE, shuffle=False)
    test = tf.keras.utils.image_dataset_from_directory("dataset/test", class_names=CLASS_NAMES, image_size=IMG_SIZE, batch_size=BATCH_SIZE, shuffle=False)
    with open("models/class_names.json","w",encoding="utf-8") as f: json.dump(CLASS_NAMES,f,indent=2)
    aug=tf.keras.Sequential([tf.keras.layers.RandomRotation(.04),tf.keras.layers.RandomZoom(.08),tf.keras.layers.RandomTranslation(.04,.04)])
    model=tf.keras.Sequential([tf.keras.layers.Input((*IMG_SIZE,3)),aug,tf.keras.layers.Rescaling(1./255),tf.keras.layers.Conv2D(32,3,padding="same",activation="relu"),tf.keras.layers.BatchNormalization(),tf.keras.layers.MaxPooling2D(),tf.keras.layers.Conv2D(64,3,padding="same",activation="relu"),tf.keras.layers.BatchNormalization(),tf.keras.layers.MaxPooling2D(),tf.keras.layers.Conv2D(128,3,padding="same",activation="relu"),tf.keras.layers.BatchNormalization(),tf.keras.layers.MaxPooling2D(),tf.keras.layers.GlobalAveragePooling2D(),tf.keras.layers.Dense(128,activation="relu"),tf.keras.layers.Dropout(.4),tf.keras.layers.Dense(6,activation="softmax")])
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-4),loss="sparse_categorical_crossentropy",metrics=["accuracy"])
    callbacks=[tf.keras.callbacks.ModelCheckpoint("models/best_model.keras",monitor="val_loss",save_best_only=True),tf.keras.callbacks.EarlyStopping(monitor="val_loss",patience=5,restore_best_weights=True),tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss",factor=.5,patience=2,min_lr=1e-7)]
    start=time.perf_counter(); hist=model.fit(train,validation_data=val,epochs=EPOCHS,callbacks=callbacks); elapsed=time.perf_counter()-start
    model=tf.keras.models.load_model("models/best_model.keras"); model.save("models/karyopredict_model.keras"); model.evaluate(test)
    with open("results/training_history.json","w",encoding="utf-8") as f: json.dump(hist.history,f,indent=2)
    with open("results/training_info.json","w",encoding="utf-8") as f: json.dump({"epochs_completed":len(hist.epoch),"training_seconds":round(elapsed,2),"image_size":list(IMG_SIZE),"batch_size":BATCH_SIZE},f,indent=2)
    print(f"Training time: {elapsed/60:.2f} minutes; epochs completed: {len(hist.epoch)}")
if __name__=="__main__": main()
