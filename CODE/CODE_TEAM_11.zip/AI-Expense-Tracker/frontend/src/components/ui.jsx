import { useCallback, useEffect, useRef, useState } from "react";
import { ToastContext } from "./toastContext";

/* ---------------------------------------------------------------------------
   Small shared UI pieces: toast messages, modal, confirm dialog, progress bar.
--------------------------------------------------------------------------- */

// ---- Toasts (replace the browser alert() pop-ups) --------------------------
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const nextId = useRef(1);

  const notify = useCallback((message, type = "success") => {
    const id = nextId.current++;
    setToasts((current) => [...current, { id, message, type }]);
    setTimeout(() => setToasts((current) => current.filter((t) => t.id !== id)), type === "error" ? 6000 : 3500);
  }, []);

  return (
    <ToastContext.Provider value={notify}>
      {children}
      <div className="toast-stack" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.type}`} role="status">
            <span>{t.type === "error" ? "⚠️" : t.type === "info" ? "ℹ️" : "✅"}</span>
            <p>{t.message}</p>
            <button
              type="button"
              aria-label="Dismiss message"
              onClick={() => setToasts((current) => current.filter((x) => x.id !== t.id))}
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

// ---- Modal ------------------------------------------------------------------
export function Modal({ title, onClose, children, wide = false }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button type="button" className="modal-close" onClick={onClose} aria-label="Close">×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({ title, children, confirmLabel = "Delete", busy = false, danger = true, onConfirm, onCancel }) {
  return (
    <Modal title={title} onClose={busy ? () => {} : onCancel}>
      <div className="confirm-body">{children}</div>
      <div className="modal-actions">
        <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={busy}>Cancel</button>
        <button type="button" className={`btn ${danger ? "btn-danger" : "btn-primary"}`} onClick={onConfirm} disabled={busy}>
          {busy ? "Please wait…" : confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

// ---- Progress bar -------------------------------------------------------------
export function ProgressBar({ percent, tone = "primary", label }) {
  const safe = Math.max(0, Math.min(100, Number(percent) || 0));
  return (
    <div
      className="progress"
      role="progressbar"
      aria-valuenow={Math.round(safe)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
    >
      <div className={`progress-fill tone-${tone}`} style={{ width: `${safe}%` }} />
    </div>
  );
}

export function EmptyState({ icon = "📭", title, children }) {
  return (
    <div className="empty-state">
      <div className="empty-icon" aria-hidden="true">{icon}</div>
      <strong>{title}</strong>
      {children && <p>{children}</p>}
    </div>
  );
}

export function SectionHeader({ title, subtitle, badge, children }) {
  return (
    <div className="section-head">
      <div>
        <h2>
          {title}
          {badge && <span className="badge badge-soft">{badge}</span>}
        </h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {children && <div className="section-head-actions">{children}</div>}
    </div>
  );
}
