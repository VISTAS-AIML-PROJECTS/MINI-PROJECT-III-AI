import { useState } from "react";
import { api } from "../api";
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, formatINR } from "../utils/finance";
import { ConfirmDialog, Modal } from "./ui";
import { useToast } from "./toastContext";

/*
  Recent Transactions with Edit and Delete (Feature 8).
  After any change we call onChanged(), which reloads ALL data in App.jsx.
  Every card that uses transactions (totals, charts, balance, goals,
  suggestions, health score ...) is calculated from that same list, so
  everything updates together.
*/
export default function TransactionList({ transactions, onChanged }) {
  const notify = useToast();
  const [showAll, setShowAll] = useState(false);
  const [editing, setEditing] = useState(null);   // transaction being edited
  const [deleting, setDeleting] = useState(null); // transaction waiting for delete confirmation
  const [busy, setBusy] = useState(false);

  const visible = showAll ? transactions : transactions.slice(0, 5);

  const confirmDelete = async () => {
    setBusy(true);
    try {
      await api(`/transactions/${deleting.id}`, { method: "DELETE" });
      notify("Transaction deleted.");
      setDeleting(null);
      await onChanged();
    } catch (error) {
      notify(error.message, "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="recent-transactions">
      <div className="section-header list-header">
        <div>
          <h2>{showAll ? "All Transactions" : "Recent Transactions"}</h2>
          <p>{showAll ? `All ${transactions.length} of your transactions` : "Your latest income and expenses"}</p>
        </div>
        {transactions.length > 5 && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setShowAll(!showAll)}>
            {showAll ? "Show fewer" : `Show all (${transactions.length})`}
          </button>
        )}
      </div>

      {transactions.length === 0 ? (
        <div className="no-transactions">
          <p>No transactions available yet. Use “Add Income” or “Add Expense” to get started.</p>
        </div>
      ) : (
        <div className={`transaction-list ${showAll ? "scrollable" : ""}`}>
          {visible.map((transaction) => (
            <div className="transaction-item with-actions" key={transaction.id}>
              <div className="transaction-info">
                <div className="transaction-name">{transaction.category}</div>
                <div className="transaction-description">{transaction.description || "No description"}</div>
              </div>

              <div className="transaction-date">{transaction.date}</div>

              <div className={transaction.type === "income" ? "transaction-amount income" : "transaction-amount expense"}>
                {transaction.type === "income" ? "+" : "-"}
                {formatINR(transaction.amount)}
              </div>

              <div className="row-actions">
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing(transaction)}>Edit</button>
                <button type="button" className="btn btn-danger-soft btn-sm" onClick={() => setDeleting(transaction)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <EditTransactionModal
          transaction={editing}
          onClose={() => setEditing(null)}
          onSaved={async () => {
            setEditing(null);
            notify("Transaction updated.");
            await onChanged();
          }}
        />
      )}

      {deleting && (
        <ConfirmDialog
          title="Delete this transaction?"
          confirmLabel="Delete transaction"
          busy={busy}
          onCancel={() => setDeleting(null)}
          onConfirm={confirmDelete}
        >
          <p>This transaction will be permanently removed and your totals and charts will be recalculated.</p>
          <div className="confirm-summary">
            <span>{deleting.type === "income" ? "Income" : "Expense"} · {deleting.category}</span>
            <strong>{formatINR(deleting.amount)}</strong>
            <small>{deleting.description || "No description"} · {deleting.date}</small>
          </div>
        </ConfirmDialog>
      )}
    </div>
  );
}

function EditTransactionModal({ transaction, onClose, onSaved }) {
  const notify = useToast();
  const [form, setForm] = useState({
    type: transaction.type,
    amount: String(transaction.amount),
    category: transaction.category,
    description: transaction.description || "",
    date: transaction.date,
  });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const categories = form.type === "expense" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;
  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  // Changing the type changes the list of categories, so reset an invalid category.
  const changeType = (e) => {
    const type = e.target.value;
    const valid = (type === "expense" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES).includes(form.category);
    setForm({ ...form, type, category: valid ? form.category : "" });
  };

  const submit = async (e) => {
    e.preventDefault();
    const amount = Number(form.amount);
    if (!form.amount || !Number.isFinite(amount) || amount <= 0) return setError("Please enter an amount greater than ₹0.");
    if (!form.category) return setError("Please choose a category.");
    if (!form.date) return setError("Please choose a date.");
    setError("");
    setSaving(true);
    try {
      await api(`/transactions/${transaction.id}`, { method: "PUT", body: { ...form, amount } });
      await onSaved();
    } catch (err) {
      setError(err.message);
      notify(err.message, "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title="Edit Transaction" onClose={onClose}>
      <form className="modal-form" onSubmit={submit} noValidate>
        <label>
          Transaction Type
          <select value={form.type} onChange={changeType}>
            <option value="expense">Expense</option>
            <option value="income">Income</option>
          </select>
        </label>

        <label>
          Amount (₹)
          <input type="number" min="0.01" step="0.01" value={form.amount} onChange={update("amount")} autoFocus />
        </label>

        <label>
          Category
          <select value={form.category} onChange={update("category")}>
            <option value="">Select category</option>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>

        <label>
          Description
          <input type="text" maxLength={200} placeholder="Optional description" value={form.description} onChange={update("description")} />
        </label>

        <label>
          Date
          <input type="date" value={form.date} onChange={update("date")} />
        </label>

        {error && <p className="form-error" role="alert">{error}</p>}

        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? "Saving…" : "Save Changes"}</button>
        </div>
      </form>
    </Modal>
  );
}
