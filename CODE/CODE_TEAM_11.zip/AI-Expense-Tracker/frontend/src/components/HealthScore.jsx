import { useMemo } from "react";
import { computeHealthScore } from "../utils/finance";
import { EmptyState, ProgressBar, SectionHeader } from "./ui";

const COLORS = { good: "#16a34a", warn: "#d97706", bad: "#dc2626" };

/* Financial Health Score (Feature 7). The formula is documented in utils/finance.js */
export default function HealthScore({ transactions, bills }) {
  const result = useMemo(() => computeHealthScore(transactions, bills), [transactions, bills]);

  return (
    <section className="card">
      <SectionHeader title="Financial Health Score" subtitle="A simple look at your money habits" badge="Estimate" />

      {!result.available ? (
        <EmptyState icon="📊" title="Score not available yet">{result.reason}</EmptyState>
      ) : (
        <>
          <div className="score-layout">
            <ScoreGauge score={result.score} tone={result.tone} level={result.level} />
            <div className="score-intro">
              <h3>{result.level}</h3>
              <p>
                Your score is calculated from {result.factors.filter((f) => f.available).length} of {result.factors.length} factors.
                Factors without enough data are left out instead of counting against you.
              </p>
              {result.limited && (
                <p className="info-strip">Only {result.monthCount} month{result.monthCount === 1 ? "" : "s"} of data so far - the score will become more reliable as you add more.</p>
              )}
            </div>
          </div>

          <div className="factor-list">
            {result.factors.map((f) => (
              <div className={`factor ${f.available ? "" : "factor-off"}`} key={f.id}>
                <div className="factor-head">
                  <strong>{f.name}</strong>
                  <span>{f.available ? `${f.points.toFixed(1)} / ${f.weight} pts` : "Not counted"}</span>
                </div>
                <ProgressBar
                  percent={f.available ? (f.points / f.weight) * 100 : 0}
                  tone={!f.available ? "muted" : f.points / f.weight >= 0.7 ? "good" : f.points / f.weight >= 0.4 ? "warn" : "bad"}
                  label={f.name}
                />
                <p className="factor-value">{f.value}</p>
                <p className="muted small-text">{f.explanation}</p>
              </div>
            ))}
          </div>

          {result.improvements.length > 0 && (
            <div className="summary-list">
              <h4>How to improve</h4>
              <ul>{result.improvements.map((tip) => <li key={tip}>{tip}</li>)}</ul>
            </div>
          )}
        </>
      )}

      <p className="muted small-text">
        This score is an estimate for educational purposes only. It is not a credit score or a professional financial assessment.
      </p>
    </section>
  );
}

function ScoreGauge({ score, tone, level }) {
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - score / 100);
  return (
    <div className="gauge" role="img" aria-label={`Financial health score ${score} out of 100, ${level}`}>
      <svg viewBox="0 0 140 140" width="150" height="150">
        <circle cx="70" cy="70" r={radius} fill="none" stroke="#e8ecf3" strokeWidth="12" />
        <circle
          cx="70" cy="70" r={radius} fill="none" stroke={COLORS[tone]} strokeWidth="12" strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={offset} transform="rotate(-90 70 70)"
          style={{ transition: "stroke-dashoffset .6s ease" }}
        />
      </svg>
      <div className="gauge-text"><strong>{score}</strong><span>out of 100</span></div>
    </div>
  );
}
