import { useMemo } from "react";
import { computeBalanceSummary, formatINR, formatPercent } from "../utils/finance";
import { SectionHeader } from "./ui";

/* About My Balance (Feature 3) - explains the current position in simple words. */
export default function BalanceCard({ transactions }) {
  const s = useMemo(() => computeBalanceSummary(transactions), [transactions]);
  const positive = s.balance >= 0;

  return (
    <section className="card balance-card">
      <SectionHeader title="About My Balance" subtitle="Your current financial position in simple language" />

      <div className={`balance-hero ${positive ? "is-positive" : "is-negative"}`}>
        <span>Current Balance</span>
        <strong>{formatINR(s.balance)}</strong>
        <small>Total Income − Total Expenses (same as Total Savings above)</small>
      </div>

      <div className="stat-grid three">
        <div className="stat-panel">
          <h4>Income Overview</h4>
          <dl>
            <div><dt>Total income</dt><dd>{formatINR(s.totalIncome)}</dd></div>
            <div><dt>Income this month</dt><dd>{formatINR(s.monthIncome)}</dd></div>
            <div>
              <dt>Income spent</dt>
              <dd>{s.percentSpent === null ? "N/A" : formatPercent(s.percentSpent)}</dd>
            </div>
          </dl>
        </div>

        <div className="stat-panel">
          <h4>Expense Overview</h4>
          <dl>
            <div><dt>Total expenses</dt><dd>{formatINR(s.totalExpenses)}</dd></div>
            <div><dt>Largest category</dt><dd>{s.topCategory ? s.topCategory.name : "N/A"}</dd></div>
            <div>
              <dt>Spent in it</dt>
              <dd>{s.topCategory ? `${formatINR(s.topCategory.amount)} (${formatPercent(s.topCategory.percent)})` : "N/A"}</dd>
            </div>
          </dl>
        </div>

        <div className="stat-panel">
          <h4>Savings Overview</h4>
          <dl>
            <div>
              <dt>Savings</dt>
              <dd className={positive ? "text-good" : "text-bad"}>{formatINR(s.balance)}</dd>
            </div>
            <div>
              <dt>Savings rate</dt>
              <dd className={s.savingsRate === null ? "" : s.savingsRate >= 0 ? "text-good" : "text-bad"}>
                {s.savingsRate === null ? "N/A (no income)" : formatPercent(s.savingsRate)}
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="summary-list">
        <h4>Financial Summary</h4>
        <ul>
          {s.statements.map((text) => <li key={text}>{text}</li>)}
        </ul>
      </div>
    </section>
  );
}
