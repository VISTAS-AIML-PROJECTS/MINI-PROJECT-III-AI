import { useMemo } from "react";
import {
  Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { expenseTotalsByCategory, formatCompactINR, formatINR, monthLabel, monthKey, sumByType } from "../utils/finance";

const CHART_COLORS = ["#2563eb", "#7c3aed", "#0891b2", "#d97706", "#db2777", "#16a34a", "#dc2626", "#64748b"];
const tooltipStyle = { borderRadius: "8px", border: "1px solid #e7eaf0" };

/*
  Analytics: Expense by Category, Income vs Expenses, AI Spending Analysis,
  Monthly Spending Trend, Expense Prediction, Budget Recommendation.
  (Your original calculations, moved here from App.jsx so App.jsx stays readable.)
*/
export default function Analytics({ transactions }) {
  const data = useMemo(() => {
    const totalIncome = sumByType(transactions, "income");
    const totalExpenses = sumByType(transactions, "expense");

    const byCategory = expenseTotalsByCategory(transactions);
    const expenseChartData = Object.entries(byCategory).map(([name, value], index) => ({
      name, value, color: CHART_COLORS[index % CHART_COLORS.length],
    }));

    const budgetRecommendations = expenseChartData.map((item) => {
      const spendingPercentage = totalIncome > 0 ? (item.value / totalIncome) * 100 : 0;
      let recommendedAmount = item.value;
      if (spendingPercentage >= 25) recommendedAmount = item.value * 0.8;
      else if (spendingPercentage >= 15) recommendedAmount = item.value * 0.9;
      return { category: item.name, currentAmount: item.value, recommendedAmount, spendingPercentage };
    });

    const top = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0];
    const spendingAnalysis =
      top && totalExpenses > 0 ? { category: top[0], amount: top[1], percentage: (top[1] / totalExpenses) * 100 } : null;

    const monthly = transactions
      .filter((t) => t.type === "expense")
      .reduce((months, t) => {
        const key = monthKey(t.date) || "Unknown";
        months[key] = (months[key] || 0) + Number(t.amount);
        return months;
      }, {});
    const monthlySpendingData = Object.entries(monthly)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, amount]) => ({ month, amount, monthLabel: monthLabel(month) }));

    const averageMonthlyExpense = monthlySpendingData.length
      ? monthlySpendingData.reduce((t, m) => t + m.amount, 0) / monthlySpendingData.length
      : 0;

    let predictedNextMonthExpense = averageMonthlyExpense;
    let predictionMethod = "average";
    if (monthlySpendingData.length >= 2) {
      const last = monthlySpendingData[monthlySpendingData.length - 1].amount;
      const previous = monthlySpendingData[monthlySpendingData.length - 2].amount;
      predictedNextMonthExpense = Math.max(0, last + (last - previous));
      predictionMethod = "trend";
    }

    return {
      totalIncome, totalExpenses, expenseChartData, budgetRecommendations, spendingAnalysis,
      monthlySpendingData, predictedNextMonthExpense, predictionMethod,
      incomeExpenseChartData: [
        { name: "Income", amount: totalIncome, fill: "#2563eb" },
        { name: "Expenses", amount: totalExpenses, fill: "#dc2626" },
      ],
    };
  }, [transactions]);

  const {
    totalIncome, totalExpenses, expenseChartData, budgetRecommendations, spendingAnalysis,
    monthlySpendingData, predictedNextMonthExpense, predictionMethod, incomeExpenseChartData,
  } = data;

  return (
    <div className="analytics-section">
      <div className="section-header">
        <div>
          <h2>Analytics</h2>
          <p>Understand where your money is going</p>
        </div>
      </div>

      <div className="analytics-cards">
        <div className="analytics-card">
          <h3>Expense by Category</h3>
          {expenseChartData.length === 0 ? (
            <p className="analytics-empty">No expense data available yet.</p>
          ) : (
            <>
              <div className="expense-chart" aria-label="Expense distribution by category">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={expenseChartData} dataKey="value" nameKey="name" cx="50%" cy="50%"
                      innerRadius={52} outerRadius={78} paddingAngle={3} stroke="none" labelLine={false}
                      label={({ value }) => `${((value / totalExpenses) * 100).toFixed(1)}%`}
                    >
                      {expenseChartData.map((entry) => <Cell key={entry.name} fill={entry.color} />)}
                    </Pie>
                    <Tooltip formatter={(value) => [formatINR(value), "Amount"]} contentStyle={tooltipStyle} />
                    <Legend verticalAlign="bottom" height={55} iconType="circle" />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="category-legend">
                {expenseChartData.map((entry) => (
                  <div className="category-row" key={entry.name}>
                    <span className="category-name"><i style={{ backgroundColor: entry.color }}></i>{entry.name}</span>
                    <strong>{formatINR(entry.value)}</strong>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        <div className="analytics-card">
          <h3>Income vs Expenses</h3>
          <div className="income-expense-row">
            <div><span>Income</span><strong>{formatINR(totalIncome)}</strong></div>
            <div><span>Expenses</span><strong>{formatINR(totalExpenses)}</strong></div>
          </div>

          {totalIncome === 0 && totalExpenses === 0 ? (
            <p className="analytics-empty">Add income or expenses to view a comparison.</p>
          ) : (
            <div className="income-expense-chart" aria-label="Income compared with expenses">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={incomeExpenseChartData} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                  <CartesianGrid vertical={false} stroke="#edf0f3" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: "#6b7280", fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} width={56} tick={{ fill: "#8a93a3", fontSize: 11 }} tickFormatter={formatCompactINR} />
                  <Tooltip formatter={(value) => [formatINR(value), "Amount"]} cursor={{ fill: "#f4f7fb" }} contentStyle={tooltipStyle} />
                  <Bar dataKey="amount" radius={[6, 6, 0, 0]}>
                    {incomeExpenseChartData.map((entry) => <Cell key={entry.name} fill={entry.fill} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="analytics-card ai-analysis-card">
          <h3>AI Spending Analysis</h3>
          {spendingAnalysis ? (
            <>
              <p className="ai-analysis-text">Your highest spending category is <strong>{spendingAnalysis.category}</strong>.</p>
              <div className="ai-analysis-amount">{formatINR(spendingAnalysis.amount)}</div>
              <p className="ai-analysis-text">This represents <strong>{spendingAnalysis.percentage.toFixed(1)}%</strong> of your total expenses.</p>
              <div className="ai-analysis-tip">Consider reviewing your spending in this category to improve your savings.</div>
            </>
          ) : (
            <p className="analytics-empty">Add some expenses to receive spending insights.</p>
          )}
        </div>
      </div>

      <div className="analytics-card monthly-trend-card">
        <h3>Monthly Spending Trend</h3>
        {monthlySpendingData.length === 0 ? (
          <p className="analytics-empty">Add some expenses to view your spending trend.</p>
        ) : (
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={monthlySpendingData} margin={{ top: 10, right: 16, left: 0, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="monthLabel" tick={{ fontSize: 12, fill: "#6b7280" }} />
                <YAxis width={60} tick={{ fontSize: 11, fill: "#8a93a3" }} tickFormatter={formatCompactINR} />
                <Tooltip formatter={(value) => [formatINR(value), "Expenses"]} contentStyle={tooltipStyle} />
                <Line type="monotone" dataKey="amount" stroke="#2563eb" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="analytics-cards two-col">
        <div className="analytics-card prediction-card">
          <h3>Expense Prediction</h3>
          {predictedNextMonthExpense > 0 ? (
            <>
              <p className="prediction-label">Estimated expense for next month</p>
              <div className="prediction-amount">{formatINR(predictedNextMonthExpense)}</div>
              <p className="prediction-note">
                {predictionMethod === "trend"
                  ? "Estimated by continuing the change between your last two months of spending. The latest month may still be incomplete, so treat this as a rough guide."
                  : "Based on your average monthly spending. Add another month of expenses for a trend-based estimate."}
              </p>
            </>
          ) : (
            <p className="analytics-empty">Add more expenses to generate a prediction.</p>
          )}
        </div>

        <div className="analytics-card budget-card">
          <h3>Budget Recommendation</h3>
          {budgetRecommendations.length === 0 ? (
            <p className="analytics-empty">Add some expenses to receive personalized budget recommendations.</p>
          ) : (
            <div className="budget-list">
              {budgetRecommendations.map((item) => {
                const reduction = item.currentAmount > 0 ? ((item.currentAmount - item.recommendedAmount) / item.currentAmount) * 100 : 0;
                const text =
                  item.spendingPercentage >= 25
                    ? "High spending compared with your income. Consider reducing this category."
                    : item.spendingPercentage >= 15
                    ? "This category takes a noticeable share of your income. A small reduction may help."
                    : "Spending in this category is within a reasonable range.";
                return (
                  <div className="budget-item" key={item.category}>
                    <div className="budget-item-header">
                      <span>{item.category}</span>
                      <strong>{formatINR(item.recommendedAmount)}</strong>
                    </div>
                    <div className="budget-details">
                      Current: {formatINR(item.currentAmount)} • {item.spendingPercentage.toFixed(1)}% of income
                    </div>
                    <div className="budget-bar">
                      <div className="budget-progress" style={{ width: `${Math.min(item.spendingPercentage * 2, 100)}%` }}></div>
                    </div>
                    <div className="budget-saving">
                      {reduction > 0 ? `Suggested reduction: ${reduction.toFixed(0)}%` : "Maintain current spending level"}
                    </div>
                    <p className="budget-reason">{text}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
