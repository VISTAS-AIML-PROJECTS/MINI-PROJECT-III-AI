import { useMemo, useState } from "react";
import { api } from "../api";
import { BILL_CATEGORIES, billStatus, daysBetween, formatDateLong, formatINR, todayISO } from "../utils/finance";
import { ConfirmDialog, EmptyState, SectionHeader } from "./ui";
import { useToast } from "./toastContext";

const EMPTY = { name: "", category: "", amount: "", due_date: "", notes: "", status: "unpaid" };
const STATUS_LABEL = { paid: "Paid", overdue: "Overdue", "due-soon": "Due soon", upcoming: "Upcoming" };

/*
  Bill Reminder (Feature 6) - an IN-APP reminder list.
  There are NO background notifications (no email / push): reminders are shown
  only while you have the app open. "Overdue" is decided with today's date on
  your own device.
*/
export default function BillReminder({ bills, onChanged }) {
  const notify = useToast();
  const [form, setForm] = useState(EMPTY);
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [paying, setPaying] = useState(null);
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState("unpaid");

  const today = todayISO();
  const enriched = useMemo(
    () => bills.map((bill) => ({ bill, status: billStatus(bill, today), days: daysBetween(today, bill.due_date) })),
    [bills, today]
  );

  const unpaid = enriched.filter((b) => b.status !== "paid");
  const overdue = enriched.filter((b) => b.status === "overdue");
  const dueSoon = enriched.filter((b) => b.status === "due-soon");
  const sum = (list) => list.reduce((s, b) => s + b.bill.amount, 0);

  const shown = enriched
    .filter((b) => (filter === "all" ? true : filter === "paid" ? b.status === "paid" : b.status !== "paid"))
    .sort((a, b) => (a.status === "paid") - (b.status === "paid") || a.bill.due_date.localeCompare(b.bill.due_date));

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });
  const reset = () => { setForm(EMPTY); setEditingId(null); setError(""); };

  const startEdit = (bill) => {
    setEditingId(bill.id);
    setError("");
    setForm({
      name: bill.name, category: bill.category, amount: String(bill.amount),
      due_date: bill.due_date, notes: bill.notes || "", status: bill.status,
    });
    document.getElementById("bill-form")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const submit = async (e) => {
    e.preventDefault();
    const amount = Number(form.amount);
    if (!form.name.trim()) return setError("Please enter the bill name.");
    if (!form.category) return setError("Please choose a category.");
    if (form.amount === "" || !Number.isFinite(amount) || amount <= 0) return setError("Amount must be greater than ₹0.");
    if (!form.due_date) return setError("Please choose a due date.");
    setError("");
    setSaving(true);
    try {
      const body = { ...form, name: form.name.trim(), amount };
      if (editingId) await api(`/bills/${editingId}`, { method: "PUT", body });
      else await api("/bills", { method: "POST", body });
      notify(editingId ? "Bill updated." : "Bill added.");
      reset();
      await onChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const confirmPay = async (recordExpense) => {
    setBusy(true);
    try {
      await api(`/bills/${paying.id}/pay`, { method: "POST", body: { record_expense: recordExpense } });
      notify(recordExpense ? "Bill marked as paid and added to your expenses." : "Bill marked as paid.");
      setPaying(null);
      await onChanged({ alsoTransactions: recordExpense });
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const confirmDelete = async () => {
    setBusy(true);
    try {
      await api(`/bills/${deleting.id}`, { method: "DELETE" });
      notify("Bill deleted.");
      setDeleting(null);
      if (editingId === deleting.id) reset();
      await onChanged();
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const dueText = ({ status, days }) => {
    if (status === "paid") return "";
    if (days < 0) return `${-days} day${days === -1 ? "" : "s"} overdue`;
    if (days === 0) return "Due today";
    if (days === 1) return "Due tomorrow";
    return `Due in ${days} days`;
  };

  return (
    <div className="stack">
      <section className="card">
        <SectionHeader title="Bill Reminder" subtitle="Keep track of upcoming payments. Reminders appear here while the app is open." />

        <div className="stat-grid four bill-stats">
          <div className="mini-stat"><span>Unpaid bills total</span><strong>{formatINR(sum(unpaid), true)}</strong><small>{unpaid.length} bill{unpaid.length === 1 ? "" : "s"}</small></div>
          <div className={`mini-stat ${overdue.length ? "stat-bad" : ""}`}><span>Overdue</span><strong>{overdue.length}</strong><small>{formatINR(sum(overdue), true)}</small></div>
          <div className={`mini-stat ${dueSoon.length ? "stat-warn" : ""}`}><span>Due within 7 days</span><strong>{dueSoon.length}</strong><small>{formatINR(sum(dueSoon), true)}</small></div>
          <div className="mini-stat"><span>Paid</span><strong>{enriched.length - unpaid.length}</strong><small>of {enriched.length} saved</small></div>
        </div>

        {overdue.length > 0 && (
          <p className="alert-strip bad">⚠️ You have {overdue.length} overdue bill{overdue.length === 1 ? "" : "s"} totalling {formatINR(sum(overdue), true)}.</p>
        )}
      </section>

      <section className="card" id="bill-form">
        <h3 className="card-title">{editingId ? "Edit Bill" : "Add a Bill"}</h3>
        <form className="form-grid three" onSubmit={submit} noValidate>
          <label>
            Bill Name
            <input type="text" maxLength={100} placeholder="e.g. Home Wi-Fi" value={form.name} onChange={update("name")} />
          </label>
          <label>
            Category
            <select value={form.category} onChange={update("category")}>
              <option value="">Select category</option>
              {BILL_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
          <label>
            Amount (₹)
            <input type="number" min="0.01" step="0.01" placeholder="Bill amount" value={form.amount} onChange={update("amount")} />
          </label>
          <label>
            Due Date
            <input type="date" value={form.due_date} onChange={update("due_date")} />
          </label>
          <label>
            Payment Status
            <select value={form.status} onChange={update("status")}>
              <option value="unpaid">Unpaid</option>
              <option value="paid">Paid</option>
            </select>
          </label>
          <label>
            Notes (optional)
            <input type="text" maxLength={200} placeholder="Any note" value={form.notes} onChange={update("notes")} />
          </label>
          {error && <p className="form-error full" role="alert">{error}</p>}
          <div className="form-actions full">
            <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? "Saving…" : editingId ? "Save Changes" : "Add Bill"}</button>
            {editingId && <button type="button" className="btn btn-ghost" onClick={reset}>Cancel editing</button>}
          </div>
        </form>
      </section>

      <section className="card">
        <div className="tab-row" role="tablist" aria-label="Filter bills">
          {[["unpaid", "Unpaid"], ["paid", "Paid"], ["all", "All"]].map(([id, label]) => (
            <button key={id} role="tab" aria-selected={filter === id} className={`tab ${filter === id ? "active" : ""}`} onClick={() => setFilter(id)}>{label}</button>
          ))}
        </div>

        {shown.length === 0 ? (
          <EmptyState icon="🧾" title={bills.length === 0 ? "No bills added yet" : "No bills in this view"}>
            {bills.length === 0 ? "Add your first bill above, for example Electricity or Rent." : "Try another tab."}
          </EmptyState>
        ) : (
          <ul className="bill-list">
            {shown.map((entry) => {
              const { bill, status } = entry;
              return (
                <li key={bill.id} className={`bill-item bill-${status}`}>
                  <div className="bill-main">
                    <strong>{bill.name}</strong>
                    <span className="muted">{bill.category} · due {formatDateLong(bill.due_date)}</span>
                    {bill.notes && <small className="muted">{bill.notes}</small>}
                  </div>
                  <div className="bill-status">
                    <span className={`badge badge-bill-${status}`}>{STATUS_LABEL[status]}</span>
                    <small>{status === "paid" ? (bill.paid_date ? `Paid on ${formatDateLong(bill.paid_date)}` : "") : dueText(entry)}</small>
                  </div>
                  <strong className="bill-amount">{formatINR(bill.amount)}</strong>
                  <div className="row-actions">
                    {status !== "paid" && <button type="button" className="btn btn-soft btn-sm" onClick={() => setPaying(bill)}>Mark as paid</button>}
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => startEdit(bill)}>Edit</button>
                    <button type="button" className="btn btn-danger-soft btn-sm" onClick={() => setDeleting(bill)}>Delete</button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      {paying && (
        <ConfirmDialog
          title="Mark this bill as paid?"
          danger={false}
          busy={busy}
          confirmLabel="Mark as paid only"
          onCancel={() => setPaying(null)}
          onConfirm={() => confirmPay(false)}
        >
          <p><strong>{paying.name}</strong> · {formatINR(paying.amount)}</p>
          <p className="muted">Bills are never marked as paid automatically. Do you also want this payment recorded as an expense (category “Bills”) so your balance and charts include it?</p>
          <button type="button" className="btn btn-primary wide-btn" disabled={busy} onClick={() => confirmPay(true)}>
            Mark as paid and add expense
          </button>
        </ConfirmDialog>
      )}

      {deleting && (
        <ConfirmDialog title="Delete this bill?" confirmLabel="Delete bill" busy={busy} onCancel={() => setDeleting(null)} onConfirm={confirmDelete}>
          <p>“{deleting.name}” will be removed from your bill list.</p>
        </ConfirmDialog>
      )}
    </div>
  );
}
