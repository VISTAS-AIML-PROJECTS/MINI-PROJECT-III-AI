import { analyzeGoal, formatINR } from "../utils/finance";

/*
  Goal Analysis (Feature 2)
  This is a transparent RULE-BASED calculation on your recorded transactions.
  It is NOT a live AI model, and the numbers are estimates - not guarantees.
*/
export default function GoalAnalysis({ goal, metrics, history, combinedRequired }) {
  const a = analyzeGoal(goal, metrics, history, combinedRequired);
  const showNumbers = a.verdict !== "completed" && a.verdict !== "no-data" && a.required !== null;

  return (
    <div className={`goal-analysis tone-box-${a.tone}`}>
      <div className="goal-analysis-head">
        <h4>Goal Analysis</h4>
        <span className="badge badge-soft" title="Calculated with fixed rules from your transactions - no external AI service is used">
          Rule-based estimate
        </span>
      </div>

      <p className="analysis-title">{a.title}</p>
      <p className="analysis-text">{a.explanation}</p>

      {showNumbers && a.surplus !== null && (
        <div className="analysis-numbers">
          <div>
            <span>Required monthly savings</span>
            <strong>{formatINR(a.required, true)}</strong>
          </div>
          <div>
            <span>Estimated monthly surplus</span>
            <strong className={a.surplus >= 0 ? "" : "text-bad"}>{formatINR(a.surplus, true)}</strong>
          </div>
          <div>
            <span>{a.difference >= 0 ? "Room to spare" : "Shortfall"}</span>
            <strong className={a.difference >= 0 ? "text-good" : "text-bad"}>{formatINR(Math.abs(a.difference), true)}</strong>
          </div>
        </div>
      )}

      {a.suggestions.length > 0 && (
        <ul className="analysis-list">
          {a.suggestions.map((text) => <li key={text}>{text}</li>)}
        </ul>
      )}

      {a.notes.length > 0 && (
        <ul className="analysis-notes">
          {a.notes.map((text) => <li key={text}>{text}</li>)}
        </ul>
      )}

      <p className="analysis-disclaimer">
        {a.monthCount > 0
          ? `Estimated from your average over ${a.monthCount} recorded month${a.monthCount === 1 ? "" : "s"}. `
          : ""}
        Future income and spending can change, so this is an estimate and not a guaranteed outcome.
      </p>
    </div>
  );
}
