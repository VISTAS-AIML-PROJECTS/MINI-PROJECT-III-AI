import { useMemo, useState } from "react";
import { MIN_EXPENSES_FOR_SUGGESTIONS, buildSuggestions, formatINR } from "../utils/finance";
import { EmptyState, SectionHeader } from "./ui";

const ICONS = { reduce: "✂️", info: "ℹ️", rise: "📈", rate: "🎯" };

/*
  Saving Suggestions (Feature 5)
  The suggestions are recalculated from the transactions on every change.
  "Done" / "Dismiss" choices are saved in the database (per user) using the
  suggestion's key, so they are remembered after logging out.
*/
export default function SavingSuggestions({ transactions, states, onSetState }) {
  const [showClosed, setShowClosed] = useState(false);
  const result = useMemo(() => buildSuggestions(transactions), [transactions]);

  const stateOf = (key) => states.find((s) => s.key === key)?.status;
  const active = result.items.filter((i) => !stateOf(i.key));
  const closed = result.items.filter((i) => stateOf(i.key));
  const trimTotal = active.filter((i) => i.type === "reduce").reduce((sum, i) => sum + i.potentialMonthly, 0);

  return (
    <section className="card">
      <SectionHeader
        title="Saving Suggestions"
        subtitle="Practical ideas based on the expenses you have recorded"
        badge="Rule-based"
      />

      {!result.enoughData ? (
        <EmptyState icon="🧾" title="Not enough expense history yet">
          Record at least {MIN_EXPENSES_FOR_SUGGESTIONS} expenses (you have {result.expenseCount}) to receive suggestions. Fewer records could give misleading advice.
        </EmptyState>
      ) : active.length === 0 ? (
        <EmptyState icon="✅" title={closed.length ? "You have handled all current suggestions" : "No suggestions right now"}>
          {closed.length
            ? "New suggestions will appear when your spending changes."
            : "Nothing in your recorded spending stands out at the moment. Keep tracking to stay on top of it."}
        </EmptyState>
      ) : (
        <>
          {trimTotal > 0 && (
            <p className="info-strip">
              If you applied every “trim” suggestion below, you could save about <strong>{formatINR(trimTotal, true)}</strong> per month.
              This is an estimate from your recorded spending.
            </p>
          )}
          <ul className="suggestion-list">
            {active.map((item) => (
              <li className={`suggestion suggestion-${item.type}`} key={item.key}>
                <span className="suggestion-icon" aria-hidden="true">{ICONS[item.type]}</span>
                <div className="suggestion-body">
                  <strong>{item.title}</strong>
                  <p>{item.detail}</p>
                  {item.potentialMonthly !== null && (
                    <span className="badge badge-good">Potential saving ≈ {formatINR(item.potentialMonthly, true)}</span>
                  )}
                </div>
                <div className="suggestion-actions">
                  <button type="button" className="btn btn-soft btn-sm" onClick={() => onSetState(item.key, "completed")}>Mark done</button>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => onSetState(item.key, "dismissed")}>Dismiss</button>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}

      {closed.length > 0 && (
        <div className="closed-suggestions">
          <button type="button" className="link-button" onClick={() => setShowClosed(!showClosed)}>
            {showClosed ? "Hide" : "Show"} completed and dismissed ({closed.length})
          </button>
          {showClosed && (
            <ul className="suggestion-list muted-list">
              {closed.map((item) => (
                <li className="suggestion" key={item.key}>
                  <span className="suggestion-icon" aria-hidden="true">{stateOf(item.key) === "completed" ? "✅" : "🚫"}</span>
                  <div className="suggestion-body">
                    <strong>{item.title}</strong>
                    <small>{stateOf(item.key) === "completed" ? "Marked as done" : "Dismissed"}</small>
                  </div>
                  <div className="suggestion-actions">
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => onSetState(item.key, "active")}>Restore</button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <p className="muted small-text">
        Essential expenses such as bills, health and education are never suggested for cutting. Suggestions use averages of your recorded months and are estimates, not guarantees.
      </p>
    </section>
  );
}
