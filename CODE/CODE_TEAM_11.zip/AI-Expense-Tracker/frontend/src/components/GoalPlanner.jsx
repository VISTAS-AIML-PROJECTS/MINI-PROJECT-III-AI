import { useMemo, useState } from "react";
import { api } from "../api";
import { computeGoalMetrics, formatDateLong, formatINR, formatPercent, getHistory, todayISO } from "../utils/finance";
import GoalAnalysis from "./GoalAnalysis";
import { ConfirmDialog, EmptyState, ProgressBar, SectionHeader } from "./ui";
import { useToast } from "./toastContext";

const EMPTY_FORM = { name: "", target_amount: "", current_savings: "", target_date: "" };

/* Goal Planner (Feature 1) + Goal Analysis (Feature 2) */
export default function GoalPlanner({ goals, transactions, onChanged }) {
  const notify = useToast();
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const today = todayISO();
  // The analysis is recalculated on every render, so it always follows the latest transactions and goals.
  const history = useMemo(() => getHistory(transactions), [transactions]);
  // Active goals first, then overdue, then completed (soonest deadline first inside each group)
  const ORDER = { active: 0, overdue: 1, completed: 2 };
  const rows = goals
    .map((goal) => ({ goal, metrics: computeGoalMetrics(goal, today) }))
    .sort((a, b) => ORDER[a.metrics.status] - ORDER[b.metrics.status] || a.goal.target_date.localeCompare(b.goal.target_date));
  const combinedRequired = rows
    .filter((r) => r.metrics.status === "active")
    .reduce((sum, r) => sum + r.metrics.monthlyRequired, 0);
  const activeCount = rows.filter((r) => r.metrics.status === "active").length;

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const startEdit = (goal) => {
    setEditingId(goal.id);
    setError("");
    setForm({
      name: goal.name,
      target_amount: String(goal.target_amount),
      current_savings: String(goal.current_savings),
      target_date: goal.target_date,
    });
    document.getElementById("goal-form")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const resetForm = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setError("");
  };

  // Frontend validation (the backend validates again - never rely on the browser alone)
  const validate = () => {
    const target = Number(form.target_amount);
    const saved = form.current_savings === "" ? 0 : Number(form.current_savings);
    if (!form.name.trim()) return "Please enter a goal name.";
    if (form.name.trim().length > 100) return "Goal name must be 100 characters or fewer.";
    if (form.target_amount === "" || !Number.isFinite(target) || target <= 0) return "Target amount must be greater than ₹0.";
    if (!Number.isFinite(saved) || saved < 0) return "Current savings cannot be negative.";
    if (!form.target_date) return "Please choose a target date.";
    const original = editingId ? goals.find((g) => g.id === editingId) : null;
    const unchangedDate = original && original.target_date === form.target_date;
    if (!unchangedDate && form.target_date < today) return "Target date cannot be in the past.";
    return "";
  };

  const submit = async (e) => {
    e.preventDefault();
    const problem = validate();
    if (problem) return setError(problem);
    setError("");
    setSaving(true);
    const body = {
      name: form.name.trim(),
      target_amount: Number(form.target_amount),
      current_savings: form.current_savings === "" ? 0 : Number(form.current_savings),
      target_date: form.target_date,
    };
    try {
      if (editingId) await api(`/goals/${editingId}`, { method: "PUT", body });
      else await api("/goals", { method: "POST", body });
      notify(editingId ? "Goal updated." : "Goal created.");
      resetForm();
      await onChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const addSavings = async (goal, amount) => {
    try {
      await api(`/goals/${goal.id}`, {
        method: "PUT",
        body: {
          name: goal.name,
          target_amount: goal.target_amount,
          current_savings: Math.round((goal.current_savings + amount) * 100) / 100,
          target_date: goal.target_date,
        },
      });
      notify(`Added ${formatINR(amount, true)} to "${goal.name}".`);
      await onChanged();
      return true;
    } catch (err) {
      notify(err.message, "error");
      return false;
    }
  };

  const confirmDelete = async () => {
    setBusy(true);
    try {
      await api(`/goals/${deleting.id}`, { method: "DELETE" });
      notify("Goal deleted.");
      setDeleting(null);
      if (editingId === deleting.id) resetForm();
      await onChanged();
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack">
      <section className="card" id="goal-form">
        <SectionHeader
          title="Goal Planner"
          subtitle="Set savings goals and see how much to save every month"
        />

        <form className="goal-form" onSubmit={submit} noValidate>
          <label>
            Goal Name
            <input type="text" maxLength={100} placeholder="e.g. Buy a Laptop, Emergency Fund" value={form.name} onChange={update("name")} />
          </label>
          <label>
            Target Amount (₹)
            <input type="number" min="1" step="0.01" placeholder="Total money needed" value={form.target_amount} onChange={update("target_amount")} />
          </label>
          <label>
            Current Savings (₹)
            <input type="number" min="0" step="0.01" placeholder="Already saved (optional)" value={form.current_savings} onChange={update("current_savings")} />
          </label>
          <label>
            Target Date
            <input type="date" min={editingId ? undefined : today} value={form.target_date} onChange={update("target_date")} />
          </label>

          {error && <p className="form-error full" role="alert">{error}</p>}

          <div className="form-actions full">
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? "Saving…" : editingId ? "Save Changes" : "Create Goal"}
            </button>
            {editingId && <button type="button" className="btn btn-ghost" onClick={resetForm}>Cancel editing</button>}
          </div>
        </form>
      </section>

      {rows.length === 0 ? (
        <section className="card">
          <EmptyState icon="🎯" title="No goals yet">
            Create your first goal above, for example “Emergency Fund”. The app will calculate how much you need to save each month.
          </EmptyState>
        </section>
      ) : (
        <>
          {activeCount > 1 && (
            <p className="info-strip">
              Your {activeCount} active goals together need about <strong>{formatINR(combinedRequired, true)}</strong> per month.
            </p>
          )}
          {rows.map(({ goal, metrics }) => (
            <GoalCard
              key={goal.id}
              goal={goal}
              metrics={metrics}
              history={history}
              combinedRequired={activeCount > 1 ? combinedRequired : null}
              onEdit={() => startEdit(goal)}
              onDelete={() => setDeleting(goal)}
              onAddSavings={(amount) => addSavings(goal, amount)}
            />
          ))}
        </>
      )}

      {deleting && (
        <ConfirmDialog
          title="Delete this goal?"
          confirmLabel="Delete goal"
          busy={busy}
          onCancel={() => setDeleting(null)}
          onConfirm={confirmDelete}
        >
          <p>“{deleting.name}” will be removed permanently. Your transactions are not affected.</p>
        </ConfirmDialog>
      )}
    </div>
  );
}

function GoalCard({ goal, metrics: m, history, combinedRequired, onEdit, onDelete, onAddSavings }) {
  const [amount, setAmount] = useState("");
  const [amountError, setAmountError] = useState("");
  const tone = m.status === "completed" ? "good" : m.status === "overdue" ? "bad" : m.progress >= 75 ? "good" : "primary";

  const submitSavings = async (e) => {
    e.preventDefault();
    const value = Number(amount);
    if (!amount || !Number.isFinite(value) || value <= 0) return setAmountError("Enter an amount greater than ₹0.");
    setAmountError("");
    if (await onAddSavings(value)) setAmount("");
  };

  return (
    <section className={`card goal-card goal-${m.status}`}>
      <div className="goal-top">
        <div>
          <h3>{goal.name}</h3>
          <p className="muted">Target date: {formatDateLong(goal.target_date)}</p>
        </div>
        <div className="goal-badges">
          {m.status === "completed" && <span className="badge badge-good">Completed 🎉</span>}
          {m.status === "overdue" && <span className="badge badge-bad">Deadline passed</span>}
          {m.status === "active" && <span className="badge badge-info">{m.monthsLeft} month{m.monthsLeft === 1 ? "" : "s"} left</span>}
          <button type="button" className="btn btn-ghost btn-sm" onClick={onEdit}>Edit</button>
          <button type="button" className="btn btn-danger-soft btn-sm" onClick={onDelete}>Delete</button>
        </div>
      </div>

      {m.status === "completed" && (
        <p className="goal-message good">
          Congratulations! You have reached this goal
          {m.exceededBy > 0 ? ` and saved ${formatINR(m.exceededBy, true)} more than the target.` : "."}
        </p>
      )}
      {m.status === "overdue" && (
        <p className="goal-message bad">
          The target date has passed and {formatINR(m.remaining, true)} is still remaining. Edit the goal to set a new date.
        </p>
      )}

      <div className="goal-progress">
        <div className="goal-progress-label">
          <span>Progress</span>
          <strong>{formatPercent(m.progress, m.progress % 1 === 0 ? 0 : 1)}</strong>
        </div>
        <ProgressBar percent={m.progress} tone={tone} label={`${goal.name} progress`} />
      </div>

      <div className="stat-grid five">
        <div className="mini-stat"><span>Target amount</span><strong>{formatINR(m.target, true)}</strong></div>
        <div className="mini-stat"><span>Current savings</span><strong>{formatINR(m.saved, true)}</strong></div>
        <div className="mini-stat"><span>Remaining</span><strong>{formatINR(m.remaining, true)}</strong></div>
        <div className="mini-stat">
          <span>Monthly saving required</span>
          <strong>{m.monthlyRequired === null ? "—" : formatINR(m.monthlyRequired, true)}</strong>
        </div>
        <div className="mini-stat"><span>Progress</span><strong>{formatPercent(m.progress, 1)}</strong></div>
      </div>

      {m.status !== "completed" && (
        <form className="inline-form" onSubmit={submitSavings} noValidate>
          <label className="sr-only" htmlFor={`add-${goal.id}`}>Amount to add to {goal.name}</label>
          <input
            id={`add-${goal.id}`} type="number" min="0.01" step="0.01"
            placeholder="Add to savings (₹)" value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <button type="submit" className="btn btn-soft btn-sm">Add savings</button>
          {amountError && <span className="form-error">{amountError}</span>}
        </form>
      )}

      <GoalAnalysis goal={goal} metrics={m} history={history} combinedRequired={combinedRequired} />
    </section>
  );
}
