import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from "../utils/finance";

/* Add Expense / Add Income form. Values live in App.jsx so "Edit Details" on the review page keeps what you typed. */
export default function TransactionForm({ type, draft, setDraft, error, onSubmit, onCancel }) {
  const isExpense = type === "expense";
  const categories = isExpense ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;
  const update = (field) => (e) => setDraft({ ...draft, [field]: e.target.value });

  return (
    <div className="expense-form" id="transaction-form">
      <h3>{isExpense ? "Add Expense" : "Add Income"}</h3>

      <form onSubmit={onSubmit} noValidate>
        <label htmlFor="tx-amount">Amount (₹)</label>
        <input id="tx-amount" type="number" min="0.01" step="0.01" placeholder="Enter amount" value={draft.amount} onChange={update("amount")} autoFocus />

        <label htmlFor="tx-category">Category</label>
        <select id="tx-category" value={draft.category} onChange={update("category")}>
          <option value="">Select category</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>

        <label htmlFor="tx-description">Description</label>
        <input id="tx-description" type="text" maxLength={200} placeholder="Optional description" value={draft.description} onChange={update("description")} />

        <label htmlFor="tx-date">Date</label>
        <input id="tx-date" type="date" value={draft.date} onChange={update("date")} />

        {error && <p className="form-error" role="alert">{error}</p>}

        <div className="form-actions">
          <button type="submit" className="btn btn-primary">{isExpense ? "Save Expense" : "Save Income"}</button>
          <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
        </div>
      </form>
    </div>
  );
}
