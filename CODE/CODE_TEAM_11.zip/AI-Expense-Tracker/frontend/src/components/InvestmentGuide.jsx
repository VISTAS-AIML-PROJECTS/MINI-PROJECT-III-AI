import { useMemo, useState } from "react";
import { formatINR, getHistory } from "../utils/finance";
import { EmptyState, SectionHeader } from "./ui";

/*
  Investment Recommendation (Feature 4) - EDUCATIONAL ONLY.

  * No interest rates or market returns are shown (they change often and we
    do not have a live data source), so nothing here can be "wrong" or outdated.
  * Nothing is guaranteed and nothing is ever bought for the user.
  * "Fit" only compares the user's own answers (time horizon and risk comfort)
    with the general nature of each product.
*/

const OBJECTIVES = [
  { id: "emergency", label: "Build an emergency fund", note: "An emergency fund is money you may need quickly, so easy access and low risk usually matter more than growth." },
  { id: "short", label: "Save for a short-term goal (trip, gadget)", note: "For goals within a few years, protecting your money usually matters more than chasing growth." },
  { id: "big", label: "Save for a big purchase (vehicle, home down-payment)", note: "The purchase date is fixed, so it helps to reduce risk as the date gets closer." },
  { id: "education", label: "Save for education", note: "Education costs usually have a fixed date, so a mix of safety and (for longer periods) some growth is often discussed." },
  { id: "long", label: "Grow wealth for the long term / retirement", note: "Long periods can allow you to ride out ups and downs, but returns are never guaranteed." },
  { id: "income", label: "Earn regular income from savings", note: "The focus is on predictable payouts, which usually means lower-risk products." },
];

const HORIZONS = [
  { id: "lt1", label: "Less than 1 year" },
  { id: "1to3", label: "1 to 3 years" },
  { id: "3to5", label: "3 to 5 years" },
  { id: "5plus", label: "More than 5 years" },
];

const RISKS = [
  { id: 1, label: "Low - I do not want to see my money fall in value" },
  { id: 2, label: "Moderate - I can accept some ups and downs" },
  { id: 3, label: "High - I can accept large ups and downs for possible growth" },
];

// horizon fit: "good" | "partial" | "poor"  for each time horizon
const OPTIONS = [
  {
    id: "savings", name: "Savings account", risk: 1, riskLabel: "Low",
    what: "A normal bank account that pays a small amount of interest and lets you withdraw money whenever you need it.",
    benefits: ["Money is easy to access at any time", "Simple and widely available", "Bank deposits in India are covered by deposit insurance up to a limit set by the authorities (check the current limit)"],
    limits: ["Interest is usually low and may not keep up with rising prices", "Not designed for long-term growth"],
    horizon: { lt1: "good", "1to3": "partial", "3to5": "poor", "5plus": "poor" },
    horizonNote: "Best suited to money you may need soon; usually not the main choice for long periods.",
    objectives: ["emergency", "short"],
  },
  {
    id: "fd", name: "Fixed Deposit (FD)", risk: 1, riskLabel: "Low",
    what: "You deposit a lump sum with a bank for a fixed period and receive interest as agreed when you open the deposit.",
    benefits: ["The interest rate is fixed for the chosen period", "Predictable and easy to understand", "Different tenures are available"],
    limits: ["Withdrawing early usually involves a penalty", "Interest is generally taxable", "Returns may not beat rising prices over long periods"],
    horizon: { lt1: "partial", "1to3": "good", "3to5": "good", "5plus": "partial" },
    horizonNote: "Works when you know you will not need the money until the deposit period ends.",
    objectives: ["emergency", "short", "big", "education", "income"],
  },
  {
    id: "rd", name: "Recurring Deposit (RD)", risk: 1, riskLabel: "Low",
    what: "You deposit a fixed amount every month for a chosen period, and receive the total plus interest at the end.",
    benefits: ["Builds a regular saving habit", "Fixed interest for the chosen period", "You can start with a small monthly amount"],
    limits: ["Missing monthly instalments may lead to charges", "Early closure usually reduces the interest", "Growth potential is limited"],
    horizon: { lt1: "partial", "1to3": "good", "3to5": "good", "5plus": "partial" },
    horizonNote: "Suits goals with a fixed date that you fund from monthly income.",
    objectives: ["short", "big", "education"],
  },
  {
    id: "govt", name: "Government-backed savings schemes", risk: 1, riskLabel: "Low",
    what: "Savings schemes run or backed by the Government of India, such as PPF or NSC. Each scheme has its own rules, limits and lock-in period.",
    benefits: ["Backed by the government", "Some schemes offer tax benefits (rules change - check the current ones)", "Encourage disciplined long-term saving"],
    limits: ["Lock-in periods can be long (for example, PPF is designed for 15 years)", "Interest rates are set by the government and can change", "Yearly investment limits apply"],
    horizon: { lt1: "poor", "1to3": "poor", "3to5": "partial", "5plus": "good" },
    horizonNote: "Usually suited to longer periods because your money is locked in.",
    objectives: ["education", "long", "income"],
  },
  {
    id: "mf", name: "Mutual funds (debt, hybrid or equity)", risk: 2, riskLabel: "Low to High (depends on the fund)",
    what: "A fund collects money from many people and invests it in bonds, shares or both. Investing through a monthly SIP is common.",
    benefits: ["Professionally managed and diversified", "You can start with small amounts", "Equity funds have historically been able to grow over long periods (not guaranteed)"],
    limits: ["Values go up and down and you can lose money", "Fees (expense ratio) reduce returns", "Past performance does not guarantee future results", "Choosing the right fund type takes some learning"],
    horizon: { lt1: "poor", "1to3": "partial", "3to5": "partial", "5plus": "good" },
    horizonNote: "Equity-based funds are generally meant for longer periods; some debt funds are used for shorter ones. Fund type matters.",
    objectives: ["big", "education", "long"],
  },
  {
    id: "equity", name: "Equity (direct shares)", risk: 3, riskLabel: "High",
    what: "You buy shares of individual companies and own a small part of them.",
    benefits: ["Possible growth over long periods", "You choose what to buy", "Some shares pay dividends"],
    limits: ["Prices can fall sharply and you can lose part or all of your money", "Needs research and patience", "Not suitable for money you may need soon"],
    horizon: { lt1: "poor", "1to3": "poor", "3to5": "partial", "5plus": "good" },
    horizonNote: "Short periods are risky because prices can stay low for years.",
    objectives: ["long"],
  },
  {
    id: "gold", name: "Gold (jewellery, coins, gold ETFs, digital gold)", risk: 2, riskLabel: "Moderate",
    what: "Buying gold in physical or financial form, often used to diversify savings.",
    benefits: ["Often used as a store of value and a way to diversify", "Widely understood and easy to sell in India"],
    limits: ["Price fluctuates and can stay low for long periods", "Physical gold has making charges and storage risk", "It does not pay interest or dividends"],
    horizon: { lt1: "poor", "1to3": "partial", "3to5": "partial", "5plus": "good" },
    horizonNote: "Prices move up and down, so it is generally considered over longer periods.",
    objectives: ["long", "big"],
  },
];

const FIT_TEXT = {
  good: "Time horizon generally fits",
  partial: "Time horizon partly fits",
  poor: "Time horizon generally does not fit",
};

function assess(option, horizon, riskPref) {
  const horizonFit = option.horizon[horizon];
  const riskOk = option.risk <= riskPref;
  let overall = "partial";
  if (horizonFit === "poor" || !riskOk) overall = "less";
  else if (horizonFit === "good") overall = "fits";
  return { horizonFit, riskOk, overall };
}

const OVERALL_LABEL = { fits: "Fits your inputs", partial: "Partly fits your inputs", less: "Less aligned with your inputs" };

export default function InvestmentGuide({ transactions }) {
  const [objective, setObjective] = useState("long");
  const [horizon, setHorizon] = useState("5plus");
  const [riskPref, setRiskPref] = useState(2);
  const [amount, setAmount] = useState("");
  const [compare, setCompare] = useState([]);

  const history = useMemo(() => getHistory(transactions), [transactions]);
  const objectiveInfo = OBJECTIVES.find((o) => o.id === objective);
  const amountNumber = Number(amount);
  const hasAmount = amount !== "" && Number.isFinite(amountNumber) && amountNumber > 0;

  const toggleCompare = (id) =>
    setCompare((current) => (current.includes(id) ? current.filter((x) => x !== id) : current.length < 3 ? [...current, id] : current));

  const compared = OPTIONS.filter((o) => compare.includes(o.id));

  return (
    <div className="stack">
      <section className="card">
        <SectionHeader
          title="Investment Recommendation"
          subtitle="Learn how common options work and see which ones match your answers"
          badge="Educational"
        />

        <div className="disclaimer-box">
          <strong>Please read:</strong> This section is for learning only. It is not personal financial advice and no
          return is guaranteed. The value of many investments can fall as well as rise. No money is invested by this app,
          and interest rates are not shown because they change often - check the current details with your bank or the
          official source before deciding.
        </div>

        <div className="form-grid four">
          <label>
            Investment objective
            <select value={objective} onChange={(e) => setObjective(e.target.value)}>
              {OBJECTIVES.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
            </select>
          </label>
          <label>
            Time horizon
            <select value={horizon} onChange={(e) => setHorizon(e.target.value)}>
              {HORIZONS.map((h) => <option key={h.id} value={h.id}>{h.label}</option>)}
            </select>
          </label>
          <label>
            Risk preference
            <select value={riskPref} onChange={(e) => setRiskPref(Number(e.target.value))}>
              {RISKS.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
            </select>
          </label>
          <label>
            Approximate amount (₹, optional)
            <input type="number" min="0" step="1" placeholder="e.g. 25000" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </label>
        </div>

        <div className="info-strip">
          <strong>{objectiveInfo.label}:</strong> {objectiveInfo.note}
        </div>
        {hasAmount && (
          <p className="muted small-text">
            Amount considered: {formatINR(amountNumber, true)}. Minimum amounts, charges and rules differ between products and providers, so check them before deciding.
          </p>
        )}
        {history.monthCount > 0 && history.avgExpense > 0 && (
          <p className="muted small-text">
            A common guideline is to keep 3 to 6 months of expenses as an emergency fund before taking market risk. Based on your recorded average monthly expenses ({formatINR(history.avgExpense, true)}), that would be roughly {formatINR(history.avgExpense * 3, true)} to {formatINR(history.avgExpense * 6, true)}.
          </p>
        )}
      </section>

      <div className="invest-grid">
        {OPTIONS.map((option) => {
          const a = assess(option, horizon, riskPref);
          const commonly = option.objectives.includes(objective);
          return (
            <article className={`card invest-card fit-${a.overall}`} key={option.id}>
              <div className="invest-top">
                <h3>{option.name}</h3>
                <span className={`badge badge-risk-${option.risk}`}>Risk: {option.riskLabel}</span>
              </div>

              <p className="invest-what">{option.what}</p>

              <div className="fit-row">
                <span className={`fit-pill fit-${a.overall}`}>{OVERALL_LABEL[a.overall]}</span>
                {commonly && <span className="fit-pill fit-objective">Often considered for this objective</span>}
              </div>
              <ul className="fit-reasons">
                <li className={`reason-${a.horizonFit}`}>{FIT_TEXT[a.horizonFit]} - {option.horizonNote}</li>
                <li className={a.riskOk ? "reason-good" : "reason-poor"}>
                  {a.riskOk ? "Within the risk level you selected" : "Higher risk than the level you selected"}
                </li>
              </ul>

              <div className="pros-cons">
                <div>
                  <h5>Potential benefits</h5>
                  <ul>{option.benefits.map((b) => <li key={b}>{b}</li>)}</ul>
                </div>
                <div>
                  <h5>Important limitations</h5>
                  <ul>{option.limits.map((l) => <li key={l}>{l}</li>)}</ul>
                </div>
              </div>

              <label className="compare-check">
                <input
                  type="checkbox"
                  checked={compare.includes(option.id)}
                  onChange={() => toggleCompare(option.id)}
                  disabled={!compare.includes(option.id) && compare.length >= 3}
                />
                Compare (up to 3)
              </label>
            </article>
          );
        })}
      </div>

      <section className="card">
        <SectionHeader title="Compare options" subtitle="Tick “Compare” on up to three options above" />
        {compared.length < 2 ? (
          <EmptyState icon="⚖️" title="Choose at least two options to compare" />
        ) : (
          <div className="table-scroll">
            <table className="compare-table">
              <thead>
                <tr>
                  <th />
                  {compared.map((o) => <th key={o.id}>{o.name}</th>)}
                </tr>
              </thead>
              <tbody>
                <tr><th>General risk</th>{compared.map((o) => <td key={o.id}>{o.riskLabel}</td>)}</tr>
                <tr><th>Your time horizon</th>{compared.map((o) => <td key={o.id}>{FIT_TEXT[o.horizon[horizon]]}</td>)}</tr>
                <tr><th>Your risk preference</th>{compared.map((o) => <td key={o.id}>{o.risk <= riskPref ? "Within your level" : "Higher than your level"}</td>)}</tr>
                <tr><th>Benefits</th>{compared.map((o) => <td key={o.id}><ul>{o.benefits.map((b) => <li key={b}>{b}</li>)}</ul></td>)}</tr>
                <tr><th>Limitations</th>{compared.map((o) => <td key={o.id}><ul>{o.limits.map((l) => <li key={l}>{l}</li>)}</ul></td>)}</tr>
              </tbody>
            </table>
          </div>
        )}
        <p className="muted small-text">There is no single “best” investment. The right choice depends on your goal, time, comfort with risk and personal situation. Consider speaking to a SEBI-registered adviser before investing.</p>
      </section>
    </div>
  );
}
