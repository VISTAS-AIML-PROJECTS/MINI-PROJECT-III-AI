import { useState } from "react";
import { api } from "../api";
import { todayISO } from "../utils/finance";
import { SectionHeader } from "./ui";
import { useToast } from "./toastContext";

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

/* Monthly PDF report (Feature 9). The PDF itself is built by the backend (report.py). */
export default function ReportDownload({ transactions }) {
  const notify = useToast();
  const now = todayISO();
  const [year, setYear] = useState(Number(now.slice(0, 4)));
  const [month, setMonth] = useState(Number(now.slice(5, 7)));
  const [busy, setBusy] = useState(false);

  // Year choices: from the earliest transaction year (or this year) up to next year
  const years = transactions.map((t) => Number(String(t.date).slice(0, 4))).filter(Boolean);
  const first = Math.min(Number(now.slice(0, 4)), ...years);
  const yearOptions = [];
  for (let y = Number(now.slice(0, 4)) + 1; y >= first; y--) yearOptions.push(y);

  const count = transactions.filter((t) => t.date.startsWith(`${year}-${String(month).padStart(2, "0")}`)).length;

  const download = async () => {
    setBusy(true);
    try {
      const response = await api(`/report/monthly?year=${year}&month=${month}`, { raw: true });
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `AI-Expense-Tracker-Report-${year}-${String(month).padStart(2, "0")}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      notify("Your report has been downloaded.");
    } catch (err) {
      notify(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card">
      <SectionHeader title="Monthly Report" subtitle="Download a PDF summary of any month" />
      <div className="report-row">
        <label>
          Month
          <select value={month} onChange={(e) => setMonth(Number(e.target.value))}>
            {MONTHS.map((name, i) => <option key={name} value={i + 1}>{name}</option>)}
          </select>
        </label>
        <label>
          Year
          <select value={year} onChange={(e) => setYear(Number(e.target.value))}>
            {yearOptions.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        </label>
        <button type="button" className="btn btn-primary" onClick={download} disabled={busy}>
          {busy ? "Preparing PDF…" : "Download Monthly Report"}
        </button>
      </div>
      <p className="muted small-text">
        {count > 0
          ? `${count} transaction${count === 1 ? "" : "s"} recorded for ${MONTHS[month - 1]} ${year}.`
          : `No transactions recorded for ${MONTHS[month - 1]} ${year}. The report will say so instead of showing made-up data.`}
      </p>
    </section>
  );
}
