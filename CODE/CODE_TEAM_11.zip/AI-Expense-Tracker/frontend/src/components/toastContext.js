import { createContext, useContext } from "react";

// Kept in its own file so ui.jsx only exports components (needed for React fast refresh).
export const ToastContext = createContext(() => {});
export const useToast = () => useContext(ToastContext);
