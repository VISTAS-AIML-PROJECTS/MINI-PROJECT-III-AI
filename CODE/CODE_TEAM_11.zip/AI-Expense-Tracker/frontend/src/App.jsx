import { useCallback, useEffect, useMemo, useState } from "react";
import "./App.css";
import { ApiError, api, getToken, setToken, setUnauthorizedHandler } from "./api";
import Analytics from "./components/Analytics";
import BalanceCard from "./components/BalanceCard";
import BillReminder from "./components/BillReminder";
import GoalPlanner from "./components/GoalPlanner";
import HealthScore from "./components/HealthScore";
import InvestmentGuide from "./components/InvestmentGuide";
import ReportDownload from "./components/ReportDownload";
import SavingSuggestions from "./components/SavingSuggestions";
import TransactionForm from "./components/TransactionForm";
import TransactionList from "./components/TransactionList";
import { useToast } from "./components/toastContext";
import { billStatus, formatINR, sumByType, todayISO } from "./utils/finance";

const TABS = [
  { id: "overview", label: "Overview", icon: "🏠" },
  { id: "goals", label: "Goals", icon: "🎯" },
  { id: "bills", label: "Bills", icon: "🧾" },
  { id: "insights", label: "Insights", icon: "💡" },
  { id: "invest", label: "Invest", icon: "📈" },
  { id: "reports", label: "Reports", icon: "📄" },
];

const emptyDraft = () => ({ amount: "", category: "", description: "", date: todayISO() });

function App() {
  const notify = useToast();

  // ----- account / session -----
  const [isSignup, setIsSignup] = useState(false);
  const [user, setUser] = useState(null);
  const [checkingSession, setCheckingSession] = useState(Boolean(getToken()));
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // ----- data (everything is reloaded together so all cards stay in sync) -----
  const [transactions, setTransactions] = useState([]);
  const [goals, setGoals] = useState([]);
  const [bills, setBills] = useState([]);
  const [suggestionStates, setSuggestionStates] = useState([]);
  const [loadError, setLoadError] = useState("");
  const [loading, setLoading] = useState(false);

  // ----- dashboard UI -----
  const [tab, setTab] = useState("overview");
  const [formType, setFormType] = useState(null); // null | "expense" | "income"
  const [draft, setDraft] = useState(emptyDraft);
  const [formError, setFormError] = useState("");
  const [showVerification, setShowVerification] = useState(false);
  const [saving, setSaving] = useState(false);

  const loadAll = useCallback(async () => {
    try {
      const [tx, goalList, billList, states] = await Promise.all([
        api("/transactions"), api("/goals"), api("/bills"), api("/suggestions/state"),
      ]);
      setTransactions(tx);
      setGoals(goalList);
      setBills(billList);
      setSuggestionStates(states);
      setLoadError("");
    } catch (error) {
      setLoadError(error.message);
    }
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
    setTransactions([]);
    setGoals([]);
    setBills([]);
    setSuggestionStates([]);
    setFormType(null);
    setShowVerification(false);
    setTab("overview");
    setPassword("");
  }, []);

  // Log out automatically if the server says the saved login is no longer valid.
  useEffect(() => {
    setUnauthorizedHandler(() => {
      logout();
      notify("Your session has expired. Please log in again.", "info");
    });
  }, [logout, notify]);

  // Restore a saved login after a page refresh.
  useEffect(() => {
    if (!getToken()) return;
    let cancelled = false;
    (async () => {
      try {
        const data = await api("/me");
        if (cancelled) return;
        setUser(data.user);
        setLoading(true);
        await loadAll();
      } catch (error) {
        if (!(error instanceof ApiError) || error.status === 401) setToken(null);
      } finally {
        if (!cancelled) { setCheckingSession(false); setLoading(false); }
      }
    })();
    return () => { cancelled = true; };
  }, [loadAll]);

  // ------------------------------------------------------------------ auth
  const handleSubmit = async (e) => {
    e.preventDefault();
    setAuthError("");

    if (isSignup) {
      if (name.trim().length < 2) return setAuthError("Please enter your full name.");
      if (password.length < 6) return setAuthError("Password must be at least 6 characters long.");
      if (password !== confirmPassword) return setAuthError("Passwords do not match.");
    }

    setAuthBusy(true);
    try {
      if (isSignup) {
        await api("/signup", { method: "POST", body: { name: name.trim(), email: email.trim(), password } });
        notify("Account created successfully! Please log in.");
        setIsSignup(false);
        setName(""); setPassword(""); setConfirmPassword("");
      } else {
        const data = await api("/login", { method: "POST", body: { email: email.trim(), password } });
        setToken(data.token);
        setUser(data.user);
        setPassword("");
        setLoading(true);
        await loadAll();
        setLoading(false);
      }
    } catch (error) {
      setAuthError(error.message);
    } finally {
      setAuthBusy(false);
    }
  };

  // ---------------------------------------------- add income / add expense
  const openForm = (type) => {
    setFormType(type);
    setDraft(emptyDraft());
    setFormError("");
    setTab("overview");
    setTimeout(() => document.getElementById("transaction-form")?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
  };

  // Step 1: check the form, then show the "Review Transaction" page (Smart Data Verification).
  const handleFormSubmit = (e) => {
    e.preventDefault();
    const amount = Number(draft.amount);

    if (!draft.amount || !Number.isFinite(amount) || amount <= 0) return setFormError("Please enter a valid amount greater than ₹0.");
    if (!draft.category) return setFormError(`Please select ${formType === "expense" ? "an expense" : "an income"} category.`);
    if (!draft.date) return setFormError("Please select a date.");
    setFormError("");

    // Warning for an unusually high expense (kept from your original version)
    if (formType === "expense" && amount >= 50000) {
      const proceed = window.confirm("⚠️ This is a high-value expense. Please verify the amount carefully.");
      if (!proceed) return;
    }
    setShowVerification(true);
  };

  // Step 2: the user confirmed on the review page, so save it.
  const confirmSave = async () => {
    setSaving(true);
    try {
      await api(`/${formType}`, {
        method: "POST",
        body: { amount: Number(draft.amount), category: draft.category, description: draft.description.trim(), date: draft.date },
      });
      await loadAll(); // refresh first, so the dashboard never flashes old totals
      notify(formType === "expense" ? "Expense saved successfully!" : "Income saved successfully!");
      setShowVerification(false);
      setFormType(null);
      setDraft(emptyDraft());
    } catch (error) {
      notify(error.message, "error");
      setFormError(error.message);
      setShowVerification(false); // go back to the form so the problem can be fixed
    } finally {
      setSaving(false);
    }
  };

  // -------------------------------------------------- saving suggestion state
  const setSuggestionState = async (key, status) => {
    const previous = suggestionStates;
    // update the screen immediately, then confirm with the server
    setSuggestionStates((current) => {
      const rest = current.filter((s) => s.key !== key);
      return status === "active" ? rest : [...rest, { key, status }];
    });
    try {
      await api("/suggestions/state", { method: "PUT", body: { key, status } });
    } catch (error) {
      setSuggestionStates(previous);
      notify(error.message, "error");
    }
  };

  // ------------------------------------------------ numbers for the top cards
  const totals = useMemo(() => {
    const totalIncome = sumByType(transactions, "income");
    const totalExpenses = sumByType(transactions, "expense");
    return { totalIncome, totalExpenses, totalSavings: totalIncome - totalExpenses };
  }, [transactions]);

  const overdueBills = useMemo(() => bills.filter((b) => billStatus(b) === "overdue"), [bills]);

  // =============================================================== SCREENS
  // Smart Data Verification page
  if (user && showVerification) {
    return (
      <div className="verification-page">
        <div className="verification-card">
          <div className="verification-header">
            <h2>Review Transaction</h2>
            <p>Please review the transaction details before saving.</p>
          </div>

          <div className="verification-status">
            <span className="status-dot"></span>
            Details are ready for confirmation
          </div>

          <div className="transaction-details">
            <div className="detail-row"><span>Transaction Type</span><strong>{formType === "expense" ? "Expense" : "Income"}</strong></div>
            <div className="detail-row"><span>Amount</span><strong>{formatINR(Number(draft.amount))}</strong></div>
            <div className="detail-row"><span>Category</span><strong>{draft.category}</strong></div>
            <div className="detail-row"><span>Description</span><strong>{draft.description || "No description"}</strong></div>
            <div className="detail-row"><span>Date</span><strong>{draft.date}</strong></div>
          </div>

          <p className="verification-note">Please make sure all the information above is correct.</p>

          <div className="verification-buttons">
            <button className="edit-verification" onClick={() => setShowVerification(false)} disabled={saving}>Edit Details</button>
            <button className="confirm-verification" onClick={confirmSave} disabled={saving}>
              {saving ? "Saving…" : "Confirm & Save"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Checking a saved login
  if (checkingSession) {
    return <div className="splash"><div className="spinner" aria-label="Loading"></div><p>Loading your dashboard…</p></div>;
  }

  // Dashboard
  if (user) {
    return (
      <div className="dashboard">
        <header className="dashboard-header">
          <h1><span className="title-ai">AI</span> Expense Tracker</h1>

          <div className="user-section">
            <span className="user-name">👤 {user.name}</span>
            <button className="btn btn-ghost btn-sm" onClick={logout}>Logout</button>
          </div>
        </header>

        <nav className="tab-bar" aria-label="Dashboard sections">
          <div className="tab-bar-inner">
            {TABS.map((t) => (
              <button key={t.id} className={`nav-tab ${tab === t.id ? "active" : ""}`} aria-current={tab === t.id ? "page" : undefined} onClick={() => setTab(t.id)}>
                <span aria-hidden="true">{t.icon}</span> {t.label}
                {t.id === "bills" && overdueBills.length > 0 && <span className="nav-dot" title="Overdue bills">{overdueBills.length}</span>}
              </button>
            ))}
          </div>
        </nav>

        <main className="dashboard-content">
          {loadError && (
            <div className="alert-strip bad" role="alert">
              ⚠️ {loadError}{" "}
              <button className="link-button" onClick={() => { setLoading(true); loadAll().finally(() => setLoading(false)); }}>Try again</button>
            </div>
          )}

          {loading && <p className="muted">Loading your data…</p>}

          {tab === "overview" && (
            <>
              <h2 className="welcome">Welcome back, {user.name} 👋</h2>
              <p className="dashboard-subtitle">Here's your financial overview</p>

              {overdueBills.length > 0 && (
                <div className="alert-strip bad">
                  ⚠️ You have {overdueBills.length} overdue bill{overdueBills.length === 1 ? "" : "s"}.{" "}
                  <button className="link-button" onClick={() => setTab("bills")}>View bills</button>
                </div>
              )}

              <div className="summary-cards">
                <div className="summary-card income-card">
                  <span className="summary-label">Total Income</span>
                  <h2>{formatINR(totals.totalIncome)}</h2>
                  <p>Money received</p>
                </div>
                <div className="summary-card expense-card">
                  <span className="summary-label">Total Expenses</span>
                  <h2>{formatINR(totals.totalExpenses)}</h2>
                  <p>Money spent</p>
                </div>
                <div className="summary-card savings-card">
                  <span className="summary-label">Total Savings</span>
                  <h2 className={totals.totalSavings < 0 ? "text-bad" : ""}>{formatINR(totals.totalSavings)}</h2>
                  <p>Income − Expenses</p>
                </div>
              </div>

              <BalanceCard transactions={transactions} />

              <div className="action-buttons">
                <button className="btn btn-primary" onClick={() => openForm("expense")}>＋ Add Expense</button>
                <button className="btn btn-success" onClick={() => openForm("income")}>＋ Add Income</button>
              </div>

              {formType && (
                <TransactionForm
                  type={formType} draft={draft} setDraft={setDraft} error={formError}
                  onSubmit={handleFormSubmit} onCancel={() => { setFormType(null); setFormError(""); }}
                />
              )}

              <TransactionList transactions={transactions} onChanged={loadAll} />
              <Analytics transactions={transactions} />
            </>
          )}

          {tab === "goals" && <GoalPlanner goals={goals} transactions={transactions} onChanged={loadAll} />}
          {tab === "bills" && <BillReminder bills={bills} onChanged={loadAll} />}

          {tab === "insights" && (
            <div className="stack">
              <SavingSuggestions transactions={transactions} states={suggestionStates} onSetState={setSuggestionState} />
              <HealthScore transactions={transactions} bills={bills} />
            </div>
          )}

          {tab === "invest" && <InvestmentGuide transactions={transactions} />}
          {tab === "reports" && <ReportDownload transactions={transactions} />}
        </main>
      </div>
    );
  }

  // Login / Sign Up
  return (
    <div className="login-container">
      <div className="login-box">
        <h1><span className="title-ai">AI</span> Expense<br /> Tracker</h1>

        <p className="subtitle">{isSignup ? "Create your account to get started" : "Your pocket financial advisor"}</p>

        <form onSubmit={handleSubmit} noValidate>
          {isSignup && (
            <>
              <label htmlFor="name">Full Name</label>
              <input id="name" type="text" placeholder="Enter your full name" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
            </>
          )}

          <label htmlFor="email">Email</label>
          <input id="email" type="email" placeholder="Enter your email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />

          <label htmlFor="password">Password</label>
          <input id="password" type="password" placeholder="Enter your password" autoComplete={isSignup ? "new-password" : "current-password"} value={password} onChange={(e) => setPassword(e.target.value)} />

          {isSignup && (
            <>
              <label htmlFor="confirm">Confirm Password</label>
              <input id="confirm" type="password" placeholder="Confirm your password" autoComplete="new-password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
            </>
          )}

          {authError && <p className="form-error auth-error" role="alert">{authError}</p>}

          <button type="submit" disabled={authBusy}>
            {authBusy ? "Please wait…" : isSignup ? "Create Account" : "Login"}
          </button>
        </form>

        <p className="signup-text">
          {isSignup ? "Already have an account? " : "Don't have an account? "}
          <span role="button" tabIndex={0} onClick={() => { setIsSignup(!isSignup); setAuthError(""); }}
            onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (setIsSignup(!isSignup), setAuthError(""))}>
            {isSignup ? "Login" : "Sign Up"}
          </span>
        </p>
      </div>
    </div>
  );
}

export default App;
