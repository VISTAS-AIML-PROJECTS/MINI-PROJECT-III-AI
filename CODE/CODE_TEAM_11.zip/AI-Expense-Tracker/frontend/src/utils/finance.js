/*
  finance.js  -  all the money calculations in one place
  ------------------------------------------------------
  These are plain JavaScript functions (no React inside), so they are easy to
  read and easy to test. Every dashboard feature (About My Balance, Goal
  Analysis, Saving Suggestions, Financial Health Score) calls these functions
  with the SAME `transactions` list, so when a transaction is added, edited or
  deleted, everything updates together and always agrees.

  Nothing here invents data: if there is not enough history, the functions say
  so instead of guessing.
*/

export const EXPENSE_CATEGORIES = ["Food", "Transport", "Shopping", "Entertainment", "Bills", "Education", "Health", "Other"];
export const INCOME_CATEGORIES = ["Salary", "Freelance", "Business", "Allowance", "Investment", "Other"];
export const BILL_CATEGORIES = [
  "Electricity", "Water", "Internet", "Mobile Recharge", "Rent",
  "Insurance", "Subscription", "Loan / EMI", "Other",
];

const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

// ---------------------------------------------------------------------------
// Formatting
// ---------------------------------------------------------------------------
const inrFormatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});
const inrWholeFormatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

/** 125000 -> "₹1,25,000.00" (Indian digit grouping) */
export function formatINR(value, whole = false) {
  const number = Number(value) || 0;
  return (whole ? inrWholeFormatter : inrFormatter).format(number === 0 ? 0 : number); // avoids "-₹0.00"
}

/** Short axis labels for charts: 120000 -> "₹1.2L" */
export function formatCompactINR(value) {
  const n = Number(value) || 0;
  const abs = Math.abs(n);
  if (abs >= 10000000) return `₹${+(n / 10000000).toFixed(1)}Cr`;
  if (abs >= 100000) return `₹${+(n / 100000).toFixed(1)}L`;
  if (abs >= 1000) return `₹${+(n / 1000).toFixed(1)}k`;
  return `₹${n}`;
}

export function formatPercent(value, digits = 1) {
  return `${(Number(value) || 0).toFixed(digits)}%`;
}

// ---------------------------------------------------------------------------
// Dates  (all in the user's LOCAL time, so "today" is correct in India too.
// Using new Date().toISOString() would give the UTC date, which is wrong
// between midnight and 5:30 AM in India.)
// ---------------------------------------------------------------------------
export function todayISO(now = new Date()) {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export const monthKey = (isoDate) => String(isoDate || "").slice(0, 7); // "2026-09"

export function monthLabel(key) {
  const [year, month] = key.split("-").map(Number);
  if (!year || !month) return key;
  return `${MONTH_NAMES[month - 1]} ${year}`;
}

export function previousMonthKey(key) {
  const [year, month] = key.split("-").map(Number);
  return month === 1 ? `${year - 1}-12` : `${year}-${String(month - 1).padStart(2, "0")}`;
}

function parseISO(iso) {
  const [y, m, d] = String(iso).split("-").map(Number);
  return Date.UTC(y, (m || 1) - 1, d || 1);
}

/** Whole days from date a to date b (negative if b is earlier). */
export function daysBetween(aISO, bISO) {
  return Math.round((parseISO(bISO) - parseISO(aISO)) / 86400000);
}

/** Add whole months to an ISO date, keeping the day inside the target month. */
export function addMonthsISO(iso, months) {
  const [y, m, d] = iso.split("-").map(Number);
  const total = y * 12 + (m - 1) + months;
  const year = Math.floor(total / 12);
  const month = total % 12;
  const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  return `${year}-${String(month + 1).padStart(2, "0")}-${String(Math.min(d, lastDay)).padStart(2, "0")}`;
}

export function formatDateLong(iso) {
  const [y, m, d] = String(iso).split("-").map(Number);
  if (!y) return iso;
  return `${d} ${MONTH_NAMES[m - 1]} ${y}`;
}

// ---------------------------------------------------------------------------
// Basic totals
// ---------------------------------------------------------------------------
export const sumByType = (transactions, type) =>
  transactions.filter((t) => t.type === type).reduce((total, t) => total + Number(t.amount), 0);

export function expenseTotalsByCategory(transactions) {
  return transactions
    .filter((t) => t.type === "expense")
    .reduce((totals, t) => {
      totals[t.category] = (totals[t.category] || 0) + Number(t.amount);
      return totals;
    }, {});
}

/** { "2026-09": { income, expense } } for every month that has a transaction */
export function monthlyTotals(transactions) {
  const months = {};
  transactions.forEach((t) => {
    const key = monthKey(t.date);
    if (!key) return;
    months[key] = months[key] || { income: 0, expense: 0 };
    months[key][t.type === "income" ? "income" : "expense"] += Number(t.amount);
  });
  return months;
}

/**
  History used for estimates: the last `maxMonths` calendar months that
  actually contain transactions. Months with no records are NOT counted
  (we do not invent zero-income or zero-expense months).
*/
export function getHistory(transactions, maxMonths = 6) {
  const totals = monthlyTotals(transactions);
  const keys = Object.keys(totals).sort().slice(-maxMonths);
  const months = keys.map((key) => ({
    key,
    income: totals[key].income,
    expense: totals[key].expense,
    savings: totals[key].income - totals[key].expense,
  }));
  const count = months.length;
  const income = months.reduce((s, m) => s + m.income, 0);
  const expense = months.reduce((s, m) => s + m.expense, 0);
  return {
    months,
    monthCount: count,
    totalIncome: income,
    totalExpense: expense,
    avgIncome: count ? income / count : 0,
    avgExpense: count ? expense / count : 0,
    avgSurplus: count ? (income - expense) / count : 0,
  };
}

// ---------------------------------------------------------------------------
// Feature 3: About My Balance
// ---------------------------------------------------------------------------
export function computeBalanceSummary(transactions, today = todayISO()) {
  const totalIncome = sumByType(transactions, "income");
  const totalExpenses = sumByType(transactions, "expense");
  const balance = totalIncome - totalExpenses; // identical to the "Total Savings" card

  const currentKey = monthKey(today);
  const prevKey = previousMonthKey(currentKey);
  const inMonth = (key, type) =>
    transactions.filter((t) => t.type === type && monthKey(t.date) === key).reduce((s, t) => s + Number(t.amount), 0);
  const hasExpenseIn = (key) => transactions.some((t) => t.type === "expense" && monthKey(t.date) === key);

  const monthIncome = inMonth(currentKey, "income");
  const monthExpenses = inMonth(currentKey, "expense");
  const prevMonthExpenses = inMonth(prevKey, "expense");

  const categoryTotals = Object.entries(expenseTotalsByCategory(transactions)).sort((a, b) => b[1] - a[1]);
  const topCategory =
    categoryTotals.length && totalExpenses > 0
      ? { name: categoryTotals[0][0], amount: categoryTotals[0][1], percent: (categoryTotals[0][1] / totalExpenses) * 100 }
      : null;

  const percentSpent = totalIncome > 0 ? (totalExpenses / totalIncome) * 100 : null;
  const savingsRate = totalIncome > 0 ? (balance / totalIncome) * 100 : null;

  // Plain-language statements. Each one is only added when the data supports it.
  const statements = [];
  if (transactions.length === 0) {
    statements.push("Add your income and expenses to see a summary of your finances.");
  } else {
    if (totalIncome === 0) statements.push("You have not recorded any income yet, so savings and spending percentages cannot be calculated.");
    else if (balance > 0) statements.push("Your income is higher than your expenses.");
    else if (balance < 0) statements.push("Your expenses are currently higher than your income.");
    else statements.push("Your income and expenses are equal, so nothing is left over.");

    if (topCategory) statements.push(`Your largest expense category is ${topCategory.name}.`);

    if (hasExpenseIn(currentKey) && hasExpenseIn(prevKey)) {
      if (monthExpenses > prevMonthExpenses) {
        statements.push(`Your expenses so far this month (${formatINR(monthExpenses, true)}) are already higher than last month's total (${formatINR(prevMonthExpenses, true)}).`);
      } else if (monthExpenses < prevMonthExpenses) {
        statements.push(`Your expenses so far this month (${formatINR(monthExpenses, true)}) are lower than last month's total (${formatINR(prevMonthExpenses, true)}).`);
      } else {
        statements.push("Your expenses this month match last month's total.");
      }
    }
    if (totalIncome > 0 && monthIncome === 0) statements.push("No income has been recorded for the current month yet.");
  }

  return {
    totalIncome, totalExpenses, balance, monthIncome, monthExpenses,
    percentSpent, savingsRate, topCategory, statements,
    hasData: transactions.length > 0,
  };
}

// ---------------------------------------------------------------------------
// Feature 1: Goal maths
// ---------------------------------------------------------------------------
export function computeGoalMetrics(goal, today = todayISO()) {
  const target = Number(goal.target_amount) || 0;
  const saved = Number(goal.current_savings) || 0;

  const remaining = Math.max(0, target - saved);           // Remaining = Target - Saved
  const progress = target > 0 ? clamp((saved / target) * 100, 0, 100) : 0; // Progress = Saved / Target x 100
  const completed = target > 0 && saved >= target;
  const exceededBy = Math.max(0, saved - target);

  const daysLeft = daysBetween(today, goal.target_date);
  const overdue = !completed && daysLeft < 0;
  // Months remaining is rounded UP and is at least 1, so we never divide by zero.
  const monthsLeft = daysLeft >= 0 ? Math.max(1, Math.ceil(daysLeft / 30.4375)) : 0;
  // Monthly Saving Required = Remaining / Months Remaining
  const monthlyRequired = completed ? 0 : overdue ? null : remaining / monthsLeft;

  return {
    target, saved, remaining, progress, completed, exceededBy,
    daysLeft, monthsLeft, overdue, monthlyRequired,
    status: completed ? "completed" : overdue ? "overdue" : "active",
  };
}

// ---------------------------------------------------------------------------
// Feature 2: Goal analysis (transparent rule-based estimate - NOT a live AI model)
// ---------------------------------------------------------------------------
export function analyzeGoal(goal, metrics, history, combinedRequired = null, today = todayISO()) {
  const base = {
    required: metrics.monthlyRequired,
    surplus: history.avgSurplus,
    difference: null,
    monthCount: history.monthCount,
    suggestions: [],
    notes: [],
  };

  if (metrics.completed) {
    return {
      ...base, verdict: "completed", tone: "good",
      title: "Goal completed",
      explanation: "You have already saved the full target amount, so no more monthly saving is needed for this goal.",
      suggestions: ["Consider creating a new goal for your next milestone."],
    };
  }

  if (history.monthCount === 0) {
    return {
      ...base, verdict: "no-data", tone: "neutral", surplus: null,
      title: "Not enough transaction history",
      explanation: metrics.overdue
        ? "The target date has passed. Add your income and expenses to get an estimate of how long the goal may take."
        : "Add your income and expenses so the app can compare your monthly surplus with what this goal requires.",
      suggestions: ["Record at least one month of income and expenses."],
    };
  }

  const surplus = history.avgSurplus;
  const notes = [];
  if (history.monthCount < 3) {
    notes.push(`This estimate uses only ${history.monthCount} month${history.monthCount === 1 ? "" : "s"} of recorded data, so treat it as a rough guide.`);
  }
  if (history.avgIncome === 0) notes.push("No income is recorded in these months, so the surplus only reflects expenses.");

  // The date on which the goal could be reached at the current surplus
  const monthsAtSurplus = surplus > 0 ? Math.ceil(metrics.remaining / surplus) : null;
  const suggestedDate = monthsAtSurplus ? addMonthsISO(today, monthsAtSurplus) : null;

  if (metrics.overdue) {
    const suggestions = ["Extend the target date so the goal becomes realistic again."];
    if (suggestedDate) suggestions.push(`At your estimated surplus, the remaining amount could take about ${monthsAtSurplus} month${monthsAtSurplus === 1 ? "" : "s"} (around ${formatDateLong(suggestedDate)}). This is an estimate, not a guarantee.`);
    else suggestions.push("Your recorded expenses are equal to or higher than your income, so first look for ways to create a monthly surplus.");
    return {
      ...base, verdict: "overdue", tone: "warn", notes, suggestedDate,
      title: "The target date has passed",
      explanation: `You still need ${formatINR(metrics.remaining, true)} but the deadline is over.`,
      suggestions,
    };
  }

  const required = metrics.monthlyRequired;
  const difference = surplus - required; // positive = room to spare, negative = shortfall
  const common = { ...base, required, surplus, difference, notes, suggestedDate };

  // Several goals share the same surplus - warn when they cannot all be funded
  if (combinedRequired !== null && combinedRequired > Math.max(surplus, 0) && surplus > 0 && required <= surplus) {
    notes.push(`Your active goals together need about ${formatINR(combinedRequired, true)} per month, which is more than your estimated surplus of ${formatINR(surplus, true)}. The same surplus cannot fund all of them at once.`);
  }

  if (surplus <= 0) {
    return {
      ...common, verdict: "no-surplus", tone: "bad",
      title: "No monthly surplus available",
      explanation: `In your recorded months, expenses were equal to or higher than income (average difference ${formatINR(surplus, true)} per month), so there is currently no surplus to put toward this goal.`,
      suggestions: [
        "You may need to reduce expenses to reach this target.",
        "Look at the Saving Suggestions section for categories to trim.",
        "Your target date may need to be extended.",
      ],
    };
  }

  const usedShare = (required / surplus) * 100;

  if (required <= surplus * 0.8) {
    return {
      ...common, verdict: "comfortable", tone: "good",
      title: "Looks achievable",
      explanation: `Your current monthly surplus may be sufficient for this goal. The goal needs about ${formatINR(required, true)} per month, which is ${usedShare.toFixed(0)}% of your estimated surplus.`,
      suggestions: [
        "Consider setting up a fixed monthly transfer for this goal.",
        "Your surplus can change from month to month, so review this analysis regularly.",
      ],
    };
  }

  if (required <= surplus) {
    return {
      ...common, verdict: "tight", tone: "warn",
      title: "Possible, but tight",
      explanation: `The goal needs about ${formatINR(required, true)} per month, which is ${usedShare.toFixed(0)}% of your estimated surplus. That leaves very little room if your spending rises.`,
      suggestions: [
        "Consider increasing your monthly savings gradually.",
        "Keep some buffer for unexpected expenses, or extend the target date slightly.",
      ],
    };
  }

  const shortfall = required - surplus;
  const cutPercent = history.avgExpense > 0 ? (shortfall / history.avgExpense) * 100 : null;
  const suggestions = [
    cutPercent !== null
      ? `You may need to reduce expenses by about ${formatINR(shortfall, true)} per month (roughly ${cutPercent.toFixed(0)}% of your average spending) to reach this target.`
      : "You may need to reduce expenses to reach this target.",
    `Your target date may need to be extended - at your estimated surplus the remaining amount could take about ${monthsAtSurplus} month${monthsAtSurplus === 1 ? "" : "s"} (around ${formatDateLong(suggestedDate)}).`,
    "Consider increasing your monthly savings gradually, or increasing your income.",
  ];
  return {
    ...common, verdict: "shortfall", tone: "bad",
    title: "Required savings exceed your surplus",
    explanation: `The goal needs about ${formatINR(required, true)} per month, but your estimated monthly surplus is ${formatINR(surplus, true)} - a gap of ${formatINR(shortfall, true)} per month.`,
    suggestions,
  };
}

// ---------------------------------------------------------------------------
// Feature 5: Saving suggestions
// ---------------------------------------------------------------------------
/*
  How categories are treated:
    essential     (Bills, Health, Education)  -> we never tell you to "cut" these.
                  We only mention them for information.
    flexible      (Food, Transport)           -> partly needed, small trims possible.
    discretionary (Shopping, Entertainment, Other) -> best place to look for savings.
*/
export const CATEGORY_KIND = {
  Bills: "essential", Health: "essential", Education: "essential",
  Food: "flexible", Transport: "flexible",
  Shopping: "discretionary", Entertainment: "discretionary", Other: "discretionary",
};

export const MIN_EXPENSES_FOR_SUGGESTIONS = 5;
const REDUCTION = 0.1; // the "reduce by 10%" example

export function buildSuggestions(transactions, today = todayISO()) {
  const expenseCount = transactions.filter((t) => t.type === "expense").length;
  if (expenseCount < MIN_EXPENSES_FOR_SUGGESTIONS) {
    return { enoughData: false, expenseCount, items: [] };
  }

  const history = getHistory(transactions);
  const historyKeys = new Set(history.months.map((m) => m.key));
  const inHistory = transactions.filter((t) => t.type === "expense" && historyKeys.has(monthKey(t.date)));
  const perCategory = expenseTotalsByCategory(inHistory);
  const avgTotalExpense = history.avgExpense;
  const items = [];

  const rows = Object.entries(perCategory)
    .map(([name, total]) => ({ name, avg: total / history.monthCount, share: avgTotalExpense > 0 ? (total / history.monthCount / avgTotalExpense) * 100 : 0 }))
    .sort((a, b) => b.avg - a.avg);

  // A) Reduce flexible / discretionary categories that are a big part of spending
  rows
    .filter((r) => CATEGORY_KIND[r.name] !== "essential" && r.avg >= 500 && r.share >= 10)
    .slice(0, 3)
    .forEach((r) => {
      const kind = CATEGORY_KIND[r.name] || "discretionary";
      const potential = r.avg * REDUCTION;
      items.push({
        key: `reduce:${r.name}`, type: "reduce", category: r.name, potentialMonthly: potential,
        title: `Trim ${r.name} spending by 10%`,
        detail: `${r.name} makes up ${r.share.toFixed(0)}% of your expenses (about ${formatINR(r.avg, true)} per month). Reducing it by 10% could save approximately ${formatINR(potential, true)} per month based on your recorded spending.` +
          (kind === "flexible" ? ` ${r.name} is partly a necessity, so aim for small changes rather than big cuts.` : ""),
      });
    });

  // B) Essential categories: information only, no "cut" advice
  rows
    .filter((r) => CATEGORY_KIND[r.name] === "essential" && r.share >= 25)
    .slice(0, 1)
    .forEach((r) => {
      items.push({
        key: `info:${r.name}`, type: "info", category: r.name, potentialMonthly: null,
        title: `${r.name} is a large part of your spending`,
        detail: `${r.name} accounts for ${r.share.toFixed(0)}% of your expenses. This is usually an essential expense, so instead of cutting it, check whether a cheaper plan or provider is available.`,
      });
    });

  // C) Categories that rose compared with last month (month-to-date)
  const currentKey = monthKey(today);
  const prevKey = previousMonthKey(currentKey);
  const monthCategory = (key) => expenseTotalsByCategory(transactions.filter((t) => monthKey(t.date) === key));
  const hasPrev = transactions.some((t) => t.type === "expense" && monthKey(t.date) === prevKey);
  if (hasPrev) {
    const cur = monthCategory(currentKey);
    const prev = monthCategory(prevKey);
    Object.keys(cur)
      .filter((name) => prev[name] > 0 && cur[name] > prev[name] * 1.2 && cur[name] - prev[name] >= 500)
      .sort((a, b) => cur[b] - prev[b] - (cur[a] - prev[a]))
      .slice(0, 2)
      .forEach((name) => {
        const rise = cur[name] - prev[name];
        items.push({
          key: `rise:${name}:${currentKey}`, type: "rise", category: name, potentialMonthly: rise,
          title: `${name} expenses increased compared with last month`,
          detail: `So far this month you have spent ${formatINR(cur[name], true)} on ${name}, compared with ${formatINR(prev[name], true)} for all of last month. Returning to last month's level would save about ${formatINR(rise, true)}.`,
        });
      });
  }

  // D) Overall savings level
  if (history.avgIncome > 0) {
    const rate = (history.avgSurplus / history.avgIncome) * 100;
    if (history.avgSurplus < 0) {
      items.push({
        key: "overspend", type: "rate", potentialMonthly: -history.avgSurplus,
        title: "You spend more than you earn",
        detail: `On average your recorded expenses were ${formatINR(-history.avgSurplus, true)} per month higher than your income. Bringing spending down to your income level is the first step.`,
      });
    } else if (rate < 10) {
      const gap = history.avgIncome * 0.2 - history.avgSurplus;
      items.push({
        key: "low-savings-rate", type: "rate", potentialMonthly: gap,
        title: "Your savings rate is low",
        detail: `You are saving about ${rate.toFixed(0)}% of your income. A common guideline is to save around 20%, which would mean roughly ${formatINR(gap, true)} more per month. This is only a guideline - your situation may differ.`,
      });
    }
  }

  return { enoughData: true, expenseCount, monthCount: history.monthCount, items };
}

// ---------------------------------------------------------------------------
// Bills helpers (Feature 6)
// ---------------------------------------------------------------------------
export const DUE_SOON_DAYS = 7;

/** "paid" | "overdue" | "due-soon" | "upcoming" - uses the user's local date */
export function billStatus(bill, today = todayISO()) {
  if (bill.status === "paid") return "paid";
  const days = daysBetween(today, bill.due_date);
  if (days < 0) return "overdue";
  if (days <= DUE_SOON_DAYS) return "due-soon";
  return "upcoming";
}

// ---------------------------------------------------------------------------
// Feature 7: Financial Health Score
// ---------------------------------------------------------------------------
/*
  SCORING FORMULA (each factor earns points up to its weight; total = 100)

  1. Savings rate        30 pts   rate = (income - expenses) / income
                                   points = 30 x clamp(rate / 20%, 0, 1)
                                   -> saving 20% or more of income earns full points
  2. Spending vs income  25 pts   ratio = expenses / income
                                   points = 25 x clamp((1 - ratio) / 0.5, 0, 1)
                                   -> spending 50% of income or less earns full points,
                                      spending 100% or more earns 0
  3. Savings consistency 20 pts   share of recorded months where income > expenses
                                   points = 20 x share   (needs at least 2 months)
  4. Budget adherence    15 pts   NOT AVAILABLE - the app has no user-set budgets
  5. Bill payments       10 pts   bills that are paid on time / (paid + overdue bills)
                                   points = 10 x share   (needs at least 1 such bill)

  Factors without enough data are LEFT OUT (they are not counted as zero).
  Final score = points earned / points possible x 100, using only the
  available factors. Missing data therefore never lowers the score.
  No score is shown at all with fewer than 5 transactions or no income.
*/
export const MIN_TRANSACTIONS_FOR_SCORE = 5;

export function computeHealthScore(transactions, bills = [], today = todayISO()) {
  const history = getHistory(transactions);

  if (transactions.length < MIN_TRANSACTIONS_FOR_SCORE || history.totalIncome <= 0) {
    return {
      available: false,
      reason: transactions.length < MIN_TRANSACTIONS_FOR_SCORE
        ? `Add at least ${MIN_TRANSACTIONS_FOR_SCORE} transactions (you have ${transactions.length}) to see your score.`
        : "Record some income to see your score - the score compares your spending with your income.",
    };
  }

  const factors = [];
  const rate = ((history.totalIncome - history.totalExpense) / history.totalIncome) * 100;
  const ratio = history.totalExpense / history.totalIncome;

  factors.push({
    id: "savings-rate", name: "Savings rate", weight: 30, available: true,
    points: 30 * clamp(rate / 20, 0, 1),
    value: `${rate.toFixed(1)}% of income saved`,
    explanation: "Saving 20% or more of your income earns full points.",
    tip: "Try to move a fixed part of your income into savings as soon as you receive it.",
  });

  factors.push({
    id: "spending-ratio", name: "Spending vs income", weight: 25, available: true,
    points: 25 * clamp((1 - ratio) / 0.5, 0, 1),
    value: `Expenses are ${(ratio * 100).toFixed(1)}% of income`,
    explanation: "Spending 50% of income or less earns full points; spending all of it earns none.",
    tip: "Look at your largest expense categories in Saving Suggestions to bring spending down.",
  });

  if (history.monthCount >= 2) {
    const positive = history.months.filter((m) => m.savings > 0).length;
    factors.push({
      id: "consistency", name: "Savings consistency", weight: 20, available: true,
      points: 20 * (positive / history.monthCount),
      value: `Saved money in ${positive} of ${history.monthCount} months`,
      explanation: "Earns points for every recorded month where income was higher than expenses.",
      tip: "Aim to stay below your income every month, not just on average.",
    });
  } else {
    factors.push({
      id: "consistency", name: "Savings consistency", weight: 20, available: false, points: 0,
      value: "Not enough data",
      explanation: "Needs at least 2 months of transactions. It is left out of your score until then.",
      tip: "",
    });
  }

  factors.push({
    id: "budget", name: "Budget adherence", weight: 15, available: false, points: 0,
    value: "Not available",
    explanation: "You have not set any budgets, so this factor is left out. It does not lower your score.",
    tip: "",
  });

  const relevantBills = bills.filter((b) => b.status === "paid" || billStatus(b, today) === "overdue");
  if (relevantBills.length > 0) {
    const onTime = relevantBills.filter((b) => b.status === "paid" && (!b.paid_date || b.paid_date <= b.due_date)).length;
    factors.push({
      id: "bills", name: "Bill payments", weight: 10, available: true,
      points: 10 * (onTime / relevantBills.length),
      value: `${onTime} of ${relevantBills.length} bills paid on time`,
      explanation: "Paid-on-time bills earn points. Overdue or late bills reduce this factor.",
      tip: "Pay overdue bills and mark them as paid in the Bill Reminder section.",
    });
  } else {
    factors.push({
      id: "bills", name: "Bill payments", weight: 10, available: false, points: 0,
      value: "No paid or overdue bills yet",
      explanation: "Add bills in the Bill Reminder section to include this factor. It is left out until then.",
      tip: "",
    });
  }

  const usable = factors.filter((f) => f.available);
  const earned = usable.reduce((s, f) => s + f.points, 0);
  const possible = usable.reduce((s, f) => s + f.weight, 0);
  const score = Math.round((earned / possible) * 100);

  let level = "Needs attention";
  let tone = "bad";
  if (score >= 80) { level = "Strong"; tone = "good"; }
  else if (score >= 60) { level = "Good"; tone = "good"; }
  else if (score >= 40) { level = "Fair"; tone = "warn"; }

  const improvements = usable.filter((f) => f.points < f.weight * 0.7 && f.tip).map((f) => f.tip);

  return {
    available: true, score, level, tone, factors, improvements,
    monthCount: history.monthCount,
    limited: history.monthCount < 3,
  };
}
