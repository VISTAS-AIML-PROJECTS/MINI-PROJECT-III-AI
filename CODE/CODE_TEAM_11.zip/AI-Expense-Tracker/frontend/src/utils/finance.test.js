// Run with:  npm test      (uses Node's built-in test runner, no extra packages)
import test from "node:test";
import assert from "node:assert/strict";
import {
  addMonthsISO, analyzeGoal, billStatus, buildSuggestions, computeBalanceSummary,
  computeGoalMetrics, computeHealthScore, daysBetween, formatINR, getHistory, todayISO,
} from "./finance.js";

const T = (id, type, amount, category, date) => ({ id, type, amount, category, description: "", date });
const TODAY = "2026-09-30";

// Same numbers as a real sample user: Aug + Sep 2026
const sample = [
  T(1, "expense", 15000, "Other", "2026-09-16"),
  T(2, "expense", 1000, "Food", "2026-09-14"),
  T(3, "expense", 250, "Transport", "2026-09-05"),
  T(4, "income", 70000, "Salary", "2026-09-10"),
  T(5, "expense", 4496, "Health", "2026-08-09"),
  T(6, "expense", 5672, "Shopping", "2026-08-15"),
  T(7, "income", 70000, "Salary", "2026-08-01"),
];

test("dates use local calendar day and handle month ends", () => {
  assert.equal(todayISO(new Date(2026, 8, 30, 0, 30)), "2026-09-30"); // local, not UTC
  assert.equal(daysBetween("2026-09-30", "2026-10-05"), 5);
  assert.equal(daysBetween("2026-09-30", "2026-09-29"), -1);
  assert.equal(addMonthsISO("2026-01-31", 1), "2026-02-28");
  assert.equal(addMonthsISO("2026-11-15", 3), "2027-02-15");
});

test("formatINR uses Indian grouping and never shows -0", () => {
  assert.equal(formatINR(125000), "₹1,25,000.00");
  assert.equal(formatINR(-0), "₹0.00");
  assert.equal(formatINR(1234567.5, true), "₹12,34,568");
});

test("balance equals income minus expenses (matches Total Savings card)", () => {
  const b = computeBalanceSummary(sample, TODAY);
  assert.equal(b.balance, 140000 - (15000 + 1000 + 250 + 4496 + 5672));
  assert.ok(Math.abs(b.savingsRate - (b.balance / 140000) * 100) < 1e-9);
  assert.equal(b.topCategory.name, "Other");
  assert.equal(b.monthIncome, 70000);
  assert.ok(b.statements.includes("Your income is higher than your expenses."));
  assert.ok(b.statements.some((s) => s.includes("already higher than last month")));
});

test("balance handles no data, zero income and negative balance", () => {
  const none = computeBalanceSummary([], TODAY);
  assert.equal(none.balance, 0);
  assert.equal(none.percentSpent, null);
  assert.equal(none.savingsRate, null);
  assert.equal(none.topCategory, null);

  const zeroIncome = computeBalanceSummary([T(1, "expense", 500, "Food", "2026-09-01")], TODAY);
  assert.equal(zeroIncome.savingsRate, null);
  assert.equal(zeroIncome.percentSpent, null);
  assert.ok(zeroIncome.statements[0].includes("not recorded any income"));

  const negative = computeBalanceSummary([T(1, "income", 100, "Salary", "2026-09-01"), T(2, "expense", 300, "Food", "2026-09-02")], TODAY);
  assert.equal(negative.balance, -200);
  assert.ok(negative.statements.includes("Your expenses are currently higher than your income."));

  const equal = computeBalanceSummary([T(1, "income", 300, "Salary", "2026-09-01"), T(2, "expense", 300, "Food", "2026-09-02")], TODAY);
  assert.equal(equal.balance, 0);
  assert.ok(equal.statements[0].includes("equal"));
});

test("no month comparison statement when there is no previous-month data", () => {
  const b = computeBalanceSummary([T(1, "income", 1000, "Salary", "2026-09-01"), T(2, "expense", 100, "Food", "2026-09-02")], TODAY);
  assert.ok(!b.statements.some((s) => s.includes("last month")));
});

test("goal metrics: normal goal", () => {
  const m = computeGoalMetrics({ target_amount: 60000, current_savings: 15000, target_date: "2027-03-30" }, TODAY);
  assert.equal(m.remaining, 45000);
  assert.equal(m.progress, 25);
  assert.equal(m.monthsLeft, 6);
  assert.equal(m.monthlyRequired, 7500);
  assert.equal(m.status, "active");
});

test("goal metrics: completed, exceeded, zero remaining", () => {
  const done = computeGoalMetrics({ target_amount: 1000, current_savings: 1000, target_date: "2027-01-01" }, TODAY);
  assert.equal(done.completed, true);
  assert.equal(done.remaining, 0);
  assert.equal(done.monthlyRequired, 0);
  const over = computeGoalMetrics({ target_amount: 1000, current_savings: 1500, target_date: "2027-01-01" }, TODAY);
  assert.equal(over.progress, 100);
  assert.equal(over.exceededBy, 500);
  assert.equal(over.status, "completed");
});

test("goal metrics: deadline today, past deadline, completed past goal", () => {
  const today = computeGoalMetrics({ target_amount: 1000, current_savings: 0, target_date: TODAY }, TODAY);
  assert.equal(today.monthsLeft, 1);
  assert.equal(today.monthlyRequired, 1000);
  const past = computeGoalMetrics({ target_amount: 1000, current_savings: 100, target_date: "2026-01-01" }, TODAY);
  assert.equal(past.overdue, true);
  assert.equal(past.monthlyRequired, null);
  assert.equal(past.status, "overdue");
  const pastDone = computeGoalMetrics({ target_amount: 1000, current_savings: 1000, target_date: "2026-01-01" }, TODAY);
  assert.equal(pastDone.status, "completed");
});

test("goal analysis: the example from the brief (income 30k, expenses 20k, needs 15k)", () => {
  const txs = [T(1, "income", 30000, "Salary", "2026-09-01"), T(2, "expense", 20000, "Other", "2026-09-02")];
  const history = getHistory(txs);
  const metrics = { monthlyRequired: 15000, remaining: 90000, completed: false, overdue: false };
  const a = analyzeGoal({}, metrics, history, null, TODAY);
  assert.equal(a.verdict, "shortfall");
  assert.equal(a.surplus, 10000);
  assert.equal(a.difference, -5000);
  assert.ok(a.explanation.includes("gap"));
  assert.ok(a.suggestions.some((s) => s.includes("reduce expenses")));
  assert.ok(a.notes.some((n) => n.includes("only 1 month")));
});

test("goal analysis verdicts: comfortable, tight, no surplus, no data, overdue, completed", () => {
  const rich = getHistory([T(1, "income", 50000, "Salary", "2026-09-01"), T(2, "expense", 20000, "Food", "2026-09-02")]); // surplus 30k
  const m = (required, extra = {}) => ({ monthlyRequired: required, remaining: required * 3, completed: false, overdue: false, ...extra });
  assert.equal(analyzeGoal({}, m(10000), rich, null, TODAY).verdict, "comfortable");
  assert.equal(analyzeGoal({}, m(27000), rich, null, TODAY).verdict, "tight");
  assert.equal(analyzeGoal({}, m(31000), rich, null, TODAY).verdict, "shortfall");

  const broke = getHistory([T(1, "income", 1000, "Salary", "2026-09-01"), T(2, "expense", 5000, "Food", "2026-09-02")]);
  assert.equal(analyzeGoal({}, m(100), broke, null, TODAY).verdict, "no-surplus");

  assert.equal(analyzeGoal({}, m(100), getHistory([]), null, TODAY).verdict, "no-data");
  assert.equal(analyzeGoal({}, m(null, { overdue: true }), rich, null, TODAY).verdict, "overdue");
  assert.equal(analyzeGoal({}, m(0, { completed: true }), rich, null, TODAY).verdict, "completed");
});

test("goal analysis warns when combined goals exceed the surplus", () => {
  const rich = getHistory([T(1, "income", 50000, "Salary", "2026-09-01"), T(2, "expense", 20000, "Food", "2026-09-02")]);
  const a = analyzeGoal({}, { monthlyRequired: 10000, remaining: 30000, completed: false, overdue: false }, rich, 45000, TODAY);
  assert.ok(a.notes.some((n) => n.includes("together")));
});

test("history counts only months that have transactions", () => {
  const h = getHistory([T(1, "income", 100, "Salary", "2026-01-01"), T(2, "income", 100, "Salary", "2026-05-01")]);
  assert.equal(h.monthCount, 2);
  assert.equal(getHistory([]).avgSurplus, 0);
});

test("suggestions: not enough data", () => {
  const s = buildSuggestions([T(1, "expense", 100, "Food", "2026-09-01")], TODAY);
  assert.equal(s.enoughData, false);
  assert.equal(s.items.length, 0);
});

test("suggestions: reduce, essential info, rise, low savings", () => {
  const txs = [
    T(1, "income", 40000, "Salary", "2026-08-01"), T(2, "income", 40000, "Salary", "2026-09-01"),
    T(3, "expense", 5000, "Food", "2026-08-05"), T(4, "expense", 5000, "Food", "2026-09-05"),
    T(5, "expense", 2000, "Shopping", "2026-08-10"), T(6, "expense", 8000, "Shopping", "2026-09-10"),
    T(7, "expense", 12000, "Bills", "2026-08-12"), T(8, "expense", 12000, "Bills", "2026-09-12"),
    T(9, "expense", 8000, "Entertainment", "2026-08-20"), T(10, "expense", 8000, "Entertainment", "2026-09-20"),
  ];
  const s = buildSuggestions(txs, TODAY);
  assert.equal(s.enoughData, true);
  const byKey = Object.fromEntries(s.items.map((i) => [i.key, i]));
  assert.ok(byKey["reduce:Food"]);
  assert.equal(Math.round(byKey["reduce:Food"].potentialMonthly), 500); // 10% of 5,000 avg
  assert.ok(!byKey["reduce:Bills"], "essential categories are never told to cut");
  assert.ok(byKey["info:Bills"]);
  assert.equal(byKey["info:Bills"].potentialMonthly, null);
  assert.ok(byKey["rise:Shopping:2026-09"]);
  assert.equal(byKey["rise:Shopping:2026-09"].potentialMonthly, 6000);
  assert.ok(!byKey["low-savings-rate"], "this sample saves 25% of income, so no low-savings hint");
});

test("suggestions: low savings rate hint appears below 10%", () => {
  const txs = [
    T(1, "income", 50000, "Salary", "2026-09-01"),
    ...[2, 3, 4, 5, 6].map((i) => T(i, "expense", 9200, "Bills", "2026-09-0" + i)),
  ]; // spends 46,000 of 50,000 -> saves 8%
  const item = buildSuggestions(txs, TODAY).items.find((i) => i.key === "low-savings-rate");
  assert.ok(item);
  assert.equal(Math.round(item.potentialMonthly), 6000); // 20% of 50,000 minus the 4,000 already saved
});

test("suggestions: no 'rise' suggestion without previous-month data; overspend detected", () => {
  const txs = [T(1, "income", 1000, "Salary", "2026-09-01"), ...[2, 3, 4, 5, 6].map((i) => T(i, "expense", 1000, "Shopping", "2026-09-0" + i))];
  const s = buildSuggestions(txs, TODAY);
  assert.ok(!s.items.some((i) => i.type === "rise"));
  assert.ok(s.items.some((i) => i.key === "overspend"));
});

test("bill status uses the given local date", () => {
  assert.equal(billStatus({ status: "unpaid", due_date: "2026-09-29" }, TODAY), "overdue");
  assert.equal(billStatus({ status: "unpaid", due_date: TODAY }, TODAY), "due-soon");
  assert.equal(billStatus({ status: "unpaid", due_date: "2026-10-07" }, TODAY), "due-soon");
  assert.equal(billStatus({ status: "unpaid", due_date: "2026-10-08" }, TODAY), "upcoming");
  assert.equal(billStatus({ status: "paid", due_date: "2020-01-01" }, TODAY), "paid");
});

test("health score: unavailable with little data or no income", () => {
  assert.equal(computeHealthScore([], [], TODAY).available, false);
  const fiveExpenses = [1, 2, 3, 4, 5].map((i) => T(i, "expense", 100, "Food", "2026-09-0" + i));
  const r = computeHealthScore(fiveExpenses, [], TODAY);
  assert.equal(r.available, false);
  assert.ok(r.reason.includes("income"));
});

test("health score: formula, skipped factors and bounds", () => {
  const good = [
    T(1, "income", 100000, "Salary", "2026-08-01"), T(2, "expense", 30000, "Food", "2026-08-02"),
    T(3, "income", 100000, "Salary", "2026-09-01"), T(4, "expense", 30000, "Food", "2026-09-02"),
    T(5, "expense", 100, "Food", "2026-09-03"),
  ];
  const r = computeHealthScore(good, [], TODAY);
  assert.equal(r.available, true);
  assert.equal(r.score, 100); // 30/30 + 25/25 + 20/20 over the available factors
  assert.equal(r.factors.find((f) => f.id === "budget").available, false);
  assert.equal(r.factors.find((f) => f.id === "bills").available, false);
  assert.equal(r.limited, true);

  const bad = [
    T(1, "income", 1000, "Salary", "2026-08-01"), T(2, "expense", 5000, "Food", "2026-08-02"),
    T(3, "income", 1000, "Salary", "2026-09-01"), T(4, "expense", 5000, "Food", "2026-09-02"),
    T(5, "expense", 100, "Food", "2026-09-03"),
  ];
  const b = computeHealthScore(bad, [], TODAY);
  assert.equal(b.score, 0);
  assert.equal(b.level, "Needs attention");
  assert.ok(b.improvements.length > 0);
});

test("health score: bills factor counts on-time vs late/overdue", () => {
  const txs = [
    T(1, "income", 100000, "Salary", "2026-08-01"), T(2, "expense", 30000, "Food", "2026-08-02"),
    T(3, "income", 100000, "Salary", "2026-09-01"), T(4, "expense", 30000, "Food", "2026-09-02"),
    T(5, "expense", 100, "Food", "2026-09-03"),
  ];
  const bills = [
    { status: "paid", due_date: "2026-09-10", paid_date: "2026-09-09" },
    { status: "unpaid", due_date: "2026-09-01" }, // overdue
    { status: "unpaid", due_date: "2026-12-01" }, // not due yet -> ignored
  ];
  const r = computeHealthScore(txs, bills, TODAY);
  const f = r.factors.find((x) => x.id === "bills");
  assert.equal(f.available, true);
  assert.equal(f.points, 5); // 1 of 2 on time
  assert.equal(r.score, Math.round(((30 + 25 + 20 + 5) / 85) * 100)); // (80/85 -> 94)
});
