/*
  api.js - one place that talks to the Flask backend.

  * The login token is saved in the browser (localStorage) so you stay logged in
    after a refresh, and it is sent with every request.
  * The backend address comes from VITE_API_URL (see .env.example). When it is
    not set, the local backend at http://127.0.0.1:5000 is used.
*/
export const API_URL = (import.meta.env.VITE_API_URL || "http://127.0.0.1:5000").replace(/\/$/, "");

const TOKEN_KEY = "aet_token";
let token = null;
try {
  token = localStorage.getItem(TOKEN_KEY);
} catch {
  token = null; // storage blocked - the user simply logs in again next time
}
let onUnauthorized = null;

export const getToken = () => token;

export function setToken(value) {
  token = value;
  try {
    if (value) localStorage.setItem(TOKEN_KEY, value);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore */
  }
}

/** App.jsx registers a function here that logs the user out when the token expires. */
export function setUnauthorizedHandler(handler) {
  onUnauthorized = handler;
}

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

/**
  api("/goals")                                   -> GET, returns JSON
  api("/goals", { method: "POST", body: {...} })  -> POST with JSON
  api("/report/monthly?...", { raw: true })       -> returns the Response (used for the PDF)
*/
export async function api(path, { method = "GET", body, raw = false } = {}) {
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = `Bearer ${token}`;

  let response;
  try {
    response = await fetch(`${API_URL}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError("Unable to connect to the server. Please check that the backend is running.", 0);
  }

  if (response.ok && raw) return response;

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    if (response.status === 401 && token && onUnauthorized) onUnauthorized();
    throw new ApiError((data && data.message) || "Something went wrong. Please try again.", response.status);
  }
  return data;
}
