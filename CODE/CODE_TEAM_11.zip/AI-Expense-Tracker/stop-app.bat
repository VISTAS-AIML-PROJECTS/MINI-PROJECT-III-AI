@echo off
rem Stops the backend and frontend windows started by start-app.bat
echo Stopping AI Expense Tracker...
taskkill /FI "WINDOWTITLE eq AI Expense Tracker - Backend*" /T /F >nul 2>nul
taskkill /FI "WINDOWTITLE eq AI Expense Tracker - Frontend*" /T /F >nul 2>nul
echo Done. Your data is safe in backend\instance\expense_tracker.db
timeout /t 3 >nul
