from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


# ---------------------------------------------------------------------------
# Existing tables (unchanged, so your current database keeps working)
# ---------------------------------------------------------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)


class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey("user.id"),
        nullable=False
    )

    type = db.Column(db.String(20), nullable=False)

    amount = db.Column(db.Float, nullable=False)

    category = db.Column(db.String(50), nullable=False)

    description = db.Column(db.String(200))

    date = db.Column(db.String(20), nullable=False)


# ---------------------------------------------------------------------------
# New tables (created automatically the first time the server starts)
# ---------------------------------------------------------------------------
class Goal(db.Model):
    """A savings goal, e.g. "Buy a Laptop". Every goal belongs to one user."""

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    target_amount = db.Column(db.Float, nullable=False)
    current_savings = db.Column(db.Float, nullable=False, default=0)
    target_date = db.Column(db.String(10), nullable=False)  # YYYY-MM-DD
    created_at = db.Column(db.String(10), nullable=False)   # YYYY-MM-DD


class Bill(db.Model):
    """A bill the user wants to be reminded about."""

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    due_date = db.Column(db.String(10), nullable=False)      # YYYY-MM-DD
    notes = db.Column(db.String(200))
    status = db.Column(db.String(10), nullable=False, default="unpaid")  # unpaid / paid
    paid_date = db.Column(db.String(10))                     # set when marked paid


class SuggestionState(db.Model):
    """Remembers which Saving Suggestions the user completed or dismissed."""

    __table_args__ = (
        db.UniqueConstraint("user_id", "suggestion_key", name="uq_user_suggestion"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    suggestion_key = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(12), nullable=False)        # completed / dismissed
