"""
AI Expense Tracker - Flask backend

What is in this file
--------------------
1. App setup (database, CORS, secret key)
2. Small helper functions (validation + login check)
3. Routes:
     Accounts      /signup  /login  /me
     Transactions  /expense  /income  /transactions  (+ edit / delete)
     Goals         /goals
     Bills         /bills
     Suggestions   /suggestions/state
     Report        /report/monthly   (PDF download)

Security idea (simple version)
------------------------------
When you log in, the server gives the browser a signed "token".
The browser sends that token with every request. The server reads the
user id FROM THE TOKEN, never from the request body or URL, so one user
can never read or change another user's data.
"""

import math
import os
import re
from datetime import date, datetime, timedelta
from functools import wraps

from flask import Flask, g, jsonify, request, send_file
from flask_cors import CORS
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash

from models import Bill, Goal, SuggestionState, Transaction, User, db
from report import build_monthly_report

# ---------------------------------------------------------------------------
# 1. App setup
# ---------------------------------------------------------------------------
app = Flask(__name__)

# Database: SQLite by default (same file as before: backend/instance/expense_tracker.db).
# For online hosting you can set DATABASE_URL (for example a PostgreSQL address).
database_url = os.environ.get("DATABASE_URL", "sqlite:///expense_tracker.db")
if database_url.startswith("postgres://"):  # some hosts still use the old prefix
    database_url = database_url.replace("postgres://", "postgresql://", 1)

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)


def load_secret_key():
    """Secret key used to sign login tokens.

    1. If the SECRET_KEY environment variable exists, use it (best for hosting).
    2. Otherwise create a random key once and keep it in backend/instance/,
       so users stay logged in after the server restarts.
    """
    env_key = os.environ.get("SECRET_KEY")
    if env_key:
        return env_key

    os.makedirs(app.instance_path, exist_ok=True)
    key_file = os.path.join(app.instance_path, "secret_key.txt")
    if os.path.exists(key_file):
        with open(key_file, "r", encoding="utf-8") as f:
            return f.read().strip()

    new_key = os.urandom(32).hex()
    with open(key_file, "w", encoding="utf-8") as f:
        f.write(new_key)
    return new_key


app.config["SECRET_KEY"] = load_secret_key()
token_serializer = URLSafeTimedSerializer(app.config["SECRET_KEY"], salt="login-token")
TOKEN_MAX_AGE_SECONDS = 7 * 24 * 60 * 60  # a login lasts 7 days

# CORS: which websites may call this API.
# Local development ports are always allowed. When you deploy, add your
# website address in the CORS_ORIGINS environment variable (comma separated).
allowed_origins = [re.compile(r"^http://(localhost|127\.0\.0\.1)(:\d+)?$")]
allowed_origins += [o.strip() for o in os.environ.get("CORS_ORIGINS", "").split(",") if o.strip()]
CORS(app, origins=allowed_origins, expose_headers=["Content-Disposition"])

# ---------------------------------------------------------------------------
# 2. Helpers
# ---------------------------------------------------------------------------
EXPENSE_CATEGORIES = ["Food", "Transport", "Shopping", "Entertainment", "Bills", "Education", "Health", "Other"]
INCOME_CATEGORIES = ["Salary", "Freelance", "Business", "Allowance", "Investment", "Other"]
BILL_CATEGORIES = [
    "Electricity", "Water", "Internet", "Mobile Recharge", "Rent",
    "Insurance", "Subscription", "Loan / EMI", "Other",
]
MAX_AMOUNT = 1_000_000_000  # 100 crore - protects against typing mistakes
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ApiError(Exception):
    """Raise this anywhere to send a clear JSON error message to the browser."""

    def __init__(self, message, status=400):
        super().__init__(message)
        self.message = message
        self.status = status


@app.errorhandler(ApiError)
def handle_api_error(error):
    return jsonify({"message": error.message}), error.status


@app.errorhandler(404)
def handle_404(_error):
    return jsonify({"message": "Not found"}), 404


@app.errorhandler(405)
def handle_405(_error):
    return jsonify({"message": "Method not allowed"}), 405


@app.errorhandler(500)
def handle_500(_error):
    db.session.rollback()
    return jsonify({"message": "Something went wrong on the server. Please try again."}), 500


def json_body():
    """Return the JSON sent by the browser as a dict (empty dict if missing/invalid)."""
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def parse_amount(value, field="Amount", allow_zero=False):
    if isinstance(value, bool) or value is None or str(value).strip() == "":
        raise ApiError(f"{field} is required.")
    try:
        amount = float(value)
    except (TypeError, ValueError):
        raise ApiError(f"{field} must be a number.")
    if not math.isfinite(amount):
        raise ApiError(f"{field} must be a valid number.")
    if amount < 0 or (amount == 0 and not allow_zero):
        raise ApiError(f"{field} cannot be negative." if allow_zero else f"{field} must be greater than 0.")
    if amount > MAX_AMOUNT:
        raise ApiError(f"{field} is too large.")
    return round(amount, 2)


def parse_date(value, field="Date"):
    """Accepts only real calendar dates written as YYYY-MM-DD."""
    text = str(value or "").strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        raise ApiError(f"{field} must be a valid date (YYYY-MM-DD).")
    try:
        parsed = datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        raise ApiError(f"{field} is not a real calendar date.")
    if parsed.year < 2000 or parsed.year > 2100:
        raise ApiError(f"{field} must be between the years 2000 and 2100.")
    return text


def clean_text(value, field, max_length, required=False):
    text = str(value or "").strip()
    if required and not text:
        raise ApiError(f"{field} is required.")
    if len(text) > max_length:
        raise ApiError(f"{field} must be at most {max_length} characters.")
    return text


def login_required(view):
    """Decorator: the route runs only when a valid login token is sent."""

    @wraps(view)
    def wrapper(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            raise ApiError("Please log in to continue.", 401)
        try:
            payload = token_serializer.loads(header[7:], max_age=TOKEN_MAX_AGE_SECONDS)
        except SignatureExpired:
            raise ApiError("Your session has expired. Please log in again.", 401)
        except BadSignature:
            raise ApiError("Invalid session. Please log in again.", 401)

        user = db.session.get(User, payload.get("uid"))
        if user is None:
            raise ApiError("Account not found. Please log in again.", 401)
        g.user = user
        return view(*args, **kwargs)

    return wrapper


def user_payload(user):
    return {"id": user.id, "name": user.name, "email": user.email}


def transaction_payload(t):
    return {
        "id": t.id,
        "type": t.type,
        "amount": t.amount,
        "category": t.category,
        "description": t.description,
        "date": t.date,
    }


def goal_payload(goal):
    return {
        "id": goal.id,
        "name": goal.name,
        "target_amount": goal.target_amount,
        "current_savings": goal.current_savings,
        "target_date": goal.target_date,
        "created_at": goal.created_at,
    }


def bill_payload(bill):
    return {
        "id": bill.id,
        "name": bill.name,
        "category": bill.category,
        "amount": bill.amount,
        "due_date": bill.due_date,
        "notes": bill.notes or "",
        "status": bill.status,
        "paid_date": bill.paid_date,
    }


def find_owned(model, record_id, label):
    """Fetch a record ONLY if it belongs to the logged-in user."""
    record = model.query.filter_by(id=record_id, user_id=g.user.id).first()
    if record is None:
        raise ApiError(f"{label} not found.", 404)
    return record


# ---------------------------------------------------------------------------
# 3a. Accounts
# ---------------------------------------------------------------------------
@app.route("/")
def home():
    return "AI Expense Tracker Backend is Running!"


@app.route("/signup", methods=["POST"])
def signup():
    data = json_body()
    name = clean_text(data.get("name"), "Name", 100, required=True)
    email = clean_text(data.get("email"), "Email", 120, required=True).lower()
    password = str(data.get("password") or "")

    if not password:
        raise ApiError("All fields are required")
    if not EMAIL_PATTERN.match(email):
        raise ApiError("Please enter a valid email address.")
    if len(password) < 6:
        raise ApiError("Password must be at least 6 characters long.")
    if len(name) < 2:
        raise ApiError("Please enter your full name.")

    if User.query.filter(db.func.lower(User.email) == email).first():
        raise ApiError("Email already registered", 409)

    db.session.add(User(name=name, email=email, password=generate_password_hash(password)))
    db.session.commit()
    return jsonify({"message": "Account created successfully"}), 201


@app.route("/login", methods=["POST"])
def login():
    data = json_body()
    email = str(data.get("email") or "").strip().lower()
    password = str(data.get("password") or "")

    if not email or not password:
        raise ApiError("Email and password are required")

    user = User.query.filter(db.func.lower(User.email) == email).first()
    if user is None or not check_password_hash(user.password, password):
        raise ApiError("Invalid email or password", 401)

    token = token_serializer.dumps({"uid": user.id})
    return jsonify({"message": "Login successful", "user": user_payload(user), "token": token}), 200


@app.route("/me", methods=["GET"])
@login_required
def me():
    """Lets the website check that a saved login is still valid."""
    return jsonify({"user": user_payload(g.user)}), 200


# ---------------------------------------------------------------------------
# 3b. Transactions
# ---------------------------------------------------------------------------
def categories_for(tx_type):
    return EXPENSE_CATEGORIES if tx_type == "expense" else INCOME_CATEGORIES


def read_transaction_fields(data, tx_type):
    """Validate the fields shared by "add" and "edit"."""
    amount = parse_amount(data.get("amount"))
    category = clean_text(data.get("category"), "Category", 50, required=True)
    if category not in categories_for(tx_type):
        raise ApiError(f"'{category}' is not a valid {tx_type} category.")
    description = clean_text(data.get("description"), "Description", 200)
    tx_date = parse_date(data.get("date"))
    return amount, category, description, tx_date


def create_transaction(tx_type):
    data = json_body()
    amount, category, description, tx_date = read_transaction_fields(data, tx_type)
    db.session.add(Transaction(
        user_id=g.user.id, type=tx_type, amount=amount,
        category=category, description=description, date=tx_date,
    ))
    db.session.commit()
    label = "Expense" if tx_type == "expense" else "Income"
    return jsonify({"message": f"{label} added successfully"}), 201


@app.route("/expense", methods=["POST"])
@login_required
def add_expense():
    return create_transaction("expense")


@app.route("/income", methods=["POST"])
@login_required
def add_income():
    return create_transaction("income")


@app.route("/transactions", methods=["GET"])
@login_required
def get_transactions():
    rows = Transaction.query.filter_by(user_id=g.user.id).order_by(
        Transaction.date.desc(), Transaction.id.desc()
    ).all()
    return jsonify([transaction_payload(t) for t in rows]), 200


@app.route("/transactions/<int:transaction_id>", methods=["GET"])
@login_required
def get_transactions_legacy(transaction_id):
    """Old URL /transactions/<user_id> kept so nothing breaks.
    You can only ask for your own data."""
    if transaction_id != g.user.id:
        raise ApiError("You can only view your own transactions.", 403)
    return get_transactions()


@app.route("/transactions/<int:transaction_id>", methods=["PUT"])
@login_required
def update_transaction(transaction_id):
    tx = find_owned(Transaction, transaction_id, "Transaction")
    data = json_body()

    tx_type = str(data.get("type") or "").strip().lower()
    if tx_type not in ("income", "expense"):
        raise ApiError("Transaction type must be income or expense.")

    amount, category, description, tx_date = read_transaction_fields(data, tx_type)
    tx.type, tx.amount, tx.category = tx_type, amount, category
    tx.description, tx.date = description, tx_date
    db.session.commit()
    return jsonify({"message": "Transaction updated successfully", "transaction": transaction_payload(tx)}), 200


@app.route("/transactions/<int:transaction_id>", methods=["DELETE"])
@login_required
def delete_transaction(transaction_id):
    tx = find_owned(Transaction, transaction_id, "Transaction")
    db.session.delete(tx)
    db.session.commit()
    return jsonify({"message": "Transaction deleted successfully"}), 200


# ---------------------------------------------------------------------------
# 3c. Goals
# ---------------------------------------------------------------------------
def read_goal_fields(data, existing=None):
    name = clean_text(data.get("name"), "Goal name", 100, required=True)
    target = parse_amount(data.get("target_amount"), "Target amount")
    saved = parse_amount(data.get("current_savings", 0) or 0, "Current savings", allow_zero=True)
    target_date = parse_date(data.get("target_date"), "Target date")

    # A brand-new goal cannot start in the past. (One day of tolerance is
    # allowed because the server and the user may be in different time zones.)
    # When editing, an old date is allowed if it was not changed - for example
    # to update the saved amount of a goal whose deadline has already passed.
    unchanged = existing is not None and existing.target_date == target_date
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    if not unchanged and target_date < yesterday:
        raise ApiError("Target date cannot be in the past.")
    return name, target, saved, target_date


@app.route("/goals", methods=["GET"])
@login_required
def list_goals():
    goals = Goal.query.filter_by(user_id=g.user.id).order_by(Goal.target_date, Goal.id).all()
    return jsonify([goal_payload(x) for x in goals]), 200


@app.route("/goals", methods=["POST"])
@login_required
def create_goal():
    name, target, saved, target_date = read_goal_fields(json_body())
    goal = Goal(
        user_id=g.user.id, name=name, target_amount=target, current_savings=saved,
        target_date=target_date, created_at=date.today().isoformat(),
    )
    db.session.add(goal)
    db.session.commit()
    return jsonify({"message": "Goal created successfully", "goal": goal_payload(goal)}), 201


@app.route("/goals/<int:goal_id>", methods=["PUT"])
@login_required
def update_goal(goal_id):
    goal = find_owned(Goal, goal_id, "Goal")
    name, target, saved, target_date = read_goal_fields(json_body(), existing=goal)
    goal.name, goal.target_amount = name, target
    goal.current_savings, goal.target_date = saved, target_date
    db.session.commit()
    return jsonify({"message": "Goal updated successfully", "goal": goal_payload(goal)}), 200


@app.route("/goals/<int:goal_id>", methods=["DELETE"])
@login_required
def delete_goal(goal_id):
    goal = find_owned(Goal, goal_id, "Goal")
    db.session.delete(goal)
    db.session.commit()
    return jsonify({"message": "Goal deleted successfully"}), 200


# ---------------------------------------------------------------------------
# 3d. Bills
# ---------------------------------------------------------------------------
def read_bill_fields(data):
    name = clean_text(data.get("name"), "Bill name", 100, required=True)
    category = clean_text(data.get("category"), "Category", 50, required=True)
    if category not in BILL_CATEGORIES:
        raise ApiError(f"'{category}' is not a valid bill category.")
    amount = parse_amount(data.get("amount"))
    due_date = parse_date(data.get("due_date"), "Due date")
    notes = clean_text(data.get("notes"), "Notes", 200)
    status = str(data.get("status") or "unpaid").strip().lower()
    if status not in ("paid", "unpaid"):
        raise ApiError("Payment status must be paid or unpaid.")
    return name, category, amount, due_date, notes, status


@app.route("/bills", methods=["GET"])
@login_required
def list_bills():
    bills = Bill.query.filter_by(user_id=g.user.id).order_by(Bill.due_date, Bill.id).all()
    return jsonify([bill_payload(b) for b in bills]), 200


@app.route("/bills", methods=["POST"])
@login_required
def create_bill():
    name, category, amount, due_date, notes, status = read_bill_fields(json_body())
    bill = Bill(user_id=g.user.id, name=name, category=category, amount=amount,
                due_date=due_date, notes=notes, status=status)
    db.session.add(bill)
    db.session.commit()
    return jsonify({"message": "Bill added successfully", "bill": bill_payload(bill)}), 201


@app.route("/bills/<int:bill_id>", methods=["PUT"])
@login_required
def update_bill(bill_id):
    bill = find_owned(Bill, bill_id, "Bill")
    name, category, amount, due_date, notes, status = read_bill_fields(json_body())
    bill.name, bill.category, bill.amount = name, category, amount
    bill.due_date, bill.notes = due_date, notes
    if status != bill.status:
        bill.status = status
        bill.paid_date = date.today().isoformat() if status == "paid" else None
    db.session.commit()
    return jsonify({"message": "Bill updated successfully", "bill": bill_payload(bill)}), 200


@app.route("/bills/<int:bill_id>/pay", methods=["POST"])
@login_required
def pay_bill(bill_id):
    """Mark a bill as paid. This only happens when the user clicks the button.

    If record_expense is true, the payment is also saved as an expense
    (category "Bills") so your balance and charts stay correct.
    """
    bill = find_owned(Bill, bill_id, "Bill")
    if bill.status == "paid":
        raise ApiError("This bill is already marked as paid.", 409)

    today = date.today().isoformat()
    bill.status = "paid"
    bill.paid_date = today

    if json_body().get("record_expense"):
        db.session.add(Transaction(
            user_id=g.user.id, type="expense", amount=bill.amount, category="Bills",
            description=f"{bill.name} (bill payment)"[:200], date=today,
        ))
    db.session.commit()
    return jsonify({"message": "Bill marked as paid", "bill": bill_payload(bill)}), 200


@app.route("/bills/<int:bill_id>", methods=["DELETE"])
@login_required
def delete_bill(bill_id):
    bill = find_owned(Bill, bill_id, "Bill")
    db.session.delete(bill)
    db.session.commit()
    return jsonify({"message": "Bill deleted successfully"}), 200


# ---------------------------------------------------------------------------
# 3e. Saving-suggestion states (completed / dismissed)
# ---------------------------------------------------------------------------
@app.route("/suggestions/state", methods=["GET"])
@login_required
def get_suggestion_states():
    rows = SuggestionState.query.filter_by(user_id=g.user.id).all()
    return jsonify([{"key": r.suggestion_key, "status": r.status} for r in rows]), 200


@app.route("/suggestions/state", methods=["PUT"])
@login_required
def set_suggestion_state():
    data = json_body()
    key = str(data.get("key") or "").strip()
    status = str(data.get("status") or "").strip().lower()

    if not re.fullmatch(r"[A-Za-z0-9:_\-. ]{1,120}", key):
        raise ApiError("Invalid suggestion key.")
    if status not in ("completed", "dismissed", "active"):
        raise ApiError("Status must be completed, dismissed or active.")

    row = SuggestionState.query.filter_by(user_id=g.user.id, suggestion_key=key).first()
    if status == "active":  # "active" = restore the suggestion
        if row:
            db.session.delete(row)
    elif row:
        row.status = status
    else:
        db.session.add(SuggestionState(user_id=g.user.id, suggestion_key=key, status=status))
    db.session.commit()
    return jsonify({"message": "Saved"}), 200


# ---------------------------------------------------------------------------
# 3f. Monthly PDF report
# ---------------------------------------------------------------------------
@app.route("/report/monthly", methods=["GET"])
@login_required
def monthly_report():
    try:
        year = int(request.args.get("year", ""))
        month = int(request.args.get("month", ""))
    except ValueError:
        raise ApiError("Please choose a valid month and year.")
    if not (1 <= month <= 12) or not (2000 <= year <= 2100):
        raise ApiError("Please choose a valid month and year.")

    def month_rows(y, m):
        prefix = f"{y:04d}-{m:02d}-"
        return Transaction.query.filter(
            Transaction.user_id == g.user.id, Transaction.date.like(prefix + "%")
        ).order_by(Transaction.date, Transaction.id).all()

    prev_year, prev_month = (year - 1, 12) if month == 1 else (year, month - 1)

    pdf_buffer = build_monthly_report(
        user_name=g.user.name,
        year=year,
        month=month,
        transactions=month_rows(year, month),
        previous_transactions=month_rows(prev_year, prev_month),
    )
    filename = f"AI-Expense-Tracker-Report-{year:04d}-{month:02d}.pdf"
    return send_file(pdf_buffer, mimetype="application/pdf", as_attachment=True, download_name=filename)


# Create any missing tables (existing tables and data are never touched).
with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "1") == "1")
