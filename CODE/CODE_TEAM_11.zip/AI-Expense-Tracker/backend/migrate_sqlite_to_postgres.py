r"""
Copy your data from the local SQLite file to another database (for example PostgreSQL).
Your SQLite file is only READ - it is never changed.

Usage (from the backend folder):
    venv\Scripts\python.exe migrate_sqlite_to_postgres.py "postgresql://USER:PASSWORD@HOST:5432/DBNAME"

Optional second argument: path of the SQLite file (default instance/expense_tracker.db).
The target database must be EMPTY. Run it only once.
"""
import os
import sys

from sqlalchemy import create_engine, inspect, text

if len(sys.argv) < 2:
    sys.exit(__doc__)

target_url = sys.argv[1].replace("postgres://", "postgresql://", 1)
source_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join("instance", "expense_tracker.db")
if not os.path.exists(source_path):
    sys.exit(f"SQLite file not found: {source_path}")

os.environ["DATABASE_URL"] = target_url   # makes app.py create the tables in the TARGET database
os.environ.setdefault("SECRET_KEY", "migration-only")
from app import app  # noqa: E402
from models import db  # noqa: E402

source = create_engine("sqlite:///" + os.path.abspath(source_path).replace("\\", "/"))
ORDER = ["user", "transaction", "goal", "bill", "suggestion_state"]  # parents before children

with app.app_context():
    target = db.engine
    existing = set(inspect(source).get_table_names())
    with source.connect() as src, target.begin() as dst:
        for name in ORDER:
            if name not in existing:
                print(f"- {name}: not in the SQLite file, skipped")
                continue
            if dst.execute(text(f'SELECT COUNT(*) FROM "{name}"')).scalar():
                sys.exit(f"Target table '{name}' is not empty. Use an empty database.")
            rows = [dict(r._mapping) for r in src.execute(text(f'SELECT * FROM "{name}"'))]
            if rows:
                table = db.metadata.tables[name]
                dst.execute(table.insert(), rows)
            print(f"- {name}: copied {len(rows)} rows")
        if target.dialect.name == "postgresql":      # keep auto-numbering in step with copied ids
            for name in ORDER:
                dst.execute(text(
                    f"SELECT setval(pg_get_serial_sequence('\"{name}\"', 'id'), "
                    f"COALESCE((SELECT MAX(id) FROM \"{name}\"), 1), "
                    f"(SELECT COUNT(*) > 0 FROM \"{name}\"))"))
print("Done. Your SQLite file was not changed.")
