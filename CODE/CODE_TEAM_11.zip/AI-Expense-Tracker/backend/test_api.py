r"""
Automatic backend tests.  Run from the backend folder with:

    venv\Scripts\python.exe -m unittest test_api -v

The tests use a temporary database, so your real data is never touched.
"""
import os
import tempfile
import unittest

_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(_tmp, "test.db").replace("\\", "/")
os.environ["SECRET_KEY"] = "test-secret"

from app import app, db  # noqa: E402  (must come after the environment is set)
from models import Bill, Goal, Transaction  # noqa: E402


def signup_and_login(client, name, email, password="secret12"):
    client.post("/signup", json={"name": name, "email": email, "password": password})
    res = client.post("/login", json={"email": email, "password": password})
    data = res.get_json()
    return {"Authorization": f"Bearer {data['token']}"}, data["user"]["id"]


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = app.test_client()
        cls.alice, cls.alice_id = signup_and_login(cls.client, "Alice A", "alice@example.com")
        cls.bob, cls.bob_id = signup_and_login(cls.client, "Bob B", "bob@example.com")

    # ---------- accounts ----------
    def test_signup_validation(self):
        c = self.client
        self.assertEqual(c.post("/signup", json={}).status_code, 400)
        self.assertEqual(c.post("/signup", json={"name": "X Y", "email": "not-an-email", "password": "abcdef"}).status_code, 400)
        self.assertEqual(c.post("/signup", json={"name": "X Y", "email": "x@y.com", "password": "123"}).status_code, 400)
        self.assertEqual(c.post("/signup", json={"name": "Alice", "email": "ALICE@example.com", "password": "abcdef"}).status_code, 409)

    def test_login_wrong_password_and_case_insensitive_email(self):
        self.assertEqual(self.client.post("/login", json={"email": "alice@example.com", "password": "wrong"}).status_code, 401)
        self.assertEqual(self.client.post("/login", json={"email": "ALICE@Example.com", "password": "secret12"}).status_code, 200)
        self.assertEqual(self.client.post("/login", data="not json").status_code, 400)

    def test_requires_token(self):
        for path in ("/transactions", "/goals", "/bills", "/suggestions/state", "/report/monthly?year=2026&month=9", "/me"):
            self.assertEqual(self.client.get(path).status_code, 401, path)
        self.assertEqual(self.client.get("/transactions", headers={"Authorization": "Bearer garbage"}).status_code, 401)

    def test_cors_preflight_is_allowed(self):
        res = self.client.options("/transactions", headers={
            "Origin": "http://localhost:5173", "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "authorization"})
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.headers.get("Access-Control-Allow-Origin"), "http://localhost:5173")
        bad = self.client.options("/transactions", headers={"Origin": "http://evil.example", "Access-Control-Request-Method": "GET"})
        self.assertIsNone(bad.headers.get("Access-Control-Allow-Origin"))

    # ---------- transactions ----------
    def add(self, headers, kind, **overrides):
        body = {"amount": 100, "category": "Food" if kind == "expense" else "Salary", "description": "t", "date": "2026-09-10"}
        body.update(overrides)
        return self.client.post(f"/{kind}", json=body, headers=headers)

    def test_transaction_validation(self):
        h = self.alice
        self.assertEqual(self.add(h, "expense", amount=-5).status_code, 400)
        self.assertEqual(self.add(h, "expense", amount=0).status_code, 400)
        self.assertEqual(self.add(h, "expense", amount="abc").status_code, 400)
        self.assertEqual(self.add(h, "expense", amount="nan").status_code, 400)
        self.assertEqual(self.add(h, "expense", amount=None).status_code, 400)
        self.assertEqual(self.add(h, "expense", date="2026-02-30").status_code, 400)
        self.assertEqual(self.add(h, "expense", date="10/09/2026").status_code, 400)
        self.assertEqual(self.add(h, "expense", category="Salary").status_code, 400)
        self.assertEqual(self.add(h, "income", category="Food").status_code, 400)
        self.assertEqual(self.add(h, "expense", description="x" * 201).status_code, 400)
        self.assertEqual(self.add(h, "expense", amount=1e12).status_code, 400)

    def test_edit_delete_and_isolation(self):
        self.assertEqual(self.add(self.alice, "expense", amount=250, description="lunch").status_code, 201)
        rows = self.client.get("/transactions", headers=self.alice).get_json()
        tx = next(r for r in rows if r["description"] == "lunch")

        # Bob cannot see, edit or delete Alice's transaction
        bob_rows = self.client.get("/transactions", headers=self.bob).get_json()
        self.assertNotIn(tx["id"], [r["id"] for r in bob_rows])
        put = self.client.put(f"/transactions/{tx['id']}", headers=self.bob, json={**tx, "amount": 1, "type": "expense"})
        self.assertEqual(put.status_code, 404)
        self.assertEqual(self.client.delete(f"/transactions/{tx['id']}", headers=self.bob).status_code, 404)
        self.assertEqual(self.client.get(f"/transactions/{self.alice_id}", headers=self.bob).status_code, 403)

        # Alice can edit (including changing the type) and validation applies
        edited = self.client.put(f"/transactions/{tx['id']}", headers=self.alice,
                                 json={"type": "income", "amount": 300, "category": "Freelance", "description": "fixed", "date": "2026-09-11"})
        self.assertEqual(edited.status_code, 200)
        self.assertEqual(edited.get_json()["transaction"]["type"], "income")
        bad = self.client.put(f"/transactions/{tx['id']}", headers=self.alice,
                              json={"type": "income", "amount": -1, "category": "Freelance", "date": "2026-09-11"})
        self.assertEqual(bad.status_code, 400)
        bad_cat = self.client.put(f"/transactions/{tx['id']}", headers=self.alice,
                                  json={"type": "expense", "amount": 5, "category": "Freelance", "date": "2026-09-11"})
        self.assertEqual(bad_cat.status_code, 400)

        self.assertEqual(self.client.delete(f"/transactions/{tx['id']}", headers=self.alice).status_code, 200)
        self.assertEqual(self.client.delete(f"/transactions/{tx['id']}", headers=self.alice).status_code, 404)

    def test_newest_first_by_date(self):
        self.add(self.bob, "expense", date="2026-01-01", description="old")
        self.add(self.bob, "expense", date="2026-03-01", description="new")
        rows = self.client.get("/transactions", headers=self.bob).get_json()
        dates = [r["date"] for r in rows]
        self.assertEqual(dates, sorted(dates, reverse=True))

    # ---------- goals ----------
    def test_goals_crud_validation_isolation(self):
        good = {"name": "Laptop", "target_amount": 60000, "current_savings": 10000, "target_date": "2099-01-01"}
        res = self.client.post("/goals", json=good, headers=self.alice)
        self.assertEqual(res.status_code, 201)
        gid = res.get_json()["goal"]["id"]

        for change in ({"name": ""}, {"target_amount": 0}, {"target_amount": -1}, {"current_savings": -5},
                       {"target_date": "2020-01-01"}, {"target_date": "nope"}, {"target_amount": "abc"}):
            self.assertEqual(self.client.post("/goals", json={**good, **change}, headers=self.alice).status_code, 400, change)

        # savings above target is allowed (completed-goal state handled by the UI)
        self.assertEqual(self.client.put(f"/goals/{gid}", json={**good, "current_savings": 70000}, headers=self.alice).status_code, 200)

        # other users cannot see / edit / delete it
        self.assertEqual(self.client.get("/goals", headers=self.bob).get_json(), [])
        self.assertEqual(self.client.put(f"/goals/{gid}", json=good, headers=self.bob).status_code, 404)
        self.assertEqual(self.client.delete(f"/goals/{gid}", headers=self.bob).status_code, 404)
        self.assertEqual(self.client.delete(f"/goals/{gid}", headers=self.alice).status_code, 200)

    def test_past_goal_can_still_update_savings(self):
        with app.app_context():
            g = Goal(user_id=self.alice_id, name="Old", target_amount=1000, current_savings=100,
                     target_date="2020-01-01", created_at="2019-01-01")
            db.session.add(g); db.session.commit(); gid = g.id
        ok = self.client.put(f"/goals/{gid}", headers=self.alice,
                             json={"name": "Old", "target_amount": 1000, "current_savings": 500, "target_date": "2020-01-01"})
        self.assertEqual(ok.status_code, 200)
        moved = self.client.put(f"/goals/{gid}", headers=self.alice,
                                json={"name": "Old", "target_amount": 1000, "current_savings": 500, "target_date": "2021-01-01"})
        self.assertEqual(moved.status_code, 400)

    # ---------- bills ----------
    def test_bills_flow(self):
        bill = {"name": "Electricity", "category": "Electricity", "amount": 1300, "due_date": "2026-10-05", "notes": "n", "status": "unpaid"}
        res = self.client.post("/bills", json=bill, headers=self.alice)
        self.assertEqual(res.status_code, 201)
        bid = res.get_json()["bill"]["id"]
        for change in ({"amount": -1}, {"amount": 0}, {"due_date": "2026-13-01"}, {"category": "Nope"}, {"name": " "}, {"status": "maybe"}):
            self.assertEqual(self.client.post("/bills", json={**bill, **change}, headers=self.alice).status_code, 400, change)

        self.assertEqual(self.client.post(f"/bills/{bid}/pay", json={}, headers=self.bob).status_code, 404)
        before = len(self.client.get("/transactions", headers=self.alice).get_json())
        paid = self.client.post(f"/bills/{bid}/pay", json={"record_expense": True}, headers=self.alice)
        self.assertEqual(paid.status_code, 200)
        self.assertEqual(paid.get_json()["bill"]["status"], "paid")
        after = self.client.get("/transactions", headers=self.alice).get_json()
        self.assertEqual(len(after), before + 1)
        self.assertEqual(self.client.post(f"/bills/{bid}/pay", json={}, headers=self.alice).status_code, 409)

        edit = self.client.put(f"/bills/{bid}", json={**bill, "amount": 1500, "status": "paid"}, headers=self.alice)
        self.assertEqual(edit.get_json()["bill"]["amount"], 1500)
        self.assertEqual(self.client.get("/bills", headers=self.bob).get_json(), [])
        self.assertEqual(self.client.delete(f"/bills/{bid}", headers=self.bob).status_code, 404)
        self.assertEqual(self.client.delete(f"/bills/{bid}", headers=self.alice).status_code, 200)

    def test_pay_without_recording_expense(self):
        res = self.client.post("/bills", json={"name": "Rent", "category": "Rent", "amount": 9000, "due_date": "2026-10-01"}, headers=self.bob)
        bid = res.get_json()["bill"]["id"]
        before = len(self.client.get("/transactions", headers=self.bob).get_json())
        self.client.post(f"/bills/{bid}/pay", json={"record_expense": False}, headers=self.bob)
        self.assertEqual(len(self.client.get("/transactions", headers=self.bob).get_json()), before)

    # ---------- suggestion state ----------
    def test_suggestion_state(self):
        put = lambda key, status, h: self.client.put("/suggestions/state", json={"key": key, "status": status}, headers=h)
        self.assertEqual(put("reduce:Shopping", "dismissed", self.alice).status_code, 200)
        self.assertEqual(put("reduce:Shopping", "completed", self.alice).status_code, 200)
        states = self.client.get("/suggestions/state", headers=self.alice).get_json()
        self.assertEqual(states, [{"key": "reduce:Shopping", "status": "completed"}])
        self.assertEqual(self.client.get("/suggestions/state", headers=self.bob).get_json(), [])
        self.assertEqual(put("bad/key", "dismissed", self.alice).status_code, 400)
        self.assertEqual(put("reduce:Shopping", "nonsense", self.alice).status_code, 400)
        self.assertEqual(put("reduce:Shopping", "active", self.alice).status_code, 200)
        self.assertEqual(self.client.get("/suggestions/state", headers=self.alice).get_json(), [])

    # ---------- PDF ----------
    def test_pdf_report(self):
        carol, _ = signup_and_login(self.client, "Carol C", "carol@example.com")
        self.add(carol, "income", amount=50000, date="2026-08-05")
        self.add(carol, "expense", amount=1234.5, category="Food", date="2026-08-06", description="A & B <lunch>")
        self.add(carol, "expense", amount=999, category="Shopping", date="2026-09-06")
        res = self.client.get("/report/monthly?year=2026&month=8", headers=carol)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.mimetype, "application/pdf")
        self.assertTrue(res.data.startswith(b"%PDF"))
        self.assertIn("AI-Expense-Tracker-Report-2026-08.pdf", res.headers["Content-Disposition"])

        empty = self.client.get("/report/monthly?year=2025&month=1", headers=carol)   # month with no data
        self.assertEqual(empty.status_code, 200)
        self.assertTrue(empty.data.startswith(b"%PDF"))
        for query in ("year=2026&month=13", "year=abc&month=1", "month=1", "year=1900&month=1"):
            self.assertEqual(self.client.get(f"/report/monthly?{query}", headers=carol).status_code, 400, query)

    def test_pdf_contains_only_own_data(self):
        from unittest import mock
        import app as app_module
        dave, dave_id = signup_and_login(self.client, "Dave D", "dave@example.com")
        erin, erin_id = signup_and_login(self.client, "Erin E", "erin@example.com")
        self.add(dave, "expense", amount=777, description="DAVE-SECRET", date="2026-07-07")
        self.add(erin, "expense", amount=5, description="erin-item", date="2026-07-08")

        real = app_module.build_monthly_report
        captured = {}

        def spy(**kwargs):
            captured.update(kwargs)
            return real(**kwargs)

        with mock.patch.object(app_module, "build_monthly_report", side_effect=spy):
            res = self.client.get("/report/monthly?year=2026&month=7", headers=erin)
        self.assertEqual(res.status_code, 200)
        rows = captured["transactions"] + captured["previous_transactions"]
        self.assertTrue(rows)
        self.assertTrue(all(t.user_id == erin_id for t in rows))
        self.assertEqual(captured["user_name"], "Erin E")


if __name__ == "__main__":
    unittest.main()
