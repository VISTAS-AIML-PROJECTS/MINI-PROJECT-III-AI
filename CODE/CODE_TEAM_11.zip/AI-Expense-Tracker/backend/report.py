"""
Monthly PDF report builder (uses the ReportLab library).

build_monthly_report(...) receives ONLY the logged-in user's transactions for
one month (plus the previous month for a comparison) and returns a PDF in memory.
Nothing in the report is invented: every number is calculated from those rows.
"""

import calendar
import math
import os
from datetime import date
from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

# ---------------------------------------------------------------------------
# Fonts: the standard PDF fonts cannot draw the rupee sign, so we bundle
# DejaVu Sans (backend/fonts). If the font files are missing we fall back to "Rs.".
# ---------------------------------------------------------------------------
FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
FONT, FONT_BOLD, RUPEE = "Helvetica", "Helvetica-Bold", "Rs. "
try:
    pdfmetrics.registerFont(TTFont("DejaVu", os.path.join(FONT_DIR, "DejaVuSans.ttf")))
    pdfmetrics.registerFont(TTFont("DejaVu-Bold", os.path.join(FONT_DIR, "DejaVuSans-Bold.ttf")))
    FONT, FONT_BOLD, RUPEE = "DejaVu", "DejaVu-Bold", "\u20b9"
except Exception:  # pragma: no cover - only when fonts are missing
    pass

# Colours (same palette as the website)
BLUE = colors.HexColor("#2563eb")
VIOLET = colors.HexColor("#7c3aed")
GREEN = colors.HexColor("#16a34a")
RED = colors.HexColor("#dc2626")
INK = colors.HexColor("#172033")
MUTED = colors.HexColor("#6b7280")
LINE = colors.HexColor("#e5e7eb")
SOFT = colors.HexColor("#f5f7fb")
PIE_COLORS = ["#2563eb", "#7c3aed", "#0891b2", "#d97706", "#db2777", "#16a34a", "#dc2626", "#64748b"]


def money(value):
    """Indian digit grouping: 1234567.5 -> ₹12,34,567.50"""
    negative = value < 0
    whole, _, decimals = f"{abs(value):.2f}".partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return f"{'-' if negative else ''}{RUPEE}{whole}.{decimals}"


def styles():
    base = dict(fontName=FONT, textColor=INK, leading=14)
    return {
        "title": ParagraphStyle("title", fontName=FONT_BOLD, fontSize=24, leading=28, textColor=colors.white),
        "subtitle": ParagraphStyle("subtitle", fontName=FONT, fontSize=11, leading=14, textColor=colors.HexColor("#dbe4ff")),
        "h2": ParagraphStyle("h2", fontName=FONT_BOLD, fontSize=13, leading=16, textColor=INK, spaceBefore=14, spaceAfter=6),
        "body": ParagraphStyle("body", fontSize=10, **base),
        "small": ParagraphStyle("small", fontName=FONT, fontSize=8.5, leading=11, textColor=MUTED),
        "cell": ParagraphStyle("cell", fontSize=8.5, leading=11, **{k: v for k, v in base.items() if k != "leading"}),
        "kpi_label": ParagraphStyle("kpi_label", fontName=FONT, fontSize=8.5, leading=11, textColor=MUTED),
    }


def kpi_cell(label, value, color, st):
    return [
        Paragraph(label, st["kpi_label"]),
        Paragraph(f'<font color="{color.hexval().replace("0x", "#")}">{escape(value)}</font>',
                  ParagraphStyle("kpi_value", fontName=FONT_BOLD, fontSize=14, leading=18)),
    ]


def pie_drawing(rows):
    drawing = Drawing(150, 130)
    pie = Pie()
    pie.x, pie.y, pie.width, pie.height = 15, 8, 115, 115
    pie.data = [amount for _, amount in rows]
    pie.labels = None
    pie.slices.strokeWidth = 1
    pie.slices.strokeColor = colors.white
    for i in range(len(rows)):
        pie.slices[i].fillColor = colors.HexColor(PIE_COLORS[i % len(PIE_COLORS)])
    drawing.add(pie)
    return drawing


def income_expense_chart(income, expenses):
    drawing = Drawing(240, 130)
    chart = VerticalBarChart()
    chart.x, chart.y, chart.width, chart.height = 45, 22, 175, 95
    chart.data = [[income, expenses]]
    chart.categoryAxis.categoryNames = ["Income", "Expenses"]
    chart.categoryAxis.labels.fontName = FONT
    chart.categoryAxis.labels.fontSize = 8
    chart.valueAxis.valueMin = 0
    top = max(income, expenses, 1)
    # Pick a "nice" step (1, 2, 2.5, 5 x 10^n) so the axis numbers look tidy
    raw_step = top / 4
    magnitude = 10 ** math.floor(math.log10(raw_step))
    step = next(m * magnitude for m in (1, 2, 2.5, 5, 10) if m * magnitude >= raw_step)
    chart.valueAxis.valueMax = step * math.ceil(top * 1.02 / step)
    chart.valueAxis.valueStep = step
    chart.valueAxis.labels.fontName = FONT
    chart.valueAxis.labels.fontSize = 7
    chart.valueAxis.labelTextFormat = lambda v: f"{v:,.0f}"
    chart.valueAxis.strokeColor = LINE
    chart.valueAxis.gridStrokeColor = LINE
    chart.valueAxis.visibleGrid = True
    chart.bars.strokeColor = None
    chart.bars[(0, 0)].fillColor = BLUE
    chart.bars[(0, 1)].fillColor = RED
    chart.barWidth = 30
    chart.groupSpacing = 25
    drawing.add(chart)
    return drawing


def totals(transactions):
    income = sum(t.amount for t in transactions if t.type == "income")
    expenses = sum(t.amount for t in transactions if t.type == "expense")
    return income, expenses


def build_summary_sentences(income, expenses, by_category, prev_income, prev_expenses, prev_count, has_data):
    """Short plain-language summary. Every sentence is backed by the numbers above."""
    if not has_data:
        return ["No transactions were recorded for this month, so there is nothing to summarise."]

    sentences = []
    net = income - expenses
    if income > 0 and net > 0:
        sentences.append(f"Income was higher than expenses, leaving net savings of {money(net)} "
                         f"({net / income * 100:.1f}% of income).")
    elif income > 0 and net == 0:
        sentences.append("Income and expenses were equal this month, so no savings were made.")
    elif income > 0:
        sentences.append(f"Expenses were higher than income by {money(-net)} this month.")
    elif expenses > 0:
        sentences.append(f"No income was recorded this month, while expenses were {money(expenses)}.")
    else:
        sentences.append("Only income was recorded this month; no expenses were recorded.")

    if by_category:
        name, amount = by_category[0]
        sentences.append(f"The largest expense category was {name} at {money(amount)} "
                         f"({amount / expenses * 100:.1f}% of total expenses).")

    if prev_count > 0 and prev_expenses > 0 and expenses > 0:
        change = (expenses - prev_expenses) / prev_expenses * 100
        if abs(change) < 0.05:
            sentences.append("Expenses were the same as in the previous month.")
        else:
            word = "higher" if change > 0 else "lower"
            sentences.append(f"Expenses were {abs(change):.1f}% {word} than the previous month "
                             f"({money(prev_expenses)}).")
    return sentences


def page_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont(FONT, 8)
    canvas.setFillColor(MUTED)
    canvas.drawString(18 * mm, 10 * mm, "AI Expense Tracker \u2022 Personal report generated from your recorded transactions")
    canvas.drawRightString(A4[0] - 18 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


def build_monthly_report(user_name, year, month, transactions, previous_transactions):
    st = styles()
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=15 * mm, bottomMargin=18 * mm,
        title=f"AI Expense Tracker - {calendar.month_name[month]} {year}", author="AI Expense Tracker",
    )
    width = A4[0] - 36 * mm
    story = []

    month_label = f"{calendar.month_name[month]} {year}"
    generated = date.today().strftime("%d %B %Y")

    # --- Title band -------------------------------------------------------
    header = Table(
        [[Paragraph("AI Expense Tracker", st["title"])],
         [Paragraph("Monthly Financial Report", st["subtitle"])]],
        colWidths=[width],
    )
    header.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BLUE),
        ("LEFTPADDING", (0, 0), (-1, -1), 14), ("RIGHTPADDING", (0, 0), (-1, -1), 14),
        ("TOPPADDING", (0, 0), (0, 0), 14), ("BOTTOMPADDING", (0, 1), (0, 1), 14),
        ("BOTTOMPADDING", (0, 0), (0, 0), 0), ("TOPPADDING", (0, 1), (0, 1), 2),
    ]))
    story += [header, Spacer(1, 10)]

    meta = Table(
        [[Paragraph("<b>User</b>", st["cell"]), Paragraph(escape(user_name), st["cell"]),
          Paragraph("<b>Report period</b>", st["cell"]), Paragraph(month_label, st["cell"])],
         [Paragraph("<b>Generated on</b>", st["cell"]), Paragraph(generated, st["cell"]),
          Paragraph("<b>Transactions</b>", st["cell"]), Paragraph(str(len(transactions)), st["cell"])]],
        colWidths=[width * 0.16, width * 0.34, width * 0.2, width * 0.3],
    )
    meta.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.6, LINE), ("BACKGROUND", (0, 0), (-1, -1), SOFT),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story += [meta, Spacer(1, 10)]

    # --- Numbers ----------------------------------------------------------
    income, expenses = totals(transactions)
    net = income - expenses
    has_data = len(transactions) > 0
    savings_rate = f"{net / income * 100:.1f}%" if income > 0 else "N/A"

    kpis = Table(
        [[kpi_cell("Total Income", money(income), GREEN, st),
          kpi_cell("Total Expenses", money(expenses), RED, st),
          kpi_cell("Net Savings", money(net), GREEN if net >= 0 else RED, st),
          kpi_cell("Savings Rate", savings_rate, BLUE, st)]],
        colWidths=[width / 4] * 4,
    )
    kpis.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.6, LINE), ("INNERGRID", (0, 0), (-1, -1), 0.6, LINE),
        ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
    ]))
    story.append(kpis)
    if income == 0:
        story.append(Paragraph("Savings rate is not available because no income was recorded this month.", st["small"]))

    # --- Expense breakdown -------------------------------------------------
    by_category = {}
    for t in transactions:
        if t.type == "expense":
            by_category[t.category] = by_category.get(t.category, 0) + t.amount
    category_rows = sorted(by_category.items(), key=lambda item: item[1], reverse=True)

    story.append(Paragraph("Expense Breakdown by Category", st["h2"]))
    if category_rows:
        table_data = [[Paragraph("<b>Category</b>", st["cell"]), Paragraph("<b>Amount</b>", st["cell"]),
                       Paragraph("<b>Share</b>", st["cell"])]]
        for i, (name, amount) in enumerate(category_rows):
            swatch = PIE_COLORS[i % len(PIE_COLORS)]
            table_data.append([
                Paragraph(f'<font color="{swatch}">\u25cf</font> {escape(name)}', st["cell"]),
                Paragraph(money(amount), st["cell"]),
                Paragraph(f"{amount / expenses * 100:.1f}%", st["cell"]),
            ])
        cat_table = Table(table_data, colWidths=[width * 0.28, width * 0.2, width * 0.12], repeatRows=1)
        cat_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), SOFT), ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        combo = Table([[cat_table, pie_drawing(category_rows)]], colWidths=[width * 0.62, width * 0.38])
        combo.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
        story.append(combo)
    else:
        story.append(Paragraph("No expenses were recorded this month.", st["body"]))

    # --- Income vs expenses -------------------------------------------------
    story.append(Paragraph("Income vs Expenses", st["h2"]))
    if has_data:
        if income > 0:
            ratio_text = f"Expenses were {expenses / income * 100:.1f}% of income."
        else:
            ratio_text = "No income was recorded, so no comparison ratio is available."
        summary = Table(
            [[income_expense_chart(income, expenses),
              [Paragraph(f"<b>Income:</b> {money(income)}", st["body"]),
               Paragraph(f"<b>Expenses:</b> {money(expenses)}", st["body"]),
               Paragraph(f"<b>Net:</b> {money(net)}", st["body"]),
               Spacer(1, 4), Paragraph(ratio_text, st["small"])]]],
            colWidths=[width * 0.55, width * 0.45],
        )
        summary.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
        story.append(summary)
    else:
        story.append(Paragraph("No data available for this month.", st["body"]))

    # --- Short summary --------------------------------------------------------
    prev_income, prev_expenses = totals(previous_transactions)
    sentences = build_summary_sentences(income, expenses, category_rows, prev_income, prev_expenses,
                                        len(previous_transactions), has_data)
    story.append(Paragraph("Financial Summary", st["h2"]))
    for sentence in sentences:
        story.append(Paragraph(f"\u2022 {escape(sentence)}", st["body"]))
        story.append(Spacer(1, 2))

    # --- Transaction list ------------------------------------------------------
    story.append(Paragraph("Transactions", st["h2"]))
    if has_data:
        rows = [[Paragraph(f"<b>{h}</b>", st["cell"]) for h in ("Date", "Type", "Category", "Description", "Amount")]]
        for t in transactions:
            sign = "+" if t.type == "income" else "-"
            color = "#16a34a" if t.type == "income" else "#dc2626"
            rows.append([
                Paragraph(escape(t.date), st["cell"]),
                Paragraph(t.type.capitalize(), st["cell"]),
                Paragraph(escape(t.category), st["cell"]),
                Paragraph(escape(t.description or "-"), st["cell"]),
                Paragraph(f'<font color="{color}">{sign}{money(t.amount)}</font>',
                          ParagraphStyle("amt", parent=st["cell"], alignment=2)),
            ])
        tx_table = Table(rows, colWidths=[width * 0.14, width * 0.12, width * 0.17, width * 0.33, width * 0.24], repeatRows=1)
        style = [
            ("BACKGROUND", (0, 0), (-1, 0), SOFT), ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]
        tx_table.setStyle(TableStyle(style))
        story.append(tx_table)
    else:
        story.append(Paragraph("No transactions recorded for this month.", st["body"]))

    story += [Spacer(1, 12), Paragraph(
        "This report is generated only from the transactions you recorded in AI Expense Tracker. "
        "It is for personal reference and is not professional financial advice.", st["small"])]

    doc.build(story, onFirstPage=page_footer, onLaterPages=page_footer)
    buffer.seek(0)
    return buffer
