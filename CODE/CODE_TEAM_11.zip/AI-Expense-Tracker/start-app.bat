@echo off
setlocal EnableExtensions
title AI Expense Tracker - Launcher

rem ============================================================
rem  AI Expense Tracker - one-click launcher (Windows)
rem  Double-click this file from the AI-Expense-Tracker folder.
rem  It starts the Flask backend and the React frontend, then
rem  opens the app in your browser when it is ready.
rem  Your database is never deleted or recreated.
rem ============================================================

cd /d "%~dp0"
set "ROOT=%CD%"
set "BACKEND=%ROOT%\backend"
set "FRONTEND=%ROOT%\frontend"
set "PY=%BACKEND%\venv\Scripts\python.exe"
set "FRONT_URL=http://127.0.0.1:5173"
set "BACK_URL=http://127.0.0.1:5000"

echo.
echo  ==============================
echo    AI Expense Tracker launcher
echo  ==============================
echo.

rem ---------- 1. Check that everything we need exists ----------
if not exist "%BACKEND%\app.py" goto :err_backend
if not exist "%FRONTEND%\package.json" goto :err_frontend
if not exist "%PY%" goto :err_venv
where npm >nul 2>nul
if errorlevel 1 goto :err_node

rem ---------- 2. Make sure the ports are free ----------
netstat -ano | findstr /R /C:":5000 .*LISTENING" >nul
if not errorlevel 1 goto :err_port5000
netstat -ano | findstr /R /C:":5173 .*LISTENING" >nul
if not errorlevel 1 goto :err_port5173

rem ---------- 3. Install anything that is missing (first run only) ----------
"%PY%" -c "import flask, flask_cors, flask_sqlalchemy, reportlab" >nul 2>nul
if errorlevel 1 (
    echo  Installing missing backend packages - this needs internet and runs once...
    "%PY%" -m pip install -r "%BACKEND%\requirements.txt"
    if errorlevel 1 goto :err_pip
)

if not exist "%FRONTEND%\node_modules" (
    echo  Installing frontend packages - this needs internet and runs once...
    pushd "%FRONTEND%"
    call npm install
    if errorlevel 1 (
        popd
        goto :err_npm
    )
    popd
)

rem ---------- 4. Start the backend and the frontend in their own windows ----------
echo  Starting the backend  at %BACK_URL% ...
start "AI Expense Tracker - Backend" /D "%BACKEND%" cmd /k ""%PY%" app.py"

echo  Starting the frontend at %FRONT_URL% ...
start "AI Expense Tracker - Frontend" /D "%FRONTEND%" cmd /k "npm run dev -- --host 127.0.0.1 --port 5173 --strictPort"

rem ---------- 5. Wait until both servers answer, then open the browser ----------
echo  Waiting for the servers to be ready...
powershell -NoProfile -Command "$ok=$false; for($i=0;$i -lt 90;$i++){ try{ Invoke-WebRequest -Uri '%BACK_URL%' -UseBasicParsing -TimeoutSec 2 | Out-Null; Invoke-WebRequest -Uri '%FRONT_URL%' -UseBasicParsing -TimeoutSec 2 | Out-Null; $ok=$true; break } catch { Start-Sleep -Seconds 1 } }; if($ok){ exit 0 } else { exit 1 }"
if errorlevel 1 goto :err_slow

echo.
echo  Ready! Opening %FRONT_URL% in your browser.
start "" "%FRONT_URL%"
echo.
echo  Keep the two black windows open while you use the app.
echo  To stop everything, run stop-app.bat or close those two windows.
echo.
timeout /t 6 >nul
exit /b 0

rem ======================= error messages =======================
:err_backend
echo  [ERROR] Could not find backend\app.py
echo          Place start-app.bat inside the AI-Expense-Tracker folder, next to the backend and frontend folders.
goto :fail

:err_frontend
echo  [ERROR] Could not find frontend\package.json
echo          Place start-app.bat inside the AI-Expense-Tracker folder, next to the backend and frontend folders.
goto :fail

:err_venv
echo  [ERROR] The Python virtual environment was not found at:
echo          %PY%
echo          Create it once with these commands, then run this file again:
echo            cd backend
echo            python -m venv venv
echo            venv\Scripts\python.exe -m pip install -r requirements.txt
goto :fail

:err_node
echo  [ERROR] Node.js / npm was not found.
echo          Install Node.js from https://nodejs.org then run this file again.
goto :fail

:err_port5000
echo  [ERROR] Port 5000 is already in use. The backend may already be running.
echo          Run stop-app.bat, or close the other program that uses port 5000, then try again.
goto :fail

:err_port5173
echo  [ERROR] Port 5173 is already in use. The frontend may already be running.
echo          Run stop-app.bat, or close the other program that uses port 5173, then try again.
goto :fail

:err_pip
echo  [ERROR] Installing the backend packages failed. Check your internet connection.
echo          You can also run:  backend\venv\Scripts\python.exe -m pip install -r backend\requirements.txt
goto :fail

:err_npm
echo  [ERROR] npm install failed. Check your internet connection and try again.
goto :fail

:err_slow
echo  [WARNING] The servers did not answer within 90 seconds.
echo            Look at the Backend and Frontend windows for the error message.
echo            If both look fine, open %FRONT_URL% manually.
goto :fail

:fail
echo.
pause
exit /b 1
