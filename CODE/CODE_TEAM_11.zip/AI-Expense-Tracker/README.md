# AI Expense Tracker

A personal finance web app: track income and expenses, see charts and AI-style insights, set savings goals,
track bills, get a financial health score and download a monthly PDF report.

**Stack:** React + Vite + Recharts (frontend) · Flask + SQLAlchemy (backend) · SQLite (database) · ReportLab (PDF)

---

## 1. How to run

### Easiest way (Windows)
Double-click **`start-app.bat`** in this folder. It starts the backend and frontend, waits until they are ready and
opens http://127.0.0.1:5173 in your browser. Keep the two black windows open. Run **`stop-app.bat`** to stop.

The first time it may install missing packages (needs internet): `reportlab` for the PDF report.

### Manual way (two terminals)
```bat
:: Terminal 1 - backend
cd backend
venv\Scripts\python.exe -m pip install -r requirements.txt
venv\Scripts\python.exe app.py

:: Terminal 2 - frontend
cd frontend
npm install
npm run dev
```
Open the address that Vite prints (normally http://localhost:5173).

### Run the automatic tests
```bat
cd backend  && venv\Scripts\python.exe -m unittest test_api -v
cd frontend && npm test
```

---

## 2. What is in the app

| Tab | Features |
|---|---|
| **Overview** | Total Income / Expenses / Savings · **About My Balance** · Add Expense / Add Income (with the review page) · Recent Transactions with **Edit / Delete** · Expense by Category · Income vs Expenses · AI Spending Analysis · Monthly Trend · Expense Prediction · Budget Recommendation |
| **Goals** | **Goal Planner** (create, edit, delete, add savings, progress bar, completed / overdue states) · **AI Goal Analysis** per goal |
| **Bills** | **Bill Reminder**: add, edit, delete, mark as paid, overdue / due-soon, unpaid total |
| **Insights** | **Saving Suggestions** (mark done / dismiss) · **Financial Health Score** |
| **Invest** | **Investment Recommendation** (educational guide + compare) |
| **Reports** | **Monthly PDF report** for any month and year |

### Important honesty notes
* **"AI" features are rule-based**, not a live AI model. They use fixed, visible formulas on *your* recorded
  transactions (Spending Analysis, Goal Analysis, Saving Suggestions, Health Score, Prediction). Each screen says
  "rule-based" or "estimate". No paid API is used.
* Estimates are never guarantees. With too little data the app says so instead of guessing.
* Investment Recommendation is **educational only**. It shows no interest rates or returns (they change) and never
  invests money.
* Bill Reminder is **in-app only**. There are no email or push notifications.

### How the scoring works (Financial Health Score)
Documented in `frontend/src/utils/finance.js`. Factors: savings rate (30 pts), spending vs income (25),
savings consistency (20), budget adherence (15, *not available - the app has no budgets*), bill payments (10).
Factors without data are left out, never counted as zero. No score is shown with fewer than 5 transactions or no income.

---

## 3. Project structure

```
AI-Expense-Tracker/
├── start-app.bat            NEW  one-click launcher
├── stop-app.bat             NEW  stops the launcher windows
├── README.md / DEPLOYMENT.md
├── backend/
│   ├── app.py               CHANGED  all API routes (token login, validation, new endpoints)
│   ├── models.py            CHANGED  + Goal, Bill, SuggestionState tables
│   ├── report.py            NEW  builds the monthly PDF
│   ├── fonts/               NEW  DejaVu fonts (so the ₹ sign prints in the PDF)
│   ├── test_api.py          NEW  14 automatic backend tests
│   ├── requirements.txt     NEW
│   ├── Procfile             NEW  (for hosting)
│   ├── migrate_sqlite_to_postgres.py   NEW  (for hosting)
│   └── instance/expense_tracker.db     YOUR DATA - untouched
└── frontend/
    ├── .env.example         NEW
    └── src/
        ├── App.jsx          CHANGED  login, tabs, add-transaction flow
        ├── App.css          CHANGED  your styles kept + new styles appended
        ├── index.css        CHANGED  removed Vite-template leftovers
        ├── main.jsx         CHANGED  adds the toast provider
        ├── api.js           NEW  talks to Flask, sends the login token
        ├── utils/finance.js NEW  every calculation in one place
        ├── utils/finance.test.js  NEW  20 automatic tests
        └── components/      NEW  Analytics, BalanceCard, GoalPlanner, GoalAnalysis, InvestmentGuide,
                                  SavingSuggestions, BillReminder, HealthScore, ReportDownload,
                                  TransactionList, TransactionForm, ui, toastContext
```

## 4. Database changes
* Your `user` and `transaction` tables are **unchanged** (same columns, same rows).
* Three new tables are created automatically the first time the server starts: `goal`, `bill`, `suggestion_state`.
* Existing passwords keep working (same hashing).

## 5. Bugs found in the original code and fixed
1. **Anyone could read or change anyone's data.** The API trusted a `user_id` in the URL/body. Now login returns a
   signed token and the server takes the user from the token. (Old URL `/transactions/<id>` still works, but only for your own id.)
2. **Income skipped the verification page and all validation.** Now Add Income uses the same review flow as expenses.
3. **No server-side validation** (negative amounts, bad dates, huge numbers, fake categories). Added.
4. **Dark-mode computers showed unreadable grey text** and the page was forced to 1126px wide (leftover Vite template CSS). Fixed.
5. **Logging out kept the previous user's data in memory.** Now cleared. Login also survives a page refresh.
6. **Today's date used UTC**, which is the wrong day in India between 00:00 and 05:30. Now uses local time.
7. **Expense Prediction note** said "average" while it used a trend. Text now matches the method.
8. Chart axes showed long raw numbers; now compact (₹1.2L). Browser `alert()` pop-ups replaced with toasts.
9. Email sign-up was case-sensitive (`A@x.com` ≠ `a@x.com`). Now case-insensitive.

## 6. Known limitations
* Prediction and goal estimates use few months of data, so they are rough. The current, unfinished month counts as a month.
* No budgets feature exists, so "budget adherence" is not part of the Health Score.
* Notifications work only while the app is open.
* Tokens last 7 days and are kept in the browser's localStorage (fine for a college project).
* `start-app.bat` could not be run in the environment where this was built (it is Linux). It follows standard
  Windows batch rules, but please report any message it shows.
