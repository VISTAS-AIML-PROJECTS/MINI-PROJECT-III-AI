# Deployment guide (online hosting)

> **Status: NOT deployed.** I could not deploy for you (no hosting account or internet access). This is a
> step-by-step guide. Nothing here has been run on a real host, so test each step.

## Can I keep SQLite?
**Not on most free hosts.** Many hosts (Render free, Railway, Heroku, Fly without a volume) give the server a
temporary disk: the SQLite file is **erased on every restart or redeploy**, and you cannot run more than one
server copy. Use **PostgreSQL** for anything online. SQLite is perfectly fine on your own computer.

Your code already supports this: set the `DATABASE_URL` environment variable and the backend uses that database.
`migrate_sqlite_to_postgres.py` copies your existing users and transactions (tested only SQLite → SQLite here;
the PostgreSQL branch follows the standard approach but was not run against a real PostgreSQL server).

## Suggested free setup
| Part | Service | Notes |
|---|---|---|
| Frontend | **Vercel**, **Netlify** or Cloudflare Pages | build `npm run build`, publish folder `dist` |
| Backend | **Render** (Web Service) or Railway | start command: `gunicorn app:app` |
| Database | **Neon**, Supabase or Render PostgreSQL | gives you a `postgresql://...` address |

Free tiers change often, so check each provider's current limits. Free backends usually "sleep" and the first request is slow.

## Steps
1. **Put the project on GitHub.** Do NOT upload `venv`, `node_modules`, `instance/` (contains your database and
   `secret_key.txt`). Add them to `.gitignore`.
2. **Create the PostgreSQL database** and copy its connection address.
3. **(Optional) Move your data:**
   `cd backend` then `venv\Scripts\python.exe -m pip install psycopg2-binary` then
   `venv\Scripts\python.exe migrate_sqlite_to_postgres.py "postgresql://USER:PASSWORD@HOST/DB"`
4. **Deploy the backend** (root directory `backend`). Build command `pip install -r requirements.txt`, start
   command `gunicorn app:app`. Set environment variables:

   | Variable | Value |
   |---|---|
   | `DATABASE_URL` | your PostgreSQL address |
   | `SECRET_KEY` | a long random string, e.g. run `python -c "import secrets;print(secrets.token_hex(32))"` |
   | `CORS_ORIGINS` | your frontend address, e.g. `https://my-expenses.vercel.app` (no trailing slash; comma-separate several) |
   | `FLASK_DEBUG` | `0` |

   Never put these values in your code or in GitHub. Changing `SECRET_KEY` logs everyone out.
5. **Deploy the frontend** (root directory `frontend`). Build command `npm run build`, output `dist`.
   Set `VITE_API_URL` to your backend address (e.g. `https://my-expenses-api.onrender.com`). Vite reads this when
   it builds, so rebuild after changing it.
6. **Test online:** sign up, add a transaction, download a report.

## Production checklist
* HTTPS is provided by the hosts above. Keep it on.
* `CORS_ORIGINS` must contain exactly your frontend address, otherwise the browser blocks requests.
* Back up the database: Neon and Render offer backups/snapshots (check the plan), or run `pg_dump "$DATABASE_URL" > backup.sql` regularly.
  For local SQLite, simply copy `backend/instance/expense_tracker.db`.
* Passwords are stored hashed. Real money apps would also need login rate limiting and email verification; that is out of scope here.
