import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay
)

import joblib
import os
import matplotlib.pyplot as plt


# ==========================================
# 1. LOAD DATASET
# ==========================================

data = pd.read_csv(
    "dataset/prenatal_genetic_dataset_1250_rows_14_features.csv",
    keep_default_na=False
)

print("Dataset loaded successfully!")
print(data.head())

print("\nDataset Information")
print("-------------------")
print("Total records:", len(data))
print("Total columns:", len(data.columns))


# ==========================================
# 2. SEPARATE INPUT AND OUTPUT
# ==========================================

X = data.drop("Risk_Level", axis=1)
y = data["Risk_Level"]


# ==========================================
# 3. CONVERT TEXT COLUMNS INTO NUMBERS
# ==========================================

label_encoders = {}

for column in X.select_dtypes(include="object").columns:

    encoder = LabelEncoder()

    X[column] = encoder.fit_transform(X[column])

    label_encoders[column] = encoder


# Convert target labels
target_encoder = LabelEncoder()

y = target_encoder.fit_transform(y)


# ==========================================
# 4. SPLIT DATASET
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("\nDataset Split")
print("-------------")
print("Training records:", len(X_train))
print("Testing records :", len(X_test))


# ==========================================
# 5. CREATE RANDOM FOREST MODEL
# ==========================================

model = RandomForestClassifier(
    n_estimators=200,
    random_state=42
)


# ==========================================
# 6. TRAIN MODEL
# ==========================================

model.fit(X_train, y_train)

print("\nModel training completed!")


# ==========================================
# 7. MAKE PREDICTIONS
# ==========================================

predictions = model.predict(X_test)


# ==========================================
# 8. MODEL EVALUATION
# ==========================================

print("\n")
print("======================================")
print("          MODEL EVALUATION")
print("======================================")


# Accuracy
accuracy = accuracy_score(
    y_test,
    predictions
)

print("\nAccuracy:", round(accuracy * 100, 2), "%")


# Precision, Recall and F1-score
print("\nClassification Report")
print("---------------------")

print(
    classification_report(
        y_test,
        predictions,
        target_names=target_encoder.classes_
    )
)


# ==========================================
# 9. CONFUSION MATRIX
# ==========================================

cm = confusion_matrix(
    y_test,
    predictions
)

print("\nConfusion Matrix")
print("----------------")

print(cm)


# ==========================================
# 10. DISPLAY CONFUSION MATRIX
# ==========================================

display = ConfusionMatrixDisplay(
    confusion_matrix=cm,
    display_labels=target_encoder.classes_
)

display.plot()

plt.title("GeneGuide AI - Confusion Matrix")

plt.tight_layout()


# ==========================================
# 11. SAVE CONFUSION MATRIX
# ==========================================

os.makedirs(
    "evaluation",
    exist_ok=True
)

confusion_matrix_path = (
    "evaluation/confusion_matrix.png"
)

plt.savefig(
    confusion_matrix_path,
    dpi=300
)

print("\nConfusion matrix saved successfully!")
print("File:", confusion_matrix_path)


# Show graph
plt.show()


# ==========================================
# 12. SAVE MODEL
# ==========================================

os.makedirs(
    "model",
    exist_ok=True
)

joblib.dump(
    model,
    "model/random_forest_model.pkl"
)

joblib.dump(
    label_encoders,
    "model/label_encoders.pkl"
)

joblib.dump(
    target_encoder,
    "model/target_encoder.pkl"
)


# ==========================================
# 13. FINAL MESSAGE
# ==========================================

print("\n======================================")
print("       MODEL SAVED SUCCESSFULLY")
print("======================================")

print("Random Forest model  : model/random_forest_model.pkl")
print("Label encoders       : model/label_encoders.pkl")
print("Target encoder       : model/target_encoder.pkl")
print("Confusion matrix     : evaluation/confusion_matrix.png")