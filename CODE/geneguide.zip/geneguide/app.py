from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
import joblib
import sqlite3
from datetime import datetime
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# Secret key for login session
app.secret_key = "geneguide_secret_key"


# =========================================================
# LOAD AI MODEL
# =========================================================

model = joblib.load("model/random_forest_model.pkl")

label_encoders = joblib.load("model/label_encoders.pkl")

target_encoder = joblib.load("model/target_encoder.pkl")


# =========================================================
# CREATE DATABASE
# =========================================================

def create_database():

    connection = sqlite3.connect("geneguide.db")

    cursor = connection.cursor()

    # Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)

    # Assessment history table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS assessments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,

            date_time TEXT,

            mother_age INTEGER,
            father_age INTEGER,
            pregnancy_week INTEGER,

            family_history TEXT,
            affected_family_members INTEGER,
            family_history_type TEXT,

            carrier_status TEXT,
            genetic_test_result TEXT,

            previous_child_disorder TEXT,
            previous_abnormal_pregnancy TEXT,

            consanguineous_marriage TEXT,
            previous_miscarriages INTEGER,

            multiple_pregnancy TEXT,
            previous_prenatal_screening TEXT,

            risk_level TEXT,

            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    connection.commit()

    connection.close()


# Run database creation automatically
create_database()


# =========================================================
# LOGIN REQUIRED FUNCTION
# =========================================================

def login_required(function):

    @wraps(function)
    def decorated_function(*args, **kwargs):

        if "user_id" not in session:
            return redirect(url_for("login"))

        return function(*args, **kwargs)

    return decorated_function


# =========================================================
# HOME PAGE
# =========================================================

@app.route("/")
def home():

    return render_template("index.html")


# =========================================================
# REGISTER
# =========================================================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form["username"].strip()

        password = request.form["password"]

        # Check empty fields
        if not username or not password:

            return "Username and password are required."

        # Hash password
        hashed_password = generate_password_hash(password)

        connection = sqlite3.connect("geneguide.db")

        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO users (username, password)
                VALUES (?, ?)
                """,
                (username, hashed_password)
            )

            connection.commit()

        except sqlite3.IntegrityError:

            connection.close()

            return "Username already exists. Please choose another."

        connection.close()

        return redirect(url_for("login"))

    return render_template("register.html")


# =========================================================
# LOGIN
# =========================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form["username"].strip()

        password = request.form["password"]

        connection = sqlite3.connect("geneguide.db")

        connection.row_factory = sqlite3.Row

        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT *
            FROM users
            WHERE username = ?
            """,
            (username,)
        )

        user = cursor.fetchone()

        connection.close()

        # Check username and password
        if user and check_password_hash(user["password"], password):

            session["user_id"] = user["id"]

            session["username"] = user["username"]

            return redirect(url_for("assessment"))

        return "Invalid username or password."

    return render_template("login.html")


# =========================================================
# LOGOUT
# =========================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("home"))


# =========================================================
# ASSESSMENT PAGE
# =========================================================

@app.route("/assessment")
@login_required
def assessment():

    return render_template("assessment.html")


# =========================================================
# PREDICTION
# =========================================================

@app.route("/predict", methods=["POST"])
@login_required
def predict():

    try:

        # -------------------------------------------------
        # GET NUMERIC VALUES
        # -------------------------------------------------

        mother_age = int(
            request.form["Mother_Age"]
        )

        father_age = int(
            request.form["Father_Age"]
        )

        pregnancy_week = int(
            request.form["Pregnancy_Week"]
        )

        affected_members = int(
            request.form[
                "Number_of_Affected_Family_Members"
            ]
        )

        miscarriages = int(
            request.form["Previous_Miscarriages"]
        )


        # -------------------------------------------------
        # INPUT VALIDATION
        # -------------------------------------------------

        if not 18 <= mother_age <= 45:

            return "Invalid Mother Age. Please enter a value between 18 and 45."


        if not 20 <= father_age <= 55:

            return "Invalid Father Age. Please enter a value between 20 and 55."


        if not 8 <= pregnancy_week <= 40:

            return "Invalid Pregnancy Week. Please enter a value between 8 and 40."


        if not 0 <= affected_members <= 3:

            return "Invalid number of affected family members. Please enter a value between 0 and 3."


        if not 0 <= miscarriages <= 3:

            return "Invalid number of previous miscarriages. Please enter a value between 0 and 3."


        # -------------------------------------------------
        # GET CATEGORICAL VALUES
        # -------------------------------------------------

        input_data = {

            "Mother_Age":
                mother_age,

            "Father_Age":
                father_age,

            "Pregnancy_Week":
                pregnancy_week,

            "Family_History":
                request.form["Family_History"],

            "Number_of_Affected_Family_Members":
                affected_members,

            "Type_of_Family_History":
                request.form.get("Type_of_Family_History", "None"),

            "Carrier_Status":
                request.form["Carrier_Status"],

            "Parental_Genetic_Test_Result":
                request.form["Parental_Genetic_Test_Result"],

            "Previous_Child_Genetic_Disorder":
                request.form["Previous_Child_Genetic_Disorder"],

            "Previous_Abnormal_Pregnancy":
                request.form["Previous_Abnormal_Pregnancy"],

            "Consanguineous_Marriage":
                request.form["Consanguineous_Marriage"],

            "Previous_Miscarriages":
                miscarriages,

            "Multiple_Pregnancy":
                request.form["Multiple_Pregnancy"],

            "Previous_Prenatal_Screening":
                request.form["Previous_Prenatal_Screening"]
        }


        # -------------------------------------------------
        # CONVERT TO DATAFRAME
        # -------------------------------------------------

        df = pd.DataFrame([input_data])


        # -------------------------------------------------
        # ENCODE CATEGORICAL VALUES
        # -------------------------------------------------

        for column, encoder in label_encoders.items():

            df[column] = encoder.transform(
                df[column]
            )


        # -------------------------------------------------
        # AI PREDICTION
        # -------------------------------------------------

        prediction = model.predict(df)


        # Convert prediction back to text

        risk_level = target_encoder.inverse_transform(
            prediction
        )[0]


        # -------------------------------------------------
        # SAVE ASSESSMENT HISTORY
        # -------------------------------------------------

        connection = sqlite3.connect("geneguide.db")

        cursor = connection.cursor()

        cursor.execute(
            """
            INSERT INTO assessments (

                user_id,
                date_time,

                mother_age,
                father_age,
                pregnancy_week,

                family_history,
                affected_family_members,
                family_history_type,

                carrier_status,
                genetic_test_result,

                previous_child_disorder,
                previous_abnormal_pregnancy,

                consanguineous_marriage,
                previous_miscarriages,

                multiple_pregnancy,
                previous_prenatal_screening,

                risk_level

            )

            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

            """,

            (

                session["user_id"],

                datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),

                mother_age,
                father_age,
                pregnancy_week,

                input_data["Family_History"],

                affected_members,

                input_data[
                    "Type_of_Family_History"
                ],

                input_data[
                    "Carrier_Status"
                ],

                input_data[
                    "Parental_Genetic_Test_Result"
                ],

                input_data[
                    "Previous_Child_Genetic_Disorder"
                ],

                input_data[
                    "Previous_Abnormal_Pregnancy"
                ],

                input_data[
                    "Consanguineous_Marriage"
                ],

                miscarriages,

                input_data[
                    "Multiple_Pregnancy"
                ],

                input_data[
                    "Previous_Prenatal_Screening"
                ],

                risk_level
            )
        )

        connection.commit()

        connection.close()


        # -------------------------------------------------
        # SHOW RESULT
        # -------------------------------------------------

        return render_template(
            "result.html",
            risk_level=risk_level
        )


    except ValueError:

        return "Invalid input. Please enter valid numbers."


    except KeyError as e:

        return f"Missing required field: {e}"


    except Exception as e:

        return f"Error processing assessment: {e}"


# =========================================================
# HISTORY
# =========================================================

@app.route("/history")
@login_required
def history():

    connection = sqlite3.connect("geneguide.db")

    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()

    cursor.execute(
        """
        SELECT *
        FROM assessments

        WHERE user_id = ?

        ORDER BY id DESC
        """,
        (session["user_id"],)
    )

    assessments = cursor.fetchall()

    connection.close()

    return render_template(
        "history.html",
        assessments=assessments
    )


# =========================================================
# RUN FLASK APPLICATION
# =========================================================

if __name__ == "__main__":

    app.run(debug=True)