document.addEventListener("DOMContentLoaded", function () {

    const familyHistoryRadios = document.querySelectorAll(
        'input[name="Family_History"]'
    );

    const typeDropdown = document.getElementById(
        "Type_of_Family_History"
    );

    const form = document.querySelector(".assessment-form");

    if (!typeDropdown || familyHistoryRadios.length === 0) {
        return;
    }

    function syncTypeDropdown() {

        const selected = document.querySelector(
            'input[name="Family_History"]:checked'
        );

        if (!selected) {
            return;
        }

        if (selected.value === "No") {
            typeDropdown.value = "None";
            typeDropdown.disabled = true;
        } else {
            typeDropdown.disabled = false;
            if (typeDropdown.value === "None") {
                typeDropdown.value = "";
            }
        }
    }

    familyHistoryRadios.forEach(function (radio) {
        radio.addEventListener("change", syncTypeDropdown);
    });

    // Unlock the dropdown right before submitting so its value is sent
    if (form) {
        form.addEventListener("submit", function () {
            typeDropdown.disabled = false;
        });
    }

});