import joblib
import pandas as pd

# Load the trained model
model = joblib.load("model/random_forest_model.pkl")

# Load the encoders
label_encoders = joblib.load("model/label_encoders.pkl")
target_encoder = joblib.load("model/target_encoder.pkl")

# Sample patient input
sample_data = {
    "Mother_Age": 38,
    "Father_Age": 42,
    "Pregnancy_Week": 12,
    "Family_History": "Yes",
    "Number_of_Affected_Family_Members": 2,
    "Type_of_Family_History": "Chromosomal",
    "Carrier_Status": "Positive",
    "Parental_Genetic_Test_Result": "Positive",
    "Previous_Child_Genetic_Disorder": "No",
    "Previous_Abnormal_Pregnancy": "No",
    "Consanguineous_Marriage": "No",
    "Previous_Miscarriages": 1,
    "Multiple_Pregnancy": "No",
    "Previous_Prenatal_Screening": "Abnormal"
}

# Convert input into DataFrame
input_data = pd.DataFrame([sample_data])

# Convert text values into numbers
for column, encoder in label_encoders.items():
    input_data[column] = encoder.transform(input_data[column])

# Predict risk
prediction = model.predict(input_data)

# Convert prediction back to text
risk_level = target_encoder.inverse_transform(prediction)

print("Predicted Risk Level:", risk_level[0])