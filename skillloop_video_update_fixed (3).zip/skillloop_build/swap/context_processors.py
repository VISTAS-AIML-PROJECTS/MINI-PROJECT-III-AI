from . import tokens
from .models import TeachSession


def token_wallet(request):
    """Makes the token balance available to every template (navbar chip)."""
    user = getattr(request, "user", None)
    if not user or not user.is_authenticated:
        return {}
    return {
        "token_balance": tokens.balance(user),
        "teach_pending_count": TeachSession.objects.filter(learner=user, status="Pending").count(),
    }
