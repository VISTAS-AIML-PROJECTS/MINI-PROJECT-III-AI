from django.core.management.base import BaseCommand
from django.contrib.auth.models import User

from swap import tokens


class Command(BaseCommand):
    help = "Raise every existing member's token balance to at least --to (default 50)."

    def add_arguments(self, parser):
        parser.add_argument("--to", type=int, default=50)

    def handle(self, *args, **opts):
        target, changed = opts["to"], 0
        for user in User.objects.all():
            wallet = tokens.get_wallet(user)
            if wallet.balance < target:
                tokens.earn(user, target - wallet.balance, f"Top-up to {target} tokens", kind="admin")
                changed += 1
        self.stdout.write(self.style.SUCCESS(f"{changed} wallet(s) raised to {target} tokens."))
