class PermissionsPolicyMiddleware:
    """Explicitly allow this site (and only this site) to use camera + microphone."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response.setdefault("Permissions-Policy", "camera=(self), microphone=(self), display-capture=(self)")
        return response
