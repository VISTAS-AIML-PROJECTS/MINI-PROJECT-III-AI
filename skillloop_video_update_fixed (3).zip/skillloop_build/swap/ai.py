"""
Skill Loop AI Assistant
========================

A small, dependency-free "brain" that answers questions about the platform
(how matching works, how to book a mentor, how live rooms work, etc.) and
gives light, personalized nudges using the user's own data.

Design goals:
  * Never crash the page. If anything goes wrong (bad input, network
    issues, missing config) we fall back to a friendly canned response
    instead of raising - the chatbot must always "just work".
  * Zero required external dependencies. Everything below runs with only
    the Python standard library, so the assistant works the moment the
    Django app is running - no API key needed.
  * Optional upgrade path: if ANTHROPIC_API_KEY (or OPENAI_API_KEY) is
    set as an environment variable, we try a real LLM call first and
    silently fall back to the rule-based brain on any failure/timeout.
"""

import json
import os
import re
import urllib.request
import urllib.error

REQUEST_TIMEOUT_SECONDS = 8

# Each entry: (list of trigger keywords, response template)
# The response can use {name} which is replaced with the user's first name.
KNOWLEDGE_BASE = [
    (["hello", "hi", "hey", "yo", "sup"],
     "Hey {name}! I'm the Skill Loop assistant. I can help you with skills, "
     "matching, live rooms, mentor bookings, or just tell you how the site works. "
     "What do you need?"),

    (["thanks", "thank you", "thx", "appreciate"],
     "Anytime, {name}! Good luck with your next skill swap. 🎉"),

    (["bye", "goodbye", "see you"],
     "See you around, {name}! Come back whenever you want to learn or teach something new."),

    (["what is skill loop", "what is this", "about this site", "about skillloop", "what does this do"],
     "Skill Loop is a peer-to-peer skill-exchange platform. You list skills you can "
     "teach and skills you want to learn, and we find people whose skills complete "
     "yours - a reciprocal match. You can also join live rooms for real-time Q&A "
     "with up to 50 people, or book 1:1 sessions with mentors."),

    (["match", "matching", "reciprocal", "find someone", "find a partner"],
     "Reciprocal matching looks for people where the fit works BOTH ways: you can "
     "teach them something they want to learn, and they can teach you something you "
     "want to learn. The stronger that overlap, the higher the match score. Add a few "
     "'Can Teach' and 'Wants to Learn' skills on the Skills page, then check the "
     "Matches or AI Picks tab."),

    (["room", "live room", "group", "three people", "3 people", "multiplayer", "same time"],
     "Live Rooms let many people (up to 50, your choice when creating one) work together at the same time from any device - "
     "laptop, PC, or phone. One person posts a Question, others reply with an Answer "
     "or Note, and everyone's screen updates automatically every few seconds. Create "
     "a room from the Rooms page and share the room code with your partners."),

    (["mentor", "book", "booking", "session", "coach"],
     "You can browse mentors on the Mentors page and book a session by picking a "
     "skill, date, time and duration. The mentor will see your request under "
     "'My Bookings' and can confirm or decline it. Want to become a mentor "
     "yourself? There's a toggle for that right on the Mentors page."),

    (["token", "tokens", "out of tokens", "run out", "earn", "credits", "coins"],
     "Tokens keep learning fair. Everyone starts with a few free tokens; joining a "
     "live room or requesting a mentor session spends some. When you run out, keep "
     "learning by teaching another user: open the Tokens page, tell us who you "
     "taught, and once they confirm the lesson you earn tokens back."),

    (["feedback", "complaint", "complain", "report", "issue", "bug", "problem"],
     "You can report a problem with a class or with the website from the Feedback "
     "page (footer link, or the 'Report an issue' button inside a live room). Our "
     "team reviews every report and replies there, so check back for a response."),

    (["captcha", "robot", "security code", "security check"],
     "The 'I'm not a robot' check just asks you to type the characters in the "
     "image. Can't read it? Press the refresh arrow for a new one."),

    (["add skill", "add a skill", "new skill", "create skill", "teach", "learn"],
     "Head to the 'My Skills' page. Add anything you can teach as a 'Can Teach' "
     "skill, and anything you'd like to pick up as a 'Wants to Learn' skill. The "
     "more you add, the better your matches and recommendations get."),

    (["request", "requests", "pending", "accept", "reject"],
     "Skill exchange requests show up under 'Requests'. Sent requests are things "
     "you've asked others for; received requests are ones waiting on YOUR reply. "
     "Accepting a request just means you've agreed to coordinate the swap - you "
     "chat the details out yourselves."),

    (["ai pick", "recommend", "recommendation", "suggest"],
     "AI Picks combine your reciprocal-match score with how active a person is on "
     "the platform, to surface the people most worth reaching out to first."),

    (["device", "mobile", "phone", "laptop", "cross device", "multiple device"],
     "Skill Loop is a normal responsive website, so it works the same on your "
     "laptop, PC, tablet, or phone - just open the same URL in a browser and log "
     "in. Anything you or a partner posts (messages, bookings, matches) is stored "
     "on the server, so every device sees the same up-to-date data."),

    (["profile", "bio", "picture", "edit profile"],
     "You can update your bio, location, interests, and profile picture from the "
     "Edit Profile page, linked from your avatar in the top right."),

    (["help", "how does this work", "confused", "stuck"],
     "Happy to help, {name}. Try asking me about: skills, matching, live rooms, "
     "mentor booking, or requests - or tell me what you're trying to do and I'll "
     "point you the right way."),
]

FALLBACK_RESPONSES = [
    "I'm not totally sure about that one, {name}, but I can help with skills, "
    "matching, live rooms, mentor bookings, or requests - want to try one of those?",
    "Hmm, I don't have a good answer for that yet. Try asking about how matching, "
    "rooms, or mentor bookings work!",
]


def _tokenize(text):
    return set(re.findall(r"[a-z0-9']+", text.lower()))


def _rule_based_reply(user, message):
    name = (user.first_name or user.username) if user and user.is_authenticated else "there"
    text = (message or "").strip().lower()

    if not text:
        return "Ask me anything about Skill Loop - skills, matching, rooms, or mentors!"

    best_score = 0
    best_response = None

    for keywords, response in KNOWLEDGE_BASE:
        score = sum(1 for kw in keywords if kw in text)
        if score > best_score:
            best_score = score
            best_response = response

    if best_response is None:
        best_response = FALLBACK_RESPONSES[hash(text) % len(FALLBACK_RESPONSES)]

    try:
        return best_response.format(name=name)
    except Exception:
        return best_response


def _try_llm_call(user, message, history):
    """Optional real-LLM upgrade. Returns a string reply or None if unavailable."""
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None

    try:
        payload = {
            "model": "claude-sonnet-4-6",
            "max_tokens": 400,
            "system": (
                "You are the friendly built-in assistant for Skill Loop, a "
                "peer-to-peer skill exchange website with skill listings, "
                "reciprocal matching, live 3-person Q&A rooms, and mentor "
                "booking. Answer briefly and helpfully."
            ),
            "messages": [
                {"role": "user" if h["role"] == "user" else "assistant", "content": h["content"]}
                for h in history
            ] + [{"role": "user", "content": message}],
        }
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SECONDS) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            blocks = data.get("content", [])
            text = "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
            return text.strip() or None
    except Exception:
        # Any network / auth / parsing problem -> silently fall back.
        return None


def generate_bot_reply(user, message, history=None):
    """
    Return a reply string for the given user message.
    `history` is an optional list of {"role": "user"/"bot", "content": str}
    for the most recent turns, used only by the optional LLM upgrade path.
    """
    history = history or []

    llm_reply = _try_llm_call(user, message, history)
    if llm_reply:
        return llm_reply

    return _rule_based_reply(user, message)
