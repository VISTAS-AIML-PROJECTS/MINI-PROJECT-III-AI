"""Bot protection + brute-force protection, reusable on any form."""
import hmac

from django import forms
from django.core.cache import cache
from django.core.exceptions import ValidationError

from . import captcha

LOGIN_MAX_FAILURES = 5
LOGIN_LOCK_SECONDS = 10 * 60


class BotProtectionMixin:
    """
    Add to any Form / ModelForm (listed BEFORE forms.Form / forms.ModelForm).
    Adds an "I'm not a robot" code, a hidden honeypot and a minimum
    fill-time check. The template just does {% include "swap/_captcha.html" %}.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # A fresh challenge on every render (including re-renders after errors).
        self.challenge_token = captcha.new_token()
        self.form_stamp = captcha.new_stamp()
        self.fields["captcha_answer"] = forms.CharField(
            label="Security code",
            max_length=12,
            error_messages={"required": "Please type the code from the image."},
            widget=forms.TextInput(attrs={
                "placeholder": "Type the code",
                "autocomplete": "off",
                "autocapitalize": "characters",
                "spellcheck": "false",
                "maxlength": "12",
                "id": "captchaAnswer",
            }),
        )

    def clean_captcha_answer(self):
        answer = (self.cleaned_data.get("captcha_answer") or "").strip().upper().replace(" ", "")
        try:
            nonce = captcha.check_token(self.data.get("captcha_token", ""))
        except captcha.CaptchaError as exc:
            raise ValidationError(str(exc))
        # Single use: a challenge can only ever be attempted once.
        if not cache.add(f"captcha-used:{nonce}", 1, captcha.MAX_AGE + 60):
            raise ValidationError("That code was already used. Please use the new code below.")
        if not hmac.compare_digest(answer, captcha.code_for(nonce)):
            raise ValidationError("The code didn't match. Please try the new one below.")
        return answer

    def clean(self):
        cleaned = super().clean()
        if self.data.get("website_url"):          # honeypot: only bots fill it
            raise ValidationError("Submission rejected.")
        age = captcha.stamp_age(self.data.get("form_stamp", ""))
        if age is None:
            raise ValidationError("Your session looks out of date. Please reload the page and try again.")
        if age < captcha.MIN_FILL_SECONDS:
            raise ValidationError("That was too fast. Please wait a moment and submit again.")
        return cleaned


# ---------- login brute-force lock ----------

def _lock_key(request, identifier):
    ip = request.META.get("REMOTE_ADDR", "unknown")
    return f"login-fail:{ip}:{(identifier or '').lower()[:80]}"


def is_login_locked(request, identifier):
    return cache.get(_lock_key(request, identifier), 0) >= LOGIN_MAX_FAILURES


def register_login_failure(request, identifier):
    key = _lock_key(request, identifier)
    cache.set(key, cache.get(key, 0) + 1, LOGIN_LOCK_SECONDS)


def clear_login_failures(request, identifier):
    cache.delete(_lock_key(request, identifier))
