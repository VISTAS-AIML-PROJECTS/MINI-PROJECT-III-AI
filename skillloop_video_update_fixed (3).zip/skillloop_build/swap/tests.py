import json
import time

from django.contrib.auth.models import User
from django.test import TestCase, override_settings
from django.urls import reverse

from . import captcha, tokens
from .models import SkillRoom


def solved_captcha():
    """POST fields that pass the self-hosted security check."""
    token = captcha.new_token()
    nonce = captcha.check_token(token)
    return {
        "captcha_token": token,
        "captcha_answer": captcha.code_for(nonce),
        "form_stamp": captcha.new_stamp(now=time.time() - 10),
    }


def make_room(owner, **kw):
    room = SkillRoom.objects.create(title="Python help", created_by=owner, **kw)
    room.participants.add(owner)
    return room


class TokenTests(TestCase):
    def test_new_members_start_with_50_tokens(self):
        user = User.objects.create_user("ann", password="pw12345!")
        self.assertEqual(tokens.get_wallet(user).balance, 50)


class CaptchaPlacementTests(TestCase):
    def setUp(self):
        self.a = User.objects.create_user("alice", password="pw12345!")
        self.b = User.objects.create_user("bob", password="pw12345!")
        self.room = make_room(self.a, max_participants=2)

    def test_login_page_has_captcha(self):
        self.assertContains(self.client.get(reverse("login")), "captcha_token")

    def test_register_page_has_no_captcha(self):
        self.assertNotContains(self.client.get(reverse("register")), "captcha_token")

    def test_feedback_page_has_no_captcha(self):
        self.client.login(username="bob", password="pw12345!")
        self.assertNotContains(self.client.get(reverse("feedback_new")), "captcha_token")

    def test_joining_a_class_needs_captcha(self):
        self.client.login(username="bob", password="pw12345!")
        url = reverse("room_join", args=[self.room.room_code])
        self.assertContains(self.client.get(url), "captcha_token")

        self.client.post(url, {})                          # no answer -> not joined
        self.assertFalse(self.room.participants.filter(pk=self.b.pk).exists())

        self.client.post(url, solved_captcha())            # solved -> joined
        self.assertTrue(self.room.participants.filter(pk=self.b.pk).exists())
        self.assertEqual(tokens.get_wallet(self.b).balance, 49)


@override_settings(CALL_MAX_PARTICIPANTS=2)
class CallSignallingTests(TestCase):
    def setUp(self):
        self.a = User.objects.create_user("alice", password="pw12345!")
        self.b = User.objects.create_user("bob", password="pw12345!")
        self.c = User.objects.create_user("carol", password="pw12345!")
        self.room = make_room(self.a, max_participants=5)
        self.room.participants.add(self.b, self.c)
        self.code = self.room.room_code

    def post(self, client, name, body):
        return client.post(reverse(name, args=[self.code]), json.dumps(body), content_type="application/json")

    def client_for(self, username):
        from django.test import Client
        c = Client()
        c.login(username=username, password="pw12345!")
        return c

    def test_two_people_can_exchange_signals(self):
        ca, cb = self.client_for("alice"), self.client_for("bob")
        self.assertEqual(self.post(ca, "call_join", {"session": "aaaa"}).status_code, 200)
        self.assertEqual(self.post(cb, "call_join", {"session": "bbbb"}).status_code, 200)

        peers = self.post(ca, "call_poll", {"session": "aaaa", "after": 0}).json()["peers"]
        self.assertEqual([p["id"] for p in peers], [self.b.id])

        r = self.post(ca, "call_signal", {"to": self.b.id, "kind": "offer",
                                          "payload": {"s": "aaaa", "t": "bbbb", "sdp": {"type": "offer", "sdp": "x"}}})
        self.assertEqual(r.status_code, 200)
        got = self.post(cb, "call_poll", {"session": "bbbb", "after": 0}).json()["signals"]
        self.assertEqual([(s["from"], s["kind"]) for s in got], [(self.a.id, "offer")])

        # the sender never receives their own message
        self.assertEqual(self.post(ca, "call_poll", {"session": "aaaa", "after": 0}).json()["signals"], [])

    def test_call_is_capped_but_chat_room_is_not(self):
        self.post(self.client_for("alice"), "call_join", {"session": "aaaa"})
        self.post(self.client_for("bob"), "call_join", {"session": "bbbb"})
        self.assertEqual(self.post(self.client_for("carol"), "call_join", {"session": "cccc"}).status_code, 409)

    def test_outsiders_are_rejected(self):
        outsider = User.objects.create_user("eve", password="pw12345!")
        ce = self.client_for("eve")
        self.assertEqual(self.post(ce, "call_join", {"session": "eeee"}).status_code, 403)
        self.assertEqual(self.post(ce, "call_poll", {"session": "eeee"}).status_code, 403)

    def test_leaving_removes_presence(self):
        ca, cb = self.client_for("alice"), self.client_for("bob")
        self.post(ca, "call_join", {"session": "aaaa"})
        self.post(cb, "call_join", {"session": "bbbb"})
        self.post(cb, "call_leave", {})
        self.assertEqual(self.post(ca, "call_poll", {"session": "aaaa", "after": 0}).json()["peers"], [])


# ================= LIVE CLASS FLOW =================
from django.test import Client
from .models import CallPresence, CallSignal, RoomMessage


def login_client(username):
    c = Client()
    c.login(username=username, password="pw12345!")
    return c


class RoomFlowTests(TestCase):
    def setUp(self):
        self.a = User.objects.create_user("alice", password="pw12345!")
        self.b = User.objects.create_user("bob", password="pw12345!")
        self.ca, self.cb = login_client("alice"), login_client("bob")

    def test_create_room_makes_host_participant_and_code(self):
        r = self.ca.post(reverse("room_list"), {"title": "Python Basics", "topic": "Python", "max_participants": 10})
        room = SkillRoom.objects.get(title="Python Basics")
        self.assertRedirects(r, reverse("room_detail", args=[room.room_code]))
        self.assertEqual(len(room.room_code), 8)
        self.assertTrue(room.participants.filter(pk=self.a.pk).exists())
        self.assertEqual(tokens.get_wallet(self.a).balance, 49)   # host charged once
        page = self.ca.get(reverse("room_detail", args=[room.room_code]))
        self.assertContains(page, room.room_code)
        self.assertContains(page, "Share Class")

    def test_room_appears_in_list_and_join_from_list(self):
        room = make_room(self.a, max_participants=5)
        self.assertContains(self.cb.get(reverse("room_list")), room.room_code)
        r = self.cb.post(reverse("room_join", args=[room.room_code]), solved_captcha())
        self.assertRedirects(r, reverse("room_detail", args=[room.room_code]))
        self.assertTrue(room.participants.filter(pk=self.b.pk).exists())
        self.assertEqual(tokens.get_wallet(self.b).balance, 49)

    def test_join_by_code_is_case_insensitive_and_needs_captcha(self):
        room = make_room(self.a, max_participants=5)
        r = self.cb.post(reverse("room_join_by_code"), {"room_code": room.room_code.lower()})
        self.assertRedirects(r, reverse("room_join", args=[room.room_code]), fetch_redirect_response=False)
        self.assertFalse(room.participants.filter(pk=self.b.pk).exists())
        self.cb.post(reverse("room_join", args=[room.room_code.lower()]), solved_captcha())
        self.assertTrue(room.participants.filter(pk=self.b.pk).exists())

    def test_invalid_code_rejected(self):
        r = self.cb.post(reverse("room_join_by_code"), {"room_code": "NOPE1234"}, follow=True)
        self.assertContains(r, "No class found")

    def test_full_and_inactive_rooms_cannot_be_joined(self):
        full = make_room(self.a, max_participants=2)
        full.participants.add(User.objects.create_user("x", password="pw12345!"))
        self.cb.post(reverse("room_join", args=[full.room_code]), solved_captcha())
        self.assertFalse(full.participants.filter(pk=self.b.pk).exists())
        ended = make_room(self.a, max_participants=5)
        ended.is_active = False
        ended.save()
        self.cb.post(reverse("room_join", args=[ended.room_code]), solved_captcha())
        self.assertFalse(ended.participants.filter(pk=self.b.pk).exists())

    def test_no_tokens_cannot_join_and_no_double_charge(self):
        room = make_room(self.a, max_participants=5)
        w = tokens.get_wallet(self.b); w.balance = 0; w.save()
        self.cb.post(reverse("room_join", args=[room.room_code]), solved_captcha())
        self.assertFalse(room.participants.filter(pk=self.b.pk).exists())
        w.balance = 5; w.save()
        self.cb.post(reverse("room_join", args=[room.room_code]), solved_captcha())
        self.cb.post(reverse("room_leave", args=[room.room_code]))
        self.cb.post(reverse("room_join", args=[room.room_code]), solved_captcha())   # rejoin is free
        self.assertTrue(room.participants.filter(pk=self.b.pk).exists())
        self.assertEqual(tokens.get_wallet(self.b).balance, 4)

    def test_chat_only_for_participants(self):
        room = make_room(self.a)
        RoomMessage.objects.create(room=room, sender=self.a, content="secret hello")
        self.assertEqual(self.cb.get(reverse("room_messages_api", args=[room.room_code])).status_code, 403)
        self.assertEqual(self.cb.post(reverse("room_detail", args=[room.room_code]), {"message_type": "chat", "content": "hi"}).status_code, 403)
        self.assertNotContains(self.cb.get(reverse("room_detail", args=[room.room_code])), "secret hello")
        self.assertEqual(self.ca.get(reverse("room_messages_api", args=[room.room_code])).status_code, 200)


@override_settings(CALL_MAX_PARTICIPANTS=2)
class CallHardeningTests(TestCase):
    def setUp(self):
        self.a = User.objects.create_user("alice", password="pw12345!")
        self.b = User.objects.create_user("bob", password="pw12345!")
        self.c = User.objects.create_user("carol", password="pw12345!")
        self.room = make_room(self.a, max_participants=5)
        self.room.participants.add(self.b, self.c)
        self.code = self.room.room_code
        self.ca, self.cb, self.cc = login_client("alice"), login_client("bob"), login_client("carol")

    def post(self, c, name, body):
        return c.post(reverse(name, args=[self.code]), json.dumps(body), content_type="application/json")

    def sig(self, c, to, kind, s, t, payload=None):
        pl = {"s": s, "t": t}
        pl.update(payload or {"sdp": {"type": kind, "sdp": "x"}})
        return self.post(c, "call_signal", {"to": to, "kind": kind, "payload": pl})

    def test_signal_kinds_and_validation(self):
        self.post(self.ca, "call_join", {"session": "aaaa"}); self.post(self.cb, "call_join", {"session": "bbbb"})
        self.assertEqual(self.sig(self.ca, self.b.id, "offer", "aaaa", "bbbb").status_code, 200)
        self.assertEqual(self.sig(self.cb, self.a.id, "answer", "bbbb", "aaaa").status_code, 200)
        self.assertEqual(self.sig(self.ca, self.b.id, "candidate", "aaaa", "bbbb", {"candidate": {"candidate": "c"}}).status_code, 200)
        self.assertEqual(self.sig(self.ca, self.b.id, "bogus", "aaaa", "bbbb").status_code, 400)
        self.assertEqual(self.post(self.ca, "call_signal", {"to": "zz", "kind": "offer", "payload": {}}).status_code, 400)
        self.assertEqual(self.post(self.ca, "call_signal", {"to": self.b.id, "kind": "offer", "payload": "str"}).status_code, 400)

    def test_signal_rejects_stale_sessions_and_non_call_members(self):
        self.post(self.ca, "call_join", {"session": "aaaa"}); self.post(self.cb, "call_join", {"session": "bbbb"})
        self.assertEqual(self.sig(self.ca, self.b.id, "offer", "aaaa", "OLD1").status_code, 409)   # old recipient session
        self.assertEqual(self.sig(self.ca, self.b.id, "offer", "OLD2", "bbbb").status_code, 410)   # spoofed sender session
        self.assertEqual(self.sig(self.cc, self.a.id, "offer", "cccc", "aaaa").status_code, 410)   # participant, not in call
        self.assertEqual(self.sig(self.ca, self.c.id, "offer", "aaaa", "cccc").status_code, 404)   # recipient not in call
        self.assertEqual(self.sig(self.ca, self.a.id, "offer", "aaaa", "aaaa").status_code, 400)   # to self

    def test_outsider_cannot_signal_or_leave_others(self):
        eve = User.objects.create_user("eve", password="pw12345!"); ce = login_client("eve")
        self.post(self.ca, "call_join", {"session": "aaaa"})
        self.assertEqual(self.sig(ce, self.a.id, "offer", "eeee", "aaaa").status_code, 403)
        self.assertEqual(self.post(ce, "call_join", {"session": "eeee"}).status_code, 403)

    def test_rejoin_with_new_session_replaces_old(self):
        self.post(self.ca, "call_join", {"session": "aaaa"}); self.post(self.cb, "call_join", {"session": "bbbb"})
        self.post(self.cb, "call_join", {"session": "b2b2"})       # refresh
        self.assertEqual(CallPresence.objects.filter(room=self.room, user=self.b).count(), 1)
        peers = self.post(self.ca, "call_poll", {"session": "aaaa", "after": 0}).json()["peers"]
        self.assertEqual(peers[0]["session"], "b2b2")
        self.assertEqual(self.post(self.cb, "call_poll", {"session": "bbbb", "after": 0}).status_code, 410)

    def test_leave_room_removes_call_presence(self):
        self.post(self.ca, "call_join", {"session": "aaaa"}); self.post(self.cb, "call_join", {"session": "bbbb"})
        self.cb.post(reverse("room_leave", args=[self.code]))
        self.assertFalse(CallPresence.objects.filter(room=self.room, user=self.b).exists())
        self.assertEqual(self.post(self.cb, "call_join", {"session": "bbbb"}).status_code, 403)

    def test_call_url_is_case_insensitive(self):
        r = self.cb.post(reverse("call_join", args=[self.code.lower()]), json.dumps({"session": "bbbb"}), content_type="application/json")
        self.assertEqual(r.status_code, 200)


class IceConfigTests(TestCase):
    def test_stun_always_present(self):
        from django.conf import settings
        self.assertTrue(any("stun:" in str(s["urls"]) for s in settings.WEBRTC_ICE_SERVERS))
