"""
Self-hosted "I'm not a robot" challenge.

Why self-hosted: no API keys, no third-party scripts and no internet access
are needed, so it cannot fail because an external service is down.

How it works (stateless, safe with several tabs open):
  * A challenge token = random nonce + timestamp + HMAC signature.
  * The answer is NOT stored anywhere. It is derived from the nonce with a
    secret key, so nobody can read it out of the token or the page.
  * The image endpoint re-derives the answer from the token and draws it.
  * On submit the server re-derives the answer and compares. The nonce is
    then marked used (see security.py) so a solved challenge can't be replayed.
"""
import hashlib
import hmac
import io
import random
import secrets
import time

from PIL import Image, ImageDraw, ImageFont

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # no 0/O, 1/I/L lookalikes
CODE_LENGTH = 5
MAX_AGE = 15 * 60          # a challenge is valid for 15 minutes
MIN_FILL_SECONDS = 2       # a human cannot fill a form faster than this
IMG_W, IMG_H = 190, 66

_FONT_CANDIDATES = [
    "DejaVuSans-Bold.ttf", "arialbd.ttf", "Arial Bold.ttf", "Arial.ttf",
    "LiberationSans-Bold.ttf", "FreeSansBold.ttf", "Verdana.ttf",
]


class CaptchaError(Exception):
    """Raised with a user-friendly message."""


def _secret(secret=None):
    if secret is not None:
        return secret if isinstance(secret, bytes) else secret.encode()
    from django.conf import settings
    return settings.SECRET_KEY.encode()


def _mac(msg, secret=None):
    return hmac.new(_secret(secret), msg.encode(), hashlib.sha256)


# ---------- challenge tokens ----------

def new_token(secret=None, now=None):
    nonce = secrets.token_hex(8)
    ts = int(now if now is not None else time.time())
    sig = _mac(f"tok:{nonce}.{ts}", secret).hexdigest()[:32]
    return f"{nonce}.{ts}.{sig}"


def check_token(token, secret=None, now=None):
    """Return the nonce if the token is authentic and fresh, else raise."""
    try:
        nonce, ts, sig = (token or "").split(".")
        ts = int(ts)
    except ValueError:
        raise CaptchaError("Security check is missing. Please use the new code below.")
    expected = _mac(f"tok:{nonce}.{ts}", secret).hexdigest()[:32]
    if not hmac.compare_digest(sig, expected):
        raise CaptchaError("Security check is invalid. Please use the new code below.")
    age = (now if now is not None else time.time()) - ts
    if age < 0 or age > MAX_AGE:
        raise CaptchaError("That code expired. Please use the new code below.")
    return nonce


def code_for(nonce, secret=None):
    digest = _mac(f"code:{nonce}", secret).digest()
    return "".join(ALPHABET[b % len(ALPHABET)] for b in digest[:CODE_LENGTH])


# ---------- "how long was the form open" stamp ----------

def new_stamp(secret=None, now=None):
    ts = int(now if now is not None else time.time())
    return f"{ts}.{_mac(f'stamp:{ts}', secret).hexdigest()[:32]}"


def stamp_age(stamp, secret=None, now=None):
    """Seconds since the form was rendered, or None if the stamp is bad."""
    try:
        ts, sig = (stamp or "").split(".")
        ts = int(ts)
    except ValueError:
        return None
    if not hmac.compare_digest(sig, _mac(f"stamp:{ts}", secret).hexdigest()[:32]):
        return None
    return (now if now is not None else time.time()) - ts


# ---------- image ----------

def _load_font(size):
    for name in _FONT_CANDIDATES:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:                                   # Pillow >= 10.1
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def render_png(code):
    rnd = random.Random()
    img = Image.new("RGB", (IMG_W, IMG_H), (243, 239, 255))
    draw = ImageDraw.Draw(img)

    for _ in range(9):   # background lines
        c = tuple(rnd.randint(150, 215) for _ in range(3))
        draw.line([(rnd.randint(0, IMG_W), rnd.randint(0, IMG_H)),
                   (rnd.randint(0, IMG_W), rnd.randint(0, IMG_H))], fill=c, width=rnd.randint(1, 2))

    font = _load_font(34)
    slot = (IMG_W - 14) // len(code)
    x = 4
    for ch in code:
        tile = Image.new("RGBA", (56, 56), (0, 0, 0, 0))
        td = ImageDraw.Draw(tile)
        colour = (rnd.randint(30, 110), rnd.randint(20, 80), rnd.randint(110, 200))
        td.text((6, 6), ch, font=font, fill=colour)
        tile = tile.rotate(rnd.randint(-24, 24), resample=Image.BICUBIC, expand=False)
        img.paste(tile, (x, rnd.randint(2, IMG_H - 58)), tile)
        x += slot

    for _ in range(3):   # strike-through lines over the text
        c = tuple(rnd.randint(60, 150) for _ in range(3))
        draw.line([(0, rnd.randint(18, IMG_H - 18)), (IMG_W, rnd.randint(18, IMG_H - 18))],
                  fill=c, width=2)
    for _ in range(140):  # speckle
        draw.point((rnd.randint(0, IMG_W - 1), rnd.randint(0, IMG_H - 1)),
                   fill=tuple(rnd.randint(90, 200) for _ in range(3)))

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()
