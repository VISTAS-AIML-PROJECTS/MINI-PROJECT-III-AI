import uuid

from django.db import models
from django.contrib.auth.models import User


CATEGORY_CHOICES = [
    ("Programming", "Programming"),
    ("Artificial Intelligence", "Artificial Intelligence"),
    ("Web Development", "Web Development"),
    ("Data Science", "Data Science"),
    ("Designing", "Designing"),
    ("Languages", "Languages"),
    ("Music", "Music"),
    ("Photography", "Photography"),
    ("Business", "Business"),
    ("Other", "Other Skills"),
]

LEVEL_CHOICES = [
    ("Beginner", "Beginner"),
    ("Intermediate", "Intermediate"),
    ("Advanced", "Advanced"),
    ("Expert", "Expert"),
]

SKILL_TYPE_CHOICES = [
    ("teach", "Can Teach"),
    ("learn", "Wants to Learn"),
]

REQUEST_STATUS_CHOICES = [
    ("Pending", "Pending"),
    ("Accepted", "Accepted"),
    ("Rejected", "Rejected"),
    ("Cancelled", "Cancelled"),
    ("Completed", "Completed"),
]


class UserProfile(models.Model):
    """Extra information about a user, on top of Django's built-in User model."""

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="profile",
    )

    profile_picture = models.ImageField(
        upload_to="profile_pictures/",
        blank=True,
        null=True,
    )

    bio = models.TextField(blank=True)

    location = models.CharField(max_length=100, blank=True)

    interests = models.CharField(
        max_length=255,
        blank=True,
        help_text="Comma separated interests, e.g. AI, Music, Startups",
    )

    experience_level = models.CharField(
        max_length=20,
        choices=LEVEL_CHOICES,
        default="Beginner",
    )

    is_mentor = models.BooleanField(
        default=False,
        help_text="Whether this user offers 1:1 mentor sessions.",
    )

    mentor_headline = models.CharField(
        max_length=140,
        blank=True,
        help_text="Short tagline shown on the mentor's card, e.g. 'Senior React dev, 6 yrs'.",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username

    def interests_list(self):
        return [i.strip() for i in self.interests.split(",") if i.strip()]


class Skill(models.Model):
    """A single skill entry that a user can either teach or wants to learn."""

    owner = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="skills",
    )

    name = models.CharField(max_length=100)

    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default="Other")

    level = models.CharField(max_length=20, choices=LEVEL_CHOICES, default="Beginner")

    skill_type = models.CharField(max_length=10, choices=SKILL_TYPE_CHOICES)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.owner.username} - {self.name} ({self.get_skill_type_display()})"


class SkillRequest(models.Model):
    """A skill exchange request sent from one user to another."""

    sender = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="sent_requests",
    )

    receiver = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="received_requests",
    )

    skill_offered = models.CharField(max_length=100, help_text="What the sender will teach")

    skill_wanted = models.CharField(max_length=100, help_text="What the sender wants to learn")

    message = models.TextField(blank=True)

    status = models.CharField(
        max_length=20,
        choices=REQUEST_STATUS_CHOICES,
        default="Pending",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.sender.username} -> {self.receiver.username} ({self.status})"


BOOKING_STATUS_CHOICES = [
    ("Pending", "Pending"),
    ("Confirmed", "Confirmed"),
    ("Declined", "Declined"),
    ("Cancelled", "Cancelled"),
    ("Completed", "Completed"),
]


class MentorBooking(models.Model):

    student = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="mentor_bookings",
    )

    mentor = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        related_name="bookings_as_mentor",
        null=True,
        blank=True,
    )

    # Kept for backwards compatibility / display even if the mentor
    # account is later removed.
    mentor_name = models.CharField(max_length=100)

    skill = models.CharField(max_length=100)

    booking_date = models.DateField()

    booking_time = models.TimeField()

    duration_minutes = models.PositiveIntegerField(default=30)

    notes = models.TextField(blank=True)

    status = models.CharField(
        max_length=20,
        choices=BOOKING_STATUS_CHOICES,
        default="Pending",
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-booking_date", "-booking_time"]

    def __str__(self):
        return f"{self.student.username} -> {self.mentor_name} ({self.status})"


# ================= LIVE COLLAB ROOMS =================
# Small real-time-ish rooms where up to `max_participants` people can hop
# in from any device (laptop, PC, mobile - anything with a browser) and
# post questions / answers / notes. Updates are synced across every open
# device through lightweight polling of `RoomMessage`, so as long as
# everyone is pointed at the same running server, everyone sees the same
# conversation update within a couple of seconds.

ROOM_MAX_PARTICIPANTS_CHOICES = [
    (2, "2 people"),
    (3, "3 people"),
    (5, "5 people"),
    (10, "10 people"),
    (25, "25 people"),
    (50, "50 people"),
]

MESSAGE_TYPE_CHOICES = [
    ("chat", "Message"),
    ("question", "Question"),
    ("answer", "Answer"),
    ("note", "Note"),
]


def generate_room_code():
    return uuid.uuid4().hex[:8].upper()


class SkillRoom(models.Model):
    """A small live room for a focused skill Q&A / practice session."""

    title = models.CharField(max_length=140)

    topic = models.CharField(
        max_length=100,
        blank=True,
        help_text="What skill or subject this room is about.",
    )

    room_code = models.CharField(
        max_length=12,
        unique=True,
        default=generate_room_code,
        editable=False,
    )

    created_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="rooms_created",
    )

    participants = models.ManyToManyField(
        User,
        related_name="rooms",
        blank=True,
    )

    max_participants = models.PositiveSmallIntegerField(
        choices=ROOM_MAX_PARTICIPANTS_CHOICES,
        default=10,
    )

    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.title} ({self.room_code})"

    def participant_count(self):
        return self.participants.count()

    def is_full(self):
        return self.participant_count() >= self.max_participants

    def spots_left(self):
        return max(0, self.max_participants - self.participant_count())

    def slots(self):
        """Up to 10 dots for the capacity indicator (scaled for big rooms)."""
        total = min(self.max_participants, 10)
        count = self.participant_count()
        if self.max_participants <= 10:
            filled = min(count, total)
        else:
            filled = min(total, -(-count * total // self.max_participants))
        return [i < filled for i in range(total)]


class RoomMessage(models.Model):
    """One post inside a SkillRoom: a question, an answer, or a note."""

    room = models.ForeignKey(
        SkillRoom,
        on_delete=models.CASCADE,
        related_name="messages",
    )

    sender = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="room_messages",
    )

    message_type = models.CharField(
        max_length=10,
        choices=MESSAGE_TYPE_CHOICES,
        default="chat",
    )

    content = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"[{self.room.room_code}] {self.sender.username}: {self.content[:40]}"


# ================= AI CHATBOT =================

CHAT_ROLE_CHOICES = [
    ("user", "User"),
    ("bot", "Bot"),
]


class ChatMessage(models.Model):
    """One turn of the built-in AI assistant conversation for a user."""

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="chat_messages",
    )

    role = models.CharField(max_length=10, choices=CHAT_ROLE_CHOICES)

    content = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"{self.user.username} [{self.role}]: {self.content[:40]}"



# ================= TOKENS (learn-by-teaching economy) =================
# Every learner has a small wallet. Joining a live room or booking a mentor
# costs tokens. When the wallet is empty, the way to keep learning is to
# teach another user: once that user confirms the lesson, the teacher earns
# tokens. All amounts live in settings.py (TOKEN_*).

class TokenWallet(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="wallet")
    balance = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username}: {self.balance} tokens"


TOKEN_KIND_CHOICES = [
    ("bonus", "Bonus"),
    ("spend", "Spent"),
    ("earn", "Earned by teaching"),
    ("refund", "Refund"),
    ("admin", "Admin adjustment"),
]


class TokenTransaction(models.Model):
    """Append-only ledger: every change to a wallet leaves a row here."""

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="token_transactions")
    amount = models.IntegerField(help_text="Positive = received, negative = spent")
    kind = models.CharField(max_length=10, choices=TOKEN_KIND_CHOICES)
    reason = models.CharField(max_length=200)
    reference = models.CharField(max_length=60, blank=True, db_index=True)
    balance_after = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]

    def __str__(self):
        return f"{self.user.username} {self.amount:+d} ({self.kind})"


TEACH_STATUS_CHOICES = [
    ("Pending", "Waiting for confirmation"),
    ("Confirmed", "Confirmed"),
    ("Declined", "Declined"),
    ("Cancelled", "Cancelled"),
]


class TeachSession(models.Model):
    """A lesson one user says they taught another. The learner must confirm
    it before the teacher is rewarded, which keeps the system honest."""

    teacher = models.ForeignKey(User, on_delete=models.CASCADE, related_name="teach_sessions_given")
    learner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="teach_sessions_received")
    skill = models.CharField(max_length=100)
    summary = models.TextField(max_length=500)
    status = models.CharField(max_length=10, choices=TEACH_STATUS_CHOICES, default="Pending")
    tokens_awarded = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.teacher.username} taught {self.learner.username}: {self.skill} ({self.status})"


# ================= FEEDBACK / COMPLAINTS =================

FEEDBACK_KIND_CHOICES = [
    ("complaint", "Complaint"),
    ("issue", "Issue / bug"),
    ("suggestion", "Suggestion"),
]

FEEDBACK_TARGET_CHOICES = [
    ("class", "A class / live room"),
    ("site", "The website"),
]

FEEDBACK_STATUS_CHOICES = [
    ("Open", "Open"),
    ("Reviewing", "In review"),
    ("Resolved", "Resolved"),
]


class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="feedback_items")
    kind = models.CharField(max_length=12, choices=FEEDBACK_KIND_CHOICES, default="issue")
    target = models.CharField(max_length=6, choices=FEEDBACK_TARGET_CHOICES, default="site")
    room = models.ForeignKey(
        SkillRoom, null=True, blank=True, on_delete=models.SET_NULL, related_name="feedback_items",
    )
    subject = models.CharField(max_length=140)
    message = models.TextField(max_length=2000)
    status = models.CharField(max_length=10, choices=FEEDBACK_STATUS_CHOICES, default="Open")
    admin_response = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name_plural = "feedback"

    def __str__(self):
        return f"[{self.get_kind_display()}] {self.subject} - {self.user.username}"


# ================= VIDEO / VOICE CALLS (WebRTC signalling) =================
# Audio/video flows browser-to-browser (WebRTC). The server only relays the
# small "offer / answer / ICE candidate" handshake messages stored here, and
# remembers who is currently in the call of each room.

class CallPresence(models.Model):
    """Who is in a room's video call right now (refreshed by a heartbeat)."""

    room = models.ForeignKey(SkillRoom, on_delete=models.CASCADE, related_name="call_presence")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="call_presence")
    session = models.CharField(max_length=32, help_text="Random id for this browser tab's call session")
    last_seen = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = [("room", "user")]

    def __str__(self):
        return f"{self.user.username} in call {self.room.room_code}"


class CallSignal(models.Model):
    """One WebRTC handshake message from one participant to another."""

    room = models.ForeignKey(SkillRoom, on_delete=models.CASCADE, related_name="call_signals")
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="signals_sent")
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name="signals_received")
    kind = models.CharField(max_length=12)          # offer / answer / candidate
    payload = models.TextField()                    # JSON from the browser
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["id"]
        indexes = [models.Index(fields=["room", "recipient", "id"])]
