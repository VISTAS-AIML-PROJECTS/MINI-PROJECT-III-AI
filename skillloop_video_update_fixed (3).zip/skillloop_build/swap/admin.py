from django.contrib import admin
from .models import (
    UserProfile,
    Skill,
    SkillRequest,
    MentorBooking,
    SkillRoom,
    RoomMessage,
    ChatMessage,
    TokenWallet,
    TokenTransaction,
    TeachSession,
    Feedback,
)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "location", "experience_level", "is_mentor", "created_at")
    list_filter = ("is_mentor",)
    search_fields = ("user__username", "user__email", "location")


@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "skill_type", "category", "level")
    list_filter = ("skill_type", "category", "level")
    search_fields = ("name", "owner__username")


@admin.register(SkillRequest)
class SkillRequestAdmin(admin.ModelAdmin):
    list_display = ("sender", "receiver", "skill_offered", "skill_wanted", "status", "created_at")
    list_filter = ("status",)


@admin.register(MentorBooking)
class MentorBookingAdmin(admin.ModelAdmin):
    list_display = ("student", "mentor_name", "skill", "booking_date", "booking_time", "status")
    list_filter = ("status",)


class RoomMessageInline(admin.TabularInline):
    model = RoomMessage
    extra = 0
    readonly_fields = ("sender", "message_type", "content", "created_at")


@admin.register(SkillRoom)
class SkillRoomAdmin(admin.ModelAdmin):
    list_display = ("title", "room_code", "created_by", "max_participants", "is_active", "created_at")
    list_filter = ("is_active", "max_participants")
    search_fields = ("title", "room_code")
    inlines = [RoomMessageInline]


@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("user", "role", "content", "created_at")
    list_filter = ("role",)
    search_fields = ("user__username", "content")

# ================= TOKENS =================

@admin.register(TokenWallet)
class TokenWalletAdmin(admin.ModelAdmin):
    list_display = ("user", "balance", "created_at")
    search_fields = ("user__username", "user__email")
    # Tip: edit "balance" here to grant or remove tokens by hand.


@admin.register(TokenTransaction)
class TokenTransactionAdmin(admin.ModelAdmin):
    list_display = ("user", "amount", "kind", "reason", "balance_after", "created_at")
    list_filter = ("kind",)
    search_fields = ("user__username", "reason", "reference")
    readonly_fields = ("user", "amount", "kind", "reason", "reference", "balance_after", "created_at")

    def has_add_permission(self, request):
        return False


@admin.register(TeachSession)
class TeachSessionAdmin(admin.ModelAdmin):
    list_display = ("teacher", "learner", "skill", "status", "tokens_awarded", "created_at")
    list_filter = ("status",)
    search_fields = ("teacher__username", "learner__username", "skill")


# ================= FEEDBACK =================

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ("subject", "user", "kind", "target", "room", "status", "created_at")
    list_filter = ("status", "kind", "target")
    list_editable = ("status",)
    search_fields = ("subject", "message", "user__username", "room__title")
    readonly_fields = ("user", "kind", "target", "room", "subject", "message", "created_at", "updated_at")
    fields = (
        "user", "kind", "target", "room", "subject", "message",
        "status", "admin_response", "created_at", "updated_at",
    )
    actions = ["mark_reviewing", "mark_resolved"]

    @admin.action(description="Mark selected as In review")
    def mark_reviewing(self, request, queryset):
        queryset.update(status="Reviewing")

    @admin.action(description="Mark selected as Resolved")
    def mark_resolved(self, request, queryset):
        queryset.update(status="Resolved")
