import json
import threading
from datetime import timedelta

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.db import transaction, OperationalError
from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.utils import timezone
from django.views.decorators.http import require_POST, require_GET

from .models import (
    UserProfile,
    Skill,
    SkillRequest,
    MentorBooking,
    SkillRoom,
    RoomMessage,
    CallPresence,
    CallSignal,
    ChatMessage,
    TeachSession,
    Feedback,
    CATEGORY_CHOICES,
    LEVEL_CHOICES,
)
from .forms import (
    RegisterForm,
    ProfileForm,
    UserBasicForm,
    SkillForm,
    SkillRequestForm,
    MentorProfileForm,
    MentorBookingForm,
    SkillRoomForm,
    RoomMessageForm,
    LoginForm,
    TeachSessionForm,
    FeedbackForm,
    JoinRoomForm,
)
from django.conf import settings
from . import captcha, tokens
from .security import is_login_locked, register_login_failure, clear_login_failures
from .matching import find_matches_for_user, get_recommendations_for_user
from .ai import generate_bot_reply


# ================= HOME =================

def home(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    stats = {
        "users": User.objects.count(),
        "skills": Skill.objects.count(),
        "exchanges": SkillRequest.objects.filter(status="Completed").count(),
    }
    return render(request, "swap/home.html", {"stats": stats})


# ================= REGISTER =================

def register_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data["password"])
            user.save()

            UserProfile.objects.get_or_create(user=user)

            login(request, user)
            messages.success(request, "Welcome to Skill Loop! Let's set up your skills.")
            return redirect("skills")
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = RegisterForm()

    return render(request, "swap/register.html", {"form": form})


# ================= LOGIN =================

def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    identifier = ""
    if request.method == "POST":
        identifier = request.POST.get("email", "").strip()

        if is_login_locked(request, identifier):
            messages.error(request, "Too many failed attempts. Please wait a few minutes and try again.")
            form = LoginForm()
        else:
            form = LoginForm(request.POST)
            if form.is_valid():
                identifier = form.cleaned_data["email"].strip()
                password = form.cleaned_data["password"]

                username = identifier
                # Allow logging in with either username or email.
                if "@" in identifier:
                    try:
                        matched_user = User.objects.get(email__iexact=identifier)
                        username = matched_user.username
                    except User.DoesNotExist:
                        username = identifier

                user = authenticate(request, username=username, password=password)

                if user is not None:
                    clear_login_failures(request, identifier)
                    login(request, user)
                    return redirect("dashboard")
                register_login_failure(request, identifier)
                messages.error(request, "Incorrect username/email or password.")
            else:
                messages.error(request, "Please complete the security check and fill in every field.")
    else:
        form = LoginForm()

    return render(request, "swap/login.html", {"form": form, "identifier": identifier})


# ================= LOGOUT =================

def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect("home")


# ================= DASHBOARD =================

@login_required(login_url="login")
def dashboard(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)

    my_skills = request.user.skills.all()
    matches = find_matches_for_user(request.user)
    recommendations = get_recommendations_for_user(request.user, limit=3)

    context = {
        "profile": profile,
        "my_skills": my_skills,
        "teach_skills": my_skills.filter(skill_type="teach"),
        "learn_skills": my_skills.filter(skill_type="learn"),
        "matches": matches[:5],
        "match_count": len(matches),
        "recommendations": recommendations,
        "received_requests": request.user.received_requests.filter(status="Pending"),
        "sent_requests": request.user.sent_requests.exclude(status="Cancelled")[:5],
        "accepted_count": SkillRequest.objects.filter(
            Q(sender=request.user) | Q(receiver=request.user), status="Accepted"
        ).count(),
    }
    return render(request, "swap/dashboard.html", context)


# ================= PROFILE =================

@login_required(login_url="login")
def view_profile(request, username=None):
    target_user = get_object_or_404(User, username=username) if username else request.user
    profile, _ = UserProfile.objects.get_or_create(user=target_user)

    context = {
        "profile_user": target_user,
        "profile": profile,
        "teach_skills": target_user.skills.filter(skill_type="teach"),
        "learn_skills": target_user.skills.filter(skill_type="learn"),
        "is_own_profile": target_user == request.user,
    }
    return render(request, "swap/profile.html", context)


@login_required(login_url="login")
def edit_profile(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        user_form = UserBasicForm(request.POST, instance=request.user)
        profile_form = ProfileForm(request.POST, request.FILES, instance=profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, "Your profile has been updated.")
            return redirect("profile")
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        user_form = UserBasicForm(instance=request.user)
        profile_form = ProfileForm(instance=profile)

    return render(
        request,
        "swap/edit_profile.html",
        {"user_form": user_form, "profile_form": profile_form},
    )


# ================= SKILLS =================

@login_required(login_url="login")
def skill_list(request):
    if request.method == "POST":
        form = SkillForm(request.POST)
        if form.is_valid():
            skill = form.save(commit=False)
            skill.owner = request.user
            skill.save()
            messages.success(request, f"Added \"{skill.name}\" to your skills.")
            return redirect("skills")
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = SkillForm()

    my_skills = request.user.skills.all()

    return render(
        request,
        "swap/skills.html",
        {
            "form": form,
            "teach_skills": my_skills.filter(skill_type="teach"),
            "learn_skills": my_skills.filter(skill_type="learn"),
        },
    )


@login_required(login_url="login")
def skill_edit(request, skill_id):
    skill = get_object_or_404(Skill, id=skill_id, owner=request.user)

    if request.method == "POST":
        form = SkillForm(request.POST, instance=skill)
        if form.is_valid():
            form.save()
            messages.success(request, "Skill updated.")
            return redirect("skills")
    else:
        form = SkillForm(instance=skill)

    return render(request, "swap/skill_edit.html", {"form": form, "skill": skill})


@login_required(login_url="login")
def skill_delete(request, skill_id):
    skill = get_object_or_404(Skill, id=skill_id, owner=request.user)
    if request.method == "POST":
        skill.delete()
        messages.success(request, "Skill removed.")
    return redirect("skills")


# ================= SEARCH & DISCOVERY =================

@login_required(login_url="login")
def search(request):
    query = request.GET.get("q", "").strip()
    category = request.GET.get("category", "").strip()
    level = request.GET.get("level", "").strip()

    skills = Skill.objects.filter(skill_type="teach").exclude(owner=request.user)

    if query:
        skills = skills.filter(Q(name__icontains=query) | Q(owner__username__icontains=query))
    if category:
        skills = skills.filter(category=category)
    if level:
        skills = skills.filter(level=level)

    return render(
        request,
        "swap/search.html",
        {
            "skills": skills.select_related("owner", "owner__profile")[:50],
            "query": query,
            "category": category,
            "level": level,
            "categories": CATEGORY_CHOICES,
            "levels": LEVEL_CHOICES,
        },
    )


# ================= RECIPROCAL MATCHING =================

@login_required(login_url="login")
def reciprocal_matches(request):
    matches = find_matches_for_user(request.user)
    return render(request, "swap/reciprocal_matches.html", {"matches": matches})


@login_required(login_url="login")
def recommendations_view(request):
    recommendations = get_recommendations_for_user(request.user, limit=12)
    return render(request, "swap/recommendations.html", {"recommendations": recommendations})


# ================= SKILL EXCHANGE REQUESTS =================

@login_required(login_url="login")
def send_request(request, username):
    receiver = get_object_or_404(User, username=username)

    if receiver == request.user:
        messages.error(request, "You cannot send a request to yourself.")
        return redirect("search")

    if request.method == "POST":
        form = SkillRequestForm(request.POST)
        if form.is_valid():
            skill_request = form.save(commit=False)
            skill_request.sender = request.user
            skill_request.receiver = receiver
            skill_request.save()
            messages.success(request, f"Your request has been sent to {receiver.username}.")
            return redirect("sent_requests")
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = SkillRequestForm()

    return render(request, "swap/send_request.html", {"form": form, "receiver": receiver})


@login_required(login_url="login")
def received_requests(request):
    requests_qs = request.user.received_requests.all()
    return render(request, "swap/received_requests.html", {"requests": requests_qs})


@login_required(login_url="login")
def sent_requests(request):
    requests_qs = request.user.sent_requests.all()
    return render(request, "swap/sent_requests.html", {"requests": requests_qs})


@login_required(login_url="login")
def respond_request(request, request_id, action):
    skill_request = get_object_or_404(SkillRequest, id=request_id, receiver=request.user)

    if action == "accept":
        skill_request.status = "Accepted"
        messages.success(request, "Request accepted! You can now coordinate your exchange.")
    elif action == "reject":
        skill_request.status = "Rejected"
        messages.info(request, "Request rejected.")
    else:
        messages.error(request, "Unknown action.")
        return redirect("received_requests")

    skill_request.save()
    return redirect("received_requests")


@login_required(login_url="login")
def cancel_request(request, request_id):
    skill_request = get_object_or_404(SkillRequest, id=request_id, sender=request.user)
    skill_request.status = "Cancelled"
    skill_request.save()
    messages.info(request, "Request cancelled.")
    return redirect("sent_requests")


# ================= LIVE COLLAB ROOMS (up to 3 people, any device) =================

@login_required(login_url="login")
def room_list(request):
    rooms = SkillRoom.objects.filter(is_active=True).select_related("created_by")
    my_rooms = rooms.filter(participants=request.user)

    if request.method == "POST":
        form = SkillRoomForm(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    room = form.save(commit=False)
                    room.created_by = request.user
                    room.save()
                    room.participants.add(request.user)
                    tokens.spend_once(
                        request.user, tokens.cfg("TOKEN_COST_ROOM"),
                        f"Hosted live room: {room.title}", f"room:{room.id}",
                    )
            except tokens.InsufficientTokens:
                messages.error(request, "You're out of tokens. Teach someone to earn more, then start your room.")
                return redirect("tokens")
            messages.success(request, f"Room \"{room.title}\" created! Share code {room.room_code}.")
            return redirect("room_detail", room_code=room.room_code)
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = SkillRoomForm()

    return render(
        request,
        "swap/rooms_list.html",
        {
            "rooms": rooms.exclude(id__in=my_rooms.values_list("id", flat=True))[:30],
            "my_rooms": my_rooms,
            "form": form,
            "token_cost": tokens.cfg("TOKEN_COST_ROOM"),
            "call_max": settings.CALL_MAX_PARTICIPANTS,
        },
    )


@login_required(login_url="login")
def room_join_by_code(request):
    if request.method != "POST":
        return redirect("room_list")
    code = request.POST.get("room_code", "").strip().upper()
    room = SkillRoom.objects.filter(room_code=code).first() if code else None
    if not room:
        messages.error(request, "No class found with that code. Check the code and try again.")
        return redirect("room_list")
    if not room.is_active:
        messages.error(request, "That class has ended and can no longer be joined.")
        return redirect("room_list")
    # Goes through the normal join page, so the security check still applies.
    return redirect("room_join", room_code=room.room_code)


_JOIN_LOCK = threading.Lock()
_CALL_LOCK = threading.Lock()


def _room_by_code(room_code, **filters):
    """Room codes are stored upper-case; URLs/typed codes are case-insensitive."""
    return get_object_or_404(SkillRoom, room_code=str(room_code).strip().upper(), **filters)


def _join_room(request, room):
    """Join a room safely even when many people click Join at the same moment.

    * a process-level lock + select_for_update serialise concurrent joins
    * capacity is re-checked inside the lock, so a room can never overfill
    * tokens are charged in the same transaction (rolled back if it fails)
    """
    if room.participants.filter(id=request.user.id).exists():
        return redirect("room_detail", room_code=room.room_code)

    outcome = "joined"
    try:
        with _JOIN_LOCK, transaction.atomic():
            locked = SkillRoom.objects.select_for_update().get(pk=room.pk)
            if locked.participants.filter(id=request.user.id).exists():
                return redirect("room_detail", room_code=room.room_code)
            if not locked.is_active:
                outcome = "inactive"
            elif locked.participants.count() >= locked.max_participants:
                outcome = "full"
            else:
                tokens.spend_once(
                    request.user, tokens.cfg("TOKEN_COST_ROOM"),
                    f"Joined live room: {locked.title}", f"room:{locked.id}",
                )
                locked.participants.add(request.user)
    except tokens.InsufficientTokens:
        messages.error(request, "You're out of tokens. Teach another user to earn more and keep learning.")
        return redirect("tokens")
    except OperationalError:
        messages.error(request, "The room is very busy right now - please try joining again.")
        return redirect("room_list")

    if outcome == "inactive":
        messages.error(request, "That class has ended and can no longer be joined.")
        return redirect("room_list")
    if outcome == "full":
        messages.error(request, f"\"{room.title}\" already has {room.max_participants} people in it.")
        return redirect("room_list")
    messages.success(request, f"You joined \"{room.title}\".")
    return redirect("room_detail", room_code=room.room_code)


@login_required(login_url="login")
def room_join(request, room_code):
    """Joining a class asks for the security check (I'm not a robot) first."""
    room = _room_by_code(room_code)
    if room.participants.filter(id=request.user.id).exists():
        return redirect("room_detail", room_code=room.room_code)
    if not room.is_active:
        messages.error(request, "That class has ended and can no longer be joined.")
        return redirect("room_list")

    if request.method == "POST":
        form = JoinRoomForm(request.POST)
        if form.is_valid():
            return _join_room(request, room)
        messages.error(request, "Please complete the security check to join this class.")
    else:
        form = JoinRoomForm()

    return render(request, "swap/room_join.html", {
        "room": room,
        "form": form,
        "token_cost": tokens.cfg("TOKEN_COST_ROOM"),
    })


@login_required(login_url="login")
@require_POST
def room_leave(request, room_code):
    room = _room_by_code(room_code)
    room.participants.remove(request.user)
    CallPresence.objects.filter(room=room, user=request.user).delete()
    CallSignal.objects.filter(room=room).filter(Q(sender=request.user) | Q(recipient=request.user)).delete()
    messages.info(request, f"You left \"{room.title}\".")
    return redirect("room_list")


@login_required(login_url="login")
def room_detail(request, room_code):
    room = _room_by_code(room_code)
    is_participant = room.participants.filter(id=request.user.id).exists()

    if request.method == "POST":
        if not is_participant:
            return HttpResponseForbidden("Join the room before posting.")
        form = RoomMessageForm(request.POST)
        if form.is_valid():
            msg = form.save(commit=False)
            msg.room = room
            msg.sender = request.user
            msg.save()
            if request.headers.get("x-requested-with") == "XMLHttpRequest":
                return JsonResponse({
                    "ok": True,
                    "message": _serialize_room_message(msg, request.user),
                })
            return redirect("room_detail", room_code=room.room_code)
        elif request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"ok": False, "errors": form.errors}, status=400)
    else:
        form = RoomMessageForm()

    # Latest 200 messages, oldest first (busy rooms keep working as they grow).
    # Chat history and the member list are only for participants.
    room_messages = []
    if is_participant:
        room_messages = list(room.messages.select_related("sender").order_by("-id")[:200])[::-1]

    return render(
        request,
        "swap/room_detail.html",
        {
            "room": room,
            "form": form,
            "is_participant": is_participant,
            "participants": room.participants.all() if is_participant else [],
            "participant_count": room.participant_count(),
            "in_call_count": _active_presence(room).count() if is_participant else 0,
            "room_messages": room_messages,
            "last_message_id": room_messages[-1].id if room_messages else 0,
            "ice_servers": settings.WEBRTC_ICE_SERVERS if is_participant else [],
            "call_max": settings.CALL_MAX_PARTICIPANTS,
            "me": {"id": request.user.id, "name": request.user.first_name or request.user.username},
        },
    )


def _serialize_room_message(msg, current_user):
    return {
        "id": msg.id,
        "sender": msg.sender.first_name or msg.sender.username,
        "is_me": msg.sender_id == current_user.id,
        "type": msg.message_type,
        "type_label": msg.get_message_type_display(),
        "content": msg.content,
        "created_at": msg.created_at.strftime("%I:%M %p"),
    }


@login_required(login_url="login")
def room_messages_api(request, room_code):
    """Polling endpoint so every open device (laptop/PC/mobile) sees new
    questions/answers within a few seconds, without needing websockets."""
    room = _room_by_code(room_code)
    if not room.participants.filter(id=request.user.id).exists():
        return HttpResponseForbidden("Not a participant of this room.")

    after_id = request.GET.get("after", 0)
    try:
        after_id = int(after_id)
    except (TypeError, ValueError):
        after_id = 0

    new_messages = room.messages.filter(id__gt=after_id).select_related("sender")[:100]

    return JsonResponse({
        "ok": True,
        "messages": [_serialize_room_message(m, request.user) for m in new_messages],
        "participant_count": room.participant_count(),
        "max_participants": room.max_participants,
        "participants": [p.first_name or p.username for p in room.participants.all()],
        "avatars": [
            {"name": p.first_name or p.username, "initial": p.username[:1].upper()}
            for p in room.participants.all()
        ],
        "is_full": room.is_full(),
        "in_call": _active_presence(room).count(),
    })


# ================= VIDEO / VOICE CALL (WebRTC signalling) =================
# The media itself goes browser-to-browser. These endpoints only keep the
# "who is in the call" list and pass the handshake messages between people.

CALL_STALE_SECONDS = 12      # no heartbeat for this long = person has left


def _call_room_or_403(request, room_code):
    room = _room_by_code(room_code, is_active=True)
    if not room.participants.filter(id=request.user.id).exists():
        return room, JsonResponse({"ok": False, "error": "Join the room first."}, status=403)
    return room, None


def _json_body(request):
    try:
        return json.loads(request.body.decode() or "{}")
    except (ValueError, UnicodeDecodeError):
        return {}


def _active_presence(room):
    cutoff = timezone.now() - timedelta(seconds=CALL_STALE_SECONDS)
    CallPresence.objects.filter(room=room, last_seen__lt=cutoff).delete()
    return CallPresence.objects.filter(room=room).select_related("user")


@login_required(login_url="login")
@require_POST
def call_join(request, room_code):
    room, denied = _call_room_or_403(request, room_code)
    if denied:
        return denied
    session = str(_json_body(request).get("session", ""))[:32]
    if not session:
        return JsonResponse({"ok": False, "error": "Missing session."}, status=400)

    # The lock + transaction make the capacity check and the insert one step,
    # so simultaneous joiners can never push the call past its limit.
    with _CALL_LOCK, transaction.atomic():
        active = _active_presence(room)
        already = active.filter(user=request.user).exists()
        if not already and active.count() >= settings.CALL_MAX_PARTICIPANTS:
            return JsonResponse({
                "ok": False,
                "error": f"The video call is full ({settings.CALL_MAX_PARTICIPANTS} people max). You can still use the class chat.",
            }, status=409)
        CallPresence.objects.update_or_create(room=room, user=request.user, defaults={"session": session})
        # Drop handshake messages left over from an earlier visit (both directions).
        CallSignal.objects.filter(room=room).filter(Q(recipient=request.user) | Q(sender=request.user)).delete()
    return JsonResponse({"ok": True})


@login_required(login_url="login")
@require_POST
def call_poll(request, room_code):
    """Heartbeat + fetch: returns who is in the call and any new handshake messages."""
    room, denied = _call_room_or_403(request, room_code)
    if denied:
        return denied
    data = _json_body(request)
    session = str(data.get("session", ""))[:32]
    try:
        after = int(data.get("after", 0))
    except (TypeError, ValueError):
        after = 0

    presence = _active_presence(room)
    mine = presence.filter(user=request.user, session=session).first()
    if not mine:
        return JsonResponse({"ok": False, "error": "not_in_call"}, status=410)
    mine.save()   # refreshes last_seen

    signals = CallSignal.objects.filter(room=room, recipient=request.user, id__gt=after)[:200]
    if after == 0 and not signals:
        CallSignal.objects.filter(room=room, created_at__lt=timezone.now() - timedelta(minutes=5)).delete()

    return JsonResponse({
        "ok": True,
        "peers": [
            {"id": p.user_id, "name": p.user.first_name or p.user.username, "session": p.session}
            for p in presence if p.user_id != request.user.id
        ],
        "signals": [
            {"id": sg.id, "from": sg.sender_id, "kind": sg.kind, "payload": sg.payload}
            for sg in signals
        ],
    })


@login_required(login_url="login")
@require_POST
def call_signal(request, room_code):
    room, denied = _call_room_or_403(request, room_code)
    if denied:
        return denied
    data = _json_body(request)
    kind = data.get("kind")
    payload = data.get("payload")
    if kind not in ("offer", "answer", "candidate") or not isinstance(payload, dict):
        return JsonResponse({"ok": False, "error": "Bad signal."}, status=400)
    try:
        to_id = int(data.get("to"))
    except (TypeError, ValueError):
        return JsonResponse({"ok": False, "error": "Bad recipient."}, status=400)

    body = json.dumps(payload)
    if len(body) > 20000:
        return JsonResponse({"ok": False, "error": "Signal too large."}, status=400)
    if to_id == request.user.id:
        return JsonResponse({"ok": False, "error": "Bad recipient."}, status=400)

    # Sender must currently be in the call, with the session they claim.
    presence = _active_presence(room)
    mine = presence.filter(user=request.user).first()
    if not mine or str(payload.get("s", "")) != mine.session:
        return JsonResponse({"ok": False, "error": "not_in_call"}, status=410)
    # Recipient must be in the same call right now, in the session targeted.
    theirs = presence.filter(user_id=to_id).first()
    if not theirs:
        return JsonResponse({"ok": False, "error": "That person already left the call."}, status=404)
    if str(payload.get("t", "")) != theirs.session:
        return JsonResponse({"ok": False, "error": "Stale session."}, status=409)

    sg = CallSignal.objects.create(room=room, sender=request.user, recipient_id=to_id, kind=kind, payload=body)
    return JsonResponse({"ok": True, "id": sg.id})


@login_required(login_url="login")
@require_POST
def call_leave(request, room_code):
    room = _room_by_code(room_code)
    CallPresence.objects.filter(room=room, user=request.user).delete()
    CallSignal.objects.filter(room=room).filter(Q(recipient=request.user) | Q(sender=request.user)).delete()
    return JsonResponse({"ok": True})


# ================= MENTOR BOOKING =================

@login_required(login_url="login")
def mentor_list(request):
    query = request.GET.get("q", "").strip()

    mentors = (
        UserProfile.objects.filter(is_mentor=True)
        .exclude(user=request.user)
        .select_related("user")
        .prefetch_related("user__skills")
    )

    if query:
        mentors = mentors.filter(
            Q(user__username__icontains=query)
            | Q(user__first_name__icontains=query)
            | Q(mentor_headline__icontains=query)
            | Q(user__skills__name__icontains=query)
        ).distinct()

    my_profile, _ = UserProfile.objects.get_or_create(user=request.user)

    if request.method == "POST" and "toggle_mentor" in request.POST:
        form = MentorProfileForm(request.POST, instance=my_profile)
        if form.is_valid():
            form.save()
            if my_profile.is_mentor:
                messages.success(request, "You're now listed as a mentor. 🎓")
            else:
                messages.info(request, "You're no longer listed as a mentor.")
            return redirect("mentor_list")
    else:
        form = MentorProfileForm(instance=my_profile)

    return render(
        request,
        "swap/mentors.html",
        {
            "mentors": mentors,
            "query": query,
            "form": form,
            "my_profile": my_profile,
        },
    )


@login_required(login_url="login")
def book_mentor(request, username):
    mentor_user = get_object_or_404(User, username=username)
    mentor_profile, _ = UserProfile.objects.get_or_create(user=mentor_user)

    if mentor_user == request.user:
        messages.error(request, "You can't book a session with yourself.")
        return redirect("mentor_list")

    if not mentor_profile.is_mentor:
        messages.error(request, "This user isn't currently offering mentor sessions.")
        return redirect("mentor_list")

    if request.method == "POST":
        form = MentorBookingForm(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    booking = form.save(commit=False)
                    booking.student = request.user
                    booking.mentor = mentor_user
                    booking.mentor_name = mentor_user.first_name or mentor_user.username
                    booking.save()
                    tokens.spend(
                        request.user, tokens.cfg("TOKEN_COST_MENTOR"),
                        f"Mentor session request: {booking.mentor_name}", f"booking:{booking.id}",
                    )
            except tokens.InsufficientTokens:
                messages.error(request, "You're out of tokens. Teach another user to earn more, then book your session.")
                return redirect("tokens")
            messages.success(request, f"Booking request sent to {booking.mentor_name}!")
            return redirect("my_bookings")
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = MentorBookingForm()

    return render(
        request,
        "swap/book_mentor.html",
        {
            "form": form,
            "mentor_user": mentor_user,
            "mentor_profile": mentor_profile,
            "token_cost": tokens.cfg("TOKEN_COST_MENTOR"),
        },
    )


@login_required(login_url="login")
def my_bookings(request):
    as_student = request.user.mentor_bookings.select_related("mentor")
    as_mentor = request.user.bookings_as_mentor.select_related("student")

    return render(
        request,
        "swap/my_bookings.html",
        {
            "as_student": as_student,
            "as_mentor": as_mentor,
            "is_mentor": getattr(request.user, "profile", None) and request.user.profile.is_mentor,
        },
    )


@login_required(login_url="login")
@require_POST
def respond_booking(request, booking_id, action):
    booking = get_object_or_404(MentorBooking, id=booking_id, mentor=request.user)

    if action == "confirm":
        booking.status = "Confirmed"
        messages.success(request, "Booking confirmed.")
    elif action == "decline":
        booking.status = "Declined"
        tokens.refund(booking.student, f"booking:{booking.id}", "Refund: mentor declined your session")
        messages.info(request, "Booking declined. The student's tokens were refunded.")
    elif action == "complete":
        booking.status = "Completed"
        messages.success(request, "Marked as completed. Nice work!")
    else:
        messages.error(request, "Unknown action.")
        return redirect("my_bookings")

    booking.save()
    return redirect("my_bookings")


@login_required(login_url="login")
@require_POST
def cancel_booking(request, booking_id):
    booking = get_object_or_404(MentorBooking, id=booking_id, student=request.user)
    was_pending = booking.status == "Pending"
    booking.status = "Cancelled"
    booking.save()
    if was_pending and tokens.refund(request.user, f"booking:{booking.id}", "Refund: you cancelled a pending session"):
        messages.info(request, "Booking cancelled and your tokens were refunded.")
    else:
        messages.info(request, "Booking cancelled.")
    return redirect("my_bookings")


# ================= AI CHATBOT =================

@login_required(login_url="login")
def chatbot_view(request):
    history = list(request.user.chat_messages.all()[:100])
    return render(request, "swap/chatbot.html", {"history": history})


@login_required(login_url="login")
@require_POST
def chatbot_api(request):
    try:
        payload = json.loads(request.body.decode("utf-8") or "{}")
    except (ValueError, UnicodeDecodeError):
        payload = {}

    message = (payload.get("message") or request.POST.get("message") or "").strip()
    if not message:
        return HttpResponseBadRequest("Message required.")
    message = message[:1000]

    recent = list(
        request.user.chat_messages.order_by("-created_at")[:8]
    )[::-1]
    history = [{"role": m.role, "content": m.content} for m in recent]

    ChatMessage.objects.create(user=request.user, role="user", content=message)

    try:
        reply = generate_bot_reply(request.user, message, history=history)
    except Exception:
        reply = "Sorry, I hit a snag processing that - could you try rephrasing?"

    ChatMessage.objects.create(user=request.user, role="bot", content=reply)

    return JsonResponse({"ok": True, "reply": reply})


# ================= TOKENS: learn by teaching =================

@login_required(login_url="login")
def tokens_wallet(request):
    wallet = tokens.get_wallet(request.user)

    if request.method == "POST":
        form = TeachSessionForm(request.POST, teacher=request.user)
        if form.is_valid():
            learner = form.learner
            blocker = tokens.teach_blocker(request.user, learner)
            open_count = TeachSession.objects.filter(teacher=request.user, status="Pending").count()
            if blocker:
                form.add_error(None, blocker)
            elif TeachSession.objects.filter(teacher=request.user, learner=learner, status="Pending").exists():
                form.add_error("learner_username", "You already have a lesson waiting for this learner to confirm.")
            elif open_count >= 5:
                form.add_error(None, "You have 5 lessons waiting for confirmation. Wait for some to be confirmed first.")
            else:
                TeachSession.objects.create(
                    teacher=request.user,
                    learner=learner,
                    skill=form.cleaned_data["skill"].strip(),
                    summary=form.cleaned_data["summary"].strip(),
                )
                messages.success(
                    request,
                    f"Sent to {learner.first_name or learner.username} for confirmation. "
                    f"You'll earn {tokens.cfg('TOKEN_REWARD_TEACH')} tokens once they confirm.",
                )
                return redirect("tokens")
    else:
        form = TeachSessionForm(
            teacher=request.user,
            initial={"learner_username": request.GET.get("learner", "")},
        )

    return render(request, "swap/tokens.html", {
        "wallet": wallet,
        "form": form,
        "history": request.user.token_transactions.all()[:15],
        "pending_for_me": TeachSession.objects.filter(learner=request.user, status="Pending").select_related("teacher"),
        "my_sessions": TeachSession.objects.filter(teacher=request.user).select_related("learner")[:8],
        "cost_room": tokens.cfg("TOKEN_COST_ROOM"),
        "welcome_bonus": tokens.cfg("TOKEN_WELCOME_BONUS"),
        "cost_mentor": tokens.cfg("TOKEN_COST_MENTOR"),
        "reward": tokens.cfg("TOKEN_REWARD_TEACH"),
        "daily_limit": tokens.cfg("TOKEN_TEACH_DAILY_LIMIT"),
        "out_of_tokens": wallet.balance < min(tokens.cfg("TOKEN_COST_ROOM"), tokens.cfg("TOKEN_COST_MENTOR")),
    })


@login_required(login_url="login")
@require_POST
def teach_respond(request, session_id, action):
    if action in ("confirm", "decline"):
        session = get_object_or_404(TeachSession, id=session_id, learner=request.user)
        name = session.teacher.first_name or session.teacher.username
        if action == "confirm":
            reward = tokens.confirm_teach_session(session)
            if reward is None:
                messages.info(request, "That lesson was already handled.")
            elif reward:
                messages.success(request, f"Thanks for confirming! {name} earned {reward} tokens.")
            else:
                messages.info(request, f"Lesson confirmed. {name} has hit a reward limit, so no tokens were paid this time.")
        else:
            TeachSession.objects.filter(pk=session.pk, status="Pending").update(
                status="Declined", resolved_at=timezone.now()
            )
            messages.info(request, "Lesson declined.")
    elif action == "cancel":
        session = get_object_or_404(TeachSession, id=session_id, teacher=request.user)
        TeachSession.objects.filter(pk=session.pk, status="Pending").update(
            status="Cancelled", resolved_at=timezone.now()
        )
        messages.info(request, "Lesson cancelled.")
    else:
        messages.error(request, "Unknown action.")
    return redirect("tokens")


# ================= FEEDBACK / COMPLAINTS =================

@login_required(login_url="login")
def feedback_new(request):
    if request.method == "POST":
        form = FeedbackForm(request.POST, user=request.user)
        recent = Feedback.objects.filter(
            user=request.user, created_at__gte=timezone.now() - timedelta(hours=1)
        ).count()
        if recent >= 5:
            messages.error(request, "You've sent several reports in the last hour. Please wait a little before sending more.")
        elif form.is_valid():
            item = form.save(commit=False)
            item.user = request.user
            item.save()
            messages.success(request, "Thank you! Your report was sent to the Skill Loop team.")
            return redirect("feedback_list")
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        initial = {}
        room_code = request.GET.get("room", "").strip().upper()
        if room_code:
            room = SkillRoom.objects.filter(room_code=room_code).first()
            if room:
                initial.update({"target": "class", "room": room.pk, "kind": "complaint"})
        form = FeedbackForm(user=request.user, initial=initial)

    return render(request, "swap/feedback_form.html", {"form": form})


@login_required(login_url="login")
def feedback_list(request):
    items = request.user.feedback_items.select_related("room")
    return render(request, "swap/feedback_list.html", {"items": items})


# ================= SECURITY CAPTCHA =================

@require_GET
def captcha_image(request):
    try:
        nonce = captcha.check_token(request.GET.get("t", ""))
    except captcha.CaptchaError:
        return HttpResponse(status=400)
    response = HttpResponse(captcha.render_png(captcha.code_for(nonce)), content_type="image/png")
    response["Cache-Control"] = "no-store, max-age=0"
    return response


@require_GET
def captcha_new(request):
    response = JsonResponse({"token": captcha.new_token()})
    response["Cache-Control"] = "no-store, max-age=0"
    return response
