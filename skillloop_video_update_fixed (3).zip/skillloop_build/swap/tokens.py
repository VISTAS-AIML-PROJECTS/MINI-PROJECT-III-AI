"""
Token economy helpers. All writes are single atomic UPDATEs with a guard
(balance >= amount), so two simultaneous requests can never overspend.
"""
from datetime import timedelta

from django.conf import settings
from django.db import transaction
from django.db.models import F
from django.utils import timezone

from .models import TokenWallet, TokenTransaction, TeachSession


class InsufficientTokens(Exception):
    pass


def cfg(name):
    defaults = {
        "TOKEN_WELCOME_BONUS": 50,
        "TOKEN_COST_ROOM": 1,
        "TOKEN_COST_MENTOR": 2,
        "TOKEN_REWARD_TEACH": 3,
        "TOKEN_TEACH_DAILY_LIMIT": 3,
    }
    return getattr(settings, name, defaults[name])


def get_wallet(user):
    wallet, created = TokenWallet.objects.get_or_create(
        user=user, defaults={"balance": cfg("TOKEN_WELCOME_BONUS")}
    )
    if created and wallet.balance:
        TokenTransaction.objects.create(
            user=user, amount=wallet.balance, kind="bonus",
            reason="Welcome bonus", balance_after=wallet.balance,
        )
    return wallet


def balance(user):
    return get_wallet(user).balance


def _log(user, amount, kind, reason, reference):
    new_balance = TokenWallet.objects.values_list("balance", flat=True).get(user=user)
    return TokenTransaction.objects.create(
        user=user, amount=amount, kind=kind, reason=reason[:200],
        reference=reference, balance_after=new_balance,
    )


@transaction.atomic
def spend(user, amount, reason, reference=""):
    get_wallet(user)
    changed = TokenWallet.objects.filter(user=user, balance__gte=amount).update(
        balance=F("balance") - amount
    )
    if not changed:
        raise InsufficientTokens(f"You need {amount} token(s) for this.")
    return _log(user, -amount, "spend", reason, reference)


def spend_once(user, amount, reason, reference):
    """Charge at most once per reference (e.g. re-joining a room is free)."""
    if TokenTransaction.objects.filter(user=user, kind="spend", reference=reference).exists():
        return None
    return spend(user, amount, reason, reference)


@transaction.atomic
def earn(user, amount, reason, reference="", kind="earn"):
    get_wallet(user)
    TokenWallet.objects.filter(user=user).update(balance=F("balance") + amount)
    return _log(user, amount, kind, reason, reference)


@transaction.atomic
def refund(user, reference, reason="Refund"):
    """Give back a spend made under `reference`, once."""
    spent = TokenTransaction.objects.filter(user=user, kind="spend", reference=reference).first()
    if not spent:
        return False
    if TokenTransaction.objects.filter(user=user, kind="refund", reference=reference).exists():
        return False
    earn(user, -spent.amount, reason, reference, kind="refund")
    return True


# ---------- teaching rewards ----------

def teach_blocker(teacher, learner):
    """Return a reason string if this teacher can't earn from this learner now."""
    since = timezone.now() - timedelta(hours=24)
    confirmed = TeachSession.objects.filter(
        teacher=teacher, status="Confirmed", tokens_awarded__gt=0, resolved_at__gte=since
    )
    if confirmed.count() >= cfg("TOKEN_TEACH_DAILY_LIMIT"):
        return (f"You've reached today's limit of {cfg('TOKEN_TEACH_DAILY_LIMIT')} "
                "rewarded lessons. Try again tomorrow.")
    if confirmed.filter(learner=learner).exists():
        return "You already earned tokens from this learner in the last 24 hours."
    return None


def confirm_teach_session(session):
    """
    Learner confirms -> teacher is paid (unless an anti-abuse limit applies,
    in which case the lesson is still recorded but earns nothing).
    Returns the number of tokens awarded, or None if it was already resolved.
    """
    with transaction.atomic():
        reward = 0 if teach_blocker(session.teacher, session.learner) else cfg("TOKEN_REWARD_TEACH")
        updated = TeachSession.objects.filter(pk=session.pk, status="Pending").update(
            status="Confirmed", resolved_at=timezone.now(), tokens_awarded=reward,
        )
        if not updated:
            return None
        if reward:
            earn(
                session.teacher, reward,
                f"Taught {session.skill} to {session.learner.first_name or session.learner.username}",
                reference=f"teach:{session.pk}",
            )
    return reward
