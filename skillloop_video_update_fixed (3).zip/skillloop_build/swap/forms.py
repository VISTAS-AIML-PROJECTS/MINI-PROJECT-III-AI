from django import forms
from django.contrib.auth.models import User
from django.db.models import Q

from .models import (
    UserProfile, Skill, SkillRequest, MentorBooking, SkillRoom, RoomMessage, Feedback,
)
from .security import BotProtectionMixin


class RegisterForm(forms.ModelForm):
    """Sign-up form built on top of Django's User model."""

    password = forms.CharField(
        widget=forms.PasswordInput(attrs={"placeholder": "Create a password"}),
        min_length=6,
    )

    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={"placeholder": "Confirm your password"}),
        min_length=6,
    )

    class Meta:
        model = User
        fields = ["username", "email", "first_name"]
        widgets = {
            "username": forms.TextInput(attrs={"placeholder": "Choose a username"}),
            "email": forms.EmailInput(attrs={"placeholder": "you@example.com"}),
            "first_name": forms.TextInput(attrs={"placeholder": "Your full name"}),
        }
        labels = {
            "first_name": "Full name",
        }

    def clean_email(self):
        email = self.cleaned_data["email"]
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email

    def clean_username(self):
        username = self.cleaned_data["username"]
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("This username is already taken.")
        return username

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")

        if password and confirm_password and password != confirm_password:
            raise forms.ValidationError("Passwords do not match.")

        return cleaned_data


class ProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ["profile_picture", "bio", "location", "interests", "experience_level"]
        widgets = {
            "bio": forms.Textarea(attrs={"rows": 4, "placeholder": "Tell others about yourself..."}),
            "location": forms.TextInput(attrs={"placeholder": "City, Country"}),
            "interests": forms.TextInput(attrs={"placeholder": "e.g. AI, Music, Startups"}),
        }


class UserBasicForm(forms.ModelForm):
    """Lets a user update their name/email alongside their profile."""

    class Meta:
        model = User
        fields = ["first_name", "email"]
        widgets = {
            "first_name": forms.TextInput(attrs={"placeholder": "Your full name"}),
            "email": forms.EmailInput(attrs={"placeholder": "you@example.com"}),
        }
        labels = {
            "first_name": "Full name",
        }


class SkillForm(forms.ModelForm):
    class Meta:
        model = Skill
        fields = ["name", "category", "level", "skill_type"]
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "e.g. Python, UI/UX Design"}),
        }


class SkillRequestForm(forms.ModelForm):
    class Meta:
        model = SkillRequest
        fields = ["skill_offered", "skill_wanted", "message"]
        widgets = {
            "message": forms.Textarea(
                attrs={"rows": 3, "placeholder": "Write a short message introducing yourself..."}
            ),
        }


# ================= MENTOR BOOKING =================

class MentorProfileForm(forms.ModelForm):
    """Lets a user flip themselves into/out of being a bookable mentor."""

    class Meta:
        model = UserProfile
        fields = ["is_mentor", "mentor_headline"]
        widgets = {
            "mentor_headline": forms.TextInput(
                attrs={"placeholder": "e.g. Senior React developer, 6 years experience"}
            ),
        }


class MentorBookingForm(forms.ModelForm):
    class Meta:
        model = MentorBooking
        fields = ["skill", "booking_date", "booking_time", "duration_minutes", "notes"]
        widgets = {
            "skill": forms.TextInput(attrs={"placeholder": "What do you want help with?"}),
            "booking_date": forms.DateInput(attrs={"type": "date"}),
            "booking_time": forms.TimeInput(attrs={"type": "time"}),
            "duration_minutes": forms.NumberInput(attrs={"min": 15, "step": 15}),
            "notes": forms.Textarea(
                attrs={"rows": 3, "placeholder": "Anything the mentor should know beforehand?"}
            ),
        }


# ================= LIVE ROOMS =================

class SkillRoomForm(forms.ModelForm):
    class Meta:
        model = SkillRoom
        fields = ["title", "topic", "max_participants"]
        widgets = {
            "title": forms.TextInput(attrs={"placeholder": "e.g. Python debugging help"}),
            "topic": forms.TextInput(attrs={"placeholder": "e.g. Programming"}),
        }


class JoinRoomForm(BotProtectionMixin, forms.Form):
    """Only the security check - shown when someone joins a class."""


class RoomMessageForm(forms.ModelForm):
    class Meta:
        model = RoomMessage
        fields = ["message_type", "content"]
        widgets = {
            "content": forms.Textarea(
                attrs={"rows": 2, "placeholder": "Type a message...", "maxlength": 2000}
            ),
        }


# ================= LOGIN (captcha-protected) =================

class LoginForm(BotProtectionMixin, forms.Form):
    """Field names match the existing login template (email = username or email)."""

    email = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput, max_length=128, strip=False)


# ================= TOKENS: teach to earn =================

class TeachSessionForm(forms.Form):
    learner_username = forms.CharField(
        max_length=150,
        label="Who did you teach?",
        widget=forms.TextInput(attrs={"placeholder": "Their username", "autocomplete": "off"}),
    )
    skill = forms.CharField(
        max_length=100,
        label="Skill you taught",
        widget=forms.TextInput(attrs={"placeholder": "e.g. Python basics"}),
    )
    summary = forms.CharField(
        min_length=10,
        max_length=500,
        label="What did you cover?",
        widget=forms.Textarea(attrs={"rows": 3, "placeholder": "A sentence or two about the lesson..."}),
    )

    def __init__(self, *args, teacher=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.teacher = teacher
        self.learner = None

    def clean_learner_username(self):
        username = self.cleaned_data["learner_username"].strip()
        try:
            learner = User.objects.get(username__iexact=username)
        except User.DoesNotExist:
            raise forms.ValidationError("No user with that username.")
        if self.teacher is not None and learner.pk == self.teacher.pk:
            raise forms.ValidationError("You can't teach yourself - pick another learner.")
        self.learner = learner
        return learner.username


# ================= FEEDBACK =================

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ["kind", "target", "room", "subject", "message"]
        labels = {"kind": "What is this?", "target": "It's about", "room": "Which class?"}
        widgets = {
            "subject": forms.TextInput(attrs={"placeholder": "Short summary", "maxlength": 140}),
            "message": forms.Textarea(attrs={
                "rows": 5, "maxlength": 2000,
                "placeholder": "Tell us what happened. The more detail, the faster we can fix it.",
            }),
        }

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["room"].required = False
        self.fields["room"].empty_label = "Select the class / room"
        self.fields["message"].min_length = 10
        if user is not None:
            self.fields["room"].queryset = SkillRoom.objects.filter(
                Q(participants=user) | Q(messages__sender=user) | Q(created_by=user)
            ).distinct()
        else:
            self.fields["room"].queryset = SkillRoom.objects.none()

    def clean_message(self):
        message = self.cleaned_data["message"].strip()
        if len(message) < 10:
            raise forms.ValidationError("Please add a little more detail (at least 10 characters).")
        return message

    def clean(self):
        cleaned = super().clean()
        target, room = cleaned.get("target"), cleaned.get("room")
        if target == "class" and not room:
            self.add_error("room", "Please choose the class this is about.")
        if target == "site":
            cleaned["room"] = None
        return cleaned
