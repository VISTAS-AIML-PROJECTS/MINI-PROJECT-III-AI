"""
Reciprocal skill matching engine for Skill Loop.

The core idea:
    User A "can teach" something User B "wants to learn", AND
    User B "can teach" something User A "wants to learn".

That is a reciprocal match. We turn that into a 0-100 match score so
users can see how strong a match is, not just whether one exists.
"""

from django.contrib.auth.models import User

from .models import UserProfile


def _names_lower(skill_qs):
    return {s.name.strip().lower() for s in skill_qs if s.name.strip()}


def find_matches_for_user(user):
    """
    Return a list of dicts, one per potential match, sorted by score
    (highest first). Each dict contains:
        - user: the matched User
        - profile: their UserProfile (or None)
        - score: 0-100 match percentage
        - i_can_teach_them: skills I teach that they want to learn
        - they_can_teach_me: skills they teach that I want to learn
        - reciprocal: True if the match works both ways
    """

    my_teach = _names_lower(user.skills.filter(skill_type="teach"))
    my_learn = _names_lower(user.skills.filter(skill_type="learn"))

    if not my_teach and not my_learn:
        return []

    matches = []

    other_users = (
        User.objects.exclude(id=user.id)
        .filter(is_active=True)
        .prefetch_related("skills")
        .select_related("profile")
    )

    for other in other_users:
        other_teach = _names_lower(other.skills.filter(skill_type="teach"))
        other_learn = _names_lower(other.skills.filter(skill_type="learn"))

        # Skills I can teach them (my "teach" overlaps their "learn")
        i_can_teach_them = my_teach & other_learn

        # Skills they can teach me (their "teach" overlaps my "learn")
        they_can_teach_me = other_teach & my_learn

        if not i_can_teach_them and not they_can_teach_me:
            continue

        reciprocal = bool(i_can_teach_them) and bool(they_can_teach_me)

        # --- Scoring ---
        # Base score: reciprocal matches score much higher than one-directional ones.
        if reciprocal:
            score = 70
        else:
            score = 35

        # Bonus for each extra overlapping skill (diminishing returns).
        overlap_count = len(i_can_teach_them) + len(they_can_teach_me)
        score += min(25, (overlap_count - 1) * 8) if overlap_count > 0 else 0

        # Small bonus if the users share an interest, since that suggests
        # a good cultural / motivational fit for an exchange.
        try:
            my_interests = set(i.lower() for i in user.profile.interests_list())
            other_interests = set(i.lower() for i in other.profile.interests_list())
            if my_interests & other_interests:
                score += 5
        except UserProfile.DoesNotExist:
            pass

        score = max(1, min(100, score))

        matches.append(
            {
                "user": other,
                "profile": getattr(other, "profile", None),
                "score": score,
                "i_can_teach_them": sorted(i_can_teach_them),
                "they_can_teach_me": sorted(they_can_teach_me),
                "reciprocal": reciprocal,
            }
        )

    matches.sort(key=lambda m: m["score"], reverse=True)
    return matches


def get_recommendations_for_user(user, limit=6):
    """
    Simple AI-style recommendation layer built on top of matching.

    For now this uses the same reciprocal-matching signal plus a popularity
    boost (users with more total skills listed are considered more active
    on the platform), which gives a believable "recommendation score"
    without needing an ML library. This can be swapped for a real
    content-based / cosine-similarity model later without changing the
    calling code.
    """

    matches = find_matches_for_user(user)

    recommendations = []
    for match in matches:
        other = match["user"]
        activity_bonus = min(10, other.skills.count())
        ai_score = max(1, min(100, match["score"] + activity_bonus // 2))

        reasons = []
        if match["they_can_teach_me"]:
            reasons.append(
                f"{other.first_name or other.username} can teach you "
                f"{', '.join(match['they_can_teach_me'][:2])}."
            )
        if match["i_can_teach_them"]:
            reasons.append(
                f"You can teach {', '.join(match['i_can_teach_them'][:2])}, "
                f"which {other.first_name or other.username} wants to learn."
            )

        recommendations.append(
            {
                **match,
                "ai_score": ai_score,
                "reasons": reasons,
            }
        )

    recommendations.sort(key=lambda m: m["ai_score"], reverse=True)
    return recommendations[:limit]
