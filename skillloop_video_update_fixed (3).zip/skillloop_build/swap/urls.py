from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),

    # Auth
    path("register/", views.register_view, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),

    # Dashboard
    path("dashboard/", views.dashboard, name="dashboard"),

    # Profile
    path("profile/", views.view_profile, name="profile"),
    path("profile/edit/", views.edit_profile, name="edit_profile"),
    path("profile/<str:username>/", views.view_profile, name="view_profile"),

    # Skills
    path("skills/", views.skill_list, name="skills"),
    path("skills/<int:skill_id>/edit/", views.skill_edit, name="skill_edit"),
    path("skills/<int:skill_id>/delete/", views.skill_delete, name="skill_delete"),

    # Search & discovery
    path("search/", views.search, name="search"),

    # Matching
    path("matches/", views.reciprocal_matches, name="reciprocal_matches"),
    path("recommendations/", views.recommendations_view, name="recommendations"),

    # Skill exchange requests
    path("request/<str:username>/", views.send_request, name="send_request"),
    path("requests/received/", views.received_requests, name="received_requests"),
    path("requests/sent/", views.sent_requests, name="sent_requests"),
    path("requests/<int:request_id>/cancel/", views.cancel_request, name="cancel_request"),
    path("requests/<int:request_id>/<str:action>/", views.respond_request, name="respond_request"),

    # Live rooms: video call + chat (up to 50 in the room, any device)
    path("rooms/", views.room_list, name="room_list"),
    path("rooms/join-by-code/", views.room_join_by_code, name="room_join_by_code"),
    path("rooms/<str:room_code>/", views.room_detail, name="room_detail"),
    path("rooms/<str:room_code>/join/", views.room_join, name="room_join"),
    path("rooms/<str:room_code>/call/join/", views.call_join, name="call_join"),
    path("rooms/<str:room_code>/call/poll/", views.call_poll, name="call_poll"),
    path("rooms/<str:room_code>/call/signal/", views.call_signal, name="call_signal"),
    path("rooms/<str:room_code>/call/leave/", views.call_leave, name="call_leave"),
    path("rooms/<str:room_code>/leave/", views.room_leave, name="room_leave"),
    path("rooms/<str:room_code>/messages/", views.room_messages_api, name="room_messages_api"),

    # Mentor booking
    path("mentors/", views.mentor_list, name="mentor_list"),
    path("mentors/<str:username>/book/", views.book_mentor, name="book_mentor"),
    path("bookings/", views.my_bookings, name="my_bookings"),
    path("bookings/<int:booking_id>/cancel/", views.cancel_booking, name="cancel_booking"),
    path("bookings/<int:booking_id>/<str:action>/", views.respond_booking, name="respond_booking"),

    # Tokens (learn by teaching)
    path("tokens/", views.tokens_wallet, name="tokens"),
    path("tokens/teach/<int:session_id>/<str:action>/", views.teach_respond, name="teach_respond"),

    # Feedback / complaints
    path("feedback/", views.feedback_list, name="feedback_list"),
    path("feedback/new/", views.feedback_new, name="feedback_new"),

    # Security captcha
    path("captcha/image/", views.captcha_image, name="captcha_image"),
    path("captcha/new/", views.captcha_new, name="captcha_new"),

    # AI chatbot
    path("assistant/", views.chatbot_view, name="chatbot"),
    path("assistant/api/", views.chatbot_api, name="chatbot_api"),
]
