# Skill Loop

A peer-to-peer skill-exchange platform built with Django. Users list skills
they can teach and skills they want to learn, get matched with people whose
skills complement theirs (reciprocal skill matching), book mentor sessions,
and collaborate live in small group rooms — with a built-in AI assistant
to help along the way.

## Features in this build

- User registration, login, logout (Django auth)
- User profile (picture, bio, location, interests, experience level)
- Skill management (add / edit / delete, category + level)
- Skill search & discovery (filter by category/level/keyword)
- Reciprocal skill matching engine with a match score
- AI-style recommendation engine with explained reasons ("AI Picks")
- Skill exchange request system (send / accept / reject / cancel)
- **Live Classes with video + voice + chat** — every class room has a built-in
  camera/microphone call (peer-to-peer WebRTC) and a chat panel, so two people
  can see, hear and message each other. Up to 50 people (you pick 2 / 3 / 5 / 10 / 25 / 50 when
  creating a room) can join the same room at once, from any device (laptop,
  PC, or mobile browser), and post Questions / Answers / Notes. Joining is
  concurrency-safe: a room can never overfill even if everyone clicks Join at
  the same second. Every open device polls for updates automatically (~every 3
  seconds). The video call supports up to 6 people at once (`CALL_MAX_PARTICIPANTS`);
  the rest of the class can still follow along in chat, so everyone stays in sync without needing to refresh.
- **Mentor booking** — any user can flip on "list me as a mentor", other
  users can browse mentors and book a session (date, time, duration,
  notes); mentors confirm/decline from "My Bookings".
- **Built-in AI chatbot assistant** — a floating widget on every page (plus
  a full "Assistant" page) that answers questions about how the site
  works. It runs entirely offline with a rule-based brain, so it always
  responds instantly with zero setup. If you set an `ANTHROPIC_API_KEY`
  environment variable, it will automatically upgrade to real Claude
  responses and fall back to the offline brain if that call ever fails.
- **Tokens (learn by teaching)** — every member has a token wallet (shown in
  the navbar). Joining/hosting a live room and requesting a mentor session
  cost tokens. When you run out, the way to keep learning is to teach another
  user: submit the lesson on the **Tokens** page, the learner confirms it, and
  you earn tokens. Built-in fair-use limits stop token farming.
- **Feedback & complaints** — members can report a complaint, issue or
  suggestion about a class (live room) or the website (footer link, dashboard
  button, or "Report an issue" inside a room). Staff reply from the Django
  admin and the member sees the reply and status on **My reports**.
- **Security** — a self-hosted "I'm not a robot" code (no API keys, no
  internet needed) asked **only on Login and when joining a class**, plus a hidden honeypot
  field, a minimum-fill-time check, single-use codes, and a temporary lock
  after 5 wrong passwords.
- Personalized dashboard with quick links to everything above
- Fully responsive, clean dark-navy professional UI (mobile, tablet, desktop)

## Setup

```bash
# 1. Create and activate a virtual environment (if not already active)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create the database tables
#    (if you already have an older db.sqlite3 from a previous version, delete it
#     first for a clean start, or run the same two commands to upgrade it)
python manage.py makemigrations swap
python manage.py migrate

#    Already have members? Give everyone the new 50-token balance:
python manage.py topup_tokens --to 50

# 4. (Optional) create an admin account
python manage.py createsuperuser

# 5. Run the development server
python manage.py runserver
```

Open **http://127.0.0.1:8000/** in your browser.

### (Optional) Turn on real AI replies for the chatbot

By default the assistant works fully offline. To upgrade it to a real LLM,
set an environment variable before starting the server:

```bash
export ANTHROPIC_API_KEY="sk-ant-..."     # Windows: set ANTHROPIC_API_KEY=sk-ant-...
python manage.py runserver
```

No key? No problem — the assistant keeps working using its built-in
knowledge base, it just won't be a full LLM.

## Video calls: camera and microphone (read this first)

Browsers only allow camera/microphone on a **secure address**: `https://...`
or `http://localhost`. That means:

- **Testing alone:** run the server and open `http://localhost:8000` in two
  different browser windows (or one normal + one private window), log in as two
  users, join the same class, click **Join video call** in both.
- **Testing on another device / friend's phone:** `http://192.168.x.x:8000` will
  NOT get camera access (the browser blocks it). Put the site on HTTPS instead,
  e.g. run `ngrok http 8000` or `cloudflared tunnel --url http://localhost:8000`
  and open the `https://` link it prints on every device.
- **Real deployment:** Render / Railway / PythonAnywhere all give you HTTPS.
  Also set `ALLOWED_HOSTS` and `CSRF_TRUSTED_ORIGINS` to your domain.

Calls connect browser-to-browser. Most networks work with the free STUN servers
already configured. If two people on strict/corporate/mobile networks can see
each other's tile but get "Connection failed", add a TURN server to
`WEBRTC_ICE_SERVERS` in `settings.py`.

## Getting multiple people onto the SAME running app (multi-device)

Skill Loop is a normal web app: everyone who opens the same URL in their
browser sees the same live data (skills, matches, rooms, bookings), because
it's all stored on one server / one database. To let people join from
*different physical devices* (not just different browser tabs on your own
machine), you have two easy options:

**Option A — Same Wi-Fi / local network (fastest for testing with friends nearby)**

```bash
python manage.py runserver 0.0.0.0:8000
```

Then find your computer's local IP (e.g. `192.168.1.23` — run `ipconfig`
on Windows or `ifconfig`/`ip addr` on Mac/Linux) and have others open
`http://192.168.1.23:8000/` on their laptop, PC, or phone, as long as
they're on the same Wi-Fi network as the server.

**Option B — Deploy it to the internet (works from anywhere, any network)**

Push this project to a host like Render, Railway, PythonAnywhere, or
Fly.io (all have free tiers that run Django comfortably). Once deployed,
everyone reaches the same public URL from any device, anywhere — this is
the right choice once you're done testing locally.

> `ALLOWED_HOSTS` is already set to `["*"]` in `skillloop/settings.py` to
> make local network testing painless. Lock it down to your real domain(s)
> before deploying somewhere public.

## How to try the reciprocal matching

1. Register **User A**, go to "My Skills", add:
   - Can Teach: `Python`
   - Wants to Learn: `UI/UX Design`
2. Log out, register **User B**, add:
   - Can Teach: `UI/UX Design`
   - Wants to Learn: `Python`
3. Log in as either user and open **Matches** in the navbar — you should
   see the other user listed as a reciprocal match with a score, and be
   able to send them a swap request from there.

## How to try a live class (video + chat)

1. Log in as **User A**, go to **Live Rooms → Create room** (title +
   optional topic, max people = 3), then open the room.
2. Copy the room code shown at the top.
3. On a second device/browser, log in as **User B**, go to **Live Rooms →
   Have a room code?**, paste it, and join.
4. Repeat with a **User C** on a third device.
5. In both browsers click **Join video call** and allow camera/microphone.
   You should see and hear each other within a few seconds.
6. Use the chat panel next to the video; messages appear for everyone automatically.

## How to try mentor booking

1. Log in as **User A**, go to **Mentors**, tick "List me as a mentor",
   add a headline, and save.
2. Log in as **User B**, go to **Mentors**, find User A, and click
   **Book a session** — pick a skill, date, time, and duration.
3. Log back in as **User A**, go to **My Bookings** → "Requests as
   mentor", and Confirm or Decline the request.

## Tuning the token system

All numbers live at the bottom of `skillloop/settings.py`:

```python
TOKEN_WELCOME_BONUS = 50       # free tokens for every member
TOKEN_COST_ROOM = 1            # join / host a live room
TOKEN_COST_MENTOR = 2          # request a mentor session (refunded if declined)
TOKEN_REWARD_TEACH = 3         # earned when a learner confirms your lesson
TOKEN_TEACH_DAILY_LIMIT = 3    # rewarded lessons per teacher per 24h
```

Admins can grant or remove tokens by hand in **Admin → Token wallets**.

## How to try tokens

1. Log in as **User A**, open **Live Rooms** and join rooms until the token
   chip in the navbar reaches 0 (you'll be sent to the Tokens page).
2. On the Tokens page fill in **Teach to earn** with **User B**'s username.
3. Log in as **User B** → **Tokens** → "Lessons waiting for your confirmation"
   → **Yes, they taught me**.
4. Log back in as **User A** — the balance went up and you can keep learning.

## How to try feedback

1. Click **Feedback** in the footer (or **Report an issue** inside a room),
   fill in the form, solve the security code and send.
2. In **/admin → Feedback** open the report, write a response, set the status.
3. The member sees the reply under **Feedback → My reports**.

## Project structure

```
skillloop/        Django project settings & root urls
swap/             The main app (models, views, forms, matching engine, ai assistant, templates)
swap/ai.py        The chatbot's rule-based brain + optional real-LLM upgrade hook
swap/tokens.py    Token wallet / ledger / teach-to-earn rules
swap/captcha.py   Self-hosted "I'm not a robot" image challenge
swap/security.py  Bot-protection form mixin + login lockout
swap/middleware.py  Allows camera/microphone for this site (Permissions-Policy)
static/css/       Shared stylesheet (design system)
```

## Live class video calls: deployment notes

* Everyone must open the SAME deployed server (same database). `localhost` only works for people on your own machine.
* Camera/microphone need **HTTPS** (or `localhost`). Plain `http://192.168.x.x:8000` is not guaranteed to allow them; use an HTTPS host (a tunnel such as ngrok/Cloudflare Tunnel or a real deployment).
* STUN is built in. To add a TURN relay for strict networks, set environment variables before starting Django:
  `TURN_URL=turn:turn.example.com:3478  TURN_USERNAME=...  TURN_CREDENTIAL=...`
* Class chat: up to 50 people. Video call: max 6 at once (`CALL_MAX_PARTICIPANTS`).
* First run: `python manage.py makemigrations swap && python manage.py migrate`, then `python manage.py test swap`.
